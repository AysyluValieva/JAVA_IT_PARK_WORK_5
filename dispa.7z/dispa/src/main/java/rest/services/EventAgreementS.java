package rest.services;

import rest.dto.EventAgreementDto;
import rest.forms.EventAgreementForm;
import rest.forms.SrvRenderedForm;
import rest.forms.EventServicePatientForm;



import java.util.List;

public interface EventAgreementS {

    List<EventAgreementDto> getOneEventAgreement();

    void addEventAgreement(EventAgreementForm eventAgreement);
    void updateEventAgreement(EventAgreementForm eventAgreement);
    void addEventServicePatient(EventServicePatientForm eventServicePatient);


}
