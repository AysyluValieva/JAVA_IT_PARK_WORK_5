package rest.services;

import rest.dto.ClinicDto;
import rest.dto.EventDto;
import rest.dto.EventPatientsDto;
import rest.dto.IndividualDto;
import rest.forms.EventPatientForm;


import java.util.List;
import java.util.Optional;

public interface EventPatientS {

    List<ClinicDto> getClinics();
    List<EventDto> getEvents();
    List<IndividualDto> getIndividual(String surname);

    List<EventPatientsDto> getAllEventPatient(Integer eventId);

    void addEventPatient(EventPatientForm eventPatient);
}
