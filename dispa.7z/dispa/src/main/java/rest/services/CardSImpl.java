package rest.services;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

import rest.forms.EventPatientForm;
import rest.models.*;
import rest.repositories.*;
import rest.dto.*;
import rest.dto.IndividualDto;


@Component
public class CardSImpl implements CardS{

    @Autowired
    private IndividualRepository individualRepository;

    public List<IndividualDto> getIndividual(Integer indivId) {
        List<Individual> individuals = individualRepository.findOneIndividualById(indivId);

        List<IndividualDto> individualDtos = new ArrayList<>();
        for (Individual individual : individuals) {
            individualDtos.add(IndividualDto.builder()
                    .id(individual.getId())
                    .name(individual.getName())
                    .patrName(individual.getPatrName())
                    .surname(individual.getSurname())
                    .genderID(individual.getGenderID().getCode())
                    .birthDt(individual.getBirthDt())
                    .build());
        }
        return individualDtos;
    }


    @Autowired
    private CardRepository cardRepository;

    public List<CartDto> getCart(Integer eventPatientId) {
        List<EventServicePatient> eventServicePatients = cardRepository.findByEventPatientId(eventPatientId);

        List<CartDto> cartDtos = new ArrayList<>();
        for (EventServicePatient eventServicePatient : eventServicePatients) {
            cartDtos.add(CartDto.builder()
                    .id(eventServicePatient.getId())
                    .serviceName(eventServicePatient.getEventServiceID().getServiceID().getName())
                    .status(eventServicePatient.getStatus().getName())
                    .build());
        }
        return cartDtos;
    }
}
