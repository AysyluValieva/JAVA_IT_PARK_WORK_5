package rest.services;

import rest.dto.CartDto;
import rest.dto.IndividualDto;


import java.util.List;

public interface CardS {

    List<IndividualDto> getIndividual(Integer indivId);
    List<CartDto> getCart(Integer eventPatientId);
}
