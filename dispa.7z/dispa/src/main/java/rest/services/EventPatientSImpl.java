package rest.services;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

import rest.forms.EventPatientForm;
import rest.models.*;
import rest.repositories.*;
import rest.dto.ClinicDto;
import rest.dto.EventDto;
import rest.dto.EventPatientsDto;
import rest.dto.IndividualDto;


@Component
public class EventPatientSImpl implements EventPatientS{

    @Autowired
    private ClinicRepository clinicsRepository;

    public List<ClinicDto> getClinics() {
        List<Clinic> clinics = clinicsRepository.findOneClinic();

        List<ClinicDto> clinicDtos = new ArrayList<>();
        for (Clinic clinic : clinics) {
            clinicDtos.add(ClinicDto.builder()
                      .id(clinic.getId())
                      .shortName(clinic.getShortName())
                    .build());
        }
        return clinicDtos;
    }

    @Autowired
    private EventRepository eventsRepository;

    public List<EventDto> getEvents() {
        List<Event> events = eventsRepository.findOneEvent();

        List<EventDto> eventDtos = new ArrayList<>();
        for (Event event : events) {
            eventDtos.add(EventDto.builder()
                    .id(event.getId())
                    .name(event.getName())
                    .build());
        }
        return eventDtos;
    }

    @Autowired
    private IndividualRepository individualRepository;

    public List<IndividualDto> getIndividual(String surname) {
        List<Individual> individuals = individualRepository.findBySurname(surname);

        List<IndividualDto> individualDtos = new ArrayList<>();
        for (Individual individual : individuals) {
            individualDtos.add(IndividualDto.builder()
                    .id(individual.getId())
                    .name(individual.getName())
                    .patrName(individual.getPatrName())
                    .surname(individual.getSurname())
                    .genderID(individual.getGenderID().getCode())
                    .birthDt(individual.getBirthDt())
                    .build());
        }
        return individualDtos;
    }


    @Autowired
    private EventPatientsRepository eventPatientsRepository;

    public List<EventPatientsDto> getAllEventPatient(Integer eventId) {
        List<EventPatient> eventParients = eventPatientsRepository.findByEventId(eventId);

        List<EventPatientsDto> eventPatientsDtos = new ArrayList<>();
        for (EventPatient eventPatient : eventParients) {
            eventPatientsDtos.add(EventPatientsDto.builder()
                    .id(eventPatient.getId())
                    .eventID(eventPatient.getEventID().getId())
                    .indivID(eventPatient.getIndivID().getId())
                    .name(eventPatient.getIndivID().getName())
                    .surname(eventPatient.getIndivID().getSurname())
                    .patrName(eventPatient.getIndivID().getPatrName())
                    .gender(eventPatient.getIndivID().getGenderID().getCode())
                    .birthDt(eventPatient.getIndivID().getBirthDt())
                    .eventName(eventPatient.getEventID().getName())
                    .build());
        }
        return eventPatientsDtos;
    }



    @Override
    public void addEventPatient(EventPatientForm eventPatient) {

        Event event = eventsRepository.findOneEventID().get();
        Individual indiv = individualRepository.findOneIndividualID(eventPatient.getIndivID()).get();

        EventPatient newEventPatient = EventPatient.builder()
                .eventID(event)
                .indivID(indiv)
                .build();
        eventPatientsRepository.save(newEventPatient);

    }
}
