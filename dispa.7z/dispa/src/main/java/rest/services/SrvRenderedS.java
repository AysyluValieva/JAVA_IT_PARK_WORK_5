package rest.services;

import rest.dto.SrvRenderedDto;
import rest.forms.SrvRenderedForm;
import rest.models.EventServicePatient;


import java.util.List;

public interface SrvRenderedS {

    List<SrvRenderedDto> getSrvRendered(Integer srvId);

    SrvRenderedDto updateSrvRendered(SrvRenderedForm srvRenderedId);

}
