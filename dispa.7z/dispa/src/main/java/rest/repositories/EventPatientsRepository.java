package rest.repositories;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import rest.models.EventPatient;

import java.util.List;
public interface EventPatientsRepository extends JpaRepository<EventPatient, Integer>{


    @Query(nativeQuery = true, value = "SELECT mep.id, mep.event_id, mep.indiv_id, i.name, i.surname, i.patr_name, g.code, i.birth_dt, e.name as eventName " +
            "from disp.md_event_patient mep " +
            "join public.pim_individual i on i.id = mep.indiv_id " +
            "join public.pim_gender g on g.id = i.gender_id " +
            "join disp.md_event e on e.id = mep.event_id " +
            "where mep.event_id = ?1")
    List<EventPatient> findByEventId(Integer eventId);
}
