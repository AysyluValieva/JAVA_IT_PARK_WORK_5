package rest.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import rest.models.ServiceStatus;
import java.util.List;
import java.util.Optional;
public interface ServiceStatusRepository extends JpaRepository<ServiceStatus, Integer> {

    @Query(nativeQuery = true, value = "SELECT id, name from disp.md_event_service_status WHERE UPPER (name) like '%'||upper(?1)||'%' limit 1")
    List<ServiceStatus> findOneStatus(String surname);

    @Query(nativeQuery = true, value = "SELECT id, name from pim_individual WHERE UPPER (name) like '%'||upper(?1)||'%' limit 1")
    Optional<ServiceStatus> findOneStatusByName(String name);
}
