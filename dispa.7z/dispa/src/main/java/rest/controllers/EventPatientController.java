package rest.controllers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import rest.dto.EventPatientsDto;
import rest.forms.EventPatientForm;
import rest.services.EventPatientS;


import java.util.List;

@Controller
public class EventPatientController {

    @Autowired
    private EventPatientS service;

    @GetMapping("/events/{event-id}/eventPatients")
    @ResponseBody
    public ResponseEntity<List<EventPatientsDto>>
    getUsersOfGroup(@PathVariable("event-id") Integer eventId) {
        return ResponseEntity.ok(service.getAllEventPatient(eventId));
    }

    @GetMapping("/eventPatients")
    public String getEventPatientsPage(ModelMap model) {
        List<EventPatientsDto> eventPatients = service.getAllEventPatient(2501);
        model.addAttribute("eventPatients", eventPatients);
        return "EventPatients_page";
    }

    @PostMapping("/eventPatients")
    public String addUser(EventPatientForm eventPatient) {
        service.addEventPatient(eventPatient);
        return "redirect:/eventPatients";
    }
}
