CREATE FUNCTION print_setting_create_or_update(p_id integer, p_block1top integer, p_block1left integer, p_block2top integer, p_block2left integer, p_block3top integer, p_block3left integer, p_registrator_id integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
DECLARE
  result_id INTEGER;
  l_block1top INTEGER;
  l_block1left INTEGER;
  l_block2top INTEGER;
  l_block2left INTEGER;
  l_block3top INTEGER;
  l_block3left INTEGER;
  l_is_update BOOLEAN;
BEGIN
  IF p_registrator_id ISNULL
  THEN RAISE EXCEPTION 'Регистрирующее лицо не определено'; END IF;

  SELECT COALESCE (p_block1top, 0)
  INTO l_block1top;

  SELECT COALESCE (p_block1left, 0)
  INTO l_block1left;

  SELECT COALESCE (p_block2top, 0)
  INTO l_block2top;

  SELECT COALESCE (p_block2left, 0)
  INTO l_block2left;

  SELECT COALESCE (p_block3top, 0)
  INTO l_block3top;

  SELECT COALESCE (p_block3left, 0)
  INTO l_block3left;

  l_is_update = CASE WHEN p_id NOTNULL AND exists(SELECT 1
                                                  FROM sickdoc.print_settings
                                                  WHERE id = p_id) THEN TRUE
                ELSE FALSE END;

  IF l_is_update
  THEN
    UPDATE sickdoc.print_settings SET
      block1left = l_block1left,
      block1top = l_block1top,
      block2left = l_block2left,
      block2top = l_block2top,
      block3left = l_block3left,
      block3top = l_block3top
    WHERE ID = p_id;
    result_id =  p_id;
  ELSE
    --т.к новая запись автоматически становится основной для регистратора, всем остальным записям регистратора необходимо предварительно установить статус is_main = false
    UPDATE sickdoc.print_settings
    SET is_main = FALSE
    WHERE registrator_id = p_registrator_id;

    INSERT INTO sickdoc.print_settings(
      id, block1left, block1top, block2left, block2top, block3left, block3top, is_main, registrator_id )
    VALUES(
      DEFAULT, l_block1left, l_block1top, l_block2left, l_block2top, l_block3left, l_block3top, TRUE, p_registrator_id ) returning id into result_id;

  END IF;

  return result_id;

END;
$$;

