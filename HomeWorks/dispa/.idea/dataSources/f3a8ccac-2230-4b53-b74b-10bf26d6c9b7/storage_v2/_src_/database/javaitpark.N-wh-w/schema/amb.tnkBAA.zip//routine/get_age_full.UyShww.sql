CREATE FUNCTION get_age_full(birth_dt date, open_dt date)
  RETURNS interval
LANGUAGE plpgsql
AS $$
declare
  age interval := '0 day';
--    age text :='0';
begin
  if birth_dt IS NULL or open_dt IS NULL
  	then
    	return age;
    	exit;
  end if;
  IF (DATE_PART('year', open_dt) - DATE_PART('year', birth_dt) - (CASE TO_CHAR(open_dt, 'MMDD') < TO_CHAR(birth_dt, 'MMDD') WHEN TRUE THEN 1 ELSE 0 END)) <= 0
  	THEN
    	if date_part('month', open_dt) - date_part('month',birth_dt) - (CASE TO_CHAR(open_dt, 'DD') < TO_CHAR(birth_dt, 'DD') WHEN TRUE THEN 1 ELSE 0 END) <= 0
        	then
				age = CAST(open_dt - birth_dt ||' day' AS INTERVAL);
--            	age = cast(cast(date_part('day', open_dt) - date_part('day',birth_dt) as varchar(2))||' day' as interval);
--				age = cast(date_part('day', open_dt) - date_part('day',birth_dt) as varchar(2))||' day';
            else
            	age = cast(cast(date_part('month', open_dt) - date_part('month',birth_dt) - (CASE TO_CHAR(open_dt, 'DD') < TO_CHAR(birth_dt, 'DD') WHEN TRUE THEN 1 ELSE 0 END) as varchar(2))||' month' as interval);
--                age = cast(date_part('month', open_dt) - date_part('month',birth_dt) - (CASE TO_CHAR(open_dt, 'DD') < TO_CHAR(birth_dt, 'DD') WHEN TRUE THEN 1 ELSE 0 END) as varchar(2))||' month';
        end if;
    ELSE
    	age = cast(cast(DATE_PART('year', open_dt) - DATE_PART('year', birth_dt) - (CASE TO_CHAR(open_dt, 'MMDD') < TO_CHAR(birth_dt, 'MMDD') WHEN TRUE THEN 1 ELSE 0 END) as varchar(3))||' year' as interval);
--        age = cast(DATE_PART('year', open_dt) - DATE_PART('year', birth_dt) - (CASE TO_CHAR(open_dt, 'MMDD') < TO_CHAR(birth_dt, 'MMDD') WHEN TRUE THEN 1 ELSE 0 END) as varchar(3))||' year';
  END IF;
  return age;
end;
$$;

