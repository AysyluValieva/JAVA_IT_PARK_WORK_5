CREATE FUNCTION fin_spec_validate(p1_bill_id integer, p2_user_id integer)
  RETURNS void
STRICT
LANGUAGE plpgsql
AS $$
DECLARE
    _r RECORD;
    _v VARCHAR;
    _validation_code VARCHAR[];
    _validation_enabled BOOLEAN[];
    _validation_title VARCHAR[];
BEGIN
    /*
        version: 2015-01-28
    */
    -----------------------------------------------------отключаемые валидации-----------------------------------------------------------------------
    _validation_code := ARRAY 
    [
        'PRICE_IS_NULL',              --1
        'PRICE_MIN_VALUE'             --2
    ];
    _validation_title := NULL;
    FOREACH _v IN ARRAY _validation_code 
    LOOP 
        SELECT 
            coalesce (u.enabled, v.enabled) AS enabled, title INTO _r 
        FROM 
            fin_bill_validation                AS v 
            LEFT JOIN fin_bill_validation_user AS u ON u.validation_id = v.id AND u.user_id = p2_user_id
        WHERE 
            v.code = _v;
        _validation_enabled := _validation_enabled || _r.enabled;
        _validation_title   := _validation_title   || _r.title  ;
    END LOOP;
    
    DELETE FROM fin_bill_spec_item_error AS e WHERE e.code = ANY (_validation_code) AND EXISTS (SELECT 1 FROM fin_bill_spec_item WHERE bill_id = p1_bill_id AND id = e.item_id)
    ;
    FOR _r IN 
        SELECT id, price FROM fin_bill_spec_item WHERE bill_id = p1_bill_id
    LOOP
        IF 
            _validation_enabled[1] AND _r.price IS NULL
        THEN
            INSERT INTO fin_bill_spec_item_error (id, error, code, item_id) 
                SELECT nextval ('fin_bill_spec_item_error_seq'), _validation_title[1], 'PRICE_IS_NULL', _r.id;
        ELSIF 
            _validation_enabled[2] AND _r.price < 1
        THEN
            INSERT INTO fin_bill_spec_item_error (id, error, code, item_id) 
                SELECT nextval ('fin_bill_spec_item_error_seq'), _validation_title[2], 'PRICE_MIN_VALUE', _r.id;
        END IF;
    END LOOP;
    -----------------------------------------------------обновление поля с ошибками------------------------------------------------------------------
    UPDATE fin_bill_steps AS s
    SET
        spec_err_exists = EXISTS (SELECT 1 FROM fin_bill_spec_item_error WHERE item_id = s.spec_item_id)
    WHERE
        s.bill_id = p1_bill_id
    ;
END;
$$;

