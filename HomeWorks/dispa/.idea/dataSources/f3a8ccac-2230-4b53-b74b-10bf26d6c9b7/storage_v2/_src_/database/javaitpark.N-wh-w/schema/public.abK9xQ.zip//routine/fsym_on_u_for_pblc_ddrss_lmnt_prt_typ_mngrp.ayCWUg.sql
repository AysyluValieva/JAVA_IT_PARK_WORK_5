CREATE FUNCTION fsym_on_u_for_pblc_ddrss_lmnt_prt_typ_mngrp()
  RETURNS trigger
LANGUAGE plpgsql
AS $fun$
declare var_row_data text; 
                                declare var_old_data text; 
                                begin
                                   
                                  if 1=1 and "public".sym_triggers_disabled() = 0 then                                                                                                 
                                    var_row_data := 
          case when new."id" is null then '' else '"' || cast(cast(new."id" as numeric) as varchar) || '"' end||','||
          case when new."format" is null then '' else '"' || replace(replace(cast(new."format" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."name" is null then '' else '"' || replace(replace(cast(new."name" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."ordern" is null then '' else '"' || cast(cast(new."ordern" as numeric) as varchar) || '"' end||','||
          case when new."short_name" is null then '' else '"' || replace(replace(cast(new."short_name" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."level_id" is null then '' else '"' || cast(cast(new."level_id" as numeric) as varchar) || '"' end; 
                                    var_old_data := 
          case when old."id" is null then '' else '"' || cast(cast(old."id" as numeric) as varchar) || '"' end||','||
          case when old."format" is null then '' else '"' || replace(replace(cast(old."format" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when old."name" is null then '' else '"' || replace(replace(cast(old."name" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when old."ordern" is null then '' else '"' || cast(cast(old."ordern" as numeric) as varchar) || '"' end||','||
          case when old."short_name" is null then '' else '"' || replace(replace(cast(old."short_name" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when old."level_id" is null then '' else '"' || cast(cast(old."level_id" as numeric) as varchar) || '"' end; 
                                    if 1=1 then 
                                    insert into "public".sym_data                                                                                                                     
                                    (table_name, event_type, trigger_hist_id, pk_data, row_data, old_data, channel_id, transaction_id, source_node_id, external_data, create_time)                     
                                    values(                                                                                                                                                            
                                      'address_element_part_type',                                                                                                                                            
                                      'U',                                                                                                                                                             
                                      23,                                                                                                                                             
                                      
          case when old."id" is null then '' else '"' || cast(cast(old."id" as numeric) as varchar) || '"' end,                                                                                                                                                      
                                      var_row_data,                                                                                                                                                      
                                      var_old_data,                                                                                                                                                   
                                      'public_address_element_part_type_default',                                                                                                                                                
                                      txid_current(),                                                                                                                                               
                                      "public".sym_node_disabled(),                                                                                                                   
                                      null,                                                                                                                                               
                                      CURRENT_TIMESTAMP                                                                                                                
                                    );                                                                                                                                                                 
                                  end if;                                                                                                                                                              
                                  end if;                                                                                                                                                              
                                                                                                                                                                               
                                  return null;                                                                                                                                                         
                                end;
$fun$;

