CREATE FUNCTION insert_into_step_step_regimen(clinic_id integer, code character varying, name character varying, is_closed boolean, is_death boolean, is_refusal boolean, is_future boolean, is_transfer_permitted boolean, is_planning boolean, is_reason boolean, e_code character varying, fdate date, tdate date)
  RETURNS integer
LANGUAGE plpgsql
AS $$
DECLARE
                step_id integer;
                step_care_id integer;
                regimen_id integer;
            BEGIN
                step_id := (select MAX(id) from mc_step_result) +1 ;
                step_care_id := ( select MAX(id) from mc_step_result_to_care_regimen) + 1;
                regimen_id := (select id from mc_care_regimen cr where cr.e_code = '6');
                insert into mc_step_result (id, clinic_id, code,name,is_closed,is_death,is_refusal,is_future,is_transfer_permitted,is_planning,is_reason,e_code, from_dt, to_dt )
                    values (step_id, clinic_id, code,name,is_closed,is_death,is_refusal,is_future,is_transfer_permitted,is_planning,is_reason,e_code, fdate, tdate );
                insert into mc_step_result_to_care_regimen(id, code, step_result_id, regimen_id, from_dt, to_dt)
                    values(step_care_id, step_care_id, step_id, regimen_id, fdate, tdate);
                return step_id;
            END
$$;

