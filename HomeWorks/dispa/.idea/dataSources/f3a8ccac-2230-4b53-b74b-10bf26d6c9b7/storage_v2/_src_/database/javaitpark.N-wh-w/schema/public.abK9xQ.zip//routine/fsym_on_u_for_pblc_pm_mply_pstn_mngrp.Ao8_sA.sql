CREATE FUNCTION fsym_on_u_for_pblc_pm_mply_pstn_mngrp()
  RETURNS trigger
LANGUAGE plpgsql
AS $fun$
declare var_row_data text; 
                                declare var_old_data text; 
                                begin
                                   
                                  if 1=1 and "public".sym_triggers_disabled() = 0 then                                                                                                 
                                    var_row_data := 
          case when new."id" is null then '' else '"' || cast(cast(new."id" as numeric) as varchar) || '"' end||','||
          case when new."dismissal_order_code" is null then '' else '"' || replace(replace(cast(new."dismissal_order_code" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."start_date" is null then '' else '"' || to_char(new."start_date", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when new."hiring_order_code" is null then '' else '"' || replace(replace(cast(new."hiring_order_code" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."rate" is null then '' else '"' || cast(cast(new."rate" as numeric) as varchar) || '"' end||','||
          case when new."end_date" is null then '' else '"' || to_char(new."end_date", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when new."dismissal_reason_id" is null then '' else '"' || cast(cast(new."dismissal_reason_id" as numeric) as varchar) || '"' end||','||
          case when new."employee_id" is null then '' else '"' || cast(cast(new."employee_id" as numeric) as varchar) || '"' end||','||
          case when new."employment_type_id" is null then '' else '"' || cast(cast(new."employment_type_id" as numeric) as varchar) || '"' end||','||
          case when new."hiring_type_id" is null then '' else '"' || cast(cast(new."hiring_type_id" as numeric) as varchar) || '"' end||','||
          case when new."position_id" is null then '' else '"' || cast(cast(new."position_id" as numeric) as varchar) || '"' end||','||
          case when new."position_type_id" is null then '' else '"' || cast(cast(new."position_type_id" as numeric) as varchar) || '"' end||','||
          case when new."unit_id" is null then '' else '"' || cast(cast(new."unit_id" as numeric) as varchar) || '"' end||','||
          case when new."code" is null then '' else '"' || replace(replace(cast(new."code" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."pref_prescription" is null then '' when new."pref_prescription" then '"1"' else '"0"' end||','||
          case when new."extra_payment" is null then '' when new."extra_payment" then '"1"' else '"0"' end||','||
          case when new."target_training" is null then '' when new."target_training" then '"1"' else '"0"' end||','||
          case when new."leaving_reason_id" is null then '' else '"' || cast(cast(new."leaving_reason_id" as numeric) as varchar) || '"' end; 
                                    var_old_data := 
          case when old."id" is null then '' else '"' || cast(cast(old."id" as numeric) as varchar) || '"' end||','||
          case when old."dismissal_order_code" is null then '' else '"' || replace(replace(cast(old."dismissal_order_code" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when old."start_date" is null then '' else '"' || to_char(old."start_date", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when old."hiring_order_code" is null then '' else '"' || replace(replace(cast(old."hiring_order_code" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when old."rate" is null then '' else '"' || cast(cast(old."rate" as numeric) as varchar) || '"' end||','||
          case when old."end_date" is null then '' else '"' || to_char(old."end_date", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when old."dismissal_reason_id" is null then '' else '"' || cast(cast(old."dismissal_reason_id" as numeric) as varchar) || '"' end||','||
          case when old."employee_id" is null then '' else '"' || cast(cast(old."employee_id" as numeric) as varchar) || '"' end||','||
          case when old."employment_type_id" is null then '' else '"' || cast(cast(old."employment_type_id" as numeric) as varchar) || '"' end||','||
          case when old."hiring_type_id" is null then '' else '"' || cast(cast(old."hiring_type_id" as numeric) as varchar) || '"' end||','||
          case when old."position_id" is null then '' else '"' || cast(cast(old."position_id" as numeric) as varchar) || '"' end||','||
          case when old."position_type_id" is null then '' else '"' || cast(cast(old."position_type_id" as numeric) as varchar) || '"' end||','||
          case when old."unit_id" is null then '' else '"' || cast(cast(old."unit_id" as numeric) as varchar) || '"' end||','||
          case when old."code" is null then '' else '"' || replace(replace(cast(old."code" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when old."pref_prescription" is null then '' when old."pref_prescription" then '"1"' else '"0"' end||','||
          case when old."extra_payment" is null then '' when old."extra_payment" then '"1"' else '"0"' end||','||
          case when old."target_training" is null then '' when old."target_training" then '"1"' else '"0"' end||','||
          case when old."leaving_reason_id" is null then '' else '"' || cast(cast(old."leaving_reason_id" as numeric) as varchar) || '"' end; 
                                    if var_old_data is null or var_row_data != var_old_data then 
                                    insert into "public".sym_data                                                                                                                     
                                    (table_name, event_type, trigger_hist_id, pk_data, row_data, old_data, channel_id, transaction_id, source_node_id, external_data, create_time)                     
                                    values(                                                                                                                                                            
                                      'pim_employee_position',                                                                                                                                            
                                      'U',                                                                                                                                                             
                                      18285,                                                                                                                                             
                                      
          case when old."id" is null then '' else '"' || cast(cast(old."id" as numeric) as varchar) || '"' end,                                                                                                                                                      
                                      var_row_data,                                                                                                                                                      
                                      var_old_data,                                                                                                                                                   
                                      'public_pim_employee_position_default',                                                                                                                                                
                                      txid_current(),                                                                                                                                               
                                      "public".sym_node_disabled(),                                                                                                                   
                                      null,                                                                                                                                               
                                      CURRENT_TIMESTAMP                                                                                                                
                                    );                                                                                                                                                                 
                                  end if;                                                                                                                                                              
                                  end if;                                                                                                                                                              
                                                                                                                                                                               
                                  return null;                                                                                                                                                         
                                end;
$fun$;

