CREATE FUNCTION add_res_team_job_resourse(xteam integer, xchange integer, xres integer, xrole integer, xworkplace character varying, xjobkind integer, xhead boolean, xplanbd timestamp without time zone, xplaned timestamp without time zone, xreg integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
						nv_id integer;
						xplanbdt TIMESTAMP WITHOUT TIME ZONE;
						xplanedt TIMESTAMP WITHOUT TIME ZONE;
					  begin
						select into xplanbdt,xplanedt cast(from_data+from_time as TIMESTAMP),cast(to_data+to_time as TIMESTAMP) from amb.md_ambulance_change where id =  xchange;
						nv_id = nextval('amb.sr_res_team_job_resourse_id_seq');
						insert into amb.sr_res_team_job_resourse(id,change_id,team_job_id,resource_id,role_id,workplace,job_kind_id,is_head,planned_bdate,planned_edate,registrator_id)
										values (nv_id,xchange,xteam,xres,xrole,xworkplace,xjobkind,xhead,coalesce(xplanbd,xplanbdt),coalesce(xplaned,xplanedt),xreg);

						/* на откуп валидациям
						if not exists (select * from amb.sr_res_team_job_resourse where resource_id = xres and change_id = xchange)
						  then
							insert into amb.sr_res_team_job_resourse(id,change_id,team_job_id,resource_id,role_id,workplace,job_kind_id,is_head,planned_bdate,planned_edate,registrator_id)
										values (nv_id,xchange,xteam,xres,xrole,xworkplace,xjobkind,xhead,coalesce(xplanbd,xplanbdt),coalesce(xplaned,xplanedt),xreg);
						end if;
						*/
						return nv_id;
					  end;

$$;

