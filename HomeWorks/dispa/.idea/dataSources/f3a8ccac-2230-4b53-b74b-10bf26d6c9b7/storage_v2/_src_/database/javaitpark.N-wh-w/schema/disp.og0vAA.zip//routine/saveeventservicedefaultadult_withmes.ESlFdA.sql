CREATE FUNCTION saveeventservicedefaultadult_withmes(xepid integer, xssrid integer, xcaseid integer, xbdate character varying, xresource integer, xservice integer, xorg integer, xmes integer DEFAULT NULL::integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
          serviceid integer;
          srrid integer;
          xstatus integer;
          isLink boolean;
          orgservice integer;
          isMdService boolean;
          stepid integer;
          oldstepid integer;
        begin
        orgservice := (select mes.org_id from disp.md_event_service mes  where mes.service_id = serviceid and mes.event_id=(select event_id from disp.md_event_patient where id=xepid));
        if (orgservice=xorg) then xstatus:=4; else xstatus:=3; end if;
        select (count(1) > 0) into isLink from disp.md_event_service_link where xssrid is not null and service_id=xssrid;
        if (isLink) then
             xstatus:=3;
        else xstatus:=4;
        end if;

        select (count(1) > 0) into isMdService from disp.md_event_patient mep
                left join MD_SRV_RENDERED msr on msr.case_id = mep.case_id
                inner join SR_SRV_RENDERED ssr on ssr.id = msr.id and ssr.service_id = serviceid
                where mep.id = xepid;

        serviceid = xservice;

          if (isLink OR isMdService) then
              if xssrid IS NULL then
                  if(isLink) then
                         xssrid = (select service_id from disp.md_event_service_link where service_id=xssrid);
                  else xssrid = (select ssr.id from disp.md_event_patient mep
                                  left join MD_SRV_RENDERED msr on msr.case_id = mep.case_id
                                  inner join SR_SRV_RENDERED ssr on ssr.id = msr.id and ssr.service_id = serviceid
                                  where mep.id = xepid);
                  end if;
              end if;
              srrid = xssrid;
              if (select res_group_id from SR_SRV_RENDERED where id = xssrid) <> xresource then
                oldstepid = (select step_id from MD_SRV_RENDERED where id = xssrid);
                stepid = (select disp.find_insert_mc_step_withMes(xepid, xbdate, xcaseId, xresource, xmes));
                update MD_SRV_RENDERED set step_id = stepid where id = xssrid;
                if (select count(1) = 0 from md_srv_rendered where step_id = oldstepid) then
                  delete from mc_step where id = oldstepid;
                end if;
              end if;
              update SR_SRV_RENDERED set bdate=COALESCE(to_date(xbdate, 'DD.MM.YYYY'), current_date), edate=COALESCE(to_date(xbdate, 'DD.MM.YYYY'), current_date), res_group_id=xresource
               where id = xssrid;

          else
            srrid = nextval('sr_srv_rendered_seq');
            insert into SR_SRV_RENDERED (id, service_id, bdate, res_group_id, customer_id, is_rendered, edate, quantity, funding_id, org_id, payment_status_id)
              values (srrid, serviceid, COALESCE(to_date(xbdate, 'DD.MM.YYYY'), current_date), xresource, (select indiv_id from disp.md_event_patient where id = xepid), TRUE, COALESCE(to_date(xbdate, 'DD.MM.YYYY'), current_date), 1,
              (select me.pay_type from disp.md_event me left join disp.md_event_patient mep on mep.event_id=me.id  where mep.id=xepid),
              (select me.org_id from disp.md_event_patient mep left join disp.md_event me on me.id = mep.event_id where mep.id = xepid), 1);
            stepid = (select disp.find_insert_mc_step_withMes(xepid, xbdate, xcaseId, xresource, xmes));
            insert into MD_SRV_RENDERED (id, case_id, step_id) values (srrid, xcaseId, stepid);

          end if;

          -- change STATUS
          update disp.md_event_service_patient  set status = xstatus
              where  id = (select mesp.id from disp.md_event_patient mep
                left join disp.md_event_service_patient mesp on mesp.event_patient_id = mep.id
                inner join disp.md_event_service mes on mes.id = mesp.service_id and mes.service_id = serviceid
                where mep.id = xepid);
          return srrid;
        end;
$$;

