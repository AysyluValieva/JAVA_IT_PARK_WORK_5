CREATE FUNCTION fin_fill_pivot_cases_table_dev(p1_bill_id integer)
  RETURNS void
STRICT
LANGUAGE plpgsql
AS $$
DECLARE 
    _code_ogrn_org_id INTEGER;
    _code_oms_id INTEGER;
    _code_snils_ind_id INTEGER;
	
	_r RECORD;
	
	_is_log BOOLEAN:=TRUE;
BEGIN
    IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_fill_pivot_cases_table. Начало'); END IF;
    --IF EXISTS (SELECT 1 FROM billing.fin_bill_cases WHERE bill_id = p1_bill_id) THEN DELETE FROM billing.fin_bill_cases WHERE bill_id = p1_bill_id; END IF;
    
    _code_ogrn_org_id  := (SELECT id FROM public.pim_code_type WHERE code = 'OGRN'    );
    _code_oms_id       := (SELECT id FROM public.pim_code_type WHERE code = 'CODE_OMS');
    _code_snils_ind_id := (SELECT id FROM public.pim_code_type WHERE code = 'SNILS'   );
    --------------общие сведения------------------
    DROP TABLE IF EXISTS tmp_fin_bill_cases;
    CREATE TEMP TABLE tmp_fin_bill_cases (LIKE billing.fin_bill_cases INCLUDING DEFAULTS INCLUDING CONSTRAINTS) 	
	   ON COMMIT PRESERVE ROWS;      

    CREATE UNIQUE INDEX tt_fbc_case_id ON tmp_fin_bill_cases (case_id);   

    	
    INSERT INTO tmp_fin_bill_cases 
    (
        bill_id, case_id, care_regimen_id, patient_id, patient_age, active_policy_id, belonging_type, new_born, id_pac, 
        step_cnt, open_date, close_date, last_id, last_outcome_date, region_data, item_id_arr
    )
        SELECT
            bill_id, case_id, care_regimen_id, patient_id, patient_age, active_policy_id, belonging_type, new_born, id_pac,
            step_cnt, case_open_date, case_close_date, closing_step_id, case_close_date, hstore('pr_nov',region_data -> 'pr_nov'), array_agg (fin_bill_spec_item_id)
        FROM 
            tmp_fin_bill_generate 
        WHERE 
            1 = 1 /*bill_id = p1_bill_id*/ AND NOT is_sifted AND case_id IS NOT NULL
        GROUP BY 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15
    ;
	--raise notice '1: %', clock_timestamp();	
	ANALYZE tmp_fin_bill_cases;

	--raise notice '2: %', clock_timestamp();	
	
    WITH cases AS 
    (
        SELECT
            f.bill_id, 
            f.case_id,
            coalesce (trim (c.uid), '') AS uid,
            c.admission_type_id,
            c.care_level_id,
            m.code::TEXT AS care_regimen_code,
            coalesce (trim (l.code), '') AS care_level_code,
            coalesce (trim (t.code), '') AS case_type_code,
            t.case_mode_id,
            coalesce (trim (r.code), '') AS repeat_count_code,
            coalesce (trim (p.code), '') AS payment_method_code,
            ARRAY [coalesce (trim (g.code), ''), coalesce (trim (g.e_code), '')] AS init_goal_code_arr,
            coalesce (trim (o.code), '') AS care_providing_form_code,
            coalesce (trim (i.code), '') AS provision_condition_code,
            coalesce (trim (n.code), '') AS ref_clinic_code, 
            coalesce (trim (s.code), '') AS ref_clinic_code_oms
         FROM 
            tmp_fin_bill_cases                           AS f
            JOIN public.mc_case                          AS c ON c.id = f.case_id
            LEFT JOIN public.mc_payment_method           AS p ON p.id = c.payment_method_id
            LEFT JOIN public.mc_case_type                AS t ON t.id = c.case_type_id
            LEFT JOIN public.mc_repeat_count             AS r ON r.id = c.repeat_count_id
            LEFT JOIN public.mc_care_regimen             AS m ON m.id = c.care_regimen_id
            LEFT JOIN public.mc_care_level               AS l ON l.id = c.care_level_id
            LEFT JOIN public.mc_case_init_goal           AS g ON g.id = c.init_goal_id
            LEFT JOIN public.md_care_providing_form      AS o ON o.id = c.care_providing_form_id
            LEFT JOIN public.md_care_provision_condition AS i ON i.id = c.provision_condition_id
            LEFT JOIN public.md_referral                 AS e ON e.id = c.referral_id
            LEFT JOIN public.md_clinic                   AS n ON n.id = e.ref_organization_id
            LEFT JOIN public.pim_org_code                AS s ON s.org_id = n.id AND s.type_id = _code_oms_id
        WHERE
            1 = 1 /*f.bill_id = p1_bill_id*/
    )
    UPDATE tmp_fin_bill_cases AS f
    SET
        uid                      = c.uid                     ,
        admission_type_id        = c.admission_type_id       ,
        care_level_id            = c.care_level_id           ,
        care_regimen_code        = c.care_regimen_code       ,
        care_level_code          = c.care_level_code         ,
        case_type_code           = c.case_type_code          ,
        case_mode_id             = c.case_mode_id            ,
        repeat_count_code        = c.repeat_count_code       ,
        payment_method_code      = c.payment_method_code     ,
        init_goal_code_arr       = c.init_goal_code_arr      ,
        ref_clinic_code          = c.ref_clinic_code         ,
        ref_clinic_code_oms      = c.ref_clinic_code_oms     ,
        care_providing_form_code = c.care_providing_form_code,
        provision_condition_code = c.provision_condition_code
    FROM 
        cases AS c
    WHERE
        1 = 1 /*f.bill_id = c.bill_id*/ 
		AND f.case_id = c.case_id;
	--raise notice '3: %', clock_timestamp();	
    WITH patient AS 
    (
        SELECT
            f.bill_id, 
            f.case_id,
			i.gender_id,
            CASE WHEN f.new_born THEN concat (i.gender_id, to_char (i.birth_dt, 'DDMMYY'), coalesce (a.newborn_number, 1)::VARCHAR(2)) ELSE '0' END AS new_born_part,
            CASE WHEN f.new_born THEN a.birthweight ELSE NULL END AS birthweight,
            array_agg (coalesce (trim (p.ui_code), '')) AS os_sluch,
			-- + 
			array_agg (bb.birthweight) AS birthweight_agg
         FROM 
            tmp_fin_bill_cases                     AS f
            JOIN public.pim_individual             AS i ON i.id = f.patient_id
            JOIN public.pci_patient                AS a ON a.id = i.id
            LEFT JOIN public.pci_patient_part_case AS c ON c.patient_id = a.id
                                                     	AND f.open_date<@ daterange(c.from_dt,c.to_dt,'[]')
            LEFT JOIN public.pci_part_case         AS p ON p.id = c.part_case_id 
			-- + вес новорождённого для пациента-матери
			LEFT JOIN public.pim_party_relation_party AS mm ON mm.party_id = i.id
            LEFT JOIN public.pim_party_relation_party AS cc ON cc.rel_id = mm.rel_id
            LEFT JOIN public.pim_individual           AS kk ON kk.id = cc.party_id
            LEFT JOIN public.pci_patient              AS bb ON bb.id = kk.id
        WHERE
            1 = 1 /*f.bill_id = p1_bill_id*/
        GROUP BY 1, 2, 3, 4, 5
    )
    UPDATE tmp_fin_bill_cases AS f
    SET
        new_born_part   = p.new_born_part,
        pat_birthweight = p.birthweight,
        pat_os_sluch    = p.os_sluch,
		
		birthweight     = CASE 
		                    WHEN p.gender_id = 2 
							     AND p.birthweight_agg iS NOT NULL
							  THEN p.birthweight_agg
					      END
    FROM 
        patient AS p
    WHERE
        1 = 1/*f.bill_id = p.bill_id*/ 
		AND f.case_id = p.case_id;
	--raise notice '4: %', clock_timestamp();	
    FOR _r IN
        SELECT 
            f.bill_id, 
            f.case_id, 
            a.diagnos_id,
            a.injury_type_id, 
            a.disease_type_id,
            ARRAY (SELECT diagnos_id FROM public.mc_diagnosis WHERE (NOT is_main OR is_main IS UNKNOWN) AND type_id = 2 AND case_id = f.case_id) AS r_diags_arr,
            ARRAY (SELECT diagnos_id FROM public.mc_diagnosis WHERE (NOT is_main OR is_main IS UNKNOWN) AND type_id = 3 AND case_id = f.case_id) AS c_diags_arr
        FROM 
            tmp_fin_bill_cases AS f 
            JOIN LATERAL (SELECT main_diagnos_id FROM public.mc_case WHERE id = f.case_id LIMIT 1) AS c ON TRUE
            JOIN LATERAL (SELECT id FROM public.mc_diagnosis WHERE is_main AND case_id = f.case_id ORDER BY stage_id DESC NULLS LAST, establishment_date DESC NULLS LAST, id DESC LIMIT 1) AS m ON TRUE
            LEFT JOIN LATERAL (SELECT diagnos_id, injury_type_id, disease_type_id FROM public.mc_diagnosis WHERE id = coalesce (c.main_diagnos_id, m.id) LIMIT 1) a ON TRUE
        WHERE
            f.bill_id = p1_bill_id
    LOOP
        UPDATE tmp_fin_bill_cases 
        SET 
            main_diagnosis_id          = _r.diagnos_id,
            main_diagnosis_code        = /*coalesce (trim ((SELECT code FROM public.md_diagnosis WHERE id = _r.diagnos_id LIMIT 1)), ''),*/
                                         coalesce (trim (billing.get_diagnosis_on_kurgan(_r.diagnos_id)), ''),
            injury_code                = coalesce (trim ((SELECT code FROM public.mc_injury_type WHERE id = _r.injury_type_id LIMIT 1)), ''),
            disease_type_code          = coalesce (trim ((SELECT code FROM public.mc_disease_type WHERE id = _r.disease_type_id LIMIT 1)), ''),
            related_diagnosis_arr      = /*ARRAY (SELECT code FROM public.md_diagnosis WHERE id = ANY (_r.r_diags_arr)),*/
                                         coalesce(nullif(ARRAY(SELECT coalesce (trim (billing.get_diagnosis_on_kurgan(dd)), '') FROM  (SELECT unnest(_r.r_diags_arr) dd) h ),'{}'),ARRAY(SELECT ''::text)),
            complication_diagnosis_arr = /*ARRAY (SELECT code FROM public.md_diagnosis WHERE id = ANY (_r.c_diags_arr))*/
                                         coalesce(nullif(ARRAY(SELECT coalesce(trim (billing.get_diagnosis_on_kurgan(dd)), '') FROM (SELECT unnest (_r.c_diags_arr)  dd) h),'{}'),ARRAY(SELECT ''::text))
        WHERE
            1 = 1 /*bill_id = _r.bill_id*/ 
			AND case_id = _r.case_id;
    END LOOP;		
	--raise notice '5: %', clock_timestamp();		
	/*---------------------------------*/

    WITH cte AS 
    (
        SELECT 
            f.case_id,
            s.id 		step_id,
            s.admission_date,
            s.outcome_date,
            s.main_diagnosis_id,
	    row_number() over (partition by f.case_id order by s.admission_date, s.admission_time NULLS FIRST, s.id) 	rn
		--(array_agg (s.id ORDER BY s.admission_date, s.admission_time NULLS FIRST, s.id))[1] AS step_id
        FROM 
            (SELECT DISTINCT case_id FROM tmp_fin_bill_cases) AS f, public.mc_step AS s
        WHERE 
            1 = 1 /*f.bill_id = p1_bill_id*/
            AND s.case_id = f.case_id
        --GROUP BY 1, 2
    )
    UPDATE tmp_fin_bill_cases AS f
    SET 
        first_id             = t.step_id                   ,
        first_diagnosis_id   = d.id                        ,
        first_diagnosis_code = coalesce (trim (billing.get_diagnosis_on_kurgan(d.id)), ''),
        first_admission_date = t.admission_date            ,
        first_outcome_date   = t.outcome_date               
    FROM 
        (SELECT * FROM cte WHERE rn = 1) AS t
        LEFT JOIN public.mc_diagnosis AS m ON m.id = t.main_diagnosis_id AND coalesce (m.is_main, FALSE)
        LEFT JOIN public.md_diagnosis AS d ON d.id = m.diagnos_id
    WHERE 
        1 = 1 /*f.bill_id = t.bill_id*/ 
	AND f.case_id = t.case_id;
    /*-----------------------------------*/
	--raise notice '6: %', clock_timestamp();
		
    UPDATE tmp_fin_bill_cases AS f
    SET 
        last_outcome_id          = t.outcome_id              ,
        last_result_id           = t.result_id               ,
        last_result_code         = t.result_code             ,
        last_is_closed           = t.is_closed               ,
        last_care_result         = t.care_result             ,
        last_mes_code            = t.mes_code                ,
        last_csg_code            = t.csg_code                ,
        last_vmp_type_code       = t.vmp_type_code           ,
        last_vmp_method_code     = t.vmp_method_code         ,
		-- +
        last_hsp_department_id   = t.last_hsp_department_id  ,
        last_hsp_department_code = t.hsp_department_code     ,
        last_hsp_department_name = t.hsp_department_name     ,
        last_department_id       = t.last_department_id      ,
        last_department_code     = t.department_code         ,
        last_department_name     = t.department_name         ,		
		-- +
        last_doctor_code         = t.doctor_code             ,
        last_doctor_snils        = ''                        ,
        last_profile_code        = t.profile_code		
    FROM 
        (SELECT 
            f.bill_id,
            f.case_id,
            s.outcome_id,
            coalesce (trim ((SELECT code FROM public.mc_step_care_result WHERE id = s.outcome_id LIMIT 1)), '') AS care_result,
            s.result_id,
            coalesce (trim ((SELECT code FROM public.mc_step_result WHERE id = s.result_id LIMIT 1)), '') AS result_code,
            coalesce ((SELECT is_closed FROM public.mc_step_result WHERE id = s.result_id LIMIT 1), FALSE) AS is_closed,
            coalesce (trim ((SELECT code FROM public.md_mes WHERE id = s.mes_id LIMIT 1)), '') AS mes_code,
            coalesce (trim ((SELECT code FROM public.md_clinical_statistical_group WHERE id = s.csg_id LIMIT 1)), '') AS csg_code,
            coalesce (trim ((SELECT code FROM public.mc_vmp_type WHERE id = s.vmp_type_id LIMIT 1)), '') AS vmp_type_code,
            coalesce (trim ((SELECT code FROM public.mc_vmp_method WHERE id = s.vmp_method_id LIMIT 1)), '') AS vmp_method_code,
			-- +
            n.id AS last_hsp_department_id,
            d.id AS last_department_id,
	    coalesce (trim (n.code), '') AS hsp_department_code,
            coalesce (trim (n.name), '') AS hsp_department_name,
            coalesce (trim (d.code), '') AS department_code,
            coalesce (trim (d.name), '') AS department_name,
			-- +
            g.responsible_id AS doctor_code,
			-- +
            coalesce(o.code,o2.code) AS profile_code			

        FROM 
            tmp_fin_bill_cases				   AS f
            JOIN public.mc_step        			   AS s ON s.id = f.last_id
			-- + 
            LEFT JOIN public.hsp_record                    AS h ON h.id = s.id
            LEFT JOIN public.pim_department                AS n ON n.id = h.department_id
            LEFT JOIN public.sr_res_group                  AS g ON g.id = s.res_group_id
            LEFT JOIN public.pim_department                AS d ON d.id = g.department_id
			-- +
			-- +
	    LEFT JOIN public.md_profile                    AS o ON o.id = s.profile_id
            LEFT JOIN public.md_employee_position          AS mep ON mep.id = g.responsible_id
            LEFT JOIN public.md_profile 		   AS o2 ON mep.profile_id = o2.id			
        WHERE 
            f.bill_id = p1_bill_id 
        ) t
    WHERE 
        1 = 1 /*f.bill_id = t.bill_id*/ 
		AND f.case_id = t.case_id;
    /*-----------------------------------------*/
	--raise notice '7: %', clock_timestamp();    
    UPDATE tmp_fin_bill_cases AS f
    SET 
        last_speciality_code_arr = t.speciality_code_arr     ,
        last_doctor_snils        = t.snils 					     
    FROM 
      (
        SELECT 
            f.bill_id,
            f.case_id,
            ARRAY [coalesce (trim (c.code), ''), coalesce (trim (c.e_code), '')] AS speciality_code_arr,
			-- +
			i.snils
        FROM 
            tmp_fin_bill_cases                         AS f
            LEFT JOIN public.pim_employee_position         AS p ON p.id = f.last_doctor_code::integer
            LEFT JOIN public.pim_position                  AS t ON t.id = p.position_id
            LEFT JOIN public.pim_speciality                AS c ON c.id = t.speciality_id
			LEFT JOIN LATERAL
			(
                SELECT 
                    regexp_replace (replace (replace (code, '-', ''), ' ', ''), '(...)(...)(...)(..)', '\1-\2-\3 \4') AS snils
                FROM 
                    public.pim_indiv_code 
                WHERE 
                    indiv_id = (SELECT individual_id FROM public.pim_employee WHERE id = f.last_doctor_code::integer LIMIT 1) AND type_id = _code_snils_ind_id 
                ORDER BY issue_dt DESC NULLS LAST LIMIT 1
            ) AS i ON TRUE
        WHERE 
            1 = 1 /*f.bill_id = p1_bill_id */
       )  t
    WHERE 
        1 = 1 /*f.bill_id = t.bill_id */
		AND f.case_id = t.case_id;
    /*-----------------------------------------*/
	--raise notice '8: %', clock_timestamp();
    UPDATE tmp_fin_bill_cases AS f
 	SET
 		first_admission_date = (SELECT 
    							s.admission_date 
                            FROM tmp_fin_bill_cases c 
								JOIN public.mc_step s ON s.case_id = c.case_id
                                LEFT JOIN public.hsp_record h ON h.id = s.id
    							LEFT JOIN public.pim_department dep ON dep.id = h.department_id
 							WHERE
                            	c.bill_id = p1_bill_id AND c.case_id = f.case_id AND dep.type_id <> 4 --не берем примное отделение   
                            ORDER BY s.id  
 							LIMIT 1),   
    	first_admission_time = (SELECT 
    							s.admission_time 
                            FROM tmp_fin_bill_cases c 
								JOIN public.mc_step s ON s.case_id = c.case_id
                                LEFT JOIN public.hsp_record h ON h.id = s.id
    							LEFT JOIN public.pim_department dep ON dep.id = h.department_id
 							WHERE
                            	c.bill_id = p1_bill_id AND c.case_id = f.case_id AND dep.type_id <> 4 --не берем примное отделение   
                            ORDER BY s.id  
 							LIMIT 1)
 	WHERE
 		1 = 1 /*bill_id = p1_bill_id*/ 
		AND care_regimen_code IN ('2','3','4','5');
    /*-----------------------------------------*/
	--raise notice '9: %', clock_timestamp();    
	UPDATE tmp_fin_bill_cases cs 
	SET
		sovmp = CASE
					WHEN a.to_dt < a.from_dt THEN NULL
					WHEN a.to_dt = a.from_dt THEN 1
					ELSE a.to_dt - a.from_dt
				END
	FROM public.mc_attendant a   
	WHERE
		a.case_id = cs.case_id
		AND cs.care_regimen_code = '2';
	/*--------------------------------------*/	
	WITH reg AS (
    	SELECT    	
       		c.bill_id,
        	c.case_id,
        	code.mcod 
    	FROM 
    		tmp_fin_bill_cases c
        	LEFT JOIN billing.fin_bill_cases_to_patient_reg r ON c.case_id = r.case_id
        	LEFT JOIN LATERAL (SELECT LEFT(oc.code,6) as mcod FROM public.pim_org_code oc
            					JOIN public.pci_patient_reg p ON oc.org_id = p.clinic_id
                               WHERE p.id = r.patient_reg_id AND oc.type_id = 8
                           	   LIMIT 1  
                          	   ) as code ON TRUE
    	WHERE 
    		1 = 1 /*c.bill_id = p1_bill_id*/
    )
    UPDATE tmp_fin_bill_cases AS c         
	SET
		region_data = region_data || hstore('mcod',reg.mcod)
	FROM 
		reg	
	WHERE
		c.case_id = reg.case_id
	; 	
		
    IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_fill_pivot_cases_table. Конец'); END IF;		
		
END;
$$;

