CREATE FUNCTION fsym_on_i_for_sym_mntr_mngrp()
  RETURNS trigger
LANGUAGE plpgsql
AS $fun$
begin                                                                                                                                                                  
                                   
                                  if 1=1 and 1=1 then                                                                                                 
                                    insert into "public".sym_data                                                                                                                     
                                    (table_name, event_type, trigger_hist_id, row_data, channel_id, transaction_id, source_node_id, external_data, create_time)                                        
                                    values(                                                                                                                                                            
                                      'sym_monitor',                                                                                                                                            
                                      'I',                                                                                                                                                             
                                      41,                                                                                                                                             
                                      
          case when new."monitor_id" is null then '' else '"' || replace(replace(cast(new."monitor_id" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."node_group_id" is null then '' else '"' || replace(replace(cast(new."node_group_id" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."external_id" is null then '' else '"' || replace(replace(cast(new."external_id" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."type" is null then '' else '"' || replace(replace(cast(new."type" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."expression" is null then '' else '"' || replace(replace(cast(new."expression" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."threshold" is null then '' else '"' || cast(cast(new."threshold" as numeric) as varchar) || '"' end||','||
          case when new."run_period" is null then '' else '"' || cast(cast(new."run_period" as numeric) as varchar) || '"' end||','||
          case when new."run_count" is null then '' else '"' || cast(cast(new."run_count" as numeric) as varchar) || '"' end||','||
          case when new."severity_level" is null then '' else '"' || cast(cast(new."severity_level" as numeric) as varchar) || '"' end||','||
          case when new."enabled" is null then '' else '"' || cast(cast(new."enabled" as numeric) as varchar) || '"' end||','||
          case when new."create_time" is null then '' else '"' || to_char(new."create_time", 'YYYY-MM-DD HH24:MI:SS.US') || '"' end||','||
          case when new."last_update_by" is null then '' else '"' || replace(replace(cast(new."last_update_by" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."last_update_time" is null then '' else '"' || to_char(new."last_update_time", 'YYYY-MM-DD HH24:MI:SS.US') || '"' end,                                                                                                                                                      
                                      'config',                                                                                                                                                
                                      txid_current(),                                                                                                                                               
                                      "public".sym_node_disabled(),                                                                                                                   
                                      null,                                                                                                                                               
                                      CURRENT_TIMESTAMP                                                                                                                
                                    );                                                                                                                                                                 
                                  end if;                                                                                                                                                              
                                                                                                                                                                               
                                  return null;                                                                                                                                                         
                                end;
$fun$;

