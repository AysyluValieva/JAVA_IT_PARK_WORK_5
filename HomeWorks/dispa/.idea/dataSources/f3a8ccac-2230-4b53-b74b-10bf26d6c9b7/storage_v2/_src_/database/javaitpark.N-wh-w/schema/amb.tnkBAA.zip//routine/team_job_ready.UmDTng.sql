CREATE FUNCTION team_job_ready(xtjid integer[], xreg integer, xuser integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
                xbrg integer;
                res record;
                xbdate TIMESTAMP WITHOUT TIME ZONE;
              begin
                xbdate := now();
                foreach xbrg in array xtjid loop
                    for res in select * from amb.sr_res_team_job_resourse where team_job_id = xbrg
                                and (deviation_id is null) and (edate is null) and (bdate is null)
                            and (planned_bdate <= (select planned_bdate from amb.sr_res_team_job where id = xbrg))
                    loop
                            update amb.sr_res_team_job_resourse set bdate = xbdate where id = res.id;
                    end loop;
                    update amb.sr_res_team_job set bdate = xbdate where id = xbrg;
                    execute amb.add_team_job_status_hist (xbrg,xbdate,1,xreg,null,xuser);
                end loop;
              end;
$$;

