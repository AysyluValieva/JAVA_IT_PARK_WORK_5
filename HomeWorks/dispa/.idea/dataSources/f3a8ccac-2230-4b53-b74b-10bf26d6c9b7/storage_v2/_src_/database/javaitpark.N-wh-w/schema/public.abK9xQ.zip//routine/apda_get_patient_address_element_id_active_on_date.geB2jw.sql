CREATE FUNCTION apda_get_patient_address_element_id_active_on_date(individual_id integer, dt date, default_code character varying)
  RETURNS integer
LANGUAGE plpgsql
AS $$
BEGIN
  IF $3 NOTNULL
  THEN $3 = upper($3);
  ELSE $3 = 'REGISTER'; END IF;
  RETURN (SELECT ppa.addr_id
          FROM pim_party_address ppa JOIN pim_party_addr_to_addr_type pata
              ON pata.party_address_id = ppa.id
            JOIN pim_address_type at ON pata.address_type_id = at.id
          WHERE ppa.party_id = $1 AND ppa.is_valid = TRUE
                AND ($2 >= ppa.from_date OR ppa.from_date ISNULL)
                AND ($2 <= ppa.to_date OR ppa.to_date ISNULL)
                AND at.code = $3
          ORDER BY ppa.addr_id
          LIMIT 1
  );
END
$$;

