CREATE FUNCTION counting_rest_count(p_clinic_id integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
DECLARE
  l_record RECORD;
  l_arr bigint[] DEFAULT '{}';
  l_arr_diapason bigint[] DEFAULT '{}';
  l_count bigint DEFAULT 0;
  l_total_number bigint DEFAULT 0;
  l_iterator bigint;
BEGIN
	FOR l_record IN SELECT * FROM sickdoc.sickdoc WHERE clinic_id = p_clinic_id LOOP
		l_arr:=l_arr || l_record."number"::bigint;
	END LOOP;

	FOR l_record IN SELECT * FROM sickdoc.bso_rec_record r JOIN sickdoc.bso_record_range rr ON rr.rec_record_id = r.id WHERE r.clinic_id = p_clinic_id LOOP
		l_total_number:=l_total_number + (l_record.end_num -l_record.start_num + 1);
		l_count:=0;
		FOREACH l_iterator IN ARRAY l_arr LOOP
			IF (l_iterator > l_record.start_num AND l_iterator < l_record.end_num) THEN l_count := l_count + 1; END IF;
		END LOOP;
		l_total_number:=l_total_number - l_count;

	END LOOP;
	RETURN l_total_number;
END;
$$;

