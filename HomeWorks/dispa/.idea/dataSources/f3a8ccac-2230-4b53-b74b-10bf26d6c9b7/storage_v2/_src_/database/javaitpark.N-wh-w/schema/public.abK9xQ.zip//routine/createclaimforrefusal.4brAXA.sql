CREATE FUNCTION createclaimforrefusal(_idlpu character varying, _idpdat character varying, _idappointment character varying)
  RETURNS TABLE(success boolean)
LANGUAGE plpgsql
AS $$
DECLARE
  _id integer;
  _id_ap integer;
BEGIN

if( upper(_idappointment)='NULL::TEXT' or upper(_idappointment)='NULL' or _idappointment='') then  _idappointment=NULL; end if;
   if( upper(_idlpu)='NULL::TEXT'  or upper(_idlpu)='NULL' or _idlpu='' ) then  _idlpu=NULL; end if;
    if( upper(_idpdat)='NULL::TEXT'  or upper(_idpdat)='NULL' or _idpdat='') then  _idpdat=NULL; end if;

  select ticket_id into _id_ap from sr_session_ticket where session_id=_idappointment::integer;
    
 --меняю статус
update md_appointment set state_id=4 
where id=_id_ap::integer and customer_id=_idpdat::integer and organization_id=_idlpu::integer;

update md_appointment_log set state_id=4 where appointment_id=_id_ap::integer;

--удаляю запись
delete from sr_session_ticket where ticket_id=_id_ap::integer;

return query(select true); 



END;
$$;

