CREATE FUNCTION journal_attach_or_detach_department(p_journal_id integer, p_dep_id integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
BEGIN

  IF exists(SELECT 1
            FROM sickdoc.journal_default
            WHERE journal_id = $1 AND dep_id = $2)
  THEN
    PERFORM sickdoc.journal_detach_department($1, $2);
  ELSE
    PERFORM sickdoc.journal_attach_department($1, $2);
  END IF;

END;
$$;

