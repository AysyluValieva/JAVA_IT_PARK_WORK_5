CREATE FUNCTION period_update(p_id integer, p_cur_clinic_id integer, p_from_dt date, p_is_other_clinic boolean, p_issued_employee_id integer, p_issued_employee_position character varying, p_other_clinic_id integer, p_to_dt date, p_witness_employee_id integer, p_witness_employee_position character varying)
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
  l_clinic_id INTEGER;
  l_sickdoc_id INTEGER;
BEGIN

  l_clinic_id = CASE WHEN p_is_other_clinic THEN p_other_clinic_id
                ELSE p_cur_clinic_id END;

  UPDATE sickdoc.period
  SET
    clinic_id                 = l_clinic_id,
    from_dt                   = p_from_dt,
    issued_employee_id        = p_issued_employee_id,
    issued_employee_position  = p_issued_employee_position,
    to_dt                     = p_to_dt,
    witness_employee_id       = p_witness_employee_id,
    witness_employee_position = p_witness_employee_position
  WHERE id = p_id;

  SELECT sickdoc_id
  FROM sickdoc.period
  WHERE id = p_id
  INTO l_sickdoc_id;

  PERFORM sickdoc.sickdoc_calculate_and_set_range_dates_and_duration(l_sickdoc_id);
END;
$$;

