CREATE FUNCTION journal_update(p_id integer, p_clinic_id integer, p_code character varying, p_name character varying, p_is_common_for_clinic boolean, p_begin_dt date, p_end_dt date)
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
  l_dep_id INTEGER;
  l_common_journal_id INTEGER;
  l_is_active_after BOOLEAN;
  l_is_active_before BOOLEAN;
BEGIN
  IF exists(SELECT 1
            FROM sickdoc.journal j
            WHERE j.name = p_name AND j.clinic_id = p_clinic_id AND j.id <> p_id)
  THEN
    RAISE 'Журнал с наименованием % уже существует в МО. Введите уникальное наименование', p_name;
  END IF;

  IF exists(SELECT 1
            FROM sickdoc.journal j
            WHERE j.code = p_code AND j.clinic_id = p_clinic_id AND j.id <> p_id)
  THEN
    RAISE 'Журнал с кодом % уже существует в МО. Введите уникальное наименование', p_code;
  END IF;

  l_is_active_before = (SELECT sickdoc.journal_is_active(p_id));

  IF p_is_common_for_clinic
  THEN
    SELECT sickdoc.journal_get_common_for_clinic(p_clinic_id)
    INTO l_common_journal_id;

    IF l_common_journal_id <> p_id
    THEN
      UPDATE sickdoc.journal
      SET is_common_for_clinic = FALSE
      WHERE id = l_common_journal_id;

      DELETE FROM sickdoc.journal_default
      WHERE journal_id = p_id;
    END IF;
  END IF;

  UPDATE
    sickdoc.journal
  SET
    clinic_id            = p_clinic_id,
    code                 = p_code,
    name                 = p_name,
    is_common_for_clinic = p_is_common_for_clinic,
    begin_dt             = p_begin_dt,
    end_dt               = p_end_dt
  WHERE id = p_id;

  l_is_active_after = (SELECT sickdoc.journal_is_active(p_id));

  --   если был архивным, а стал действующим, то смотрим не привязаны ли его отделения к другому действующему журналу, и отвязываем такие от
  IF NOT l_is_active_before AND l_is_active_after
  THEN
    FOR l_dep_id IN (SELECT dep_id
                     FROM sickdoc.journal_default
                     WHERE journal_id = p_id)
    LOOP
      IF (SELECT 1
          FROM sickdoc.journal_default
          WHERE journal_id <> p_id AND l_dep_id = dep_id)
      THEN
        DELETE
        FROM sickdoc.journal_default
        WHERE journal_id = p_id AND dep_id = l_dep_id;
      END IF;
    END LOOP;
  END IF;

END;
$$;

