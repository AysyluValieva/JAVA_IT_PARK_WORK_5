CREATE FUNCTION get_doc(p_individual_id integer, p_type_id integer, p_series boolean)
  RETURNS text
LANGUAGE plpgsql
AS $$
DECLARE
     doc_value text;
BEGIN
    SELECT
        case when p_series then pid.series else pid.number end INTO doc_value
    FROM
        pim_individual_doc pid
    WHERE
        indiv_id = p_individual_id
        AND type_id = p_type_id
      LIMIT 1
    ;
    
RETURN doc_value;
END;
$$;

