CREATE FUNCTION get_sickdoc_status(sickdoc_id integer)
  RETURNS character varying
IMMUTABLE
LANGUAGE plpgsql
AS $$
BEGIN
    RETURN
    (SELECT state.code
     FROM sickdoc.sickdoc s
       JOIN md_sicklist_state state ON s.state_id = state.id
     WHERE s.id = $1);
  END;
$$;

