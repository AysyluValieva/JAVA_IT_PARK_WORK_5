CREATE FUNCTION fin_fill_price(p1_bill_id integer)
  RETURNS void
STRICT
LANGUAGE plpgsql
AS $$
DECLARE 
  
   _to_date DATE:=(SELECT m.to_date FROM public.fin_bill_main m WHERE m.id = p1_bill_id);
   _bill_type text:=billing.kurgan_fin_get_type_bill(p1_bill_id);
   _is_log BOOLEAN:=TRUE;
  
BEGIN

 IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_fill_price. Начало'); END IF; 
 
 
IF _bill_type='app' THEN 
   
        WITH T AS
           (
               SELECT s.srv_rendered_id, s.spec_item_id, billing.kurgan_fin_get_price_app(s.price_pos_id, s.service_id, coalesce(s.quantity::integer,1), 
               c.patient_age, coalesce(to_date(s.region_data->'date_bill_mek','dd.mm.yyyy'),_to_date), coalesce(c.init_goal_code_arr[1],''),s.urov) AS r
               FROM billing.fin_bill_steps s
               JOIN billing.fin_bill_cases c ON c.bill_id=s.bill_id AND c.case_id=s.case_id
               JOIN billing.fin_bill_generate f ON f.bill_id=s.bill_id AND f.id=s.srv_rendered_id
               WHERE s.bill_id=p1_bill_id AND NOT coalesce(f.region_data ? 'tarif',false)
             ),
        U AS 
            (
              UPDATE billing.fin_bill_steps S 
              SET region_data= coalesce(region_data,hstore(''))||hstore('is_mrt',(t.r).is_mrt::text),
                     tariff = (t.r).tariff,
                     price  = (t.r).price,
                     tariff_code =(t.r).tariff_code
              FROM t WHERE s.bill_id=p1_bill_id AND s.srv_rendered_id=t.srv_rendered_id
		AND (COALESCE(s.tariff, 0) <> COALESCE((t.r).tariff, 0)
			OR COALESCE(s.price, 0) <> COALESCE((t.r).price, 0)
			OR COALESCE(s.tariff_code, '') <> COALESCE((t.r).tariff_code, '')
			OR COALESCE(s.region_data, hstore('')) <> coalesce(region_data,hstore(''))||hstore('is_mrt',(t.r).is_mrt::text)
			)
			
            )              
        UPDATE fin_bill_spec_item AS f     
        SET  tariff = (t.r).tariff,
             price  = (t.r).price
        FROM t
        WHERE f.id = t.spec_item_id 
		AND (COALESCE(f.tariff, 0) <>  COALESCE((t.r).tariff, 0)
			OR COALESCE(f.price, 0) <>  COALESCE((t.r).price, 0)
			)
	;

END IF;
IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_fill_price. Конец'); END IF; 
 
EXCEPTION
    WHEN NO_DATA_FOUND THEN RAISE EXCEPTION 'Отсутствуют данные по счёту';
END;
$$;

