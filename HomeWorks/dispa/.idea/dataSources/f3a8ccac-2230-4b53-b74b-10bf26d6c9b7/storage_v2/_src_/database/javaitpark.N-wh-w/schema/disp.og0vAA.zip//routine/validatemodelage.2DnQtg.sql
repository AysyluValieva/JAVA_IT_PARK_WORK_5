CREATE FUNCTION validatemodelage(t character varying)
  RETURNS character varying
LANGUAGE plpgsql
AS $$
DECLARE
	notValid text[];
	num character varying;
BEGIN
IF t is null THEN return 'true'; END IF;

FOREACH num IN ARRAY regexp_split_to_array(replace(t,' ',''), ',')
	LOOP
		IF num NOT SIMILAR TO '[0-9]{1,3}([.]([02-9]|1[01]?))?'
		THEN
			notValid := array_append(notValid, num::text);
		END IF;
	END LOOP;

IF array_length(notValid, 1) is null
THEN return 'true';
ELSE return array_to_string(notValid, ', ');
END IF;

END;
$$;

