CREATE FUNCTION get_form_param_full_name(p_form_id integer)
  RETURNS text
LANGUAGE plpgsql
AS $$
declare
v_res text := '';
r record;
begin
for r in select m.name as unit_name, val, rem
       from inv_form_param_value fpv, cmn_measure m, inv_form_param fp
       where form_param_id = fp.id and form_id = p_form_id and unit_id = m.id
       order by fp.degree asc, fpv.id loop
  if r.val is not null and r.val != 0 then
     v_res := v_res || ' ' || r.val||r.unit_name || coalesce(' '||r.rem, '');
  end if;
end loop;
return v_res;
end;
$$;

