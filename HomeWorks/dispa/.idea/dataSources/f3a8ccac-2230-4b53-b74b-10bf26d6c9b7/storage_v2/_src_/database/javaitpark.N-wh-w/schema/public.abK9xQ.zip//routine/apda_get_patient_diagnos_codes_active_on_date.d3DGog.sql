CREATE FUNCTION apda_get_patient_diagnos_codes_active_on_date(individual_id integer, dt date)
  RETURNS character varying[]
LANGUAGE plpgsql
AS $$
BEGIN
  RETURN (SELECT array_agg(md.code)
          FROM pci_dispensary pd
            JOIN md_diagnosis md ON pd.diagnosis_id = md.id
          WHERE pd.patient_id = $1
                AND (dt >= pd.reg_in_dt OR pd.reg_in_dt ISNULL)
                AND (dt <= pd.reg_out_dt OR pd.reg_out_dt ISNULL));
END;
$$;

