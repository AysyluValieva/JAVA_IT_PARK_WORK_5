CREATE FUNCTION repartitioning_process()
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
                  ids        INTEGER [];
                  batch_size INTEGER = 200;
                  task_id    INTEGER;
                  i          INTEGER;
                BEGIN
                  RAISE NOTICE 'Start repartitioning process';
                  RAISE NOTICE 'Total task count = %', (SELECT count(*)
                                                        FROM audit.repartitioning_task
                                                        WHERE status_id = 1);

                  ids = array(SELECT id
                              FROM audit.repartitioning_task
                              WHERE status_id = 1
                              ORDER BY id
                              LIMIT batch_size);

                  WHILE array_length(ids, 1) > 0 LOOP
                    FOR i IN array_lower(ids, 1) .. array_upper(ids, 1)
                    LOOP
                      EXECUTE audit.repartitioning_task(ids [i]);
                    END LOOP;
                    ids = array(SELECT id
                                FROM audit.repartitioning_task
                                WHERE status_id = 1
                                ORDER BY id
                                LIMIT batch_size);
                  END LOOP;

                  RAISE NOTICE 'Finish repartitioning process';
                END;
$$;

