CREATE FUNCTION get_bed_day_amount(caseid integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
                    r record;
                    bed_days integer = 0;
                    excluded_days integer = 0;
                    duration integer;
                    outcome_date date = current_date;
                    days_off_count integer = 0;
                begin
                    for r in (select hr.id, hr.bed_days_amount, hr.days_comp_algo_id, hr.missed_days_amount, s.admission_date, s.outcome_date, c.clinic_id from hsp_record hr
                       inner join mc_step s on s.id = hr.id
                       inner join mc_case c on c.id = s.case_id and c.id = caseId) loop

                        if (r.bed_days_amount is not null) then duration = r.bed_days_amount; else
                            if (r.outcome_date is not null) then outcome_date = r.outcome_date; end if;
                            if (r.missed_days_amount is not null) then excluded_days = r.missed_days_amount; end if;

                            if (r.days_comp_algo_id = 4) then
                               select count(c) into days_off_count from sr_calendar c
                               where c.org_id = r.clinic_id and c.dt <= r.admission_date and c.dt >= r.outcome_date and c.time_type_id = 2;
                               excluded_days = excluded_days + days_off_count;
                            end if;

                            duration = outcome_date - r.admission_date - excluded_days;

                            if (r.days_comp_algo_id = 2 or r.days_comp_algo_id = 4 or (r.days_comp_algo_id = 3 and r.admission_date = outcome_date)) then
                              duration = duration + 1;
                            end if;
                        end if;

                        bed_days = bed_days + duration;
            	    end loop;
            	    return bed_days;
                end;
$$;

