CREATE FUNCTION change_notification_status(xid integer, xstatus_id character varying)
  RETURNS void
LANGUAGE plpgsql
AS $$
begin
		update disp.md_notification set status_id = cast(xstatus_id as integer) where id = xid;
            end;
$$;

