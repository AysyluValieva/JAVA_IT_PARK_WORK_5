CREATE FUNCTION apdam_create_patient_district_limited_context()
  RETURNS void
LANGUAGE plpgsql
AS $$
BEGIN
  DROP TABLE IF EXISTS apdam_patient_district_limited;
  CREATE UNLOGGED TABLE apdam_patient_district_limited WITH (AUTOVACUUM_ENABLED = FALSE
  ) AS
    SELECT
      p.patient_id,
      d.district_id,
      p.age         AS p_age,
      p.gender_id   AS p_gender_id,
      p.pim_party_address_id,
      p.house_name,
      p.flat_name,
      d.building_pattern,
      d.org_terminal_id,
      d.diagnosis_terminal_id,
      d.age_terminal_id,
      d.gender_terminal_id,
      d.benefit_terminal_id,
      d.orgs,
      d.benefits,
      d.diagnos_code_from,
      d.diagnos_code_to,
      d.age_from,
      d.age_to,
      d.gender_id
    FROM apdam_district_extended d
      JOIN apdam_patient_with_address p ON p.address_id = d.address_id;

  CREATE INDEX ON apdam_patient_district_limited USING BTREE (patient_id);

  --удаляем тех кто не подошел по building_pattern
  DELETE FROM apdam_patient_district_limited
  WHERE (building_pattern NOTNULL
         AND (apda_check_address_by_building_pattern(house_name, flat_name, building_pattern) = FALSE));
END;
$$;

