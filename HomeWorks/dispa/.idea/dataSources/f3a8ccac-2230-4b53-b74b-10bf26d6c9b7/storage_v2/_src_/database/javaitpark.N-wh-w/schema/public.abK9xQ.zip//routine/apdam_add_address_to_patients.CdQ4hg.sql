CREATE FUNCTION apdam_add_address_to_patients(in_reg_date date, in_active_address_code character varying)
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
  default_address_type_id INT;
BEGIN
  IF in_active_address_code ISNULL OR in_active_address_code = ''
  THEN in_active_address_code = 'REGISTER'; END IF;
  SELECT id
  INTO default_address_type_id
  FROM pim_address_type
  WHERE code = $2;

  DROP TABLE IF EXISTS apdam_patient_with_address;
  CREATE UNLOGGED TABLE apdam_patient_with_address WITH (AUTOVACUUM_ENABLED = FALSE
  ) AS
    SELECT
      p.patient_id,
      p.age,
      p.gender_id,
      a.address_id,
      a.house_name,
      a.flat_name,
      a.pim_party_address_id
    FROM apdam_patient p
      JOIN LATERAL ( SELECT
                       p.patient_id AS patient_id,
                       CASE WHEN ae.level_id = 7
                         THEN ae.parent_id
                       WHEN ae.level_id = 8
                         THEN ae2.parent_id
                       ELSE ae.id END AS address_id,
                       CASE WHEN ae.level_id = 7
                         THEN ae.name
                       WHEN ae.level_id = 8
                         THEN ae2.name
                       ELSE NULL END  AS house_name,
                       CASE WHEN ae.level_id = 8
                         THEN ae.name
                       ELSE NULL END  AS flat_name,
                       ppa.id       AS pim_party_address_id
                     FROM pim_party_address ppa
                       JOIN pim_party_addr_to_addr_type pata ON pata.party_address_id = ppa.id
                       JOIN address_element ae ON ae.id = ppa.addr_id
                       LEFT JOIN address_element ae2 ON ae2.id = ae.parent_id AND ae.level_id = 8
                     WHERE ppa.is_valid = TRUE
                           AND pata.address_type_id = default_address_type_id
                           AND ppa.party_id = p.patient_id
                           AND ppa.addr_id NOTNULL
                           AND ($1 >= ppa.from_date OR ppa.from_date ISNULL)
                           AND ($1 <= ppa.to_date OR ppa.to_date ISNULL)
                     ORDER BY ae.id
                     LIMIT 1
           ) a ON a.patient_id = p.patient_id;

  CREATE INDEX ON apdam_patient_with_address USING BTREE (address_id);
END;
$$;

