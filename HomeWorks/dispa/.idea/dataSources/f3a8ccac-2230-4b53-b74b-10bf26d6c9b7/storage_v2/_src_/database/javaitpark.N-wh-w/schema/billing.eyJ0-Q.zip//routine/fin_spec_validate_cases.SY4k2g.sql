CREATE FUNCTION fin_spec_validate_cases(p1_bill_id integer, p2_user_id integer)
  RETURNS void
STRICT
LANGUAGE plpgsql
AS $$
DECLARE
    _r RECORD;
    _v VARCHAR;
    _validation_code VARCHAR[];
    _validation_enabled BOOLEAN[];
    _validation_title VARCHAR[];
BEGIN
    /*
        version: 2015-01-28
    */
    _validation_code := ARRAY 
    [
        'REGIMEN_IS_REQUIRED'            ,--1
        'REGIMEN_CODE_IS_NULL'           ,--2
        'CARE_LEVEL_IS_REQUIRED'         ,--3
        'CARE_LEVEL_CODE_IS_NULL'        ,--4
        'MAIN_DIAGNOSIS_IS_REQUIRED'     ,--5
        'MAIN_DIAGNOSIS_WRONG_FORMAT'    ,--6
        'PRIMARY_DIAGNOSIS_WRONG_FORMAT' ,--7
        'CARE_PROVIDING_FORM_IS_REQUIRED',--8
        'PAYMENT_METHOD_IS_REQUIRED'     ,--9
        'NO_TREATMENT_START_DATE'        ,--10
        'NO_TREATMENT_END_DATE'          ,--11
        'NO_STEP_RESULT'                 ,--12
        'STEP_RESULT_CODE_IS_REQUIRED'   ,--13
        'STEP_RESULT_CODE_LENGTH'        ,--14
        'NO_OUTCOME'                     ,--15
        'OUTCOME_CODE_IS_REQUIRED'       ,--16
        'OUTCOME_CODE_LENGTH'            ,--17
        'DATE_1_BEFORE_DATE_2'            --18
    ];
    FOREACH _v IN ARRAY _validation_code 
    LOOP 
        SELECT 
            coalesce (u.enabled, v.enabled) AS enabled, title INTO _r 
        FROM 
            public.fin_bill_validation                AS v 
            LEFT JOIN public.fin_bill_validation_user AS u ON u.validation_id = v.id AND u.user_id = p2_user_id
        WHERE 
            v.code = _v;
        _validation_enabled := _validation_enabled || _r.enabled;
        _validation_title   := _validation_title   || _r.title  ;
    END LOOP;
    
    DELETE FROM public.fin_bill_spec_item_error AS e USING public.fin_bill_spec_item AS i 
    WHERE 
        e.code = ANY (_validation_code) AND i.bill_id = p1_bill_id AND i.id = e.item_id
    ;
    FOR _r IN 
        SELECT 
            case_type_code, care_regimen_id, care_regimen_code, care_level_id, care_level_code, payment_method_code, care_providing_form_code, main_diagnosis_id, main_diagnosis_code, first_diagnosis_id, first_diagnosis_code, first_admission_date, last_outcome_date, last_result_code, last_is_closed, last_result_id, last_outcome_id, last_care_result, open_date, close_date, item_id_arr
        FROM 
            billing.fin_bill_cases
        WHERE
            bill_id = p1_bill_id
    LOOP
        IF 
            _validation_enabled[1] AND _r.care_regimen_id IS NULL 
        THEN 
            INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id)
                SELECT nextval ('public.fin_bill_spec_item_error_seq'), _validation_title[1], 'REGIMEN_IS_REQUIRED', unnest (_r.item_id_arr)
            ;
        ELSIF 
            _validation_enabled[2] AND _r.care_regimen_code IS NULL 
        THEN 
            INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id)
                SELECT nextval ('public.fin_bill_spec_item_error_seq'), _validation_title[2], 'REGIMEN_CODE_IS_NULL', unnest (_r.item_id_arr)
            ;
        END IF;
        IF 
            _validation_enabled[3] AND _r.care_level_id IS NULL
        THEN 
            INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id)
                SELECT nextval ('public.fin_bill_spec_item_error_seq'), _validation_title[3], 'CARE_LEVEL_IS_REQUIRED', unnest (_r.item_id_arr)
            ;
        ELSIF 
            _validation_enabled[4] AND _r.care_level_code = ''
        THEN
            INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id)
                SELECT nextval ('public.fin_bill_spec_item_error_seq'), _validation_title[4], 'CARE_LEVEL_CODE_IS_NULL', unnest (_r.item_id_arr)
            ;
        END IF;
        IF 
            _validation_enabled[5] AND _r.main_diagnosis_id IS NULL
        THEN 
            INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id)
                SELECT nextval ('public.fin_bill_spec_item_error_seq'), _validation_title[5], 'MAIN_DIAGNOSIS_IS_REQUIRED', unnest (_r.item_id_arr)
            ;
        ELSIF 
            _validation_enabled[6] 
            AND 
            (
                _r.main_diagnosis_code NOT SIMILAR TO '[A-Z][0-9]{2}.?[0-9]{0,2}[*,+]?' 
                OR 
                EXISTS (SELECT 1 FROM public.md_diagnosis WHERE id = _r.main_diagnosis_id AND NOT coalesce (is_leaf, FALSE))
            )
        THEN 
            INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id)
                SELECT nextval ('public.fin_bill_spec_item_error_seq'), _validation_title[6], 'MAIN_DIAGNOSIS_WRONG_FORMAT', unnest (_r.item_id_arr)
            ;
        ELSIF 
            _validation_enabled[7] AND _r.first_diagnosis_id IS NOT NULL 
            AND 
            (
                _r.first_diagnosis_code NOT SIMILAR TO '[A-Z][0-9]{2}.?[0-9]{0,2}[*,+]?'
                OR
                EXISTS (SELECT 1 FROM public.md_diagnosis WHERE id = _r.first_diagnosis_id AND NOT coalesce (is_leaf, FALSE))
            )
        THEN
            INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id)
                SELECT nextval ('public.fin_bill_spec_item_error_seq'), _validation_title[7], 'PRIMARY_DIAGNOSIS_WRONG_FORMAT', unnest (_r.item_id_arr)
            ;
        END IF;
        IF 
            _validation_enabled[8] AND _r.care_providing_form_code = ''
        THEN 
            INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id)
                SELECT nextval ('public.fin_bill_spec_item_error_seq'), _validation_title[8], 'CARE_PROVIDING_FORM_IS_REQUIRED', unnest (_r.item_id_arr)
            ;
        END IF;
        IF 
            _validation_enabled[9] AND _r.payment_method_code = ''
        THEN
            INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id)
                SELECT nextval ('public.fin_bill_spec_item_error_seq'), _validation_title[9], 'PAYMENT_METHOD_IS_REQUIRED', unnest (_r.item_id_arr)
            ;
        END IF;
        IF 
            _validation_enabled[10] AND _r.first_admission_date IS NULL 
        THEN 
            INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id)
                SELECT nextval ('public.fin_bill_spec_item_error_seq'), _validation_title[10], 'NO_TREATMENT_START_DATE', unnest (_r.item_id_arr)
            ;
        END IF;
        IF 
            _validation_enabled[11] AND _r.last_outcome_date IS NULL
        THEN
            INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id)
                SELECT nextval ('public.fin_bill_spec_item_error_seq'), _validation_title[11], 'NO_TREATMENT_END_DATE', unnest (_r.item_id_arr)
            ;
        END IF;
        IF 
            _validation_enabled[12] AND (_r.last_result_id IS NULL OR NOT coalesce (_r.last_is_closed, FALSE))
        THEN 
            INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id)
                SELECT nextval ('public.fin_bill_spec_item_error_seq'), _validation_title[12], 'NO_STEP_RESULT', unnest (_r.item_id_arr)
            ;
        ELSIF 
            _validation_enabled[13] AND (_r.last_result_code = '' OR NOT coalesce (_r.last_is_closed, FALSE)) 
        THEN 
            INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id)
                SELECT nextval ('public.fin_bill_spec_item_error_seq'), _validation_title[13], 'STEP_RESULT_CODE_IS_REQUIRED', unnest (_r.item_id_arr)
            ;
        ELSIF 
            _validation_enabled[14] AND length (_r.last_result_code) > 3 
        THEN 
            INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id)
                SELECT nextval ('public.fin_bill_spec_item_error_seq'), _validation_title[14], 'STEP_RESULT_CODE_LENGTH', unnest (_r.item_id_arr)
            ;
        END IF;
        IF 
            _validation_enabled[15] AND _r.case_type_code = '2' AND _r.last_outcome_id IS NULL
        THEN 
            INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id)
                SELECT nextval ('public.fin_bill_spec_item_error_seq'), _validation_title[15], 'NO_OUTCOME', unnest (_r.item_id_arr)
            ;
        ELSIF 
            _validation_enabled[16] AND _r.last_care_result = ''
        THEN 
            INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id)
                SELECT nextval ('public.fin_bill_spec_item_error_seq'), _validation_title[16], 'OUTCOME_CODE_IS_REQUIRED', unnest (_r.item_id_arr)
            ;
        ELSIF 
            _validation_enabled[17] AND length (_r.last_care_result) <> 3 
        THEN 
            INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id)
                SELECT nextval ('public.fin_bill_spec_item_error_seq'), _validation_title[17], 'OUTCOME_CODE_LENGTH', unnest (_r.item_id_arr)
            ;
        END IF;
        IF 
            _validation_enabled[18] AND _r.close_date < _r.open_date
        THEN
            INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id)
                SELECT nextval ('public.fin_bill_spec_item_error_seq'), _validation_title[18], 'DATE_1_BEFORE_DATE_2', unnest (_r.item_id_arr)
            ;
        END IF;
    END LOOP;
END;
$$;

