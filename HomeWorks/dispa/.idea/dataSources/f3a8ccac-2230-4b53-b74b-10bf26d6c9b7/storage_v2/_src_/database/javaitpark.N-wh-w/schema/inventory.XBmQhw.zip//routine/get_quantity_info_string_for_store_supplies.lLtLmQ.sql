CREATE FUNCTION get_quantity_info_string_for_store_supplies(mneiquantity numeric, quantity numeric, holdmodifid integer, fundid integer, storeid integer, expinvoicedate date, unitflag integer, mneiid integer, mneicountinsecpk integer)
  RETURNS text
LANGUAGE plpgsql
AS $$
DECLARE
 resultString TEXT;
 mneiName TEXT;
 resQuantity NUMERIC;
 resMneiQuantity NUMERIC;

BEGIN
  select inventory.get_store_supplies_mnei_quantity(mneiQuantity,holdModifId,fundId, storeId, expInvoiceDate) into resMneiQuantity;
  if resMneiQuantity=0 then
     return 0; end if;
  resQuantity =resMneiQuantity/mneiCountInSecPk;
  select cm.mnemocode from cmn_measure cm where cm.id=mneiId into mneiName;

  if resQuantity = resMneiQuantity
  then
       resultString = trim(to_char(resQuantity, 'FM999999990.999999'), '.')||' '||inventory.get_unit_name_by_flag_of_modif(unitFlag, holdModifId);
  else
       resultString = trim(to_char(resQuantity, 'FM999999990.999999'), '.')||' '||inventory.get_unit_name_by_flag_of_modif(unitFlag, holdModifId)
                ||' ('||trim(to_char(resMneiQuantity, 'FM999999990.999999'), '.')||' '||mneiName||')';
  end if;

  return resultString;
END;
$$;

