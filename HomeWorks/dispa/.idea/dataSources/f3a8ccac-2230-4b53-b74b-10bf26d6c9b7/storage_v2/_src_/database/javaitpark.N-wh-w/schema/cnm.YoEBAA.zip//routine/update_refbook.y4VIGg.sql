CREATE FUNCTION update_refbook(full_table_name text, sequence_name text, full_name character varying, short_name character varying, column_props cnm.ref_col_metadata[])
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
	  from_dt_column text := 'from_dt';
	  to_dt_column text := 'to_dt';
	  records_count int;
	  identifier_column_name varchar(255);
	  table_name varchar(255);
	  schema_name varchar(255);
	  refbook_id integer;
	  refbook_version_id integer;
	  column_id integer;
	  column_name text;
	  column_description text;
	  user_column_description text;
	  is_display_name bool;
  begin
    -- determine schema and table_name
    IF (position('.' in full_table_name) = 0) THEN
	    EXECUTE 'SELECT count(pg_namespace.nspname) FROM pg_class JOIN pg_namespace ON pg_class.relnamespace = pg_namespace.oid WHERE relname = $1'
	    INTO records_count
	    USING full_table_name;

	    IF (records_count > 1) THEN
		    RAISE EXCEPTION 'Table with the name "%" exists in more than one scheme', full_table_name
		    USING HINT = 'Please define schema name clearly through the point';
	    END IF;

	    table_name = full_table_name;
	    EXECUTE 'SELECT pg_namespace.nspname FROM pg_class JOIN pg_namespace ON pg_class.relnamespace = pg_namespace.oid WHERE relname = $1'
	    INTO schema_name
            USING full_table_name;
    ELSE
      table_name := substring(full_table_name from position('.' in full_table_name)+1);
      schema_name := substring(full_table_name from 0 for position('.' in full_table_name));
    END IF;
    RAISE NOTICE 'schema_name %, table_name %',schema_name,table_name;

    -- get refbook id
    BEGIN
	EXECUTE 'SELECT id FROM cnm.internal_refbook WHERE table_name = $1 and schema_name = $2'
	INTO STRICT refbook_id
	USING table_name, schema_name;
	EXCEPTION WHEN NO_DATA_FOUND THEN RAISE EXCEPTION 'there is no refbook for table %.%, run cnm.create_refbook()', schema_name, table_name;
    END;

    -- check columns from_dt and to_dt
    EXECUTE 'SELECT count(1) FROM pg_attribute WHERE attrelid = (SELECT pg_class.oid FROM pg_class JOIN pg_namespace ON pg_class.relnamespace = pg_namespace.oid WHERE relname = $1 and nspname = $2) AND attname = $3'
    INTO records_count
    USING table_name, schema_name, from_dt_column;

    IF (records_count = 0) THEN
	    EXECUTE 'ALTER TABLE '|| (schema_name||'.'||table_name)::regclass ||' ADD COLUMN '|| from_dt_column ||' date';
    END IF;

    EXECUTE 'SELECT count(1) FROM pg_attribute WHERE attrelid = (SELECT pg_class.oid FROM pg_class JOIN pg_namespace ON pg_class.relnamespace = pg_namespace.oid WHERE relname = $1 and nspname = $2) AND attname = $3'
    INTO records_count
    USING table_name, schema_name, to_dt_column;

    IF (records_count = 0) THEN
	    EXECUTE 'ALTER TABLE '|| (schema_name||'.'||table_name)::regclass ||' ADD COLUMN '|| to_dt_column ||' date';
    END IF;

    -- create internal_refbook
    BEGIN
      EXECUTE 'SELECT pg_attribute.attname FROM pg_attribute
		          INNER JOIN pg_class ON pg_attribute.attrelid = pg_class.oid
              INNER JOIN pg_namespace ON pg_class.relnamespace = pg_namespace.oid
              INNER JOIN pg_index ON pg_index.indrelid = pg_class.oid
              WHERE pg_class.relname = $1 AND nspname = $2 AND pg_attribute.attnum = any(pg_index.indkey) AND indisprimary'
      INTO STRICT identifier_column_name
      USING table_name, schema_name;
      EXCEPTION WHEN NO_DATA_FOUND THEN
          RAISE NOTICE 'no primary key - no identifier column';
          WHEN TOO_MANY_ROWS THEN
          RAISE NOTICE 'complex primary key - no identifier column';
    END;
    RAISE NOTICE 'identifier_column_name - %', identifier_column_name;

    EXECUTE 'UPDATE cnm.refbook SET full_name = COALESCE($1, full_name), short_name = COALESCE($2, short_name) WHERE id = $3'
    USING full_name, short_name, refbook_id;

    EXECUTE 'UPDATE cnm.internal_refbook SET sequence_name = COALESCE($1, sequence_name) WHERE id = $2'
    USING sequence_name, refbook_id;

    IF (identifier_column_name is null) THEN
	UPDATE cnm.internal_refbook SET identifier_column_id = null WHERE id = refbook_id;
    END IF;

    -- create refbook_version
    EXECUTE 'SELECT id FROM cnm.refbook_version WHERE refbook_id = $1 AND version is null'
    INTO refbook_version_id
    USING refbook_id;

    -- create refbook_column's
    FOR column_name, column_description IN
      EXECUTE 'SELECT pg_attribute.attname, pg_description.description FROM pg_attribute
        INNER JOIN pg_class ON pg_class.oid = pg_attribute.attrelid
        INNER JOIN pg_namespace ON pg_class.relnamespace = pg_namespace.oid
        LEFT JOIN pg_description ON pg_description.objoid = pg_class.oid and pg_description.objsubid = pg_attribute.attnum
        WHERE pg_class.relname = $1 AND nspname = $2 AND attnum > 0 AND NOT attisdropped'
      USING table_name, schema_name
    LOOP
      EXECUTE 'select a.column_description, a.is_display_name from unnest($1) a where a.column_name = $2'
      INTO user_column_description, is_display_name
      USING column_props, column_name;

      EXECUTE 'SELECT id FROM cnm.refbook_column WHERE name = $1 AND refbook_version_id = $2'
      INTO column_id
      USING column_name, refbook_version_id;

      IF (column_id is not null) THEN
	EXECUTE 'UPDATE cnm.refbook_column SET title = COALESCE($1, title), is_display_name = COALESCE($2, is_display_name) WHERE id = $3'
	USING user_column_description, is_display_name, column_id;
      ELSE
	INSERT INTO cnm.refbook_column(id, name, title, refbook_version_id, is_display_name) VALUES(nextval('cnm.refbook_column_id_seq'), column_name, COALESCE(user_column_description, column_description), refbook_version_id, COALESCE(is_display_name, false));
      END IF;

      IF (identifier_column_name IS NOT NULL AND identifier_column_name = column_name) THEN
        UPDATE cnm.internal_refbook set identifier_column_id = COALESCE(column_id, currval('cnm.refbook_column_id_seq')) where id = refbook_id; -- check currval
      END IF;
    END LOOP;

    -- delete dropped columns from refbook_column
    FOR column_id IN
	EXECUTE 'SELECT id FROM cnm.refbook_column WHERE refbook_version_id = $1
                       AND NOT EXISTS (SELECT pg_attribute.attname FROM pg_attribute
                       INNER JOIN pg_class ON pg_class.oid = pg_attribute.attrelid
                       INNER JOIN pg_namespace ON pg_class.relnamespace = pg_namespace.oid
                       WHERE pg_class.relname = $2 AND nspname = $3 AND pg_attribute.attname = cnm.refbook_column.name AND attnum > 0 AND NOT attisdropped)'
	USING refbook_version_id, table_name, schema_name
    LOOP
	DELETE FROM cnm.refbook_column WHERE id = column_id;
    END LOOP;
  end;
$$;

