CREATE FUNCTION apdam_update_reg(in_md_clinic_id integer, in_check_district boolean, in_department_id integer, in_type_id integer, in_reg_date date, in_update_type integer, in_detachment_type integer, in_specific_criteria character varying, in_address_code character varying)
  RETURNS void
LANGUAGE plpgsql
AS $$
BEGIN
  RAISE NOTICE '--Открепление умерших пациентов ...';
  EXECUTE apdam_detach_dead(in_md_clinic_id, in_check_district, in_department_id, in_type_id, in_reg_date);

  RAISE NOTICE '--Создание контекста для прикреплений ...';
  EXECUTE apdam_create_reg_context(in_md_clinic_id, in_check_district, in_department_id, in_type_id, in_reg_date,
                                   in_address_code);

  RAISE NOTICE '--Поиск новых участков для прикреплений ...';
  EXECUTE apdam_search_reg_new_distinct();

  RAISE NOTICE '--Обновление участков прикреплений ...';
  EXECUTE apdam_update_reg_distinct(in_md_clinic_id, in_department_id, in_type_id, in_reg_date, in_update_type);

  RAISE NOTICE '--Открепление прикреплений для которых не найден участок ...';
  EXECUTE apdam_detach_reg(in_reg_date, in_detachment_type, in_specific_criteria);
END;
$$;

