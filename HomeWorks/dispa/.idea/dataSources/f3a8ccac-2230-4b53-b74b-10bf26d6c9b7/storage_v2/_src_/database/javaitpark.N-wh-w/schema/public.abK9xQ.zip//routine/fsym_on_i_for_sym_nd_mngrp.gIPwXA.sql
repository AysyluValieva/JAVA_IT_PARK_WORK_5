CREATE FUNCTION fsym_on_i_for_sym_nd_mngrp()
  RETURNS trigger
LANGUAGE plpgsql
AS $fun$
begin                                                                                                                                                                  
                                   
                                  if 1=1 and 1=1 then                                                                                                 
                                    insert into "public".sym_data                                                                                                                     
                                    (table_name, event_type, trigger_hist_id, row_data, channel_id, transaction_id, source_node_id, external_data, create_time)                                        
                                    values(                                                                                                                                                            
                                      'sym_node',                                                                                                                                            
                                      'I',                                                                                                                                                             
                                      26,                                                                                                                                             
                                      
          case when new."node_id" is null then '' else '"' || replace(replace(cast(new."node_id" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."node_group_id" is null then '' else '"' || replace(replace(cast(new."node_group_id" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."external_id" is null then '' else '"' || replace(replace(cast(new."external_id" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."sync_enabled" is null then '' else '"' || cast(cast(new."sync_enabled" as numeric) as varchar) || '"' end||','||
          case when new."sync_url" is null then '' else '"' || replace(replace(cast(new."sync_url" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."schema_version" is null then '' else '"' || replace(replace(cast(new."schema_version" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."symmetric_version" is null then '' else '"' || replace(replace(cast(new."symmetric_version" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."database_type" is null then '' else '"' || replace(replace(cast(new."database_type" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."database_version" is null then '' else '"' || replace(replace(cast(new."database_version" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."heartbeat_time" is null then '' else '"' || to_char(new."heartbeat_time", 'YYYY-MM-DD HH24:MI:SS.US') || '"' end||','||
          case when new."timezone_offset" is null then '' else '"' || replace(replace(cast(new."timezone_offset" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."batch_to_send_count" is null then '' else '"' || cast(cast(new."batch_to_send_count" as numeric) as varchar) || '"' end||','||
          case when new."batch_in_error_count" is null then '' else '"' || cast(cast(new."batch_in_error_count" as numeric) as varchar) || '"' end||','||
          case when new."created_at_node_id" is null then '' else '"' || replace(replace(cast(new."created_at_node_id" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."deployment_type" is null then '' else '"' || replace(replace(cast(new."deployment_type" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end,                                                                                                                                                      
                                      'config',                                                                                                                                                
                                      txid_current(),                                                                                                                                               
                                      "public".sym_node_disabled(),                                                                                                                   
                                      null,                                                                                                                                               
                                      CURRENT_TIMESTAMP                                                                                                                
                                    );                                                                                                                                                                 
                                  end if;                                                                                                                                                              
                                                                                                                                                                               
                                  return null;                                                                                                                                                         
                                end;
$fun$;

