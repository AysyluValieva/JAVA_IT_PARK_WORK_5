CREATE FUNCTION add_table(table_name text)
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
    pk_column_info               RECORD;
    pk_value_to_write_with_types TEXT;
    pk_value_to_write TEXT;
    full_table_name TEXT;
    audit_table_name TEXT;
  BEGIN
    pk_value_to_write_with_types := '';
    pk_value_to_write := '';
    IF (strpos($1, '.') = 0)
    THEN full_table_name := 'public.' || $1;
    ELSE full_table_name := $1; END IF;
    audit_table_name := replace(replace(full_table_name, '.', '$'), '"', '');
    FOR pk_column_info IN SELECT
                            pg_attribute.attname :: TEXT                               AS column_name,
                            format_type(pg_attribute.atttypid, pg_attribute.atttypmod) AS type
                          FROM pg_index, pg_class, pg_attribute, pg_namespace
                          WHERE
                            pg_class.oid = full_table_name :: REGCLASS AND
                            indrelid = pg_class.oid AND
                            pg_class.relnamespace = pg_namespace.oid AND
                            pg_attribute.attrelid = pg_class.oid AND
                            pg_attribute.attnum = ANY (pg_index.indkey)
                            AND indisprimary
    LOOP
      pk_value_to_write_with_types := pk_value_to_write_with_types || pk_column_info.column_name || ' ' || pk_column_info.type || ',';
      pk_value_to_write := pk_value_to_write || pk_column_info.column_name || ',';

    END LOOP;
    EXECUTE format('CREATE TABLE audit."%s"(
        aud_rec bigserial,
				%s
				type TEXT NOT NULL CHECK (type IN (''I'',''D'',''U'',''T'')),
				delta hstore,
				aud_when timestamp(6),
				aud_who varchar,
				aud_source varchar,
				CONSTRAINT %s_pk PRIMARY KEY (aud_rec));
				CREATE INDEX ON audit.%s(%s) '
    , audit_table_name, pk_value_to_write_with_types, audit_table_name, audit_table_name, substring(pk_value_to_write, 1, length(pk_value_to_write) - 1));
  END;
$$;

