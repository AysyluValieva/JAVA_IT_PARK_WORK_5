CREATE FUNCTION get_available_beds(from_dt date, to_dt date)
  RETURNS TABLE(id integer, name character varying)
LANGUAGE plpgsql
AS $$
BEGIN
                  IF (from_dt IS NULL AND to_dt IS NULL)
                  THEN
                    from_dt := current_date - INTERVAL '14 day';
                    to_dt := current_date + INTERVAL '14 day';
                  ELSEIF from_dt IS NULL
                    THEN from_dt := to_dt - INTERVAL '1 month';
                  ELSEIF to_dt IS NULL
                    THEN to_dt := from_dt + INTERVAL '1 month';
                  END IF;
                  RETURN QUERY WITH bed_room AS (
                      SELECT DISTINCT
                        d.id                                                                                  AS d_id,
                        p.id                                                                                  AS p_id,
                        r.id                                                                                  AS r_id,
                        b.id                                                                                  AS id,
                        b.number                                                                              AS name,
                        d.id :: TEXT :: LTREE || p.id :: TEXT || p.id :: TEXT || r.id :: TEXT || b.id :: TEXT AS bed_tree
                      FROM public.md_bed b
                        JOIN LATERAL (SELECT
                                      FROM public.md_bed_resource mbr
                                      WHERE mbr.bed_id = b.id) mbr ON TRUE
                        JOIN LATERAL (SELECT
                                      FROM public.pim_room_resource prr
                                      WHERE prr.room_id = b.room_id
                                      LIMIT 1) prr ON TRUE
                        JOIN public.md_room mr ON b.room_id = mr.id
                        JOIN public.pim_room room ON b.room_id = room.id
                        JOIN public.pim_room r ON r.id = b.room_id
                        JOIN public.pim_department d ON d.id = r.department_id
                        JOIN public.pim_department_type t ON d.type_id = t.id AND trim(lower(t.code)) IN ('3', lower('SURGERY'))
                        JOIN public.md_department_profile dp ON d.id = dp.department_id
                        JOIN public.md_profile p ON p.id = dp.profile_id
                      GROUP BY d.id, p.id, r.id, b.id, b.number
                  ),
                      bed_room_profile AS (
                        SELECT
                          r.r_id,
                          rp.profile_id
                        FROM bed_room r
                          JOIN public.md_room_profile rp ON rp.room_id = r.r_id AND rp.profile_id = r.p_id
                        GROUP BY 1, 2
                    ),
                      bed_room_tree AS (
                      SELECT r.*
                      FROM bed_room r
                      WHERE NOT exists(SELECT
                                       FROM bed_room_profile rp)
                      UNION ALL
                      SELECT r.*
                      FROM bed_room r
                        JOIN bed_room_profile rp ON r.r_id = rp.r_id AND r.p_id = rp.profile_id
                    )
                  SELECT
                    b.id,
                    b.name
                  FROM bed_room_tree b
                    JOIN generate_series(from_dt :: DATE, to_dt :: DATE,
                         '1 day') dd(dt) ON TRUE
                    LEFT JOIN LATERAL (SELECT TRUE AS is_unused
                                       FROM hospital.unused_bed u
                                       WHERE u.bed_tree @> b.bed_tree AND u.date_range @> dd.dt :: DATE
                                       LIMIT 1) u ON TRUE
                  WHERE is_unused IS NULL
                  GROUP BY b.id, b.name;
                END;
$$;

