CREATE FUNCTION fsym_on_u_for_pblc_pm_dprtmnt_mngrp()
  RETURNS trigger
LANGUAGE plpgsql
AS $fun$
declare var_row_data text; 
                                declare var_old_data text; 
                                begin
                                   
                                  if 1=1 and "public".sym_triggers_disabled() = 0 then                                                                                                 
                                    var_row_data := 
          case when new."id" is null then '' else '"' || cast(cast(new."id" as numeric) as varchar) || '"' end||','||
          case when new."accounting_center_id" is null then '' else '"' || cast(cast(new."accounting_center_id" as numeric) as varchar) || '"' end||','||
          case when new."code" is null then '' else '"' || replace(replace(cast(new."code" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."from_dt" is null then '' else '"' || to_char(new."from_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when new."name" is null then '' else '"' || replace(replace(cast(new."name" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."to_dt" is null then '' else '"' || to_char(new."to_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when new."type_id" is null then '' else '"' || cast(cast(new."type_id" as numeric) as varchar) || '"' end||','||
          case when new."funding_id" is null then '' else '"' || cast(cast(new."funding_id" as numeric) as varchar) || '"' end||','||
          case when new."org_id" is null then '' else '"' || cast(cast(new."org_id" as numeric) as varchar) || '"' end||','||
          case when new."parent_id" is null then '' else '"' || cast(cast(new."parent_id" as numeric) as varchar) || '"' end||','||
          case when new."sphere_id" is null then '' else '"' || cast(cast(new."sphere_id" as numeric) as varchar) || '"' end||','||
          case when new."is_available_diagnosis" is null then '' when new."is_available_diagnosis" then '"1"' else '"0"' end||','||
          case when new."is_payment" is null then '' when new."is_payment" then '"1"' else '"0"' end||','||
          case when new."unit_id" is null then '' else '"' || cast(cast(new."unit_id" as numeric) as varchar) || '"' end||','||
          case when new."kind_id" is null then '' else '"' || cast(cast(new."kind_id" as numeric) as varchar) || '"' end||','||
          case when new."e_code" is null then '' else '"' || replace(replace(cast(new."e_code" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."scope_id" is null then '' else '"' || cast(cast(new."scope_id" as numeric) as varchar) || '"' end||','||
          case when new."is_separate" is null then '' when new."is_separate" then '"1"' else '"0"' end||','||
          case when new."is_social_significant" is null then '' else '"' || cast(cast(new."is_social_significant" as numeric) as varchar) || '"' end||','||
          case when new."age_group_id" is null then '' else '"' || cast(cast(new."age_group_id" as numeric) as varchar) || '"' end||','||
          case when new."is_branch_type" is null then '' when new."is_branch_type" then '"1"' else '"0"' end||','||
          case when new."visits_per_shift" is null then '' else '"' || cast(cast(new."visits_per_shift" as numeric) as varchar) || '"' end||','||
          case when new."departures_per_shift" is null then '' else '"' || cast(cast(new."departures_per_shift" as numeric) as varchar) || '"' end||','||
          case when new."visits_per_day" is null then '' else '"' || cast(cast(new."visits_per_day" as numeric) as varchar) || '"' end||','||
          case when new."necropsies_per_day" is null then '' else '"' || cast(cast(new."necropsies_per_day" as numeric) as varchar) || '"' end||','||
          case when new."clinical_trials_per_shift" is null then '' else '"' || cast(cast(new."clinical_trials_per_shift" as numeric) as varchar) || '"' end||','||
          case when new."brigades_amount" is null then '' else '"' || cast(cast(new."brigades_amount" as numeric) as varchar) || '"' end||','||
          case when new."ose" is null then '' else '"' || replace(replace(cast(new."ose" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."ose_reject" is null then '' else '"' || replace(replace(cast(new."ose_reject" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."at_home" is null then '' when new."at_home" then '"1"' else '"0"' end; 
                                    var_old_data := 
          case when old."id" is null then '' else '"' || cast(cast(old."id" as numeric) as varchar) || '"' end||','||
          case when old."accounting_center_id" is null then '' else '"' || cast(cast(old."accounting_center_id" as numeric) as varchar) || '"' end||','||
          case when old."code" is null then '' else '"' || replace(replace(cast(old."code" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when old."from_dt" is null then '' else '"' || to_char(old."from_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when old."name" is null then '' else '"' || replace(replace(cast(old."name" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when old."to_dt" is null then '' else '"' || to_char(old."to_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when old."type_id" is null then '' else '"' || cast(cast(old."type_id" as numeric) as varchar) || '"' end||','||
          case when old."funding_id" is null then '' else '"' || cast(cast(old."funding_id" as numeric) as varchar) || '"' end||','||
          case when old."org_id" is null then '' else '"' || cast(cast(old."org_id" as numeric) as varchar) || '"' end||','||
          case when old."parent_id" is null then '' else '"' || cast(cast(old."parent_id" as numeric) as varchar) || '"' end||','||
          case when old."sphere_id" is null then '' else '"' || cast(cast(old."sphere_id" as numeric) as varchar) || '"' end||','||
          case when old."is_available_diagnosis" is null then '' when old."is_available_diagnosis" then '"1"' else '"0"' end||','||
          case when old."is_payment" is null then '' when old."is_payment" then '"1"' else '"0"' end||','||
          case when old."unit_id" is null then '' else '"' || cast(cast(old."unit_id" as numeric) as varchar) || '"' end||','||
          case when old."kind_id" is null then '' else '"' || cast(cast(old."kind_id" as numeric) as varchar) || '"' end||','||
          case when old."e_code" is null then '' else '"' || replace(replace(cast(old."e_code" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when old."scope_id" is null then '' else '"' || cast(cast(old."scope_id" as numeric) as varchar) || '"' end||','||
          case when old."is_separate" is null then '' when old."is_separate" then '"1"' else '"0"' end||','||
          case when old."is_social_significant" is null then '' else '"' || cast(cast(old."is_social_significant" as numeric) as varchar) || '"' end||','||
          case when old."age_group_id" is null then '' else '"' || cast(cast(old."age_group_id" as numeric) as varchar) || '"' end||','||
          case when old."is_branch_type" is null then '' when old."is_branch_type" then '"1"' else '"0"' end||','||
          case when old."visits_per_shift" is null then '' else '"' || cast(cast(old."visits_per_shift" as numeric) as varchar) || '"' end||','||
          case when old."departures_per_shift" is null then '' else '"' || cast(cast(old."departures_per_shift" as numeric) as varchar) || '"' end||','||
          case when old."visits_per_day" is null then '' else '"' || cast(cast(old."visits_per_day" as numeric) as varchar) || '"' end||','||
          case when old."necropsies_per_day" is null then '' else '"' || cast(cast(old."necropsies_per_day" as numeric) as varchar) || '"' end||','||
          case when old."clinical_trials_per_shift" is null then '' else '"' || cast(cast(old."clinical_trials_per_shift" as numeric) as varchar) || '"' end||','||
          case when old."brigades_amount" is null then '' else '"' || cast(cast(old."brigades_amount" as numeric) as varchar) || '"' end||','||
          case when old."ose" is null then '' else '"' || replace(replace(cast(old."ose" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when old."ose_reject" is null then '' else '"' || replace(replace(cast(old."ose_reject" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when old."at_home" is null then '' when old."at_home" then '"1"' else '"0"' end; 
                                    if var_old_data is null or var_row_data != var_old_data then 
                                    insert into "public".sym_data                                                                                                                     
                                    (table_name, event_type, trigger_hist_id, pk_data, row_data, old_data, channel_id, transaction_id, source_node_id, external_data, create_time)                     
                                    values(                                                                                                                                                            
                                      'pim_department',                                                                                                                                            
                                      'U',                                                                                                                                                             
                                      18286,                                                                                                                                             
                                      
          case when old."id" is null then '' else '"' || cast(cast(old."id" as numeric) as varchar) || '"' end,                                                                                                                                                      
                                      var_row_data,                                                                                                                                                      
                                      var_old_data,                                                                                                                                                   
                                      'public_pim_department_default',                                                                                                                                                
                                      txid_current(),                                                                                                                                               
                                      "public".sym_node_disabled(),                                                                                                                   
                                      null,                                                                                                                                               
                                      CURRENT_TIMESTAMP                                                                                                                
                                    );                                                                                                                                                                 
                                  end if;                                                                                                                                                              
                                  end if;                                                                                                                                                              
                                                                                                                                                                               
                                  return null;                                                                                                                                                         
                                end;
$fun$;

