CREATE FUNCTION get_bed_day_amount_n2o(caseid integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
                  r record;
                  bed_days integer = 0;
                  excluded_days integer = 0;
                  duration integer = 0;
                  admission_date date;
                  outcome_date date = current_date;
                  days_off_count integer = 0;
                  algorithm_id integer = 0;
                begin
                  for r in (select hr.id,
                              hr.previous_id,
                              hr.bed_days_amount,
                              hr.days_comp_algo_id,
                              hr.missed_days_amount,
                              hr.department_id,
                              s.admission_date,
                              s.outcome_date,
                              c.clinic_id,
                              cra.days_comp_algo_id as algo
                            from public.hsp_record hr
                            inner join public.mc_step s on s.id = hr.id
                            inner join public.mc_case c on c.id = s.case_id and c.id = caseId
                            left join public.mc_care_regimen_algo cra on cra.regimen_id = s.regimen_id ORDER BY hr.id ASC)
                  loop
                      -- если за один день будет несколько переводов в разные отделения, надо пропустить эти записи
                      continue when (admission_date = r.admission_date and outcome_date = r.outcome_date);
                      -- если следующий перевод будет в тот же день, но выписка в другой (или наоборот), тогда надо
                      -- вычесть дни за предыдущую ЗОГ, т.е. старшая выписка является корректной
                      if((admission_date = r.admission_date) or (outcome_date = r.outcome_date))
                        THEN
                          bed_days = bed_days - duration;
                      END IF;
                      admission_date = r.admission_date;
                      if (r.outcome_date is not null)
                        then outcome_date = r.outcome_date;
                        else outcome_date = current_date;
                      end if;
                      -- Количество койкодней, пропущенное пациентом
                      -- (используется при лечении в дневном стационаре, заполняется пользователем)
                      if (r.missed_days_amount is not null)
                        then excluded_days = r.missed_days_amount;
                        else excluded_days = 0;
                      end if;
                      -- определение алгоритма подсчета койкодней
                      if (r.days_comp_algo_id is not null)
                        then algorithm_id = r.days_comp_algo_id;
                        else
                          if(r.algo is not null)
                            then algorithm_id = r.algo;
                            else algorithm_id = 1;
                          end if;
                      end if;
                      -- учитываются день поступления, день выбытия и календарь выходных дней
                      if (algorithm_id = 4) then
                        SELECT CASE WHEN exists(SELECT *
                        FROM public.sr_org_shift osh
                          JOIN public.sr_schedule_org so ON so.id = osh.schedule_org_id
                        WHERE so.org_id = r.clinic_id AND so.department_id = r.department_id)
                        THEN (SELECT count(osh)
                              -- INTO days_off_count
                              FROM public.sr_org_shift osh
                                JOIN public.sr_schedule_org so ON so.id = osh.schedule_org_id
                              WHERE so.org_id = r.clinic_id AND so.department_id = r.department_id
                                    AND (osh.date >= r.admission_date AND osh.date <= outcome_date)
                                    AND osh.time_type_id = 2)
                             ELSE
                               (SELECT count(osh)
                                -- INTO days_off_count
                                FROM public.sr_org_shift osh
                                  JOIN public.sr_schedule_org so ON so.id = osh.schedule_org_id
                                WHERE so.org_id = r.clinic_id and so.department_id is null
                                      AND (osh.date >= r.admission_date AND osh.date <= outcome_date)
                                      AND osh.time_type_id = 2) END INTO days_off_count;
                        excluded_days = excluded_days + days_off_count;
                      end if;
                      duration = outcome_date - r.admission_date - excluded_days;
                      -- возможен вариант, что выходные дни перекроют все койкодни
                      if (duration < 0)
                        THEN duration = 0;
                      END IF;
                      -- учитывается день поступления
                      if (algorithm_id = 2 or algorithm_id = 4 or (algorithm_id = 3 and r.admission_date = outcome_date)) then
                        duration = duration + 1;
                      end if;
                      bed_days = bed_days + duration;
                  end loop;
                  return bed_days;
                end;
$$;

