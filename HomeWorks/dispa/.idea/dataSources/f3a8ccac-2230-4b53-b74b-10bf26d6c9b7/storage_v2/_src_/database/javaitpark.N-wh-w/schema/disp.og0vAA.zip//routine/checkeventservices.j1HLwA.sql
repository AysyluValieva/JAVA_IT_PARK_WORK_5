CREATE FUNCTION checkeventservices(xorg integer, xstandard integer)
  RETURNS character varying
LANGUAGE plpgsql
AS $$
declare
          normDocService record;
          services character varying;
          exis boolean;
        begin
          services = null;
          exis = true;
          for normDocService in
              select COALESCE(ss.org_id, (select org_id from sr_service where id = sssd.service_id))::int org_id,
                 COALESCE(ss.id, sssd.service_id)::int service_id, mnds.name
              from md_standard_prescription msp
                left join md_standard ms on ms.id = xstandard
                left join md_prescription mp on mp.id = msp.id
                left join sr_service ss on ss.id = mp.service_type_id
                left join disp.md_standard_prescription_extended mspe on mspe.id = msp.id
                left join md_norm_document_service mnds on mnds.id = mspe.norm_doc_service_id
                left join disp.sr_srv_service_document sssd on sssd.document_service_id = mnds.id and sssd.owner_org_id = xorg
              where msp.standard_id = xstandard

          loop
            if ((normDocService.org_id is null) or (normDocService.service_id is null)) then
              services = concat_ws(',', services, '"'||normDocService.name||'"');
              exis = false;
            end if;
          end loop;
          if (exis = true) then return 't';
          else return services; end if;
        end;
$$;

