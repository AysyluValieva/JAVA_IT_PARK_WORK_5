CREATE FUNCTION fin_spec_gen_extra(p1_bill_id integer, p2_status text)
  RETURNS void
STRICT
LANGUAGE plpgsql
AS $$
--DECLARE 
    --_item_type TEXT;
BEGIN
    /*
        current version date 2014-12-12
    */
    ---------------------------------------------------------------параметры-------------------------------------------------------------------------
    /*
    _item_type := (SELECT trim (p.commentary) FROM fin_bill_main AS b, fin_price_list AS p WHERE b.price_list_id = p.id AND b.id = fin_bill__get_main_bill (p1_bill_id))
    ;
    -----------------------------------------------------------тип позиции счёта---------------------------------------------------------------------
    --dentist
    WITH t AS 
    (
        SELECT DISTINCT 
            bill_id, case_id 
        FROM 
            fin_bill_generate AS f
        WHERE 
            f.bill_id = p1_bill_id AND f.care_regimen_id = 1 AND coalesce (array_length (f.price_pos_arr, 1), 0) < 2
            AND coalesce ((SELECT c.name FROM sr_service AS s LEFT JOIN sr_srv_category AS c ON c.id = s.category_id WHERE s.id = f.service_id LIMIT 1), '0') = 'Стоматология'
    )
    UPDATE fin_bill_generate AS f
    SET
        item_type = 'dentist'
    FROM t
    WHERE
        f.bill_id = t.bill_id AND f.case_id = t.case_id
    ;
    --ambulatory
    WITH t AS 
    (
        SELECT DISTINCT 
            bill_id, case_id 
        FROM 
            fin_bill_generate
        WHERE 
            bill_id = p1_bill_id AND item_type IS NULL AND NOT is_sifted AND care_regimen_id = 1 
    )
    UPDATE fin_bill_generate AS f
    SET
        item_type = 'ambulatory'
    FROM t
    WHERE
        f.bill_id = t.bill_id AND f.case_id = t.case_id
    ;
    --hospital
    WITH t AS 
    (
        SELECT DISTINCT 
            bill_id, case_id 
        FROM 
            fin_bill_generate
        WHERE 
            bill_id = p1_bill_id AND item_type IS NULL AND NOT is_sifted AND care_regimen_id in (2, 3, 4, 5)
    )
    UPDATE fin_bill_generate AS f
    SET
        item_type = 'hospital'
    FROM t
    WHERE
        f.bill_id = t.bill_id AND f.case_id = t.case_id
    ;
    -------------------------------------------------------------отсеивание--------------------------------------------------------------------------
    IF 
        fin_bill__get_sift_status ('SIFT_EMPTY_ITEM_TYPE') 
    THEN
        UPDATE fin_bill_generate 
        SET 
            is_sifted = TRUE, sifting_cause = 'Не входит в реализованные виды помощи' 
        WHERE 
            bill_id = p1_bill_id AND NOT is_sifted AND item_type IS NULL
        ;
    END IF;
    -----------------------------------------------------------номер записи в выгрузке---------------------------------------------------------------
    WITH t AS 
    (
        SELECT bill_id, id, dense_rank () OVER (ORDER BY case_id) AS n_zap FROM fin_bill_generate WHERE bill_id = p1_bill_id AND NOT is_sifted
    )
    UPDATE fin_bill_generate AS f
    SET
        n_zap = t.n_zap
    FROM t
    WHERE
        t.bill_id = f.bill_id AND t.id = f.id
    ;
    */
EXCEPTION
    WHEN NO_DATA_FOUND THEN RAISE EXCEPTION 'Отсутствуют данные по счёту';
END;
$$;

