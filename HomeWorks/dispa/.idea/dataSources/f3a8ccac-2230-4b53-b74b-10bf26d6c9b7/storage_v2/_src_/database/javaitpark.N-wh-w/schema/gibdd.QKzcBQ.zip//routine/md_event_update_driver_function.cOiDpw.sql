CREATE FUNCTION md_event_update_driver_function(xeid integer, xpid integer, xseries character varying, xnumber character varying, xblankdate date, xcategories character varying, xreference integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
  service integer;
  services_for_patient_age  integer [];

begin
  PERFORM gibdd.md_event_edit_category_function(xreference,xcategories);
  UPDATE gibdd.md_gibdd_reference_reference SET series = xseries, number = xnumber WHERE card_id = xreference;
  UPDATE gibdd.md_gibdd_reference SET blank_date = xblankdate WHERE id = xreference;
  DELETE FROM disp.md_event_service_patient WHERE event_patient_id = xreference;

  services_for_patient_age := (select disp.select_service_for_gibdd_patient_licences (xreference, (select event_age from disp.md_event_patient where id=xreference), xcategories));
  if(services_for_patient_age is not null) then
    foreach service in array services_for_patient_age
    loop
      insert into disp.md_event_service_patient (id, service_id, indiv_id, event_id, event_patient_id) values (nextval('disp.md_event_service_patient_id_seq'), service, xpid, xeid, xreference);
    end loop;
  end if;

  return xreference;
end;
$$;

