CREATE FUNCTION migration_delete_double_rows(_table_name character varying)
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
  _audit_table_name VARCHAR;
BEGIN
  _audit_table_name = replace(replace(_table_name, '.', '$'), '_aud', '');

  IF (SELECT EXISTS(
                 SELECT 1
                 FROM pg_catalog.pg_class c
                   JOIN pg_catalog.pg_namespace n ON n.oid = c.relnamespace
                 WHERE n.nspname = 'audit' AND c.relname = _audit_table_name AND c.relkind = 'r') AND
             audit.migration_get_count_row_in_table('audit', _audit_table_name) > 0
  )
  THEN
    EXECUTE audit.migration_table_log_write(
        (SELECT id FROM audit.migration_table where table_name = _table_name), 'INFO', 'Remove duplicate rows');

    EXECUTE format('
      DELETE FROM %1$s
      WHERE rev > ( SELECT min(id)
                    FROM sec_audit_entry
                    WHERE date >
                       (  SELECT aud_when
                          FROM audit."%2$s"
                          WHERE id = (SELECT min(id) FROM audit."%3$s") LIMIT 1))',
                   _table_name, _audit_table_name, _audit_table_name
    );
  END IF;
END;
$$;

