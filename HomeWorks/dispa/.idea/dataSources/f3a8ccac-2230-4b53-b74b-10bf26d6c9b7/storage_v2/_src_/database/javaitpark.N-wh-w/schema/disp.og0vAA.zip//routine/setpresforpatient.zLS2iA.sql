CREATE FUNCTION setpresforpatient(xcheckservices character varying, xeid integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
        checkserviceId json;
        servicePatientRendered integer [];
        servicePatientPres integer [];
        service integer;
        begin

        foreach checkserviceId in array array(select value from json_array_elements(cast(xcheckservices as json)))
                      LOOP
                          servicePatientPres:=array_append(servicePatientPres,checkserviceId::text::int);
                      END LOOP;
                      
       if (select count(*) from disp.md_event_service_patient where event_patient_id = xeid) > 0 then
	              servicePatientRendered:=(array (select service_id from disp.md_event_service_patient where  event_patient_id=xeid ));
       end if;

 -- добавление услуг
      foreach service in array servicePatientPres
          loop
          if (servicePatientRendered is not null) then
              if (SELECT service = ANY(servicePatientRendered))=false then
                          insert into disp.md_event_service_patient (id, service_id, indiv_id, event_id,event_patient_id,status)
                                  values (
                                  nextval('disp.md_event_service_patient_id_seq'),
                                  service,
                                  (select indiv_id from disp.md_event_patient where id=xeid),
                                  (select event_id from disp.md_event_patient where id=xeid),
                                  xeid,1);
                                  insert into disp.md_event_service_patient_agreement (id, service_id, agree, denial, agree_date)
			values (nextval('disp.md_event_service_patient_agreement_id_seq'),currval('disp.md_event_service_patient_id_seq'), TRUE, FALSE, (select adate from disp.md_event_agreement where event_patient_id=xeid limit 1));
               end if;

               else
               insert into disp.md_event_service_patient (id, service_id, indiv_id, event_id,event_patient_id,status)
                                  values (
                                  nextval('disp.md_event_service_patient_id_seq'),
                                  service,
                                  (select indiv_id from disp.md_event_patient where id=xeid),
                                  (select event_id from disp.md_event_patient where id=xeid),
                                  xeid,1);
               end if;

          end loop;

      --удаление услуг
      foreach service in array (array (select service_id from disp.md_event_service_patient where  event_patient_id=xeid  and (status=1 or status =2)))
             loop
                  if (SELECT service = ANY(servicePatientPres))=false then
                         delete from disp.md_event_service_patient where event_patient_id=xeid and service_id=service;
                  end if;
             end loop;

        --пересчет процентов оказанных услуг
        update disp.md_event_patient mep set _overview = (select
            round(
            100.0 *
            CAST((select count(*) from disp.md_event_patient omep
            inner join disp.md_event_service_patient omesp on omesp.event_patient_id = omep.id and (omesp.status = 4 or omesp.status = 3)
            inner join disp.md_event_service omes on omes.id = omesp.service_id
            where omep.id = mep.id and (omes.ignore_service is NULL or omes.ignore_service = FALSE)) as real) / NULLIF(CAST((select count(*) from disp.md_event_patient omep2
            inner join disp.md_event_service_patient omesp2 on omesp2.event_patient_id = omep2.id
            inner join disp.md_event_service omes2 on omes2.id = omesp2.service_id
            where omep2.id = mep.id and (omes2.ignore_service is NULL or omes2.ignore_service = FALSE)) as real), 0)
            ))
            where id = xeid;


            --если были додабавлены услуги, то сделать сразу согласие, тем же числом что и др услуги

          return 1;
        end;
$$;

