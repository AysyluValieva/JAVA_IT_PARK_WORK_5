CREATE FUNCTION checktabtoregister(xregister integer, xtab integer, xchecked boolean)
  RETURNS void
LANGUAGE plpgsql
AS $$
begin
                IF xchecked then
                    insert into d_accounting.register_n2o_tab (register_id, n2o_tab_id) values (xregister, xtab);
                ELSE
                    delete from d_accounting.register_n2o_tab where register_id = xregister and n2o_tab_id = xtab;
                END IF;
            end;
$$;

