CREATE FUNCTION fin_spec_validate_policy(p1_bill_id integer, p2_user_id integer)
  RETURNS void
STRICT
LANGUAGE plpgsql
AS $$
DECLARE
    _r RECORD;
    _v VARCHAR;
    _validation_code VARCHAR[];
    _validation_enabled BOOLEAN[];
    _validation_title VARCHAR[];
BEGIN
    /*
        version: 2015-01-28
    */
    _validation_code := ARRAY 
    [
        'NO_ACTIVE_POLICY'                  ,--1
        'NO_INSURANCE_COMPANY'              ,--2
        'INSURANCE_COMPANY_CODE_IS_REQUIRED',--3
        'INSURANCE_COMPANY_CODE_LENGTH'     ,--4
        'ISSUER_WRONG_OGRN'                 ,--5
        'ISSUER_NAME_MAX_LENGTH'            ,--6
        'WRONG_INSURANCE_DOCUMENT'          ,--7
        'INSURANCE_SERIES_IS_REQUIRED'      ,--8
        'INSURANCE_SERIES_MAX_LENGTH'       ,--9
        'INSURANCE_NUMBER_MAX_LENGTH'       ,--10
        'NO_INSURANCE_TERRITORY'             --11
    ];
    FOREACH _v IN ARRAY _validation_code 
    LOOP 
        SELECT 
            coalesce (u.enabled, v.enabled) AS enabled, title INTO _r 
        FROM 
            fin_bill_validation                AS v 
            LEFT JOIN fin_bill_validation_user AS u ON u.validation_id = v.id AND u.user_id = p2_user_id
        WHERE 
            v.code = _v;
        _validation_enabled := _validation_enabled || _r.enabled;
        _validation_title   := _validation_title   || _r.title  ;
    END LOOP;
    
    DELETE FROM fin_bill_spec_item_error AS e USING fin_bill_spec_item AS i 
    WHERE 
        e.code = ANY (_validation_code) AND i.bill_id = p1_bill_id AND i.id = e.item_id
    ;
    FOR _r IN 
        SELECT 
            id, belonging_type, type, series, number, issuer_id, issuer_code_oms, issuer_ogrn, issuer_short_name, issuer_work_territory_id, item_id_arr
        FROM 
            fin_bill_policy
        WHERE
            bill_id = p1_bill_id
    LOOP
        IF 
            _validation_enabled[1] AND (_r.id = 0 OR NOT EXISTS (SELECT 1 FROM pim_individual_doc WHERE id = _r.id))
        THEN 
            INSERT INTO fin_bill_spec_item_error (id, error, code, item_id)
                SELECT nextval ('fin_bill_spec_item_error_seq'), _validation_title[1], 'NO_ACTIVE_POLICY', unnest (_r.item_id_arr)
            ;
        ELSE 
            IF 
                _validation_enabled[2] AND _r.issuer_id IS NULL
            THEN 
                INSERT INTO fin_bill_spec_item_error (id, error, code, item_id)
                    SELECT nextval ('fin_bill_spec_item_error_seq'), _validation_title[2], 'NO_INSURANCE_COMPANY', unnest (_r.item_id_arr)
                ;
            ELSIF 
                _validation_enabled[3] AND _r.issuer_code_oms = ''
            THEN 
                INSERT INTO fin_bill_spec_item_error (id, error, code, item_id)
                    SELECT nextval ('fin_bill_spec_item_error_seq'), _validation_title[3], 'INSURANCE_COMPANY_CODE_IS_REQUIRED', unnest (_r.item_id_arr)
                ;
            ELSIF 
                _validation_enabled[4] AND length (_r.issuer_code_oms) <> 5 
            THEN 
                INSERT INTO fin_bill_spec_item_error (id, error, code, item_id)
                    SELECT nextval ('fin_bill_spec_item_error_seq'), _validation_title[4], 'INSURANCE_COMPANY_CODE_LENGTH', unnest (_r.item_id_arr)
                ;
            ELSIF 
                _validation_enabled[5] AND length (_r.issuer_ogrn) <> 13 
            THEN 
                INSERT INTO fin_bill_spec_item_error (id, error, code, item_id)
                    SELECT nextval ('fin_bill_spec_item_error_seq'), _validation_title[5], 'ISSUER_WRONG_OGRN', unnest (_r.item_id_arr)
                ;
            ELSIF 
                _validation_enabled[6] AND length (_r.issuer_short_name) > 100 
            THEN 
                INSERT INTO fin_bill_spec_item_error (id, error, code, item_id)
                    SELECT nextval ('fin_bill_spec_item_error_seq'), _validation_title[6], 'ISSUER_NAME_MAX_LENGTH', unnest (_r.item_id_arr)
                ;
            END IF;
            IF 
                _validation_enabled[7] AND _r.type NOT IN ('MHI_OLDER', 'MHI_UNIFORM', 'MHI_TEMP', 'ENP')
            THEN 
                INSERT INTO fin_bill_spec_item_error (id, error, code, item_id)
                    SELECT nextval ('fin_bill_spec_item_error_seq'), _validation_title[7], 'WRONG_INSURANCE_DOCUMENT', unnest (_r.item_id_arr)
                ;
            ELSE 
                IF 
                    _validation_enabled[8] AND _r.type = 'MHI_OLDER' AND _r.series = ''  AND _r.belonging_type = 'local'
                THEN 
                    INSERT INTO fin_bill_spec_item_error (id, error, code, item_id)
                        SELECT nextval ('fin_bill_spec_item_error_seq'), _validation_title[8], 'INSURANCE_SERIES_IS_REQUIRED', unnest (_r.item_id_arr)
                    ;
                ELSIF 
                    _validation_enabled[9] AND _r.type = 'MHI_OLDER' AND length (_r.series) NOT BETWEEN 1 AND 10 AND _r.belonging_type = 'local'
                THEN
                    INSERT INTO fin_bill_spec_item_error (id, error, code, item_id)
                        SELECT nextval ('fin_bill_spec_item_error_seq'), _validation_title[9], 'INSURANCE_SERIES_MAX_LENGTH', unnest (_r.item_id_arr)
                    ;
                END IF;
                IF 
                    _validation_enabled[10] AND length (_r.number) NOT BETWEEN 1 AND 20 
                THEN 
                    INSERT INTO fin_bill_spec_item_error (id, error, code, item_id)
                        SELECT nextval ('fin_bill_spec_item_error_seq'), _validation_title[10], 'INSURANCE_NUMBER_MAX_LENGTH', unnest (_r.item_id_arr)
                    ;
                END IF;
            END IF;
            IF 
                _validation_enabled[11] AND _r.issuer_work_territory_id IS NULL
            THEN 
                INSERT INTO fin_bill_spec_item_error (id, error, code, item_id)
                    SELECT nextval ('fin_bill_spec_item_error_seq'), _validation_title[11], 'NO_INSURANCE_TERRITORY', unnest (_r.item_id_arr)
                ;
            END IF;
        END IF;
    END LOOP;
END;
$$;

