CREATE FUNCTION conditions_of_formation(xjournal_id integer)
  RETURNS text
LANGUAGE plpgsql
AS $$
declare
  _rec record;
  result TEXT;
begin
  result = 'false';
  for _rec in (
    select a.event, b.operation from monitoring.mn_event_for_remove_control a
      join monitoring.mn_journal_event_remove_control b ON a.id = b.remove_control_id where b.journal_id = xjournal_id
    order by b.id DESC)
  LOOP
    if result = 'false' then
      result = concat('(',_rec.event,' limit 1)');
    ELSE
      result =  concat('(',result,' ',_rec.operation, ' (', _rec.event,'limit 1))');
    END IF;
  END LOOP;
  return result;
END;
$$;

