CREATE FUNCTION apdam_create_district_attachment_info_context(in_reg_date date)
  RETURNS void
LANGUAGE plpgsql
AS $$
BEGIN
  DROP TABLE IF EXISTS apdam_district_attachment_info;
  CREATE UNLOGGED TABLE apdam_district_attachment_info WITH (AUTOVACUUM_ENABLED = FALSE
  ) AS
    SELECT
      t.*,
      count_regs.c1 AS count_regs
    FROM (SELECT DISTINCT
            district_id,
            CASE WHEN attache_number ISNULL
              THEN TRUE
            ELSE FALSE END AS is_unlimited,
            attache_number,
            order_number
          FROM apdam_district) t,
      LATERAL (SELECT count(id) AS c1
               FROM pci_patient_reg r
               WHERE r.district_id = t.district_id
                     AND r.state_id = 1
                     AND ($1 >= r.reg_dt OR r.reg_dt ISNULL)
                     AND ($1 <= r.unreg_dt OR r.unreg_dt ISNULL)) count_regs;
END;
$$;

