CREATE FUNCTION extendedstdpres(xid integer, xservice integer, xmodel integer, xresource integer, xpriority integer, xdcheck boolean, xorder integer, xignore boolean, xstage integer, xrequired boolean)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
		  i integer;
    begin
      IF (select count(id) from disp.md_standard_prescription_extended where id = xid) = 0 THEN
        i = xid;
        insert into disp.md_standard_prescription_extended (id, norm_doc_service_id, model_patient_id, res_group_id, priority, district_check, order_idx, ignore_service, stage_number,required)
          values (i, xservice, xmodel, xresource, CAST(xpriority as text), xdcheck, xorder, xignore, xstage,xrequired);
      ELSE
        update disp.md_standard_prescription_extended set norm_doc_service_id = xservice, model_patient_id = xmodel,
          res_group_id = xresource, priority = CAST(xpriority as text), district_check = xdcheck, order_idx = xorder,
          ignore_service = xignore, stage_number = xstage, required=xrequired
          where id = xid;
      END IF;
      update md_prescription set service_type_id=NULL where id = xid;
      return i;
      end;
$$;

