CREATE FUNCTION ordered_number_fun()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE
            l_clinic_id integer;
            l_cur_max_value integer;
            BEGIN
            l_clinic_id := NEW.clinic_id;
            EXECUTE 'SELECT COALESCE(MAX(clinic_record_order),0) FROM ' || quote_ident(TG_TABLE_SCHEMA) || '.'
            || quote_ident(TG_TABLE_NAME) || ' WHERE clinic_id= ' || l_clinic_id INTO l_cur_max_value ;
            NEW.clinic_record_order:= l_cur_max_value+1;
            RETURN NEW;
            END;
$$;

