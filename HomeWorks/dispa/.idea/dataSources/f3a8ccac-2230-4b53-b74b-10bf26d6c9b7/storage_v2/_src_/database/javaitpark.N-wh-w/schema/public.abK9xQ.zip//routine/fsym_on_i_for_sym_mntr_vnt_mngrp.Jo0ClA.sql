CREATE FUNCTION fsym_on_i_for_sym_mntr_vnt_mngrp()
  RETURNS trigger
LANGUAGE plpgsql
AS $fun$
begin                                                                                                                                                                  
                                   
                                  if 1=1 and 1=1 then                                                                                                 
                                    insert into "public".sym_data                                                                                                                     
                                    (table_name, event_type, trigger_hist_id, row_data, channel_id, transaction_id, source_node_id, external_data, create_time)                                        
                                    values(                                                                                                                                                            
                                      'sym_monitor_event',                                                                                                                                            
                                      'I',                                                                                                                                                             
                                      52,                                                                                                                                             
                                      
          case when new."monitor_id" is null then '' else '"' || replace(replace(cast(new."monitor_id" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."node_id" is null then '' else '"' || replace(replace(cast(new."node_id" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."event_time" is null then '' else '"' || to_char(new."event_time", 'YYYY-MM-DD HH24:MI:SS.US') || '"' end||','||
          case when new."host_name" is null then '' else '"' || replace(replace(cast(new."host_name" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."type" is null then '' else '"' || replace(replace(cast(new."type" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."threshold" is null then '' else '"' || cast(cast(new."threshold" as numeric) as varchar) || '"' end||','||
          case when new."event_value" is null then '' else '"' || cast(cast(new."event_value" as numeric) as varchar) || '"' end||','||
          case when new."event_count" is null then '' else '"' || cast(cast(new."event_count" as numeric) as varchar) || '"' end||','||
          case when new."severity_level" is null then '' else '"' || cast(cast(new."severity_level" as numeric) as varchar) || '"' end||','||
          case when new."is_resolved" is null then '' else '"' || cast(cast(new."is_resolved" as numeric) as varchar) || '"' end||','||
          case when new."is_notified" is null then '' else '"' || cast(cast(new."is_notified" as numeric) as varchar) || '"' end||','||
          case when new."last_update_time" is null then '' else '"' || to_char(new."last_update_time", 'YYYY-MM-DD HH24:MI:SS.US') || '"' end,                                                                                                                                                      
                                      'heartbeat',                                                                                                                                                
                                      txid_current(),                                                                                                                                               
                                      "public".sym_node_disabled(),                                                                                                                   
                                      null,                                                                                                                                               
                                      CURRENT_TIMESTAMP                                                                                                                
                                    );                                                                                                                                                                 
                                  end if;                                                                                                                                                              
                                                                                                                                                                               
                                  return null;                                                                                                                                                         
                                end;
$fun$;

