CREATE FUNCTION journal_attach_all_departments(p_journal_id integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
  l_clinic_id INTEGER;
BEGIN

-- Если журнал является общим для клиники, то ничего не привязываем
  IF (SELECT is_common_for_clinic
      FROM sickdoc.journal
      WHERE id = p_journal_id)
  THEN
    RETURN;
  END IF;

  l_clinic_id = (
    SELECT clinic_id
    FROM sickdoc.journal
    WHERE id = $1
  );

  LOCK TABLE sickdoc.journal_default IN EXCLUSIVE MODE;

  IF (SELECT sickdoc.journal_is_active(p_journal_id))
  THEN
    UPDATE sickdoc.journal_default
    SET journal_id = p_journal_id
    FROM (SELECT id
          FROM pim_department
          WHERE org_id = l_clinic_id) AS d
    WHERE journal_id <> p_journal_id AND
          d.id = dep_id AND
          (SELECT sickdoc.journal_is_active(journal_id));
  END IF;

  INSERT INTO sickdoc.journal_default
    SELECT
      p_journal_id,
      d.id
    FROM (SELECT id
          FROM pim_department
          WHERE org_id = l_clinic_id) AS d
    WHERE d.id NOT IN (SELECT dep_id
                       FROM sickdoc.journal_default
                       WHERE journal_id = p_journal_id);

END;
$$;

