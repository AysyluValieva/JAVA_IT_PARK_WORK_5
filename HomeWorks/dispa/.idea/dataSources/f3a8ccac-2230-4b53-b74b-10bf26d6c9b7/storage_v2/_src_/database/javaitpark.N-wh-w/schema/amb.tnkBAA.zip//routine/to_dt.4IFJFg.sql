CREATE FUNCTION to_dt(text)
  RETURNS date
LANGUAGE plpgsql
AS $$
begin
	if $1 !~ '\d{4}\-\d{2}\-\d{2}' then return null;
	else return $1::date;
	end if;
end;
$$;

