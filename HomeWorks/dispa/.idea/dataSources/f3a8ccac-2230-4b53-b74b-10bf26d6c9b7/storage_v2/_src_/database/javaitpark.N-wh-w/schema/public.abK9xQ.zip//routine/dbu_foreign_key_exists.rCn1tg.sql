CREATE FUNCTION dbu_foreign_key_exists(constraintname character varying, tablename character varying)
  RETURNS boolean
LANGUAGE plpgsql
AS $$
declare result boolean;
            begin

            select count(*) > 0 into result
            from pg_constraint
            inner join pg_class on pg_constraint.conrelid  = pg_class.oid
            inner join pg_namespace on pg_constraint.connamespace = pg_namespace.oid
            and pg_namespace.nspname !~ '^(pg_|information_schema)'
            where pg_constraint.contype = 'f'
            and pg_constraint.conname = lower($1)
            and pg_class.relname = lower($2);
            return result;
            end;
$$;

