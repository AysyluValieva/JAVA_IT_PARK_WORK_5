CREATE FUNCTION fsym_on_i_for_pblc_sr_srv_prttyp_fn_typ_mngrp()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
begin                                                                                                                                                                  
                                   
                                  if 1=1 and "public".sym_triggers_disabled() = 0 then                                                                                                 
                                    insert into "public".sym_data                                                                                                                     
                                    (table_name, event_type, trigger_hist_id, row_data, channel_id, transaction_id, source_node_id, external_data, create_time)                                        
                                    values(                                                                                                                                                            
                                      'sr_srv_prototype_fin_type',                                                                                                                                            
                                      'I',                                                                                                                                                             
                                      688,                                                                                                                                             
                                      
          case when new."id" is null then '' else '"' || cast(cast(new."id" as numeric) as varchar) || '"' end||','||
          case when new."bdate" is null then '' else '"' || to_char(new."bdate", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when new."edate" is null then '' else '"' || to_char(new."edate", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when new."funding_id" is null then '' else '"' || cast(cast(new."funding_id" as numeric) as varchar) || '"' end||','||
          case when new."prototype_id" is null then '' else '"' || cast(cast(new."prototype_id" as numeric) as varchar) || '"' end,                                                                                                                                                      
                                      'public_sr_srv_prototype_fin_type_default',                                                                                                                                                
                                      txid_current(),                                                                                                                                               
                                      "public".sym_node_disabled(),                                                                                                                   
                                      null,                                                                                                                                               
                                      CURRENT_TIMESTAMP                                                                                                                
                                    );                                                                                                                                                                 
                                  end if;                                                                                                                                                              
                                                                                                                                                                               
                                  return null;                                                                                                                                                         
                                end;
$$;

