CREATE FUNCTION calc_uid_snils_doc()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
declare
            begin
                if (TG_OP = 'DELETE')
                then
                    update pim_individual
                    set list_uid = (
                        select ic.code from pim_indiv_code ic
                        join pim_code_type ct on (ic.type_id = ct.id) where ic.indiv_id = OLD.indiv_id and ct.code = 'UID' limit 1
                    ),
                    list_snils = (
                        select ic.code from pim_indiv_code ic
                        join pim_code_type ct on (ic.type_id = ct.id) where ic.indiv_id = OLD.indiv_id and ct.code = 'SNILS' limit 1
                    )
                    where id = OLD.indiv_id;

                    return OLD;
                else
                    update pim_individual
                        set list_uid = (
                            select ic.code from pim_indiv_code ic
                            join pim_code_type ct on (ic.type_id = ct.id) where ic.indiv_id = pim_individual.id and ct.code = 'UID'
                            limit 1
                        ),
                        list_snils = (
                            select ic.code from pim_indiv_code ic
                            join pim_code_type ct on (ic.type_id = ct.id) where ic.indiv_id = pim_individual.id and ct.code = 'SNILS'
                            limit 1
                        )
                        where id = NEW.indiv_id;
                    --нужно обновлять и "старого" владельца, если меняется indiv_id
                    if (TG_OP = 'UPDATE' AND NEW.indiv_id <> OLD.indiv_id) then
                        update pim_individual
                            set list_uid = (
                                select ic.code from pim_indiv_code ic
                                join pim_code_type ct on (ic.type_id = ct.id) where ic.indiv_id = pim_individual.id and ct.code = 'UID'
                                limit 1
                            ),
                            list_snils = (
                                select ic.code from pim_indiv_code ic
                                join pim_code_type ct on (ic.type_id = ct.id) where ic.indiv_id = pim_individual.id and ct.code = 'SNILS'
                                limit 1
                            )
                            where id = OLD.indiv_id;
                    end if;

                    return NEW;
                end if;
            end;
$$;

