CREATE FUNCTION save_monitoring(xid integer, xaccountid integer, xyear integer, xheight integer, xweight integer, xsysbloodpress integer, xdiasbloodpress integer, xofmiid integer, xofmidate date, xofmidescription text, xnevmiid integer, xnevmidate date, xnevmidescription text, xstopmiid integer, xstopmidate date, xstopmidescription text, xhba1 double precision, xhba1c1 double precision, xhba1c2 double precision, xhba1c3 double precision, xhba1c4 double precision, xglucose double precision, xglucosetwohours double precision, xavghypoglycemia double precision, xhardhypoglycemia double precision, xtotalcholesterol double precision, xlpvp double precision, xlpnp double precision, xtriglycerides double precision, xuricacid double precision, xcreatinine double precision, xskf double precision, xalbumin double precision, xalbuminuria double precision, xalbuminuriaday double precision, xproteinuria double precision, xproteinuriaday double precision, xuricleukocyte integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
DECLARE
  _id INTEGER;
BEGIN
  _id = xid;

  IF (_id IS NULL)
  THEN
    INSERT INTO d_accounting.account_monitoring (id, account_id, year, height, weight, sys_blood_press, dias_blood_press, hba1, hba1c_1, hba1c_2, hba1c_3, hba1c_4,
                                                 glucose, glucose_two_hours, avg_hypoglycemia, hard_hypoglycemia, total_cholesterol, lpvp, lpnp, triglycerides, uric_acid,
                                                 creatinine, skf, albumin, albuminuria, albuminuria_day,
                                                 proteinuria, proteinuria_day,uric_leukocyte)
    VALUES (nextval('d_accounting.account_monitoring_seq'), xAccountId, xYear, xHeight, xWeight, xSysBloodPress,
                                                            xDiasBloodPress, xHba1, xHba1c1, xHba1c2, xHba1c3, xHba1c4,
                                                                                                               xGlucose,
                                                                                                               xGlucoseTwoHours,
                                                                                                               xAvgHypoglycemia,
                                                                                                               xHardHypoglycemia,
                                                                                                               xTotalCholesterol,
                                                                                                               xLpvp,
                                                                                                               xLpnp,
                                                                                                               xTriglycerides,
                                                                                                               xUricAcid,
            xCreatinine, xSkf, xAlbumin, xAlbuminuria, xAlbuminuriaDay,
            xProteinuria, xProteinuriaDay,xUricLeukocyte)
    RETURNING id
      INTO _id;
  ELSE
    UPDATE d_accounting.account_monitoring
    SET year           = xYear, height = xHeight, weight = xWeight, sys_blood_press = xSysBloodPress,
      dias_blood_press = xDiasBloodPress,
      hba1             = xHba1, hba1c_1 = xHba1c1, hba1c_2 = xHba1c2, hba1c_3 = xHba1c3, hba1c_4 = xHba1c4,
      glucose          = xGlucose, glucose_two_hours = xGlucoseTwoHours,
      avg_hypoglycemia = xAvgHypoglycemia, hard_hypoglycemia = xHardHypoglycemia, total_cholesterol = xTotalCholesterol,
      lpvp             = xLpvp, lpnp = xLpnp,
      triglycerides    = xTriglycerides, uric_acid = xUricAcid, creatinine = xCreatinine, skf = xSkf,
      albumin          = xAlbumin, albuminuria = xAlbuminuria, albuminuria_day = xAlbuminuriaDay,
      proteinuria      = xProteinuria, proteinuria_day = xProteinuriaDay, uric_leukocyte = xUricLeukocyte
    WHERE id = _id;
  END IF;

  IF (xOfmiId IS NOT NULL OR xOfmiDate IS NOT NULL OR xOfmiDescription IS NOT NULL)
  THEN
    IF (xOfmiId IS NOT NULL)
    THEN
      IF (xOfmiDate IS NULL)
      THEN
        DELETE FROM d_accounting.monitoring_inspection
        WHERE id = xOfmiId;
      ELSE
        UPDATE d_accounting.monitoring_inspection
        SET date = xOfmiDate, description = xOfmiDescription
        WHERE id = xOfmiId;
      END IF;
    ELSE
      INSERT INTO d_accounting.monitoring_inspection (id, monitoring_id, inspection_type_id, date, description)
      VALUES (nextval('d_accounting.monitoring_inspection_seq'), _id, 1, xOfmiDate, xOfmiDescription);
    END IF;
  END IF;

  IF (xNevmiId IS NOT NULL OR xNevmiDate IS NOT NULL OR xNevmiDescription IS NOT NULL)
  THEN
    IF (xNevmiId IS NOT NULL)
    THEN
      IF (xNevmiDate IS NULL)
      THEN
        DELETE FROM d_accounting.monitoring_inspection
        WHERE id = xNevmiId;
      ELSE
        UPDATE d_accounting.monitoring_inspection
        SET date = xNevmiDate, description = xNevmiDescription
        WHERE id = xNevmiId;
      END IF;
    ELSE
      INSERT INTO d_accounting.monitoring_inspection (id, monitoring_id, inspection_type_id, date, description)
      VALUES (nextval('d_accounting.monitoring_inspection_seq'), _id, 2, xNevmiDate, xNevmiDescription);
    END IF;
  END IF;

  IF (xStopmiId IS NOT NULL OR xStopmiDate IS NOT NULL OR xStopmiDescription IS NOT NULL)
  THEN
    IF (xStopmiId IS NOT NULL)
    THEN
      IF (xStopmiDate IS NULL)
      THEN
        DELETE FROM d_accounting.monitoring_inspection
        WHERE id = xStopmiId;
      ELSE
        UPDATE d_accounting.monitoring_inspection
        SET date = xStopmiDate, description = xStopmiDescription
        WHERE id = xStopmiId;
      END IF;
    ELSE
      INSERT INTO d_accounting.monitoring_inspection (id, monitoring_id, inspection_type_id, date, description)
      VALUES (nextval('d_accounting.monitoring_inspection_seq'), _id, 3, xStopmiDate, xStopmiDescription);
    END IF;
  END IF;

  RETURN _id;
END;
$$;

