CREATE FUNCTION get_sa()
  RETURNS SETOF pg_stat_activity
SECURITY DEFINER
LANGUAGE SQL
AS $$
SELECT * FROM pg_catalog.pg_stat_activity;
$$;

