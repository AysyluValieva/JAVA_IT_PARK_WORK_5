CREATE FUNCTION team_job_close(xtjid integer[], xreg integer, xuser integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
                xbrg integer;
                res record;
                xedate TIMESTAMP WITHOUT TIME ZONE;
              begin
                xedate := now();
                foreach xbrg in array xtjid loop
                  for res in select * from amb.sr_res_team_job_resourse where team_job_id = xbrg
                    loop
                        if (res.deviation_id is null) and (res.edate is null)
                        then
                            update amb.sr_res_team_job_resourse set edate = xedate where id = res.id;
                        end if;
                    end loop;
                  update amb.sr_res_team_job set edate = xedate where id = xbrg;
                  execute amb.add_team_job_status_hist (xbrg,xedate,7,xreg,null,xuser);
                end loop;
              end;
$$;

