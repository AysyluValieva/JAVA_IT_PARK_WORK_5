CREATE FUNCTION get_incorrect_modification_list()
  RETURNS TABLE(id integer, name character varying, sec_pack_unit_id integer, mnei_count_in_sec_pk integer, mnei_id integer, price_unit_flag integer)
LANGUAGE plpgsql
AS $$
BEGIN
return query
   select hm.id,hm.name,hm.sec_pack_unit_id,hm.mnei_count_in_sec_pk ,hm.mnei_id,hm.price_unit_flag from inventory.hold_modif hm
   where (hm.price_unit_flag=0 and (hm.sec_pack_unit_id is not null or hm.mnei_count_in_sec_pk is not null or hm.mnei_id is null))
         or (hm.price_unit_flag=2 and (hm.sec_pack_unit_id is null or hm.mnei_count_in_sec_pk=0 or hm.mnei_count_in_sec_pk is null or hm.mnei_id is null));
END;
$$;

