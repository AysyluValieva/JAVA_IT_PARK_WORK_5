CREATE FUNCTION fsym_on_u_for_sym_nd_scrty_mngrp()
  RETURNS trigger
LANGUAGE plpgsql
AS $fun$
declare var_row_data text; 
                                declare var_old_data text; 
                                begin
                                   
                                  if 1=1 and 1=1 then                                                                                                 
                                    var_row_data := 
          case when new."node_id" is null then '' else '"' || replace(replace(cast(new."node_id" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."node_password" is null then '' else '"' || replace(replace(cast(new."node_password" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."registration_enabled" is null then '' else '"' || cast(cast(new."registration_enabled" as numeric) as varchar) || '"' end||','||
          case when new."registration_time" is null then '' else '"' || to_char(new."registration_time", 'YYYY-MM-DD HH24:MI:SS.US') || '"' end||','||
          case when new."initial_load_enabled" is null then '' else '"' || cast(cast(new."initial_load_enabled" as numeric) as varchar) || '"' end||','||
          case when new."initial_load_time" is null then '' else '"' || to_char(new."initial_load_time", 'YYYY-MM-DD HH24:MI:SS.US') || '"' end||','||
          case when new."initial_load_id" is null then '' else '"' || cast(cast(new."initial_load_id" as numeric) as varchar) || '"' end||','||
          case when new."initial_load_create_by" is null then '' else '"' || replace(replace(cast(new."initial_load_create_by" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."rev_initial_load_enabled" is null then '' else '"' || cast(cast(new."rev_initial_load_enabled" as numeric) as varchar) || '"' end||','||
          case when new."rev_initial_load_time" is null then '' else '"' || to_char(new."rev_initial_load_time", 'YYYY-MM-DD HH24:MI:SS.US') || '"' end||','||
          case when new."rev_initial_load_id" is null then '' else '"' || cast(cast(new."rev_initial_load_id" as numeric) as varchar) || '"' end||','||
          case when new."rev_initial_load_create_by" is null then '' else '"' || replace(replace(cast(new."rev_initial_load_create_by" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."created_at_node_id" is null then '' else '"' || replace(replace(cast(new."created_at_node_id" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end; 
                                    var_old_data := null; 
                                    if 1=1 then 
                                    insert into "public".sym_data                                                                                                                     
                                    (table_name, event_type, trigger_hist_id, pk_data, row_data, old_data, channel_id, transaction_id, source_node_id, external_data, create_time)                     
                                    values(                                                                                                                                                            
                                      'sym_node_security',                                                                                                                                            
                                      'U',                                                                                                                                                             
                                      89,                                                                                                                                             
                                      
          case when old."node_id" is null then '' else '"' || replace(replace(cast(old."node_id" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end,                                                                                                                                                      
                                      var_row_data,                                                                                                                                                      
                                      var_old_data,                                                                                                                                                   
                                      'config',                                                                                                                                                
                                      txid_current(),                                                                                                                                               
                                      "public".sym_node_disabled(),                                                                                                                   
                                      null,                                                                                                                                               
                                      CURRENT_TIMESTAMP                                                                                                                
                                    );                                                                                                                                                                 
                                  end if;                                                                                                                                                              
                                  end if;                                                                                                                                                              
                                                                                                                                                                               
                                  return null;                                                                                                                                                         
                                end;
$fun$;

