CREATE FUNCTION find_first_step(xepid integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
          stepid integer;
        begin
          stepid = (select ssr.step_id from disp.md_event_patient mep1
                left join disp.md_event_service_patient mesp on mesp.event_patient_id = mep1.id
                left join disp.md_event_service mes on mes.id = mesp.service_id
                left join md_norm_document_service mnds on mnds.id = mes.doc_service_id
                left join (select ssr.id, msr.case_id, ssr.service_id, msr.step_id from MD_SRV_RENDERED msr
                left join SR_SRV_RENDERED ssr on ssr.id = msr.id) as ssr on ssr.case_id = mep1.case_id and ssr.service_id = mes.service_id
                where mep1.id = xepid and mnds.code = 'Д1.02' limit 1);
          return stepid;
        end;
$$;

