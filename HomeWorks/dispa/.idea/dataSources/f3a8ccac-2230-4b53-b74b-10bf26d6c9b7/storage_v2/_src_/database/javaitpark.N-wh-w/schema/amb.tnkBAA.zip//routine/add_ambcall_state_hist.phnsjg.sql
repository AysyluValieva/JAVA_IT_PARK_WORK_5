CREATE FUNCTION add_ambcall_state_hist(xcall integer, xdt timestamp without time zone, xstate integer, xtransmit integer, xreg integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
	i integer;
  begin
  /*добавление записи о состоянии в историю*/
	i = nextval('amb.md_ambcall_state_history_id_seq');
    insert into amb.md_ambcall_state_history (id,call_id,date_time,state_id,transmit_id,registrator_id)
    	VALUES(i,xcall,xdt,xstate,xtransmit,xreg);
    return i;
  end;
$$;

