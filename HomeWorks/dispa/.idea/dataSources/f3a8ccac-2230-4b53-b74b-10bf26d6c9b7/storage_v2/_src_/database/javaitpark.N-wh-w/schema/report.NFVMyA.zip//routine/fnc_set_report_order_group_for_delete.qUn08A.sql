CREATE FUNCTION fnc_set_report_order_group_for_delete(_report_id integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
                _i RECORD;
                BEGIN

                FOR _i IN
                    SELECT group_id
                    FROM report.report_to_group
                    WHERE report_id = _report_id
                LOOP
                    UPDATE report.report_to_group SET report_order =
                        (SELECT COALESCE(max(report_order), 0) + 1 FROM report.report_to_group WHERE group_id = _i.group_id)
                    WHERE group_id = _i.group_id AND report_id = _report_id;

                    UPDATE report.report_to_group rp SET report_order = up.report_order
                    FROM
                    (SELECT id, row_number() OVER (ORDER BY report_order) as report_order
                        FROM report.report_to_group
                     WHERE group_id = _i.group_id) up
                    WHERE rp.id = up.id;

                END LOOP;

                END;
$$;

