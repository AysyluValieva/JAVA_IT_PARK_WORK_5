CREATE FUNCTION fsym_on_i_for_mb_md_mblnc_prrty_t_g_mngrp()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
begin                                                                                                                                                                  
                                   
                                  if 1=1 and "public".sym_triggers_disabled() = 0 then                                                                                                 
                                    insert into "public".sym_data                                                                                                                     
                                    (table_name, event_type, trigger_hist_id, row_data, channel_id, transaction_id, source_node_id, external_data, create_time)                                        
                                    values(                                                                                                                                                            
                                      'md_ambulance_priority_to_age',                                                                                                                                            
                                      'I',                                                                                                                                                             
                                      19,                                                                                                                                             
                                      
          case when new."id" is null then '' else '"' || cast(cast(new."id" as numeric) as varchar) || '"' end||','||
          case when new."priority_id" is null then '' else '"' || cast(cast(new."priority_id" as numeric) as varchar) || '"' end||','||
          case when new."from_age_day" is null then '' else '"' || cast(cast(new."from_age_day" as numeric) as varchar) || '"' end||','||
          case when new."from_age_month" is null then '' else '"' || cast(cast(new."from_age_month" as numeric) as varchar) || '"' end||','||
          case when new."from_age_year" is null then '' else '"' || cast(cast(new."from_age_year" as numeric) as varchar) || '"' end||','||
          case when new."to_age_day" is null then '' else '"' || cast(cast(new."to_age_day" as numeric) as varchar) || '"' end||','||
          case when new."to_age_month" is null then '' else '"' || cast(cast(new."to_age_month" as numeric) as varchar) || '"' end||','||
          case when new."to_age_year" is null then '' else '"' || cast(cast(new."to_age_year" as numeric) as varchar) || '"' end,                                                                                                                                                      
                                      'amb_md_ambulance_priority_to_age_default',                                                                                                                                                
                                      txid_current(),                                                                                                                                               
                                      "public".sym_node_disabled(),                                                                                                                   
                                      null,                                                                                                                                               
                                      CURRENT_TIMESTAMP                                                                                                                
                                    );                                                                                                                                                                 
                                  end if;                                                                                                                                                              
                                                                                                                                                                               
                                  return null;                                                                                                                                                         
                                end;
$$;

