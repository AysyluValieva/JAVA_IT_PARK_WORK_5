CREATE FUNCTION apdam_update_reg_distinct(in_md_clinic_id integer, in_department_id integer, in_type_id integer, in_reg_date date, in_update_type integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
BEGIN
  IF in_update_type = 1
  THEN
    WITH cte AS (
        SELECT *
        FROM apdam_regs r
        WHERE r.new_district_id != r.current_district_id OR (r.current_district_id ISNULL AND r.new_district_id NOTNULL)
    )
    UPDATE pci_patient_reg r
    SET
      district_id = cte.new_district_id
    FROM cte
    WHERE cte.reg_id = r.id;
  ELSEIF in_update_type = 2
    THEN
      --закрываем старые прикрепления
      WITH cte AS (
          SELECT *
          FROM apdam_regs r
          WHERE r.new_district_id != r.current_district_id
                OR (r.current_district_id ISNULL AND r.new_district_id NOTNULL)
      )
      UPDATE pci_patient_reg r
      SET
        state_id = 2,
        unreg_cause_id = 1,
        unreg_dt = in_reg_date - 1
      FROM cte
      WHERE cte.reg_id = r.id;

      --создаем новые прикрепления
      WITH cte AS (
          SELECT
            r.new_district_id,
            r.patient_id,
            reg.address_id
          FROM apdam_regs r
            JOIN pci_patient_reg reg ON reg.id = r.reg_id
          WHERE r.new_district_id != r.current_district_id
                OR (r.current_district_id ISNULL AND r.new_district_id NOTNULL)
      )
      INSERT INTO pci_patient_reg (request_dt, reg_dt, clinic_id, department_id, district_id, address_id, patient_id, state_id, type_id)
        SELECT
          current_date,
          in_reg_date,
          in_md_clinic_id,
          in_department_id,
          cte.new_district_id,
          cte.address_id,
          cte.patient_id,
          1,
          in_type_id
        FROM cte;
  END IF;
END;
$$;

