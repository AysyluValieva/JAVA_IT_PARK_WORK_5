CREATE FUNCTION sickdoc_extended_create_or_update(p_sickdoc_id integer, p_care_for_patient_id1 integer, p_care_for_patient_id2 integer, p_disability_reason_code character varying, p_disability_from_dt date, p_disability_to_dt date, p_disability_reason_edited_id integer, p_disability_reason_ext_id integer, p_disability_reason_id integer, p_family_relation_id1 integer, p_family_relation_id2 integer, p_is_disability_group_changed boolean, p_is_early_pregnancy_register boolean, p_is_regimen_violation boolean, p_is_mse boolean, p_mse_examination_dt date, p_mse_org_id integer, p_mse_referral_dt date, p_mse_register_dt date, p_on_placement_service boolean, p_regimen_violation_doctor_id integer, p_regimen_violation_dt date, p_regimen_violation_id integer, p_sanatorium_id integer, p_sanatorium_ogrn_code character varying, p_voucher_code character varying)
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
  c_care_for_family_member_code CONSTANT VARCHAR = '09';
  c_pregnancy_leave_code CONSTANT VARCHAR = '05';
  c_sanatorium_aftercare_code CONSTANT VARCHAR = '08';
  l_mse_examination_dt DATE;
  l_mse_org_id INTEGER;
  l_mse_referral_dt DATE;
  l_mse_register_dt DATE;
  l_disability_from_dt DATE;
  l_disability_to_dt DATE;
  l_disability_reason_edited_code VARCHAR;
  l_id INTEGER;
  l_is_disability_group_changed BOOLEAN = FALSE;
  l_regimen_id INTEGER;
  l_regimen_violation_doctor_id INTEGER;
  l_regimen_violation_dt DATE;
  l_regimen_violation_id INTEGER;
  l_sanatorium_id INTEGER;
  l_sanatorium_ogrn_code VARCHAR;
  l_voucher_code VARCHAR;
  l_is_update BOOLEAN;
  l_is_early_pregnancy_register BOOLEAN = FALSE;
BEGIN
  l_id = p_sickdoc_id;
  l_is_update = CASE WHEN l_id NOTNULL AND exists(SELECT 1
                                                  FROM sickdoc.sickdoc_extended
                                                  WHERE id = l_id) THEN TRUE
                ELSE FALSE END;

-- Простановка "Нетрудоспособности" взависимости от кода причины и кода изменения причины
  l_disability_reason_edited_code = (SELECT code
                                     FROM md_sl_disability_reason
                                     WHERE id = p_disability_reason_edited_id);

  IF l_disability_reason_edited_code NOTNULL OR p_disability_reason_code IN (c_pregnancy_leave_code, c_sanatorium_aftercare_code)
  THEN
    l_disability_from_dt = p_disability_from_dt;
    l_disability_to_dt = p_disability_to_dt;
  END IF;

  IF p_disability_reason_code = c_sanatorium_aftercare_code OR l_disability_reason_edited_code = c_sanatorium_aftercare_code
  THEN
    l_sanatorium_id = p_sanatorium_id;
    l_sanatorium_ogrn_code = p_sanatorium_ogrn_code;
    l_voucher_code = p_voucher_code;
  END IF;

  IF p_disability_reason_code = c_pregnancy_leave_code
  THEN
    l_is_early_pregnancy_register = p_is_early_pregnancy_register;
  END IF;


-- Галка "Нарушение режима"
  IF p_is_regimen_violation
  THEN
    l_regimen_violation_doctor_id = p_regimen_violation_doctor_id;
    l_regimen_violation_dt = p_regimen_violation_dt;
    l_regimen_violation_id = p_regimen_violation_id;
  END IF;

-- Галка "МСЭ"
  IF p_is_mse
  THEN
    l_is_disability_group_changed = p_is_disability_group_changed;
    l_mse_examination_dt = p_mse_examination_dt;
    l_mse_referral_dt = p_mse_referral_dt;
    l_mse_register_dt = p_mse_register_dt;
  END IF;

-- !!!ОТКУДА БРАТЬ mse_emp и mse_org_id?
  IF l_is_update
  THEN
    UPDATE sickdoc.sickdoc_extended
    SET
      disability_from_dt          = l_disability_from_dt,
      disability_reason_edited_id = p_disability_reason_edited_id,
      disability_reason_ext_id    = p_disability_reason_ext_id,
      disability_reason_id        = p_disability_reason_id,
      disability_to_dt            = l_disability_to_dt,
      is_disability_group_changed = l_is_disability_group_changed,
      is_early_pregnancy_register = l_is_early_pregnancy_register,
      mse_examination_dt          = l_mse_examination_dt,
      mse_referral_dt             = l_mse_referral_dt,
      mse_register_dt             = l_mse_register_dt,
      on_placement_service        = p_on_placement_service,
      regimen_id                  = l_regimen_id,
      regimen_violation_doctor_id = l_regimen_violation_doctor_id,
      regimen_violation_dt        = l_regimen_violation_dt,
      regimen_violation_id        = l_regimen_violation_id,
      sanatorium_id               = l_sanatorium_id,
      sanatorium_ogrn_code        = l_sanatorium_ogrn_code,
      voucher_code                = l_voucher_code
    WHERE id = l_id;
  ELSE
    INSERT INTO sickdoc.sickdoc_extended (
      id, disability_from_dt, disability_reason_edited_id, disability_reason_ext_id, disability_reason_id,
      disability_to_dt, is_disability_group_changed, is_early_pregnancy_register, mse_examination_dt,
      mse_referral_dt, mse_register_dt, on_placement_service, regimen_id, regimen_violation_doctor_id,
      regimen_violation_dt, regimen_violation_id, sanatorium_id, sanatorium_ogrn_code, voucher_code)
    VALUES (
      l_id, l_disability_from_dt, p_disability_reason_edited_id, p_disability_reason_ext_id, p_disability_reason_id,
      l_disability_to_dt, l_is_disability_group_changed, l_is_early_pregnancy_register, l_mse_examination_dt,
      l_mse_referral_dt, l_mse_register_dt, p_on_placement_service, l_regimen_id, l_regimen_violation_doctor_id,
      l_regimen_violation_dt, l_regimen_violation_id, l_sanatorium_id, l_sanatorium_ogrn_code, l_voucher_code
    );
  END IF;

  PERFORM sickdoc.family_member_update(
      l_id, p_disability_reason_code, p_care_for_patient_id1, p_care_for_patient_id2, p_family_relation_id1, p_family_relation_id2);

END;
$$;

