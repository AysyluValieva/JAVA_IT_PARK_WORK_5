CREATE FUNCTION refresh_treatment_plan(xpregnant_map_id integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
	params record;
BEGIN
    -- Получаем данные о плане лечения, дате постановки на учет, дате открепления и пациентке
	SELECT tp.id, patient_id, reg_dt, unreg_dt INTO params FROM motherhood.mh_treatment_plan tp
		INNER JOIN motherhood.mh_pregnant_map pm on pm.id = tp.pregnant_map_id
		WHERE pm.id = xpregnant_map_id;

	-- Выбираем все услуги по прототипу, которые оказаны пациентке в период нахождения на учете с минимальной разницей между оказанием услуги и планируемой датой
	UPDATE motherhood.mh_treatment_plan_service tps
	SET rendered_service_id = (
		SELECT msd.id FROM public.md_srv_rendered msd
		INNER JOIN public.sr_srv_rendered ssr ON msd.id = ssr.id
		INNER JOIN public.sr_service ss ON ss.id = ssr.service_id
		LEFT JOIN public.md_appointment ma ON ma.srv_rendered_id = ssr.id
		LEFT JOIN public.md_referral mr ON mr.service_id = ssr.id
		WHERE ss.prototype_id = tps.prototype_id AND ssr.customer_id = params.patient_id and (ma.id is null or ma.state_id not in (1, 4, 6)) and (mr.id is null or mr.status_id != 3) and ssr.is_refused is not true
		AND params.reg_dt <= COALESCE(ssr.bdate, ssr.planned_date) AND (params.unreg_dt IS NULL OR params.unreg_dt >= COALESCE(ssr.bdate, ssr.planned_date))
		AND NOT EXISTS (SELECT 1 FROM motherhood.mh_treatment_plan_service ssps WHERE ssps.prototype_id = tps.prototype_id AND treatment_plan_id = params.id AND ssps.id != tps.id and ABS(COALESCE(ssr.bdate, ssr.planned_date) - ssps.planned_dt) < ABS(COALESCE(ssr.bdate, ssr.planned_date) - tps.planned_dt))
		ORDER BY ABS(ssr.bdate - tps.planned_dt) LIMIT 1)
	WHERE treatment_plan_id = params.id;

	UPDATE motherhood.mh_treatment_plan SET refresh_dt = current_timestamp WHERE id = params.id;

END;
$$;

