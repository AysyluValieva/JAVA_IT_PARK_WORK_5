CREATE FUNCTION team_job_deviation_validation(xres integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
	result integer;
    res record;
    xtjid integer;
    xresurce integer;
    xchange integer;
  begin
    if xres is not null
    	then
  			select into xtjid,xresurce,xchange team_job_id,resource_id,change_id from amb.sr_res_team_job_resourse where id = xres;
    		result := 1;
    		if xtjid is NULL
    			then result := 0;
        		else
    				IF EXISTS (select * from amb.sr_res_team_job_resourse srtjr
    					where (srtjr.team_job_id = xtjid) and (srtjr.workplace like '%Водитель%') and (srtjr.edate is null) and (srtjr.resource_id <> xresurce) and (srtjr.change_id = xchange))
    	    			and EXISTS(select * from amb.sr_res_team_job_resourse srtjr left join sr_resource sr on srtjr.resource_id = sr.id
        				where srtjr.team_job_id = xtjid and sr.res_kind_id = 1 and (srtjr.workplace like '%Врач%' or srtjr.workplace like '%Фельдшер%')
                        		and srtjr.edate is null and resource_id <> xresurce and change_id = xchange)
        				and  exists(select * from amb.sr_res_team_job_resourse srtjr left join sr_resource sr on srtjr.resource_id = sr.id
        				where srtjr.team_job_id = xtjid and sr.res_kind_id = 5 and srtjr.edate is null and resource_id <> xresurce and change_id = xchange)
    				THEN
    					result := 0;
    				END IF;
    		end if;
    	else result := 0;
    end if;
    return result;
  end;
$$;

