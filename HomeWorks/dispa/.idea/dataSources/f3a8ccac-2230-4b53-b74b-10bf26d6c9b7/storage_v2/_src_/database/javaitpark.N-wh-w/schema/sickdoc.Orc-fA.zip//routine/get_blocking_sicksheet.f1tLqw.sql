CREATE FUNCTION get_blocking_sicksheet(p_individual integer, p_disability_reason_id integer)
  RETURNS character varying
LANGUAGE plpgsql
AS $$
DECLARE
  sicksheet VARCHAR := NULL;
  s sickdoc.sickdoc;
  se sickdoc.sickdoc_extended;
BEGIN

  -- Проходим по всем открытым ЛН пользователя
  FOR s IN
    (SELECT *
      FROM sickdoc.sickdoc
      WHERE individual_id = p_individual AND state_id = 2 )
  LOOP
    -- Если блокирующий ЛН еще не найден
    IF sicksheet ISNULL THEN

      SELECT *
        FROM sickdoc.sickdoc_extended
        WHERE id = s.id
        INTO se;

      IF ( (se.disability_reason_id <> p_disability_reason_id) OR (se.family_member_1_id ISNULL) OR (se.family_member_2_id ISNULL) )
      THEN
        sicksheet = s.number;
      END IF;

    END IF;
  END LOOP;

  RETURN sicksheet;
END;
$$;

