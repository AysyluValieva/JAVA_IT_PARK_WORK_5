CREATE FUNCTION show_full_age(xage character varying)
  RETURNS text
LANGUAGE plpgsql
AS $$
DECLARE
  eventAge TEXT;
  result   TEXT;
  ageyear  TEXT;
  agemonth TEXT;
BEGIN

  IF (Position('.' IN xage) > 0)
  THEN
    ageyear = LEFT(xage, Position('.' IN xage) - 1);
  ELSE
    ageyear = xage;
  END IF;
  IF (Position('.' IN xage) > 0)
  THEN
    agemonth = substr(xage, Position('.' IN xage) + 1) || 'мес.';
  ELSE
    agemonth = '';
  END IF;

  IF (ageyear NOT IN ('1', '2', '3', '4'))
  THEN
    ageyear = ageyear || 'л. ';
  ELSE
    ageyear = ageyear || 'г. ';
  END IF;

  RETURN ageyear || agemonth;
END;
$$;

