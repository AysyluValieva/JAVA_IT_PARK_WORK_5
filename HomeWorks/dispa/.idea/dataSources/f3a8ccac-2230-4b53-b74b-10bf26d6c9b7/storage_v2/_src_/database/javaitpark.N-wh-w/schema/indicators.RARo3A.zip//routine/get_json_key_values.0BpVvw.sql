CREATE FUNCTION get_json_key_values(_j json, _key text)
  RETURNS text[]
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT ARRAY(SELECT elem->>_key FROM json_array_elements(_j) elem)
$$;

