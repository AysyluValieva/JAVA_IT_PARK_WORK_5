CREATE FUNCTION savegibddinspec(xepid integer, xssrid integer, xcaseid integer, xbdate character varying, xresource integer, xmd integer, xdis integer, xservice integer, xsuspicion boolean, xvalida boolean, xvalida1 boolean, xvalidb boolean, xvalidb1 boolean, xvalidbe boolean, xvalidc boolean, xvalidc1 boolean, xvalidce boolean, xvalidc1e boolean, xvalidd boolean, xvalidd1 boolean, xvalidde boolean, xvalidd1e boolean, xvalidm boolean, xvalidtm boolean, xvalidtb boolean)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
          serviceid integer;
          srrid integer;
          stepid integer;
          sysresid integer;
          gibddserviceid integer;
        begin
          serviceid = xservice;
          if (select count(meec.id) from disp.md_event_eq_case meec
                left join MD_SRV_RENDERED msr on msr.case_id = meec.case_id
                inner join SR_SRV_RENDERED ssr on ssr.id = msr.id and ssr.service_id = serviceid
                where meec.event_patient_id = xepid) > 0 then
              if xssrid IS NULL then
                xssrid = (select ssr.id from disp.md_event_eq_case meec
                left join MD_SRV_RENDERED msr on msr.case_id = meec.case_id
                inner join SR_SRV_RENDERED ssr on ssr.id = msr.id and ssr.service_id = serviceid
                where meec.event_patient_id = xepid);
              end if;
              srrid = xssrid;
              update mc_step set admission_date = COALESCE(to_date(xbdate, 'DD.MM.YYYY'), current_date), outcome_date = COALESCE(to_date(xbdate, 'DD.MM.YYYY'), current_date)
                where id = (select step_id from gibdd.md_gibdd_service where service_id = xssrid);

              if xresource != (select res_group_id from SR_SRV_RENDERED where id = xssrid) then
                sysresid = nextval('sr_res_group_seq');
                insert into SR_RES_GROUP (id, bdate, edate, is_system, name, department_id, org_id, responsible_id, is_available_in_electronic_queue, label_id)
                  select sysresid as id, bdate, edate, TRUE as is_system, name, department_id, org_id, responsible_id, is_available_in_electronic_queue, label_id
                  from SR_RES_GROUP
                  where id = xresource;
                update mc_step set res_group_id = sysresid
                  where id = (select step_id from gibdd.md_gibdd_service where service_id = xssrid);
              end if;
              update mc_diagnosis set diagnos_id =  xmd, disease_type_id = xdis, establishment_date = COALESCE(to_date(xbdate, 'DD.MM.YYYY'), current_date)
                where id = (select diagnos_id from gibdd.md_gibdd_service where service_id = xssrid);
              update disp.md_dispr_diagnosis_service set resource_id = xresource, service_id = serviceid
                where diagnosis_id = (select diagnos_id from disp.md_event_service_therapeutist where service_id = xssrid);
              update SR_SRV_RENDERED set bdate=COALESCE(to_date(xbdate, 'DD.MM.YYYY'), current_date), edate=COALESCE(to_date(xbdate, 'DD.MM.YYYY'), current_date), res_group_id=xresource
               where id = xssrid;
              if (select count(id) from gibdd.md_gibdd_service where service_id = xssrid) > 0 then
                update gibdd.md_gibdd_service set main_diagnosis_id=xmd, disease_type_id=xdis, is_surmise = xsuspicion, rendered_date = to_date(xbdate, 'DD.MM.YYYY')
                  where service_id = xssrid;
                gibddserviceid = (select id from gibdd.md_gibdd_service where service_id = xssrid);
              else
                gibddserviceid = nextval('gibdd.md_gibdd_service_seq');
                insert into gibdd.md_gibdd_service (id, event_patient_id, service_id, main_diagnosis_id, disease_type_id, is_surmise, res_group_id, rendered_date)
                  values (gibddserviceid, xepid, srrid, xmd, xdis, xsuspicion, sysresid, to_date(xbdate, 'DD.MM.YYYY'));
              end if;
          else
            srrid = nextval('sr_srv_rendered_seq');
            stepid =  nextval('mc_step_seq');
            sysresid = nextval('sr_res_group_seq');
            -- insert newsysres, step, visit, diag
            insert into SR_RES_GROUP (id, bdate, edate, is_system, name, department_id, org_id, responsible_id, is_available_in_electronic_queue, label_id)
              select sysresid as id, bdate, edate, TRUE as is_system, name, department_id, org_id, responsible_id, is_available_in_electronic_queue, label_id
              from SR_RES_GROUP
              where id = xresource;
            insert into mc_step (id, admission_date, outcome_date, case_id, regimen_id, res_group_id, outcome_id, profile_id)
              values (stepid, COALESCE(to_date(xbdate, 'DD.MM.YYYY'), current_date), COALESCE(to_date(xbdate, 'DD.MM.YYYY'), current_date), xcaseId, 3, sysresid, (select id from mc_step_care_result where code = '306'),
                      (select mp.id from SR_RES_GROUP srg
                       left join SR_RES_GROUP_RELATIONSHIP srgr on srgr.group_id = srg.id
                       inner join pim_employee_position_resource pepr on pepr.id = srgr.resource_id
                       left join PIM_EMPLOYEE_POSITION pep on pep.id = pepr.employee_position_id
                       left join PIM_POSITION pp on pp.id = pep.POSITION_ID
                       left join PIM_SPECIALITY ps on ps.id = pp.speciality_id
                       left join disp.md_profile_specialty mps on mps.spec_code = ps.code
                       left join md_profile mp on mp.code = mps.profile_code
                       where srg.id = xresource limit 1));
            insert into plc_visit (id, goal_id, place_id) values (stepid, 46, 1);

            insert into MC_DIAGNOSIS (id, case_id, patient_id, establishment_date, diagnos_id, disease_type_id, type_id, is_suspicion, is_main)
              values (nextval('mc_diagnosis_seq'), xcaseId, (select indiv_id from disp.md_event_patient where id = xepid), COALESCE(to_date(xbdate, 'DD.MM.YYYY'), current_date), xmd,
                      xdis, 1, xsuspicion, TRUE);
            insert into disp.md_dispr_diagnosis_service (id, resource_id, service_id, diagnosis_id)
              values (nextval('disp.md_dispr_diagnosis_service_id_seq'), xresource, serviceid, currval('mc_diagnosis_seq'));
            -- end insert
            insert into SR_SRV_RENDERED (id, service_id, bdate, res_group_id, customer_id, is_rendered, edate, quantity, funding_id, org_id, payment_status_id)
              values (srrid, serviceid, COALESCE(to_date(xbdate, 'DD.MM.YYYY'), current_date), xresource, (select indiv_id from disp.md_event_patient where id = xepid), TRUE, COALESCE(to_date(xbdate, 'DD.MM.YYYY'), current_date), 1, 8, (select me.org_id from disp.md_event_patient mep left join disp.md_event me on me.id = mep.event_id where mep.id = xepid), 1);
            insert into MD_SRV_RENDERED (id, case_id, step_id) values (srrid, xcaseId, stepid);
            gibddserviceid = nextval('gibdd.md_gibdd_service_seq');
            insert into gibdd.md_gibdd_service (id, event_patient_id, service_id, main_diagnosis_id, disease_type_id, is_surmise, res_group_id, rendered_date, step_id, diagnos_id)
              values (gibddserviceid, xepid, srrid, xmd, xdis, xsuspicion, sysresid, to_date(xbdate, 'DD.MM.YYYY'), stepid, currval('mc_diagnosis_seq'));
          end if;

          -- change STATUS
          update disp.md_event_service_patient_status set status = 4
              where service_id = (select mesp.id from disp.md_event_patient mep
                left join disp.md_event_service_patient mesp on mesp.event_id = mep.event_id and mesp.indiv_id = mep.indiv_id
                inner join disp.md_event_service mes on mes.id = mesp.service_id and mes.service_id = serviceid
                where mep.id = xepid);


	  delete from gibdd.md_gibdd_service_category where gibdd_service_id = (select id from gibdd.md_gibdd_service where service_id = xssrid);
	  insert into gibdd.md_gibdd_service_category (gibdd_service_id, category_id, is_valid) values (gibddserviceid, 1, xvalidA);
	  insert into gibdd.md_gibdd_service_category (gibdd_service_id, category_id, is_valid) values (gibddserviceid, 2, xvalidA1);
          insert into gibdd.md_gibdd_service_category (gibdd_service_id, category_id, is_valid) values (gibddserviceid, 3, xvalidB);
          insert into gibdd.md_gibdd_service_category (gibdd_service_id, category_id, is_valid) values (gibddserviceid, 4, xvalidB1);
          insert into gibdd.md_gibdd_service_category (gibdd_service_id, category_id, is_valid) values (gibddserviceid, 5, xvalidBE);
	  insert into gibdd.md_gibdd_service_category (gibdd_service_id, category_id, is_valid) values (gibddserviceid, 6, xvalidC);
	  insert into gibdd.md_gibdd_service_category (gibdd_service_id, category_id, is_valid) values (gibddserviceid, 7, xvalidC1);
	  insert into gibdd.md_gibdd_service_category (gibdd_service_id, category_id, is_valid) values (gibddserviceid, 8, xvalidCE);
	  insert into gibdd.md_gibdd_service_category (gibdd_service_id, category_id, is_valid) values (gibddserviceid, 9, xvalidC1E);
	  insert into gibdd.md_gibdd_service_category (gibdd_service_id, category_id, is_valid) values (gibddserviceid, 10, xvalidD);
	  insert into gibdd.md_gibdd_service_category (gibdd_service_id, category_id, is_valid) values (gibddserviceid, 11, xvalidD1);
	  insert into gibdd.md_gibdd_service_category (gibdd_service_id, category_id, is_valid) values (gibddserviceid, 12, xvalidDE);
	  insert into gibdd.md_gibdd_service_category (gibdd_service_id, category_id, is_valid) values (gibddserviceid, 13, xvalidD1E);
	  insert into gibdd.md_gibdd_service_category (gibdd_service_id, category_id, is_valid) values (gibddserviceid, 14, xvalidM);
	  insert into gibdd.md_gibdd_service_category (gibdd_service_id, category_id, is_valid) values (gibddserviceid, 15, xvalidTm);
	  insert into gibdd.md_gibdd_service_category (gibdd_service_id, category_id, is_valid) values (gibddserviceid, 16, xvalidTb);

	  return srrid;
        end;
$$;

