CREATE FUNCTION get_quantity_for_write_off(storesupid integer, writeoffdocdt date)
  RETURNS text
LANGUAGE plpgsql
AS $$
DECLARE
  resultString     TEXT;
  mneiName         TEXT;
  unitName         TEXT;
  resMneiQuantity  NUMERIC;
  resQuantity      NUMERIC;
  hmrow            RECORD;

BEGIN

  SELECT inventory.get_store_supply_quantity_at_date_inclusive(storeSupId, writeOffDocDt) INTO resMneiQuantity;

  IF resMneiQuantity <= 0
  THEN
    RETURN 0; END IF;

  SELECT
    hm.id,
    hm.price_unit_flag,
    hm.mnei_id,
    hm.mnei_count_in_sec_pk
  INTO hmRow
  FROM
    inventory.store_supply iss
    JOIN inventory.batch ib ON iss.batch_id = ib.id
    JOIN inventory.hold_modif hm ON ib.hold_modif_id = hm.id
  WHERE
    iss.id = storeSupId;

  SELECT cm.mnemocode INTO mneiName FROM cmn_measure cm WHERE cm.id = hmRow.mnei_id;

  SELECT inventory.get_unit_name_by_flag_of_modif(hmRow.price_unit_flag, hmRow.id) INTO unitName;

  resQuantity = resMneiQuantity / coalesce(hmRow.mnei_count_in_sec_pk, 1);

  IF resQuantity = resMneiQuantity
  THEN
    resultString = trim(to_char(resQuantity, 'FM999999990.999999'), '.') || ' ' || unitName;
  ELSE
    resultString = trim(to_char(resQuantity, 'FM999999990.999999'), '.') || ' ' || unitName
                   || ' (' || trim(to_char(resMneiQuantity, 'FM999999990.999999'), '.') || ' ' || mneiName || ')';
  END IF;
  RETURN resultString;
END;
$$;

