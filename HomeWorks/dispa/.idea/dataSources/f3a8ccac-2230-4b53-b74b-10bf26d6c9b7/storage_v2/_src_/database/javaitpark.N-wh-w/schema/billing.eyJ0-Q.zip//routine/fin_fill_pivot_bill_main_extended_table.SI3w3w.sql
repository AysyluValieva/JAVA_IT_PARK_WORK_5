CREATE FUNCTION fin_fill_pivot_bill_main_extended_table(p1_bill_id integer)
  RETURNS void
STRICT
LANGUAGE plpgsql
AS $$
DECLARE 
    _main_bill_id INTEGER := public.fin_bill__get_main_bill (p1_bill_id);
    _base_bill_id INTEGER := (SELECT base_id FROM public.fin_bill_correctional WHERE id = p1_bill_id);
    _from_date DATE;
    _to_date DATE;
    _oms_id INTEGER := (SELECT id FROM public.pim_code_type WHERE code = 'CODE_OMS'        );
    _inn_id INTEGER := (SELECT id FROM public.pim_code_type WHERE code = 'INN_ORGANIZATION');
    _grn_id INTEGER := (SELECT id FROM public.pim_code_type WHERE code = 'OGRN'            );
    _kpp_id INTEGER := (SELECT id FROM public.pim_code_type WHERE code = 'KPP'             );
BEGIN
    /*
        version: 2015-06-18
    */
    IF EXISTS (SELECT 1 FROM billing.fin_bill_main_extended WHERE bill_id = p1_bill_id) THEN DELETE FROM billing.fin_bill_main_extended WHERE bill_id = p1_bill_id; END IF;
    
    SELECT 
        coalesce (a.from_date, m.from_date), coalesce (a.to_date, m.to_date) INTO _from_date, _to_date
    FROM
        public.fin_bill_main AS m LEFT JOIN public.fin_bill_additional AS a ON m.id = a.base_id AND a.id = p1_bill_id
    WHERE
        m.id = _main_bill_id
    ;
    IF
        _base_bill_id <> _main_bill_id
    THEN
        SELECT 
            coalesce (a.from_date, m.from_date), coalesce (a.to_date, m.to_date) INTO _from_date, _to_date
        FROM
            public.fin_bill_main AS m LEFT JOIN public.fin_bill_additional AS a ON m.id = a.base_id AND a.id = _base_bill_id
        WHERE
            m.id = _main_bill_id
        ;
    END IF;
    
    INSERT INTO billing.fin_bill_main_extended 
    (
        --------------счёт---------------
        main_bill_id,
        bill_id,
        bill_number,
        bill_package_number,
        bill_comment,
        bill_price_commentary,
        bill_date,
        bill_generate_date,
        bill_full_year,
        bill_year,
        bill_month,
        bill_from_date,
        bill_to_date,
        bill_price_list_id,
        bill_is_additional,
        bill_is_correctional,
        bill_fin_type_code,
        bill_is_local,
        bill_is_foreign,
        bill_is_nopolicy,
        --получатель (recipient) платежа (больница)--
        rcp_id,
        rcp_short_name,
        rcp_full_name,
        rcp_code_oms,
        rcp_inn,
        rcp_ogrn,
        rcp_kpp,
        rcp_contact_email,
        --плательщик (payer) (страховая)--
        payer_id,
        payer_short_name,
        payer_full_name,
        payer_role,
        payer_code_oms,
        payer_inn,
        payer_kpp
    )
        WITH role_refbook (role_code, role) AS (
            VALUES ('T', 'HIF_ORGANIZATION'), ('M', 'CLINIC_ORGANIZATION'), ('S', 'MEDICAL_INSURANCE_ORGANIZATION')
        ), bill AS (
            SELECT
                _main_bill_id AS main_bill_id,
                b.id AS bill_id,
                m.payer_id,
                m.clinic_id,
                b.package_number AS bill_package_number,
                coalesce (trim (b.number), '') AS bill_number,
                coalesce (trim (b.comment), '') AS bill_comment,
                coalesce (trim ((SELECT commentary FROM public.fin_price_list WHERE id = m.price_list_id LIMIT 1)), '') AS bill_price_commentary,
                b.date AS bill_date,
                CURRENT_DATE AS bill_generate_date,
                to_char (_to_date, 'YYYY') AS bill_full_year,
                to_char (_to_date, 'YY') AS bill_year,
                to_char (_to_date, 'MM') AS bill_month,
                _from_date AS bill_from_date,
                _to_date AS bill_to_date,
                m.price_list_id AS bill_price_list_id,
                EXISTS (SELECT 1 FROM public.fin_bill_additional WHERE id = b.id) AS bill_is_additional,
                EXISTS (SELECT 1 FROM public.fin_bill_correctional WHERE id = b.id) AS bill_is_correctional,
                coalesce (trim ((SELECT code FROM public.fin_funding_source_type WHERE id = m.financing_type_id LIMIT 1)), '') AS bill_fin_type_code
            FROM
                public.fin_bill AS b, public.fin_bill_main AS m 
            WHERE
                b.id = p1_bill_id AND m.id = _main_bill_id
        ), bill_insurance_affiliation AS (
            SELECT
                b.main_bill_id,
                coalesce (0 = ANY (array_agg (r.region_id)), TRUE) AS bill_is_local,
                coalesce (1 = ANY (array_agg (r.region_id)), TRUE) AS bill_is_foreign,
                coalesce (2 = ANY (array_agg (r.region_id)), TRUE) AS bill_is_nopolicy
            FROM
                bill                              AS b
                LEFT JOIN public.fin_bill_main_to_region AS r ON r.main_bill_id = b.main_bill_id
            GROUP BY 1
        ), recipient AS (
            SELECT
                b.bill_id,
                r.id AS rcp_id,
                coalesce (trim (r.short_name), '') AS rcp_short_name,
                coalesce (trim (r.full_name), '') AS rcp_full_name,
                coalesce (trim ((SELECT code FROM public.pim_org_code WHERE org_id = b.clinic_id AND type_id = _oms_id ORDER BY issue_dt DESC NULLS LAST LIMIT 1)), '') AS rcp_code_oms,
                coalesce (trim ((SELECT code FROM public.pim_org_code WHERE org_id = b.clinic_id AND type_id = _inn_id ORDER BY issue_dt DESC NULLS LAST LIMIT 1)), '') AS rcp_inn,
                coalesce (trim ((SELECT code FROM public.pim_org_code WHERE org_id = b.clinic_id AND type_id = _grn_id ORDER BY issue_dt DESC NULLS LAST LIMIT 1)), '') AS rcp_ogrn,
                coalesce (trim ((SELECT code FROM public.pim_org_code WHERE org_id = b.clinic_id AND type_id = _kpp_id ORDER BY issue_dt DESC NULLS LAST LIMIT 1)), '') AS rcp_kpp,
                coalesce (trim ((SELECT value FROM public.pim_org_contact WHERE org_id = b.clinic_id AND type_id = 4 ORDER BY id DESC LIMIT 1)), '') AS rcp_contact_email
            FROM
                bill AS b LEFT JOIN public.pim_organization AS r ON r.id = b.clinic_id
        ), payer AS (
            SELECT
                b.bill_id,
                p.id AS payer_id,
                coalesce (trim (p.short_name), '') AS payer_short_name,
                coalesce (trim (p.full_name), '') AS payer_full_name,
                e.role_code AS payer_role,
                coalesce (trim ((SELECT code FROM public.pim_org_code WHERE org_id = b.payer_id AND type_id = _oms_id ORDER BY issue_dt DESC NULLS LAST LIMIT 1)), '') AS payer_code_oms,
                coalesce (trim ((SELECT code FROM public.pim_org_code WHERE org_id = b.payer_id AND type_id = _inn_id ORDER BY issue_dt DESC NULLS LAST LIMIT 1)), '') AS payer_inn,
                coalesce (trim ((SELECT code FROM public.pim_org_code WHERE org_id = b.payer_id AND type_id = _kpp_id ORDER BY issue_dt DESC NULLS LAST LIMIT 1)), '') AS payer_kpp
            FROM
                bill AS b 
                LEFT JOIN public.pim_organization AS p ON p.id = b.payer_id
                LEFT JOIN LATERAL 
                (
                    SELECT 
                        e.role_code 
                    FROM 
                        public.pim_party_role_to_party AS t, public.pim_party_role AS r, role_refbook AS e
                    WHERE
                        r.id = t.role_id AND e.role = r.code AND t.party_id = b.payer_id
                    ORDER BY e.role_code
                    LIMIT 1
                ) AS e ON TRUE
        )
        SELECT
            --------------счёт---------------
            b.main_bill_id,
            b.bill_id,
            b.bill_number,
            b.bill_package_number,
            b.bill_comment,
            b.bill_price_commentary,
            b.bill_date,
            b.bill_generate_date,
            b.bill_full_year,
            b.bill_year,
            b.bill_month,
            b.bill_from_date,
            b.bill_to_date,
            b.bill_price_list_id,
            b.bill_is_additional,
            b.bill_is_correctional,
            b.bill_fin_type_code,
            a.bill_is_local,
            a.bill_is_foreign,
            a.bill_is_nopolicy,
            --получатель (recipient) платежа (больница)--
            r.rcp_id,
            r.rcp_short_name,
            r.rcp_full_name,
            r.rcp_code_oms,
            r.rcp_inn,
            r.rcp_ogrn,
            r.rcp_kpp,
            r.rcp_contact_email,
            --плательщик (payer) (страховая)--
            p.payer_id,
            p.payer_short_name,
            p.payer_full_name,
            p.payer_role,
            p.payer_code_oms,
            p.payer_inn,
            p.payer_kpp
        FROM 
            bill AS b, bill_insurance_affiliation AS a, recipient AS r, payer AS p
        WHERE
            b.main_bill_id = a.main_bill_id AND b.bill_id = r.bill_id AND b.bill_id = p.bill_id
    ;
END;
$$;

