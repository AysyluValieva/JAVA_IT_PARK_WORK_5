CREATE FUNCTION shape_treatment_plan(xpregnant_map_id integer, template_ids integer[])
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
BEGIN
	IF(SELECT count(1) = 0 from motherhood.mh_treatment_plan tp where tp.pregnant_map_id = xpregnant_map_id)
		THEN INSERT INTO motherhood.mh_treatment_plan (pregnant_map_id, refresh_dt) VALUES (xpregnant_map_id, current_timestamp);
	END IF;

	INSERT INTO motherhood.mh_treatment_plan_service(planned_dt, pregnant_age, treatment_plan_id, prototype_id)
	SELECT (case when ppm.value is not null then pm.reg_dt + trunc((ppm.value - pm.pregnant_age)*7)::int else null end), ppm.value, tp.id, stp.prototype_id
		FROM motherhood.mh_treatment_plan tp, motherhood.mh_pregnant_map pm, public.services_template_prototype stp
		LEFT JOIN public.services_template st ON st.id = stp.template_id
		LEFT JOIN motherhood.mh_prototype_pregnant_age ppm ON ppm.prototype_id = stp.id
	WHERE pm.id = xpregnant_map_id and tp.pregnant_map_id = pm.id and
		NOT EXISTS (SELECT 1 from motherhood.mh_treatment_plan_service tps where tps.treatment_plan_id = tp.id and tps.prototype_id = stp.prototype_id and (tps.pregnant_age = ppm.value or (tps.pregnant_age is null and ppm.value is null)))
		and ((template_ids is null and st.is_base is true) or st.id = ANY(template_ids))
	GROUP BY stp.prototype_id, ppm.value, tp.id, pm.reg_dt, pm.pregnant_age
	ORDER BY stp.prototype_id;

END;
$$;

