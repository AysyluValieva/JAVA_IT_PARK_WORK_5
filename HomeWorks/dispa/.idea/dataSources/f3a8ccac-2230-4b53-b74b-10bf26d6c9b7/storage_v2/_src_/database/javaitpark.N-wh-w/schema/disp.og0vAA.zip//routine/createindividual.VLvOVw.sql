CREATE FUNCTION createindividual(xsurname character varying, xname character varying, xpatrname character varying, xbirthday character varying)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
		i integer;
            begin
                i = nextval('pim_party_id_seq');
                insert into pim_party (id, type_id, version, note)
		values (i, 1, current_timestamp, null);
                insert into pim_individual (id, surname, name, patr_name, birth_dt) values (i, xsurname, xname, xpatrName, to_date(xbirthday, 'DD.MM.YYYY'));
                return i;
            end;
$$;

