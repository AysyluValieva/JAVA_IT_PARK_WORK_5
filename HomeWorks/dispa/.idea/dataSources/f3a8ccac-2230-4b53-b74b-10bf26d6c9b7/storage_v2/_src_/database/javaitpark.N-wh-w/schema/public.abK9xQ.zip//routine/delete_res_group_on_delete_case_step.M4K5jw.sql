CREATE FUNCTION delete_res_group_on_delete_case_step()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
                IF TG_OP = 'DELETE' THEN
                    IF (OLD.res_group_id is not null 
                    and not exists (select 1 from sr_srv_rendered where res_group_id = OLD.res_group_id)
                    and not exists (select 1 from mc_step where res_group_id = OLD.res_group_id and id <> OLD.id)) THEN
                        delete from sr_res_group where is_system = true and id = OLD.res_group_id;
                    END IF;
                    RETURN OLD;
                END IF;
            END;
$$;

