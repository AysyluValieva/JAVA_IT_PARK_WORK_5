CREATE FUNCTION fin_get_pricelist_by_case(p1_case_id integer, p2_date date, OUT id integer, OUT cnt integer)
  RETURNS record
STABLE
STRICT
LANGUAGE plpgsql
AS $$
DECLARE
    _p RECORD;
    _price_type_id INTEGER;
    _price_id_arr INTEGER[];
BEGIN
    /*
        version: 2015-12-09
    */
    SELECT 
        c.clinic_id, c.funding_id INTO STRICT _p 
    FROM 
        mc_case AS c 
    WHERE 
        c.id = p1_case_id
    ;
    _price_type_id := 6
    ;
    _price_id_arr := ARRAY
    (
        SELECT
            p.id
        FROM 
            fin_price_list AS p, fin_pl_to_fin_type AS f
        WHERE
            p.id = f.price_list_id AND p.type_id = _price_type_id
            AND p.clinic_id = _p.clinic_id AND f.financing_type_id = _p.funding_id AND p2_date <@ daterange (p.from_dt::DATE, p.to_dt::DATE, '[]')
        ORDER BY p.from_dt DESC NULLS LAST, p.to_dt DESC, p.id DESC
    );
    IF
        _price_id_arr = '{}'::INTEGER[]
    THEN
        id := 0; cnt := 0;
    ELSIF
        array_length (_price_id_arr, 1) > 1
    THEN
        id := _price_id_arr[1]; cnt := array_length (_price_id_arr, 1);
    ELSIF
        array_length (_price_id_arr, 1) = 1
    THEN
        id := _price_id_arr[1]; cnt := 1;
    END IF;
END;
$$;

