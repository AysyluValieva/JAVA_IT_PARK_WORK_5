CREATE FUNCTION delete_transport(xid integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
                xresid integer;
                xstate integer;
              begin
                xresid = (select resource_id from amb.pim_transport_resource where transport_id = xid);
                If not exists (select * from SR_RES_GROUP_RELATIONSHIP where resource_id = xresid) and not exists(select * from amb.sr_res_team_job_resourse where resource_id = xresid)
                    then
                        delete from amb.pim_transport_resource where transport_id = xid;
                        delete from amb.pim_transport where id = xid;
                        delete from sr_resource where id = xresid;
                    else
                        xstate = (select id from pim_stock_unit_state where code = '53');
                        insert into amb.pim_transport_state (transport_id,state_id,from_dt)
                            values(xid,xstate,now());
                        update amb.pim_transport set to_dt = now() where id = xid;
                end if;
              end;
$$;

