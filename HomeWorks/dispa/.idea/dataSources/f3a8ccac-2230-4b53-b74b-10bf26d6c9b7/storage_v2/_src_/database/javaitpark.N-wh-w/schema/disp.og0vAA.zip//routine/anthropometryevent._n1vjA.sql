CREATE FUNCTION anthropometryevent(xid integer, xcaseid integer, xheight integer, xweight integer, xwaist integer, xserviceid integer, xresource integer, xdate character varying)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
          i integer;
        begin
          update disp.md_event_anthro set height=CAST(xheight as integer),
            weight=CAST(xweight as integer),
            waist=CAST(xwaist as integer),
            index_mass=CAST(CAST(xweight as real)/(CAST(xheight as real)/100 * CAST(xheight as real)/100) as real),
            type_mass=CASE WHEN (CAST(CAST(xweight as real)/(CAST(xheight as real)/100 * CAST(xheight as real)/100) as real) < 18.5) THEN 1
            WHEN (CAST(CAST(xweight as real)/(CAST(xheight as real)/100 * CAST(xheight as real)/100) as real) > 18.5 and CAST(CAST(xweight as real)/(CAST(xheight as real)/100 * CAST(xheight as real)/100) as real) < 24.9) THEN 2
            WHEN (CAST(CAST(xweight as real)/(CAST(xheight as real)/100 * CAST(xheight as real)/100) as real) > 25 and CAST(CAST(xweight as real)/(CAST(xheight as real)/100 * CAST(xheight as real)/100) as real) < 29.9) THEN 3
            WHEN (CAST(CAST(xweight as real)/(CAST(xheight as real)/100 * CAST(xheight as real)/100) as real) > 30 and CAST(CAST(xweight as real)/(CAST(xheight as real)/100 * CAST(xheight as real)/100) as real) < 34.9) THEN 4
            WHEN (CAST(CAST(xweight as real)/(CAST(xheight as real)/100 * CAST(xheight as real)/100) as real) > 35 and CAST(CAST(xweight as real)/(CAST(xheight as real)/100 * CAST(xheight as real)/100) as real) < 39.9) THEN 5
            WHEN (CAST(CAST(xweight as real)/(CAST(xheight as real)/100 * CAST(xheight as real)/100) as real) > 40) THEN 6
            ELSE NULL
            END
            where id = xid;
          if (select count(msr.id) from MD_SRV_RENDERED msr
              left join SR_SRV_RENDERED ssr on ssr.id = msr.id
              where msr.case_id = xcaseId and ssr.service_id = xserviceid) = 0 then
              i = nextval('sr_srv_rendered_seq');
              insert into SR_SRV_RENDERED (id, service_id, bdate, res_group_id, customer_id, is_rendered, edate, quantity, funding_id, org_id, payment_status_id)
                values (i, xserviceid, COALESCE(to_date(xdate, 'DD.MM.YYYY'), current_date), xresource, (select indiv_id from disp.md_event_patient where id = xid), TRUE, COALESCE(to_date(xdate, 'DD.MM.YYYY'), current_date), 1, 8, (select me.org_id from disp.md_event_patient mep left join disp.md_event me on me.id = mep.event_id where mep.id = xid), 1);
              insert into MD_SRV_RENDERED (id, case_id) values (i, xcaseId);
          else
              update SR_SRV_RENDERED set bdate = to_date(xdate, 'DD.MM.YYYY'), res_group_id = xresource
                where id in (select id from MD_SRV_RENDERED where case_id = xcaseId) and service_id = xserviceid;
          end if;
          -- change STATUS
          update disp.md_event_service_patient_status set status = 4
              where service_id = (select mesp.id from disp.md_event_patient mep
                left join disp.md_event_service_patient mesp on mesp.event_patient_id = mep.id
                inner join disp.md_event_service mes on mes.id = mesp.service_id and mes.service_id = xserviceid
                where mep.id = xid);
          return i;
        end;
$$;

