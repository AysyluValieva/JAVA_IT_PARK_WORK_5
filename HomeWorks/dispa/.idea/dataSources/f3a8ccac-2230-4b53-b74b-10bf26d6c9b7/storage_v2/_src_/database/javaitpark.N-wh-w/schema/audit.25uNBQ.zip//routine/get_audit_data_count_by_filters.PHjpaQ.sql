CREATE FUNCTION get_audit_data_count_by_filters(_table_setting_id integer, _aud_record_id character varying, _record_id character varying, _sec_user_login character varying, _periods character varying)
  RETURNS bigint
LANGUAGE plpgsql
AS $$
DECLARE
                  base_query      VARCHAR;
                  count_records   INTEGER;
                BEGIN
                  IF _aud_record_id NOTNULL
                  THEN
                    RETURN 1 :: BIGINT;
                  ELSE
                    base_query = audit.get_audit_data_by_filters_query(
                        _table_setting_id, _aud_record_id, _record_id, _sec_user_login, _periods);

                    base_query = replace(base_query, ':select', 'count(*)');

                    EXECUTE base_query INTO count_records;

                    RETURN count_records :: BIGINT;
                  END IF;
                END;
$$;

