CREATE FUNCTION fin_price_modifier__need_apply(r_id integer, condition character varying)
  RETURNS boolean
LANGUAGE plpgsql
AS $$
declare result boolean;
begin
	if condition is null or trim(condition) = '' then return true; end if;
	if upper(condition) not like '%SELECT%' then execute 'select ' || condition ||' from sr_srv_rendered where id='||r_id into result; end if;
    if upper(condition) like '%SELECT%' then
      execute replace(condition, '?', r_id||'') into result;
    end if;
    return result;
end;
$$;

