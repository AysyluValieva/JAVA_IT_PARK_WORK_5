CREATE FUNCTION fin_get_bill_restrictions(p1_bill_id integer, OUT value text)
  RETURNS text
STABLE
STRICT
LANGUAGE plpgsql
AS $$
DECLARE 
    _main_bill_id INTEGER := public.fin_bill__get_main_bill (p1_bill_id);
    _type_id INTEGER;
    _case_type_id INTEGER;
    _restrictions HSTORE;
BEGIN
    SELECT 
        case_type_id, type_id INTO _case_type_id, _type_id
    FROM
        public.fin_bill_main
    WHERE
        id = _main_bill_id
    ;
    
    IF
        _type_id IS NOT NULL
    THEN
        _restrictions :=
            hstore ('care_regimen',   (SELECT string_agg (care_regimen_id::TEXT, ', ')   FROM public.fin_bill_main_type_to_care_regimen   WHERE main_bill_type_id = _type_id)) || 
            hstore ('payment_method', (SELECT string_agg (payment_method_id::TEXT, ', ') FROM public.fin_bill_main_type_to_payment_method WHERE main_bill_type_id = _type_id)) || 
            hstore ('init_goal',      (SELECT string_agg (case_init_goal_id::TEXT, ', ') FROM public.fin_bill_main_type_to_case_init_goal WHERE main_bill_type_id = _type_id)) || 
            hstore ('case_type',      (SELECT string_agg (case_type_id::TEXT, ', ')      FROM public.fin_bill_main_type_to_case_type      WHERE main_bill_type_id = _type_id)) || 
            hstore ('care_level',     (SELECT string_agg (care_level_id::TEXT, ', ')     FROM public.fin_bill_main_type_to_care_level     WHERE main_bill_type_id = _type_id))
        ;
    ELSE
        _restrictions :=
            hstore ('care_regimen',   (SELECT string_agg (care_regimen_id::TEXT, ', ')   FROM public.fin_bill_main_to_care_regimen   WHERE main_bill_id = _main_bill_id)) || 
            hstore ('payment_method', (SELECT string_agg (payment_method_id::TEXT, ', ') FROM public.fin_bill_main_to_payment_method WHERE main_bill_id = _main_bill_id)) || 
            hstore ('init_goal',      (SELECT string_agg (case_init_goal_id::TEXT, ', ') FROM public.fin_bill_main_to_case_init_goal WHERE main_bill_id = _main_bill_id)) || 
            hstore ('case_type',      _case_type_id::TEXT) 
        ;
    END IF;
    value := concat 
    (
        'AND c.case_type_id IN ('      || (_restrictions -> 'case_type')      || ') ', 
        'AND c.init_goal_id IN ('      || (_restrictions -> 'init_goal')      || ') ', 
        'AND c.care_level_id IN ('     || (_restrictions -> 'care_level')     || ') ', 
        'AND c.care_regimen_id IN ('   || (_restrictions -> 'care_regimen')   || ') ', 
        'AND c.payment_method_id IN (' || (_restrictions -> 'payment_method') || ') '  
    );
END;
$$;

