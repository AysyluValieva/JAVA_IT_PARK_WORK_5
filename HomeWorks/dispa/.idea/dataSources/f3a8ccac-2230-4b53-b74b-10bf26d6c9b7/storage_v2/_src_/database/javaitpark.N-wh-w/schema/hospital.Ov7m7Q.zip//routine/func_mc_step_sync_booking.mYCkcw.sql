CREATE FUNCTION func_mc_step_sync_booking()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
/*
если в текущем посещении выбирается/удаляется групповой ресурс
в составе которого уже есть составной  ресурс койка, созданный ранее,
то мы добавляем/удаляем запись в бронирование койки на это посещение,
при условии, что подразделение в профиле койки и подразделение посещения совпадают
*/
DECLARE
    busy_id INTEGER;
    conf_id INTEGER;
    unconf_id INTEGER;
    free_id INTEGER;
    rez     INTEGER;
    rol_res INTEGER;
    check_used_kf BOOLEAN;
BEGIN
    select id into unconf_id from hospital.booking_status where code = '2';
    select id into conf_id from hospital.booking_status where code = '3';
    select id into busy_id from hospital.booking_status where code = '5';
    select id into free_id from hospital.booking_status where code = '4';
    select id into rol_res from sr_res_role where code = 'BED';

    --insert into hospital.booking_dev_log (log) select 'начало';
    IF (TG_OP = 'DELETE')
    THEN
        SELECT
            CASE
                WHEN exists(SELECT 1
                            FROM hospital.detailed_bed_sheduler_settings ds
                                LEFT JOIN public.cmn_scope_type cst ON ds.level_id = cst.id
                            WHERE cst.code = 'Clinic' AND ds.org_id = mc.clinic_id
                                  AND ds.use_detailed_bed_sheduler IS TRUE AND
                                  (ds.from_date IS NULL OR ds.from_date <= current_date))
                    THEN true
                ELSE
                    CASE WHEN (NOT exists(
                        SELECT 1
                        FROM hospital.detailed_bed_sheduler_settings ds
                            LEFT JOIN public.cmn_scope_type cst ON ds.level_id = cst.id
                        WHERE cst.code = 'Clinic' AND ds.org_id = mc.clinic_id)
                               AND exists(
                                   SELECT 1
                                   FROM hospital.detailed_bed_sheduler_settings ds
                                       LEFT JOIN public.cmn_scope_type cst ON ds.level_id = cst.id
                                   WHERE cst.code = 'Global' AND ds.use_detailed_bed_sheduler IS TRUE AND
                                         (ds.from_date IS NULL OR ds.from_date <= current_date))
                    )
                        THEN true
                    ELSE false
                    END
                END into check_used_kf
        from mc_case mc where mc.id = OLD.case_id;
        -- найдем все связанные записи в таблице BOOKING и делаем их isCurrent = FALSE
        IF (check_used_kf) THEN
            WITH dd as (UPDATE hospital.booking boo
            SET iscurrent = false
            where boo.step_id = OLD.id
                  and boo.iscurrent = TRUE
                  and boo.status_id = busy_id returning *)
            ---log0 as (insert into hospital.dev_log (comment, log) select 'триггерная функция hospital.func_mc_step_sync_booking точка 0',  array_to_json(array_agg(row_to_json(t))) from (select * from dd) t RETURNING 1)
                select 1 into rez;
        end if;
        RETURN OLD;
    ELSE
        IF (TG_OP = 'INSERT') THEN
            SELECT
                CASE
                WHEN exists(SELECT 1
                            FROM hospital.detailed_bed_sheduler_settings ds
                                LEFT JOIN public.cmn_scope_type cst ON ds.level_id = cst.id
                            WHERE cst.code = 'Clinic' AND ds.org_id = mc.clinic_id
                                  AND ds.use_detailed_bed_sheduler IS TRUE AND
                                  (ds.from_date IS NULL OR ds.from_date <= current_date))
                    THEN true
                ELSE
                    CASE WHEN (NOT exists(
                        SELECT 1
                        FROM hospital.detailed_bed_sheduler_settings ds
                            LEFT JOIN public.cmn_scope_type cst ON ds.level_id = cst.id
                        WHERE cst.code = 'Clinic' AND ds.org_id = mc.clinic_id)
                               AND exists(
                                   SELECT 1
                                   FROM hospital.detailed_bed_sheduler_settings ds
                                       LEFT JOIN public.cmn_scope_type cst ON ds.level_id = cst.id
                                   WHERE cst.code = 'Global' AND ds.use_detailed_bed_sheduler IS TRUE AND
                                         (ds.from_date IS NULL OR ds.from_date <= current_date))
                    )
                        THEN true
                    ELSE false
                    END
                END into check_used_kf
            from mc_case mc where mc.id = NEW.case_id;
            IF (check_used_kf) THEN -- только если КФ включен
                -- только если тип составного ресурса КОЙКА, добавим в БРОНИ новые записи, при условии что есть step_id и даты буккинга заполнены,
                -- кроме того проверяем совпадение подразделения в профиле койки и подразделение посещения
                with
                    ins_b as (
                    insert into hospital.booking (step_id, rg_rel_id, bed_id, status_id, status_date, begin_dt, end_dt, iscurrent)
                    select  new.id, rg_rel.id, mbr.bed_id, busy_id, current_date, rg_rel.bdatetime, rg_rel.edatetime, TRUE
                    from    sr_res_group_relationship rg_rel
                            join lateral (select hr.department_id from hsp_record hr where hr.id = new.id limit 1) hr on true-- только госпитальные случаи
                            join md_bed_resource mbr on mbr.id = rg_rel.resource_id
                            join md_bed mb on mb.id = mbr.bed_id
                            join md_room room ON mb.room_id = room.id
                            --join md_room_profile rp ON rp.room_id = room.id
                            join pim_room pr ON pr.id = room.id
                    where   rg_rel.group_id = new.res_group_id
                            and rg_rel.role_id = rol_res
                            and rg_rel.bdatetime <= rg_rel.edatetime
                            and pr.department_id = hr.department_id
--                         проверка на существование профиля помещения или отделения вместо join md_room_profile rp ON rp.room_id = room.id
                            and exists (select rp.id from md_room_profile rp where rp.room_id = room.id
                                union select mdp.id from md_department_profile mdp where mdp.department_id = pr.department_id)
                    returning *),
                    ---log3i as (insert into hospital.dev_log (comment, log) select 'insert __ hospital.func_mc_step_sync_booking точка 1',  array_to_json(array_agg(row_to_json(t))) from (select * from ins_b) t RETURNING 1),
                    ins_bs as (
                    insert into hospital.booking_shift (booking_id, count_shift, dt)
                    select  boo.id, 1, d.dt--current_date
                    from    ins_b boo
                            join lateral (select dt from generate_series(boo.begin_dt::date, boo.end_dt::date, '1 day')dt)d on true
                    returning 1)
                select 1 into rez;
                --END IF;
            end if;
            RETURN NEW;
        ELSE
            SELECT
                CASE
                WHEN exists(SELECT 1
                            FROM hospital.detailed_bed_sheduler_settings ds
                                LEFT JOIN public.cmn_scope_type cst ON ds.level_id = cst.id
                            WHERE cst.code = 'Clinic' AND ds.org_id = mc.clinic_id
                                  AND ds.use_detailed_bed_sheduler IS TRUE AND
                                  (ds.from_date IS NULL OR ds.from_date <= current_date))
                    THEN true
                ELSE
                    CASE WHEN (NOT exists(
                        SELECT 1
                        FROM hospital.detailed_bed_sheduler_settings ds
                            LEFT JOIN public.cmn_scope_type cst ON ds.level_id = cst.id
                        WHERE cst.code = 'Clinic' AND ds.org_id = mc.clinic_id)
                               AND exists(
                                   SELECT 1
                                   FROM hospital.detailed_bed_sheduler_settings ds
                                       LEFT JOIN public.cmn_scope_type cst ON ds.level_id = cst.id
                                   WHERE cst.code = 'Global' AND ds.use_detailed_bed_sheduler IS TRUE AND
                                         (ds.from_date IS NULL OR ds.from_date <= current_date))
                    )
                        THEN true
                    ELSE false
                    END
                END into check_used_kf
            from mc_case mc where mc.id = NEW.case_id;
            IF (check_used_kf) THEN -- только если КФ включен
                -- если старое значение не равно новому, чистим старое, и проверяем есть ли новое состояние
                IF (OLD.res_group_id IS DISTINCT FROM NEW.res_group_id) THEN
                    WITH dd as (
                    UPDATE hospital.booking boo
                    SET iscurrent = false
                    where boo.step_id = OLD.id
                          and boo.iscurrent = TRUE
                          and boo.status_id = busy_id
                    returning *
                          )
                    ---log1 as (insert into hospital.dev_log (comment, log) select 'триггерная функция hospital.func_mc_step_sync_booking точка 1',  array_to_json(array_agg(row_to_json(t))) from (select * from dd) t RETURNING 1)
                    select 1 into rez;
                END if;
                -- теперь работаем с новым состоянием, сравниваем новое состояние в ресурсе койки и в бронировании в разрезе только нашего посещения, если будет разница делаем неактивной бронь и создаем новую как в ресурсе
                with
                diff_before (rg_rel_id, step_id, bed_id, patient_id, department_id, bdatetime, edatetime) as
                        (SELECT
                                srgr.id AS rg_rel_id,
                                new.id AS step_id,
                                mbr.bed_id,
                                mc.patient_id,
                                hr.department_id,
                                srgr.bdatetime,
                                srgr.edatetime
                            FROM sr_res_group_relationship srgr
                                JOIN (select hr.department_id from hsp_record hr where hr.id = new.id limit 1) hr ON TRUE-- только госпитальные случаи
                                join md_bed_resource mbr on mbr.id = srgr.resource_id
                                join md_bed mb on mb.id = mbr.bed_id
                                join md_room room ON mb.room_id = room.id
--                                 join md_room_profile rp ON rp.room_id = room.id
                                join pim_room pr ON pr.id = room.id
                                join mc_case mc on mc.id = NEW.case_id
                            WHERE
                                srgr.group_id = new.res_group_id
                                and srgr.role_id = rol_res
                                and srgr.bdatetime <= srgr.edatetime
                                and pr.department_id = hr.department_id
--                         проверка на существование профиля помещения или отделения вместо join md_room_profile rp ON rp.room_id = room.id
                                and exists (select rp.id from md_room_profile rp where rp.room_id = room.id
                                            union select mdp.id from md_department_profile mdp where mdp.department_id = pr.department_id)),
                conf_unconf as ( -- сделаем неактивными записи conf, unconf если такие есть
                    select
                        boo.reservation_id, boo.id as boo_id, d.step_id, d.rg_rel_id-- ИД
                    from
                        diff_before d
                        join hospital.booking boo on boo.bed_id = d.bed_id and boo.iscurrent and boo.status_id in (conf_id, unconf_id)
                            and boo.begin_dt = d.bdatetime::date and boo.end_dt = d.edatetime::date -- поиск по датам
                        join hsp_reservation hr on hr.id = boo.reservation_id and hr.department_id = d.department_id
                        join md_referral mr on mr.id = hr.referral_id and mr.patient_id = d.patient_id -- поиск по пациенту
                    ),
                upd_boo as (--сделаем неактуальной запись UNCONF, CONF которую нашли на предыдущем шаге
                    update hospital.booking set iscurrent = FALSE from conf_unconf t where id = t.boo_id
                    returning 1
                    ),
                diff (step_id, reservation_id, rg_rel_id, bed_id, bdatetime, edatetime) as
                    (-- сравним по дням количество смен в ресурсе и в брони, если есть разница выведем значения step_id, rg_rel_id, для которых надо закомитить старые booking и завести новые
                     -- только для тех смен, по которым совпадают подразделение
                    select new.id, coalesce(b_res.reservation_id, d_res.reservation_id) as reservation_id, t.rg_rel_id, bed_id, t.bdatetime, t.edatetime, sum(count_shift_new) as count_shift_new, sum(count_shift_booking) as count_shift_booking
                    from (
                        select t.step_id, t.rg_rel_id, t.bed_id, t.bdatetime, t.edatetime,
                               t.dt, sum(count_shift_new) as count_shift_new, sum(count_shift_booking) as count_shift_booking
                        from (
                            SELECT distinct
                                df.rg_rel_id,
                                df.step_id,
                                df.bed_id,
                                df.bdatetime,
                                df.edatetime,
                                dt AS dt,
                                1 AS count_shift_new,
                                0 AS count_shift_booking
                            FROM diff_before df
                                JOIN LATERAL (
                                     SELECT dt
                                     FROM generate_series(df.bdatetime :: DATE, df.edatetime :: DATE, '1 day') dt
                                     ) d ON TRUE
                            UNION ALL
                            SELECT distinct
                                boo.rg_rel_id,
                                boo.step_id,
                                boo.bed_id,
                                boo.begin_dt,
                                boo.end_dt,
                                boo2.dt,
                                0,
                                boo2.count_shift
                            FROM
                                hospital.booking boo
                                JOIN hospital.booking_shift boo2 ON boo2.booking_id = boo.id
                            WHERE
                                boo.step_id = new.id
                                and boo.iscurrent = true
                            )t

                        GROUP BY t.step_id, t.rg_rel_id, t.bed_id, t.bdatetime, t.edatetime, t.dt
                        )t
                        left join lateral (select d_res.reservation_id from conf_unconf d_res where d_res.reservation_id is not null limit 1) d_res on true
                        left join lateral (select b_res.reservation_id from hospital.booking b_res where b_res.step_id = new.id /*and b_res.iscurrent = true*/ and b_res.reservation_id is not null limit 1) b_res on true
                    where
                        coalesce(count_shift_booking, 0) <> coalesce(count_shift_new, 0)
                    group by t.rg_rel_id, coalesce(b_res.reservation_id, d_res.reservation_id), bed_id, t.bdatetime, t.edatetime
                    ),
                ---log1 as (insert into hospital.booking_dev_log (log) select array_to_json(array_agg(row_to_json(t))) from (select * from DIFF) t RETURNING 1),
                upd_book as (-- делаем неактивными только те запими которые отличаются от нового состояния
                    UPDATE  hospital.booking boo
                    SET     iscurrent = false
                    from    diff
                    where   boo.rg_rel_id = diff.rg_rel_id
                            and boo.step_id = diff.step_id
                            and boo.iscurrent = TRUE
                            and boo.bed_id = diff.bed_id
                            and count_shift_booking <> 0
                    returning *
                    ),
                ---log2 as (insert into hospital.dev_log (comment, log) select 'триггерная функция hospital.func_mc_step_sync_booking точка 2',  array_to_json(array_agg(row_to_json(t))) from (select * from upd_book) t RETURNING 1),
                ins_book as (--добавляем новые БРОНИ только по тем записям, состояние которых не соответствует состоянию в NEW
                    insert into hospital.booking (step_id, reservation_id, rg_rel_id, bed_id, status_id, status_date, begin_dt, end_dt, iscurrent)
                    select  diff.step_id, diff.reservation_id, diff.rg_rel_id, diff.bed_id, busy_id, current_date, diff.bdatetime, diff.edatetime, true
                    from    diff
                    where   count_shift_new <> 0
                    returning *
                    ),
                ---log4i as (insert into hospital.dev_log (comment, log) select 'insert __ hospital.func_mc_step_sync_booking точка 2',  array_to_json(array_agg(row_to_json(t))) from (select * from ins_book) t RETURNING 1),
                ins_book2 as (--заполняем таблицу смен по новым добавленным записям
                    insert into hospital.booking_shift (booking_id, count_shift, dt)
                    select  boo.id, 1, d.dt
                    from  ins_book as boo
                          join lateral (select dt from generate_series(boo.begin_dt::date, boo.end_dt::date, '1 day')dt)d on true
                    RETURNING *
                    )
                select 1 into rez;
            end if;
            RETURN NEW;
        end if;
    END IF;
END;
$$;

