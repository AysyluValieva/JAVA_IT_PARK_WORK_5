CREATE FUNCTION insert_monitor_case_id(integer, integer)
  RETURNS void
LANGUAGE SQL
AS $$
insert into monitoring.monitored_cases_list (case_id, user_id)
      select $1, $2
      where not exists
      (SELECT * FROM monitoring.monitored_cases_list WHERE case_id=$1 AND user_id=$2);
$$;

