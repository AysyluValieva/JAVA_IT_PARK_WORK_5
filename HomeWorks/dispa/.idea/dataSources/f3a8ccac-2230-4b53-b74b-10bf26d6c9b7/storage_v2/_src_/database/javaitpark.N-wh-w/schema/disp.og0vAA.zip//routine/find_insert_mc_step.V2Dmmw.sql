CREATE FUNCTION find_insert_mc_step(xepid integer, xbdate character varying, xcaseid integer, xresource integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
  stepid integer;
  templateid integer;
  sysresid integer;
  mesid integer;
begin
  templateid = (select template_res_group_id from sr_res_group where id = xresource);
  mesid = (
    select me.mes_id from disp.md_event_patient mep
      join disp.md_event me on mep.event_id = me.id
    where mep.case_id = xcaseid limit 1
  );

  stepid = (select ms.id from mc_step ms
  join mc_case mc on mc.id = ms.case_id
  join disp.md_event_patient mep on mep.case_id = mc.id
  join sr_res_group srg on srg.id = ms.res_group_id
  where mep.id = xepid
  and (srg.id = xresource or srg.template_res_group_id = xresource or srg.id = templateid or srg.template_res_group_id = templateid)
  and (not exists(select 1 from disp.md_event_patient mep1
  join disp.md_event_service_patient mesp on mesp.event_patient_id = mep1.id
  join disp.md_event_service mes on mes.id = mesp.service_id
  join md_norm_document_service mnds on mnds.id = mes.doc_service_id
  join (select ssr.id, msr.case_id, ssr.service_id, msr.step_id from MD_SRV_RENDERED msr
  left join SR_SRV_RENDERED ssr on ssr.id = msr.id) as ssr on ssr.case_id = mep1.case_id and ssr.service_id = mes.service_id and ssr.step_id = ms.id
  where mnds.code in ('Д1.18', 'ОН1.1', 'ДС1.1') and mep1.id = xepid)) LIMIT 1);
  if (stepid is not null) then
    return stepid;
  else
    stepid =  nextval('mc_step_seq');
    sysresid = nextval('sr_res_group_seq');
    insert into SR_RES_GROUP(id, bdate, edate, is_system, name, department_id, org_id, responsible_id, is_available_in_electronic_queue, label_id, template_res_group_id)
      select sysresid as id, bdate, edate, TRUE as is_system, name, department_id, org_id, responsible_id, is_available_in_electronic_queue, label_id, xresource
      from SR_RES_GROUP
      where id = xresource;
    INSERT INTO sr_res_group_relationship (id, bdatetime, edatetime, resource_id, group_id, role_id, is_disabled)
      SELECT
        nextval('sr_res_group_relationship_seq') AS id,
        bdatetime,
        edatetime,
        resource_id,
        sysresid                                 AS group_id,
        role_id,
        is_disabled
      FROM sr_res_group_relationship
      WHERE group_id = xresource;
    insert into mc_step (id, admission_date, outcome_date, case_id, regimen_id, res_group_id, outcome_id, profile_id, mes_id)
    values (stepid, COALESCE(to_date(xbdate, 'DD.MM.YYYY'), current_date), COALESCE(to_date(xbdate, 'DD.MM.YYYY'), current_date), xcaseId, (select id from mc_care_regimen where code = 1 and to_dt is null),
            sysresid, (select id from mc_step_care_result where code = '306' and to_dt is null),
            coalesce((select srgp.profile_id from sr_res_group srg
              join sr_res_group_profile srgp on srgp.res_group_id = srg.id
            where srg.id = xresource or srg.id = templateid limit 1),
                     (select mp.id from SR_RES_GROUP srg
                       left join SR_RES_GROUP_RELATIONSHIP srgr on srgr.group_id = srg.id
                       inner join pim_employee_position_resource pepr on pepr.id = srgr.resource_id
                       left join PIM_EMPLOYEE_POSITION pep on pep.id = pepr.employee_position_id
                       left join PIM_POSITION pp on pp.id = pep.POSITION_ID
                       left join PIM_SPECIALITY ps on ps.id = pp.speciality_id
                       left join disp.md_profile_specialty mps on mps.spec_code = ps.code
                       left join md_profile mp on mp.code = mps.profile_code
                     where srg.id = xresource or srg.id = templateid limit 1)),
            mesid);
    insert into plc_visit (id, goal_id, place_id) values (stepid, (select mett.case_init_goal_id from disp.md_event_patient mep left join disp.md_event me on me.id = mep.event_id
      left join disp.md_event_type_target mett on mett.event_type_id = me.event_type where mep.id = xepid and mett.stage = 1 and (mett.begin_date is null or mett.begin_date <= current_date)
                                                                                           and (mett.end_date is null or mett.end_date >= current_date)),
                                                          (select id from plc_visit_place where code = '1' and to_dt is null));
    return stepid;
  end if;
end;
$$;

