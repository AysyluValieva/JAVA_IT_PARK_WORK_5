CREATE FUNCTION journal_is_active(p_id integer)
  RETURNS boolean
IMMUTABLE
LANGUAGE plpgsql
AS $$
DECLARE
  cur_dt CONSTANT DATE = current_date;
  _b DATE;
  _e DATE;
  _id INTEGER;
BEGIN

  SELECT
    id,
    begin_dt,
    end_dt
  INTO _id, _b, _e
  FROM sickdoc.journal
  WHERE id = p_id;

  RETURN (_id NOTNULL) AND ((_b ISNULL AND _e ISNULL) OR (_b <= cur_dt AND _e >= cur_dt) OR (_b <= cur_dt AND _e ISNULL) OR (_b ISNULL AND _e >= cur_dt));

END;
$$;

