CREATE FUNCTION update_event_data(xid integer, xhgi integer, xisd boolean, xi2s boolean, xed date, xit boolean, xat integer, xigtdw boolean, xigtdi boolean, xis boolean, xigts boolean)
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
          stepid integer;
          admissiondate date;
          resultid integer;
        begin
          update disp.md_dispr set health_group_id=xhgi,
                        is_d=xisd,
                        is_2_stage=xi2s,
                        end_date=xed,
                        is_therapy=xit,
                        adv_therapy=xat,
                        is_go_to_diagnostics_without=xigtdw,
                        is_go_to_diagnostics_in=xigtdi,
                        is_sanatorium=xis,
                        is_go_to_sanatorium=xigts
                        where id=xid;
          update MC_MED_CASE_RESULT set health_group_id = xhgi
                        where id = (select mc.result_id from disp.md_event_patient mep
                                    left join MC_CASE mc on mc.id = mep.case_id
                                    where mep.id = xid);
          stepid = (select step_id from disp.md_event_service_therapeutist where event_patient_id = xid);
          admissiondate = (select admission_date from mc_step where id = stepid);
          select result_id into resultid from disp.md_result_health_group mrhg
                                                    where event_type_id = (select me.event_type from disp.md_event_patient mep
                                                                           left join disp.md_event me on me.id = mep.event_id
                                                                           where mep.id = xid) and health_group_id = xhgi
                                                    and coalesce(is_2_stage, false) = coalesce(xi2s, false) and mrhg.stage = 1
                                                    and ((mrhg.begin_date is null or COALESCE(admissiondate, current_date) >= mrhg.begin_date) and (mrhg.end_date is null or COALESCE(admissiondate, current_date) <= mrhg.end_date));
          if resultid is not null then
            update mc_step set result_id = resultid
            where id = stepid;
          end if;
        end;
$$;

