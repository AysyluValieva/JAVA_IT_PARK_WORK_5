CREATE FUNCTION fin_bill__get_end_date(bill_id integer)
  RETURNS date
LANGUAGE plpgsql
AS $$
declare
    main_bill_id integer;
    to_date date;
begin
    to_date = (select fin_bill_main.to_date from fin_bill_main where fin_bill_main.id = bill_id);
    if to_date is not null then return to_date;
    end if;
    to_date = (select fin_bill_additional.to_date from fin_bill_additional where fin_bill_additional.id = bill_id);
    if to_date is not null then return to_date;
    end if;
    main_bill_id = (select fin_bill_correctional.base_id from fin_bill_correctional where fin_bill_correctional.id = bill_id);
    if main_bill_id is not null then return fin_bill__get_end_date(main_bill_id);
    end if;
end;
$$;

