CREATE FUNCTION autocreatestdpres(xstandardid integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
          i integer;
          mviews record;
        begin
          FOR mviews IN SELECT mnds.id FROM md_standard ms
                        left join md_norm_document mnd on mnd.id = ms.norm_document_id
                        left join md_norm_document_service mnds on mnds.document_id = mnd.id
                        where ms.id = xstandardId LOOP
              i = nextval('md_prescription_seq');
              insert into md_prescription(id) values (i);
              insert into md_standard_prescription(id, standard_id)
                    values(i, xstandardId);
              insert into disp.md_standard_prescription_extended (id, norm_doc_service_id)
                values (i, mviews.id);
          END LOOP;
          return 1;
        end;
$$;

