CREATE FUNCTION apda_get_patient_benefit_ids_active_on_date(individual_id integer, dt date)
  RETURNS integer[]
LANGUAGE plpgsql
AS $$
BEGIN
  RETURN (SELECT array_agg(b.benefit_def_id)
          FROM pci_benefit b
          WHERE b.patient_id = $1
                AND (dt >= b.from_dt OR b.from_dt ISNULL)
                AND (dt <= b.to_dt OR b.to_dt ISNULL));
END;
$$;

