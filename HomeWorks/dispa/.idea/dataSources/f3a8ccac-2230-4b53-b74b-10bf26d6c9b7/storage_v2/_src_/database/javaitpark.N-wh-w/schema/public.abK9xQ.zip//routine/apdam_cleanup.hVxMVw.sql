CREATE FUNCTION apdam_cleanup()
  RETURNS void
LANGUAGE plpgsql
AS $$
BEGIN
  DROP TABLE IF EXISTS apdam_regs;
  DROP TABLE IF EXISTS apdam_regs_check_by_specific_criteria;
  DROP TABLE IF EXISTS apdam_district;
  DROP TABLE IF EXISTS apdam_district_extended;
  DROP TABLE IF EXISTS apdam_patient;
  DROP TABLE IF EXISTS apdam_patient_with_address;
  DROP TABLE IF EXISTS apdam_patient_district_limited;
  DROP TABLE IF EXISTS apdam_patient_district;
  DROP TABLE IF EXISTS apdam_district_attachment_info;
END;
$$;

