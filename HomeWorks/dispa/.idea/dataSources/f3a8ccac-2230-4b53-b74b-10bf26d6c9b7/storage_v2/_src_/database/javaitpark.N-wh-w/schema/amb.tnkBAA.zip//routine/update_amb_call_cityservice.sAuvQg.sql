CREATE FUNCTION update_amb_call_cityservice(xcnote integer, xreason integer, xdescr character varying, xmessage character varying, xservice integer, xclinic integer, xemp integer, xaccepted character varying)
  RETURNS void
LANGUAGE plpgsql
AS $$
begin
	if xservice = 8 THEN
    	update amb.md_ambulance_call_in_clinic set message_number =  xmessage,clinic_id = xclinic, employee_id = xemp,accepted = xaccepted where call_note_id = xcnote;
    end if;
	update amb.md_ambulance_call_in_cityservice set message_number = xmessage, accepted = xaccepted where call_note_id = xcnote;
    update amb.md_ambulance_call_note set note_reason_id = xreason,note_description = xdescr where id = xcnote;
  end;
$$;

