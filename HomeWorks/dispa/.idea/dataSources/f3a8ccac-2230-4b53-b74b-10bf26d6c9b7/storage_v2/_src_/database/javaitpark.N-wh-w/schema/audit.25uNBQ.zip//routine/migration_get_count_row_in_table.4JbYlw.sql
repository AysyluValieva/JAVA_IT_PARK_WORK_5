CREATE FUNCTION migration_get_count_row_in_table(_table_schema character varying, _table_name character varying)
  RETURNS bigint
LANGUAGE plpgsql
AS $$
BEGIN
  IF _table_schema ISNULL
  THEN _table_schema = 'public';
  END IF;

  RETURN (SELECT c.reltuples :: BIGINT
          FROM information_schema.tables t
            JOIN pg_class c ON c.oid = concat(_table_schema, '.', _table_name) :: REGCLASS
          WHERE t.table_schema = _table_schema AND t.table_name = _table_name);
END;
$$;

