CREATE FUNCTION save_account_pregnant(xid integer, xaccountid integer, xispregnant boolean, xpregnantcount integer, xnormbirthcount integer, xinterruptedpregcount integer, xspontaneousabortcount integer, xprematurepregcount integer, xperinataldeathscount integer, xischildcongmalf boolean)
  RETURNS integer
LANGUAGE plpgsql
AS $$
DECLARE
  _id INTEGER;
BEGIN
  _id = xid;

  IF (_id IS NULL)
  THEN
    INSERT INTO d_accounting.account_pregnant (id, account_id, is_pregnant, pregnant_count, norm_birth_count, interrupted_preg_count,
    spontaneous_abort_count,premature_preg_count,perinatal_deaths_count,is_child_cong_malf)
    VALUES (nextval('d_accounting.account_pregnant_seq'), xAccountId, xIsPregnant, xPregnantCount, xNormBirthCount, xInterruptedPregCount,
            xSpontaneousAbortCount,xPrematurePregCount,xPerinatalDeathsCount,xIsChildCongMalf)
    RETURNING id
      INTO _id;
  ELSE
    UPDATE d_accounting.account_pregnant
    SET is_pregnant = xIsPregnant, pregnant_count = xPregnantCount, norm_birth_count = xNormBirthCount, interrupted_preg_count = xInterruptedPregCount,
      spontaneous_abort_count = xSpontaneousAbortCount,premature_preg_count = xPrematurePregCount,perinatal_deaths_count = xPerinatalDeathsCount,is_child_cong_malf = xIsChildCongMalf
    WHERE id = _id;
  END IF;

  RETURN _id;
END;
$$;

