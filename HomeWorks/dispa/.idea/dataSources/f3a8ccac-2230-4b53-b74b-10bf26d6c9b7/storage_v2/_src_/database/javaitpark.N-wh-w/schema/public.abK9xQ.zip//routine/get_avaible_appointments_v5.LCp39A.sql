CREATE FUNCTION get_avaible_appointments_v5(_employee_id integer, idlpu text, _individual_id integer, _bdate date, _edate date)
  RETURNS TABLE(ss integer, bdatetime character varying, edatetime character varying)
LANGUAGE plpgsql
AS $$
declare
            begin

            return QUERY (with 
all_sessions as (select ss.bdatetime, ss.edatetime, rg.id rg , ep.employee_id emp, ss.id ss
                        from pim_employee_position ep
                        inner join sr_res_group rg on rg.responsible_id=ep.id
						join sr_res_group_source srgs on srgs.res_group_id = rg.id and srgs.source_id = 0
                        inner join sr_timetable_res_group trg on trg.res_group_id=rg.id
                        inner join sr_timetable t on t.id=trg.id
                        inner join sr_shift s on s.timetable_id=t.id
                        inner join sr_session ss on ss.shift_id=s.id
												left join  sr_session_quotum ssq on ss.id=ssq.session_id
												left join sr_session_source_na sssn on sssn.session_id= ss.id
                     where rg.id = _employee_id and cast(ss.bdatetime as date)>=_bdate
and ss.bdatetime::timestamp> now()::timestamp
and cast(ss.edatetime as date)<=_edate and ssq.session_id is null and s.time_type_id!=2 and ss.time_type_id!=2
					and  sssn.session_id is null --не учитывать недоступные записи
					 ),   
--талоны пациента в заданный интервал времени                                     
individual_appointment as (
select app.bdatetime, app.edatetime 
								  from md_appointment app  
								  inner join pim_individual pi on app.customer_id=pi.id
							where pi.id=_individual_id   and app.bdatetime BETWEEN _bdate and _edate and  app.cancel_reason_id is NULL),   
--даты, на которые уже имеется запись к указанному с пециалисту в указанный интервал времени
have_employee_appointment_today as (select cast(all_sessions.bdatetime as date) d
   										from all_sessions
  										inner join md_appointment app on app.executor_id=all_sessions.rg and all_sessions.bdatetime=app.bdatetime and cancel_reason_id is NULL
   										inner join pim_individual pi on pi.id=app.customer_id
								 where  all_sessions.bdatetime>CURRENT_DATE and pi.id= _individual_id and app.state_id not in(1,4)
								 order by d
)

select all_sessions.ss,   all_sessions.bdatetime::character varying, all_sessions.edatetime::character varying
   from all_sessions
   left join md_appointment app on app.executor_id=all_sessions.rg and all_sessions.bdatetime=app.bdatetime and cancel_reason_id is NULL
   left join individual_appointment on all_sessions.bdatetime between individual_appointment.bdatetime and individual_appointment.edatetime
where individual_appointment.bdatetime is NULL
and app.id is NULL  and cast(all_sessions.bdatetime as date) not in( select d from have_employee_appointment_today) 
and all_sessions.bdatetime>CURRENT_DATE);

            end;
$$;

