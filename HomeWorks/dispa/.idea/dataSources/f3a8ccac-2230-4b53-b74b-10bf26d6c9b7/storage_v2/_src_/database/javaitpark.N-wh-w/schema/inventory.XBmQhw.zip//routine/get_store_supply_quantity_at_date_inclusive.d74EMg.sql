CREATE FUNCTION get_store_supply_quantity_at_date_inclusive(storesupplyid integer, todate date)
  RETURNS numeric
LANGUAGE plpgsql
AS $$
DECLARE
  result  NUMERIC;
  income  NUMERIC;
  outcome NUMERIC;

BEGIN

  SELECT coalesce(SUM(jur.mnei_quantity), 0)
  INTO income
  FROM inventory.store_opr_jur AS jur
    LEFT JOIN inventory.store_opr opr ON jur.store_opr_id = opr.id
    LEFT JOIN inventory.store_opr_type TYPE ON TYPE.id = opr.opr_type_id
  WHERE TYPE.id = 1 AND jur.date <= toDate :: DATE AND rec_store_sup_id = storeSupplyId;

  SELECT coalesce(SUM(jur.mnei_quantity), 0)
  INTO outcome
  FROM inventory.store_opr_jur AS jur
    LEFT JOIN inventory.store_opr opr ON jur.store_opr_id = opr.id
    LEFT JOIN inventory.store_opr_type TYPE ON TYPE.id = opr.opr_type_id
  WHERE TYPE.id = 2 AND jur.date <= toDate :: DATE AND send_store_sup_id = storeSupplyId;

  result = income - outcome;
  RETURN result;
END;
$$;

