CREATE FUNCTION update_incorrect_modif_daia_in_all_tables()
  RETURNS void
LANGUAGE plpgsql
AS $$
BEGIN

UPDATE inventory.arrival_spec spec SET mnei_quantity=quantity*coalesce(hm.mnei_count_in_sec_pk,1)
FROM
     inventory.hold_modif hm
     inner join inventory.incorrect_used_modif_list ihm on ihm.modif_id=hm.id
WHERE
spec.hold_modif_id = hm.id;
------
UPDATE inventory.store_supply ss SET act_balance_mnei=ss.act_balance_arr*coalesce(hm.mnei_count_in_sec_pk,1)
FROM
     inventory.hold_modif hm
     inner join inventory.incorrect_used_modif_list ihm on ihm.modif_id=hm.id
     left outer join inventory.batch b on b.hold_modif_id=hm.id
     inner join inventory.store_supply sup on sup.batch_id = b.id
WHERE
sup.id = ss.id;
-------
UPDATE inventory.store_opr_jur ss SET mnei_quantity=quantity*coalesce(hm.mnei_count_in_sec_pk,1)
FROM
     inventory.hold_modif hm
     inner join inventory.incorrect_used_modif_list ihm on ihm.modif_id=hm.id
     left outer join inventory.batch b on b.hold_modif_id=hm.id
     inner join inventory.store_supply sup on sup.batch_id = b.id
WHERE
(rec_store_sup_id = sup.id
or send_store_sup_id =sup.id);

-------
UPDATE inventory.exp_spec s SET mnei_quantity=quantity*coalesce(hm.mnei_count_in_sec_pk,1)
FROM
     inventory.hold_modif hm
     inner join inventory.incorrect_used_modif_list ihm on ihm.modif_id=hm.id
WHERE
hm.id=s.hold_modif_id;
------
UPDATE inventory.request_spec s SET mnei_quantity=quantity*coalesce(hm.mnei_count_in_sec_pk,1)
FROM
     inventory.hold_modif hm
     inner join inventory.incorrect_used_modif_list ihm on ihm.modif_id=hm.id
WHERE
hm.id=s.modif_id;
-----
UPDATE inventory.write_off_spec s SET mnei_quantity=quantity*coalesce(hm.mnei_count_in_sec_pk,1)
FROM
     inventory.hold_modif hm
     inner join inventory.incorrect_used_modif_list ihm on ihm.modif_id=hm.id
WHERE
hm.id=s.hold_modif_id;
------
UPDATE inventory.return_doc_spec s SET mnei_quantity=quantity*coalesce(hm.mnei_count_in_sec_pk,1)
FROM
     inventory.hold_modif hm
     inner join inventory.incorrect_used_modif_list ihm on ihm.modif_id=hm.id
WHERE
hm.id=s.hold_modif_id;
------
UPDATE inventory.application_spec s SET mnei_quantity=quantity*coalesce(hm.mnei_count_in_sec_pk,1)
FROM
     inventory.hold_modif hm
     inner join inventory.incorrect_used_modif_list ihm on ihm.modif_id=hm.id
WHERE
hm.id=s.modif_id;
------
UPDATE inventory.fin_contract_spec s SET mnei_quantity=quantity*coalesce(hm.mnei_count_in_sec_pk,1)
FROM
     inventory.hold_modif hm
     inner join inventory.incorrect_used_modif_list ihm on ihm.modif_id=hm.id
WHERE
hm.id=s.hold_modif_id;

END;
$$;

