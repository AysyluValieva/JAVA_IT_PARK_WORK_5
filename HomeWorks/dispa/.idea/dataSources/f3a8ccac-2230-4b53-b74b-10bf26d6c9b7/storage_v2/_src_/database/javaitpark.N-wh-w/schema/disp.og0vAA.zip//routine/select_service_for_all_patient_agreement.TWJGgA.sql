CREATE FUNCTION select_service_for_all_patient_agreement(xepid integer, xeventage character varying)
  RETURNS integer[]
LANGUAGE plpgsql
AS $$
DECLARE
        mes_id integer;
        model_age text;
        num text;
        services_id_model_ages text [] ;
        xage numeric;
        age text;
        service_id_actual integer [];
        service_id_model_age text;
        event_type_code character varying;
        ageyearmounth text;
        ageyear text;
    BEGIN

        services_id_model_ages=(select   array_agg(row_to_json(row(mes.id,mmpb.age)))
                            from disp.md_event_service mes
                            left join disp.md_event_service_model mesm on mesm.event_service_id=mes.id
                            left join disp.md_model_patient mmp on mmp.id=mesm.model_id
                            inner join disp.md_model_patient_base mmpb on  mmpb.model_id=mmp.id
                            left join pim_individual i on i.id= (select indiv_id from disp.md_event_patient where id=xepid)
                                where  mmpb.gender_id=i.gender_id and
                                        mes.event_id=(select event_id from disp.md_event_patient where id=xepid) and mmp.base is true
                   );

        event_type_code = (select met.code from disp.md_event_patient mep
                        join disp.md_event me on me.id = mep.event_id
                        join disp.md_event_type met on met.id = me.event_type
                        where mep.id=xepid);

        ageyearmounth=xeventage;
        ageyear=LEFT(xeventage , Position ('.' in xeventage)-1);


        if services_id_model_ages is not null then
            foreach  service_id_model_age  in array services_id_model_ages
                Loop
                --mes.id
                mes_id:=cast((service_id_model_age::json->'f1')as text);
                continue when mes_id = any(service_id_actual);
                model_age:=cast((service_id_model_age::json->'f2')as character varying);
                model_age:=substring(model_age from  2 for length (model_age)-2 );
                    FOREACH age IN ARRAY regexp_split_to_array(replace(model_age,' ',''),',')
                        LOOP
                        if(age like '%.%') then
                            if(age=ageyearmounth) then
                               service_id_actual:=array_append(service_id_actual,mes_id::integer);
                               exit;
                             end if;
                        else
                             if(age=ageyear) then
                               service_id_actual:=array_append(service_id_actual,mes_id::integer);
                               exit;
                             end if;

                        end if;
                        END LOOP;

                END LOOP;
        end if;

        return  service_id_actual;

        EXCEPTION WHEN others THEN
        return  ARRAY[]::integer[];

END;
$$;

