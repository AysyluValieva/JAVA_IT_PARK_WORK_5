CREATE FUNCTION fin_spec_import(p1_bill_id integer, p2_status text)
  RETURNS void
STRICT
LANGUAGE plpgsql
AS $$
DECLARE 
    _r RECORD;
    _main_bill_id INTEGER;
BEGIN
    /*
        version: 2015-03-13
    */
    --блокирование операций загрузки
    IF
        EXISTS (SELECT 1 FROM fin_bill_spec_item_returned_error_lock WHERE bill_id = p1_bill_id AND is_locked)
    THEN
        RAISE EXCEPTION 'В этом счёте уже загружается дефектура';
    END IF;
    IF 
        NOT EXISTS (SELECT 1 FROM fin_bill_spec_item_returned_error_lock WHERE bill_id = p1_bill_id)
    THEN
        INSERT INTO fin_bill_spec_item_returned_error_lock (bill_id) VALUES (p1_bill_id)
        ;
    END IF;
    UPDATE fin_bill_spec_item_returned_error_lock SET is_locked = TRUE WHERE bill_id = p1_bill_id
    ;
    --удаление ошибок МЭК в счёте
    DELETE FROM fin_bill_spec_item_error AS e USING fin_bill_spec_item AS i, fin_bill_mek_error AS m
    WHERE
        e.item_id = i.id AND e.code = m.code AND i.bill_id = p1_bill_id 
    ;
    UPDATE fin_bill_spec_item SET status_id = 1 WHERE bill_id = p1_bill_id
    ;
    UPDATE fin_bill_steps AS s
    SET
        spec_err_exists = EXISTS (SELECT 1 FROM fin_bill_spec_item_error WHERE item_id = s.spec_item_id)
    WHERE
        s.bill_id = p1_bill_id AND s.spec_err_exists
    ;
    --добавление bill_id
    UPDATE fin_bill_spec_item_returned_error SET bill_id = text_bill_id::INTEGER WHERE text_bill_id::INTEGER = p1_bill_id AND bill_id IS NULL
    ;
    --добавление источника ошибок
    IF 
        NOT EXISTS (SELECT 1 FROM fin_bill_error_source WHERE bill_id = p1_bill_id)
    THEN
        INSERT INTO fin_bill_error_source (id, bill_id, name) SELECT nextval ('fin_bill_error_source_seq'), p1_bill_id, p1_bill_id::TEXT;
    END IF;
    --добавление id записей счёта
    WITH t AS 
    (
        SELECT bill_id, case_id, array_agg (spec_item_id) AS item_id_arr FROM fin_bill_steps WHERE bill_id = p1_bill_id GROUP BY 1, 2
    )
    UPDATE fin_bill_spec_item_returned_error AS e 
    SET
        item_id_arr = t.item_id_arr
    FROM t
    WHERE 
        e.bill_id = t.bill_id AND e.text_case_id::INTEGER = t.case_id
    ;
    --добавление ошибок к биллингу
    WITH item AS 
    (
        SELECT 
            unnest (e.item_id_arr) AS id, s.id AS source_id, coalesce (e.code_regional, e.code, '') AS code, coalesce (e.comment_regional, e.comment, '') AS error
        FROM
            fin_bill_spec_item_returned_error AS e, fin_bill_error_source AS s
        WHERE
            s.bill_id = p1_bill_id AND e.bill_id = s.bill_id AND e.code IS NOT NULL AND e.payment_status_code <> '1'
    )
    INSERT INTO fin_bill_spec_item_error (id, item_id, source_id, code, error) 
        SELECT 
            nextval ('fin_bill_spec_item_error_seq'), id, source_id, code, error 
        FROM 
            item
        WHERE 
            EXISTS (SELECT 1 FROM fin_bill_spec_item WHERE bill_id = p1_bill_id AND id = item.id)
    ;
    --обновление статуса у позиций счёта
    IF
        p2_status = 'ACCEPTED_PARTIALLY'
    THEN
        IF
            NOT EXISTS (SELECT 1 FROM fin_bill_spec_item_returned_error WHERE bill_id = p1_bill_id)
        THEN
            UPDATE fin_bill_spec_item AS i 
            SET 
                status_id = 2 
            FROM
                fin_bill_steps AS s
            WHERE 
                s.bill_id = p1_bill_id AND s.spec_item_id = i.id AND i.status_id = 1
            ;
        ELSE
            WITH t AS
            (
                SELECT DISTINCT
                    unnest (item_id_arr) AS id 
                FROM 
                    fin_bill_spec_item_returned_error
                WHERE 
                    bill_id = p1_bill_id AND payment_status_code <> '1'
            )
            UPDATE fin_bill_spec_item AS i
            SET 
                status_id = CASE WHEN t IS NOT NULL THEN 3 ELSE 2 END
            FROM 
                fin_bill_steps AS s LEFT JOIN t ON s.spec_item_id = t.id
            WHERE 
                i.bill_id = s.bill_id AND s.spec_item_id = i.id AND s.bill_id = p1_bill_id AND NOT s.spec_err_exists AND i.status_id = 1
            ;
        END IF;
    ELSIF
        p2_status = 'RETURNED'
    THEN
        UPDATE fin_bill_spec_item AS i 
        SET 
            status_id = 3
        FROM
            fin_bill_steps AS s
        WHERE 
            s.bill_id = p1_bill_id AND s.spec_item_id = i.id AND i.status_id = 1
        ;
    END IF;
    --обновление статуса ошибок в таблице биллинга
    UPDATE fin_bill_steps AS s
    SET
        spec_err_exists = EXISTS (SELECT 1 FROM fin_bill_spec_item_error WHERE item_id = s.spec_item_id)
    WHERE
        s.bill_id = p1_bill_id AND NOT s.spec_err_exists
    ;
    --обновление информации в шапке счёта
    PERFORM fin_bill_spec_update (p1_bill_id)
    ;
    --разблокировка загрузки дефектуры
    UPDATE fin_bill_spec_item_returned_error_lock SET is_locked = FALSE WHERE bill_id = p1_bill_id
    ;
END;
$$;

