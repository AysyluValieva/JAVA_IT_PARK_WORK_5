CREATE FUNCTION zeroing_number(xorg integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
 xtypeNum integer;
 xnumid integer;
 begin
 select into xtypeNum,xnumid mans.type_num,mans.id from amb.md_ambulance_numb_setting mans left join amb.md_ambulance_numbers man on mans.id = man.numb_id
 where mans.clinic_id = xorg;
 if exists (select * from amb.md_ambulance_numb_setting mans left join amb.md_ambulance_numbers man on mans.id = man.numb_id
 where mans.clinic_id = xorg)
 THEN
 if xtypeNum = 1
 then
 update amb.md_ambulance_numbers set value = 0 where numb_id = xnumid;
 end if;
 if (xtypeNum = 2) and (EXTRACT(dow FROM now()) = 1)
 then
 update amb.md_ambulance_numbers set value = 0 where numb_id = xnumid;
 end if;
 if (xtypeNum = 3) and (EXTRACT(day FROM now()) = 1)
 then
 update amb.md_ambulance_numbers set value = 0 where numb_id = xnumid;
 end if;
 if (xtypeNum = 4) and (EXTRACT(doy FROM now()) = 1)
 then
 update amb.md_ambulance_numbers set value = 0 where numb_id = xnumid;
 end if;
 END if;
 end;
$$;

