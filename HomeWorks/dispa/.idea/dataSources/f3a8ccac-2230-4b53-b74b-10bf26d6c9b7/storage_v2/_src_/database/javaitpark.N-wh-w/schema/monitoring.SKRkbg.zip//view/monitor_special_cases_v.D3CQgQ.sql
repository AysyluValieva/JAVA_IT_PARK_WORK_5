CREATE VIEW monitor_special_cases_v AS
  SELECT row_number() OVER () AS row_num,
    mc_case.id AS case_id,
    mc_case.uid AS case_num_str,
    (((((pim_individual.surname)::text || ' '::text) || (pim_individual.name)::text) || ' '::text) || (pim_individual.patr_name)::text) AS patient_full_name,
    pim_individual.birth_dt,
    date_part('year'::text, age(now(), (pim_individual.birth_dt)::timestamp with time zone)) AS age,
    pim_department.type_id AS department_type_id,
    mc_case_state.pim_department_type_id AS mc_case_state_department_type_id,
    pci_patient.social_group_id,
    md_soc_group.name AS social_group,
    mc_case.patient_id,
    pim_gender.id AS gender_id,
    pim_gender.name AS gender_name,
    monitored_cases_list.case_id AS monitor_id,
    mc_case.create_date AS enter_date,
    md_clinic.short_name AS mo_name,
    md_clinic.id AS mo_id,
        CASE
            WHEN (monitored_cases_list.case_id IS NULL) THEN false
            ELSE true
        END AS is_on_control,
    NULL::unknown AS hosp_result,
    COALESCE(hsp.f5, 0) AS f5,
        CASE
            WHEN (hsp.f5 = 1) THEN true
            ELSE false
        END AS is_hospitalized_before,
    mc_case.create_date,
    diag.m_diag_str,
    diag.m_d_ids,
    diag.diag_str,
    diag.d_ids,
    diag.doctor_ids,
    diag.stage_ids,
    diag.f1,
    diag.f2,
    doctor.doctor_full_name,
    doctor.id AS doctor_id,
    severity.severity_level_id,
    severity.name AS severity_name,
    severity.point AS f3_severity_point,
    social_factor.point AS f4_social_point,
    COALESCE(hsp.f5, 0) AS f5_hospital_point,
    ((((COALESCE(diag.f1, (0)::numeric) + COALESCE(diag.f2, (0)::numeric)) + (COALESCE(severity.point, 0))::numeric) + (COALESCE(social_factor.point, 0))::numeric) + (COALESCE(hsp.f5, 0))::numeric) AS main_factor,
    mc_step.id AS step_id
   FROM ((((((((((((((((mc_case
     JOIN mc_step ON ((mc_step.case_id = mc_case.id)))
     JOIN pci_patient ON ((mc_case.patient_id = pci_patient.id)))
     JOIN pim_individual ON ((pci_patient.id = pim_individual.id)))
     JOIN mc_case_type ON ((mc_case.case_type_id = mc_case_type.id)))
     JOIN hsp_record ON ((mc_step.id = hsp_record.id)))
     JOIN pim_department ON (((hsp_record.department_id = pim_department.id) AND (pim_department.type_id = ( SELECT DISTINCT pim_department_type.id
           FROM pim_department_type
          WHERE ((pim_department_type.code)::text = '4'::text))))))
     LEFT JOIN mc_case_state ON ((mc_case.state_id = mc_case_state.id)))
     LEFT JOIN ( SELECT diag_.case_id,
            string_agg(
                CASE
                    WHEN (diag_.is_main = true) THEN diag_.d_str
                    ELSE NULL::text
                END, ', '::text) AS m_diag_str,
            monitoring.agg_ids(
                CASE
                    WHEN (diag_.is_main = true) THEN diag_.d_ids
                    ELSE NULL::integer[]
                END) AS m_d_ids,
            string_agg(
                CASE
                    WHEN (diag_.is_main = false) THEN diag_.d_str
                    ELSE NULL::text
                END, ', '::text) AS diag_str,
            monitoring.agg_ids(
                CASE
                    WHEN (diag_.is_main = false) THEN diag_.d_ids
                    ELSE NULL::integer[]
                END) AS d_ids,
            monitoring.agg_ids(
                CASE
                    WHEN (diag_.is_main = true) THEN diag_.doctor_ids
                    ELSE NULL::integer[]
                END) AS doctor_ids,
            monitoring.agg_ids(
                CASE
                    WHEN (diag_.is_main = true) THEN diag_.stage_ids
                    ELSE NULL::integer[]
                END) AS stage_ids,
            sum(
                CASE
                    WHEN (diag_.f1 IS NULL) THEN (0)::bigint
                    ELSE diag_.f1
                END) AS f1,
            sum(
                CASE
                    WHEN (diag_.f2 IS NULL) THEN (0)::bigint
                    ELSE diag_.f2
                END) AS f2
           FROM ( SELECT mcd.case_id,
                    true AS is_main,
                    string_agg((((md_diagnosis.code)::text || ' '::text) || (md_diagnosis.name)::text), ', '::text) AS d_str,
                    array_agg(md_diagnosis.id) AS d_ids,
                    array_agg(mcd.doctor_id) AS doctor_ids,
                    array_agg(mcd.stage_id) AS stage_ids,
                    sum(criteria.point) AS f1,
                    0 AS f2
                   FROM ((mc_diagnosis mcd
                     JOIN md_diagnosis ON ((mcd.diagnos_id = md_diagnosis.id)))
                     LEFT JOIN monitoring.md_traumatology_diagnosis_criteria criteria ON (((criteria.diagnosis_id = mcd.diagnos_id) AND (criteria.type_id = 1) AND (criteria.stage_id = mcd.stage_id))))
                  WHERE ((mcd.is_main = true) AND (NOT (mcd.stage_id IS NULL)))
                  GROUP BY mcd.case_id
                UNION
                 SELECT mcd.case_id,
                    false AS is_main,
                    string_agg((((md_diagnosis.code)::text || ' '::text) || (md_diagnosis.name)::text), ', '::text) AS d_str,
                    array_agg(md_diagnosis.id) AS d_ids,
                    array_agg(mcd.doctor_id) AS doctor_ids,
                    array_agg(mcd.stage_id) AS stage_ids,
                    0 AS f1,
                    sum(criteria.point) AS f2
                   FROM ((mc_diagnosis mcd
                     JOIN md_diagnosis ON ((mcd.diagnos_id = md_diagnosis.id)))
                     LEFT JOIN monitoring.md_traumatology_diagnosis_criteria criteria ON (((criteria.diagnosis_id = mcd.diagnos_id) AND (criteria.type_id = 2))))
                  WHERE (mcd.is_main = false)
                  GROUP BY mcd.case_id) diag_
          GROUP BY diag_.case_id) diag ON ((diag.case_id = mc_case.id)))
     LEFT JOIN ( SELECT mdep.id,
            (((((pim_individual_1.surname)::text || ' '::text) || (pim_individual_1.name)::text) || ' '::text) || (pim_individual_1.patr_name)::text) AS doctor_full_name
           FROM (((md_employee_position mdep
             JOIN pim_employee_position ON ((pim_employee_position.id = mdep.id)))
             JOIN pim_employee ON ((pim_employee_position.employee_id = pim_employee.id)))
             JOIN pim_individual pim_individual_1 ON ((pim_individual_1.id = pim_employee.individual_id)))) doctor ON ((doctor.id = diag.doctor_ids[1])))
     LEFT JOIN md_clinic ON ((md_clinic.id = mc_case.clinic_id)))
     LEFT JOIN md_soc_group ON ((md_soc_group.id = mc_case.soc_group_id)))
     LEFT JOIN pim_gender ON ((pim_individual.gender_id = pim_gender.id)))
     LEFT JOIN monitoring.monitored_cases_list ON ((mc_case.id = monitored_cases_list.case_id)))
     LEFT JOIN ( SELECT mc_step_1._patient_id,
            array_agg(mc_step_1.case_id) AS case_ids,
                CASE
                    WHEN (count(hsp_record_1.*) > 0) THEN ( SELECT md_traumatology_hospitalization.point
                       FROM monitoring.md_traumatology_hospitalization
                      WHERE (md_traumatology_hospitalization.id = 2))
                    ELSE 0
                END AS f5
           FROM ((mc_step mc_step_1
             JOIN hsp_record hsp_record_1 ON ((mc_step_1.id = hsp_record_1.id)))
             JOIN mc_step_result ON ((mc_step_result.id = mc_step_1.result_id)))
          WHERE (mc_step_result.is_closed = true)
          GROUP BY mc_step_1._patient_id) hsp ON (((mc_case.patient_id = hsp._patient_id) AND (mc_case.id <> ANY (hsp.case_ids)))))
     LEFT JOIN ( SELECT slc.severity_level_id,
            slc.point,
            msl.name
           FROM (mc_severity_level msl
             LEFT JOIN monitoring.md_traumatology_severity_level_criteria slc ON ((msl.id = slc.severity_level_id)))) severity ON ((mc_case.severity_level_id = severity.severity_level_id)))
     LEFT JOIN monitoring.md_traumatology_soc_group_criteria social_factor ON ((mc_case.soc_group_id = social_factor.soc_group_id)))
  WHERE (((mc_case.create_date > (('now'::text)::date - '6 mons'::interval)) AND (mc_case_state.pim_department_type_id = pim_department.type_id)) OR ((mc_case_state.pim_department_type_id IS NULL) AND (mc_case.create_date > (('now'::text)::date - '6 mons'::interval))));

