CREATE FUNCTION formation_age_in_text(vac_id integer, vac_date date, patient_birth_dt date)
  RETURNS vac.age_view_and_sort
LANGUAGE plpgsql
AS $$
DECLARE
  _years INTEGER;
  _mes INTEGER;
  _days INTEGER;
  _value VARCHAR(1);
  _resultView TEXT;
  _resultSort TEXT;
  BEGIN
    _years = 0;
    _mes = 0;
    _days = 0;
    _value = '';
    if (patient_birth_dt is not null) THEN
      if ((vac_date - patient_birth_dt) >= 0) THEN
            _years = (select @(date_part('year', vac_date) - date_part('year', patient_birth_dt) - (case
                                                                                                   to_char(vac_date, 'MMDD') < to_char(patient_birth_dt, 'MMDD')
                                                                                                   WHEN TRUE THEN 1 ELSE 0 END)));
            _mes = (select case
                           when
                             date_part('month', vac_date) - date_part('month',patient_birth_dt)- (case to_char(vac_date, 'DD') < to_char(patient_birth_dt, 'DD') WHEN TRUE THEN 1 ELSE 0 END) < 0
                             THEN
                               12 + cast(date_part('month', vac_date) - date_part('month',patient_birth_dt) as integer)
                           else
                             date_part('month', vac_date) - date_part('month',patient_birth_dt)
                             -(case to_char(vac_date, 'DD') < to_char(patient_birth_dt, 'DD') WHEN TRUE THEN 1 ELSE 0 END)
                           end);
            _days = (select CASE
                            WHEN (date_part('day', vac_date) - date_part('day',patient_birth_dt)) < 0
                              THEN date_part('day', vac_date) + (DATE_PART('days', DATE_TRUNC('month', patient_birth_dt) + '1 MONTH'::INTERVAL - '1 DAY'::INTERVAL) - date_part('day',patient_birth_dt))
                            ELSE date_part('day', vac_date) - date_part('day',patient_birth_dt)
                            END);
        ELSE
            _days = @(vac_date - patient_birth_dt);
            _value = '-';
      END IF;

      if (_mes = 12) then _years= _years + 1; _mes = 0; end if;
    END IF;

      _resultView = (select (case
                          when _years != 0 then concat(
                                                        _years,
                                                        case
                                                             when(right(_years::VARCHAR,1) in ('1','2','3','4') and right(_years::VARCHAR,2) not in ('11','12','13','14'))
                                                              then 'л ' else 'г '
                                                        end,
                                                        _mes, 'м ', _days,'д')
                          else (case
                                when (_years = 0 and _mes != 0)
                                  then concat(_mes, 'м ', _days,'д')
                                else concat(_value,_days,'д') end)
                            end));

      _resultSort = (
          select concat(_value,_years,'-',_mes,' ',_value,_days,'D',case when (_mes != 0 and _days =0) then ' 1M' end)
        );

    return (vac_id,_resultView,_resultSort)::vac.age_view_and_sort;
  END;
$$;

