CREATE FUNCTION orphanschangeagreestatusallserviceforpatient(xagreedate character varying, xepid integer, xstatus integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
          i integer;
          q_seq integer;
          pci integer;
          mviews record;
          rstatus integer;
          xagree boolean;
          xdenial boolean;
        begin
          IF xstatus = 1 THEN
            xagree = TRUE;
            xdenial = FALSE;
          ELSE
            xagree = FALSE;
            xdenial = TRUE;
          END IF;
          FOR mviews IN (select mesp.id as id, mespa.id as aid
                            from disp.md_event_patient mep
                            inner join disp.md_event_service_patient mesp on mep.id = mesp.event_patient_id
                            left join disp.md_event_service_patient_agreement mespa on mespa.service_id = mesp.id
                            where mep.id = xepid) LOOP
              -- change status
              IF (select count(ssr.id)
                    from disp.md_event_patient mep
                    left join MD_SRV_RENDERED msr on msr.case_id = mep.case_id
                    inner join SR_SRV_RENDERED ssr on ssr.id = msr.id and ssr.service_id = (SELECT mes.service_id FROM disp.md_event_service_patient mesp
                                                                                            left join disp.md_event_service mes on mes.id = mesp.service_id
                                                                                            where mesp.id = mviews.id)
                    where mep.id = xepid) > 0 THEN
                rstatus = 4;
              ELSE
                rstatus = 1;
              END IF;
              update disp.md_event_service_patient set status = rstatus
                  where id = mviews.id;
              -- set agreement
              IF (select count(id) from disp.md_event_service_patient_agreement where service_id = mviews.id) = 0 THEN
                i = nextval('disp.md_event_service_patient_agreement_id_seq');
                insert into disp.md_event_service_patient_agreement (id, service_id, agree, denial, agree_date)
                  values (i, mviews.id, xagree, xdenial, to_date(xagreeDate, 'DD.MM.YYYY'));
              ELSE
                update disp.md_event_service_patient_agreement set service_id=mviews.id, agree=xagree, denial=xdenial,
                  agree_date=to_date(xagreeDate, 'DD.MM.YYYY')
                where id=mviews.aid;
              END IF;
          END LOOP;
          return 1;
        end;
$$;

