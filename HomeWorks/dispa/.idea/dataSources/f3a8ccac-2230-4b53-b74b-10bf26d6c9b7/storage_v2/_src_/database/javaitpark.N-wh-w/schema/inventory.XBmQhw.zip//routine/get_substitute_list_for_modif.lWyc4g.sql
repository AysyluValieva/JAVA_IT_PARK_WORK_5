CREATE FUNCTION get_substitute_list_for_modif(modifid integer, orgid integer, innid integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
DECLARE
 modif record;
 substitute record;
 conv_rate_1 numeric;
 sub_count numeric;

BEGIN
SELECT * from inventory.hold_modif into modif where id= modifId;
FOR substitute IN (select * from inventory.create_substitute_base_list_for_modif(modifId, modif.holding_id, modif.form_type_id, orgId, innId,modif.mnei_id))
LOOP
      sub_count = (select coalesce(mnei_count_in_sec_pk,1) from inventory.hold_modif where id = substitute.id);
      conv_rate_1=sub_count/coalesce (modif.mnei_count_in_sec_pk,1);
      perform inventory.insert_substitute_list_for_modif(modifId,substitute.id,modif.mnei_id, conv_rate_1);
END LOOP;

return modifId;
END;
$$;

