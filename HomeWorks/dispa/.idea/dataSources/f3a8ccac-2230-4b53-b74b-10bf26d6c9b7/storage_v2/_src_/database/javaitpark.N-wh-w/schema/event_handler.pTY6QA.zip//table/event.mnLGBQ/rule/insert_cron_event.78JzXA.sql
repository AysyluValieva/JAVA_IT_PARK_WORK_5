CREATE RULE insert_cron_event AS
    ON INSERT TO event_handler.event
   WHERE (new.period IS NOT NULL) DO  SELECT pg_notify('cron_event'::text, format('{"action":"ADD", "event":{"cron":"%s", "event":"%s"}}'::text, new.period, new.id)) AS pg_notify;

