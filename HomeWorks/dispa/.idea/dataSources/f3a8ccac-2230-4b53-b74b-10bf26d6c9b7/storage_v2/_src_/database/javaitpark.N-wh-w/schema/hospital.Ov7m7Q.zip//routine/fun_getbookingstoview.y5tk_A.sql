CREATE FUNCTION fun_getbookingstoview(patiend_id integer, department_id integer, admission_date date, end_date date, is_current_dep boolean DEFAULT true, OUT id integer, OUT step_id integer, OUT reservation_id integer, OUT bed_id integer, OUT status_date date, OUT status_id integer, OUT begin_dt date, OUT end_dt date, OUT iscurrent boolean)
  RETURNS SETOF record
LANGUAGE SQL
AS $$
with bo as (
    SELECT bo.*, daterange(bo.begin_dt, bo.end_dt, '[]') as date_range, bs.code as bs_code
    FROM hospital.booking bo
        JOIN hospital.booking_status bs ON bo.status_id = bs.id
    WHERE bs.code IN ('2', '3')
          and daterange(bo.begin_dt, bo.end_dt, '[]') && daterange($3::date, $4::date, '[]')
          and bo.iscurrent = TRUE
    )
    select
        hb.id AS id,
        hb.step_id AS step_id,
        hb.reservation_id AS reservation_id,
        hb.bed_id AS bed_id,
        hb.status_date AS status_date,
        hb.status_id AS status_id,
        hb.begin_dt AS begin_dt,
        hb.end_dt AS end_dt,
        hb.iscurrent AS iscurrent
    from bo hb
        join md_bed mb on hb.bed_id = mb.id
        join pim_room r on mb.room_id = r.id
        join pim_department d on r.department_id = d.id
        join md_bed_resource mbr on mbr.bed_id = mb.id
        join md_bed_profile mbp on mb.bed_profile_id = mbp.id
        join lateral (
             select hr.* from hsp_reservation hr where $5 = true and hb.reservation_id = hr.id and hr.department_id = coalesce(nullif($2, -1), hr.department_id) and $2 is not null
             union all
             select hr.* from hsp_reservation hr where $5 = false and hb.reservation_id = hr.id and hr.department_id <> coalesce($2, -1)
             ) hr on true
        join md_referral mr on hr.referral_id = mr.id
    where
        mr.patient_id = coalesce(nullif($1, -1), mr.patient_id) and $1 is not null
    UNION ALL
    select -- добавляем брони которые входят в заявки найденные в 1й итерации, но по интервалам выходят за рамки указанного периода
        hb.id AS id,
        hb.step_id AS step_id,
        hb.reservation_id AS reservation_id,
        hb.bed_id AS bed_id,
        hb.status_date AS status_date,
        hb.status_id AS status_id,
        hb.begin_dt AS begin_dt,
        hb.end_dt AS end_dt,
        hb.iscurrent AS iscurrent
    from bo
        join lateral (
             select hb.* from hospital.booking hb where bo.reservation_id = hb.reservation_id and daterange(hb.begin_dt, hb.end_dt, '[]') << bo.date_range
             union all
             select hb.* from hospital.booking hb where bo.reservation_id = hb.reservation_id and daterange(hb.begin_dt, hb.end_dt, '[]') >> bo.date_range
             ) hb on true
        JOIN hospital.booking_status hbs ON hb.status_id = hbs.id and hbs.code IN ('2', '3')
        join md_bed mb on hb.bed_id = mb.id
        join pim_room r on mb.room_id = r.id
        join pim_department d on r.department_id = d.id
        join md_bed_resource mbr on mbr.bed_id = mb.id
        join md_bed_profile mbp on mb.bed_profile_id = mbp.id
        join lateral (
             select hr.* from hsp_reservation hr where $5 = true and hb.reservation_id = hr.id and hr.department_id = coalesce(nullif($2, -1), hr.department_id) and $2 is not null
             union all
             select hr.* from hsp_reservation hr where $5 = false and hb.reservation_id = hr.id and hr.department_id <> coalesce($2, -1)
             ) hr on true
        join md_referral mr on hr.referral_id = mr.id
    where
        mr.patient_id = coalesce(nullif($1, -1), mr.patient_id) and $1 is not null
    order by begin_dt ASC
$$;

