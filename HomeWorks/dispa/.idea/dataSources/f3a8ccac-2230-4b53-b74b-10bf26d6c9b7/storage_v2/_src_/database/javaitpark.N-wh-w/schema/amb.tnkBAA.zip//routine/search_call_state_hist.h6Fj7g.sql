CREATE FUNCTION search_call_state_hist(xcall integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
    xtime timestamp;
    cs record;
    xstate integer;
    xid integer;
  begin
    select into xtime from_time from amb.md_ambulance_call where id = xcall;
    xstate = 1;
    select into xid id from amb.md_ambcall_state_history where call_id = xcall and state_id = xstate;
    for cs in
    	select id,date_time,state_id from amb.md_ambcall_state_history where call_id = xcall
    loop
    	-- возможно нужно добавить равенство id состояний (пока не делала)
        if (cs.date_time >= xtime) and (cs.state_id > xstate)
        THEN
        	xtime = cs.date_time;
            xstate = cs.state_id;
            xid = cs.id;
        ELSE
        	if (cs.date_time >= xtime) and (cs.state_id = 5) and (xstate = 15)
            	then
                	xtime = cs.date_time;
            		xstate = cs.state_id;
            		xid = cs.id;
            end if;
        end if;
    end loop;
    return xid;
  end;
$$;

