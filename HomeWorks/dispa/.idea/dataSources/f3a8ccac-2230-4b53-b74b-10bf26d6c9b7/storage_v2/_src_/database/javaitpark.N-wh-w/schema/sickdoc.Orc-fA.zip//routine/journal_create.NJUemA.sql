CREATE FUNCTION journal_create(p_clinic_id integer, p_name character varying, p_begin_dt date, p_end_dt date, p_resp_id integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
DECLARE
  l_common_journal_id INTEGER;
  l_id INTEGER;
BEGIN
  IF exists(SELECT 1
            FROM sickdoc.journal j
            WHERE j.name = p_name AND j.clinic_id = p_clinic_id)
  THEN
    RAISE 'Журнал с наименованием % уже существует в МО. Введите уникальное наименование', p_name;
  END IF;


  INSERT
  INTO sickdoc.journal (
    id, clinic_id, name, begin_dt, end_dt, responsible_id)
  VALUES (
    DEFAULT, p_clinic_id, p_name, p_begin_dt, p_end_dt, p_resp_id)
  RETURNING id
    INTO l_id;
  RETURN l_id;
END;
$$;

