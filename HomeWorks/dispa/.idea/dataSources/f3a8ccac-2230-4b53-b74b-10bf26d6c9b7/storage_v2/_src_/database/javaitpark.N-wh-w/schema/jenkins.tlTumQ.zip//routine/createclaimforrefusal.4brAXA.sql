CREATE FUNCTION createclaimforrefusal(_department_id character varying, _idpdat character varying, _idappointment character varying)
  RETURNS TABLE(success boolean)
LANGUAGE plpgsql
AS $$
BEGIN
 

return query ( select * from "jenkins"."createclaimforrefusal_v3"( "_department_id" ,  "_idpdat" ,  "_idappointment" ) );

 
 
END;
$$;

