CREATE FUNCTION setrequiredservice(xcheckservices character varying, xeid integer)
  RETURNS text
LANGUAGE plpgsql
AS $$
declare
        serviceRequired integer [];
        servicePatient integer [];
        service integer;
        contains boolean ;
        checkserviceId json;
        result  text ;
        begin
        serviceRequired:=(array (select id  from disp.md_event_service where event_id=xeid and required=true));


        foreach checkserviceId in array array(select value from json_array_elements(cast(xcheckservices as json)))
                LOOP
                 servicePatient:=array_append(servicePatient,checkserviceId::text::int);
                END LOOP;


        if (serviceRequired is not null) then
            foreach service in array serviceRequired
            loop

            if (SELECT service = ANY(servicePatient))=false then
            if result is null then
            result=(select ss.name from sr_service ss
            left join disp.md_event_service mes on mes.service_id=ss.id where mes.id=service limit 1);
            else
            result=result || ', '||(select ss.name from sr_service ss left join disp.md_event_service mes on mes.service_id=ss.id where mes.id=service limit 1);
            end if;

            end if;
            end loop;
        end if;
if (result is null) then return 'true'; end if;

          return result;
        end;
$$;

