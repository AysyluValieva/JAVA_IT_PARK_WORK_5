CREATE FUNCTION select_pim_room_children_list(integer)
  RETURNS SETOF integer
LANGUAGE SQL
AS $$
WITH RECURSIVE included_rooms(id) AS (
                SELECT id FROM pim_room WHERE parent_room_id = $1
                    UNION
                SELECT pr.id
                FROM included_rooms ir, pim_room pr
                WHERE pr.parent_room_id = ir.id
            )
            SELECT id FROM included_rooms;
$$;

