CREATE FUNCTION employee_position_displayname(p_employee_position_id integer)
  RETURNS text
IMMUTABLE
LANGUAGE plpgsql
AS $$
BEGIN
    RETURN
    (SELECT concat(i.surname, ' ' || left(i.name, 1) || '.', ' ' || left(i.patr_name, 1) || '.', ', ' || pp.name)
     FROM pim_employee_position ep
       JOIN pim_position pp ON pp.id = ep.position_id
       JOIN pim_employee e ON e.id = ep.employee_id
       JOIN pim_individual i ON i.id = e.individual_id
     WHERE ep.id = $1);
  END;
$$;

