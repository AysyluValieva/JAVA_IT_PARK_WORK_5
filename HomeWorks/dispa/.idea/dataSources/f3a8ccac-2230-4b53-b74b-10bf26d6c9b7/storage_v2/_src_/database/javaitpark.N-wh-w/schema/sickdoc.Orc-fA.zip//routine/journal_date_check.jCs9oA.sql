CREATE FUNCTION journal_date_check(p_id integer, p_start_date date, p_end_date date)
  RETURNS boolean
LANGUAGE plpgsql
AS $$
DECLARE
  l_sickdoc_min_date DATE;
  l_sickdoc_max_date DATE;
BEGIN

  SELECT MIN(begin_dt), MAX(end_dt) INTO l_sickdoc_min_date, l_sickdoc_max_date FROM sickdoc.sickdoc WHERE journal_id = p_id;
  IF (p_start_date>l_sickdoc_min_date OR l_sickdoc_max_date>p_end_date) THEN RETURN false; END IF;
  RETURN TRUE;

END;
$$;

