CREATE FUNCTION check_interval_diagnosis(xchildid integer, xparentid integer)
  RETURNS boolean
LANGUAGE plpgsql
AS $$
DECLARE
result BOOLEAN;
BEGIN
    with recursive t as (select id, parent_id, parent_id = xParentId flag
                     from md_diagnosis
                     where id = xChildId

                     union all

                     select n.id, n.parent_id, n.parent_id = xParentId
                     from md_diagnosis n
                     join t on n.id = t.parent_id
                     where n.id = t.parent_id)

    SELECT exists (select 1 from t where flag)
    INTO result;

    RETURN result;
END
$$;

