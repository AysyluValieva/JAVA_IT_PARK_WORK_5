CREATE FUNCTION save_gestationage(xid integer, xjson text)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
   _rec record;
  begin
   DROP TABLE IF EXISTS cte;
    CREATE TEMP TABLE cte as(select * from json_to_recordset((xjson)::JSON) as x(id INTEGER, value INTEGER));
    for _rec in (select id, value from cte)
      loop
      if (_rec.id is null)
        then
          insert into motherhood.mh_prototype_pregnant_age (value, prototype_id) values (_rec.value, xid);
        ELSE
          WITH delDubl AS (
            select id  FROM motherhood.mh_prototype_pregnant_age where prototype_id = xid
            EXCEPT
            select id from cte where value != 0
          )
          delete from motherhood.mh_prototype_pregnant_age where id in (select id from delDubl);
          update motherhood.mh_prototype_pregnant_age set value = _rec.value where id = _rec.id;
      END IF;
    END LOOP;
    return xid;
  end;
$$;

