CREATE FUNCTION set_open_time_in_case(caseid integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
begin
   update mc_case set open_time = (select min(admission_date + coalesce(admission_time, time '00:00')) from mc_step where mc_step.case_id = caseID) where mc_case.id = caseID;
end;
$$;

