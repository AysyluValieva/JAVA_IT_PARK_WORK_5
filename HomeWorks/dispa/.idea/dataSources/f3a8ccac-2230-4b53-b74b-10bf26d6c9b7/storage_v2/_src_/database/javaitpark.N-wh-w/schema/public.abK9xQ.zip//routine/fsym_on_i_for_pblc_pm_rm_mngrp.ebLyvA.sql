CREATE FUNCTION fsym_on_i_for_pblc_pm_rm_mngrp()
  RETURNS trigger
LANGUAGE plpgsql
AS $fun$
begin                                                                                                                                                                  
                                   
                                  if 1=1 and "public".sym_triggers_disabled() = 0 then                                                                                                 
                                    insert into "public".sym_data                                                                                                                     
                                    (table_name, event_type, trigger_hist_id, row_data, channel_id, transaction_id, source_node_id, external_data, create_time)                                        
                                    values(                                                                                                                                                            
                                      'pim_room',                                                                                                                                            
                                      'I',                                                                                                                                                             
                                      63,                                                                                                                                             
                                      
          case when new."id" is null then '' else '"' || cast(cast(new."id" as numeric) as varchar) || '"' end||','||
          case when new."code" is null then '' else '"' || replace(replace(cast(new."code" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."floor_area" is null then '' else '"' || cast(cast(new."floor_area" as numeric) as varchar) || '"' end||','||
          case when new."name" is null then '' else '"' || replace(replace(cast(new."name" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."building_id" is null then '' else '"' || cast(cast(new."building_id" as numeric) as varchar) || '"' end||','||
          case when new."department_id" is null then '' else '"' || cast(cast(new."department_id" as numeric) as varchar) || '"' end||','||
          case when new."floor_id" is null then '' else '"' || cast(cast(new."floor_id" as numeric) as varchar) || '"' end||','||
          case when new."parent_room_id" is null then '' else '"' || cast(cast(new."parent_room_id" as numeric) as varchar) || '"' end||','||
          case when new."type_id" is null then '' else '"' || cast(cast(new."type_id" as numeric) as varchar) || '"' end||','||
          case when new."cell_count" is null then '' else '"' || cast(cast(new."cell_count" as numeric) as varchar) || '"' end||','||
          case when new."cell_count_extra" is null then '' else '"' || cast(cast(new."cell_count_extra" as numeric) as varchar) || '"' end||','||
          case when new."comfort_level_id" is null then '' else '"' || cast(cast(new."comfort_level_id" as numeric) as varchar) || '"' end||','||
          case when new."post_id" is null then '' else '"' || cast(cast(new."post_id" as numeric) as varchar) || '"' end||','||
          case when new."regimen_id" is null then '' else '"' || cast(cast(new."regimen_id" as numeric) as varchar) || '"' end||','||
          case when new."unit_id" is null then '' else '"' || cast(cast(new."unit_id" as numeric) as varchar) || '"' end||','||
          case when new."gender_id" is null then '' else '"' || cast(cast(new."gender_id" as numeric) as varchar) || '"' end||','||
          case when new."from_dt" is null then '' else '"' || to_char(new."from_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when new."to_dt" is null then '' else '"' || to_char(new."to_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when new."age_group_id" is null then '' else '"' || cast(cast(new."age_group_id" as numeric) as varchar) || '"' end,                                                                                                                                                      
                                      'public_pim_room_default',                                                                                                                                                
                                      txid_current(),                                                                                                                                               
                                      "public".sym_node_disabled(),                                                                                                                   
                                      null,                                                                                                                                               
                                      CURRENT_TIMESTAMP                                                                                                                
                                    );                                                                                                                                                                 
                                  end if;                                                                                                                                                              
                                                                                                                                                                               
                                  return null;                                                                                                                                                         
                                end;
$fun$;

