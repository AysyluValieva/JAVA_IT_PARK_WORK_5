CREATE FUNCTION get_individual_surname_index(patient_id integer)
  RETURNS character varying
IMMUTABLE
STRICT
LANGUAGE SQL
AS $$
select surname from pim_individual where id = $1;
$$;

