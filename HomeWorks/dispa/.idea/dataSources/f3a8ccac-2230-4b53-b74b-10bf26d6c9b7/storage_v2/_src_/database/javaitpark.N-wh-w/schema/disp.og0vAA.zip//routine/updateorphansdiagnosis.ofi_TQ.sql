CREATE FUNCTION updateorphansdiagnosis(xpatientid integer, xcaseid integer, xdiagnosiid integer, xdiseasetypeid integer, xtypeid integer, xdate character varying, xsuspicion boolean, xresult_id integer, xextra_cons_assigned_type integer, xextra_cons_assigned_org integer, xextra_cons_performed_type integer, xextra_cons_performed_org integer, xtherapy_assigned_type integer, xtherapy_assigned_org integer, xtherapy_performed_type integer, xtherapy_performed_org integer, xrehabilitation_assigned_type integer, xrehabilitation_assigned_org integer, xrehabilitation_performed_type integer, xrehabilitation_performed_org integer, xtherapy_amb_fail integer, xtherapy_hos_fail integer, xrehabilitation_amb_fail integer, xrehabilitation_hos_fail integer, xrecommended_vmp integer, xrecommendation character varying, xis_d boolean, xis_before_d boolean, xid integer, xmake_d boolean, xregistr_id integer, xextra_cons_performed_volume integer, xrecommended character varying)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
    i integer;
    recommendedid json;
  begin
    i = NULL;
    IF (select count(id) from disp.md_disp_orphans_diagnosis_extended where id = xid) = 0 THEN
      insert into MC_DIAGNOSIS (id, case_id, patient_id, establishment_date, diagnos_id, disease_type_id, type_id, is_suspicion, is_main, stage_id)
                        values (nextval('mc_diagnosis_seq'), CAST(xcaseId as int), CAST(xpatientId as int), COALESCE(to_date(xdate, 'DD.MM.YYYY'), current_date), xdiagnosIid,
                  xdiseaseTypeId, xtypeId, xsuspicion, CASE xtypeId WHEN 1 THEN TRUE ELSE FALSE END, 3);
      IF xmake_d = TRUE THEN
        i = nextval('pci_dispensary_seq');
        insert into pci_dispensary (id, diagnosis_id, reg_in_dt, clinic_id, reg_in_doctor_id, reg_stage_id, patient_id, nosol_registr_id)
          values (i, xdiagnosIid, COALESCE(to_date(xdate, 'DD.MM.YYYY'), current_date),
          (select clinic_id from mc_case where id = xcaseId),
          (select pes.id from mc_case mc
          left join mc_step ms on ms.id = mc.closing_step_id
          left join SR_RES_GROUP srg on srg.id = ms.res_group_id
          left join PIM_EMPLOYEE_POSITION pes on pes.id = srg.responsible_id
          where mc.id = xcaseId), 1, CAST(xpatientId as int), xregistr_id);
      END IF;
      insert into disp.md_disp_orphans_diagnosis_extended (id, result_id, extra_cons_assigned_type,
          extra_cons_assigned_org, extra_cons_performed_type, extra_cons_performed_org, extra_cons_performed_volume,
          therapy_assigned_type, therapy_assigned_org, therapy_performed_type, therapy_performed_org,
          rehabilitation_assigned_type, rehabilitation_assigned_org, rehabilitation_performed_type,
          rehabilitation_performed_org, therapy_amb_fail, therapy_hos_fail, rehabilitation_amb_fail,
          rehabilitation_hos_fail, recommended_vmp, recommendation, is_d, is_before_d, pci_dispensary_id)
      values (currval('mc_diagnosis_seq'), xresult_id, xextra_cons_assigned_type, xextra_cons_assigned_org,
              xextra_cons_performed_type, xextra_cons_performed_org, xextra_cons_performed_volume, xtherapy_assigned_type, xtherapy_assigned_org,
              xtherapy_performed_type, xtherapy_performed_org, xrehabilitation_assigned_type, xrehabilitation_assigned_org,
              xrehabilitation_performed_type, xrehabilitation_performed_org, xtherapy_amb_fail, xtherapy_hos_fail,
              xrehabilitation_amb_fail, xrehabilitation_hos_fail, xrecommended_vmp, xrecommendation, xis_d, xis_before_d, i);
	  xid = currval('mc_diagnosis_seq');
    ELSE
      update MC_DIAGNOSIS set diagnos_id=xdiagnosIid, disease_type_id=xdiseaseTypeId, type_id=xtypeId,
          establishment_date=COALESCE(to_date(xdate, 'DD.MM.YYYY'), current_date), is_suspicion=xsuspicion
          where id=xid;
      IF xmake_d = TRUE THEN
        IF (select pci_dispensary_id from disp.md_disp_orphans_diagnosis_extended where id = xid) IS NULL THEN
          i = nextval('pci_dispensary_seq');
          insert into pci_dispensary (id, diagnosis_id, reg_in_dt, clinic_id, reg_in_doctor_id, reg_stage_id, patient_id, nosol_registr_id)
            values (i, xdiagnosIid, COALESCE(to_date(xdate, 'DD.MM.YYYY'), current_date),
            (select clinic_id from mc_case where id = xcaseId),
            (select pes.id from mc_case mc
            left join mc_step ms on ms.id = mc.closing_step_id
            left join SR_RES_GROUP srg on srg.id = ms.res_group_id
            left join PIM_EMPLOYEE_POSITION pes on pes.id = srg.responsible_id
            where mc.id = xcaseId), 1, CAST(xpatientId as int), xregistr_id);
        END IF;
      ELSE
        i = NULL;
        DELETE FROM pci_dispensary where id = (select pci_dispensary_id from disp.md_disp_orphans_diagnosis_extended where id = xid);
      END IF;
      if (select exists(select 1 from disp.md_disp_orphans_diagnosis_extended where id = xid and result_id = xresult_id)) then
      update disp.md_disp_orphans_diagnosis_extended set extra_cons_assigned_type = xextra_cons_assigned_type,
          extra_cons_assigned_org = xextra_cons_assigned_org, extra_cons_performed_type = xextra_cons_performed_type,
          extra_cons_performed_org = xextra_cons_performed_org, extra_cons_performed_volume = xextra_cons_performed_volume, therapy_assigned_type = xtherapy_assigned_type,
          therapy_assigned_org = xtherapy_assigned_org, therapy_performed_type = xtherapy_performed_type,
          therapy_performed_org = xtherapy_performed_org, rehabilitation_assigned_type = xrehabilitation_assigned_type,
          rehabilitation_assigned_org = xrehabilitation_assigned_org,
          rehabilitation_performed_type = xrehabilitation_performed_type,
          rehabilitation_performed_org = xrehabilitation_performed_org, therapy_amb_fail = xtherapy_amb_fail,
          therapy_hos_fail = xtherapy_hos_fail, rehabilitation_amb_fail = xrehabilitation_amb_fail,
          rehabilitation_hos_fail = xrehabilitation_hos_fail, recommended_vmp = xrecommended_vmp,
          recommendation = xrecommendation, is_d = xis_d, is_before_d = xis_before_d, pci_dispensary_id = i
      where id = xid;
      else
      update disp.md_disp_orphans_diagnosis_extended_copied set extra_cons_assigned_type = xextra_cons_assigned_type,
          extra_cons_assigned_org = xextra_cons_assigned_org, extra_cons_performed_type = xextra_cons_performed_type,
          extra_cons_performed_org = xextra_cons_performed_org, therapy_assigned_type = xtherapy_assigned_type,
          therapy_assigned_org = xtherapy_assigned_org, therapy_performed_type = xtherapy_performed_type,
          therapy_performed_org = xtherapy_performed_org, rehabilitation_assigned_type = xrehabilitation_assigned_type,
          rehabilitation_assigned_org = xrehabilitation_assigned_org,
          rehabilitation_performed_type = xrehabilitation_performed_type,
          rehabilitation_performed_org = xrehabilitation_performed_org, therapy_amb_fail = xtherapy_amb_fail,
          therapy_hos_fail = xtherapy_hos_fail, rehabilitation_amb_fail = xrehabilitation_amb_fail,
          rehabilitation_hos_fail = xrehabilitation_hos_fail, recommended_vmp = xrecommended_vmp,
          recommendation = xrecommendation, is_d = xis_d, is_before_d = xis_before_d, pci_dispensary_id = i
      where id = xid;
      end if;
    END IF;
    delete from disp.md_disp_orphans_diagnosis_extended_recommended where diagnosis_extended_id = xid;
    foreach recommendedid in array array(select value from json_array_elements(cast(xrecommended as json)))
    LOOP
      insert into disp.md_disp_orphans_diagnosis_extended_recommended(diagnosis_extended_id, recommended_id) values (xid, recommendedid::text::int);
    END LOOP;
    return i;
    end;
$$;

