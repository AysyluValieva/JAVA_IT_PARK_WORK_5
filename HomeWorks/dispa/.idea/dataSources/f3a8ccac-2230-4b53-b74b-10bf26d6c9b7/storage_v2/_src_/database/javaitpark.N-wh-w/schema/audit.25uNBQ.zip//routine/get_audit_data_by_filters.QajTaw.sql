CREATE FUNCTION get_audit_data_by_filters(_table_setting_id integer, _aud_record_id character varying, _record_id character varying, _sec_user_login character varying, _periods character varying, _offset integer, _limit integer, _order character varying)
  RETURNS TABLE(aud_rec character varying, record_id text, aud_who character varying, aud_when timestamp without time zone, type text, delta text, aud_source character varying)
LANGUAGE plpgsql
AS $$
DECLARE
                  setting_record        RECORD;
                  select_id_query       VARCHAR;
                  base_query            VARCHAR;
                BEGIN
                  IF _aud_record_id NOTNULL
                  THEN
                    SELECT *
                    INTO setting_record
                    FROM audit.table_setting t
                    WHERE concat('audit.', table_schema, '$', table_name) = split_part(_aud_record_id, ':', 1);
                  ELSE
                    SELECT *
                    INTO setting_record
                    FROM audit.table_setting t
                    WHERE t.id = _table_setting_id;
                  END IF;

                  SELECT concat('concat(', string_agg(c1, ', '';'', '), ')')
                  INTO select_id_query
                  FROM (
                         SELECT concat('''', column_name, ': '', ', column_name) AS c1
                         FROM information_schema.columns
                         WHERE table_schema = 'audit' AND
                               table_name = concat(setting_record.table_schema, '$', setting_record.table_name) AND
                               column_name NOT IN ('aud_rec', 'type', 'delta', 'aud_when', 'aud_who', 'aud_source')) t;

                  IF _aud_record_id NOTNULL
                  THEN
                    RETURN QUERY EXECUTE
                      'SELECT $1, ' || select_id_query || '::TEXT, a.aud_who, a.aud_when, a.type, a.delta::TEXT, a.aud_source ' ||
                      'FROM ' || split_part(_aud_record_id, ':', 1) || ' a '
                      'WHERE a.aud_rec = ' || split_part(_aud_record_id, ':', 2)
                    USING _aud_record_id;
                  ELSE
                    base_query = audit.get_audit_data_by_filters_query(
                        _table_setting_id, _aud_record_id, _record_id, _sec_user_login, _periods);

                    base_query =
                      concat(
                        replace(
                          base_query, ':select',
                          'concat(''' || concat('audit.', setting_record.table_schema, '$', setting_record.table_name, ':') ||
                            ''', a.aud_rec)::VARCHAR, ' ||
                          select_id_query || ', a.aud_who, a.aud_when, a.type, a.delta::TEXT, a.aud_source '),
                        'ORDER BY a.aud_rec DESC LIMIT ', _limit, ' OFFSET ', _offset);

                    RETURN QUERY EXECUTE base_query;
                  END IF;
                END;
$$;

