CREATE FUNCTION save_birth_certificate(xid integer, xpregrantcartid integer, xseries text, xnumber text, xissuedate date, xclinicid integer, xemployeeid integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
  rid INTEGER;
begin

  IF (xid is null)
    THEN
      select nextval('motherhood.mh_birth_certificate_id_seq') into rid;

      insert into motherhood.mh_birth_certificate(id, series, number, pregnant_map_id, issue_dt, clinic_id, employee_id)
      values (rid, xseries, xnumber, xpregrantCartId, xissueDate, xclinicId,xemployeeId);

    ELSE
      update motherhood.mh_birth_certificate set
        series = xseries,
        number = xnumber,
        issue_dt = xissueDate,
        clinic_id = xclinicId,
        employee_id = xemployeeId
      where id = xid;

      rid = xid;
  END IF;
  return rid;
end;
$$;

