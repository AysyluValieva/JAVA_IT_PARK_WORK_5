CREATE FUNCTION updateorphanspatientcard_validation(xid integer)
  RETURNS character varying
LANGUAGE plpgsql
AS $$
declare
    fio character varying;
    oms character varying;
    oms_issuer character varying;
    birth_doc character varying;
    passport character varying;
    result character varying;
    birthday date;
    gender integer;
  begin
    select CONCAT(i.surname,' ',i.name,' ',i.patr_name) into fio from pim_individual i where id = xid;
    select i.birth_dt into birthday from pim_individual i where id = xid;
    select i.gender_id into gender from pim_individual i where id = xid;
    select coalesce((select concat_ws(' ', pid.series, pid.number)
                from pim_individual_doc pid
                join pim_doc_type pdt on pdt.id = pid.type_id
                where pdt.code = 'MHI_UNIFORM'
                and pid.is_active = true
                and ((pid.issue_dt is null or pid.issue_dt <= current_date) and (pid.expire_dt is null or pid.expire_dt >= current_date))
                and pid.indiv_id = xid
                limit 1),
                (select concat_ws(' ', pid.series, pid.number)
                from pim_individual_doc pid
                join pim_doc_type pdt on pdt.id = pid.type_id
                where pdt.code = 'MHI_OLDER'
                and pid.is_active = true
                and ((pid.issue_dt is null or pid.issue_dt <= current_date) and (pid.expire_dt is null or pid.expire_dt >= current_date))
                and pid.indiv_id = xid
                limit 1)) into oms;
    select coalesce((select coalesce((select short_name from pim_organization where id = pid.issuer_id), pid.issuer_text)
                from pim_individual_doc pid
                join pim_doc_type pdt on pdt.id = pid.type_id
                where pdt.code = 'MHI_UNIFORM'
                and pid.is_active = true
                and ((pid.issue_dt is null or pid.issue_dt <= current_date) and (pid.expire_dt is null or pid.expire_dt >= current_date))
                and pid.indiv_id = xid
                limit 1),
                (select coalesce((select short_name from pim_organization where id = pid.issuer_id), pid.issuer_text)
                from pim_individual_doc pid
                join pim_doc_type pdt on pdt.id = pid.type_id
                where pdt.code = 'MHI_OLDER'
                and pid.is_active = true
                and ((pid.issue_dt is null or pid.issue_dt <= current_date) and (pid.expire_dt is null or pid.expire_dt >= current_date))
                and pid.indiv_id = xid
                limit 1)) into oms_issuer;
    select (select pid.series || ' ' || pid.number
                from pim_individual_doc pid
                join pim_doc_type pdt on pdt.id = pid.type_id
                where pdt.code = 'BIRTH'
                and pid.is_active = true
                and pid.indiv_id = xid
                limit 1) into birth_doc;
    select (select pid.series || ' ' || pid.number
                from pim_individual_doc pid
                join pim_doc_type pdt on pdt.id = pid.type_id
                where pdt.code = 'PASSPORT_RUSSIAN_FEDERATION'
                and pid.is_active = true
                and pid.indiv_id = xid
                limit 1) into passport;
    result = null;
    if (fio is null) then
      result = concat(result, 'ФИО; ');
    end if;
    if (gender is null) then
      result = concat(result, 'Пол; ');
    end if;
    if (birthday is null) then
      result = concat(result, 'Дата рождения; ');
    end if;
    if (oms is null) then
      result = concat(result, 'Полис; ');
    end if;
    if (oms_issuer is null) then
      result = concat(result, 'Кем выдан; ');
    end if;
    if (passport is null and birth_doc is null) then
      result = concat(result, 'Свидетельство о рождении либо паспорт; ');
    end if;


    return result;
    end;
$$;

