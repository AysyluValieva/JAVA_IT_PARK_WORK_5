CREATE FUNCTION fin_bill__clinic_is_target(main_bill_id integer, clinic_id integer)
  RETURNS boolean
LANGUAGE plpgsql
AS $$
declare
    flag boolean;
begin
    flag = (
        select count(*) > 0 from fin_bill_main
        where fin_bill_main.clinic_id = fin_bill__clinic_is_target.clinic_id
        and fin_bill_main.id = fin_bill__clinic_is_target.main_bill_id
    );
    if flag then return true;
    end if;
    flag = (
        select count(*) > 0 from fin_bill_main_child_clinic
        where fin_bill_main_child_clinic.clinic_id = fin_bill__clinic_is_target.clinic_id
        and fin_bill_main_child_clinic.main_bill_id = fin_bill__clinic_is_target.main_bill_id
    );
    if flag then return true;
    end if;
    return false;
end;
$$;

