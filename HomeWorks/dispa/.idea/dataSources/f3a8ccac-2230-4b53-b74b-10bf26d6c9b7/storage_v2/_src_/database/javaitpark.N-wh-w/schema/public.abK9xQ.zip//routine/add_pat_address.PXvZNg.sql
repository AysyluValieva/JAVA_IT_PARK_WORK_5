CREATE FUNCTION add_pat_address(xpatient integer, xreg_type integer, xaddress integer, xfrom_date date, xto_date date, xis_valid boolean, xtext_addr character varying, xnote character varying, xaddr_type integer[])
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
                xaddr integer;
                res record;
                xtype integer;
                is_val boolean;
              begin
                is_val = case when xfrom_date is null and xto_date is null
                            then xis_valid
                            else null
                         end;
                  xaddr = nextval('public.pim_party_address_id_seq');
                  insert into public.pim_party_address(id,party_id,register_type_id,addr_id,from_date,to_date,is_valid,text_addr,note)
                      values (xaddr,xpatient,xreg_type,xaddress,xfrom_date,xto_date,xis_valid,xtext_addr,xnote);

                  foreach xtype in array xaddr_type loop
                    insert into public.pim_party_addr_to_addr_type(id,party_address_id,address_type_id)
                        values (nextval('public.pim_party_addr_to_addr_type_seq'),xaddr,xtype);
                    if (cast(now() as date) >= xfrom_date and (xto_date >= cast(now() as date) or xto_date is null))
                    then
                        for res in (select ppa.id from public.pim_party_address ppa
                                join pim_party_addr_to_addr_type ppatat on ppatat.party_address_id = ppa.id
                                where ppa.party_id = xpatient and ppatat.address_type_id = xtype
                                    and (ppa.is_valid is true or ppa.from_date is not null and ppa.to_date is null) and ppa.id <> xaddr)
                        loop
                            update public.pim_party_address set is_valid = null,to_date = cast(xfrom_date - cast('1 day' as interval) as date) where id = res.id;
                        end loop;
                    end if;
                  end loop;

                  return xaddr;
              end;
$$;

