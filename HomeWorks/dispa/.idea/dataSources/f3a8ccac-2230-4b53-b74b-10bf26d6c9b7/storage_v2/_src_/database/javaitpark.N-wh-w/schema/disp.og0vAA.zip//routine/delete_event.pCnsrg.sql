CREATE FUNCTION delete_event(xid integer, xeventcode character varying)
  RETURNS void
LANGUAGE plpgsql
AS $$
declare

  begin
  if (xeventcode like 'ДВ%' ) then

                    delete from disp.md_dispr_risk_factor mesip  where mesip.event_id=xid;
                    delete from disp.md_dispr_research mesip  where mesip.event_id=xid;
                    delete from disp.md_event_service_ultrasound_exclude_anevrizm mesuea  USING  disp.md_event_patient mep  where mesuea.event_patient_id=mep.id and mep.event_id=xid;
                    delete from disp.md_event_service_prostate_antigen mesip Using disp.md_event_patient mep where mesip.event_patient_id=mep.id and mep.event_id=xid;
                    delete from disp.md_event_service_neurologist mesip Using disp.md_event_patient mep where mesip.event_patient_id=mep.id and mep.event_id=xid;
                    delete from disp.md_event_service_medical_assistant mesip Using disp.md_event_patient mep where mesip.event_patient_id=mep.id and mep.event_id=xid;
                    delete from disp.md_event_service_mammography mesip Using disp.md_event_patient mep where mesip.event_patient_id=mep.id and mep.event_id=xid;
                    delete from disp.md_event_service_glucose_in_blood mesip Using disp.md_event_patient mep where mesip.event_patient_id=mep.id and mep.event_id=xid;
                    delete from disp.md_event_service_fluorography mesip Using disp.md_event_patient mep where mesip.event_patient_id=mep.id and mep.event_id=xid;
                    delete from disp.md_event_service_excrement mesip Using disp.md_event_patient mep where mesip.event_patient_id=mep.id and mep.event_id=xid;
                    delete from disp.md_event_service_ekg mesip Using disp.md_event_patient mep where mesip.event_patient_id=mep.id and mep.event_id=xid;
                    delete from disp.md_event_service_clinical_blood_analysis mesip Using disp.md_event_patient mep where mesip.event_patient_id=mep.id and mep.event_id=xid;
                    delete from disp.md_event_service_cholesterol mesip Using disp.md_event_patient mep where mesip.event_patient_id=mep.id and mep.event_id=xid;
                    delete from disp.md_event_service_cardiovascular_risk mesip Using disp.md_event_patient mep where mesip.event_patient_id=mep.id and mep.event_id=xid;
                    delete from disp.md_event_service_bio_blood_analysis mesip Using disp.md_event_patient mep where mesip.event_patient_id=mep.id and mep.event_id=xid;
                    delete from disp.md_event_service_arterial_pressure mesip Using disp.md_event_patient mep where mesip.event_patient_id=mep.id and mep.event_id=xid;
                    delete from disp.md_event_service_ultrasound mesip Using disp.md_event_patient mep where mesip.event_patient_id=mep.id and mep.event_id=xid;
                    delete from disp.md_event_service_therapeutist mesip Using disp.md_event_patient mep where mesip.event_patient_id=mep.id and mep.event_id=xid;
                    delete from disp.md_event_service_intraocular_pressure mesip Using disp.md_event_patient mep where mesip.event_patient_id=mep.id and mep.event_id=xid;
                    delete from disp.md_event_service_general_urine_analysis mesgua Using disp.md_event_patient mep where mesgua.event_patient_id=mep.id and mep.event_id=xid;
                    delete from disp.md_disp_orphans_patient_card mdopc Using disp.md_event_patient mep where mep.id=mdopc.id and mep.event_id=xid;
                    delete from disp.md_disp_orphans_maturity mdom  Using disp.md_event_patient mep where mep.id=mdom.id and mep.event_id=xid;

    else if (xeventcode like 'ДС%' or xeventcode like 'ОН%'  )then
            delete from disp.md_disp_orphans_patient_card mdom USING disp.md_event_patient mep where mep.id=mdom.id and mep.event_id=xid;
            delete from disp.md_disp_orphans_maturity mdom USING disp.md_event_patient mep where mep.id=mdom.id and mep.event_id=xid;
            delete from disp.md_disp_orphans_diagnosis_extended mdode USING  disp.md_disp_orphans_result mdor, disp.md_event_patient mep where mdode.result_id=mdor.id and mdor.event_patient_id=mep.id and mep.event_id=xid;
            delete from disp.md_disp_orphans_vac_patient_set mdovps USING disp.md_disp_orphans_vac_patient dmovp, disp.md_event_patient mep , disp.md_disp_orphans_result mdor  WHERE mdovps.vac_id=dmovp.id and  dmovp.id=mdor.vac_id and mdor.event_patient_id=mep.id and mep.event_id=xid;
            delete from disp.md_disp_orphans_vac_patient dmovp USING disp.md_event_patient mep , disp.md_disp_orphans_result mdor WHERE dmovp.id=mdor.vac_id and mdor.event_patient_id=mep.id and mep.event_id=xid;
            delete from disp.md_disp_orphans_result mdor using disp.md_event_patient mep where mdor.event_patient_id=mep.id and mep.event_id=xid;
    end if;
    end if;

    delete from disp.md_disp_orphans_disability mdod USING disp.md_event_patient mep WHERE mep.id=mdod.id and mep.event_id=xid;
    delete from disp.md_disp_orphans_disability_diagnosis mdodd USING disp.md_event_patient mep, disp.md_disp_orphans_disability mdod WHERE mdodd.disability_id=mdod.id and mep.id=mdod.id and mep.event_id=xid;
    delete from disp.md_disp_orphans_disability_violations mdodd USING disp.md_event_patient mep, disp.md_disp_orphans_disability mdod WHERE mdodd.disability_id=mdod.id and mep.id=mdod.id and mep.event_id=xid;
  delete from disp.md_event_service_patient_status mesps USING  disp.md_event_service_patient mesp  where mesps.service_id=mesp.id and mesp.event_id=xid;
  delete from disp.md_event_service_patient_agreement mespa USING disp.md_event_service_patient mesp  WHERE mespa.service_id=mesp.id and mesp.event_id=xid;
  delete from disp.md_event_planning mdp where mdp.event_id=xid;
  delete from  disp.md_event_anthro where id=xid;
  delete from disp.md_event_questioning where id=xid;
  delete from SR_SRV_RENDERED ssr USING disp.md_event_service mes WHERE ssr.service_id=mes.id and mes.event_id=xid;
  delete from MD_SRV_RENDERED msr USING disp.md_event_eq_case meec WHERE msr.case_id=meec.case_id  and meec.event_patient_id=xid;
  delete from MC_CASE mc  USING disp.md_event_eq_case meec where mc.id=meec.case_id and meec.event_patient_id=xid;
  delete from disp.md_event_eq_case meec where meec.event_patient_id=xid;
  delete from disp.md_event_service_patient mesp where mesp.event_id=xid;
  delete from disp.md_event_patient mep where mep.event_id=xid;
  delete from disp.md_event_service_model mesm  USING disp.md_event_service mes where mesm.event_service_id=mes.id and mes.event_id=xid;
  delete from disp.md_event_service mes where mes.event_id=xid;
  delete from disp.md_event where id=xid;
  end;
$$;

