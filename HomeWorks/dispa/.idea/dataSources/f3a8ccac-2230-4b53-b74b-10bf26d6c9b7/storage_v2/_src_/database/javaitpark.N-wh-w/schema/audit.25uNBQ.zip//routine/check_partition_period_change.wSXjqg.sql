CREATE FUNCTION check_partition_period_change(_table_setting_id integer, _to_partition_period_id integer)
  RETURNS boolean
LANGUAGE plpgsql
AS $$
DECLARE
                  result BOOLEAN;
                  from_partition_period_id INTEGER;
                BEGIN
                  SELECT partition_period_id INTO from_partition_period_id
                  FROM audit.table_setting
                  WHERE id = _table_setting_id;

                  SELECT audit.check_partition_period_change(_table_setting_id, from_partition_period_id,
                    _to_partition_period_id)
                  INTO result;

                  RETURN result;
                END;
$$;

