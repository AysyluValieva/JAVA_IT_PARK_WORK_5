CREATE VIEW mon_diagnoses AS
  SELECT mc_case.id,
    mc_case.create_date,
    diag.case_id,
    diag.m_diag_str,
    diag.m_d_ids,
    diag.diag_str,
    diag.d_ids,
    diag.doctor_ids,
    diag.stage_ids,
    diag.f1,
    diag.f2,
    doctor.doctor_full_name,
    doctor.id AS doctor_id
   FROM ((mc_case
     JOIN ( SELECT diag_.case_id,
            string_agg(
                CASE
                    WHEN (diag_.is_main = true) THEN diag_.d_str
                    ELSE NULL::text
                END, ', '::text) AS m_diag_str,
            monitoring.agg_ids(
                CASE
                    WHEN (diag_.is_main = true) THEN diag_.d_ids
                    ELSE NULL::integer[]
                END) AS m_d_ids,
            string_agg(
                CASE
                    WHEN (diag_.is_main = false) THEN diag_.d_str
                    ELSE NULL::text
                END, ', '::text) AS diag_str,
            monitoring.agg_ids(
                CASE
                    WHEN (diag_.is_main = false) THEN diag_.d_ids
                    ELSE NULL::integer[]
                END) AS d_ids,
            monitoring.agg_ids(
                CASE
                    WHEN (diag_.is_main = true) THEN diag_.doctor_ids
                    ELSE NULL::integer[]
                END) AS doctor_ids,
            monitoring.agg_ids(
                CASE
                    WHEN (diag_.is_main = true) THEN diag_.stage_ids
                    ELSE NULL::integer[]
                END) AS stage_ids,
            sum(
                CASE
                    WHEN (diag_.f1 IS NULL) THEN (0)::bigint
                    ELSE diag_.f1
                END) AS f1,
            sum(
                CASE
                    WHEN (diag_.f2 IS NULL) THEN (0)::bigint
                    ELSE diag_.f2
                END) AS f2
           FROM ( SELECT mcd.case_id,
                    true AS is_main,
                    string_agg((((md_diagnosis.code)::text || ' '::text) || (md_diagnosis.name)::text), ', '::text) AS d_str,
                    array_agg(md_diagnosis.id) AS d_ids,
                    array_agg(mcd.doctor_id) AS doctor_ids,
                    array_agg(mcd.stage_id) AS stage_ids,
                    sum(criteria.point) AS f1,
                    0 AS f2
                   FROM ((mc_diagnosis mcd
                     JOIN md_diagnosis ON ((mcd.diagnos_id = md_diagnosis.id)))
                     LEFT JOIN monitoring.md_traumatology_diagnosis_criteria criteria ON (((criteria.diagnosis_id = mcd.diagnos_id) AND (criteria.type_id = 1) AND (criteria.stage_id = mcd.stage_id))))
                  WHERE ((mcd.is_main = true) AND (NOT (mcd.stage_id IS NULL)))
                  GROUP BY mcd.case_id
                UNION
                 SELECT mcd.case_id,
                    false AS is_main,
                    string_agg((((md_diagnosis.code)::text || ' '::text) || (md_diagnosis.name)::text), ', '::text) AS d_str,
                    array_agg(md_diagnosis.id) AS d_ids,
                    array_agg(mcd.doctor_id) AS doctor_ids,
                    array_agg(mcd.stage_id) AS stage_ids,
                    0 AS f1,
                    sum(criteria.point) AS f2
                   FROM ((mc_diagnosis mcd
                     JOIN md_diagnosis ON ((mcd.diagnos_id = md_diagnosis.id)))
                     LEFT JOIN monitoring.md_traumatology_diagnosis_criteria criteria ON ((criteria.diagnosis_id = mcd.diagnos_id)))
                  WHERE (mcd.is_main = false)
                  GROUP BY mcd.case_id) diag_
          GROUP BY diag_.case_id) diag ON ((diag.case_id = mc_case.id)))
     LEFT JOIN ( SELECT mdep.id,
            (((((pim_individual.surname)::text || ' '::text) || (pim_individual.name)::text) || ' '::text) || (pim_individual.patr_name)::text) AS doctor_full_name
           FROM (((md_employee_position mdep
             JOIN pim_employee_position ON ((pim_employee_position.id = mdep.id)))
             JOIN pim_employee ON ((pim_employee_position.employee_id = pim_employee.id)))
             JOIN pim_individual ON ((pim_individual.id = pim_employee.individual_id)))) doctor ON ((doctor.id = diag.doctor_ids[1])));

