CREATE FUNCTION fsym_on_u_for_pblc_pm_bldng_mngrp()
  RETURNS trigger
LANGUAGE plpgsql
AS $fun$
declare var_row_data text; 
                                declare var_old_data text; 
                                begin
                                   
                                  if 1=1 and "public".sym_triggers_disabled() = 0 then                                                                                                 
                                    var_row_data := 
          case when new."id" is null then '' else '"' || cast(cast(new."id" as numeric) as varchar) || '"' end||','||
          case when new."build_dt" is null then '' else '"' || to_char(new."build_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when new."code" is null then '' else '"' || replace(replace(cast(new."code" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."effective_area" is null then '' else '"' || cast(cast(new."effective_area" as numeric) as varchar) || '"' end||','||
          case when new."floor_area" is null then '' else '"' || cast(cast(new."floor_area" as numeric) as varchar) || '"' end||','||
          case when new."floors_number" is null then '' else '"' || cast(cast(new."floors_number" as numeric) as varchar) || '"' end||','||
          case when new."name" is null then '' else '"' || replace(replace(cast(new."name" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."power" is null then '' else '"' || cast(cast(new."power" as numeric) as varchar) || '"' end||','||
          case when new."volume" is null then '' else '"' || cast(cast(new."volume" as numeric) as varchar) || '"' end||','||
          case when new."project_type_id" is null then '' else '"' || cast(cast(new."project_type_id" as numeric) as varchar) || '"' end||','||
          case when new."land_id" is null then '' else '"' || cast(cast(new."land_id" as numeric) as varchar) || '"' end||','||
          case when new."address_id" is null then '' else '"' || cast(cast(new."address_id" as numeric) as varchar) || '"' end||','||
          case when new."ownership_pattern_id" is null then '' else '"' || cast(cast(new."ownership_pattern_id" as numeric) as varchar) || '"' end||','||
          case when new."org_id" is null then '' else '"' || cast(cast(new."org_id" as numeric) as varchar) || '"' end||','||
          case when new."from_dt" is null then '' else '"' || to_char(new."from_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when new."to_dt" is null then '' else '"' || to_char(new."to_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when new."building_function_id" is null then '' else '"' || cast(cast(new."building_function_id" as numeric) as varchar) || '"' end||','||
          case when new."building_technology_id" is null then '' else '"' || cast(cast(new."building_technology_id" as numeric) as varchar) || '"' end||','||
          case when new."on_the_books" is null then '' when new."on_the_books" then '"1"' else '"0"' end||','||
          case when new."beds_count" is null then '' else '"' || cast(cast(new."beds_count" as numeric) as varchar) || '"' end||','||
          case when new."hospital_beds_count" is null then '' else '"' || cast(cast(new."hospital_beds_count" as numeric) as varchar) || '"' end||','||
          case when new."ambulatory_beds_count" is null then '' else '"' || cast(cast(new."ambulatory_beds_count" as numeric) as varchar) || '"' end||','||
          case when new."rooms_count" is null then '' else '"' || cast(cast(new."rooms_count" as numeric) as varchar) || '"' end||','||
          case when new."rooms_area" is null then '' else '"' || cast(cast(new."rooms_area" as numeric) as varchar) || '"' end||','||
          case when new."daily_power" is null then '' else '"' || cast(cast(new."daily_power" as numeric) as varchar) || '"' end||','||
          case when new."ward_area" is null then '' else '"' || cast(cast(new."ward_area" as numeric) as varchar) || '"' end||','||
          case when new."ventilation" is null then '' when new."ventilation" then '"1"' else '"0"' end||','||
          case when new."project_number" is null then '' else '"' || replace(replace(cast(new."project_number" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."project_dt" is null then '' else '"' || to_char(new."project_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when new."reconstruction_dt" is null then '' else '"' || to_char(new."reconstruction_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when new."conditioning" is null then '' when new."conditioning" then '"1"' else '"0"' end||','||
          case when new."electric_supply" is null then '' else '"' || replace(replace(cast(new."electric_supply" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."cold_water_supply" is null then '' when new."cold_water_supply" then '"1"' else '"0"' end||','||
          case when new."medical_gas_supply" is null then '' when new."medical_gas_supply" then '"1"' else '"0"' end||','||
          case when new."common_gas_supply" is null then '' when new."common_gas_supply" then '"1"' else '"0"' end||','||
          case when new."passenger_lift" is null then '' when new."passenger_lift" then '"1"' else '"0"' end||','||
          case when new."medical_lift" is null then '' when new."medical_lift" then '"1"' else '"0"' end||','||
          case when new."fire_alarm_system" is null then '' when new."fire_alarm_system" then '"1"' else '"0"' end||','||
          case when new."security_alarm_system" is null then '' when new."security_alarm_system" then '"1"' else '"0"' end||','||
          case when new."police_call_button" is null then '' when new."police_call_button" then '"1"' else '"0"' end||','||
          case when new."evacuation_system" is null then '' when new."evacuation_system" then '"1"' else '"0"' end||','||
          case when new."fire_protection_water_supply" is null then '' when new."fire_protection_water_supply" then '"1"' else '"0"' end||','||
          case when new."fire_notification_system" is null then '' when new."fire_notification_system" then '"1"' else '"0"' end||','||
          case when new."fire_service_phone_connection" is null then '' when new."fire_service_phone_connection" then '"1"' else '"0"' end||','||
          case when new."fire_violation_count" is null then '' else '"' || cast(cast(new."fire_violation_count" as numeric) as varchar) || '"' end||','||
          case when new."has_evacuation_exit" is null then '' when new."has_evacuation_exit" then '"1"' else '"0"' end||','||
          case when new."respiratory_protection_supply" is null then '' when new."respiratory_protection_supply" then '"1"' else '"0"' end||','||
          case when new."stretcher_supply" is null then '' when new."stretcher_supply" then '"1"' else '"0"' end||','||
          case when new."nearest_fire_service_distance" is null then '' else '"' || cast(cast(new."nearest_fire_service_distance" as numeric) as varchar) || '"' end||','||
          case when new."building_type_construction_id" is null then '' else '"' || cast(cast(new."building_type_construction_id" as numeric) as varchar) || '"' end||','||
          case when new."building_type_overlap_id" is null then '' else '"' || cast(cast(new."building_type_overlap_id" as numeric) as varchar) || '"' end||','||
          case when new."building_state_id" is null then '' else '"' || cast(cast(new."building_state_id" as numeric) as varchar) || '"' end||','||
          case when new."hot_water_supply_type_id" is null then '' else '"' || cast(cast(new."hot_water_supply_type_id" as numeric) as varchar) || '"' end||','||
          case when new."heating_system_type_id" is null then '' else '"' || cast(cast(new."heating_system_type_id" as numeric) as varchar) || '"' end||','||
          case when new."sewer_type_id" is null then '' else '"' || cast(cast(new."sewer_type_id" as numeric) as varchar) || '"' end||','||
          case when new."communication_channel_type_id" is null then '' else '"' || cast(cast(new."communication_channel_type_id" as numeric) as varchar) || '"' end||','||
          case when new."latitude" is null then '' else '"' || cast(cast(new."latitude" as numeric) as varchar) || '"' end||','||
          case when new."longitude" is null then '' else '"' || cast(cast(new."longitude" as numeric) as varchar) || '"' end; 
                                    var_old_data := 
          case when old."id" is null then '' else '"' || cast(cast(old."id" as numeric) as varchar) || '"' end||','||
          case when old."build_dt" is null then '' else '"' || to_char(old."build_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when old."code" is null then '' else '"' || replace(replace(cast(old."code" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when old."effective_area" is null then '' else '"' || cast(cast(old."effective_area" as numeric) as varchar) || '"' end||','||
          case when old."floor_area" is null then '' else '"' || cast(cast(old."floor_area" as numeric) as varchar) || '"' end||','||
          case when old."floors_number" is null then '' else '"' || cast(cast(old."floors_number" as numeric) as varchar) || '"' end||','||
          case when old."name" is null then '' else '"' || replace(replace(cast(old."name" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when old."power" is null then '' else '"' || cast(cast(old."power" as numeric) as varchar) || '"' end||','||
          case when old."volume" is null then '' else '"' || cast(cast(old."volume" as numeric) as varchar) || '"' end||','||
          case when old."project_type_id" is null then '' else '"' || cast(cast(old."project_type_id" as numeric) as varchar) || '"' end||','||
          case when old."land_id" is null then '' else '"' || cast(cast(old."land_id" as numeric) as varchar) || '"' end||','||
          case when old."address_id" is null then '' else '"' || cast(cast(old."address_id" as numeric) as varchar) || '"' end||','||
          case when old."ownership_pattern_id" is null then '' else '"' || cast(cast(old."ownership_pattern_id" as numeric) as varchar) || '"' end||','||
          case when old."org_id" is null then '' else '"' || cast(cast(old."org_id" as numeric) as varchar) || '"' end||','||
          case when old."from_dt" is null then '' else '"' || to_char(old."from_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when old."to_dt" is null then '' else '"' || to_char(old."to_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when old."building_function_id" is null then '' else '"' || cast(cast(old."building_function_id" as numeric) as varchar) || '"' end||','||
          case when old."building_technology_id" is null then '' else '"' || cast(cast(old."building_technology_id" as numeric) as varchar) || '"' end||','||
          case when old."on_the_books" is null then '' when old."on_the_books" then '"1"' else '"0"' end||','||
          case when old."beds_count" is null then '' else '"' || cast(cast(old."beds_count" as numeric) as varchar) || '"' end||','||
          case when old."hospital_beds_count" is null then '' else '"' || cast(cast(old."hospital_beds_count" as numeric) as varchar) || '"' end||','||
          case when old."ambulatory_beds_count" is null then '' else '"' || cast(cast(old."ambulatory_beds_count" as numeric) as varchar) || '"' end||','||
          case when old."rooms_count" is null then '' else '"' || cast(cast(old."rooms_count" as numeric) as varchar) || '"' end||','||
          case when old."rooms_area" is null then '' else '"' || cast(cast(old."rooms_area" as numeric) as varchar) || '"' end||','||
          case when old."daily_power" is null then '' else '"' || cast(cast(old."daily_power" as numeric) as varchar) || '"' end||','||
          case when old."ward_area" is null then '' else '"' || cast(cast(old."ward_area" as numeric) as varchar) || '"' end||','||
          case when old."ventilation" is null then '' when old."ventilation" then '"1"' else '"0"' end||','||
          case when old."project_number" is null then '' else '"' || replace(replace(cast(old."project_number" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when old."project_dt" is null then '' else '"' || to_char(old."project_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when old."reconstruction_dt" is null then '' else '"' || to_char(old."reconstruction_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when old."conditioning" is null then '' when old."conditioning" then '"1"' else '"0"' end||','||
          case when old."electric_supply" is null then '' else '"' || replace(replace(cast(old."electric_supply" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when old."cold_water_supply" is null then '' when old."cold_water_supply" then '"1"' else '"0"' end||','||
          case when old."medical_gas_supply" is null then '' when old."medical_gas_supply" then '"1"' else '"0"' end||','||
          case when old."common_gas_supply" is null then '' when old."common_gas_supply" then '"1"' else '"0"' end||','||
          case when old."passenger_lift" is null then '' when old."passenger_lift" then '"1"' else '"0"' end||','||
          case when old."medical_lift" is null then '' when old."medical_lift" then '"1"' else '"0"' end||','||
          case when old."fire_alarm_system" is null then '' when old."fire_alarm_system" then '"1"' else '"0"' end||','||
          case when old."security_alarm_system" is null then '' when old."security_alarm_system" then '"1"' else '"0"' end||','||
          case when old."police_call_button" is null then '' when old."police_call_button" then '"1"' else '"0"' end||','||
          case when old."evacuation_system" is null then '' when old."evacuation_system" then '"1"' else '"0"' end||','||
          case when old."fire_protection_water_supply" is null then '' when old."fire_protection_water_supply" then '"1"' else '"0"' end||','||
          case when old."fire_notification_system" is null then '' when old."fire_notification_system" then '"1"' else '"0"' end||','||
          case when old."fire_service_phone_connection" is null then '' when old."fire_service_phone_connection" then '"1"' else '"0"' end||','||
          case when old."fire_violation_count" is null then '' else '"' || cast(cast(old."fire_violation_count" as numeric) as varchar) || '"' end||','||
          case when old."has_evacuation_exit" is null then '' when old."has_evacuation_exit" then '"1"' else '"0"' end||','||
          case when old."respiratory_protection_supply" is null then '' when old."respiratory_protection_supply" then '"1"' else '"0"' end||','||
          case when old."stretcher_supply" is null then '' when old."stretcher_supply" then '"1"' else '"0"' end||','||
          case when old."nearest_fire_service_distance" is null then '' else '"' || cast(cast(old."nearest_fire_service_distance" as numeric) as varchar) || '"' end||','||
          case when old."building_type_construction_id" is null then '' else '"' || cast(cast(old."building_type_construction_id" as numeric) as varchar) || '"' end||','||
          case when old."building_type_overlap_id" is null then '' else '"' || cast(cast(old."building_type_overlap_id" as numeric) as varchar) || '"' end||','||
          case when old."building_state_id" is null then '' else '"' || cast(cast(old."building_state_id" as numeric) as varchar) || '"' end||','||
          case when old."hot_water_supply_type_id" is null then '' else '"' || cast(cast(old."hot_water_supply_type_id" as numeric) as varchar) || '"' end||','||
          case when old."heating_system_type_id" is null then '' else '"' || cast(cast(old."heating_system_type_id" as numeric) as varchar) || '"' end||','||
          case when old."sewer_type_id" is null then '' else '"' || cast(cast(old."sewer_type_id" as numeric) as varchar) || '"' end||','||
          case when old."communication_channel_type_id" is null then '' else '"' || cast(cast(old."communication_channel_type_id" as numeric) as varchar) || '"' end||','||
          case when old."latitude" is null then '' else '"' || cast(cast(old."latitude" as numeric) as varchar) || '"' end||','||
          case when old."longitude" is null then '' else '"' || cast(cast(old."longitude" as numeric) as varchar) || '"' end; 
                                    if var_old_data is null or var_row_data != var_old_data then 
                                    insert into "public".sym_data                                                                                                                     
                                    (table_name, event_type, trigger_hist_id, pk_data, row_data, old_data, channel_id, transaction_id, source_node_id, external_data, create_time)                     
                                    values(                                                                                                                                                            
                                      'pim_building',                                                                                                                                            
                                      'U',                                                                                                                                                             
                                      18281,                                                                                                                                             
                                      
          case when old."id" is null then '' else '"' || cast(cast(old."id" as numeric) as varchar) || '"' end,                                                                                                                                                      
                                      var_row_data,                                                                                                                                                      
                                      var_old_data,                                                                                                                                                   
                                      'public_pim_building_default',                                                                                                                                                
                                      txid_current(),                                                                                                                                               
                                      "public".sym_node_disabled(),                                                                                                                   
                                      null,                                                                                                                                               
                                      CURRENT_TIMESTAMP                                                                                                                
                                    );                                                                                                                                                                 
                                  end if;                                                                                                                                                              
                                  end if;                                                                                                                                                              
                                                                                                                                                                               
                                  return null;                                                                                                                                                         
                                end;
$fun$;

