CREATE FUNCTION ins_numerator(scope integer, clinic integer, xtype integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
                xid integer;
              begin
                xid = nextval('amb.md_ambulance_numb_setting_id_seq');
                insert into amb.md_ambulance_numb_setting (id,scope_id,clinic_id,type_num)
                    values (xid,scope,clinic,xtype);
                /*insert into amb.md_ambulance_numbers (id,numb_id,value)
                    values (nextval('amb.md_ambulance_numbers_id_seq'),xid,0);*/
                return xid;
              end;
$$;

