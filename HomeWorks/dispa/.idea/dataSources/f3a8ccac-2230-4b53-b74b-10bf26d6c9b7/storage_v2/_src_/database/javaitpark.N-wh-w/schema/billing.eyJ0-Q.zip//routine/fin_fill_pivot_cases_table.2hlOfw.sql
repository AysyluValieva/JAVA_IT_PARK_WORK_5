CREATE FUNCTION fin_fill_pivot_cases_table(p1_bill_id integer)
  RETURNS void
STRICT
LANGUAGE plpgsql
AS $$
DECLARE 
    _code_ogrn_org_id INTEGER;
    _code_oms_id INTEGER;
    _code_snils_ind_id INTEGER;
    _r RECORD;
BEGIN
    /*
        version: 2015-08-17
    */
    IF EXISTS (SELECT 1 FROM billing.fin_bill_cases WHERE bill_id = p1_bill_id) THEN DELETE FROM billing.fin_bill_cases WHERE bill_id = p1_bill_id; END IF;
    
    _code_ogrn_org_id  := (SELECT id FROM public.pim_code_type WHERE code = 'OGRN'    );
    _code_oms_id       := (SELECT id FROM public.pim_code_type WHERE code = 'CODE_OMS');
    _code_snils_ind_id := (SELECT id FROM public.pim_code_type WHERE code = 'SNILS'   );
    --------------общие сведения------------------
    INSERT INTO billing.fin_bill_cases 
    (
        bill_id, case_id, patient_id, patient_age, active_policy_id, belonging_type, new_born, id_pac, representative_id, 
        step_cnt, open_date, close_date, last_id, last_outcome_date, item_id_arr
    )
        SELECT
            bill_id, case_id, patient_id, patient_age, active_policy_id, belonging_type, new_born, id_pac, representative_id, 
            step_cnt, case_open_date, case_close_date, closing_step_id, case_close_date, array_agg (fin_bill_spec_item_id)
        FROM 
            billing.fin_bill_generate 
        WHERE 
            bill_id = p1_bill_id AND NOT is_sifted AND case_id IS NOT NULL
        GROUP BY 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14
    ;
    UPDATE billing.fin_bill_cases AS f
    SET
        uid                      = coalesce (trim (c.uid), ''),
        admission_type_id        = c.admission_type_id,
        case_type_id             = c.case_type_id,
        case_type_code           = coalesce (trim ((SELECT code FROM public.mc_case_type WHERE id = c.case_type_id LIMIT 1)), ''),
        case_mode_id             = (SELECT case_mode_id FROM public.mc_case_type WHERE id = c.case_type_id LIMIT 1),
        care_regimen_id          = c.care_regimen_id,
        care_regimen_code        = coalesce (trim ((SELECT code FROM public.mc_care_regimen WHERE id = c.care_regimen_id LIMIT 1)::TEXT), ''),
        care_level_id            = c.care_level_id,
        care_level_code          = coalesce (trim ((SELECT code FROM public.mc_care_level WHERE id = c.care_level_id LIMIT 1)), ''),
        repeat_count_code        = coalesce (trim ((SELECT code FROM public.mc_repeat_count WHERE id = c.repeat_count_id LIMIT 1)), ''),
        payment_method_code      = coalesce (trim ((SELECT code FROM public.mc_payment_method WHERE id = c.payment_method_id LIMIT 1)), ''),
        init_goal_id             = c.init_goal_id,
        init_goal_code_arr       = (SELECT ARRAY [coalesce (trim (code), ''), coalesce (trim (e_code), '')] FROM public.mc_case_init_goal WHERE id = c.init_goal_id LIMIT 1),
        care_providing_form_code = coalesce (trim ((SELECT code FROM public.md_care_providing_form WHERE id = c.care_providing_form_id LIMIT 1)), ''),
        provision_condition_code = coalesce (trim ((SELECT code FROM public.md_care_provision_condition WHERE id = c.provision_condition_id LIMIT 1)), '')
    FROM 
        public.mc_case AS c
    WHERE
        f.bill_id = p1_bill_id AND f.case_id = c.id
    ;
    ------------------направления------------------
    WITH t AS 
    (
        SELECT 
            f.bill_id, 
            f.case_id, 
            coalesce (trim ((SELECT code FROM public.md_clinic WHERE id = r.ref_organization_id LIMIT 1)), '') AS ref_clinic_code,
            coalesce (trim ((SELECT code FROM public.pim_org_code WHERE org_id = r.ref_organization_id AND type_id = _code_oms_id ORDER BY issue_dt DESC NULLS LAST LIMIT 1)), '') AS ref_clinic_code_oms
        FROM
            billing.fin_bill_cases AS f 
            JOIN LATERAL (SELECT referral_id FROM public.mc_case WHERE id = f.case_id LIMIT 1) AS c ON TRUE 
            JOIN LATERAL (SELECT ref_organization_id FROM md_referral WHERE id = c.referral_id LIMIT 1) AS r ON TRUE 
        WHERE
            f.bill_id = p1_bill_id 
    )
    UPDATE billing.fin_bill_cases AS f
    SET 
        ref_clinic_code = t.ref_clinic_code, ref_clinic_code_oms = t.ref_clinic_code_oms 
    FROM t
    WHERE 
        f.bill_id = t.bill_id AND f.case_id = t.case_id
    ;
    ------------------пациент------------------
    UPDATE billing.fin_bill_cases AS f
    SET
        pat_os_sluch    = ARRAY 
                          (
                              SELECT c.ui_code FROM public.pci_patient_part_case AS p, public.pci_part_case AS c 
                              WHERE 
                                  c.id = p.part_case_id AND p.patient_id = f.patient_id AND daterange (f.open_date, f.close_date, '[]') && daterange (p.from_dt, p.to_dt, '[]') AND c.ui_code IS NOT NULL
                          ),
        pat_birthweight = CASE WHEN f.new_born THEN (SELECT birthweight FROM public.pci_patient WHERE id = f.patient_id LIMIT 1) ELSE NULL END,
        new_born_part   = CASE 
                              WHEN 
                                  f.new_born 
                              THEN 
                                  concat 
                                  (
                                      (SELECT concat (gender_id, to_char (birth_dt, 'DDMMYY')) FROM public.pim_individual WHERE id = f.patient_id LIMIT 1), 
                                      coalesce ((SELECT left (newborn_number::TEXT, 2) FROM public.pci_patient WHERE id = f.patient_id LIMIT 1), '1')
                                  ) 
                              ELSE 
                                  '0' 
                              END
    WHERE
        f.bill_id = p1_bill_id
    ;
    ----------------представитель----------------
    UPDATE billing.fin_bill_cases AS f
    SET
        rep_os_sluch = ARRAY 
                       (
                           SELECT c.ui_code FROM public.pci_patient_part_case AS p, public.pci_part_case AS c 
                           WHERE 
                               c.id = p.part_case_id AND p.patient_id = f.representative_id AND daterange (f.open_date, f.close_date, '[]') && daterange (p.from_dt, p.to_dt, '[]') AND c.ui_code IS NOT NULL
                       )
    WHERE
        f.bill_id = p1_bill_id
    ;
    --вес новорождённого для пациента-матери--
    WITH t AS 
    (
        SELECT 
            f.bill_id, f.case_id, array_agg (b.birthweight) AS birthweight
        FROM
            billing.fin_bill_cases AS f
            JOIN LATERAL (SELECT id FROM public.pim_individual WHERE gender_id = 2 AND id = f.patient_id LIMIT 1) AS i ON TRUE
            JOIN LATERAL (SELECT rel_id FROM public.pim_party_relation_party WHERE side_id = 1 AND party_id = i.id) AS m ON TRUE
            JOIN LATERAL (SELECT party_id FROM public.pim_party_relation_party WHERE side_id = 2 AND rel_id = m.rel_id) AS c ON TRUE
            JOIN LATERAL (SELECT id FROM public.pim_individual WHERE birth_dt <@ daterange (f.open_date, f.close_date, '[]') AND id = c.party_id LIMIT 1) AS k ON TRUE
            JOIN LATERAL (SELECT birthweight FROM public.pci_patient WHERE birthweight < 2500 AND id = k.id) AS b ON TRUE
        WHERE
            f.bill_id = p1_bill_id 
        GROUP BY 1, 2
    )
    UPDATE billing.fin_bill_cases AS f
    SET 
        birthweight = t.birthweight
    FROM t
    WHERE 
        f.bill_id = t.bill_id AND f.case_id = t.case_id
    ;
    -----------------диагнозы------------------
    FOR _r IN
        SELECT 
            f.bill_id, 
            f.case_id, 
            a.diagnos_id,
            a.injury_type_id, 
            a.disease_type_id,
            ARRAY (SELECT diagnos_id FROM public.mc_diagnosis WHERE (NOT is_main OR is_main IS UNKNOWN) AND type_id = 2 AND case_id = f.case_id) AS r_diags_arr,
            ARRAY (SELECT diagnos_id FROM public.mc_diagnosis WHERE (NOT is_main OR is_main IS UNKNOWN) AND type_id = 3 AND case_id = f.case_id) AS c_diags_arr
        FROM 
            billing.fin_bill_cases AS f 
            JOIN LATERAL (SELECT main_diagnos_id FROM public.mc_case WHERE id = f.case_id LIMIT 1) AS c ON TRUE
            JOIN LATERAL (SELECT id FROM public.mc_diagnosis WHERE is_main AND case_id = f.case_id ORDER BY stage_id DESC NULLS LAST, establishment_date DESC NULLS LAST, id DESC LIMIT 1) AS m ON TRUE
            LEFT JOIN LATERAL (SELECT diagnos_id, injury_type_id, disease_type_id FROM public.mc_diagnosis WHERE id = coalesce (c.main_diagnos_id, m.id) LIMIT 1) a ON TRUE
        WHERE
            f.bill_id = p1_bill_id
    LOOP
        UPDATE billing.fin_bill_cases 
        SET 
            main_diagnosis_id          = _r.diagnos_id,
            main_diagnosis_code        = coalesce (trim ((SELECT code FROM public.md_diagnosis WHERE id = _r.diagnos_id LIMIT 1)), ''),
            injury_code                = coalesce (trim ((SELECT code FROM public.mc_injury_type WHERE id = _r.injury_type_id LIMIT 1)), ''),
            disease_type_code          = coalesce (trim ((SELECT code FROM public.mc_disease_type WHERE id = _r.disease_type_id LIMIT 1)), ''),
            related_diagnosis_arr      = ARRAY (SELECT code FROM public.md_diagnosis WHERE id = ANY (_r.r_diags_arr)),
            complication_diagnosis_arr = ARRAY (SELECT code FROM public.md_diagnosis WHERE id = ANY (_r.c_diags_arr))
        WHERE
            bill_id = _r.bill_id AND case_id = _r.case_id
        ;
    END LOOP;
    ----------------первый шаг-----------------
    WITH s AS 
    (
        SELECT 
            f.bill_id, f.case_id, s.id AS step_id, s.admission_date, s.outcome_date, d.id AS diagnosis_id, coalesce (trim (d.code), '') AS diagnosis_code 
        FROM 
            billing.fin_bill_cases AS f
            JOIN LATERAL (SELECT id, main_diagnosis_id, admission_date, outcome_date FROM public.mc_step WHERE case_id = f.case_id ORDER BY admission_date, admission_time NULLS FIRST, id LIMIT 1) AS s ON TRUE
            LEFT JOIN public.mc_diagnosis AS m ON m.id = s.main_diagnosis_id 
            LEFT JOIN public.md_diagnosis AS d ON d.id = m.diagnos_id
        WHERE 
            f.bill_id = p1_bill_id
    )
    UPDATE billing.fin_bill_cases AS f
    SET 
        first_id             = s.step_id       ,
        first_diagnosis_id   = s.diagnosis_id  ,
        first_diagnosis_code = s.diagnosis_code,
        first_admission_date = s.admission_date,
        first_outcome_date   = s.outcome_date   
    FROM s
    WHERE 
        f.bill_id = s.bill_id AND f.case_id = s.case_id
    ;
    ----------------крайний шаг----------------
    WITH t AS 
    (
        SELECT 
            f.bill_id,
            f.case_id,
            s.outcome_id,
            coalesce (trim ((SELECT code FROM public.mc_step_care_result WHERE id = s.outcome_id LIMIT 1)), '') AS care_result,
            s.result_id,
            coalesce (trim ((SELECT code FROM public.mc_step_result WHERE id = s.result_id LIMIT 1)), '') AS result_code,
            coalesce ((SELECT is_closed FROM public.mc_step_result WHERE id = s.result_id LIMIT 1), FALSE) AS is_closed,
            coalesce (trim (n.code), '') AS hsp_department_code,
            coalesce (trim (n.name), '') AS hsp_department_name,
            e.employee_id AS doctor_code,
            coalesce (trim (d.code), '') AS department_code,
            coalesce (trim (d.name), '') AS department_name,
            (SELECT ARRAY [coalesce (trim (code), ''), coalesce (trim (e_code), '')] FROM public.pim_speciality WHERE id = p.speciality_id LIMIT 1) AS speciality_code_arr,
            coalesce (trim ((SELECT code FROM public.md_profile WHERE id = s.profile_id LIMIT 1), '')) AS profile_code,
            coalesce (trim ((SELECT code FROM public.md_mes WHERE id = s.mes_id LIMIT 1)), '') AS mes_code,
            coalesce (trim ((SELECT code FROM public.md_clinical_statistical_group WHERE id = s.csg_id LIMIT 1)), '') AS csg_code,
            coalesce (trim ((SELECT code FROM public.mc_vmp_type WHERE id = s.vmp_type_id LIMIT 1)), '') AS vmp_type_code,
            coalesce (trim ((SELECT code FROM public.mc_vmp_method WHERE id = s.vmp_method_id LIMIT 1)), '') AS vmp_method_code,
            coalesce (trim (i.code), '') AS snils
        FROM 
            billing.fin_bill_cases AS f
            JOIN LATERAL (SELECT id, outcome_id, result_id, res_group_id, profile_id, mes_id, csg_id, vmp_type_id, vmp_method_id FROM public.mc_step WHERE id = f.last_id LIMIT 1) AS s ON TRUE
            LEFT JOIN LATERAL (SELECT code, name FROM public.pim_department WHERE id = (SELECT department_id FROM public.hsp_record WHERE id = s.id LIMIT 1) LIMIT 1) AS n ON TRUE
            LEFT JOIN LATERAL (SELECT employee_id, position_id FROM public.pim_employee_position WHERE id = (SELECT responsible_id FROM public.sr_res_group WHERE id = s.res_group_id LIMIT 1) LIMIT 1) AS e ON TRUE
            LEFT JOIN LATERAL (SELECT department_id, speciality_id FROM public.pim_position WHERE id = e.position_id LIMIT 1) AS p ON TRUE
            LEFT JOIN LATERAL (SELECT code, name FROM public.pim_department WHERE id = p.department_id LIMIT 1) AS d ON TRUE
            LEFT JOIN LATERAL 
            (
                SELECT 
                    regexp_replace (replace (replace (code, '-', ''), ' ', ''), '(...)(...)(...)(..)', '\1-\2-\3 \4') AS code
                FROM 
                    public.pim_indiv_code 
                WHERE 
                    indiv_id = (SELECT individual_id FROM public.pim_employee WHERE id = e.employee_id LIMIT 1) AND type_id = _code_snils_ind_id 
                ORDER BY issue_dt DESC NULLS LAST LIMIT 1
            ) AS i ON TRUE
        WHERE 
            f.bill_id = p1_bill_id
    )
    UPDATE billing.fin_bill_cases AS f
    SET 
        last_outcome_id          = t.outcome_id         ,
        last_result_id           = t.result_id          ,
        last_result_code         = t.result_code        ,
        last_is_closed           = t.is_closed          ,
        last_care_result         = t.care_result        ,
        last_hsp_department_code = t.hsp_department_code,
        last_hsp_department_name = t.hsp_department_name,
        last_department_code     = t.department_code    ,
        last_department_name     = t.department_name    ,
        last_speciality_code_arr = t.speciality_code_arr,
        last_doctor_code         = t.doctor_code        ,
        last_profile_code        = t.profile_code       ,
        last_mes_code            = t.mes_code           ,
        last_csg_code            = t.csg_code           ,
        last_vmp_type_code       = t.vmp_type_code      ,
        last_vmp_method_code     = t.vmp_method_code    ,
        last_doctor_snils        = t.snils               
    FROM t
    WHERE 
        f.bill_id = t.bill_id AND f.case_id = t.case_id
    ;
END;
$$;

