CREATE FUNCTION fsym_on_u_for_pblc_pm_prty_rl_t_prty_mngrp()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
declare var_row_data text; 
                                declare var_old_data text; 
                                begin
                                   
                                  if 1=1 and "public".sym_triggers_disabled() = 0 then                                                                                                 
                                    var_row_data := 
          case when new."role_id" is null then '' else '"' || cast(cast(new."role_id" as numeric) as varchar) || '"' end||','||
          case when new."party_id" is null then '' else '"' || cast(cast(new."party_id" as numeric) as varchar) || '"' end; 
                                    var_old_data := 
          case when old."role_id" is null then '' else '"' || cast(cast(old."role_id" as numeric) as varchar) || '"' end||','||
          case when old."party_id" is null then '' else '"' || cast(cast(old."party_id" as numeric) as varchar) || '"' end; 
                                    if var_old_data is null or var_row_data != var_old_data then 
                                    insert into "public".sym_data                                                                                                                     
                                    (table_name, event_type, trigger_hist_id, pk_data, row_data, old_data, channel_id, transaction_id, source_node_id, external_data, create_time)                     
                                    values(                                                                                                                                                            
                                      'pim_party_role_to_party',                                                                                                                                            
                                      'U',                                                                                                                                                             
                                      482,                                                                                                                                             
                                      
          case when old."role_id" is null then '' else '"' || cast(cast(old."role_id" as numeric) as varchar) || '"' end||','||
          case when old."party_id" is null then '' else '"' || cast(cast(old."party_id" as numeric) as varchar) || '"' end,                                                                                                                                                      
                                      var_row_data,                                                                                                                                                      
                                      var_old_data,                                                                                                                                                   
                                      'public_pim_party_role_to_party_default',                                                                                                                                                
                                      txid_current(),                                                                                                                                               
                                      "public".sym_node_disabled(),                                                                                                                   
                                      null,                                                                                                                                               
                                      CURRENT_TIMESTAMP                                                                                                                
                                    );                                                                                                                                                                 
                                  end if;                                                                                                                                                              
                                  end if;                                                                                                                                                              
                                                                                                                                                                               
                                  return null;                                                                                                                                                         
                                end;
$$;

