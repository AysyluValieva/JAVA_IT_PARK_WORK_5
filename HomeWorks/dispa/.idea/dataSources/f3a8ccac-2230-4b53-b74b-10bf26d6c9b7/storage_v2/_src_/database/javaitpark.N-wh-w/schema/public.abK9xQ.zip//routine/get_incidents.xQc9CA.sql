CREATE FUNCTION get_incidents(mc_case_id integer)
  RETURNS character varying
LANGUAGE plpgsql
AS $$
declare
    incidents character varying := '';
    accident record;
begin
    for accident in
          (
            select mat.name from mc_accident mca
            left join mc_accident_type mat on mat.id = mca.type_id
            where mca.case_id = mc_case_id
          )

    loop
       if incidents <> '' then
          incidents := incidents || ', ';
       end if;
      incidents := incidents || accident.name;
    end loop;

    return incidents;

end;
$$;

