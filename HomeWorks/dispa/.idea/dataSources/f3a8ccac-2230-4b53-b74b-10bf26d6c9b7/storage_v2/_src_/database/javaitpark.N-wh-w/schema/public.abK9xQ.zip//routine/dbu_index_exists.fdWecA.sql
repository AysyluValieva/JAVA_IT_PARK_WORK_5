CREATE FUNCTION dbu_index_exists(indexname character varying)
  RETURNS boolean
LANGUAGE plpgsql
AS $$
declare result boolean;
            begin

            select count(*) > 0 into result
            from pg_class
            inner join pg_index on pg_class.oid = pg_index.indexrelid
            inner join pg_namespace on pg_class.relnamespace = pg_namespace.oid
            and pg_namespace.nspname !~ '^(pg_|information_schema)'
            where pg_class.relkind = 'i'
            and pg_class.relname = lower($1);

            return result;
            end;
$$;

