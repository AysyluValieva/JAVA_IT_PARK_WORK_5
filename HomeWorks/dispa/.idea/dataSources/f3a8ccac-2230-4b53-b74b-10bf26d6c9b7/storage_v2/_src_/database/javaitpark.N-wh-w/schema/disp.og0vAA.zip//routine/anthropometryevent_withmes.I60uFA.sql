CREATE FUNCTION anthropometryevent_withmes(xid integer, xcaseid integer, xheight character varying, xweight character varying, xwaist character varying, xserviceid integer, xresource integer, xdate character varying, xmes integer DEFAULT NULL::integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
          i integer;
          msrid integer;
          stepid integer;
          oldstepid integer;
        begin
          update disp.md_event_anthro set height=CAST(xheight as real),
            weight=CAST(xweight as real),
            waist=CAST(xwaist as real),
            index_mass=CAST(CAST(xweight as real)/(CAST(xheight as real)/100 * CAST(xheight as real)/100) as real),
            type_mass=CASE WHEN (CAST(CAST(xweight as real)/(CAST(xheight as real)/100 * CAST(xheight as real)/100) as real) < 18.5) THEN 1
            WHEN (CAST(CAST(xweight as real)/(CAST(xheight as real)/100 * CAST(xheight as real)/100) as real) > 18.5 and CAST(CAST(xweight as real)/(CAST(xheight as real)/100 * CAST(xheight as real)/100) as real) < 24.9) THEN 2
            WHEN (CAST(CAST(xweight as real)/(CAST(xheight as real)/100 * CAST(xheight as real)/100) as real) > 25 and CAST(CAST(xweight as real)/(CAST(xheight as real)/100 * CAST(xheight as real)/100) as real) < 29.9) THEN 3
            WHEN (CAST(CAST(xweight as real)/(CAST(xheight as real)/100 * CAST(xheight as real)/100) as real) > 30 and CAST(CAST(xweight as real)/(CAST(xheight as real)/100 * CAST(xheight as real)/100) as real) < 34.9) THEN 4
            WHEN (CAST(CAST(xweight as real)/(CAST(xheight as real)/100 * CAST(xheight as real)/100) as real) > 35 and CAST(CAST(xweight as real)/(CAST(xheight as real)/100 * CAST(xheight as real)/100) as real) < 39.9) THEN 5
            WHEN (CAST(CAST(xweight as real)/(CAST(xheight as real)/100 * CAST(xheight as real)/100) as real) > 40) THEN 6
            ELSE NULL
            END
            where id = xid;
          if (select count(msr.id) from MD_SRV_RENDERED msr
              left join SR_SRV_RENDERED ssr on ssr.id = msr.id
              where msr.case_id = xcaseId and ssr.service_id = xserviceid) = 0 then
              i = nextval('sr_srv_rendered_seq');
              insert into SR_SRV_RENDERED (id, service_id, bdate, res_group_id, customer_id, is_rendered, edate, quantity, funding_id, org_id, payment_status_id)
                values (i, xserviceid, COALESCE(to_date(xdate, 'DD.MM.YYYY'), current_date), xresource, (select indiv_id from disp.md_event_patient where id = xid), TRUE, COALESCE(to_date(xdate, 'DD.MM.YYYY'), current_date), 1,
                (select me.pay_type from disp.md_event me left join disp.md_event_patient mep on mep.event_id=me.id  where mep.id=xid),
                (select me.org_id from disp.md_event_patient mep left join disp.md_event me on me.id = mep.event_id where mep.id = xid), 1);
              stepid = (select disp.find_insert_mc_step_withMes(xid, xdate, xcaseId, xresource, xmes));
              insert into MD_SRV_RENDERED (id, case_id, step_id) values (i, xcaseId, stepid);
          else
              select msr.id into msrid from MD_SRV_RENDERED msr join SR_SRV_RENDERED ssr on ssr.id = msr.id where msr.case_id = xcaseId and ssr.service_id = xserviceid;
              if (select res_group_id from SR_SRV_RENDERED where id = msrid) <> xresource then
                oldstepid = (select step_id from MD_SRV_RENDERED where id = msrid);
                stepid = (select disp.find_insert_mc_step_withMes(xid, xdate, xcaseId, xresource, xmes));
                update MD_SRV_RENDERED set step_id = stepid where id = msrid;
                if (select count(1) = 0 from md_srv_rendered where step_id = oldstepid) then
                  delete from mc_step where id = oldstepid;
                end if;
              end if;
              update SR_SRV_RENDERED set bdate = to_date(xdate, 'DD.MM.YYYY'), res_group_id = xresource
                where id = msrid;
              i = msrid;
          end if;
          -- change STATUS
          update disp.md_event_service_patient set status = 4
              where id = (select mesp.id from disp.md_event_patient mep
                left join disp.md_event_service_patient mesp on mesp.event_patient_id = mep.id
                inner join disp.md_event_service mes on mes.id = mesp.service_id and mes.service_id = xserviceid
                where mep.id = xid);
          return i;
        end;
$$;

