CREATE FUNCTION fsym_on_i_for_pblc_sr_srv_prttyp_mngrp()
  RETURNS trigger
LANGUAGE plpgsql
AS $fun$
begin                                                                                                                                                                  
                                   
                                  if 1=1 and "public".sym_triggers_disabled() = 0 then                                                                                                 
                                    insert into "public".sym_data                                                                                                                     
                                    (table_name, event_type, trigger_hist_id, row_data, channel_id, transaction_id, source_node_id, external_data, create_time)                                        
                                    values(                                                                                                                                                            
                                      'sr_srv_prototype',                                                                                                                                            
                                      'I',                                                                                                                                                             
                                      78,                                                                                                                                             
                                      
          case when new."id" is null then '' else '"' || cast(cast(new."id" as numeric) as varchar) || '"' end||','||
          case when new."code" is null then '' else '"' || replace(replace(cast(new."code" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."is_independent" is null then '' when new."is_independent" then '"1"' else '"0"' end||','||
          case when new."name" is null then '' else '"' || replace(replace(cast(new."name" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."is_remote" is null then '' when new."is_remote" then '"1"' else '"0"' end||','||
          case when new."terms" is null then '' else '"' || replace(replace(cast(new."terms" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."type_id" is null then '' else '"' || cast(cast(new."type_id" as numeric) as varchar) || '"' end||','||
          case when new."anesthesia_type" is null then '' when new."anesthesia_type" then '"1"' else '"0"' end||','||
          case when new."is_repeated" is null then '' when new."is_repeated" then '"1"' else '"0"' end||','||
          case when new."is_expendable_materials" is null then '' when new."is_expendable_materials" then '"1"' else '"0"' end||','||
          case when new."protocol_path" is null then '' else '"' || replace(replace(cast(new."protocol_path" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."report_path" is null then '' else '"' || replace(replace(cast(new."report_path" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."is_complete_protocol" is null then '' when new."is_complete_protocol" then '"1"' else '"0"' end||','||
          case when new."is_complex" is null then '' when new."is_complex" then '"1"' else '"0"' end||','||
          case when new."accounting_id" is null then '' else '"' || cast(cast(new."accounting_id" as numeric) as varchar) || '"' end||','||
          case when new."from_dt" is null then '' else '"' || to_char(new."from_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when new."to_dt" is null then '' else '"' || to_char(new."to_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when new."e_code" is null then '' else '"' || replace(replace(cast(new."e_code" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end,                                                                                                                                                      
                                      'public_sr_srv_prototype_default',                                                                                                                                                
                                      txid_current(),                                                                                                                                               
                                      "public".sym_node_disabled(),                                                                                                                   
                                      null,                                                                                                                                               
                                      CURRENT_TIMESTAMP                                                                                                                
                                    );                                                                                                                                                                 
                                  end if;                                                                                                                                                              
                                                                                                                                                                               
                                  return null;                                                                                                                                                         
                                end;
$fun$;

