CREATE FUNCTION apdam_check_code_in_diapason(codes character varying[], code_from character varying, code_to character varying)
  RETURNS boolean
LANGUAGE plpgsql
AS $$
DECLARE
  i INT;
BEGIN
  IF codes ISNULL THEN RETURN FALSE; END IF;
  IF code_from ISNULL THEN code_from = ''; END IF;

  IF code_to ISNULL
  THEN
    FOR i IN array_lower(codes, 1)..array_upper(codes, 1) LOOP
      IF codes[i] > code_from THEN RETURN TRUE; END IF;
    END LOOP;
  END IF;

  FOR i IN array_lower(codes, 1)..array_upper(codes, 1) LOOP
    IF codes[i] BETWEEN code_from AND code_to THEN RETURN TRUE; END IF;
  END LOOP;

  RETURN FALSE;
END;
$$;

