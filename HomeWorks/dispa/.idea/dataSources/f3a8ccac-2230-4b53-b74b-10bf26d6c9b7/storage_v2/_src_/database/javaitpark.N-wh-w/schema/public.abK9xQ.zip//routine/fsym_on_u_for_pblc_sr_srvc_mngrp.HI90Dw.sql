CREATE FUNCTION fsym_on_u_for_pblc_sr_srvc_mngrp()
  RETURNS trigger
LANGUAGE plpgsql
AS $fun$
declare var_row_data text; 
                                declare var_old_data text; 
                                begin
                                   
                                  if 1=1 and "public".sym_triggers_disabled() = 0 then                                                                                                 
                                    var_row_data := 
          case when new."id" is null then '' else '"' || cast(cast(new."id" as numeric) as varchar) || '"' end||','||
          case when new."code" is null then '' else '"' || replace(replace(cast(new."code" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."cul" is null then '' else '"' || cast(cast(new."cul" as numeric) as varchar) || '"' end||','||
          case when new."is_death" is null then '' when new."is_death" then '"1"' else '"0"' end||','||
          case when new."duration" is null then '' else '"' || cast(cast(new."duration" as numeric) as varchar) || '"' end||','||
          case when new."is_fictitious" is null then '' when new."is_fictitious" then '"1"' else '"0"' end||','||
          case when new."is_independent" is null then '' when new."is_independent" then '"1"' else '"0"' end||','||
          case when new."is_multuplicity" is null then '' when new."is_multuplicity" then '"1"' else '"0"' end||','||
          case when new."name" is null then '' else '"' || replace(replace(cast(new."name" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."terms" is null then '' else '"' || replace(replace(cast(new."terms" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."org_id" is null then '' else '"' || cast(cast(new."org_id" as numeric) as varchar) || '"' end||','||
          case when new."category_id" is null then '' else '"' || cast(cast(new."category_id" as numeric) as varchar) || '"' end||','||
          case when new."duration_unit_id" is null then '' else '"' || cast(cast(new."duration_unit_id" as numeric) as varchar) || '"' end||','||
          case when new."prototype_id" is null then '' else '"' || cast(cast(new."prototype_id" as numeric) as varchar) || '"' end||','||
          case when new."type_id" is null then '' else '"' || cast(cast(new."type_id" as numeric) as varchar) || '"' end||','||
          case when new."from_dt" is null then '' else '"' || to_char(new."from_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when new."to_dt" is null then '' else '"' || to_char(new."to_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when new."is_repeated" is null then '' when new."is_repeated" then '"1"' else '"0"' end||','||
          case when new."is_inherit_protocol" is null then '' when new."is_inherit_protocol" then '"1"' else '"0"' end||','||
          case when new."is_expendable_materials" is null then '' when new."is_expendable_materials" then '"1"' else '"0"' end||','||
          case when new."is_actual_cul" is null then '' when new."is_actual_cul" then '"1"' else '"0"' end||','||
          case when new."is_paraclinical" is null then '' when new."is_paraclinical" then '"1"' else '"0"' end||','||
          case when new."is_complex" is null then '' when new."is_complex" then '"1"' else '"0"' end||','||
          case when new."accounting_id" is null then '' else '"' || cast(cast(new."accounting_id" as numeric) as varchar) || '"' end||','||
          case when new."is_autocopy_diagnoses" is null then '' when new."is_autocopy_diagnoses" then '"1"' else '"0"' end||','||
          case when new."is_stomat" is null then '' when new."is_stomat" then '"1"' else '"0"' end||','||
          case when new."srg_dif_type_id" is null then '' else '"' || cast(cast(new."srg_dif_type_id" as numeric) as varchar) || '"' end||','||
          case when new."srg_opr_kind_id" is null then '' else '"' || cast(cast(new."srg_opr_kind_id" as numeric) as varchar) || '"' end||','||
          case when new."is_need_anatomic_zone" is null then '' when new."is_need_anatomic_zone" then '"1"' else '"0"' end||','||
          case when new."is_filling" is null then '' when new."is_filling" then '"1"' else '"0"' end||','||
          case when new."is_extraction" is null then '' when new."is_extraction" then '"1"' else '"0"' end||','||
          case when new."is_need_close_date" is null then '' when new."is_need_close_date" then '"1"' else '"0"' end||','||
          case when new."short_name" is null then '' else '"' || replace(replace(cast(new."short_name" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."is_vmp" is null then '' when new."is_vmp" then '"1"' else '"0"' end; 
                                    var_old_data := 
          case when old."id" is null then '' else '"' || cast(cast(old."id" as numeric) as varchar) || '"' end||','||
          case when old."code" is null then '' else '"' || replace(replace(cast(old."code" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when old."cul" is null then '' else '"' || cast(cast(old."cul" as numeric) as varchar) || '"' end||','||
          case when old."is_death" is null then '' when old."is_death" then '"1"' else '"0"' end||','||
          case when old."duration" is null then '' else '"' || cast(cast(old."duration" as numeric) as varchar) || '"' end||','||
          case when old."is_fictitious" is null then '' when old."is_fictitious" then '"1"' else '"0"' end||','||
          case when old."is_independent" is null then '' when old."is_independent" then '"1"' else '"0"' end||','||
          case when old."is_multuplicity" is null then '' when old."is_multuplicity" then '"1"' else '"0"' end||','||
          case when old."name" is null then '' else '"' || replace(replace(cast(old."name" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when old."terms" is null then '' else '"' || replace(replace(cast(old."terms" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when old."org_id" is null then '' else '"' || cast(cast(old."org_id" as numeric) as varchar) || '"' end||','||
          case when old."category_id" is null then '' else '"' || cast(cast(old."category_id" as numeric) as varchar) || '"' end||','||
          case when old."duration_unit_id" is null then '' else '"' || cast(cast(old."duration_unit_id" as numeric) as varchar) || '"' end||','||
          case when old."prototype_id" is null then '' else '"' || cast(cast(old."prototype_id" as numeric) as varchar) || '"' end||','||
          case when old."type_id" is null then '' else '"' || cast(cast(old."type_id" as numeric) as varchar) || '"' end||','||
          case when old."from_dt" is null then '' else '"' || to_char(old."from_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when old."to_dt" is null then '' else '"' || to_char(old."to_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when old."is_repeated" is null then '' when old."is_repeated" then '"1"' else '"0"' end||','||
          case when old."is_inherit_protocol" is null then '' when old."is_inherit_protocol" then '"1"' else '"0"' end||','||
          case when old."is_expendable_materials" is null then '' when old."is_expendable_materials" then '"1"' else '"0"' end||','||
          case when old."is_actual_cul" is null then '' when old."is_actual_cul" then '"1"' else '"0"' end||','||
          case when old."is_paraclinical" is null then '' when old."is_paraclinical" then '"1"' else '"0"' end||','||
          case when old."is_complex" is null then '' when old."is_complex" then '"1"' else '"0"' end||','||
          case when old."accounting_id" is null then '' else '"' || cast(cast(old."accounting_id" as numeric) as varchar) || '"' end||','||
          case when old."is_autocopy_diagnoses" is null then '' when old."is_autocopy_diagnoses" then '"1"' else '"0"' end||','||
          case when old."is_stomat" is null then '' when old."is_stomat" then '"1"' else '"0"' end||','||
          case when old."srg_dif_type_id" is null then '' else '"' || cast(cast(old."srg_dif_type_id" as numeric) as varchar) || '"' end||','||
          case when old."srg_opr_kind_id" is null then '' else '"' || cast(cast(old."srg_opr_kind_id" as numeric) as varchar) || '"' end||','||
          case when old."is_need_anatomic_zone" is null then '' when old."is_need_anatomic_zone" then '"1"' else '"0"' end||','||
          case when old."is_filling" is null then '' when old."is_filling" then '"1"' else '"0"' end||','||
          case when old."is_extraction" is null then '' when old."is_extraction" then '"1"' else '"0"' end||','||
          case when old."is_need_close_date" is null then '' when old."is_need_close_date" then '"1"' else '"0"' end||','||
          case when old."short_name" is null then '' else '"' || replace(replace(cast(old."short_name" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when old."is_vmp" is null then '' when old."is_vmp" then '"1"' else '"0"' end; 
                                    if var_old_data is null or var_row_data != var_old_data then 
                                    insert into "public".sym_data                                                                                                                     
                                    (table_name, event_type, trigger_hist_id, pk_data, row_data, old_data, channel_id, transaction_id, source_node_id, external_data, create_time)                     
                                    values(                                                                                                                                                            
                                      'sr_service',                                                                                                                                            
                                      'U',                                                                                                                                                             
                                      18290,                                                                                                                                             
                                      
          case when old."id" is null then '' else '"' || cast(cast(old."id" as numeric) as varchar) || '"' end,                                                                                                                                                      
                                      var_row_data,                                                                                                                                                      
                                      var_old_data,                                                                                                                                                   
                                      'public_sr_service_default',                                                                                                                                                
                                      txid_current(),                                                                                                                                               
                                      "public".sym_node_disabled(),                                                                                                                   
                                      null,                                                                                                                                               
                                      CURRENT_TIMESTAMP                                                                                                                
                                    );                                                                                                                                                                 
                                  end if;                                                                                                                                                              
                                  end if;                                                                                                                                                              
                                                                                                                                                                               
                                  return null;                                                                                                                                                         
                                end;
$fun$;

