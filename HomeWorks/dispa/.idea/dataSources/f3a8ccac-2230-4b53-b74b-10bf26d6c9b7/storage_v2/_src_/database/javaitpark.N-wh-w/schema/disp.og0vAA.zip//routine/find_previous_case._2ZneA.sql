CREATE FUNCTION find_previous_case(xresultid integer)
  RETURNS character varying
LANGUAGE plpgsql
AS $$
declare
          case_name character varying;
          result_id integer;
          cur_mep record;
          diag record;
        begin
	  select mep.event_id, mep.indiv_id, mc.open_date, mc.init_goal_id into cur_mep
	  from disp.md_disp_orphans_result mdor
	  join disp.md_event_patient mep on mep.id = mdor.event_patient_id
          join mc_case mc on mc.id = mep.case_id
	  where mdor.id = xresultid;

          select 'от ' || to_char(mc.open_date,'DD.MM.YYYY') || ', номер: ' || mc.uid into case_name from disp.md_event_patient mep
          join mc_case mc on mc.id = mep.case_id
          join mc_step ms on mc.closing_step_id = ms.id
          where mep.indiv_id = cur_mep.indiv_id
          and mc.init_goal_id = cur_mep.init_goal_id
          and ms.admission_date < cur_mep.open_date
          order by ms.admission_date desc
          limit 1;

          return case_name;

        end;
$$;

