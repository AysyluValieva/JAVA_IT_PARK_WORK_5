CREATE FUNCTION get_commission_issue_diagnosis_full_name(com_issue_id integer)
  RETURNS text
LANGUAGE plpgsql
AS $$
DECLARE
    full_name text;
  BEGIN
    SELECT concat_ws(' ', md_d.code, tt.subcode, concat_ws(', ', md_d.name, tt.subname)) INTO full_name
    FROM
  		public.commission_issue ci
        join public.md_diagnosis md_d ON md_d.id = ci.diagnosis_id
        left join (select cida.commission_issue_id,
                    array_to_string(array_agg(av.value order by ap.pos), '.') as subcode,
					array_to_string(array_agg(av.name order by ap.pos), '; ') as subname
                    from public.commission_issue_diag_attr cida
                    join public.commission_issue c on c.id=cida.commission_issue_id
                    join public.md_attr_value av on av.id=cida.attr_value_id
                    join public.md_diag_attr mda on mda.id=av.diag_attr_id
                    join public.md_attr_pos ap on ap.diag_attr_id=mda.id and ap.diagnosis_id=c.diagnosis_id
                    group by cida.commission_issue_id) as tt on tt.commission_issue_id = ci.id
       WHERE ci.id=com_issue_id;
    RETURN full_name;
  END;
$$;

