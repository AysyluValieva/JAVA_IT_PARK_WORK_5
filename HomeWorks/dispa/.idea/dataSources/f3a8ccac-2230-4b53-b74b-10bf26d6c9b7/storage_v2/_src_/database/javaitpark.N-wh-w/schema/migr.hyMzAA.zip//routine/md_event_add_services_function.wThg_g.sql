CREATE FUNCTION md_event_add_services_function(xcardid integer, xeid integer, xpid integer, xservices character varying, xservicesduplicates character varying)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
                i integer;
                serviceid json;
                serviceDuplicateid json;
                j integer;
                b boolean;
		        eventServicePatientIdRec record;
		        eventServicePatientId integer;
		        f boolean;
            begin
                i = xcardid;
                for eventServicePatientIdRec in
		          (select es.id, esp.id espId from disp.md_event_service es
		           join disp.md_event_service_patient esp on es.id = esp.service_id
		           where esp.event_patient_id = xcardid)
		        loop
		          f = false;
		          foreach serviceid in array array(select value from json_array_elements(cast(xservices as json)))
		          loop
		            if (eventServicePatientIdRec.id = serviceid::text::int) then
		              f = true;
		              exit;
		            end if;
		          end loop;
		          if (not f) then
		            delete from migr.md_migr_service where event_service_patient_id = eventServicePatientIdRec.espId;
		            delete from disp.md_event_service_patient where id = eventServicePatientIdRec.espId;
		          end if;
		        end loop;

		        foreach serviceid in array array(select value from json_array_elements(cast(xservices as json)))
                LOOP
		          select coalesce((select id from disp.md_event_service_patient esp where service_id = serviceid::text::int and event_patient_id = i), null) into eventServicePatientId;
		          if (eventServicePatientId is null) then
		            j = nextval('disp.md_event_service_patient_id_seq');
                    insert into disp.md_event_service_patient (id, service_id, indiv_id, event_id, event_patient_id,status) values (j, serviceid::text::int, xpid, xeid, i,1);
                  end if;

                  b = false;
                  foreach serviceDuplicateid in array array(select value from json_array_elements(cast(xservicesDuplicates as json)))
		          LOOP
		            if serviceid::text::int = serviceDuplicateid::text::int then
		              b = true;
		              exit;
		            end if;
                  END LOOP;
		          if (eventServicePatientId is null) then
                    insert into migr.md_migr_service (id, event_patient_id, event_service_patient_id, is_duplicate) values (nextval('migr.md_migr_service_seq'), i, j, b);
		          else
		            update migr.md_migr_service set is_duplicate = b where event_service_patient_id = eventServicePatientId;
		          end if;
                END LOOP;
                return i;
            end;
$$;

