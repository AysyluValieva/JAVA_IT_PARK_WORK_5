CREATE FUNCTION migration_get_row_change_type(_type integer)
  RETURNS text
LANGUAGE plpgsql
AS $$
BEGIN
  RETURN (CASE _type
          WHEN 0
            THEN 'I'
          WHEN 1
            THEN 'U'
          WHEN 2
            THEN 'D'
          ELSE NULL
          END);
END;
$$;

