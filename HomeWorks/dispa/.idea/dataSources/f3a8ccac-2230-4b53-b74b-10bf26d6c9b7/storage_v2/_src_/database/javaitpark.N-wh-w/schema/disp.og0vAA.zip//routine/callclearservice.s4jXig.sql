CREATE FUNCTION callclearservice(xepid integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
          
          caseId integer;
          xcheckservices character varying;
          mespId integer;
          status_service integer;
          mesId integer;
          sr_service integer;
          checkserviceId json;
        begin

          
		caseId=(select case_id from disp.md_event_patient where id=xepid);
          xcheckservices=(select array_to_json(array_agg(row_to_json(serv))) from (select id as id  from disp.md_event_service_patient where event_patient_id=xepid  and status is not null) as serv);
          if xcheckservices IS NOT NULL THEN
                --проставляют услуги по назначению (автомат)
                      foreach checkserviceId in array array(select value from json_array_elements(cast(xcheckservices as json)))
                      

                                LOOP
                                    mespId=cast(checkserviceId::json->>'id' as integer);
                                    status_service = (select status from  disp.md_event_service_patient where id=mespId and status is not null);
                                    if status_service is not null then
                                    mesId = (select mes.id from disp.md_event_service mes 
                                              left join disp.md_event_service_patient mesp on mesp.service_id=mes.id  where 
                                              mesp.id=mespId);

                                    sr_service= (select CASE status_service WHEN 4 THEN (select ssr.id
                                              from disp.md_event_service_patient mesp
                                              left join disp.md_event_service mes on mes.id=mesp.service_id
                                              inner join SR_SRV_RENDERED ssr on ssr.service_id = mes.service_id
                                              left join  MD_SRV_RENDERED msr on ssr.id = msr.id
                                              where msr.case_id = caseId and mesp.id=mespId limit 1 
                                               )
                                        WHEN 3 THEN ( select ssr.id from disp.md_event_service_patient mesp
                                              left join disp.md_event_service mes on mes.id=mesp.service_id
                                              left join disp.md_event_service_link mesl on mesl.event_service_id = mes.id
                                               inner join SR_SRV_RENDERED ssr on ssr.id = mesl.service_id
                                               where mesl.case_id = caseId and mesl.event_service_id =  (select mes.service_id from disp.md_event_service mes
                                                left join disp.md_event_service_patient mesp on mesp.service_id=mes.id where mesp.id = mespId)limit 1

                                              )
                                                ELSE NULL
                                               END);

                  PERFORM disp.clearService(sr_service, mespId, caseId, mesId);
                  
                
                  end if;
                 end loop;
                 
                 end if;
                 
          return 1;
        end;
$$;

