CREATE FUNCTION get_doc_numbers_for_batch(rec_store_sup integer)
  RETURNS text
LANGUAGE plpgsql
AS $$
DECLARE
  docsStr  text= '';
  rec record;
  t text ='';
BEGIN

   FOR rec IN (SELECT DISTINCT inv.id AS invId,concat(SUBSTRING(dt.short_name,1,4) ,'. ',inv.int_doc_number,' от ', to_char(inv.int_doc_dt, 'DD.MM.YYYY')) AS doc FROM inventory.store_opr_jur jur
      INNER JOIN inventory.document inv ON inv.id=jur.doc_id
      INNER JOIN inventory.document_type dt ON inv.int_doc_type_id=dt.id
      WHERE jur.rec_store_sup_id = rec_store_sup )
      loop
        if(docsStr <> '') THEN t = ','; END if;
        docsStr = docsStr||t||rec.doc;
      END loop;

return docsStr;
END;
$$;

