CREATE FUNCTION add_res_team_job(xteam integer, xchange integer, xreg integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
                job integer;
                xplanbd TIMESTAMP WITHOUT TIME ZONE;
                xplaned TIMESTAMP WITHOUT TIME ZONE;
              begin
                --пока так, но надо переделать на независимость от смены видимо, либо ещё усложнить условие
                select into xplanbd,xplaned cast(from_data+from_time as TIMESTAMP),cast(to_data+to_time as TIMESTAMP)
                    from amb.md_ambulance_change where id =  xchange;
                if not exists (select * from amb.sr_res_team_job where team_id = xteam and change_id = xchange)
                  then
                    job := nextval('amb.sr_res_team_job_id_seq');
                    insert into amb.sr_res_team_job (id,team_id,change_id,planned_bdate,planned_edate,registrator_id)
                        values (job,xteam,xchange,xplanbd,xplaned,xreg);
                  else
                    job := (select id from amb.sr_res_team_job where team_id = xteam and change_id = xchange);
                end if;
                return job;
              end;
$$;

