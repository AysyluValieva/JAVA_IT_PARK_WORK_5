CREATE FUNCTION md_event_add_migrant_function(xcardid integer, xeid integer, xpid integer, xlatinsurname character varying, xlatinname character varying, xlatinpatrname character varying, xcountryid integer, xpurposeid integer, xplanperiodid integer, xbegin date, xend date, xcreate date)
  RETURNS integer
LANGUAGE plpgsql
AS $$
DECLARE
  i INTEGER;
  c INTEGER;
BEGIN
  IF (xcardid IS NULL)
  THEN
    i = nextval('disp.md_event_patient_id_seq');
    INSERT INTO disp.md_event_patient (id, event_id, indiv_id) VALUES (i, xeid, xpid);
    INSERT INTO migr.md_migr_card (id, plan_period_id, begin_date, end_date, purpose_id, country_id, status_id, indiv_id,
                                   create_date)
    VALUES (i, xplanperiodid,
            xbegin, xend, xpurposeid, xcountryid, 1, xpid, xcreate);
    PERFORM gibdd.agreedisprforpatient(NULL :: INTEGER, to_char(xcreate, 'DD-MM-YYYY'), i);

--     begin: Добавление обязательных услуг
    PERFORM migr.md_event_add_services_function(i,xeid,xpid,
                                               '['||(select  string_agg(id::text, ',') as serviceIs
                                                     from disp.md_event_service
                                                     WHERE event_id = xeid
                                                           AND required is TRUE)||']',
                                               null);
--     end: Добавление обязательных услуг

  ELSE
    i = xcardid;

    IF (SELECT count(id)
        FROM disp.md_event_service_patient
        WHERE event_patient_id = xcardid AND status = 4) = 0
    THEN
      UPDATE MC_CASE
      SET open_date = xcreate
      WHERE id = (SELECT case_id
                  FROM disp.md_event_patient
                  WHERE id = xcardid);
    END IF;

    UPDATE migr.md_migr_card
    SET plan_period_id = xplanperiodid, begin_date = xbegin, end_date = xend, purpose_id = xpurposeid,
      country_id       = xcountryid, indiv_id = xpid,
      create_date      = xcreate
    WHERE id = xcardid;
  END IF;

  SELECT count(1)
  INTO c
  FROM migr.md_migr_patient
  WHERE id = xpid;
  IF (c > 0)
  THEN
    UPDATE migr.md_migr_patient
    SET latin_name = xlatinname, latin_surname = xlatinsurname, latin_patrname = xlatinpatrname
    WHERE id = xpid;
  ELSE
    INSERT INTO migr.md_migr_patient (id, latin_name, latin_surname, latin_patrname)
    VALUES (xpid, xlatinname, xlatinsurname, xlatinpatrname);
  END IF;

  RETURN i;
END;
$$;

