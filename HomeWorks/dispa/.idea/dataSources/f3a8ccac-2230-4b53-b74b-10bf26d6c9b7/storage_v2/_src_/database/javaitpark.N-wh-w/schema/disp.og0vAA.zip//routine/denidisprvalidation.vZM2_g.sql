CREATE FUNCTION denidisprvalidation(xstatus integer, xepid integer, realservices character varying)
  RETURNS character varying
LANGUAGE plpgsql
AS $$
declare
    xserviceid json;
    mesp integer;
    results text[];
    ssrid integer;
  begin
	IF xstatus=1 THEN
	  foreach xserviceid in array array(select value from json_array_elements(cast(realServices as json)))
	  LOOP
	    mesp=xserviceid::text::int;
	    select ssr.id into ssrid
      from disp.md_event_patient mep
	    join disp.md_event_service_patient esp on esp.event_patient_id = mep.id
	    join disp.md_event_service mes on mes.id = esp.service_id
	    join MD_SRV_RENDERED msr on msr.case_id = mep.case_id
      join SR_SRV_RENDERED ssr on ssr.id = msr.id and ssr.service_id = mes.service_id
	    where mep.id = xepid and esp.id = mesp;
	    if (select count(1) > 0 from fin_bill_spec_item where service_id = ssrid) then
	      results:=array_append(results, (select ss.name from SR_SRV_RENDERED ssr join sr_service ss on ssr.service_id = ss.id where ssr.id = ssrid)::text);
	    end if;
	  END LOOP;
	ELSIF xstatus = 2 THEN
	  select array(select ss.name
    from disp.md_event_patient mep
	  join disp.md_event_service_patient esp on esp.event_patient_id = mep.id
	  join disp.md_event_service mes on mes.id = esp.service_id
	  join MD_SRV_RENDERED msr on msr.case_id = mep.case_id
    join SR_SRV_RENDERED ssr on ssr.id = msr.id and ssr.service_id = mes.service_id
	  join sr_service ss on ss.id = ssr.service_id
	  join fin_bill_spec_item fbsi on fbsi.service_id = ssr.id
	  where mep.id = xepid) into results;
	END IF;
	return array_to_string(results,', ');
	end;
$$;

