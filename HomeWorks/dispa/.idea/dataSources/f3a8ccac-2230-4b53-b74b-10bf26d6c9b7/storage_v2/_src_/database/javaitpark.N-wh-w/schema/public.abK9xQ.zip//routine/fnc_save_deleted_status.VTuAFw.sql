CREATE FUNCTION fnc_save_deleted_status()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
    IF 
        NEW.is_deleted AND NOT EXISTS (SELECT 1 FROM billing.fin_bill_deleted_services WHERE bill_id = NEW.bill_id AND srv_rendered_id = NEW.service_id)
    THEN 
        INSERT INTO billing.fin_bill_deleted_services (bill_id, srv_rendered_id) VALUES (NEW.bill_id, NEW.service_id);
    ELSE
        DELETE FROM billing.fin_bill_deleted_services WHERE bill_id = NEW.bill_id AND srv_rendered_id = NEW.service_id;
    END IF;
    RETURN NULL;
END;
$$;

