CREATE FUNCTION md_event_add_migrant_function(xcardid integer, xeid integer, xpid integer, xlatinsurname character varying, xlatinname character varying, xlatinpatrname character varying, xcountryid integer, xpurposeid integer, xplanperiodid integer, xbegin date, xend date, xcreate date, xcertificate character varying, xconclusion character varying, xcertificateseries character varying DEFAULT NULL::character varying, xconclusionseries character varying DEFAULT NULL::character varying)
  RETURNS integer
LANGUAGE plpgsql
AS $$
DECLARE
  i INTEGER;
  c INTEGER;
BEGIN
  IF (xcardid IS NULL)
  THEN
    i = nextval('disp.md_event_patient_id_seq');
    INSERT INTO disp.md_event_patient (id, event_id, indiv_id) VALUES (i, xeid, xpid);
    INSERT INTO migr.md_migr_card (id, plan_period_id, begin_date, end_date, purpose_id, certificate_number, conclusion_number, country_id, status_id, indiv_id,
                                   certificate_series, conclusion_series, create_date)
    VALUES (i, xplanperiodid,
            xbegin, xend, xpurposeid, xcertificate, xconclusion, xcountryid, 1, xpid, xcertificateseries, xconclusionseries, xcreate);
    PERFORM gibdd.agreedisprforpatient(NULL :: INTEGER, to_char(xcreate, 'DD-MM-YYYY'), i);
  ELSE
    i = xcardid;

    IF (select count(id) from disp.md_event_service_patient where event_patient_id = xcardid and status = 4) = 0
    THEN
		  UPDATE MC_CASE
		  SET open_date = xcreate
		  WHERE id = (SELECT case_id FROM disp.md_event_patient WHERE id = xcardid);
	  END IF;

    UPDATE migr.md_migr_card
    SET plan_period_id   = xplanperiodid, begin_date = xbegin, end_date = xend, purpose_id = xpurposeid,
      certificate_number = xcertificate, conclusion_number = xconclusion, country_id = xcountryid, indiv_id = xpid,
      certificate_series = xcertificateseries, conclusion_series = xconclusionseries, create_date = xcreate
    WHERE id = xcardid;
  END IF;

  SELECT count(1)
  INTO c
  FROM migr.md_migr_patient
  WHERE id = xpid;
  IF (c > 0)
  THEN
    UPDATE migr.md_migr_patient
    SET latin_name = xlatinname, latin_surname = xlatinsurname, latin_patrname = xlatinpatrname
    WHERE id = xpid;
  ELSE
    INSERT INTO migr.md_migr_patient (id, latin_name, latin_surname, latin_patrname)
    VALUES (xpid, xlatinname, xlatinsurname, xlatinpatrname);
  END IF;

  RETURN i;
END;
$$;

