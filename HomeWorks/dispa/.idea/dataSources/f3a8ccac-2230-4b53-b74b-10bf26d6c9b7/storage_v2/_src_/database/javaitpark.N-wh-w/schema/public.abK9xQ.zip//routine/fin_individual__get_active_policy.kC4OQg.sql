CREATE FUNCTION fin_individual__get_active_policy(p1_individual_id integer, p2_date date, OUT policy_id integer)
  RETURNS integer
STABLE
LANGUAGE plpgsql
AS $$
DECLARE
    _enp_type_id INTEGER := (SELECT id FROM pim_doc_type WHERE code = 'MHI_UNIFORM');
    _tmp_type_id INTEGER := (SELECT id FROM pim_doc_type WHERE code = 'MHI_TEMP');
    _old_type_id INTEGER := (SELECT id FROM pim_doc_type WHERE code = 'MHI_OLDER');
BEGIN
    SELECT
        id INTO policy_id
    FROM
        pim_individual_doc
    WHERE
        indiv_id = p1_individual_id
        AND type_id = ANY (ARRAY[_enp_type_id, _tmp_type_id, _old_type_id])
        AND (p2_date >= issue_dt OR issue_dt IS NULL) AND (p2_date <= expire_dt OR expire_dt IS NULL)
    ORDER BY is_active DESC NULLS LAST, type_id = _enp_type_id DESC, type_id = _tmp_type_id DESC, type_id = _old_type_id DESC, id DESC
    LIMIT 1
    ;
END;
$$;

