CREATE FUNCTION fin_fill_pivot_bill_main_extended_table(p1_bill_id integer)
  RETURNS void
STRICT
LANGUAGE plpgsql
AS $$
DECLARE 
    _oms_id INTEGER;
    _inn_id INTEGER;
    _grn_id INTEGER;
    _kpp_id INTEGER;
BEGIN
    /*
        current version date 2014-12-22
    */
    IF EXISTS (SELECT 1 FROM fin_bill_main_extended WHERE bill_id = p1_bill_id) THEN DELETE FROM fin_bill_main_extended WHERE bill_id = p1_bill_id; END IF;
    
    _oms_id  = (SELECT id FROM pim_code_type WHERE code = 'CODE_OMS'        );
    _inn_id  = (SELECT id FROM pim_code_type WHERE code = 'INN_ORGANIZATION');
    _grn_id  = (SELECT id FROM pim_code_type WHERE code = 'OGRN'            );
    _kpp_id  = (SELECT id FROM pim_code_type WHERE code = 'KPP'             );
    
    INSERT INTO fin_bill_main_extended 
    (
        --------------счёт---------------
        main_bill_id,
        bill_id,
        bill_number,
        bill_package_number,
        bill_comment,
        bill_price_commentary,
        bill_date,
        bill_generate_date,
        bill_full_year,
        bill_year,
        bill_month,
        bill_from_date,
        bill_to_date,
        bill_price_list_id,
        bill_is_additional,
        bill_is_correctional,
        bill_fin_type_code,
        bill_is_local,
        bill_is_foreign,
        bill_is_nopolicy,
        --получатель (recipient) платежа (больница)--
        rcp_id,
        rcp_short_name,
        rcp_full_name,
        rcp_code_oms,
        rcp_inn,
        rcp_ogrn,
        rcp_kpp,
        rcp_contact_email,
        --плательщик (payer) (страховая)--
        payer_id,
        payer_short_name,
        payer_full_name,
        payer_role,
        payer_code_oms,
        payer_inn,
        payer_kpp
    )
        WITH 
        role_refbook AS
        (
            SELECT unnest (ARRAY['T', 'M', 'S']) AS role_code, unnest (ARRAY['HIF_ORGANIZATION', 'CLINIC_ORGANIZATION', 'MEDICAL_INSURANCE_ORGANIZATION']) AS role
        ),
        bill AS 
        (
            SELECT
                m.id AS main_bill_id,
                b.id AS bill_id,
                m.payer_id,
                m.clinic_id,
                b.package_number AS bill_package_number,
                coalesce (trim (b.number), '') AS bill_number,
                coalesce (trim (b.comment), '') AS bill_comment,
                coalesce (trim (l.commentary), '') AS bill_price_commentary,
                b.date AS bill_date,
                CURRENT_DATE AS bill_generate_date,
                to_char (m.to_date, 'YYYY') AS bill_full_year,
                to_char (m.to_date, 'YY') AS bill_year,
                to_char (m.to_date, 'MM') AS bill_month,
                m.from_date AS bill_from_date,
                m.to_date AS bill_to_date,
                m.price_list_id AS bill_price_list_id,
                a.id IS NOT NULL AS bill_is_additional,
                c.id IS NOT NULL AS bill_is_correctional,
                coalesce (trim (s.code), '') AS bill_fin_type_code
            FROM
                fin_bill                          AS b 
                JOIN fin_bill_main                AS m ON fin_bill__get_main_bill (b.id) = m.id 
                LEFT JOIN fin_price_list          AS l ON l.id = m.price_list_id
                LEFT JOIN fin_bill_additional     AS a ON a.base_id = m.id AND a.id = b.id
                LEFT JOIN fin_bill_correctional   AS c ON c.base_id = m.id AND c.id = b.id
                LEFT JOIN fin_funding_source_type AS s ON s.id = m.financing_type_id
            WHERE
                b.id = p1_bill_id
        ),
        bill_insurance_affiliation AS 
        (
            SELECT
                b.main_bill_id,
                coalesce (0 = ANY (array_agg (r.region_id)), TRUE) AS bill_is_local,
                coalesce (1 = ANY (array_agg (r.region_id)), TRUE) AS bill_is_foreign,
                coalesce (2 = ANY (array_agg (r.region_id)), TRUE) AS bill_is_nopolicy
            FROM
                bill                              AS b
                LEFT JOIN fin_bill_main_to_region AS r ON r.main_bill_id = b.main_bill_id
            GROUP BY 1
        ),
        recipient AS 
        (
            SELECT
                b.bill_id,
                r.id AS rcp_id,
                coalesce (trim (r.short_name), '') AS rcp_short_name,
                coalesce (trim (r.full_name), '') AS rcp_full_name,
                (array_agg (coalesce (trim (o.code), '') ORDER BY o.issue_dt DESC NULLS LAST))[1] AS rcp_code_oms,
                (array_agg (coalesce (trim (i.code), '') ORDER BY i.issue_dt DESC NULLS LAST))[1] AS rcp_inn,
                (array_agg (coalesce (trim (g.code), '') ORDER BY g.issue_dt DESC NULLS LAST))[1] AS rcp_ogrn,
                (array_agg (coalesce (trim (k.code), '') ORDER BY k.issue_dt DESC NULLS LAST))[1] AS rcp_kpp,
                (array_agg (coalesce (trim (v.value), '') ORDER BY v.id DESC))[1] AS rcp_contact_email
            FROM
                bill                       AS b
                LEFT JOIN pim_organization AS r ON r.id = b.clinic_id
                LEFT JOIN pim_org_code     AS o ON o.org_id = b.clinic_id AND o.type_id = _oms_id
                LEFT JOIN pim_org_code     AS i ON i.org_id = b.clinic_id AND i.type_id = _inn_id
                LEFT JOIN pim_org_code     AS g ON g.org_id = b.clinic_id AND g.type_id = _grn_id
                LEFT JOIN pim_org_code     AS k ON k.org_id = b.clinic_id AND k.type_id = _kpp_id
                LEFT JOIN pim_org_contact  AS v ON v.org_id = b.clinic_id AND v.type_id = 4
            GROUP BY 1, 2, 3, 4
        ),
        payer AS 
        (
            SELECT
                b.bill_id,
                p.id AS payer_id,
                coalesce (trim (p.short_name), '') AS payer_short_name,
                coalesce (trim (p.full_name), '') AS payer_full_name,
                (array_agg (e.role_code ORDER BY e.role_code))[1] AS payer_role,
                (array_agg (coalesce (trim (o.code), '') ORDER BY o.issue_dt DESC NULLS LAST))[1] AS payer_code_oms,
                (array_agg (coalesce (trim (i.code), '') ORDER BY i.issue_dt DESC NULLS LAST))[1] AS payer_inn,
                (array_agg (coalesce (trim (k.code), '') ORDER BY k.issue_dt DESC NULLS LAST))[1] AS payer_kpp
            FROM
                bill                              AS b
                LEFT JOIN pim_organization        AS p ON p.id = b.payer_id
                LEFT JOIN pim_party_role_to_party AS t ON t.party_id = b.payer_id
                LEFT JOIN pim_party_role          AS r ON r.id = t.role_id
                LEFT JOIN role_refbook            AS e ON e.role = r.code
                LEFT JOIN pim_org_code            AS o ON o.org_id = b.payer_id AND o.type_id = _oms_id
                LEFT JOIN pim_org_code            AS i ON i.org_id = b.payer_id AND i.type_id = _inn_id
                LEFT JOIN pim_org_code            AS k ON k.org_id = b.payer_id AND k.type_id = _kpp_id
            GROUP BY 1, 2, 3, 4
        )
        SELECT
            --------------счёт---------------
            b.main_bill_id,
            b.bill_id,
            b.bill_number,
            b.bill_package_number,
            b.bill_comment,
            b.bill_price_commentary,
            b.bill_date,
            b.bill_generate_date,
            b.bill_full_year,
            b.bill_year,
            b.bill_month,
            b.bill_from_date,
            b.bill_to_date,
            b.bill_price_list_id,
            b.bill_is_additional,
            b.bill_is_correctional,
            b.bill_fin_type_code,
            a.bill_is_local,
            a.bill_is_foreign,
            a.bill_is_nopolicy,
            --получатель (recipient) платежа (больница)--
            r.rcp_id,
            r.rcp_short_name,
            r.rcp_full_name,
            r.rcp_code_oms,
            r.rcp_inn,
            r.rcp_ogrn,
            r.rcp_kpp,
            r.rcp_contact_email,
            --плательщик (payer) (страховая)--
            p.payer_id,
            p.payer_short_name,
            p.payer_full_name,
            p.payer_role,
            p.payer_code_oms,
            p.payer_inn,
            p.payer_kpp
        FROM 
            bill AS b, bill_insurance_affiliation AS a, recipient AS r, payer AS p
        WHERE
            b.main_bill_id = a.main_bill_id AND b.bill_id = r.bill_id AND b.bill_id = p.bill_id
    ;
END;
$$;

