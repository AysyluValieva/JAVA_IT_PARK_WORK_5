CREATE FUNCTION fin_spec_gen_policy_dev(p1_bill_id integer)
  RETURNS void
STRICT
LANGUAGE plpgsql
AS $$
DECLARE 
    _regions_arr INTEGER[];
    _is_local BOOLEAN;
    _is_foreign BOOLEAN;
    _is_nopolicy BOOLEAN;
    _all_region BOOLEAN;
    _payer_id INTEGER;
    _bill_from_date DATE:= (SELECT m.from_date FROM fin_bill_main m WHERE m.id = p1_bill_id);
BEGIN
    /*
        current version date 19.08.2014
        
        changelog https://sources.kirkazan.ru/revisionList.jsp?url=lsd-stable%2Fbilling.configs%2Fspecific%2Ftrunk%2Fsql%2Ffin_spec_gen_policy.sql
    */
    ----------------------------------------------------параметры для страховой принадлежности-------------------------------------------------------
    _payer_id := (SELECT payer_id FROM public.fin_bill_main WHERE id = public.fin_bill__get_main_bill (p1_bill_id));
    _regions_arr := ARRAY (SELECT region_id FROM public.fin_bill_main_to_region WHERE main_bill_id = public.fin_bill__get_main_bill (p1_bill_id));
    IF 
        array_length (_regions_arr, 1) IS NOT NULL
    THEN
        _is_local    := (0 = ANY (_regions_arr));
        _is_foreign  := (1 = ANY (_regions_arr));
        _is_nopolicy := (2 = ANY (_regions_arr));
        _all_region  := _is_local AND _is_foreign AND _is_nopolicy;
    ELSE
        _is_local := TRUE; _is_foreign := TRUE; _is_nopolicy := TRUE; _all_region := TRUE;
    END IF;
  
    UPDATE tmp_fin_bill_generate 
    SET
    active_policy_id = COALESCE(
                                 billing.fin_get_policy_identity_returned_sql(case_id),                                        --сначала берем полис который вернула идентификация
                                 public.fin_individual__get_active_policy (customer_id, COALESCE(case_open_date,bdate))   --иначе подбираем полис на дату открытия случая
                                ) 
     WHERE
        1 = 1 /*bill_id = p1_bill_id*/ AND NOT is_sifted
    ;                            
  
    
    UPDATE tmp_fin_bill_generate AS f
    SET
        active_policy_issuer_id = i.issuer_id, smo_work_territory_id = s.work_territory_id 
    FROM
        public.pim_individual_doc         AS i 
        LEFT JOIN public.pim_organization AS s ON s.id = i.issuer_id
    WHERE
        1 = 1 /*f.bill_id = p1_bill_id*/ AND NOT f.is_sifted AND f.active_policy_id = i.id
    ;
    -------------------------------------------------------отсеивание по полису----------------------------------------------------------------------
      UPDATE tmp_fin_bill_generate AS f
    SET
        lpu_work_territory_id = s.work_territory_id 
    FROM
      public.pim_organization AS s 
    WHERE
        1 = 1 /*f.bill_id = p1_bill_id*/ AND NOT f.is_sifted AND s.id = f.org_id
    ;
    
    UPDATE tmp_fin_bill_generate 
    SET 
        is_sifted = TRUE, sifting_cause = 'Пустая территория обслуживания ЛПУ' 
    WHERE
        1 = 1 /*bill_id = p1_bill_id*/ AND NOT is_sifted AND lpu_work_territory_id IS NULL
    ;
    UPDATE tmp_fin_bill_generate SET belonging_type = 'nopolicy' WHERE 1 = 1 /*bill_id = p1_bill_id*/ AND NOT is_sifted AND active_policy_id IS NULL
    ;
    UPDATE tmp_fin_bill_generate SET belonging_type = 'nopolicy_issuer' WHERE 1 = 1 /*bill_id = p1_bill_id*/ AND NOT is_sifted AND belonging_type IS NULL AND active_policy_issuer_id IS NULL
    ;
    UPDATE tmp_fin_bill_generate SET belonging_type = 'nopolicy_territory' WHERE 1 = 1 /*bill_id = p1_bill_id*/ AND NOT is_sifted AND belonging_type IS NULL AND smo_work_territory_id IS NULL
    ;
    UPDATE tmp_fin_bill_generate AS f
    SET 
        belonging_type = CASE WHEN l.path <@ s.path THEN 'local' ELSE 'foreign' END
    FROM
        public.address_element_data AS l, public.address_element_data AS s
    WHERE
        1 = 1 /*f.bill_id = p1_bill_id*/ AND NOT f.is_sifted AND f.belonging_type IS NULL AND f.lpu_work_territory_id = l.id AND f.smo_work_territory_id = s.id
    ;
    IF
        NOT _all_region
    THEN
        IF
            _is_nopolicy AND _is_foreign
        THEN
            UPDATE tmp_fin_bill_generate
            SET
                is_sifted = TRUE, sifting_cause = 'Тип региона не подходит под выбранные: без полиса, чужой'
            WHERE
                1 = 1 /*bill_id = p1_bill_id*/ AND NOT is_sifted AND belonging_type = 'local'
            ;
        ELSIF
            _is_nopolicy AND _is_local
        THEN
            UPDATE tmp_fin_bill_generate
            SET
                is_sifted = TRUE, sifting_cause = 'Тип региона не подходит под выбранные: без полиса, свой'
            WHERE
                1 = 1 /*bill_id = p1_bill_id*/ AND NOT is_sifted AND belonging_type = 'foreign'
            ;
        ELSIF
            _is_foreign AND _is_local
        THEN
            UPDATE tmp_fin_bill_generate
            SET
                is_sifted = TRUE, sifting_cause = 'Тип региона не подходит под выбранные: чужой, свой'
            WHERE
                1 = 1 /*bill_id = p1_bill_id*/ AND NOT is_sifted AND belonging_type LIKE 'nopolicy%'
            ;
        ELSIF
            _is_nopolicy
        THEN
            UPDATE tmp_fin_bill_generate
            SET
                is_sifted = TRUE, sifting_cause = 'Тип региона не подходит под выбранные: без полиса'
            WHERE
                1 = 1 /*bill_id = p1_bill_id*/ AND NOT is_sifted AND belonging_type IN ('local', 'foreign')
            ;
        ELSIF
            _is_foreign
        THEN
            UPDATE tmp_fin_bill_generate
            SET
                is_sifted = TRUE, sifting_cause = 'Тип региона не подходит под выбранные: чужой'
            WHERE
                1 = 1 /*bill_id = p1_bill_id*/ AND NOT is_sifted AND belonging_type IN ('local', 'nopolicy', 'nopolicy_issuer', 'nopolicy_territory')
            ;
        ELSIF
            _is_local
        THEN
            UPDATE tmp_fin_bill_generate
            SET
                is_sifted = TRUE, sifting_cause = 'Тип региона не подходит под выбранные: свой'
            WHERE
                1 = 1 /*bill_id = p1_bill_id*/ AND NOT is_sifted AND belonging_type IN ('foreign', 'nopolicy', 'nopolicy_issuer', 'nopolicy_territory')
            ;
        END IF;
    END IF;
    
    IF 
        _is_local AND NOT (_is_foreign AND _is_nopolicy AND _all_region)
    THEN
        UPDATE tmp_fin_bill_generate
        SET
            is_sifted = TRUE, sifting_cause = 'Страховая принадлежность не подходит под выбранного плательщика'
        WHERE
            1 = 1 /*bill_id = p1_bill_id*/ AND NOT is_sifted AND coalesce (active_policy_issuer_id, 0) <> _payer_id
        ;
    END IF;
    
EXCEPTION
    WHEN NO_DATA_FOUND THEN RAISE EXCEPTION 'Отсутствуют данные по счёту';
END;
$$;

