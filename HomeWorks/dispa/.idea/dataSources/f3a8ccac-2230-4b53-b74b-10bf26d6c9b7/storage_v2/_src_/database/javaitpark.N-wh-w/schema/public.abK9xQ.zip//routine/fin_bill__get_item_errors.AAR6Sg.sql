CREATE FUNCTION fin_bill__get_item_errors(id integer)
  RETURNS character varying
LANGUAGE plpgsql
AS $$
declare
  element record;
  result text := '';
begin

  for element in
    select e.error
      from fin_bill_spec_item_error e
      where e.item_id = fin_bill__get_item_errors.id
  loop

    if result <> '' then
      result := result || ' / ' || element.error;
    else
      result := element.error;
    end if;

  end loop;

  if result = '' then
    return null;
  end if;

  return result;

end;
$$;

