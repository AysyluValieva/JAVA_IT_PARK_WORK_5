CREATE RULE insert_user_party AS
    ON INSERT TO public.sec_user_party_own_org DO INSTEAD NOTHING;

