CREATE FUNCTION agreeserviceforpatientallexceptdeni(xid integer, xserviceid integer, xagree boolean, xdenial boolean, xagreedate character varying, xepid integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
          i integer;
          q_seq integer;
          pci integer;
          mviews record;
          rstatus integer;
          mmcrid integer;
          eventcode text;
          eventtype integer;
          l_pay_method integer;
        begin
          l_pay_method = (select me.pay_method from disp.md_event_patient mep join disp.md_event me on me.id = mep.event_id where mep.id = xepid);
          xdenial = FALSE;
          xagree = xagree;

          eventcode = (select met.code from disp.md_event_patient mep
          left join disp.md_event me on me.id = mep.event_id
          left join disp.md_event_type met on met.id = me.event_type
          where mep.id = xepid);

          eventtype = (select me.event_type from disp.md_event_patient mep
	      left join disp.md_event me on me.id = mep.event_id
	      where mep.id = xepid);

          IF (select count(id) from disp.md_event_patient where case_id is not null and id = xepid) = 0 then
              q_seq = nextval('mc_case_seq');
              pci = (select indiv_id from disp.md_event_patient where id = xepid);
              -- clinic id - ЗАШИТО - плохо (16 ГБ)
              mmcrid = nextval('mc_med_case_result_id');
              insert into MC_MED_CASE_RESULT (id) values (mmcrid);
              insert into MC_CASE (id, uid, create_date, patient_id, case_type_id, clinic_id, care_level_id, funding_id, init_goal_id, care_regimen_id, payment_method_id, open_date, result_id)
                values (q_seq, eventcode||'_'||CAST(nextval('disp.md_event_case_number') as text), current_date, pci, (select id from mc_case_type where code = '1' limit 1),
                (select me.org_id from disp.md_event_patient mep left join disp.md_event me on me.id = mep.event_id where mep.id = xepid),
                (select id from mc_care_level where code = (select value from disp.settings where code = 'case.care_level_code' limit 1) limit 1),
                (select me.pay_type from disp.md_event_patient mep join disp.md_event me on me.id = mep.event_id where mep.id = xepid),
                (select ett.case_init_goal_id from disp.md_event_type_target ett where ett.event_type_id = eventtype and ett.stage = 1 and (begin_date is null or begin_date <= current_date) and (end_date is null or end_date >= current_date)),
                (select id from mc_care_regimen where code = '1' limit 1),
                (CASE WHEN l_pay_method IS NOT NULL THEN l_pay_method ELSE (SELECT id FROM mc_payment_method WHERE CODE = '11' limit 1) END),
                 current_date, mmcrid);
              update disp.md_event_patient set case_id = q_seq where id = xepid ;
          END IF;

          FOR mviews IN (select mesp.id as id, mespa.id as aid
                            from disp.md_event_patient mep
                            inner join disp.md_event_service_patient mesp on mesp.event_patient_id = mep.id
                            left join disp.md_event_service_patient_agreement mespa on mespa.service_id = mesp.id
                            left join disp.md_event_service mes on mes.id = mesp.service_id
                            left join md_norm_document_service mnds on mnds.id = mes.doc_service_id
                            where mep.id = xepid and mnds.code != 'Д1.02' and (mespa.denial != TRUE or mespa.denial IS NULL)) LOOP
              IF (select count(ssr.id)
                    from disp.md_event_patient mep
                    left join MD_SRV_RENDERED msr on msr.case_id = mep.case_id
                    inner join SR_SRV_RENDERED ssr on ssr.id = msr.id and ssr.service_id = (SELECT mes.service_id FROM disp.md_event_service_patient mesp
                                                                                            left join disp.md_event_service mes on mes.id = mesp.service_id
                                                                                            where mesp.id = mviews.id)
                    where mep.id = xepid) > 0 THEN
                rstatus = 4;
              ELSE
                rstatus = 1;
              END IF;

                update disp.md_event_service_patient set status = rstatus
                  where id = mviews.id;

              IF (select count(id) from disp.md_event_service_patient_agreement where service_id = mviews.id) = 0 THEN
                i = nextval('disp.md_event_service_patient_agreement_id_seq');
                insert into disp.md_event_service_patient_agreement (id, service_id, agree, denial, agree_date)
                  values (i, mviews.id, TRUE, FALSE, to_date(xagreeDate, 'DD.MM.YYYY'));
              ELSE
                update disp.md_event_service_patient_agreement set service_id=mviews.id, agree=TRUE, denial=FALSE,
                  agree_date=to_date(xagreeDate, 'DD.MM.YYYY')
                where id=mviews.aid;
              END IF;
          END LOOP;

          return 1;
        end;
$$;

