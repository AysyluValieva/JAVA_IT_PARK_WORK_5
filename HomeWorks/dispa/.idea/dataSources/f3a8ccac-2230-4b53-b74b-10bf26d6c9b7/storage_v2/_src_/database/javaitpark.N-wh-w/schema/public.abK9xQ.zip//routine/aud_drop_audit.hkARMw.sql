CREATE FUNCTION aud_drop_audit(table_name text)
  RETURNS void
LANGUAGE plpgsql
AS $$
BEGIN
	EXECUTE format('ALTER TABLE %s DROP COLUMN IF EXISTS aud_who;
			ALTER TABLE %s DROP COLUMN IF EXISTS aud_when;
			ALTER TABLE %s DROP COLUMN IF EXISTS aud_source;
			ALTER TABLE %s DROP COLUMN IF EXISTS aud_when_create;
			ALTER TABLE %s DROP COLUMN IF EXISTS aud_who_create;
			ALTER TABLE %s DROP COLUMN IF EXISTS aud_source_create;
			DROP TRIGGER IF EXISTS audit_trigger ON %s ', $1, $1, $1, $1, $1, $1, $1);
    END;
$$;

