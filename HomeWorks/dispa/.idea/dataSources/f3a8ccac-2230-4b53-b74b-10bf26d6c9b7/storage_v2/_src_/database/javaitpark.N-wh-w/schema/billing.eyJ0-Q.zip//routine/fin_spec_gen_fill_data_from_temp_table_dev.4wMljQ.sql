CREATE FUNCTION fin_spec_gen_fill_data_from_temp_table_dev(p1_bill_id integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
	v_cnt bigint;
BEGIN

INSERT INTO billing.mord_fin_bill_status_log (bill_id, user_id, ts, name_function) SELECT p1_bill_id, 1, clock_timestamp(), 'fin_spec_gen_fill_data_from_temp_table_1';


DELETE FROM billing.fin_bill_generate b WHERE bill_id = p1_bill_id AND NOT EXISTS(SELECT 1 FROM tmp_fin_bill_generate tb WHERE tb.id = b.id);

GET DIAGNOSTICS v_cnt = ROW_COUNT;
INSERT INTO billing.mord_fin_bill_status_log (bill_id, user_id, ts, name_function) SELECT p1_bill_id, 1, clock_timestamp(), 'fill_fin_bill_generate. Deleted: ' || v_cnt || ' rows.';


UPDATE billing.fin_bill_generate AS fbg
   SET  service_id 		= tfbg.service_id,
	contract_id 		= tfbg.contract_id,
	customer_id 		= tfbg.customer_id,
	bdate 			= tfbg.bdate,
	new_born 		= tfbg.new_born,
	patient_id 		= tfbg.patient_id,
	active_policy_id 	= tfbg.active_policy_id,
	case_id 		= tfbg.case_id,
	org_id 			= tfbg.org_id,
	quantity 		= tfbg.quantity,
	price_list_id 		= tfbg.price_list_id,
	relative_id 		= tfbg.relative_id,
	to_date 		= tfbg.to_date,
	res_group_id 		= tfbg.res_group_id,
	fin_bill_spec_item_id 	= tfbg.fin_bill_spec_item_id,
	b_fin_bill_spec_item_id = tfbg.b_fin_bill_spec_item_id,
	step_id 		= tfbg.step_id,
	--step_edate 		= tfbg.step_edate,
	tariff 			= tfbg.tariff,
	is_sifted 		= tfbg.is_sifted,
	sifting_cause 		= tfbg.sifting_cause,
	funding_id 		= tfbg.funding_id,
	attendant_id 		= tfbg.attendant_id,
	case_open_date 		= tfbg.case_open_date,
	price_position_code 	= tfbg.price_position_code,
	belonging_type 		= tfbg.belonging_type,
	closing_step_id 	= tfbg.closing_step_id,
	case_close_date 	= tfbg.case_close_date,
	price_pos_arr 		= tfbg.price_pos_arr,
	active_policy_issuer_id = tfbg.active_policy_issuer_id,
	--lpu_work_territory_id 	= tfbg.lpu_work_territory_id,
	smo_work_territory_id 	= tfbg.smo_work_territory_id,
	srv_cul 		= tfbg.srv_cul,
	step_cnt 		= tfbg.step_cnt,
	tariff_code 		= tfbg.tariff_code,
	edate 			= tfbg.edate,
	init_goal_id 		= tfbg.init_goal_id,
	case_type_id 		= tfbg.case_type_id,
	rdd_quantity 		= tfbg.rdd_quantity,
	service_code 		= tfbg.service_code,
	price_position_name 	= tfbg.price_position_name,
	patient_age 		= tfbg.patient_age,
	patient_gender_id 	= tfbg.patient_gender_id,
	item_type 		= tfbg.item_type,
	care_regimen_id 	= tfbg.care_regimen_id,
	service_name 		= tfbg.service_name,
	from_date 		= tfbg.from_date,
	provision_condition_id 	= tfbg.provision_condition_id,
	comment 		= tfbg.comment,
	tooth_number 		= tfbg.tooth_number,
	rdd_diagnosis_id 	= tfbg.rdd_diagnosis_id,
	id_pac 			= tfbg.id_pac,
	representative_id 	= tfbg.representative_id,
	rdd_cul 		= tfbg.rdd_cul,
	--anest_code 		= tfbg.anest_code,
	region_data 		= tfbg.region_data,
	price 			= tfbg.price,
	care_level_id 		= tfbg.care_level_id,
	payment_method_id 	= tfbg.payment_method_id,
	--дельта от Кургана
	role_code		= tfbg.role_code,
	bill_item_logic		= tfbg.bill_item_logic,
	prof			= tfbg.prof,
	ds_code			= tfbg.ds_code,
	kdp			= tfbg.kdp,
	service_type_id		= tfbg.service_type_id,
	is_deleted		= tfbg.is_deleted,
	tariff_name		= tfbg.tariff_name,
	item_comment		= tfbg.item_comment,
	price_old		= tfbg.price_old,
	n_zap			= tfbg.n_zap	
  FROM tmp_fin_bill_generate AS tfbg
 WHERE fbg.id = tfbg.id
       AND fbg.bill_id = p1_bill_id
       AND (COALESCE(fbg.service_id, 0) != COALESCE(tfbg.service_id, 0)
		OR COALESCE(fbg.contract_id, 0) != COALESCE(tfbg.contract_id, 0)
		OR COALESCE(fbg.customer_id, 0) != COALESCE(tfbg.customer_id, 0)
		OR COALESCE(fbg.bdate, date '19000101') != COALESCE(tfbg.bdate, date '19000101')
		OR COALESCE(fbg.new_born, FALSE) != COALESCE(tfbg.new_born, FALSE)
		OR COALESCE(fbg.patient_id, 0) != COALESCE(tfbg.patient_id, 0)
		OR COALESCE(fbg.active_policy_id, 0) != COALESCE(tfbg.active_policy_id, 0)
		OR COALESCE(fbg.case_id, 0) != COALESCE(tfbg.case_id, 0)
		OR COALESCE(fbg.org_id, 0) != COALESCE(tfbg.org_id, 0)
		OR COALESCE(fbg.quantity, 0) != COALESCE(tfbg.quantity, 0)
		OR COALESCE(fbg.price_list_id, 0) != COALESCE(tfbg.price_list_id, 0)
		OR COALESCE(fbg.relative_id, 0) != COALESCE(tfbg.relative_id, 0)
		OR COALESCE(fbg.to_date, date '19000101') != COALESCE(tfbg.to_date, date '19000101')
		OR COALESCE(fbg.res_group_id, 0) != COALESCE(tfbg.res_group_id, 0)
		OR COALESCE(fbg.fin_bill_spec_item_id, 0) != COALESCE(tfbg.fin_bill_spec_item_id, 0)
		OR COALESCE(fbg.b_fin_bill_spec_item_id, 0) != COALESCE(tfbg.b_fin_bill_spec_item_id, 0)
		OR COALESCE(fbg.step_id, 0) != COALESCE(tfbg.step_id, 0)
		--OR COALESCE(fbg.step_edate, date '19000101') != COALESCE(tfbg.step_edate, date '19000101')
		OR COALESCE(fbg.tariff, 0) != COALESCE(tfbg.tariff, 0)
		OR COALESCE(fbg.is_sifted, FALSE) != COALESCE(tfbg.is_sifted, FALSE)
		OR COALESCE(fbg.sifting_cause, '') != COALESCE(tfbg.sifting_cause, '')
		OR COALESCE(fbg.funding_id, 0) != COALESCE(tfbg.funding_id, 0)
		OR COALESCE(fbg.attendant_id, 0) != COALESCE(tfbg.attendant_id, 0)
		OR COALESCE(fbg.case_open_date, date '19000101') != COALESCE(tfbg.case_open_date, date '19000101')
		OR COALESCE(fbg.price_position_code, '') != COALESCE(tfbg.price_position_code, '')
		OR COALESCE(fbg.belonging_type, '') != COALESCE(tfbg.belonging_type, '')
		OR COALESCE(fbg.closing_step_id, 0) != COALESCE(tfbg.closing_step_id, 0)
		OR COALESCE(fbg.case_close_date, date '19000101') != COALESCE(tfbg.case_close_date, date '19000101')
		OR COALESCE(fbg.price_pos_arr, ARRAY[0]) != COALESCE(tfbg.price_pos_arr, ARRAY[0])
		OR COALESCE(fbg.active_policy_issuer_id, 0) != COALESCE(tfbg.active_policy_issuer_id, 0)
		--OR COALESCE(fbg.lpu_work_territory_id, 0) != COALESCE(tfbg.lpu_work_territory_id, 0)
		OR COALESCE(fbg.smo_work_territory_id, 0) != COALESCE(tfbg.smo_work_territory_id, 0)
		OR COALESCE(fbg.srv_cul, 0) != COALESCE(tfbg.srv_cul, 0)
		OR COALESCE(fbg.step_cnt, 0) != COALESCE(tfbg.step_cnt, 0)
		OR COALESCE(fbg.tariff_code, '') != COALESCE(tfbg.tariff_code, '')
		OR COALESCE(fbg.edate, date '19000101') != COALESCE(tfbg.edate, date '19000101')
		OR COALESCE(fbg.init_goal_id, 0) != COALESCE(tfbg.init_goal_id, 0)
		OR COALESCE(fbg.case_type_id, 0) != COALESCE(tfbg.case_type_id, 0)
		OR COALESCE(fbg.rdd_quantity, 0) != COALESCE(tfbg.rdd_quantity, 0)
		OR COALESCE(fbg.service_code, '') != COALESCE(tfbg.service_code, '')
		OR COALESCE(fbg.price_position_name, '') != COALESCE(tfbg.price_position_name, '')
		OR COALESCE(fbg.patient_age, 0) != COALESCE(tfbg.patient_age, 0)
		OR COALESCE(fbg.patient_gender_id, 0) != COALESCE(tfbg.patient_gender_id, 0)
		OR COALESCE(fbg.item_type, '') != COALESCE(tfbg.item_type, '')
		OR COALESCE(fbg.care_regimen_id, 0) != COALESCE(tfbg.care_regimen_id, 0)
		OR COALESCE(fbg.service_name, '') != COALESCE(tfbg.service_name, '')
		OR COALESCE(fbg.from_date, date '19000101') != COALESCE(tfbg.from_date, date '19000101')
		OR COALESCE(fbg.provision_condition_id, 0) != COALESCE(tfbg.provision_condition_id, 0)
		OR COALESCE(fbg.comment, '') != COALESCE(tfbg.comment, '')
		OR COALESCE(fbg.tooth_number, '') != COALESCE(tfbg.tooth_number, '')
		OR COALESCE(fbg.rdd_diagnosis_id, 0) != COALESCE(tfbg.rdd_diagnosis_id, 0)
		OR COALESCE(fbg.id_pac, '') != COALESCE(tfbg.id_pac, '')
		OR COALESCE(fbg.representative_id, 0) != COALESCE(tfbg.representative_id, 0)
		OR COALESCE(fbg.rdd_cul, 0) != COALESCE(tfbg.rdd_cul, 0)
		--OR COALESCE(fbg.anest_code, '') != COALESCE(tfbg.anest_code, '')
		OR COALESCE(fbg.region_data, hstore('')) != COALESCE(tfbg.region_data, hstore(''))
		OR COALESCE(fbg.price, 0) != COALESCE(tfbg.price, 0)
		OR COALESCE(fbg.care_level_id, 0) != COALESCE(tfbg.care_level_id, 0)
		OR COALESCE(fbg.payment_method_id, 0) != COALESCE(tfbg.payment_method_id, 0)
		--дельта от Кургана
		OR COALESCE(fbg.role_code, '') != COALESCE(tfbg.role_code, '')
		OR COALESCE(fbg.bill_item_logic, '') != COALESCE(tfbg.bill_item_logic, '')
		OR COALESCE(fbg.prof, '') != COALESCE(tfbg.prof, '')
		OR COALESCE(fbg.ds_code, '') != COALESCE(tfbg.ds_code, '')
		OR COALESCE(fbg.kdp, -1) != COALESCE(tfbg.kdp, -1)
		OR COALESCE(fbg.service_type_id, -1) != COALESCE(tfbg.service_type_id, -1)
		OR COALESCE(fbg.is_deleted, FALSE) != COALESCE(tfbg.is_deleted, FALSE)
		OR COALESCE(fbg.tariff_name, '') != COALESCE(tfbg.tariff_name, '')
		OR COALESCE(fbg.item_comment, '') != COALESCE(tfbg.item_comment, '')
		OR COALESCE(fbg.price_old, -1) != COALESCE(tfbg.price_old, -1)
		OR COALESCE(fbg.n_zap, -1) != COALESCE(tfbg.n_zap, -1)
	);

GET DIAGNOSTICS v_cnt = ROW_COUNT;
--	RAISE NOTICE 'Changed rows in billing.fin_bill_generate: %; time: %', v_cnt, clock_timestamp();
INSERT INTO billing.mord_fin_bill_status_log (bill_id, user_id, ts, name_function) SELECT p1_bill_id, 1, clock_timestamp(), 'fill_fin_bill_generate. Changed: ' || v_cnt || ' rows.';

INSERT 
  INTO billing.fin_bill_generate(id, bill_id, service_id, contract_id, customer_id, bdate, new_born, patient_id, active_policy_id, case_id, org_id,
			 quantity, price_list_id, relative_id, to_date, res_group_id, fin_bill_spec_item_id, b_fin_bill_spec_item_id, step_id, tariff,
			 is_sifted, sifting_cause, funding_id, attendant_id, case_open_date, price_position_code, belonging_type, closing_step_id,
			 case_close_date, price_pos_arr, active_policy_issuer_id, smo_work_territory_id, srv_cul, step_cnt, tariff_code, edate,
			 init_goal_id, case_type_id, rdd_quantity, service_code, price_position_name, patient_age, patient_gender_id, item_type, care_regimen_id, service_name,
			 from_date, provision_condition_id, comment, tooth_number, rdd_diagnosis_id, id_pac, representative_id, rdd_cul, region_data, price, care_level_id,
			payment_method_id,
			role_code, bill_item_logic, prof, ds_code, kdp, service_type_id, is_deleted, tariff_name, item_comment, price_old, n_zap)
SELECT id, bill_id, service_id, contract_id, customer_id, bdate, new_born, patient_id, active_policy_id, case_id, org_id,
			 quantity, price_list_id, relative_id, to_date, res_group_id, fin_bill_spec_item_id, b_fin_bill_spec_item_id, step_id, tariff,
			 is_sifted, sifting_cause, funding_id, attendant_id, case_open_date, price_position_code, belonging_type, closing_step_id,
			 case_close_date, price_pos_arr, active_policy_issuer_id, smo_work_territory_id, srv_cul, step_cnt, tariff_code, edate,
			 init_goal_id, case_type_id, rdd_quantity, service_code, price_position_name, patient_age, patient_gender_id, item_type, care_regimen_id, service_name,
			 from_date, provision_condition_id, comment, tooth_number, rdd_diagnosis_id, id_pac, representative_id, rdd_cul, region_data, price, care_level_id,
			payment_method_id,
			role_code, bill_item_logic, prof, ds_code, kdp, service_type_id, is_deleted, tariff_name, item_comment, price_old, n_zap
  FROM tmp_fin_bill_generate AS tfbg
 WHERE NOT EXISTS(SELECT 1 FROM billing.fin_bill_generate fbg WHERE fbg.bill_id = p1_bill_id AND fbg.id = tfbg.id)
 ;

GET DIAGNOSTICS v_cnt = ROW_COUNT;
--RAISE NOTICE 'Inserted rows into billing.fin_bill_generate: %; time: %', v_cnt, clock_timestamp();
INSERT INTO billing.mord_fin_bill_status_log (bill_id, user_id, ts, name_function) SELECT p1_bill_id, 1, clock_timestamp(), 'fill_fin_bill_generate. Inserted: ' || v_cnt || ' rows.';

DROP TABLE tmp_fin_bill_generate;

INSERT INTO billing.mord_fin_bill_status_log (bill_id, user_id, ts, name_function) SELECT p1_bill_id, 1, clock_timestamp(), 'fill_fin_bill_generate. Конец';

END;
$$;

