CREATE FUNCTION get_store_supply_quantity_at_date(storesupplyid integer, todate date, ismnei boolean)
  RETURNS numeric
LANGUAGE plpgsql
AS $$
DECLARE
 result  NUMERIC;
 income NUMERIC;
 outcome NUMERIC;

BEGIN
 result=0;

SELECT (case when isMnei=true then SUM(jur.mnei_quantity) else SUM(jur.quantity) end) INTO income  FROM inventory.store_opr_jur AS jur
   LEFT OUTER JOIN inventory.store_opr opr ON jur.store_opr_id=opr.id
   LEFT OUTER JOIN inventory.store_opr_type TYPE ON TYPE.id=opr.opr_type_id
   WHERE TYPE.id=1 AND jur.date < toDate::DATE AND rec_store_sup_id = storeSupplyId;

SELECT (case when isMnei=true then SUM(jur.mnei_quantity) else SUM(jur.quantity) end) INTO outcome  FROM inventory.store_opr_jur AS jur
   LEFT OUTER JOIN inventory.store_opr opr ON jur.store_opr_id=opr.id
   LEFT OUTER JOIN inventory.store_opr_type TYPE ON TYPE.id=opr.opr_type_id
   WHERE TYPE.id=2 AND jur.date < toDate::DATE AND send_store_sup_id = storeSupplyId;

if outcome IS NULL THEN outcome=0; END if;
if income IS NULL THEN income=0; END if;

result=income-outcome;
return result;
END;
$$;

