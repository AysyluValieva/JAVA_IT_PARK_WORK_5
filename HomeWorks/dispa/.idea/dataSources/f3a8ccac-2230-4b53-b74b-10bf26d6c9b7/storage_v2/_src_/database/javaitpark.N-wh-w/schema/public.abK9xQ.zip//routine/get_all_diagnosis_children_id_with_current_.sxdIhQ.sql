CREATE FUNCTION get_all_diagnosis_children_id_with_current_(diagnosis_id integer)
  RETURNS SETOF integer
LANGUAGE SQL
AS $$
WITH RECURSIVE temp1 ( "ID") AS (
            SELECT d.id
            FROM md_diagnosis d WHERE d.id = $1
            union
            select d2.id
            FROM md_diagnosis d2 INNER JOIN temp1 ON( temp1."ID"= d2.parent_id)      )
            select * from temp1
$$;

