CREATE FUNCTION get_agecat_index(patient_id integer, open_dt date)
  RETURNS integer
IMMUTABLE
LANGUAGE plpgsql
AS $$
declare
    age integer;
    v_birth_dt date;
    gender_code character varying;
begin
    SELECT birth_dt, code INTO v_birth_dt, gender_code
    FROM pim_individual pi LEFT JOIN pim_gender pg ON (pg.id = pi.gender_id)
    WHERE pi.id = patient_id;

    if v_birth_dt IS NULL or open_dt IS NULL or gender_code IS NULL or gender_code = 'UNKNOWN' then return -1;
    end if;
    age = DATE_PART('year', open_dt) - DATE_PART('year', v_birth_dt) -
	  (CASE TO_CHAR(open_dt, 'MMDD') < TO_CHAR(v_birth_dt, 'MMDD') WHEN TRUE THEN 1 ELSE 0 END);
    if age <= 14 then return 1;
    else if age >= 15 and age <= 17 then return 2;
	    else if age >= 55 and gender_code = 'FEMALE' then return 4;
		    else if age >= 60 and gender_code = 'MALE' then return 4;
			    else if age >= 18 then return 3;
				    else return 0;
				 end if;
		         end if;
		 end if;
	 end if;
    End if;
end;
$$;

