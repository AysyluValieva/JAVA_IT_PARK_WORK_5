CREATE FUNCTION calculate_weeks_for_service(servicedt date, xregdt date, xweeks integer)
  RETURNS character varying
LANGUAGE plpgsql
AS $$
DECLARE
    result varchar;
    days integer;
    weeks integer;
BEGIN
    IF (xregDt is not null and xweeks is not null)
        THEN
	        days = date_part('day', serviceDt::timestamp  - xregDt::timestamp);
	        weeks = trunc(days/7);
	        days = days - trunc(weeks*7);

	        result = concat(cast(trunc(xweeks + weeks) as varchar), ' нед. ', (case when days > 0 then cast(days as varchar) || ' дн. ' end));
    END IF;

    RETURN result;
END;
$$;

