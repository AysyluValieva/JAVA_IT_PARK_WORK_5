CREATE FUNCTION report_cell_tr_bri()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN

                    IF NEW.id IS NULL THEN
                        RAISE EXCEPTION 'Значение в колонке id нарушает ограничение NOT NULL';
                    END IF;

                    IF NEW.report_id IS NULL THEN
                        RAISE EXCEPTION 'Значение в колонке report_id нарушает ограничение NOT NULL';
                    END IF;

                    IF NEW.year_ IS NULL THEN
                        RAISE EXCEPTION 'Значение в колонке year_ нарушает ограничение NOT NULL';
                    END IF;

                    IF NEW.partition_id IS NULL THEN
                        RAISE EXCEPTION 'Значение в колонке partition_id нарушает ограничение NOT NULL';
                    END IF;

                    IF NEW.column_num IS NULL THEN
                        RAISE EXCEPTION 'Значение в колонке column_num нарушает ограничение NOT NULL';
                    END IF;

                    IF NEW.row_num IS NULL THEN
                        RAISE EXCEPTION 'Значение в колонке row_num нарушает ограничение NOT NULL';
                    END IF;

                    IF NEW.measure_def_id IS NULL THEN
                        RAISE EXCEPTION 'Значение в колонке measure_def_id нарушает ограничение NOT NULL';
                    END IF;

                    IF NEW.value NOTNULL THEN

                        IF NEW.dimension_date_id IS NULL THEN
                            RAISE EXCEPTION 'Значение в колонке dimension_date_id нарушает ограничение NOT NULL';
                        END IF;

                        IF NEW.dimension_source_id IS NULL THEN
                            RAISE EXCEPTION 'Значение в колонке dimension_source_id нарушает ограничение NOT NULL';
                        END IF;

                        IF NEW.dimension_id IS NULL THEN
                            RAISE EXCEPTION 'Значение в колонке dimension_id нарушает ограничение NOT NULL';
                        END IF;

					    NEW.calc_dt := now();

				    END IF;

                    --вставка в унаследованную таблицу
                    EXECUTE 'INSERT INTO indicators_inh.report_cell_y'|| CAST(NEW.year_ as varchar) || '_r' || CAST(NEW.report_id as varchar) || '
                                (id, partition_id, column_num, row_num, dimension_source_id, dimension_id, measure_def_id, dimension_date_id, calc_dt, value)
                                VALUES('|| NEW.id::text ||', '|| NEW.partition_id::text ||', '|| NEW.column_num::text ||', '|| NEW.row_num::text ||', '|| COALESCE(NEW.dimension_source_id::text,'null') ||'::integer, '|| COALESCE(NEW.dimension_id::text,'null') ||'::integer, '|| COALESCE(NEW.measure_def_id::text,'null') ||'::integer, '|| COALESCE(NEW.dimension_date_id::text,'null') ||'::integer, '|| CASE WHEN NEW.calc_dt ISNULL THEN 'null' ELSE ''''|| NEW.calc_dt::text || '''' END ||'::timestamp without time zone, '|| CASE WHEN NEW.value ISNULL THEN 'null' ELSE ''''|| NEW.value || '''' END ||'::varchar)';

				    RETURN NEW;

				END;
$$;

