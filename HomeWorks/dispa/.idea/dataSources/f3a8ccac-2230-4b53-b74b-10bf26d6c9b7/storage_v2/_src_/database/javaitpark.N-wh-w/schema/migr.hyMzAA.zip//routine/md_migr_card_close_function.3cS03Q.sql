CREATE FUNCTION md_migr_card_close_function(xcardid integer, xreasonid integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
begin
	      update migr.md_migr_card set status_id = 2, close_reason_id = xreasonid where id = xcardid;
            end;
$$;

