CREATE FUNCTION md_event_add_driver_function(xeid integer, xpid integer, xseries character varying, xnumber character varying, xcategories character varying)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
                i integer;
                categoryid json;
            begin
                i = nextval('disp.md_event_patient_id_seq');
                insert into disp.md_event_patient (id, event_id, indiv_id) values (i, xeid, xpid);
                insert into gibdd.md_gibdd_reference (id, series, number) values (i, xseries, xnumber);

                foreach categoryid in array array(select value from json_array_elements(cast(xcategories as json)))
                LOOP
                    insert into gibdd.md_gibdd_reference_category(reference_id, category_id) values (i, categoryid::text::int);
                END LOOP;
                return i;
            end;
$$;

