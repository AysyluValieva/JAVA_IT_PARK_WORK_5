CREATE FUNCTION update_call_card_result(xcall integer, xout integer, xis_confirmed boolean, xresult_id integer, xmasterdiag integer, xmaster_injury integer, xmdisease_type integer, xaccompdiag integer, xaccomp_injury integer, xaccompdisease_type integer, xtake_birth_id integer, xneed_exit_through integer, xactiv_visit_clinic_id integer, xother_recommendations character varying, xto_org_id integer, xto_department_id integer, xto_address_id integer, xto_description character varying, xoutdate date, xouttime time without time zone, xreceive_emp_id integer, xreceive_emp character varying, xdeath_date date, xdeath_time time without time zone, xdeathemp integer, xdeathres character varying, xtransporting_type_id integer, xcondition_ns character varying, xout_delay_reason_id integer, xmilage numeric, xcasenote character varying, xreg integer, xdeathdiag integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
                      dt date;
                      xcase integer;
                      xcase_state integer;
                      xstep integer;
                      xpatient_id integer;
                      xrendered integer;
                      xgroup integer;
                      -- time поля
                      xhas_list boolean := false;
                      -- диагнозы
                      xmasdiag integer := null;
                      xaccdiag integer := null;
                      xstage integer;
                      xaccompstage integer;
                      xmdiatype integer;
                      xaccompdiatype integer;
                      xdoctor integer;
                      xrenderedsel record;
                      xcallnote integer;
                      xconfirmed boolean;
                      -- вид услуги
                      xservice integer;

                    begin
                      -- дата принятия вызова бригадой или дата поступления вызова диспетчеру
                      if ((select cast(date_time as date)
                           from amb.md_ambcall_state_history
                           where state_id = (select id from amb.md_ambulance_call_state where e_code ='5') and call_id = xcall order by date_time desc limit 1) >
                          (select cast(from_time as date) from amb.md_ambulance_call where id = xcall))
                      then
                        dt = (select cast(date_time as date)
                              from amb.md_ambcall_state_history
                              where state_id = (select id from amb.md_ambulance_call_state where e_code ='5') and call_id = xcall order by date_time desc limit 1);
                      else
                        dt = (select cast(from_time as date) from amb.md_ambulance_call where id = xcall);
                      end if;

                      select into xpatient_id patient_id from amb.md_ambulance_call where id = xcall;
                      select into xcase, xrendered case_id, srv_rendered_id from amb.md_ambulance_call_result where id = xcall;

                      select into xstep id from mc_step where case_id = xcase;
                      select into xgroup res_group_id from sr_srv_rendered where id = xrendered;  -- не надо для случая, т.к. MC_CASE. emergency_team_code varchar(250) - не понятно, зачем вообще нужно

                      -- данные о вызове (кроме данных о пациенте)
                      update amb.md_ambulance_call set
                        to_org_id = xto_org_id,
                        to_department_id = xto_department_id,
                        to_address_id = xto_address_id,
                        to_description = xto_description
                      where id = xcall;

                      -- Проверка на null, так как поле diagnosis_is_not_confirmed не должен быть пустым
                      if xis_confirmed is not null
                      then
                        xconfirmed = xis_confirmed;
                      else
                        xconfirmed = false;
                      end if;

                      -- записи в результат вызова информации по сопроводительному листу --xhas_list = ();-- по виду вызова и отметкам (д.б. госпитализация)
                      update amb.md_ambulance_call_result set
                        out_delay_reason_id = xout_delay_reason_id,
                        list_note = xcondition_ns,
                        milage = xmilage,
                        need_exit_through = xneed_exit_through,
                        activ_visit_clinic_id = xactiv_visit_clinic_id,
                        other_recommendations = xother_recommendations,
                        receive_emp_id = xreceive_emp_id,
                        receive_emp = xreceive_emp,
                        has_list = xhas_list,
                        registrator_id = xreg,
                        create_dt = now(),
                        take_birth_id = xtake_birth_id,
                        diagnosis_is_not_confirmed = xconfirmed
                      where id = xcall;

                      -- записываем диагнозы
                      xstage = (select id from mc_stage where e_code = '4');
                      xaccompstage = (select id from mc_stage where e_code = '3');
                      xmdiatype = (select id from mc_diagnosis_type where e_code = '1');
                      xaccompdiatype = (select id from mc_diagnosis_type where e_code = '2');

                      xdoctor = (select pep.id
                                 from pim_employee_position pep
                                   join pim_employee_position_resource pepr on pepr.employee_position_id = pep.id
                                   join sr_resource sr on sr.id = pepr.id
                                   join sr_res_group_relationship srgrel on srgrel.resource_id = sr.id
                                   join sr_res_group srg on srg.id = srgrel.group_id
                                 where srg.id = xgroup and srgrel.role_id in (select id from sr_res_role where kind_id = 1));

                      if xmasterdiag is not null
                      then
                        if (select main_diagnos_id from mc_case where id = xcase) is not NULL
                        then
                          xmasdiag = (select main_diagnos_id from mc_case where id = xcase);
                        else
                          xmasdiag = (select id from mc_diagnosis where case_id = xcase and step_id = xstep and is_main = true);
                        end if;
                        if xmasdiag is null
                        THEN
                          xmasdiag = nextval('mc_diagnosis_seq');
                          insert into public.mc_diagnosis(id, patient_id, case_id, step_id, is_main, stage_id, type_id, diagnos_id, disease_type_id, establishment_date, doctor_id, injury_reason_id)
                          values (xmasdiag, xpatient_id, xcase, xstep, true, xstage, xmdiatype, xmasterdiag, xmdisease_type, dt, xdoctor, xmaster_injury);
                        else
                          update public.mc_diagnosis  set patient_id = xpatient_id, diagnos_id = xmasterdiag,disease_type_id = xmdisease_type, injury_reason_id = xmaster_injury  where id = xmasdiag;
                          update md_srv_rendered set diagnosis_id = xmasterdiag where id = xrendered;
                          update mc_step set main_diagnosis_id = xmasdiag  where id = xstep;
                          update mc_case set main_diagnos_id = xmasdiag where id = xcase;

                        end if;
                      else
                        --записи в услуга (sr_srv_rendered)
                        update md_srv_rendered set diagnosis_id = null where id = xrendered;
                        update mc_step set main_diagnosis_id = null  where id = xstep;
                        update mc_case set main_diagnos_id = null where id = xcase;
                      end if;

                      -- сопутствующий
                      if xaccompdiag is not null
                      then
                        If exists (select * from mc_diagnosis where case_id = xcase and is_main = false)
                        then
                          xaccdiag = (select id from mc_diagnosis where case_id = xcase and is_main = false);
                          update public.mc_diagnosis  set diagnos_id = xaccompdiag, disease_type_id = xaccompdisease_type, injury_reason_id = xaccomp_injury where id = xaccdiag;
                        else
                          xaccdiag = nextval('mc_diagnosis_seq');
                          insert into public.mc_diagnosis(id, patient_id, case_id, step_id, is_main, stage_id, type_id, diagnos_id, disease_type_id, establishment_date, doctor_id, injury_reason_id)
                          values (xaccdiag, xpatient_id, xcase, xstep, false, xaccompstage, xaccompdiatype, xaccompdiag, xaccompdisease_type, dt, xdoctor, xaccomp_injury);
                        end If;
                      else
                      end if;

                      -- записываем в случай (mc_case)
                      -- записываем в услугу (sr_srv_rendered)
                      update md_srv_rendered set diagnosis_id = xmasterdiag where id = xrendered;
                      update sr_srv_rendered set customer_id = xpatient_id where id = xrendered;

                      for xrenderedsel in
                      select service_id from amb.md_ambulance_call_services where call_id = xcall
                      loop
                        update sr_srv_rendered set customer_id = xpatient_id where id = xrenderedsel.service_id;
                      end loop;

                      -- шаг
                      update mc_step set main_diagnosis_id = xmasdiag,
                        result_id = xresult_id,
                        death_date = xdeath_date, death_time = xdeath_time, death_employee_id = xdeathemp,
                        outcome_date = xoutdate, outcome_time = xouttime,
                        outcome_id = xout, outcome_clinic_id = xto_org_id
                      where id = xstep;

                      -- дописано, таблица(mc_med_case_result) не нужна для снмп
                      xcase_state = (select id from mc_case_state where e_code = '1');
                      update mc_case set main_diagnos_id = xmasdiag, transporting_type_id = xtransporting_type_id,
                        note = xcasenote, death_reason = xdeathres, death_reason_diagnosis_id = xdeathdiag,
                        state_id = xcase_state, patient_id = xpatient_id
                      where id = xcase;

                      -- отметка госпитализации
                      IF ((select e_code from mc_step_result where id = xresult_id) = '403') and (xto_org_id is not null)
                         and not exists (select * from amb.md_ambulance_call_note where call_id = xcall and note_id = 21 and note_type = true and note_active = true)
                      THEN
                        xcallnote = amb.add_call_note(xcall,21,true,null,'а/у госпитализация',xreg,null);
                      ELSE
                        if (xto_org_id is null) and exists (select * from amb.md_ambulance_call_note where call_id = xcall and note_id = 21 and note_type = true and note_active = true)
                        then
                          xcallnote = amb.add_call_note(xcall,21,false,null,'а/у госпитализация',xreg,null);
                        end if;
                      END IF;

                      -- автодобавление отметок
                      execute amb.auto_add_call_note_amb_card (xcall, null, null, xreg, null, null, xmasterdiag, null, null);

                      -- определение вида услуги
                      xservice := amb.set_service (xcall);
                      return xcall;
                    end;
$$;

