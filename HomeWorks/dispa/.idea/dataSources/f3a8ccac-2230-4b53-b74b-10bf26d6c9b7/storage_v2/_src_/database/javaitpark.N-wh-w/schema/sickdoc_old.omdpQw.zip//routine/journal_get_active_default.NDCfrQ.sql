CREATE FUNCTION journal_get_active_default(p_clinic_id integer, p_dep_id integer, p_get_common_if_default_missing boolean DEFAULT true)
  RETURNS integer
IMMUTABLE
LANGUAGE plpgsql
AS $$
DECLARE
  c_cur_date CONSTANT DATE = current_date;
  l_id INTEGER;
BEGIN
  l_id = (SELECT j.id
          FROM sickdoc.journal j
            JOIN sickdoc.journal_default jd ON j.id = jd.journal_id
          WHERE jd.dep_id = $2);

  IF NOT sickdoc.journal_is_active(l_id) AND p_get_common_if_default_missing
  THEN
    l_id =  (SELECT j.id
             FROM sickdoc.journal j
             WHERE clinic_id = $1 AND is_common_for_clinic);

    IF NOT (SELECT sickdoc.journal_is_active(l_id))
    THEN
      l_id = NULL;
    END IF;
  END IF;

  RETURN l_id;
END;
$$;

