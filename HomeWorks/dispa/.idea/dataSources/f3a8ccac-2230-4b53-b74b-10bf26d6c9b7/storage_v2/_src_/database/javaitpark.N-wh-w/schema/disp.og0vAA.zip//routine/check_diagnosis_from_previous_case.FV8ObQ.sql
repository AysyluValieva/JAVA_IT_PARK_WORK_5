CREATE FUNCTION check_diagnosis_from_previous_case(xresultid integer)
  RETURNS boolean
LANGUAGE plpgsql
AS $$
declare
          xcase_id integer;
          xresult_id integer;
          cur_mep record;
          diag record;
          diagnosis_loaded boolean;
          all_diagnosis_loaded boolean;
        begin
	  all_diagnosis_loaded = false;
	  select mep.id, mep.indiv_id, mc.open_date, mc.init_goal_id into cur_mep
	  from disp.md_disp_orphans_result mdor
	  join disp.md_event_patient mep on mep.id = mdor.event_patient_id
          join mc_case mc on mc.id = mep.case_id
	  where mdor.id = xresultid;

          select mc.id into xcase_id from disp.md_event_patient mep
          join mc_case mc on mc.id = mep.case_id
          join mc_step ms on mc.closing_step_id = ms.id
          where mep.indiv_id = cur_mep.indiv_id
          and mc.init_goal_id = cur_mep.init_goal_id
          and ms.admission_date < cur_mep.open_date
          order by ms.admission_date desc
          limit 1;

          select id into xresult_id from disp.md_disp_orphans_result where event_patient_id = cur_mep.id and is_before = true;
          if (xresult_id is not null) then
            for diag in
              select id
              from mc_diagnosis md
              where case_id = xcase_id
            loop

            select exists(select 1 from disp.md_disp_orphans_diagnosis_extended_copied where id = diag.id) into diagnosis_loaded;
            all_diagnosis_loaded = all_diagnosis_loaded or diagnosis_loaded;

            end loop;
          end if;
	  return all_diagnosis_loaded;
        end;
$$;

