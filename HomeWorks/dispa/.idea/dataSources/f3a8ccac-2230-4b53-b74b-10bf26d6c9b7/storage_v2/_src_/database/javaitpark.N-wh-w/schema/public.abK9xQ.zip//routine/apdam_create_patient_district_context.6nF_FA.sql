CREATE FUNCTION apdam_create_patient_district_context(in_reg_date date)
  RETURNS void
LANGUAGE plpgsql
AS $$
BEGIN
  RAISE NOTICE '----Создание ограниченного контекста пациент - участок ...';
  EXECUTE apdam_create_patient_district_limited_context();

  RAISE NOTICE '----Создание полного контекста пациент - участок ...';
  EXECUTE apdam_create_patient_district_extended_context(in_reg_date);

  RAISE NOTICE '----Фильтрация контекста пациент - участок по критериям ...';
  EXECUTE apdam_filtration_patient_district_by_criterion();
END;
$$;

