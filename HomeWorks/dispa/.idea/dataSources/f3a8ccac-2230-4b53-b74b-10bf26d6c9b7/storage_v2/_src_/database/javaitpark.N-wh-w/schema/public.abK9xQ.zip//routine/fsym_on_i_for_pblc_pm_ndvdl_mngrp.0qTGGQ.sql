CREATE FUNCTION fsym_on_i_for_pblc_pm_ndvdl_mngrp()
  RETURNS trigger
LANGUAGE plpgsql
AS $fun$
begin                                                                                                                                                                  
                                   
                                  if 1=1 and "public".sym_triggers_disabled() = 0 then                                                                                                 
                                    insert into "public".sym_data                                                                                                                     
                                    (table_name, event_type, trigger_hist_id, row_data, channel_id, transaction_id, source_node_id, external_data, create_time)                                        
                                    values(                                                                                                                                                            
                                      'pim_individual',                                                                                                                                            
                                      'I',                                                                                                                                                             
                                      22,                                                                                                                                             
                                      
          case when new."id" is null then '' else '"' || cast(cast(new."id" as numeric) as varchar) || '"' end||','||
          case when new."birth_dt" is null then '' else '"' || to_char(new."birth_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when new."death_dt" is null then '' else '"' || to_char(new."death_dt", 'YYYY-MM-DD HH24:MI:SS.US') || '"' end||','||
          case when new."has_citizenship" is null then '' when new."has_citizenship" then '"1"' else '"0"' end||','||
          case when new."name" is null then '' else '"' || replace(replace(cast(new."name" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."patr_name" is null then '' else '"' || replace(replace(cast(new."patr_name" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."surname" is null then '' else '"' || replace(replace(cast(new."surname" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."gender_id" is null then '' else '"' || cast(cast(new."gender_id" as numeric) as varchar) || '"' end||','||
          case when new."nationality_id" is null then '' else '"' || cast(cast(new."nationality_id" as numeric) as varchar) || '"' end||','||
          case when new."list_identity_doc" is null then '' else '"' || replace(replace(cast(new."list_identity_doc" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."list_oms_doc" is null then '' else '"' || replace(replace(cast(new."list_oms_doc" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."list_job_org" is null then '' else '"' || replace(replace(cast(new."list_job_org" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."list_reg_name" is null then '' else '"' || replace(replace(cast(new."list_reg_name" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."list_snils" is null then '' else '"' || replace(replace(cast(new."list_snils" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."list_uid" is null then '' else '"' || replace(replace(cast(new."list_uid" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."birth_place" is null then '' else '"' || replace(replace(cast(new."birth_place" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."age_year" is null then '' else '"' || cast(cast(new."age_year" as numeric) as varchar) || '"' end||','||
          case when new."age_month" is null then '' else '"' || cast(cast(new."age_month" as numeric) as varchar) || '"' end||','||
          case when new."age_day" is null then '' else '"' || cast(cast(new."age_day" as numeric) as varchar) || '"' end||','||
          case when new."list_main_contact" is null then '' else '"' || replace(replace(cast(new."list_main_contact" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end,                                                                                                                                                      
                                      'public_pim_individual_default',                                                                                                                                                
                                      txid_current(),                                                                                                                                               
                                      "public".sym_node_disabled(),                                                                                                                   
                                      null,                                                                                                                                               
                                      CURRENT_TIMESTAMP                                                                                                                
                                    );                                                                                                                                                                 
                                  end if;                                                                                                                                                              
                                                                                                                                                                               
                                  return null;                                                                                                                                                         
                                end;
$fun$;

