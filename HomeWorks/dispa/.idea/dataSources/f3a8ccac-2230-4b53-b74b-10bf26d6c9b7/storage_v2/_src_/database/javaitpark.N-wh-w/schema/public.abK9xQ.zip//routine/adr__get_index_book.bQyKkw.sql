CREATE FUNCTION adr__get_index_book()
  RETURNS integer
STRICT
LANGUAGE plpgsql
AS $$
BEGIN
    return 3;
  END;
$$;

