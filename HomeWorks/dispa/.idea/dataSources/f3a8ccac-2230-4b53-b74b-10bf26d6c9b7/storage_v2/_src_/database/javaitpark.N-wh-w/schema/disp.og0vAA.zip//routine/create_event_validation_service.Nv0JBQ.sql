CREATE FUNCTION create_event_validation_service(xstandard integer, xorg integer)
  RETURNS text
LANGUAGE plpgsql
AS $$
DECLARE
   services text [] ;
   service text;
   service_name text ;
   ss_id text;
   
   sssd_service_id text;
   service_return text [];
    model_return text [];
    model_id text;
   
        
    BEGIN
       
                        
services=(select   array_agg(row_to_json(row(mnds.name, ss.id,sssd.service_id,mspe.model_patient_id)))
                from disp.md_standard_prescription_extended mspe
                left join md_standard_prescription msp on mspe.id = msp.id
                left join md_standard ms on ms.id = msp.standard_id
                left join md_prescription mp on mp.id = msp.id
                left join sr_service ss on ss.id = mp.service_type_id
                left join md_norm_document_service mnds on mnds.id = mspe.norm_doc_service_id
                left join disp.sr_srv_service_document sssd on sssd.document_service_id = mnds.id and sssd.owner_org_id = xorg -- Документ "Взрослая дисп. 1 этап"
              where msp.standard_id = xstandard
                   );

        


        if services is not null then
            foreach  service  in array services
                Loop
                --mes.id
                service_name:=cast((service::json->'f1')as text);
                ss_id:=cast((service::json->'f2')as text);
                sssd_service_id:=cast((service::json->'f3')as text);
                model_id=cast((service::json->'f4')as text);
                if (ss_id='null'and sssd_service_id='null' ) then 
                
                service_return:=array_append(service_return,service_name);
                end if;
                if (model_id='null') then
                model_return:=array_append(model_return,service_name);
                end if;
                

                END LOOP;
        end if;
       
if service_return is null and model_return  is null then return '!';  end if;
if (model_return is not null and service_return is not null) then return 'Сохранение невозможно. Услугам по приказу не указаны услуги МО:'||array_to_string(service_return,', ')||'. Назначениям стандарта не указаны базовые модели пациентов:' ||array_to_string(model_return,', '); else
if (service_return is not null) then return 'Сохранение невозможно. Услугам по приказу не указаны услуги МО:'||array_to_string(service_return,', ');

else return 'Сохранение невозможно. Назначениям стандарта не указаны базовые модели пациентов:'||array_to_string(model_return,', ');
end if ;
end if;
 return  array_to_string(service_return,', ');

        EXCEPTION WHEN others THEN
        return  ARRAY[]::text[];

END;
$$;

