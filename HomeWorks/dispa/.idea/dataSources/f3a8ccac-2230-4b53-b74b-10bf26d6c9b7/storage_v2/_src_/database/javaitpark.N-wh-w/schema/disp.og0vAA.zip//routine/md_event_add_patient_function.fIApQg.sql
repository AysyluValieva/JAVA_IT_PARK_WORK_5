CREATE FUNCTION md_event_add_patient_function(xeid integer, xpid integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
                          i integer;
                          code character varying;
                        begin
                        code=(select et.code from disp.md_event_type et join disp.md_event e on et.id = e.event_type where e.id = xeid);
                          i = nextval('disp.md_event_patient_id_seq');
                          insert into disp.md_event_patient (id, event_id, indiv_id, event_age) values (i, xeid, xpid,
                          (SELECT CONCAT(date_part('year',age( ( case when ((position('ДВ' in code) = 1)) then
                                              (select end_date from disp.md_event where id=xeid)
                                                          else now() end)
                          ,birth_dt)), '.', date_part('month',age(birth_dt))) FROM pim_individual where id = xpid));
                          insert into disp.md_event_questioning (id) values (i);
                          insert into disp.md_event_anthro (id) values (i);
                          insert into disp.md_dispr (id, event_id, indiv_id) values(i,xeid, xpid);
                          if (((position('ДС' in code) = 1) or (position('ОН' in code) = 1)) ) then
			                insert into disp.md_disp_orphans_result (id, is_before, event_patient_id) values (nextval('disp.md_disp_orphans_result_id_seq'), true, i);
			                insert into disp.md_disp_orphans_result (id, is_before, event_patient_id) values (nextval('disp.md_disp_orphans_result_id_seq'), false, i);
                          end if;
                          return i;
                        end;
$$;

