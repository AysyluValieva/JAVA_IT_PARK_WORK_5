CREATE VIEW dimension_date_day AS
  SELECT dimension_date.id,
    dimension_date.calendar_date,
    dimension_date.year_,
    dimension_date.quarter_of_year,
    dimension_date.month_of_year,
    dimension_date.week_of_year,
    dimension_date.day_of_month,
    dimension_date.day_of_week,
    dimension_date.day_of_year,
    dimension_date.half_of_year,
    dimension_date.aud_who,
    dimension_date.aud_when,
    dimension_date.aud_source,
    dimension_date.aud_who_create,
    dimension_date.aud_when_create,
    dimension_date.aud_source_create
   FROM indicators.dimension_date
  WHERE (dimension_date.dimension_date_def_id = 6);

COMMENT ON VIEW dimension_date_day IS 'Временной срез. Год, квартал, месяц, неделя, день.';

COMMENT ON COLUMN dimension_date_day.id IS 'Идентификатор';

COMMENT ON COLUMN dimension_date_day.calendar_date IS 'Дата/время';

COMMENT ON COLUMN dimension_date_day.year_ IS 'Год';

COMMENT ON COLUMN dimension_date_day.quarter_of_year IS 'Квартал года';

COMMENT ON COLUMN dimension_date_day.month_of_year IS 'Месяц года';

COMMENT ON COLUMN dimension_date_day.week_of_year IS 'Неделя года';

COMMENT ON COLUMN dimension_date_day.day_of_month IS 'День месяца';

COMMENT ON COLUMN dimension_date_day.day_of_week IS 'День недели';

COMMENT ON COLUMN dimension_date_day.day_of_year IS 'День года';

COMMENT ON COLUMN dimension_date_day.half_of_year IS 'Полугодие года';

