CREATE FUNCTION md_event_save_conclusion_function(xreferenceid integer, xissued date, xcontraindications boolean, xspecial_notes character varying, xexp date, xmedcommission integer, xindicationslist character varying)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
  indicationsListid json;
  close_reason integer;
begin
  delete from gibdd.md_gibdd_reference_indication where reference_id= xreferenceid;
  update gibdd.md_gibdd_reference set
    issued_date = xissued,
    special_notes = xspecial_notes,

    med_commission_res_group_id = xmedCommission
  where id = xreferenceid;

  update gibdd.md_gibdd_reference set
    exp_date = null
  where id = xreferenceid and is_contraindications = true;

  update gibdd.md_gibdd_reference set
    exp_date = xexp
  where id = xreferenceid and (is_contraindications is null or is_contraindications = false);

  foreach indicationsListid in array array(select value from json_array_elements(cast(xindicationsList as json)))
  LOOP
    insert into gibdd.md_gibdd_reference_indication(reference_id, indication_id) values (xreferenceid, indicationsListid::text::int);
  END LOOP;

  update gibdd.md_gibdd_reference_category rc set is_valid = (select not exists(select 1 from gibdd.md_gibdd_service_category sc join gibdd.md_gibdd_service s on sc.gibdd_service_id = s.id
  where s.event_patient_id = xreferenceid and sc.category_id = rc.category_id and sc.is_valid = false))
  where rc.reference_id = xreferenceid;

  update mc_case set closing_step_id = (select id from mc_step where case_id = (select case_id from disp.md_event_patient where id = xreferenceid) order by outcome_date desc limit 1)
  where id = (select case_id from disp.md_event_patient where id = xreferenceid) and closing_step_id is null;

  update gibdd.md_gibdd_reference set is_reopen = false, reopen_dt= null where id = xreferenceid;

  return xreferenceid;
end;
$$;

