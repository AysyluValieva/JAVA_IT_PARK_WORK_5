CREATE FUNCTION snils_generate()
  RETURNS text
LANGUAGE plpgsql
AS $$
DECLARE
   t_number text;
   i_summa integer;
   i_ostatok text;
BEGIN

/*
ПРИМЕР: Указан СНИЛС 112-233-445 95
Проверяем правильность контрольного числа: 
цифры номера        1 1 2 2 3 3 4 4 5 
номер позиции       9 8 7 6 5 4 3 2 1
Сумма = 1?9 + 1?8 + 2?7 + 2?6 + 3?5 + 3?4 + 4?3 + 4?2 + 5?1 = 95 
95 ? 101 = 0, остаток 95. 
Контрольное число 95 — указано верно 
*/
/*
summa=0;
  number='888' || "supp"."random_string_numbers"(6);
  for i in 1..9 loop 
  	 summa = summa + SUBSTRING (number, i, 1)::INTEGER* (10-i);
  end loop;
  ostatok=replace (to_char(summa%101,'00'), ' ','');
  number=number||ostatok;
  return to_char(replace(number,' ','')::bigint , '000-000-000 00');
  */
  
  --типа do while...
  i_summa=0;
  t_number='888' || "supp"."random_string_numbers"(6);
    --RAISE NOTICE 'функция %', t_number;
  for i in 1..9 loop 
  	 i_summa = i_summa + SUBSTRING (t_number, i, 1)::INTEGER* (10-i);
  end loop;
	  i_ostatok=(i_summa%101)::text;
	if(i_ostatok='0' or i_ostatok='100')
then i_ostatok='00';
else 
  i_ostatok=replace (to_char(i_summa%101,'00'), ' ','');
end if;
  t_number=t_number||i_ostatok;
    WHILE exists(select 1 from pim_individual_doc where number=t_number and type_id=19 )
LOOP
   i_summa=0;
  t_number='888' || "supp"."random_string_numbers"(6);
  for i in 1..9 loop 
  	 i_summa = i_summa + SUBSTRING (t_number, i, 1)::INTEGER* (10-i);
  end loop;
	  i_ostatok=(i_summa%101)::text;
	if(i_ostatok='0' or i_ostatok='100')
then i_ostatok='00';
else 
  i_ostatok=replace (to_char(i_summa%101,'00'), ' ','');
end if;
  t_number=t_number||i_ostatok;
END LOOP;
  
  RETURN t_number;
END;
$$;

