CREATE FUNCTION create_inoculation_service_rendered()
  RETURNS integer
LANGUAGE plpgsql
AS $$
DECLARE
            serviceRenderedId integer;
            BEGIN

            insert into sr_srv_rendered (id, is_rendered) values (nextval('sr_srv_rendered_seq'), false)
            returning id into serviceRenderedId;
            insert into md_srv_rendered (id) values (serviceRenderedId);

            return serviceRenderedId;

            END;
$$;

