CREATE FUNCTION func_pim_department_sync_hospital_unused_bed()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
/*
при создании/редактировании/удалении подразделения запишем исключение возможности использования коек в КФ
если подразделение ограничено датами создания и закрытия
*/
DECLARE
    rez             INTEGER;
    _department_id  INTEGER;
    _profile_id     INTEGER;
BEGIN
    IF (TG_OP = 'DELETE') THEN
        -- при удалении записи ПОДРАЗДЕЛЕНИЯ почистим все исключения
        DELETE FROM hospital.unused_bed where nlevel(bed_tree) = 1 and subpath(bed_tree,0,1) = OLD.id::text::ltree;
        RETURN OLD;
    ELSE
        -- если было изменение подразделения или профиля в текущем профиле подразделения то мы старые значения уже пересчитали, остается заполнить новое состояние
        WITH w_tree as (
                    SELECT  DISTINCT
                            d.id,
                            d.id :: TEXT :: LTREE  AS bed_tree,
                            d.from_dt - 1 as from_dt,
                            d.to_dt,
                            unnest(array[(d.from_dt - 1), d.to_dt]) as dt_dt
                    FROM    pim_department d
                    WHERE   d.id = NEW.id
                    ),

        w_tree_sort as (
            select  *, sum(sort) over (partition by bed_tree, dt_dt order by bed_tree, from_dt, sort, dt_dt, sort_name) as dd -- количество открытий и закрытий в один день
            FROM    (
                select  bed_tree, from_dt, sort, dt_dt, sort_name, LAG (sort, 1, 0) over (partition by bed_tree order by bed_tree, from_dt, sort, dt_dt, sort_name) as sort_lag, LEAD (sort, 1, -1) over (partition by bed_tree order by bed_tree, from_dt, sort, dt_dt, sort_name) as sort_lead
                from    (
                    select  bed_tree, from_dt, 2 as sort, dt_dt, 'begin' as sort_name from w_tree where from_dt is not null
                    UNION ALL
                    select  bed_tree, to_dt, 1, dt_dt, 'end' from w_tree where to_dt is not null
                    GROUP BY 1, 2, 3, 4, 5
                    order by 1, 2, 3, 4, 5
                    )t
                )t
            ),

        w_tree_new as  (-- расчетное состояние исключений по подразделению и профилю
            select  bed_tree, daterange(null, from_dt, '[]') as date_range, concat('по ', to_char(from_dt, 'dd.mm.yyyy'), ' это подразделение недоступно') as comment from w_tree_sort where sort_lag = 0 and sort = 2
            UNION ALL
            select  bed_tree, daterange(from_dt, null, '[]') as date_range, concat('c ', to_char(from_dt, 'dd.mm.yyyy'), ' это подразделение недоступно') as comment from w_tree_sort where sort_lag = 0 and sort_lead = -1 and sort = 1
            UNION ALL
            select  bed_tree, daterange(from_dt, lead_dt, '[]') as date_range, concat('c ', to_char(from_dt, 'dd.mm.yyyy'), ' по ' || to_char(lead_dt, 'dd.mm.yyyy'), ' это подразделение недоступно')
            from   (
                select *, lead(from_dt) over (partition by bed_tree order by bed_tree, from_dt) as lead_dt
                from w_tree_sort
                where --sort_lag <> 0
                    sort <> coalesce(sort_lag, 0)
                order by 1, 2, 3
                )t
            WHERE   sort = 1
                --and from_dt IS DISTINCT FROM  lead_dt
                and coalesce(from_dt, lead_dt) <= coalesce(lead_dt, from_dt)
            ),

        w_tree_bd as (
            select id, bed_tree, date_range, comment
            from hospital.unused_bed
            where nlevel(bed_tree) = 1 and subpath(bed_tree, 0, 1) = new.id::text::ltree
            ),

        w_tree_delta as (
            select  bed_tree as delta_bed_tree, date_range as delta_date_range, comment as delta_comment,
                sum(delta) as delta -- 1 - есть только в новом состоянии, добавляем в дельта
                                    -- 2 - есть только в бд, удаляем
                                    -- 3 - есть и там и там, ничего не делаем
            from (
                select distinct bed_tree, date_range, comment, 1 as delta from w_tree_new
                union all
                select bed_tree, date_range, comment, 2 as delta from w_tree_bd
                )t
            group by bed_tree, date_range, comment
            ),

        del_w_tree_bd as (
            delete from hospital.unused_bed using w_tree_delta
            WHERE bed_tree = delta_bed_tree and date_range = delta_date_range and comment = delta_comment
                and delta = 2
            RETURNING 1
            ),

        ins_w_tree_bd as (
            insert into hospital.unused_bed (bed_tree, date_range, comment)
            select delta_bed_tree, delta_date_range, delta_comment from w_tree_delta where delta = 1
            RETURNING 1
            )
        select 1 into REZ;
        RETURN NEW;
    END IF;
END;
$$;

