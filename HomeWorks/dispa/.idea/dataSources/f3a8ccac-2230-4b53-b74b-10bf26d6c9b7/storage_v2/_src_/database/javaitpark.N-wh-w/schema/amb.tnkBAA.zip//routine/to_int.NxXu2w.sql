CREATE FUNCTION to_int(text)
  RETURNS integer
LANGUAGE plpgsql
AS $$
begin
	if $1 ='' then return null; end if;
	if $1 ~ '\D' then return -1;
	else return $1::integer;
	end if;
end;
$$;

