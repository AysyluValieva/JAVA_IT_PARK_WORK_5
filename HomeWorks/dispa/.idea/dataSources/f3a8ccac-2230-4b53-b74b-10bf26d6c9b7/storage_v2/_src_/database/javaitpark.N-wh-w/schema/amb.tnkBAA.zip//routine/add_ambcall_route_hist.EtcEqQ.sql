CREATE FUNCTION add_ambcall_route_hist(xcall integer, xdt timestamp without time zone, xstat integer, xroute integer, xsubst integer, xbrg integer, xreg integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
	i integer;
  begin
    /*добавление записи о диспетчерезации в историю*/
	i = nextval('amb.md_ambcall_route_history_id_seq');
    insert into amb.md_ambcall_route_history (id,call_id,date_time,station_id,route_id,substation_id,brg_id,registrator_id)
    	VALUES(i,xcall,xdt,xstat,xroute,xsubst,xbrg,xreg);
    return i;
  end;
$$;

