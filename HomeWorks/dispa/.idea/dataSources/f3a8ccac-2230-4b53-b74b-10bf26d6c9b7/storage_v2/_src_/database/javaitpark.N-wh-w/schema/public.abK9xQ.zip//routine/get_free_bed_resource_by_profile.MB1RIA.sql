CREATE FUNCTION get_free_bed_resource_by_profile(strexpecteddate character varying, numberofdays integer, depid integer, profileid integer, orgid integer, resgroupid integer, OUT id integer, OUT dates timestamp without time zone)
  RETURNS SETOF record
LANGUAGE plpgsql
AS $$
declare

            dateFrom date;
            dateTo date;
            days interval;
            roleId integer;

            begin
            dateFrom = to_date(strExpectedDate, 'dd.mm.yyyy');
            dateTo=dateFrom + numberOfdays;
            days=cast(numberOfdays  as text)||' day';
            roleId=(select r.id from sr_res_role r where code='BED');

            return query  with
            srgr0 as (
            select resource_id, edatetime, role_id, group_id, rgr.id, bdatetime from sr_res_group_relationship rgr
            join sr_res_group rg on rg.id = rgr.group_id and rg.org_id = orgid
            where group_id<>resgroupid and role_id=roleId and (rgr.edatetime >= dateFrom or rgr.edatetime is null)
            ),


            srgr as
            (select *
            from srgr0 s0
            where
              (edatetime > dateFrom or edatetime is null) and group_id<>resgroupid and role_id=roleId
               and
               (
                   not exists (select 1 from srgr0 s2 where s2.role_id=roleId and resource_id = s0.resource_id and s2.group_id<>resgroupid  and s2.id <> s0.id and
                    ((s2.bdatetime >= s0.edatetime and s2.bdatetime <= s0.edatetime + days)
                     or
                   (s2.edatetime > s0.edatetime and s2.edatetime <= s0.edatetime + days)))
                 and
                    (exists (select 1 from srgr0 s2 where s2.role_id=roleId and resource_id = s0.resource_id and s2.id <> s0.id and s2.group_id<>resgroupid  and
                      s2.edatetime <= s0.bdatetime and s2.edatetime > dateFrom and s2.bdatetime <= dateTo)
                     or
                      s0.bdatetime < dateTo
                    )
               )
            )
             select sr.id, coalesce(min(srgr.edatetime + '1 hour'+ '1 min') , dateFrom) as plannedDate
             from md_bed_resource br
                  inner join sr_resource sr on br.id=sr.id
                  inner join md_bed b on b.id= br.bed_id
                  left outer join srgr on srgr.resource_id = sr.id
                  left outer join md_room room on room.id= b.room_id
                  inner join pim_room pr on pr.id=room.id
                  where pr.department_id=depId and b.bed_profile_id=profileId
                       and  not exists (select 1 from srgr0 s where s.resource_id=sr.id and s.edatetime is null and s.bdatetime is null )
                       and (srgr.resource_id is null or srgr.edatetime is not null )
             group by sr.id order by plannedDate;

            end;
$$;

