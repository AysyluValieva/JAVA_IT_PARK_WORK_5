CREATE FUNCTION journal_update(p_id integer, p_clinic_id integer, p_name character varying, p_begin_dt date, p_end_dt date, p_resp_id integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE

BEGIN
  IF exists(SELECT 1
            FROM sickdoc.journal j
            WHERE j.name = p_name AND j.clinic_id = p_clinic_id AND j.id <> p_id)
  THEN
    RAISE 'Журнал с наименованием % уже существует в МО. Введите уникальное наименование', p_name;
  END IF;

  UPDATE
    sickdoc.journal
  SET
    clinic_id            = p_clinic_id,
    name                 = p_name,
    begin_dt             = p_begin_dt,
    end_dt               = p_end_dt,
    responsible_id       = p_resp_id
  WHERE id = p_id;



END;
$$;

