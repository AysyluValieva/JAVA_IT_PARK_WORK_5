CREATE FUNCTION save_pregnant_risk_option(mapid integer, optionid integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
DECLARE
  optId INTEGER;
  rid INTEGER;
BEGIN
  optId = (select id from motherhood.mh_pregnant_map_risk_option mo where mo.pregnant_map_id = mapId and mo.risk_option_id = optionId LIMIT 1);
  IF (optId is NULL )
  THEN
    SELECT nextval('motherhood.mh_pregnant_map_risk_option_id_seq') INTO rid;
    INSERT INTO motherhood.mh_pregnant_map_risk_option (id, pregnant_map_id, risk_option_id)
    VALUES (rid, mapId, optionId);
  ELSE
    rid = optId;
  END IF;
  RETURN rid;
END;
$$;

