CREATE FUNCTION get_age_index(patient_id integer, open_dt date)
  RETURNS integer
IMMUTABLE
LANGUAGE plpgsql
AS $$
declare
    age integer;
    v_birth_dt date;
begin
    v_birth_dt = (SELECT birth_dt FROM pim_individual WHERE id = patient_id);
    if v_birth_dt IS NULL or open_dt IS NULL then return -1;
    end if;
    age = DATE_PART('year', open_dt) - DATE_PART('year', v_birth_dt) -
	  (CASE TO_CHAR(open_dt, 'MMDD') < TO_CHAR(v_birth_dt, 'MMDD') WHEN TRUE THEN 1 ELSE 0 END);
    return age;
end;
$$;

