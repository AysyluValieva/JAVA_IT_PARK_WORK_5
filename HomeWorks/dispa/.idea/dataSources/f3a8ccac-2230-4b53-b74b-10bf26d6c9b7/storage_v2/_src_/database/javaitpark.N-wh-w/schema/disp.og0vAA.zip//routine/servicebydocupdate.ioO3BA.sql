CREATE FUNCTION servicebydocupdate(xid integer, xsid integer, xdid integer, xdsid integer, xooid integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
          i integer;
        begin
          IF (select count(*) from disp.sr_srv_service_document where service_id = xsid and id = xid) > 0 THEN
            update disp.sr_srv_service_document set document_id = xdid, document_service_id = xdsid, owner_org_id = xooid
              where id = xid;
          ELSE
            update disp.sr_srv_service_document set owner_org_id = NULL, is_archive = TRUE
                where id = xid;
            -- delete from disp.sr_srv_service_document where service_id = xsid;
            insert into disp.sr_srv_service_document (id, service_id, document_id, document_service_id, owner_org_id, is_archive)
                values (nextval('disp.sr_srv_service_document_id_seq'), xsid, xdid, xdsid, xooid, FALSE);
          END IF;
          return 1;
        end;
$$;

