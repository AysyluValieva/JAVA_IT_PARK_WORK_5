CREATE FUNCTION aud_tables_to_audit()
  RETURNS SETOF character varying
LANGUAGE plpgsql
AS $$
DECLARE r varchar;
                    BEGIN
	                    for r in select '"' || table_schema || '"' ||'."'||table_name||'"'  from information_schema.tables
                        where table_type = 'BASE TABLE' and not table_schema like 'pg_%' and table_schema <> 'information_schema'
                        and table_name <> 'databasechangelog' and table_name <> 'databasechangeloglock'
                        and not table_name like '%_aud'
                        and not exists (select 1 from aud_excluded_schemas where schema_name = information_schema.tables.table_schema)
                        and not exists(select 1 from information_schema.triggers where trigger_name = 'audit_trigger' and event_object_schema ||'.'|| event_object_table = information_schema.tables.table_schema||'.'||information_schema.tables.table_name)
                        and not exists(select 1 from aud_excluded_tables where table_name = information_schema.tables.table_schema||'.'||information_schema.tables.table_name)
	                    LOOP
	                        return next r;
	                    END LOOP;
                    END;
$$;

