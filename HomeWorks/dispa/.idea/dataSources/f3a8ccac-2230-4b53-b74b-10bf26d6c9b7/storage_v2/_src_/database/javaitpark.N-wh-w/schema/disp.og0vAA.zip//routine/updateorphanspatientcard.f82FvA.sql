CREATE FUNCTION updateorphanspatientcard(xid integer, xcac integer, xloc integer, xreason integer, xmiss character varying, xbdate character varying, xedate character varying, xeducation_org integer, xstac_org integer, xindiv_id integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
    i integer;
  begin
    IF (select count(id) from disp.md_disp_orphans_patient_card where id = xid) = 0 THEN
      i = xid;
      insert into disp.md_disp_orphans_patient_card (id, category_accounting_child_id, location_id, reason_id, miss_reason, bdate, edate, education_org_id, stac_org_id)
        values (i, xcac, xloc, xreason, xmiss, to_date(xbdate, 'DD.MM.YYYY'), to_date(xedate, 'DD.MM.YYYY'), xeducation_org, xstac_org);
    ELSE
      update disp.md_disp_orphans_patient_card set category_accounting_child_id = xcac, location_id = xloc,
        reason_id = xreason, miss_reason = xmiss, bdate = to_date(xbdate, 'DD.MM.YYYY'), edate = to_date(xedate, 'DD.MM.YYYY'), education_org_id = xeducation_org, stac_org_id = xstac_org
        where id = xid;
    END IF;
    return i;
    end;
$$;

