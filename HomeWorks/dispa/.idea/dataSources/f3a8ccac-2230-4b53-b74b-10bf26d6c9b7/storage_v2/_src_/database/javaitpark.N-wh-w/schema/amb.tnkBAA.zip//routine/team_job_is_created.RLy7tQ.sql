CREATE FUNCTION team_job_is_created(xjobid integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
  	result integer;
    xsched integer;
	res integer;
    countres integer;
	resource record;
  begin
  	res:= 0;
    countres:=0;
    xsched := (select schedule_id from amb.sr_res_team_job where id = xjobid);
    if (xsched is not null)
    then
    	for resource in select work_place from amb.sr_schedule_team where id = xsched
        loop
        	countres := countres +1;
            if exists (select * from amb.sr_res_team_job_resourse srtjr
            			left join sr_resource sr on srtjr.resource_id = sr.id where team_job_id = xjobid and srtjr.workplace = resource.work_place)
            then res := res +1;
            end if;
        end loop;
    end if;
    IF EXISTS (select * from amb.sr_res_team_job_resourse srtjr left join sr_resource sr on srtjr.resource_id = sr.id where srtjr.team_job_id = xjobid and sr.res_kind_id = 1 and srtjr.workplace like '%Водитель%')
        and EXISTS(select * from amb.sr_res_team_job_resourse srtjr left join sr_resource sr on srtjr.resource_id = sr.id where srtjr.team_job_id = xjobid and sr.res_kind_id = 1 and (srtjr.workplace like '%Врач%' or srtjr.workplace like '%Фельдшер%'))
        and  exists(select * from amb.sr_res_team_job_resourse srtjr left join sr_resource sr on srtjr.resource_id = sr.id where srtjr.team_job_id = xjobid and sr.res_kind_id = 5)
    THEN
          	if ((res = countres) and (xsched is not null))
            	THEN result := 1;
                else result := 2;
            end if;
    ELSE result := 0;
    END IF;
	return result;
  end;
$$;

