CREATE FUNCTION get_audited_tables()
  RETURNS SETOF character varying
LANGUAGE plpgsql
AS $$
DECLARE r varchar;
                    BEGIN
	                    for r in select '"' || table_schema || '"' ||'."'||table_name||'"'  from information_schema.tables
                        where  exists(select 1 from information_schema.triggers where trigger_name = 'audit_trigger_full' and event_object_schema ||'.'|| event_object_table = information_schema.tables.table_schema||'.'||information_schema.tables.table_name)
	                    LOOP
	                        return next r;
	                    END LOOP;
                    END;
$$;

