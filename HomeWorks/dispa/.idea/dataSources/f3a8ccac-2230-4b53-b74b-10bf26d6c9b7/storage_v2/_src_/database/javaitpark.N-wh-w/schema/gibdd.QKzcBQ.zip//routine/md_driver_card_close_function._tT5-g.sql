CREATE FUNCTION md_driver_card_close_function(xcardid integer, xreasonid integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
begin
  update gibdd.md_gibdd_reference set status = 2, close_reason_id = xreasonid where id = xcardid;
  update gibdd.md_gibdd_reference set is_reopen = false, reopen_dt= null where id = xcardid;
  update gibdd.md_gibdd_reference_reference set is_valid = true
  where card_id = xcardid and id = (select max(id) from gibdd.md_gibdd_reference_reference where card_id = xcardid);
end;
$$;

