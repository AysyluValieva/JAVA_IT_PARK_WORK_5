CREATE FUNCTION fin_spec_gen_pick_tmp(p1_bill_id integer, p2_status_text text, p3_check_case_or_srv_date boolean, p4_multiple_srv boolean)
  RETURNS void
STRICT
LANGUAGE plpgsql
AS $$
DECLARE 
    _status TEXT;
    _main_bill_id INTEGER;
    _clinic_id INTEGER;
    _from_date DATE;
    _to_date DATE;
    _price_list_id INTEGER;
    _case_type_id INTEGER;
    _payment_method_arr INTEGER[];
    _care_regimen_arr INTEGER[];
    _case_init_goal_arr INTEGER[];
    _srv_id_arr INTEGER[];
BEGIN
    /*
        current version date 21.11.2014
    */
    ---------------------------------------------изменение статуса для исправительных счетов---------------------------------------------------------
    _status := CASE WHEN p2_status_text = 'VALIDATE' AND EXISTS (SELECT 1 FROM fin_bill_correctional WHERE id = p1_bill_id) THEN 'VALIDATE_CORRECT' ELSE p2_status_text END
    ;
    --------------------------------------------------очистка от предыдущего формирования------------------------------------------------------------
    IF 
        _status = 'VALIDATE' 
    THEN
        _srv_id_arr := ARRAY (SELECT id FROM fin_bill_generate WHERE bill_id = p1_bill_id)
        ;
    END IF;
    DELETE FROM fin_bill_generate WHERE bill_id = p1_bill_id
    ;
    DELETE FROM fin_bill_spec_item WHERE bill_id = p1_bill_id
    ;
    ------------------------------------------------------------------параметры----------------------------------------------------------------------
    _main_bill_id := fin_bill__get_main_bill (p1_bill_id)
    ;
    IF
        _status IN ('CORRECT', 'RECALCULATE', 'VALIDATE_CORRECT')
    THEN
        SELECT 
            from_date, to_date, clinic_id, price_list_id, case_type_id
            INTO 
            _from_date, _to_date, _clinic_id, _price_list_id, _case_type_id
        FROM
            fin_bill_main
        WHERE
            id = _main_bill_id
        ;
    ELSIF
        _status IN ('GENERATE', 'VALIDATE')
    THEN
        SELECT 
            coalesce (a.from_date, m.from_date), coalesce (a.to_date, m.to_date), m.clinic_id, m.price_list_id, m.case_type_id
            INTO 
            _from_date, _to_date, _clinic_id, _price_list_id, _case_type_id
        FROM
            fin_bill_main                 AS m 
            LEFT JOIN fin_bill_additional AS a ON m.id = a.base_id AND a.id = p1_bill_id
        WHERE
            m.id = _main_bill_id
        ;
    END IF;
    -------------------------------------------------режим лечения, способ оплаты, цель посещения----------------------------------------------------
    _care_regimen_arr   := ARRAY (SELECT care_regimen_id   FROM fin_bill_main_to_care_regimen   WHERE main_bill_id = _main_bill_id);
    _payment_method_arr := ARRAY (SELECT payment_method_id FROM fin_bill_main_to_payment_method WHERE main_bill_id = _main_bill_id);
    _case_init_goal_arr := ARRAY (SELECT case_init_goal_id FROM fin_bill_main_to_case_init_goal WHERE main_bill_id = _main_bill_id);
    -----------------------------------------------------------первичное добавление------------------------------------------------------------------
    IF 
        _status IN ('GENERATE', 'VALIDATE')
    THEN
        INSERT INTO fin_bill_generate 
        (
            id, bdate, edate, service_id, comment, tooth_number, funding_id, step_id, res_group_id, rdd_diagnosis_id,
            case_id, case_type_id, care_level_id, care_regimen_id, provision_condition_id, init_goal_id, 
            patient_id, closing_step_id, case_open_date, case_close_date,
            org_id, bill_id, price_list_id, from_date, to_date, contract_id
        )
            SELECT
                s.id, s.bdate, s.edate, s.service_id, s.comment, s.tooth_number, coalesce (s.funding_id, c.funding_id, 0), m.step_id, s.res_group_id, m.diagnosis_id,
                c.id, c.case_type_id, c.care_level_id, c.care_regimen_id, c.provision_condition_id, c.init_goal_id, 
                c.patient_id, c.closing_step_id, c.open_date, t.outcome_date, 
                coalesce (s.org_id, c.clinic_id), p1_bill_id, _price_list_id, _from_date, _to_date, s.contract_id
            FROM
                md_srv_rendered      AS m 
                JOIN sr_srv_rendered AS s ON m.id = s.id 
                LEFT JOIN mc_case    AS c ON c.id = m.case_id
                LEFT JOIN mc_step    AS t ON t.id = c.closing_step_id
            WHERE
                CASE WHEN p3_check_case_or_srv_date THEN t.outcome_date ELSE s.bdate END BETWEEN _from_date AND _to_date
                AND CASE WHEN p4_multiple_srv THEN TRUE ELSE NOT EXISTS (SELECT 1 FROM fin_bill_spec_item WHERE service_id = m.id AND bill_id <> p1_bill_id) END
                AND CASE 
                        WHEN c.id IS NULL THEN s.org_id = _clinic_id 
                        ELSE CASE WHEN p3_check_case_or_srv_date THEN c.clinic_id = _clinic_id ELSE coalesce (s.org_id, c.clinic_id) = _clinic_id END 
                    END
                AND CASE 
                        WHEN c.id IS NULL THEN TRUE 
                        ELSE CASE WHEN _case_type_id IS NULL THEN TRUE ELSE c.case_type_id = _case_type_id END
                    END
                AND CASE WHEN array_length (_care_regimen_arr  , 1) IS NOT NULL THEN c.care_regimen_id   = ANY (_care_regimen_arr)   ELSE TRUE END
                AND CASE WHEN array_length (_payment_method_arr, 1) IS NOT NULL THEN c.payment_method_id = ANY (_payment_method_arr) ELSE TRUE END
                AND CASE WHEN array_length (_case_init_goal_arr, 1) IS NOT NULL THEN c.init_goal_id      = ANY (_case_init_goal_arr) ELSE TRUE END
                AND CASE WHEN _status = 'VALIDATE' THEN m.id = ANY (_srv_id_arr) ELSE TRUE END
        ;
    ELSIF
        _status IN ('CORRECT', 'RECALCULATE', 'VALIDATE_CORRECT')
    THEN
        UPDATE fin_bill_spec_item_returned AS r
        SET 
            correctional_bill_id = p1_bill_id
        WHERE
            EXISTS (SELECT 1 FROM fin_bill_spec_item WHERE id = r.id AND bill_id = _main_bill_id) AND r.correctional_bill_id IS NULL
        ;
        INSERT INTO fin_bill_generate 
        (
            id, bdate, edate, service_id, comment, tooth_number, funding_id, step_id, res_group_id, rdd_diagnosis_id,
            case_id, case_type_id, care_level_id, care_regimen_id, provision_condition_id, init_goal_id, 
            patient_id, closing_step_id, case_open_date, case_close_date,
            org_id, bill_id, price_list_id, from_date, to_date, contract_id
        )
            SELECT
                f.id, f.bdate, f.edate, f.service_id, f.comment, f.tooth_number, f.funding_id, f.step_id, f.res_group_id, f.rdd_diagnosis_id,
                f.case_id, f.case_type_id, f.care_level_id, f.care_regimen_id, f.provision_condition_id, f.init_goal_id, 
                f.patient_id, f.closing_step_id, f.case_open_date, f.case_close_date, 
                f.org_id, p1_bill_id, _price_list_id, _from_date, _to_date, f.contract_id
            FROM
                fin_bill_spec_item               AS i 
                JOIN fin_bill_generate           AS f ON f.fin_bill_spec_item_id = i.id AND f.bill_id = i.bill_id
                JOIN fin_bill_spec_item_returned AS r ON r.id = i.id
            WHERE
                i.bill_id = _main_bill_id AND r.correctional_bill_id = p1_bill_id
        ;
    END IF;
EXCEPTION
    WHEN NO_DATA_FOUND THEN RAISE EXCEPTION 'Не заполнены необходимые параметры, либо неправильные данные счёта';
END;
$$;

