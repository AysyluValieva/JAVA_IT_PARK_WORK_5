CREATE FUNCTION setrequiredserviceforpatient(xcheckservices character varying, xepid integer)
  RETURNS text
LANGUAGE plpgsql
AS $$
declare
        serviceRequired integer [];
        servicePatient integer [];
        results text [];
        service integer;
        checkserviceId json;
        result  text ;
        begin


serviceRequired:=(array (select id  from disp.md_event_service where event_id=(select event_id from disp.md_event_patient where id=xepid limit 1) and required=true));

servicePatient:=(array(select mes.id from disp.md_event_service mes left join disp.md_event_service_patient mesp on mesp.service_id=mes.id where mesp.event_patient_id=xepid));
if(servicePatient is not null) then
foreach checkserviceId in array array(select value from json_array_elements(cast(xcheckservices as json)))
	LOOP
		if (checkserviceId::text!='null') then
			servicePatient:=array_append(servicePatient,checkserviceId::text::int);
		end if;

	END LOOP;
end if;

if (serviceRequired is not null) then

	foreach service in array serviceRequired
		loop

			if ((SELECT service = ANY(servicePatient)) =false) then

				results:=array_append(results, cast((select ss.name from sr_service ss where id=service limit 1)as text));
			end if;

		end loop;
end if;


result=array_to_string(results,', ');

if (result is null) then return 'true'; end if;

return result;
end;
$$;

