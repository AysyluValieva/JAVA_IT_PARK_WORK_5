CREATE FUNCTION ins_bum_num_value(xchange integer, xcount integer, xdep integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
                            xn integer;
                            xbv integer;
                            xev integer;
                            arr integer[];
                          begin
                            select into xn,xbv,xev id,value+1, value+xcount
                                from amb.md_ambulance_numbers where change_id = xchange and dep_id = xdep;
                            update amb.md_ambulance_numbers set value = xev where id = xn;
                        begin
                        for i in xbv..xev loop
                            if xev - xbv = 1 then
                            arr[1]:=xbv;
                            arr[2]:=xev;
                            exit;
                            else
                            arr[i]:=i;
                            end if;
                        end loop;
                        end;
                            insert into amb.md_ambulance_bum_numbers (change_id,numb_id,numbers)
                                values(xchange,xn,arr);
                          end;
$$;

