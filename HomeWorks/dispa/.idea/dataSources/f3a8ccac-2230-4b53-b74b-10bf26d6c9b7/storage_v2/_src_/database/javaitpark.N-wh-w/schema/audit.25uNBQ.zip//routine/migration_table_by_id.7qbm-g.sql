CREATE FUNCTION migration_table_by_id(_id integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
  _table_name    VARCHAR;
  _status_code   VARCHAR;
  _count_row     BIGINT;
  _error_message VARCHAR;
BEGIN
  SELECT table_name INTO _table_name FROM audit.migration_table WHERE id = _id;

  SELECT code
  INTO _status_code
  FROM audit.migration_table_status
  WHERE id = (SELECT status_id
              FROM audit.migration_table
              WHERE id = _id);

  IF _status_code = 'NOT_PROCESSED' OR _status_code = 'ERROR'
    THEN
      IF _status_code = 'NOT_PROCESSED'
      THEN
        EXECUTE audit.migration_table_log_write(_id, 'INFO', 'Migration process started');

        UPDATE audit.migration_table
        SET
          started_at = current_timestamp
        WHERE id = _id;
      ELSE
        EXECUTE audit.migration_table_log_write(_id, 'INFO', 'Migration process restarted');

        UPDATE audit.migration_table
        SET
          message    = NULL
        WHERE id = _id;
      END IF;

      IF (SELECT is_init FROM audit.migration_table WHERE id = _id) = FALSE
      THEN
        EXECUTE audit.migration_table_log_write(_id, 'INFO', 'Migration process init started');

        BEGIN
          EXECUTE audit.migration_init_process(_id);
          EXCEPTION
          WHEN OTHERS THEN
            _error_message = SQLERRM;

            EXECUTE audit.migration_table_log_write(
                _id, 'ERROR', concat('Migration process init error: ', _error_message));

            UPDATE audit.migration_table
            SET
              status_id  = (SELECT id
                            FROM audit.migration_table_status
                            WHERE code = 'ERROR'),
              updated_at = current_timestamp,
              message    = substring(_error_message, 0, 1000)
            WHERE id = _id;

            RETURN;
        END;

        UPDATE audit.migration_table
        SET is_init = TRUE
        WHERE id = _id;

        EXECUTE audit.migration_table_log_write(_id, 'INFO', 'Migration process init finished');

        --проверяем сколько записей осталось в _aud - таблице
        SELECT count_row INTO _count_row FROM audit.migration_table WHERE id = _id;

        IF _count_row = 0
        THEN
          EXECUTE audit.migration_table_log_write(_id, 'INFO', 'Migration process finished');

          UPDATE audit.migration_table
          SET
            status_id   = (SELECT id
                           FROM audit.migration_table_status
                           WHERE code = 'COMPLETED'),
            finished_at = current_timestamp,
            updated_at  = current_timestamp
          WHERE id = _id;

          RETURN;
        END IF;
      END IF;
    ELSE
      RETURN;
  END IF;

  --процесс миграции данных
  EXECUTE audit.migration_table_log_write(_id, 'INFO', 'Migration data started');

  BEGIN
    EXECUTE audit.migration_migrate_rows(_id);
    EXCEPTION
    WHEN OTHERS THEN
      _error_message = SQLERRM;
      EXECUTE audit.migration_table_log_write(_id, 'ERROR', concat('Migration data error: ', _error_message));

      UPDATE audit.migration_table
      SET
        status_id  = (SELECT id
                      FROM audit.migration_table_status
                      WHERE code = 'ERROR'),
        updated_at = current_timestamp,
        message    = substring(_error_message, 0, 1000)
      WHERE id = _id;

      RETURN;
  END;

  EXECUTE audit.migration_table_log_write(_id, 'INFO', 'Migration data finished');
  EXECUTE audit.migration_table_log_write(_id, 'INFO', 'Migration process finished');

  UPDATE audit.migration_table
  SET
    status_id   = (SELECT id FROM audit.migration_table_status WHERE code = 'COMPLETED'),
    updated_at  = current_timestamp,
    finished_at = current_timestamp
  WHERE id = _id;
END;
$$;

