CREATE FUNCTION add_amb_call_cityservice(xcall integer, xtype boolean, xreason integer, xdescr character varying, xreg integer, xmessage character varying, xservice integer, xclinic integer, xemp integer, xaccepted character varying)
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
  	xnote integer:= 11;
    xcnote integer;
  begin
	xcnote = amb.add_call_note (xcall,xnote,xtype,xreason,xdescr,xreg,xservice);
    if xtype THEN
        insert into amb.md_ambulance_call_in_cityservice (id,call_note_id,message_number,service_id,accepted)
    		values (nextval('amb.md_ambulance_call_in_cityservice_id_seq'),xcnote,xmessage,xservice,xaccepted);
        if xservice = 8 THEN
        	insert into amb.md_ambulance_call_in_clinic (id,call_note_id,message_number,clinic_id,employee_id,accepted)
    		values (nextval('amb.md_ambulance_call_in_clinic_id_seq'),xcnote,xmessage,xclinic,xemp,xaccepted);
        end if;
    end if;
  end;
$$;

