CREATE FUNCTION migration_get_rev_type_parent_table_name(_table_name character varying)
  RETURNS character varying
LANGUAGE plpgsql
AS $$
DECLARE
  _parent_table_name VARCHAR;
  _check BOOLEAN = TRUE ;
BEGIN
  IF (SELECT exists(SELECT 1
                    FROM information_schema.columns
                    WHERE table_name = replace(_table_name, 'public.', '') AND column_name = 'revtype'))
  THEN RETURN NULL; END IF;

  _table_name = replace(replace(_table_name, 'public.', ''), '_aud', '');

  WHILE _check LOOP
    SELECT table_name
    INTO _parent_table_name
    FROM information_schema.constraint_column_usage
    WHERE table_schema = 'public' AND constraint_schema = 'public' AND column_name = 'id' AND constraint_name IN (
      SELECT t.constraint_name
      FROM information_schema.key_column_usage AS c
        LEFT JOIN information_schema.table_constraints AS t
          ON t.constraint_name = c.constraint_name
      WHERE t.table_name = _table_name AND t.constraint_type = 'FOREIGN KEY' AND c.column_name = 'id');

    IF _parent_table_name ISNULL THEN RETURN NULL; END IF;

    IF (SELECT exists(SELECT 1
                      FROM information_schema.columns
                      WHERE table_name = concat(_parent_table_name, '_aud') AND column_name = 'revtype'))
    THEN RETURN concat(_parent_table_name, '_aud'); END IF;

    _table_name = _parent_table_name;
  END LOOP;
END;
$$;

