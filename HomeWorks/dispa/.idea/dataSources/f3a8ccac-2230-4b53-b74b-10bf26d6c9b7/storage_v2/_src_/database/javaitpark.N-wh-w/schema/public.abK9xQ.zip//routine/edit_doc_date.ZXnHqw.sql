CREATE FUNCTION edit_doc_date(pat_id integer, xissue_dt date, type_doc integer, xexpire_dt date)
  RETURNS integer
LANGUAGE plpgsql
AS $$
DECLARE
                doc record;
                begin

                for doc in (SELECT id, issue_dt
                            FROM pim_individual_doc pid
                            WHERE pid.indiv_id = pat_id
                            and pid.expire_dt is null
                            and (xexpire_dt is null or (pid.issue_dt is not null and xexpire_dt >= pid.issue_dt))
                            and (pid.type_id = type_doc
                            or pid.type_id in (SELECT id FROM pim_doc_type
                                               WHERE code IN ('MHI_OLDER','MHI_UNIFORM', 'MHI_TEMP') AND
                                               (select count(*)
                                               from pim_doc_type
                                               where code in ('MHI_OLDER','MHI_UNIFORM', 'MHI_TEMP')
                                               and id = type_doc) > 0))
                            )
                loop
                if(doc.issue_dt >= xissue_dt)
                then UPDATE pim_individual_doc
                     SET expire_dt = cast(xissue_dt - cast('1 day' as interval) as date),
                        issue_dt = cast(xissue_dt - cast('1 day' as interval) as date),
                        is_active = false
                     WHERE id = doc.id;
                else UPDATE pim_individual_doc
                     SET expire_dt = cast(xissue_dt - cast('1 day' as interval) as date),
                        is_active = false
                     WHERE id = doc.id;
                end if;
                end loop;
                return 1;
                end;
$$;

