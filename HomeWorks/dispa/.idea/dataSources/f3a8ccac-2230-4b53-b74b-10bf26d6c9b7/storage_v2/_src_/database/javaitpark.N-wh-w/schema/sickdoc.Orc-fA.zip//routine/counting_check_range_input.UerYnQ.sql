CREATE FUNCTION counting_check_range_input(p_requisites character varying)
  RETURNS boolean
LANGUAGE plpgsql
AS $$
DECLARE

  l_record RECORD;
  l_arr_input varchar[];
  l_str_iterator varchar;
  l_arr bigint[] DEFAULT '{}';
  l_arr_total bigint[] DEFAULT '{}';
  l_begin bigint;
  l_end bigint;
BEGIN

  l_arr_input := string_to_array(p_requisites,';');
  FOREACH l_str_iterator IN ARRAY l_arr_input
  LOOP
     l_arr := regexp_split_to_array(l_str_iterator, '-');
     l_begin := l_arr[1];
     IF array_length(l_arr, 1) = 2 THEN l_end := l_arr[2]; ELSE l_end := l_arr[1]; END IF;
     WHILE (l_begin <= l_end)
       LOOP
	       IF l_arr_total @> ARRAY[l_begin] THEN
		       RETURN FALSE;
	       ELSE
		       l_arr_total := l_arr_total || l_begin;
		       l_begin := l_begin + 1;
	       END IF;
       END LOOP;
  END LOOP;

  RETURN true;
END;

$$;

