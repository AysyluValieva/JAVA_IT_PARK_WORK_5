CREATE FUNCTION fsym_on_u_for_pblc_ddrss_hs_ndx_mngrp()
  RETURNS trigger
LANGUAGE plpgsql
AS $fun$
declare var_row_data text; 
                                declare var_old_data text; 
                                begin
                                   
                                  if 1=1 and "public".sym_triggers_disabled() = 0 then                                                                                                 
                                    var_row_data := 
          case when new."id" is null then '' else '"' || cast(cast(new."id" as numeric) as varchar) || '"' end||','||
          case when new."range" is null then '' else '"' || replace(replace(cast(new."range" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."index" is null then '' else '"' || replace(replace(cast(new."index" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."code" is null then '' else '"' || replace(replace(cast(new."code" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."street_id" is null then '' else '"' || cast(cast(new."street_id" as numeric) as varchar) || '"' end; 
                                    var_old_data := 
          case when old."id" is null then '' else '"' || cast(cast(old."id" as numeric) as varchar) || '"' end||','||
          case when old."range" is null then '' else '"' || replace(replace(cast(old."range" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when old."index" is null then '' else '"' || replace(replace(cast(old."index" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when old."code" is null then '' else '"' || replace(replace(cast(old."code" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when old."street_id" is null then '' else '"' || cast(cast(old."street_id" as numeric) as varchar) || '"' end; 
                                    if 1=1 then 
                                    insert into "public".sym_data                                                                                                                     
                                    (table_name, event_type, trigger_hist_id, pk_data, row_data, old_data, channel_id, transaction_id, source_node_id, external_data, create_time)                     
                                    values(                                                                                                                                                            
                                      'address_house_index',                                                                                                                                            
                                      'U',                                                                                                                                                             
                                      94,                                                                                                                                             
                                      
          case when old."id" is null then '' else '"' || cast(cast(old."id" as numeric) as varchar) || '"' end,                                                                                                                                                      
                                      var_row_data,                                                                                                                                                      
                                      var_old_data,                                                                                                                                                   
                                      'public_address_house_index_default',                                                                                                                                                
                                      txid_current(),                                                                                                                                               
                                      "public".sym_node_disabled(),                                                                                                                   
                                      null,                                                                                                                                               
                                      CURRENT_TIMESTAMP                                                                                                                
                                    );                                                                                                                                                                 
                                  end if;                                                                                                                                                              
                                  end if;                                                                                                                                                              
                                                                                                                                                                               
                                  return null;                                                                                                                                                         
                                end;
$fun$;

