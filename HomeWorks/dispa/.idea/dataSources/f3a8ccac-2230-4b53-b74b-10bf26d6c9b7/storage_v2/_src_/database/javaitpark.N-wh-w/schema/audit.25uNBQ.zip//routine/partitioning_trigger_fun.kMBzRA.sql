CREATE FUNCTION partitioning_trigger_fun()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE
                  app_user           TEXT;
                  app_source         TEXT;
                  new_row_store      hstore;
                  old_row_store      hstore;
                  delta              hstore;
                  nullable_key       TEXT;
                  insert_query       TEXT;
                  pk_column_info     RECORD;
                  pk_column_names    TEXT;
                  pk_values_from_new TEXT;
                  pk_values_from_old TEXT;
                  aud_when           TIMESTAMP;
                  table_name         VARCHAR;
                  table_postfix      VARCHAR;
                  period_code        VARCHAR;
                  period_start_date  TIMESTAMP;
                  period_end_date    TIMESTAMP;
                BEGIN
                  BEGIN
                    SELECT current_setting('app.user')
                    INTO app_user;
                    IF app_user = 'unknown'
                    THEN
                      app_user = CURRENT_USER;
                    END IF;
                    EXCEPTION
                    WHEN OTHERS THEN
                      app_user = CURRENT_USER;
                  END;

                  BEGIN
                    SELECT current_setting('app.source')
                    INTO app_source;
                    EXCEPTION
                    WHEN OTHERS THEN
                      app_source = 'DB';
                  END;

                  BEGIN
                    IF current_setting('aud.when') = '' THEN
                      aud_when = current_timestamp;
                      ELSE
                        SELECT to_timestamp(current_setting('aud.when'), 'YYYY-MM-DD HH24:MI:SS:MS')
                        INTO aud_when;
                    END IF;
                    EXCEPTION
                    WHEN OTHERS THEN
                      aud_when = current_timestamp;
                  END;

                  period_code = lower(TG_ARGV [0]);
                  table_name = TG_TABLE_SCHEMA || '$' || TG_TABLE_NAME :: TEXT;

                  IF period_code != 'none'
                  THEN
                    period_start_date = date_trunc(period_code, aud_when);
                    table_postfix = (SELECT concat('$', left(period_code, 1), '_', to_char(period_start_date, 'YYYY_MM_DD')));

                    BEGIN
                      PERFORM ('audit.' || table_name || table_postfix) :: REGCLASS;
                      EXCEPTION
                      WHEN undefined_table THEN
                        IF period_code = 'week'
                          THEN period_end_date = period_start_date + INTERVAL '1 week';
                        ELSEIF period_code = 'month'
                          THEN period_end_date = period_start_date + INTERVAL '1 month';
                        ELSEIF period_code = 'quarter'
                          THEN period_end_date = period_start_date + INTERVAL '3 month';
                        ELSE
                          period_end_date = period_start_date + INTERVAL '1 year';
                        END IF;

                        EXECUTE format(
                            'CREATE TABLE audit."%1$s" (CHECK (aud_when >= ''%2$s''::TIMESTAMP AND aud_when < ''%3$s''::TIMESTAMP))
                              INHERITS (audit."%4$s")',
                            concat(table_name, table_postfix)::TEXT, period_start_date, period_end_date, table_name);
                    END;
                    table_name = table_name || table_postfix;
                  END IF;

                  IF (TG_OP = 'INSERT' OR TG_OP = 'UPDATE')
                  THEN
                    new_row_store = hstore(NEW.*);
                  END IF;

                  IF (TG_OP = 'DELETE' OR TG_OP = 'UPDATE')
                  THEN
                    old_row_store = hstore(OLD.*);
                  END IF;

                  pk_column_names = '';
                  pk_values_from_new = '';
                  pk_values_from_old = '';

                  FOR pk_column_info IN SELECT
                                          pg_attribute.attname :: TEXT                               AS column_name,
                                          format_type(pg_attribute.atttypid, pg_attribute.atttypmod) AS type
                                        FROM pg_index, pg_class, pg_attribute, pg_namespace
                                        WHERE
                                          pg_class.oid = (TG_TABLE_SCHEMA || '.' || TG_TABLE_NAME) :: REGCLASS AND
                                          indrelid = pg_class.oid AND
                                          pg_class.relnamespace = pg_namespace.oid AND
                                          pg_attribute.attrelid = pg_class.oid AND
                                          pg_attribute.attnum = ANY (pg_index.indkey)
                                          AND indisprimary
                  LOOP
                    pk_column_names = pk_column_names || pk_column_info.column_name || ', ';

                    IF (TG_OP = 'INSERT' OR TG_OP = 'UPDATE')
                    THEN
                      pk_values_from_new =
                      pk_values_from_new || '''' || (new_row_store :: hstore -> pk_column_info.column_name) || '''' || '::' ||
                      pk_column_info.type || ', ';
                    END IF;

                    IF (TG_OP = 'DELETE')
                    THEN
                      pk_values_from_old =
                      pk_values_from_old || '''' || (old_row_store :: hstore -> pk_column_info.column_name) || '''' || '::' ||
                      pk_column_info.type || ', ';
                    END IF;
                  END LOOP;

                  IF (TG_OP = 'INSERT')
                  THEN
                    insert_query = format(
                        'INSERT INTO audit."%s" (%s type, delta, aud_when, aud_who, aud_source) VALUES (%s $1, $2, $3, $4, $5);',
                        table_name, pk_column_names, pk_values_from_new);

                    FOR nullable_key IN SELECT hs.key
                                        FROM each(new_row_store) hs
                                        WHERE hs.value IS NULL
                    LOOP
                      -- exclude null values
                      new_row_store = new_row_store - ('{' || nullable_key || '}') :: TEXT [];
                    END LOOP;

                    delta = new_row_store -
                             '{aud_when, aud_who, aud_source, aud_when_create, aud_who_create, aud_source_create}' :: TEXT [];

                  ELSEIF TG_OP = 'UPDATE'
                    THEN
                      delta = new_row_store - old_row_store -
                               '{aud_when, aud_who, aud_source, aud_when_create, aud_who_create, aud_source_create}' :: TEXT [];
                      IF delta = hstore('') THEN RETURN NULL; END IF;
                      insert_query = format(
                          'INSERT INTO audit."%s" (%s type, delta, aud_when, aud_who, aud_source) VALUES (%s $1, $2, $3, $4, $5);',
                          table_name, pk_column_names, pk_values_from_new);

                  ELSEIF TG_OP = 'DELETE'
                    THEN
                      insert_query = format(
                          'INSERT INTO audit."%s" (%s type, delta, aud_when, aud_who, aud_source) VALUES (%s $1, $2, $3, $4, $5);',
                          table_name, pk_column_names, pk_values_from_old);
                      delta = old_row_store;
                  END IF;

                  BEGIN
                    EXECUTE insert_query
                    USING left(TG_OP, 1), delta, aud_when, app_user, app_source;
                  END;

                  IF (TG_OP = 'DELETE') THEN RETURN OLD;
                  ELSE RETURN NEW;
                  END IF;
                END;
$$;

