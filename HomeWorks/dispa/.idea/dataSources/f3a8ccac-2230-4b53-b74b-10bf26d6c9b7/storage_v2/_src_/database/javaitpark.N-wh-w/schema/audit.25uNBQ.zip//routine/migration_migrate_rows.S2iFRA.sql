CREATE FUNCTION migration_migrate_rows(_id integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
  _process_record    RECORD;
  _diapason_record   RECORD;
  _count_sub_process INT;
  _error_message     VARCHAR;
  _table_name        VARCHAR;
  _started_at        TIMESTAMP;
BEGIN
  SELECT * INTO _process_record FROM audit.migration_batch_process WHERE table_id = _id;

  IF _process_record.status_id = (SELECT id FROM audit.migration_batch_process_status WHERE code = 'COMPLETED')
  THEN RETURN;
  END IF;

  SELECT count(*)
  INTO _count_sub_process
  FROM audit.migration_batch_sub_process
  WHERE process_id = _process_record.id AND is_executed = FALSE;

  IF _count_sub_process = 0
  THEN
    UPDATE audit.migration_batch_process
    SET status_id = (SELECT id
                     FROM audit.migration_batch_process_status
                     WHERE code = 'COMPLETED'),
      finished_at = current_timestamp,
      updated_at  = current_timestamp
    WHERE table_id = _id;

    RETURN;
  END IF;

  SELECT table_name INTO _table_name FROM audit.migration_table WHERE id = _process_record.table_id;

  WHILE _count_sub_process > 0 LOOP
    SELECT *
    INTO _diapason_record
    FROM audit.migration_batch_sub_process
    WHERE process_id = _process_record.id AND is_executed = FALSE
    ORDER BY from_row_id
    LIMIT 1;

    EXECUTE audit.migration_table_log_write(
        _id, 'INFO', concat('Start migrate rows between ', _diapason_record.from_row_id, ', and ',
                            _diapason_record.to_row_id));

    _started_at = current_timestamp;

    BEGIN
      EXECUTE audit.migration_rows_by_diapason(_table_name, _diapason_record.from_row_id, _diapason_record.to_row_id);
      EXCEPTION
      WHEN OTHERS THEN
        _error_message = SQLERRM;

        EXECUTE audit.migration_table_log_write(
            _id, 'ERROR', concat('Migration rows between ', _diapason_record.from_row_id, ' and ',
                                                _diapason_record.to_row_id, ' error: ', _error_message));

        UPDATE audit.migration_batch_process
        SET status_id = (SELECT id
                         FROM audit.migration_batch_process_status
                         WHERE code = 'ERROR'),
          updated_at  = current_timestamp
        WHERE table_id = _id;

        RAISE EXCEPTION '%', _error_message;
    END;

    EXECUTE audit.migration_table_log_write(
        _id, 'INFO', concat('Migration rows between ', _diapason_record.from_row_id, ' and ',
                                           _diapason_record.to_row_id, ' error: ', _error_message));

    UPDATE audit.migration_batch_sub_process
    SET
      is_executed = TRUE,
      started_at = _started_at,
      finished_at = current_timestamp
    WHERE id = _diapason_record.id;

    _count_sub_process = _count_sub_process - 1;
  END LOOP;

  EXECUTE audit.migration_table_log_write(_id, 'INFO', 'Migration data finished');

  UPDATE audit.migration_batch_process
  SET status_id = (SELECT id
                   FROM audit.migration_batch_process_status
                   WHERE code = 'COMPLETED'),
    finished_at = current_timestamp,
    updated_at  = current_timestamp
  WHERE table_id = _id;
END;
$$;

