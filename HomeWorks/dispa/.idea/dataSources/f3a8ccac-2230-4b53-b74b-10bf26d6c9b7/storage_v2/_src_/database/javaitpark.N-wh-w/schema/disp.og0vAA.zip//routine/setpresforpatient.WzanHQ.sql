CREATE FUNCTION setpresforpatient(xepid integer, xepsid integer, xsid integer, xcheck boolean)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
          i integer;
        begin
          IF xcheck = TRUE THEN
            insert into disp.md_event_service_patient (id, service_id, indiv_id, event_id, event_patient_id)
              values (nextval('disp.md_event_service_patient_id_seq'), xsid,
                (select indiv_id from disp.md_event_patient where id = xepid),
                (select event_id from disp.md_event_patient where id = xepid), xepid);
          ELSE
            delete from disp.md_event_service_patient where id = xepsid;
          END IF;
          return 1;
        end;
$$;

