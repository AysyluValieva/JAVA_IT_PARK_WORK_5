CREATE FUNCTION updateorphansmaturity(xid integer, xweight character varying, xheight character varying, xhc character varying, xim character varying, xih character varying, xcf character varying, xmf character varying, xesf character varying, xlf character varying, xpsid integer, xintid integer, xevsid integer, xmp integer, xmaleax integer, xmfa integer, xfp integer, xfax integer, xfma integer, xfme integer, xmenarhe character varying, xmrid integer, xmqid integer, xmpid integer, xvmid integer, xvhid integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
    i integer;
  begin
    IF (select count(id) from disp.md_disp_orphans_maturity where id = xid) = 0 THEN
      i = xid;
      insert into disp.md_disp_orphans_maturity (id, weight, height, head_circumference, index_mass, index_height, cognitive_function, motor_function, emotional_social_function, language_function, psychomotor_sphere_id, intelligence_id, emotional_vegetative_sphere_id, male_p, male_ax, male_fa, female_p, female_ax, female_ma, female_me, menarhe, menses_rate_id, menses_quantity_id, menses_pain_id, value_mass, value_height)
        values (i, xweight, xheight, xhc, xim, xih, xcf, xmf, xesf, xlf, xpsid, xintid, xevsid, xmp, xmaleax, xmfa, xfp, xfax, xfma, xfme, xmenarhe, xmrid, xmqid, xmpid, xvmid, xvhid);
    ELSE
      update disp.md_disp_orphans_maturity set weight = xweight, height = xheight, head_circumference = xhc, index_mass = xim, index_height = xih,
          cognitive_function = xcf, motor_function = xmf, emotional_social_function = xesf, language_function = xlf,
          psychomotor_sphere_id = xpsid, intelligence_id = xintid, emotional_vegetative_sphere_id = xevsid, male_p = xmp,
          male_ax = xmaleax, male_fa = xmfa, female_p = xfp, female_ax = xfax, female_ma = xfma, female_me = xfme, menarhe = xmenarhe,
          menses_rate_id = xmrid, menses_quantity_id = xmqid, menses_pain_id = xmpid, value_mass = xvmid, value_height = xvhid
        where id = xid;
    END IF;
    return i;
    end;
$$;

