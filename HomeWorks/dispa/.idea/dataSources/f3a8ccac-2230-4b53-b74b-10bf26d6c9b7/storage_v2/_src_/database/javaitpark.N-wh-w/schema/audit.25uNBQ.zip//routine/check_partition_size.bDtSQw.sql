CREATE FUNCTION check_partition_size()
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
                  max_size BIGINT;
                BEGIN
                  BEGIN
                    PERFORM current_setting('app.source');
                    EXCEPTION
                    WHEN OTHERS THEN
                      PERFORM set_config('app.source', 'DB', true);
                  END;

                  SELECT value
                  INTO max_size
                  FROM audit.param_setting
                  WHERE code = 'partition_max_size';

                  INSERT INTO public.partition_max_size_exceeding_notification (table_setting_id, partition_period_id, created_at)
                    SELECT
                      ts.id,
                      ts.partition_period_id,
                      current_timestamp
                    FROM (SELECT DISTINCT concat(split_part(table_name, '$', 1), '.', split_part(table_name, '$', 2)) AS table_name
                          FROM (
                                 SELECT
                                   t.table_name        AS table_name,
                                   reltuples :: BIGINT AS count_record
                                 FROM information_schema.tables t
                                   JOIN pg_class c ON c.oid = concat(t.table_schema, '.', t.table_name) :: REGCLASS
                                 WHERE table_schema = 'audit' AND table_type = 'BASE TABLE' AND t.table_name LIKE '%$%') t
                          WHERE count_record > max_size) t
                      JOIN audit.table_setting ts ON t.table_name = concat(ts.table_schema, '.', ts.table_name)
                      LEFT JOIN audit.repartitioning_task rt ON ts.id = rt.table_setting_id AND rt.status_id = 1
                    WHERE rt ISNULL;
                END;
$$;

