CREATE FUNCTION default_event_age(xepid integer, xagree_date date)
  RETURNS text
LANGUAGE plpgsql
AS $$
dECLARE
  birth_date date;
  event_year text;
  model_age text [];
  agree_age INTEGER;
  ma INTEGER;
  period_begin INTERVAL;
  period_end INTERVAL;
  result_age INTEGER;

BEGIN
  if xagree_date is null then RETURN NULL; end if;
  birth_date = (select birth_dt from pim_individual where id = (select indiv_id from disp.md_event_patient where id = xepid));
  agree_age = date_part('year',age(xagree_date, birth_date))::int * 12 +
              date_part('month',age(xagree_date, birth_date))::int;

  event_year = date_part('year',(select start_date from disp.md_event where id = (select event_id from disp.md_event_patient WHERE id = xepid)));
  period_begin = age(to_date('01.01.'||event_year, 'DD.MM.YYYY'),birth_date);
  period_end = age(to_date('31.12.'||event_year, 'DD.MM.YYYY'),birth_date);

  model_age=(select ARRAY(select (split_part(model_ages,'.',1)::int * 12 + lpad(split_part(model_ages,'.',2),2,'0')::int)
                          from (select distinct regexp_split_to_table(replace(mmpb.age,' ',''),',') as model_ages
                                from disp.md_event_service mes
                                  left join disp.md_event_service_model mesm on mesm.event_service_id=mes.id
                                  left join disp.md_model_patient mmp on mmp.id=mesm.model_id
                                  inner join disp.md_model_patient_base mmpb on  mmpb.model_id=mmp.id
                                  left join pim_individual i on i.id= (select indiv_id from disp.md_event_patient where id=xepid)
                                where mes.event_id=(select event_id from disp.md_event_patient where id=xepid) and mmp.base is true and mmpb.gender_id=i.gender_id) as set_ages
                          where (split_part(model_ages,'.',1)::int * 12 + lpad(split_part(model_ages,'.',2),2,'0')::int)
                          between (date_part('year',period_begin)::int * 12 + date_part('month',period_begin)::int) and
                          (date_part('year',period_end)::int * 12 + date_part('month',period_end)::int)
                          order by 1));

  if array_length(model_age, 1) IS NULL then RETURN NULL; end if;
  foreach ma in array model_age
  Loop
    if ma >= agree_age
    then
      result_age := ma; exit;
    end if;
  end LOOP;

  if result_age < 12 then
    RETURN '0.'||result_age;
  ELSE
    RETURN result_age/12 ||'.'||result_age%12;
  end if;

END;
$$;

