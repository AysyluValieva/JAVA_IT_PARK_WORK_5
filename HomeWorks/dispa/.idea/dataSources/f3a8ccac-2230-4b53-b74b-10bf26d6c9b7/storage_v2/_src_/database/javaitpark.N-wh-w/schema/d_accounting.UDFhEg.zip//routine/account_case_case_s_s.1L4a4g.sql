CREATE FUNCTION account_case_case_s_s()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
declare
                begin
                update mc_case c set is_social_significant = (
                select r.is_social_significant from d_accounting.register r
                join d_accounting.account a on a.register_id = r.id
                join d_accounting.account_case ac on ac.account_id = a.id
                where ac.account_id = NEW.account_id)
                where c.id = NEW.case_id;
                return NEW;
                end;
$$;

