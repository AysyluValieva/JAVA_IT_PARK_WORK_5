CREATE FUNCTION deviation_from_standard_of_care(xpatient_id integer, xcase_id integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
  _standart_id integer;
  _mo_id integer;
  _deviation integer;
begin
  SELECT mstd.id, mstd.clinic_id into _standart_id, _mo_id
  FROM mc_case mc
    JOIN mc_step ms ON mc.closing_step_id = ms.id
    JOIN md_standard mstd ON ms.standard_id = mstd.id
  WHERE mc.ID = xcase_id;
  if (_standart_id is not null)
  THEN
    if (_mo_id is not null)
    THEN
      WITH
          st_service as (
            SELECT -- назначения стандарта (услуги)
              mp.id, ms.clinic_id,ms.name, ss.id as standart_srv_id, ss.name as standart_srv_name,ss.org_id as standart_srv_mo,
                                           ssp.id as standart_prototype_id, ssp.name as standart_prototype_name
            FROM md_standard ms
              JOIN md_standard_prescription msp ON msp.standard_id = ms.id
              JOIN md_prescription mp ON msp.id = mp.id
              LEFT JOIN sr_service ss ON mp.service_type_id = ss.id and mp.is_mandatory is TRUE and ss.org_id = _mo_id
              LEFT JOIN  sr_srv_prototype ssp ON mp.prototype_id = ssp.id AND mp.service_type_id is null
            where ms.id = _standart_id and (ss.id is NOT NULL or ssp.id is NOT NULL)),
          st_service_prototype as (
            SELECT -- назначения стандарта (услуги другого МО)
              mp.id, ms.clinic_id,ms.name, ssp.id as standart_srv_pro_id, ssp.name as standart_srv_pro_name, ss.org_id as standart_srv_pro_mo
            FROM md_standard ms
              JOIN md_standard_prescription msp ON msp.standard_id = ms.id
              JOIN md_prescription mp ON msp.id = mp.id
              JOIN sr_service ss ON mp.service_type_id = ss.id
              left join sr_srv_prototype ssp ON ss.prototype_id = ssp.id
            where ms.id = _standart_id and mp.is_mandatory is TRUE and ss.org_id != _mo_id),
          rendered_srv as (
            SELECT --оказанные услуги
              mc.id as mcase, ss.id as rendered_srv_id, ss.name as rendered_srv_name,ss.org_id as rendered_srv_mo, ss.prototype_id as rendered_srv_prototype_id
            FROM mc_case mc
              JOIN md_srv_rendered msr ON mc.id = msr.case_id
              JOIN sr_srv_rendered ssr ON msr.id = ssr.id AND ssr.is_rendered is true
              JOIN sr_service ss ON ssr.service_id = ss.id
            WHERE mc.id = xcase_id),
          find_apointment as ( -- ищем в предварительной записи, запись для услуги с другой мо
            select
              cte.standart_srv_pro_id
            from md_appointment ma
              JOIN sr_service ss ON ma.service_id = ss.id
              JOIN st_service_prototype cte ON cte.standart_srv_pro_id = ss.prototype_id
              LEFT JOIN mc_case mc ON mc.id = xcase_id
              LEFT JOIN mc_step ms ON mc.closing_step_id = ms.id
            where ma.organization_id = cte.standart_srv_pro_mo and ma.customer_id = xpatient_id),
          temp_t as (
            SELECT
              ss.id as idp, sst.id as idsp
            FROM rendered_srv rs
              FULL JOIN st_service ss ON rs.rendered_srv_id = ss.standart_srv_id or rs.rendered_srv_prototype_id = ss.standart_prototype_id
              FULL JOIN st_service_prototype sst ON sst.standart_srv_pro_id = rs.rendered_srv_prototype_id
            WHERE rs.mcase = xcase_id and (ss.id is not null OR sst.id is not null)
        )

      select (case when b.count !=0 then ((a.count::numeric / b.count::numeric)*100)::integer else 100 end) into _deviation  from
        (select count(c.id) as count from (
                                            select distinct(idp) as id from temp_t where idp is not null
                                            union
                                            (select distinct idsp from temp_t where idsp is not null
                                             union
                                             SELECT distinct standart_srv_pro_id
                                             FROM find_apointment))c
        ) a,
        (SELECT count(mp.id) as count
         FROM md_standard ms
           JOIN md_standard_prescription msp ON msp.standard_id = ms.id
           JOIN md_prescription mp ON msp.id = mp.id
         where ms.id = _standart_id
        ) b;
    else
      WITH
          st_service as (
            SELECT
              mp.id, ms.clinic_id,ms.name, ssp.id as standart_prototype_id, ssp.name as standart_prototype_name
            FROM md_standard ms
              JOIN md_standard_prescription msp ON msp.standard_id = ms.id
              JOIN md_prescription mp ON msp.id = mp.id
              LEFT JOIN  sr_srv_prototype ssp ON mp.prototype_id = ssp.id AND mp.service_type_id is null
            where ms.id = _standart_id and (ssp.id is NOT NULL)),
          st_service_prototype as (
            SELECT
              mp.id, ms.clinic_id,ms.name, ssp.id as standart_srv_pro_id, ssp.name as standart_srv_pro_name, ss.org_id as standart_srv_pro_mo
            FROM md_standard ms
              JOIN md_standard_prescription msp ON msp.standard_id = ms.id
              JOIN md_prescription mp ON msp.id = mp.id
              JOIN sr_service ss ON mp.service_type_id = ss.id
              left join sr_srv_prototype ssp ON ss.prototype_id = ssp.id
            where ms.id = _standart_id and mp.is_mandatory is TRUE),
          rendered_srv as (
            SELECT --оказанные услуги
              mc.id as mcase, ss.id as rendered_srv_id, ss.name as rendered_srv_name,ss.org_id as rendered_srv_mo, ss.prototype_id as rendered_srv_prototype_id
            FROM mc_case mc
              JOIN md_srv_rendered msr ON mc.id = msr.case_id
              JOIN sr_srv_rendered ssr ON msr.id = ssr.id AND ssr.is_rendered is true
              JOIN sr_service ss ON ssr.service_id = ss.id
            WHERE mc.id = xcase_id),
          find_apointment as ( -- ищем в предварительной записи, запись для услуги с другой мо
            select
              cte.standart_srv_pro_id
            from md_appointment ma
              JOIN sr_service ss ON ma.service_id = ss.id
              JOIN st_service_prototype cte ON cte.standart_srv_pro_id = ss.prototype_id
              LEFT JOIN mc_case mc ON mc.id = xcase_id
              LEFT JOIN mc_step ms ON mc.closing_step_id = ms.id
            where ma.organization_id = cte.standart_srv_pro_mo and ma.customer_id = xpatient_id),
          temp_t as (
            SELECT
              ss.id as idp, sst.id as idsp
            FROM rendered_srv rs
              FULL JOIN st_service ss ON rs.rendered_srv_prototype_id = ss.standart_prototype_id
              FULL JOIN st_service_prototype sst ON sst.standart_srv_pro_id = rs.rendered_srv_prototype_id
            WHERE rs.mcase = xcase_id and (ss.id is not null OR sst.id is not null)
        )

      select (case when b.count !=0 then ((a.count::numeric / b.count::numeric)*100)::integer else 100 end) into _deviation  from
        (select count(c.id) as count from (
                                            select distinct(idp) as id from temp_t where idp is not null
                                            union
                                            (select distinct idsp from temp_t where idsp is not null
                                             union
                                             SELECT distinct standart_srv_pro_id
                                             FROM find_apointment))c
        ) a,
        (SELECT count(mp.id) as count
         FROM md_standard ms
           JOIN md_standard_prescription msp ON msp.standard_id = ms.id
           JOIN md_prescription mp ON msp.id = mp.id
         where ms.id = _standart_id

        ) b;
    END IF;
  else
    _deviation = 100;
  END IF;

  return (select case when (100-_deviation)!=0 then (100-_deviation) else null end);
end;
$$;

