CREATE FUNCTION gibdd_refresh_case_main_diagnisis(xcaseid integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
BEGIN
    UPDATE MC_CASE SET main_diagnos_id = (
        SELECT main_diagnosis_id
        FROM mc_step ms
        WHERE case_id = xcaseid
        AND main_diagnosis_id IS NOT NULL
        ORDER BY (ms.admission_date + (CASE WHEN (admission_time IS NOT NULL) THEN admission_time ELSE '00:00:00'::time END )) DESC, ms.ID DESC LIMIT 1
    ) WHERE id=xcaseid;
END;
$$;

