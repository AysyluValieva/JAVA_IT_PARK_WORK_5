CREATE FUNCTION get_form_full_name(p_form_id integer)
  RETURNS text
LANGUAGE plpgsql
AS $$
declare
v_res text := '';
r record;
begin
for r in select short_name, rem from inv_form_type ft, inv_form f where ft.id = f.form_type_id and f.id = p_form_id loop
  v_res := v_res ||' '||r.short_name||(case when r.rem is null or length(r.rem) = 0 then '' else r.rem end);
end loop;
v_res := v_res || ' ' || get_form_param_full_name(p_form_id);
return v_res;
end;
$$;

