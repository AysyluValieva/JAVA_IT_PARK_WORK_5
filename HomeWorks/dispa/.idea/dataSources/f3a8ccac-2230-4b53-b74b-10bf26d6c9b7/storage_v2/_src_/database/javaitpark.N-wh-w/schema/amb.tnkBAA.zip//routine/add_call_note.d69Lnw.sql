CREATE FUNCTION add_call_note(xcall integer, xnote integer, xtype boolean, xreason integer, xdescr character varying, xreg integer, xserv integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
	i integer;
    calnotid integer;
  begin
  	if not xtype
      then
      	if (xserv is not null) and (xnote = 11)
        	then
            	select into calnotid cn.id from amb.md_ambulance_call_note cn left join amb.md_ambulance_call_in_cityservice cic on cic.call_note_id = cn.id
                	where cn.call_id = xcall and cn.note_id = xnote and cn.note_type is true and cn.note_active is true and cic.service_id = xserv;
            else
        		select into calnotid id from amb.md_ambulance_call_note where call_id = xcall and note_id = xnote and note_type is true and note_active is true;
        end if;
        update amb.md_ambulance_call_note set note_active = xtype where id = calnotid;
    end if;
    i = nextval('amb.md_ambulance_call_notes_id_seq');
    insert into amb.md_ambulance_call_note (id,call_id,note_dt,note_id,registrator_id,note_reason_id,note_description,note_active,note_type)
		VALUES(i,xcall,now(),xnote,xreg,xreason,xdescr,true,xtype);
    if xnote in (1,2,3)
    	then update amb.md_ambulance_call set control = 2 where id = xcall;
    end if;
    if xnote in (10,20) and xtype is false
    	then
        	update amb.md_ambulance_call set to_time = null where id = xcall;
    end if;
    return i;
  end;
$$;

