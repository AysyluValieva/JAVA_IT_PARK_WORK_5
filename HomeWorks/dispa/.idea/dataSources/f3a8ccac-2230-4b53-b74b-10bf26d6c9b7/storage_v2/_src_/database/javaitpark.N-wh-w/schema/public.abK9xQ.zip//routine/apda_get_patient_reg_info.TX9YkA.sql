CREATE FUNCTION apda_get_patient_reg_info(patient_reg_id integer, active_address_code character varying)
  RETURNS apda_reg_info
LANGUAGE plpgsql
AS $$
BEGIN
  RETURN
  (
    SELECT (r.id,
            r.clinic_id,
            r.department_id,
            r.district_id,
            r.reg_dt,
            r.unreg_dt,
            r.type_id,
            (i.id, date_part('years', age(r.reg_dt, i.birth_dt)), i.death_dt, i.gender_id,
             apda_get_patient_address_info(
                 coalesce(pa.addr_id,
                          apda_get_patient_address_element_id_active_on_date(i.id, r.reg_dt, $2))
             ) :: apda_patient_address_info,
             apda_get_patient_org_ids_active_on_date(i.id, r.reg_dt),
             apda_get_patient_benefit_ids_active_on_date(i.id, r.reg_dt),
             apda_get_patient_diagnos_codes_active_on_date(i.id, r.reg_dt)
            ) :: apda_patient_info
    ) :: apda_reg_info
    FROM (SELECT
            id,
            clinic_id,
            department_id,
            district_id,
            coalesce(reg_dt, current_date) AS reg_dt,
            unreg_dt,
            type_id,
            patient_id,
            address_id
          FROM pci_patient_reg
          WHERE id = $1) r
      JOIN pim_individual i ON i.id = r.patient_id
      LEFT JOIN pim_party_address pa ON pa.id = r.address_id
  );
END;
$$;

