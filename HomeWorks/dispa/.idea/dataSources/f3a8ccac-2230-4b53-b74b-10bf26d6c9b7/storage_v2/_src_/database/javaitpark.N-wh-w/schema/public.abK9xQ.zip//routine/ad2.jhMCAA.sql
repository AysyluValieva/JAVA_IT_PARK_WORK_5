CREATE FUNCTION ad2()
  RETURNS text
LANGUAGE plpgsql
AS $$
declare
r_tab record;
v_cnt int := 0;
v_res text;
begin
for r_tab in select relname from pg_class where relnamespace = (select oid from pg_namespace where nspname = current_schema()) and relkind = 'r' loop
begin
select ad2(r_tab.relname) into v_res;
-- if v_res = '-1' then return v_cnt; end if;
v_cnt := v_cnt + 1;
-- exception when others then raise notice 'tab=%; %:%', r_tab.relname, sqlstate, sqlerrm; 
end;
end loop;
return v_cnt;
exception when others then 
	raise notice '%:%', sqlstate, sqlerrm;
	raise notice 'q=%', v_q;
	return -1;
end;
$$;

