CREATE FUNCTION savegibddinspec_valid(xepid integer, xcaseid integer, xservice integer, xemplpos_id integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
          serviceid integer;
          srrid integer;
          stepid integer;
          sysresid integer;
          gibddserviceid integer;
          mesp_id integer;
          orgId integer;
          xresource integer;
          cat record;

        begin
          serviceid = xservice;

          select e.org_id into orgId from disp.md_event e join disp.md_event_patient ep on e.id = ep.event_id where ep.id = xepid;

          select mes.resource_id into xresource from disp.md_event_service mes join disp.md_event_service_patient mesp on mes.id = mesp.service_id where mesp.event_patient_id = xepid and mes.service_id = xservice;

          if (xresource is null) then
            select rg.id into xresource from sr_res_group rg join sr_res_group_relationship rgr on rgr.group_id = rg.id
                join pim_employee_position_resource epr on epr.id = rgr.resource_id
                join pim_employee_position ep on ep.id = epr.employee_position_id
                join sr_res_group_service srgs on rg.id = srgs.group_id
                where ep.id = xemplPos_id and rg.org_id = orgId
                and srgs.srv_type_id = xservice and rg.is_system = false limit 1;
          end if;

          if (xresource is null) then
            select case (select count(1)
                from SR_RES_GROUP_SERVICE srgs
                join SR_RES_GROUP srg on srg.id = srgs.group_id
                where srg.is_system = false
                and srg.org_id = orgId
                and srgs.srv_type_id = xservice)
              when 1 then
                (select srg.id
                from SR_RES_GROUP_SERVICE srgs
                join SR_RES_GROUP srg on srg.id = srgs.group_id
                where srg.is_system = false
                and srg.org_id = orgId
                and srgs.srv_type_id = xservice)
              else null end into xresource;
          end if;

          srrid = nextval('sr_srv_rendered_seq');
          stepid =  nextval('mc_step_seq');
          sysresid = nextval('sr_res_group_seq');
          -- insert newsysres, step, visit, diag
          insert into SR_RES_GROUP (id, bdate, edate, is_system, name, department_id, org_id, responsible_id, is_available_in_electronic_queue, label_id)
            select sysresid as id, bdate, edate, TRUE as is_system, name, department_id, org_id, responsible_id, is_available_in_electronic_queue, label_id
            from SR_RES_GROUP
            where id = xresource;
          insert into mc_step (id, admission_date, outcome_date, case_id, regimen_id, res_group_id, outcome_id, profile_id)
            values (stepid, current_date, current_date, xcaseId, (select id from mc_care_regimen where code = 1), sysresid, (select id from mc_step_care_result where code = '306' and to_dt is null),
                    (select mp.id from SR_RES_GROUP srg
                     left join SR_RES_GROUP_RELATIONSHIP srgr on srgr.group_id = srg.id
                     inner join pim_employee_position_resource pepr on pepr.id = srgr.resource_id
                     left join PIM_EMPLOYEE_POSITION pep on pep.id = pepr.employee_position_id
                     left join PIM_POSITION pp on pp.id = pep.POSITION_ID
                     left join PIM_SPECIALITY ps on ps.id = pp.speciality_id
                     left join disp.md_profile_specialty mps on mps.spec_code = ps.code
                     left join md_profile mp on mp.code = mps.profile_code
                     where srg.id = xresource limit 1));
          insert into plc_visit (id, goal_id, place_id) values (stepid, (select mett.case_init_goal_id from disp.md_event_patient mep left join disp.md_event me on me.id = mep.event_id left join disp.md_event_type_target mett on mett.event_type_id = me.event_type where mep.id = xepid and mett.stage = 1 and (mett.begin_date is null or mett.begin_date <= current_date) and (mett.end_date is null or mett.end_date >= current_date)), (select id from plc_visit_place where code = '1'));

          insert into SR_SRV_RENDERED (id, service_id, bdate, res_group_id, customer_id, is_rendered, edate, quantity, funding_id, org_id, payment_status_id)
            values (srrid, serviceid, current_date, xresource, (select indiv_id from disp.md_event_patient where id = xepid), TRUE, current_date, 1,
            (select me.pay_type from disp.md_event me left join disp.md_event_patient mep on mep.event_id=me.id  where mep.id=xepid),
            (select me.org_id from disp.md_event_patient mep left join disp.md_event me on me.id = mep.event_id where mep.id = xepid), 1);
          insert into MD_SRV_RENDERED (id, case_id, step_id) values (srrid, xcaseId, stepid);
          gibddserviceid = nextval('gibdd.md_gibdd_service_seq');
          insert into gibdd.md_gibdd_service (id, event_patient_id, service_id, res_group_id, rendered_date, step_id)
            values (gibddserviceid, xepid, srrid, sysresid, current_date, stepid);


          -- change STATUS
          select mesp.id into mesp_id from disp.md_event_patient mep
                left join disp.md_event_service_patient mesp on mesp.event_patient_id = mep.id
                inner join disp.md_event_service mes on mes.id = mesp.service_id and mes.service_id = serviceid
                where mep.id = xepid;
          update disp.md_event_service_patient set status = 4
              where id = mesp_id;


          for cat in select category_id from gibdd.md_gibdd_reference_category where reference_id = xepid
          loop
            insert into gibdd.md_gibdd_service_category (gibdd_service_id, category_id, is_valid) values (gibddserviceid, cat.category_id, true);
          end loop;


	  UPDATE gibdd.md_gibdd_reference
          SET is_contraindications=false where id = xepid and not exists(select 1 from gibdd.md_gibdd_service gs
                left join mc_diagnosis mcd on gs.diagnos_id = mcd.id
                left join md_diagnosis md on mcd.diagnos_id = md.id
                where gs.event_patient_id = xepid
                and (md.code like 'F00%' or md.code like 'F01%' or md.code like 'F02%'
                or md.code like 'F03%' or md.code like 'F04%' or md.code like 'F05%'
                or md.code like 'F06%' or md.code like 'F07%' or md.code like 'F08%'
                or md.code like 'F09%' or md.code like 'F10%' or md.code like 'F11%'
                or md.code like 'F12%' or md.code like 'F13%' or md.code like 'F14%'
                or md.code like 'F15%' or md.code like 'F16%'
                or md.code like 'F18%' or md.code like 'F19%' or md.code like 'F20%'
                or md.code like 'F21%' or md.code like 'F22%' or md.code like 'F23%'
                or md.code like 'F24%' or md.code like 'F25%' or md.code like 'F26%'
                or md.code like 'F27%' or md.code like 'F28%' or md.code like 'F29%'
                or md.code like 'F30%' or md.code like 'F31%' or md.code like 'F32%'
                or md.code like 'F33%' or md.code like 'F34%' or md.code like 'F35%'
                or md.code like 'F36%' or md.code like 'F37%' or md.code like 'F38%'
                or md.code like 'F39%'
                or md.code like 'F70%' or md.code like 'F71%' or md.code like 'F72%'
                or md.code like 'F73%' or md.code like 'F74%' or md.code like 'F75%'
                or md.code like 'F76%' or md.code like 'F77%' or md.code like 'F78%'
                or md.code like 'F79%'
                or md.code='G40'
                or md.code='H54.0'
                or md.code like 'F40%' or md.code like 'F41%' or md.code like 'F42%'
                or md.code like 'F43%' or md.code like 'F44%' or md.code like 'F45%'
                or md.code like 'F46%' or md.code like 'F47%' or md.code like 'F48%'
                or md.code like 'F60%' or md.code like 'F61%' or md.code like 'F62%'
                or md.code like 'F63%' or md.code like 'F64%' or md.code like 'F65%'
                or md.code like 'F66%' or md.code like 'F67%' or md.code like 'F68%'
                or md.code like 'F69%'
                or md.code='H53.1'));

          UPDATE gibdd.md_gibdd_reference
          SET is_contraindications=true where id = xepid and exists(select 1 from gibdd.md_gibdd_service gs
                left join mc_diagnosis mcd on gs.diagnos_id = mcd.id
                left join md_diagnosis md on mcd.diagnos_id = md.id
                where gs.event_patient_id = xepid
                and (md.code like 'F00%' or md.code like 'F01%' or md.code like 'F02%'
                or md.code like 'F03%' or md.code like 'F04%' or md.code like 'F05%'
                or md.code like 'F06%' or md.code like 'F07%' or md.code like 'F08%'
                or md.code like 'F09%' or md.code like 'F10%' or md.code like 'F11%'
                or md.code like 'F12%' or md.code like 'F13%' or md.code like 'F14%'
                or md.code like 'F15%' or md.code like 'F16%'
                or md.code like 'F18%' or md.code like 'F19%' or md.code like 'F20%'
                or md.code like 'F21%' or md.code like 'F22%' or md.code like 'F23%'
                or md.code like 'F24%' or md.code like 'F25%' or md.code like 'F26%'
                or md.code like 'F27%' or md.code like 'F28%' or md.code like 'F29%'
                or md.code like 'F30%' or md.code like 'F31%' or md.code like 'F32%'
                or md.code like 'F33%' or md.code like 'F34%' or md.code like 'F35%'
                or md.code like 'F36%' or md.code like 'F37%' or md.code like 'F38%'
                or md.code like 'F39%'
                or md.code like 'F70%' or md.code like 'F71%' or md.code like 'F72%'
                or md.code like 'F73%' or md.code like 'F74%' or md.code like 'F75%'
                or md.code like 'F76%' or md.code like 'F77%' or md.code like 'F78%'
                or md.code like 'F79%'
                or md.code='G40'
                or md.code='H54.0'
                or md.code like 'F40%' or md.code like 'F41%' or md.code like 'F42%'
                or md.code like 'F43%' or md.code like 'F44%' or md.code like 'F45%'
                or md.code like 'F46%' or md.code like 'F47%' or md.code like 'F48%'
                or md.code like 'F60%' or md.code like 'F61%' or md.code like 'F62%'
                or md.code like 'F63%' or md.code like 'F64%' or md.code like 'F65%'
                or md.code like 'F66%' or md.code like 'F67%' or md.code like 'F68%'
                or md.code like 'F69%'
                or md.code='H53.1'));

          if (select med_commission_res_group_id is not null from gibdd.md_gibdd_reference where id = xepid) then
            update gibdd.md_gibdd_reference_category rc set is_valid = (select not exists(select 1 from gibdd.md_gibdd_service_category sc join gibdd.md_gibdd_service s on sc.gibdd_service_id = s.id
	      where s.event_patient_id = xepid and sc.category_id = rc.category_id and sc.is_valid = false))
	      where rc.reference_id = xepid;
	  end if;
	  return mesp_id;
        end;
$$;

