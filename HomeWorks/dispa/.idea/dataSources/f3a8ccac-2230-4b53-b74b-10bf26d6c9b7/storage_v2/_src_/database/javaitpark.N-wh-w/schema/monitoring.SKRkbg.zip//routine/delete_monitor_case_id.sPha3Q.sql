CREATE FUNCTION delete_monitor_case_id(integer, integer)
  RETURNS void
LANGUAGE SQL
AS $$
delete from monitoring.monitored_cases_list mc_list
      where
      mc_list.case_id=(select case_id from monitoring.monitored_cases_list where case_id=$1 and user_id=$2)
      and
      mc_list.case_id=(select case_id from monitoring.monitored_cases_list where case_id=$1 and user_id=$2);
$$;

