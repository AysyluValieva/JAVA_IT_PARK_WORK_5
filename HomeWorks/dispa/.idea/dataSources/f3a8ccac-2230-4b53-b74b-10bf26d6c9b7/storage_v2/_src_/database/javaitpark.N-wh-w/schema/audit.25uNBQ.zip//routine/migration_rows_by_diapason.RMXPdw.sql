CREATE FUNCTION migration_rows_by_diapason(_table_name character varying, _from_row_id bigint, _to_row_id bigint)
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
  _attributes_query          VARCHAR;
  _query                     VARCHAR;
  _is_has_default_pk         BOOLEAN;
  _primary_key_rows          VARCHAR;
  _revtype_field             VARCHAR;
  _check_id_rows_not_change  VARCHAR;
  _revtype_search_sub_query  VARCHAR = '';
  _revtype_parent_table_name VARCHAR;
BEGIN
  SELECT base_table_has_default_primary_key
  INTO _is_has_default_pk
  FROM audit.migration_table
  WHERE table_name = _table_name;

  --получаем колонки первичного ключа
  IF _is_has_default_pk THEN
    _primary_key_rows = 'id';
  ELSE
    SELECT string_agg(c.column_name, ', ')
    INTO _primary_key_rows
    FROM information_schema.key_column_usage AS c
      LEFT JOIN information_schema.table_constraints AS t
        ON t.constraint_name = c.constraint_name
    WHERE t.table_name = replace(replace(_table_name, 'public.', ''), '_aud', '') AND t.constraint_type = 'PRIMARY KEY';
  END IF;

  --создаем временную таблицу куда запишем переносимые данные
  SELECT string_agg(concat(a.attname, ' ', format_type(a.atttypid, a.atttypmod)), ', ')
  INTO _attributes_query
  FROM
    pg_catalog.pg_attribute a
  WHERE
    a.attnum > 0
    AND NOT a.attisdropped
    AND a.attrelid = (
      SELECT c.oid
      FROM pg_catalog.pg_class c
        LEFT JOIN pg_catalog.pg_namespace n ON n.oid = c.relnamespace
      WHERE c.relname = replace(_table_name, 'public.', '')
            AND pg_catalog.pg_table_is_visible(c.oid)
    );

  _query = concat('CREATE TEMP TABLE migration_temp(row_number INT, ', _attributes_query, ')');

  DROP TABLE IF EXISTS migration_temp;

  EXECUTE _query;

  --заполняем временную таблицу
  SELECT string_agg(concat(a.attname), ', ')
  INTO _attributes_query
  FROM
    pg_catalog.pg_attribute a
  WHERE
    a.attnum > 0
    AND NOT a.attisdropped
    AND a.attrelid = (
      SELECT c.oid
      FROM pg_catalog.pg_class c
        LEFT JOIN pg_catalog.pg_namespace n ON n.oid = c.relnamespace
      WHERE c.relname = replace(_table_name, 'public.', '')
            AND pg_catalog.pg_table_is_visible(c.oid)
    );

  _query = concat('INSERT INTO migration_temp(row_number, ', _attributes_query, ') ',
                  'SELECT ROW_NUMBER() OVER (ORDER BY ', _primary_key_rows, ', rev), ', _attributes_query, ' ',
                  'FROM ', _table_name, ' ');

  IF _is_has_default_pk THEN _query = concat(_query, 'WHERE id BETWEEN ', _from_row_id, ' AND ', _to_row_id); END IF;

  EXECUTE _query;

  --добавление индекса
  IF _is_has_default_pk THEN
    EXECUTE ('CREATE INDEX migration_temp_idx ON migration_temp USING btree (id)');
  END IF;

  --подзапрос на получение типа измениея записи
  IF _attributes_query LIKE '%revtype%'
  THEN
    _revtype_field = 't2.revtype';
  ELSE
    IF (SELECT value
        FROM audit.migration_setting
        WHERE code = 'USE_REV_TYPE_SEARCH') = 1
    THEN
      _revtype_parent_table_name =
      (SELECT rev_type_parent_table_name
       FROM audit.migration_batch_process
       WHERE table_id = (SELECT id
                         FROM audit.migration_table
                         WHERE table_name = _table_name));

      IF _revtype_parent_table_name NOTNULL AND (SELECT count_row < (SELECT value
                                                                     FROM audit.migration_setting
                                                                     WHERE code = 'REV_TYPE_PARENT_TABLE_MAX_SIZE')
                                                 FROM audit.migration_table
                                                 WHERE table_name = _revtype_parent_table_name) = TRUE
      THEN
        _revtype_field = 'rt_parent.revtype';
        _revtype_search_sub_query = concat('JOIN ', _revtype_parent_table_name, ' rt_parent ON rt_parent.rev = t.rev');
      ELSE
        _revtype_field = 'NULL';
      END IF;
    ELSE
      _revtype_field = 'NULL';
    END IF;
  END IF;

  _check_id_rows_not_change = (SELECT string_agg(concat('t1.', t.c, ' = t2.', t.c), ' AND ')
                               FROM (SELECT unnest(string_to_array(_primary_key_rows, ', ')) AS c) t);

  _query = concat(
      'INSERT INTO audit.', replace(replace(_table_name, '_aud', ''), '.', '$'),
      ' (', _primary_key_rows, ', type, delta, aud_when, aud_who, aud_source) ',
      'SELECT ',
      '   t.', replace(_primary_key_rows, ', ', ', t.'), ', ',
      '   CASE WHEN t.revtype ISNULL ',
      '   THEN audit.migration_get_row_change_type(t.delta, ''', split_part(_primary_key_rows, ',', 1), ''') ',
      '   ELSE t.revtype END, ',
      '   t.delta, e.date, u.login, ''APP_LSD'' ',
      'FROM (SELECT t2.', replace(_primary_key_rows, ', ', ', t2.'), ', t2.rev, ',
      '         audit.migration_get_row_change_type(', _revtype_field, '::INT) AS revtype, ',
        '       CASE WHEN ', _check_id_rows_not_change,
        '       THEN hstore(t2.*) - hstore(t1.*) - ''{rev, revtype, row_number}''::TEXT[] ',
        '       ELSE hstore(t2.*) - ''{rev, revtype, row_number}''::TEXT[] END AS delta ',
      '     FROM (SELECT * ',
      '           FROM migration_temp ',
      '           UNION ',
      '           SELECT 0, ', (SELECT string_agg('NULL', ',') FROM generate_series(1, array_length(
                      string_to_array(_attributes_query, ','), 1), 1)), ') t1 ',
      '       LEFT JOIN migration_temp t2 ON t1.row_number = t2.row_number - 1 ',
      ') t ',
      _revtype_search_sub_query,
      '   JOIN sec_audit_entry e ON e.id = t.rev',
      '   JOIN sec_user u ON u.id = e.user_id ',
      'WHERE t.delta != hstore('''')');

  EXECUTE _query;
END;
$$;

