CREATE FUNCTION updateindividual(xid integer, xsurname character varying, xname character varying, xpatrname character varying, xbirthday character varying)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
            begin
                update pim_individual set surname = xsurname, name = xname, patr_name = xpatrName, birth_dt = to_date(xbirthday, 'DD.MM.YYYY') where id = xid;
                return xid;
            end;
$$;

