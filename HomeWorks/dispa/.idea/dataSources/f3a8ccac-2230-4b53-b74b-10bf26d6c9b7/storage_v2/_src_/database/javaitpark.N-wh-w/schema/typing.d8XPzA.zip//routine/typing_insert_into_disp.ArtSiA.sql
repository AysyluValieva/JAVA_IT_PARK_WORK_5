CREATE FUNCTION typing_insert_into_disp()
  RETURNS boolean
LANGUAGE plpgsql
AS $$
Declare x boolean;
begin 
x=true;
CASE when exists (select 1 from pg_catalog.pg_namespace where nspname='disp') 
then EXECUTE
'insert into disp.md_event_service_link(id, case_id, service_id)
select nextval(''disp.md_event_service_id_seq''),case_id, new_id FROM  "typing_services" where org_id <> clinic_id;';
when not exists (select 1 from pg_catalog.pg_namespace where nspname='disp') then
execute '
update "typing_services" t set errors = concat(errors, ''{"level":"service", "message":"отстуствует схема disp"  "column_name":"id"}'')
 where org_id <> clinic_id and org_id is not null and clinic_id is not null;';
	end CASE;
return x;
end;
$$;

