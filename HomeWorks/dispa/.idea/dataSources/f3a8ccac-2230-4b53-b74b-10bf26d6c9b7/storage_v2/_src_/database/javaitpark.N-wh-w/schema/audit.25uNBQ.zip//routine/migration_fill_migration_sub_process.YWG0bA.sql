CREATE FUNCTION migration_fill_migration_sub_process(_process_id integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
  _record RECORD;
  _is_divisible BOOLEAN = TRUE;
  _batch_size BIGINT;
  _table_name VARCHAR;
  _it RECORD;
BEGIN
  SELECT * INTO _record FROM audit.migration_batch_process WHERE id = _process_id;
  SELECT table_name INTO _table_name FROM audit.migration_table WHERE id = _record.table_id;

  IF (SELECT base_table_has_default_primary_key FROM audit.migration_table WHERE table_name = _table_name) = FALSE THEN
    INSERT INTO audit.migration_batch_sub_process (process_id, from_row_id, to_row_id, count_row)
    VALUES (_process_id, 0, 0, _record.count_aud_row);

    RETURN;
  END IF;

  SELECT value INTO _batch_size FROM audit.migration_setting WHERE code = 'PARTITION_MAX_SIZE';

  IF (SELECT exists(SELECT 1 FROM audit.migration_batch_sub_process WHERE process_id = _process_id)) = FALSE
  THEN
    INSERT INTO audit.migration_batch_sub_process (process_id, from_row_id, to_row_id, count_row)
    VALUES (_process_id, _record.min_row_id, _record.max_row_id, _record.count_aud_row);

    IF _record.count_aud_row < _batch_size THEN _is_divisible = FALSE; END IF;
  END IF;

  WHILE _is_divisible LOOP
    _is_divisible = FALSE;

    FOR _it IN
    SELECT *
    FROM audit.migration_batch_sub_process
    WHERE count_row > _batch_size AND is_executed = FALSE
    LOOP
      _is_divisible = TRUE;

      EXECUTE audit.migration_divide_sub_process_diapason(
          _it.id, _process_id, _table_name, _it.from_row_id, _it.to_row_id, _it.count_row);
    END LOOP;
  END LOOP;
END;
$$;

