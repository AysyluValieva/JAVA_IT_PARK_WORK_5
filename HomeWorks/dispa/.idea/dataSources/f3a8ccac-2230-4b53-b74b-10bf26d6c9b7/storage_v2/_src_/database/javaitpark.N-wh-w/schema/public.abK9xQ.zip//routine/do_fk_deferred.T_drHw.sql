CREATE FUNCTION do_fk_deferred(p_tab name)
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
            fk record;
            c_n constant text := 'do_fk_deferred';
            q text;
            begin
            perform log_a(c_n||':tab='||p_tab, 'INFO');
            for fk in
            select c.relname, cs.conname, pa.attname pk_attname, ca.attname fk_attname, cs.confupdtype, cs.confdeltype, cs.confmatchtype,
            -- check - if PK==FK
            (select count(1)
            from pg_constraint cs4, pg_constraint cs5
            where cs4.conrelid = c.oid
            and cs4.contype = 'p'
            and cs4.conkey[1] = cs.conkey[1]
            and cs5.confkey[1] = cs4.conkey[1]
            and cs5.contype = 'f'
            and cs5.confrelid = c.oid) as cnt
            from pg_class c, pg_constraint cs, pg_class p, pg_attribute pa, pg_attribute ca
            where pa.attrelid = p.oid
            and pa.attnum = cs.confkey[1]
            and ca.attrelid = c.oid
            and ca.attnum = cs.conkey[1]
            and cs.contype = 'f'
            and cs.conrelid = c.oid
            and cs.confrelid = p.oid
            and p.relname = lower(p_tab)
            and cs.condeferrable = false
            loop
            perform log_a(c_n||':'||fk.relname||'.'||fk.conname, 'INFO');
            q := 'alter table '||fk.relname||' drop constraint '||fk.conname; execute q;
            q := 'alter table '||fk.relname||' add constraint '||fk.conname||' foreign key ('||fk.fk_attname||') references '||p_tab||'('||fk.pk_attname||') '
            ||' match '||(case fk.confmatchtype when 'f' then 'full' when 'p' then 'partial' when 's' then 'simple' end)
            ||' on delete '||(case fk.confdeltype when 'a' then 'no action' when 'r' then 'restrict' when 'c' then 'cascade' when 'n' then 'set null' when 'd' then 'set default' end)
            ||' on update '||(case fk.confupdtype when 'a' then 'no action' when 'r' then 'restrict' when 'c' then 'cascade' when 'n' then 'set null' when 'd' then 'set default' end)
            ||' deferrable'; execute q;
            if fk.cnt > 0 then
            perform do_fk_deferred(fk.relname);
            end if;
            end loop;
            end;
$$;

