CREATE FUNCTION get_unit_name_by_flag_of_modif(flag integer, holdmodifid integer)
  RETURNS text
LANGUAGE plpgsql
AS $$
DECLARE
 unit_name  text;
BEGIN

SELECT mnemocode INTO unit_name from cmn_measure where id=(select inventory.get_unit_id_by_flag_of_modif(flag, holdModifId));

return coalesce(unit_name,'');
END;
$$;

