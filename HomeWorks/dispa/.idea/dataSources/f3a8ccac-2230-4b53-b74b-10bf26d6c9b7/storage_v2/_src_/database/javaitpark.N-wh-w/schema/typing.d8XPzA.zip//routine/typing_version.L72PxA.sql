CREATE FUNCTION typing_version()
  RETURNS text
LANGUAGE plpgsql
AS $$
begin
          return '2.0.2 от 24.02.2015';
end
$$;

