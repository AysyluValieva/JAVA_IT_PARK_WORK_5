CREATE VIEW dimension_date_month AS
  SELECT dimension_date.id,
    dimension_date.year_,
    dimension_date.quarter_of_year,
    dimension_date.month_of_year,
    dimension_date.half_of_year,
    dimension_date.aud_who,
    dimension_date.aud_when,
    dimension_date.aud_source,
    dimension_date.aud_who_create,
    dimension_date.aud_when_create,
    dimension_date.aud_source_create
   FROM indicators.dimension_date
  WHERE (dimension_date.dimension_date_def_id = 4);

COMMENT ON VIEW dimension_date_month IS 'Временной срез. Год, квартал, месяц';

COMMENT ON COLUMN dimension_date_month.id IS 'Идентификатор';

COMMENT ON COLUMN dimension_date_month.year_ IS 'Год';

COMMENT ON COLUMN dimension_date_month.quarter_of_year IS 'Квартал года';

COMMENT ON COLUMN dimension_date_month.month_of_year IS 'Месяц года';

COMMENT ON COLUMN dimension_date_month.half_of_year IS 'Полугодие года';

