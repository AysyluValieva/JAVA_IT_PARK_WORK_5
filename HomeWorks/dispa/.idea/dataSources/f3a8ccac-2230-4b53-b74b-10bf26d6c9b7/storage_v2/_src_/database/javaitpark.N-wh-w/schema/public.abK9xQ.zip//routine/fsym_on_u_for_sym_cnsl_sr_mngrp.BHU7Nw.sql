CREATE FUNCTION fsym_on_u_for_sym_cnsl_sr_mngrp()
  RETURNS trigger
LANGUAGE plpgsql
AS $fun$
declare var_row_data text; 
                                declare var_old_data text; 
                                begin
                                   
                                  if 1=1 and 1=1 then                                                                                                 
                                    var_row_data := 
          case when new."user_id" is null then '' else '"' || replace(replace(cast(new."user_id" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."first_name" is null then '' else '"' || replace(replace(cast(new."first_name" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."last_name" is null then '' else '"' || replace(replace(cast(new."last_name" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."email" is null then '' else '"' || replace(replace(cast(new."email" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."hashed_password" is null then '' else '"' || replace(replace(cast(new."hashed_password" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."auth_meth" is null then '' else '"' || replace(replace(cast(new."auth_meth" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."user_role" is null then '' else '"' || replace(replace(cast(new."user_role" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."create_time" is null then '' else '"' || to_char(new."create_time", 'YYYY-MM-DD HH24:MI:SS.US') || '"' end||','||
          case when new."last_update_by" is null then '' else '"' || replace(replace(cast(new."last_update_by" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."last_update_time" is null then '' else '"' || to_char(new."last_update_time", 'YYYY-MM-DD HH24:MI:SS.US') || '"' end; 
                                    var_old_data := null; 
                                    if 1=1 then 
                                    insert into "public".sym_data                                                                                                                     
                                    (table_name, event_type, trigger_hist_id, pk_data, row_data, old_data, channel_id, transaction_id, source_node_id, external_data, create_time)                     
                                    values(                                                                                                                                                            
                                      'sym_console_user',                                                                                                                                            
                                      'U',                                                                                                                                                             
                                      32,                                                                                                                                             
                                      
          case when old."user_id" is null then '' else '"' || replace(replace(cast(old."user_id" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end,                                                                                                                                                      
                                      var_row_data,                                                                                                                                                      
                                      var_old_data,                                                                                                                                                   
                                      'config',                                                                                                                                                
                                      txid_current(),                                                                                                                                               
                                      "public".sym_node_disabled(),                                                                                                                   
                                      null,                                                                                                                                               
                                      CURRENT_TIMESTAMP                                                                                                                
                                    );                                                                                                                                                                 
                                  end if;                                                                                                                                                              
                                  end if;                                                                                                                                                              
                                                                                                                                                                               
                                  return null;                                                                                                                                                         
                                end;
$fun$;

