CREATE FUNCTION gen_rnd(len integer, is_alpha boolean)
  RETURNS character varying
LANGUAGE plpgsql
AS $$
declare
   i int;
   rand int;
   re varchar(1000) := '';
begin
   for i in 0..len - 1 loop
      loop
         rand := round(random()*100) + 47;
         if rand between 48 and 57 or (is_alpha and rand between 65 and 90) then exit; end if;
      end loop;   
      re := re||chr(rand);
   end loop;
   return re;
end;
$$;

