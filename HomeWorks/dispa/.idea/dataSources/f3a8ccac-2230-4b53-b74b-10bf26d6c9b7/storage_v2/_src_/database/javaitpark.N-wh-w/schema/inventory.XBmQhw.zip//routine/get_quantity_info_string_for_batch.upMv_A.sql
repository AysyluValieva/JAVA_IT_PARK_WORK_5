CREATE FUNCTION get_quantity_info_string_for_batch(storesupid integer, holdmodifid integer, mneiquantity numeric, expinvoicedate date, unitflag integer, mneiid integer, mneicountinsecpk integer)
  RETURNS text
LANGUAGE plpgsql
AS $$
DECLARE
 resultString TEXT;
 mneiName TEXT;
 unitName TEXT;
 resMneiQuantity NUMERIC;
 resQuantity NUMERIC;

BEGIN
  select inventory.get_batch_mnei_quantity(storeSupId,mneiQuantity,expInvoiceDate) into resMneiQuantity;
  if resMneiQuantity=0 then
     return 0; end if;

  mneiName = (select cm.mnemocode from cmn_measure cm where cm.id=mneiId);
  unitName = (select inventory.get_unit_name_by_flag_of_modif(unitFlag, holdModifId));
  resQuantity=resMneiQuantity/mneiCountInSecPk;

  if resQuantity = resMneiQuantity
  then
       resultString = trim(to_char(resQuantity, 'FM999999990.999999'), '.')||' '||unitName;
  else
       resultString = trim(to_char(resQuantity, 'FM999999990.999999'), '.')||' '||unitName
                ||' ('||trim(to_char(resMneiQuantity, 'FM999999990.999999'), '.')||' '||mneiName||')';
  end if;
  return resultString;
END;
$$;

