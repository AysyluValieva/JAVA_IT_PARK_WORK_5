CREATE FUNCTION set_service(xcall integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
  	-- вызов
    xage_years integer;
  	xage_months integer;
  	xage_days integer;
    xbirth_dt date;
    xclinic integer;

    -- пациент
    xcustomer_id integer;

	-- для системного составного ресурса
    xgroup integer;
    xgroup_name varchar(255);
    xrole varchar(100);
    xprofile integer;

    -- для услуги
    xrendered integer;
    xservice integer;

  begin
  	-- в sr_res_group есть поле responsible_id = pim_employee_position.id - главный в ресурсе
  	select into xage_years	 	,xrendered				,xbirth_dt		,xgroup			 	,xgroup_name	,xrole		,xprofile			,xclinic
    			cal.age_years	,calres.srv_rendered_id	,pi.birth_dt	,ssr.res_group_id	,srg.name	 	,srr.e_code	,srgprof.profile_id	,cal.station_id
    from amb.md_ambulance_call cal
    join amb.sr_res_team_job srtj on srtj.id = cal.brg_id
    join amb.sr_res_team srt on srt.id = srtj.team_id
    join sr_res_group teamsrg on teamsrg.id = srt.resource_id
    join sr_res_group_profile srgprof on srgprof.res_group_id = teamsrg.id
    join amb.md_ambulance_call_result calres on calres.id = cal.id
    join pim_individual pi on pi.id = cal.patient_id
    join sr_srv_rendered ssr on ssr.id = calres.srv_rendered_id
    join sr_res_group srg on srg.id = ssr.res_group_id
    join pim_employee_position_resource pepr on pepr.employee_position_id = srg.responsible_id
    join sr_res_group_relationship srgr on srgr.group_id = srg.id and srgr.resource_id = pepr.id
    join sr_res_role srr on srr.id = srgr.role_id
    where cal.id = xcall;

	xservice =
    case when (xage_years >= 18) and not((upper(xgroup_name) like upper('ПСХ'||'%')) or (xprofile in (select id from md_profile where e_code = '72'))) and (xrole = 'DOCTOR')
    		then (select id from sr_service where org_id = xclinic and code = '080001') -- врачебная
     	 when (xage_years >= 18) and not((upper(xgroup_name) like upper('ПСХ'||'%')) or (xprofile in (select id from md_profile where e_code = '72'))) and (xrole = 'PARAMEDIC')
    		then (select id from sr_service where org_id = xclinic and code = '080002')	-- фельдшерская
     	 when (xage_years >= 18) and ((upper(xgroup_name) like upper('ПСХ'||'%')) or (xprofile in (select id from md_profile where e_code = '72'))) and (xrole = 'DOCTOR')
    		then (select id from sr_service where org_id = xclinic and code = '080002')	-- врачебная псих
     	 when (xage_years >= 18) and ((upper(xgroup_name) like upper('ПСХ'||'%')) or (xprofile in (select id from md_profile where e_code = '72'))) and (xrole = 'PARAMEDIC')
    		then (select id from sr_service where org_id = xclinic and code = '080002')	-- фельдшерская псих

     	 when (xage_years < 18) and not((upper(xgroup_name) like upper('ПСХ'||'%')) or (xprofile in (select id from md_profile where e_code = '72'))) and (xrole = 'DOCTOR')
    		then (select id from sr_service where org_id = xclinic and code = '080001') -- дет врачебная
     	 when (xage_years < 18) and not((upper(xgroup_name) like upper('ПСХ'||'%')) or (xprofile in (select id from md_profile where e_code = '72'))) and (xrole = 'PARAMEDIC')
    		then (select id from sr_service where org_id = xclinic and code = '080002')	-- дет фельдшерская
     	 when (xage_years < 18) and ((upper(xgroup_name) like upper('ПСХ'||'%')) or (xprofile in (select id from md_profile where e_code = '72'))) and (xrole = 'DOCTOR')
    		then (select id from sr_service where org_id = xclinic and code = '080002')	-- дет врачебная псих
     	 when (xage_years < 18) and ((upper(xgroup_name) like upper('ПСХ'||'%')) or (xprofile in (select id from md_profile where e_code = '72'))) and (xrole = 'PARAMEDIC')
    		then (select id from sr_service where org_id = xclinic and code = '080002')	-- дет фельдшерская псих
    --else
    	--(select id from sr_service where org_id = xclinic and code = 'SNMP')
    end;

    if xservice is NULL
    	then
    		xservice = (select id from sr_service where org_id = xclinic and code = 'SNMP');
    end if;

    update public.sr_srv_rendered set service_id = xservice where id = xrendered;

	return xservice;
  end;
$$;

