CREATE FUNCTION servicen2oformaddform(xcode character varying, xform character varying)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
        begin
             insert into disp.service_n2o_form (id,service_code, n2o_form) values (nextval('disp.service_n2o_form_id_seq'),xcode,xform );
        return 1;
        end;
$$;

