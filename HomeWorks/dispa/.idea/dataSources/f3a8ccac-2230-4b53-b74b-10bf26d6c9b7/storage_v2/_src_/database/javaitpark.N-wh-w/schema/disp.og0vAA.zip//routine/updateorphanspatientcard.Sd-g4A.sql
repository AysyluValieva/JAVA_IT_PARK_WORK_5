CREATE FUNCTION updateorphanspatientcard(xid integer, xcac integer, xloc integer, xreason integer, xmiss character varying, xbdate character varying, xedate character varying)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
    i integer;
  begin
    IF (select count(id) from disp.md_disp_orphans_patient_card where id = xid) = 0 THEN
      i = xid;
      insert into disp.md_disp_orphans_patient_card (id, сategory_accounting_child_id, location_id, reason_id, miss_reason, bdate, edate)
        values (i, xcac, xloc, xreason, xmiss, to_date(xbdate, 'DD.MM.YYYY'), to_date(xedate, 'DD.MM.YYYY'));
    ELSE
      update disp.md_disp_orphans_patient_card set сategory_accounting_child_id = xcac, location_id = xloc,
        reason_id = xreason, miss_reason = xmiss, bdate = to_date(xbdate, 'DD.MM.YYYY'), edate = to_date(xedate, 'DD.MM.YYYY')
        where id = xid;
    END IF;
    return i;
    end;
$$;

