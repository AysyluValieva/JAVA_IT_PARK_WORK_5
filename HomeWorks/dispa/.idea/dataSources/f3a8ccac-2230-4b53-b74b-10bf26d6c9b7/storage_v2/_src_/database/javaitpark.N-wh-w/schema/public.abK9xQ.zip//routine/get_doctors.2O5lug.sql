CREATE FUNCTION get_doctors(mc_case_id integer)
  RETURNS character varying
LANGUAGE plpgsql
AS $$
declare
    fullName character varying := '';
    employeePosition record;
    individual record;
begin
    for employeePosition in
          (		
              select 
                  ep.employee_id
              from
                  sr_res_group_relationship rgr,
                  sr_resource resource,
                  sr_res_kind rk,
                  sr_res_role rr
                  cross join pim_employee_position_resource ep2
                  inner join sr_resource res on ep2.id=res.id,
                  pim_employee_position ep
              where
                  rgr.resource_id=resource.id
                  and resource.res_kind_id=rk.id
                  and rgr.role_id=rr.id
                  and ep2.employee_position_id=ep.id
                  and (rgr.group_id in
                      (
                         select
                          ms.res_group_id
                         from
                          hsp_record hr
                          inner join mc_step ms on hr.id=ms.id
                         where
                          hr.previous_id is null
                          and ms.case_id = mc_case_id
                      ))

                          and ep2.id=rgr.resource_id
                          and rk.code='1'
                          and rr.kind_id=1
              )
    loop           
       
       for individual in 
       (
          select 
               ind.surname,
               ind.name, 
               ind.patr_name
          from 
               pim_employee emp, 
               pim_individual ind 
          where 
               emp.individual_id=ind.id 
               and emp.id = employeePosition.employee_id
       )
	   loop
	   
	      if fullName <> '' then
		    fullName := fullName || ', ';
	      end if;
	      
	      fullName := fullName || individual.surname || ' ' || individual.name || ' ' || individual.patr_name;
	   end loop;
    end loop;
    return fullName;
        
end;
$$;

