CREATE FUNCTION apdam_search_reg_new_distinct()
  RETURNS void
LANGUAGE plpgsql
AS $$
BEGIN
    UPDATE apdam_regs r SET new_district_id = apda_get_district_id(reg_info);
END;
$$;

