CREATE FUNCTION apdam_attachment_new_patients_by_context(in_md_clinic_id integer, in_department_id integer, in_type_id integer, in_reg_date date)
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
  batch_size INT := 500;
  ids        INT [] := ARRAY [] :: INT [];
  r          RECORD;
BEGIN
  --прикрепляем пациентов для которых найден единственный участок
  WITH cte AS (
      SELECT
        d2.patient_id,
        d2.district_id,
        d2.pim_party_address_id
      FROM
        (SELECT
           patient_id,
           count(patient_id)
         FROM apdam_patient_district
         GROUP BY patient_id
         HAVING count(patient_id) = 1) d1
        LEFT JOIN apdam_patient_district d2 ON d2.patient_id = d1.patient_id
  )
  INSERT INTO pci_patient_reg (request_dt, reg_dt, clinic_id, department_id, district_id, address_id, patient_id, state_id, type_id)
    SELECT
      current_date,
      in_reg_date,
      in_md_clinic_id,
      in_department_id,
      cte.district_id,
      cte.pim_party_address_id,
      cte.patient_id,
      1,
      in_type_id
    FROM cte;

  --удаляем такие прикрепления из контекста
  DELETE FROM apdam_patient_district
  WHERE patient_id IN (SELECT patient_id
                       FROM apdam_patient_district
                       GROUP BY patient_id
                       HAVING count(patient_id) = 1);

  --прикрепляем остальных, чтобы не было переполнения прикрепляем по одному
  ids = (SELECT array_agg(DISTINCT patient_id)
         FROM apdam_patient_district
         LIMIT batch_size);
  IF array_length(ids, 1) > 0
  THEN
    EXECUTE apdam_create_district_attachment_info_context(in_reg_date);
  ELSE RETURN;
  END IF;

  WHILE (array_length(ids, 1) > 0) LOOP
    FOR i IN array_lower(ids, 1)..array_upper(ids, 1) LOOP
      SELECT pd.*
      INTO r
      FROM apdam_patient_district pd
        JOIN apdam_district_attachment_info dai ON dai.district_id = pd.district_id
      WHERE pd.patient_id = ids [i]
      ORDER BY
        CASE WHEN dai.is_unlimited OR dai.attache_number > dai.count_regs
          THEN 1
        ELSE 999 END,
        dai.order_number,
        dai.attache_number DESC,
        pd.district_id
      LIMIT 1;

      INSERT INTO pci_patient_reg (request_dt, reg_dt, clinic_id, department_id, district_id, address_id, patient_id, state_id, type_id)
      VALUES (current_date, in_reg_date, in_md_clinic_id, in_department_id, r.district_id, r.pim_party_address_id,
              r.patient_id, 1, in_type_id);

      UPDATE apdam_district_attachment_info
      SET count_regs = count_regs + 1;
    END LOOP;

    DELETE FROM apdam_patient_district
    WHERE patient_id = ANY (ids);
    ids = (SELECT array_agg(DISTINCT patient_id)
           FROM apdam_patient_district
           LIMIT batch_size);
  END LOOP;
END;
$$;

