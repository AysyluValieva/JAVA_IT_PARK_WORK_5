CREATE FUNCTION fsym_on_u_for_mb_md_mblnc_rsn_ccdnt_mngrp()
  RETURNS trigger
LANGUAGE plpgsql
AS $fun$
declare var_row_data text; 
                                declare var_old_data text; 
                                begin
                                   
                                  if 1=1 and "public".sym_triggers_disabled() = 0 then                                                                                                 
                                    var_row_data := 
          case when new."id" is null then '' else '"' || cast(cast(new."id" as numeric) as varchar) || '"' end||','||
          case when new."code" is null then '' else '"' || replace(replace(cast(new."code" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."name" is null then '' else '"' || replace(replace(cast(new."name" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."note_id" is null then '' else '"' || cast(cast(new."note_id" as numeric) as varchar) || '"' end||','||
          case when new."e_code" is null then '' else '"' || replace(replace(cast(new."e_code" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end; 
                                    var_old_data := 
          case when old."id" is null then '' else '"' || cast(cast(old."id" as numeric) as varchar) || '"' end||','||
          case when old."code" is null then '' else '"' || replace(replace(cast(old."code" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when old."name" is null then '' else '"' || replace(replace(cast(old."name" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when old."note_id" is null then '' else '"' || cast(cast(old."note_id" as numeric) as varchar) || '"' end||','||
          case when old."e_code" is null then '' else '"' || replace(replace(cast(old."e_code" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end; 
                                    if 1=1 then 
                                    insert into "public".sym_data                                                                                                                     
                                    (table_name, event_type, trigger_hist_id, pk_data, row_data, old_data, channel_id, transaction_id, source_node_id, external_data, create_time)                     
                                    values(                                                                                                                                                            
                                      'md_ambulance_reason_accident',                                                                                                                                            
                                      'U',                                                                                                                                                             
                                      77,                                                                                                                                             
                                      
          case when old."id" is null then '' else '"' || cast(cast(old."id" as numeric) as varchar) || '"' end,                                                                                                                                                      
                                      var_row_data,                                                                                                                                                      
                                      var_old_data,                                                                                                                                                   
                                      'amb_md_ambulance_reason_accident_default',                                                                                                                                                
                                      txid_current(),                                                                                                                                               
                                      "public".sym_node_disabled(),                                                                                                                   
                                      null,                                                                                                                                               
                                      CURRENT_TIMESTAMP                                                                                                                
                                    );                                                                                                                                                                 
                                  end if;                                                                                                                                                              
                                  end if;                                                                                                                                                              
                                                                                                                                                                               
                                  return null;                                                                                                                                                         
                                end;
$fun$;

