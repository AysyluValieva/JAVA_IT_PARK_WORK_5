CREATE FUNCTION edit_table_setting_row(_id integer, _table_hierarchy_id integer, _partition_period_id integer, _position integer, _audit_active boolean, _updated_by integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
                  r             RECORD;
                  active_status VARCHAR;
                BEGIN
                  SELECT *
                  INTO r
                  FROM audit.table_setting ts
                  WHERE id = _id;

                  --update settings
                  UPDATE audit.table_setting
                  SET table_hierarchy_id = _table_hierarchy_id, position = _position, audit_active = _audit_active
                  WHERE id = r.id;

                  IF r.partition_period_id != _partition_period_id
                  THEN
                    --close previous task
                    UPDATE audit.repartitioning_task
                    SET status_id = 2, canceled_at = current_timestamp, canceled_by = _updated_by
                    WHERE table_setting_id = r.id AND status_id = 1;

                    --create new task
                    INSERT INTO audit.repartitioning_task (
                      table_setting_id,
                      from_partition_period_id,
                      to_partition_period_id,
                      status_id,
                      mode_type_id,
                      created_at,
                      created_by)
                    VALUES (r.id, r.partition_period_id, _partition_period_id, 1, 1, current_timestamp, _updated_by);
                  END IF;

                  --enable / disable trigger
                  IF _audit_active
                  THEN active_status = 'ENABLE';
                  ELSE active_status = 'DISABLE'; END IF;
                  EXECUTE format('ALTER TABLE %1$s %2$s TRIGGER audit_partitioning_trigger', concat(r.table_schema, '.', r.table_name),
                                 active_status);
                END;
$$;

