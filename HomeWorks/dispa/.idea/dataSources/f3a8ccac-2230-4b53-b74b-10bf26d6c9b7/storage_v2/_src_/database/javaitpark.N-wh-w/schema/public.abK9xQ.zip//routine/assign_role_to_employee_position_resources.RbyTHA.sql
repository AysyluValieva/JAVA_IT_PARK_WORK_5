CREATE FUNCTION assign_role_to_employee_position_resources(new_role_id integer, employee_position_ids_json character varying, employee_res_kind_id integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
                ep_id integer;
                employee_position_ids integer[];
                new_res_count integer;
            begin

                employee_position_ids := array(select value::int from json_array_elements_text(cast(employee_position_ids_json as json)));

                new_res_count := (select count(*)
                from (select unnest(employee_position_ids) as id ) i
                left join pim_employee_position_resource ep on ep.employee_position_id=i.id
                where ep.id is null);

                if new_res_count > 0 then
                    foreach ep_id in array array(
                    select array_agg(i.id)
                    from (select unnest(employee_position_ids) as id ) i
                    left join pim_employee_position_resource ep on ep.employee_position_id=i.id
                    where ep.id is null)
                    loop
                    insert into sr_resource (id, res_kind_id, role_id) values (nextval('sr_resource_seq'), 1, new_role_id);
                    insert into pim_employee_position_resource(id, employee_position_id) values(currval('sr_resource_seq'), ep_id);
                    end loop;
                end if;

                update sr_resource set role_id=new_role_id
                where id=any(select id from pim_employee_position_resource where employee_position_id = any(employee_position_ids));

            return;
            end
$$;

