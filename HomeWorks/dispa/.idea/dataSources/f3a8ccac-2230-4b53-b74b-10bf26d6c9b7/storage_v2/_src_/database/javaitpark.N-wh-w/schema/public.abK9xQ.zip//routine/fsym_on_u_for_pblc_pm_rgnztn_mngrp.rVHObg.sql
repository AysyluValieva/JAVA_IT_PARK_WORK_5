CREATE FUNCTION fsym_on_u_for_pblc_pm_rgnztn_mngrp()
  RETURNS trigger
LANGUAGE plpgsql
AS $fun$
declare var_row_data text; 
                                declare var_old_data text; 
                                begin
                                   
                                  if 1=1 and "public".sym_triggers_disabled() = 0 then                                                                                                 
                                    var_row_data := 
          case when new."id" is null then '' else '"' || cast(cast(new."id" as numeric) as varchar) || '"' end||','||
          case when new."close_dt" is null then '' else '"' || to_char(new."close_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when new."code" is null then '' else '"' || replace(replace(cast(new."code" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."full_name" is null then '' else '"' || replace(replace(cast(new."full_name" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."reg_dt" is null then '' else '"' || to_char(new."reg_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when new."short_name" is null then '' else '"' || replace(replace(cast(new."short_name" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."legal_form_id" is null then '' else '"' || cast(cast(new."legal_form_id" as numeric) as varchar) || '"' end||','||
          case when new."sphere_id" is null then '' else '"' || cast(cast(new."sphere_id" as numeric) as varchar) || '"' end||','||
          case when new."work_territory_id" is null then '' else '"' || cast(cast(new."work_territory_id" as numeric) as varchar) || '"' end||','||
          case when new."version" is null then '' else '"' || to_char(new."version", 'YYYY-MM-DD HH24:MI:SS.US') || '"' end||','||
          case when new."parent_id" is null then '' else '"' || cast(cast(new."parent_id" as numeric) as varchar) || '"' end||','||
          case when new."country_jurisdiction_id" is null then '' else '"' || cast(cast(new."country_jurisdiction_id" as numeric) as varchar) || '"' end||','||
          case when new."unit_id" is null then '' else '"' || cast(cast(new."unit_id" as numeric) as varchar) || '"' end||','||
          case when new."own_form_id" is null then '' else '"' || cast(cast(new."own_form_id" as numeric) as varchar) || '"' end||','||
          case when new."scope_id" is null then '' else '"' || cast(cast(new."scope_id" as numeric) as varchar) || '"' end||','||
          case when new."e_code" is null then '' else '"' || replace(replace(cast(new."e_code" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."from_dt" is null then '' else '"' || to_char(new."from_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when new."to_dt" is null then '' else '"' || to_char(new."to_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when new."max_distant_point" is null then '' else '"' || cast(cast(new."max_distant_point" as numeric) as varchar) || '"' end||','||
          case when new."longitude" is null then '' else '"' || cast(cast(new."longitude" as numeric) as varchar) || '"' end||','||
          case when new."latitude" is null then '' else '"' || cast(cast(new."latitude" as numeric) as varchar) || '"' end; 
                                    var_old_data := 
          case when old."id" is null then '' else '"' || cast(cast(old."id" as numeric) as varchar) || '"' end||','||
          case when old."close_dt" is null then '' else '"' || to_char(old."close_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when old."code" is null then '' else '"' || replace(replace(cast(old."code" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when old."full_name" is null then '' else '"' || replace(replace(cast(old."full_name" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when old."reg_dt" is null then '' else '"' || to_char(old."reg_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when old."short_name" is null then '' else '"' || replace(replace(cast(old."short_name" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when old."legal_form_id" is null then '' else '"' || cast(cast(old."legal_form_id" as numeric) as varchar) || '"' end||','||
          case when old."sphere_id" is null then '' else '"' || cast(cast(old."sphere_id" as numeric) as varchar) || '"' end||','||
          case when old."work_territory_id" is null then '' else '"' || cast(cast(old."work_territory_id" as numeric) as varchar) || '"' end||','||
          case when old."version" is null then '' else '"' || to_char(old."version", 'YYYY-MM-DD HH24:MI:SS.US') || '"' end||','||
          case when old."parent_id" is null then '' else '"' || cast(cast(old."parent_id" as numeric) as varchar) || '"' end||','||
          case when old."country_jurisdiction_id" is null then '' else '"' || cast(cast(old."country_jurisdiction_id" as numeric) as varchar) || '"' end||','||
          case when old."unit_id" is null then '' else '"' || cast(cast(old."unit_id" as numeric) as varchar) || '"' end||','||
          case when old."own_form_id" is null then '' else '"' || cast(cast(old."own_form_id" as numeric) as varchar) || '"' end||','||
          case when old."scope_id" is null then '' else '"' || cast(cast(old."scope_id" as numeric) as varchar) || '"' end||','||
          case when old."e_code" is null then '' else '"' || replace(replace(cast(old."e_code" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when old."from_dt" is null then '' else '"' || to_char(old."from_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when old."to_dt" is null then '' else '"' || to_char(old."to_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when old."max_distant_point" is null then '' else '"' || cast(cast(old."max_distant_point" as numeric) as varchar) || '"' end||','||
          case when old."longitude" is null then '' else '"' || cast(cast(old."longitude" as numeric) as varchar) || '"' end||','||
          case when old."latitude" is null then '' else '"' || cast(cast(old."latitude" as numeric) as varchar) || '"' end; 
                                    if var_old_data is null or var_row_data != var_old_data then 
                                    insert into "public".sym_data                                                                                                                     
                                    (table_name, event_type, trigger_hist_id, pk_data, row_data, old_data, channel_id, transaction_id, source_node_id, external_data, create_time)                     
                                    values(                                                                                                                                                            
                                      'pim_organization',                                                                                                                                            
                                      'U',                                                                                                                                                             
                                      18282,                                                                                                                                             
                                      
          case when old."id" is null then '' else '"' || cast(cast(old."id" as numeric) as varchar) || '"' end,                                                                                                                                                      
                                      var_row_data,                                                                                                                                                      
                                      var_old_data,                                                                                                                                                   
                                      'public_pim_organization_default',                                                                                                                                                
                                      txid_current(),                                                                                                                                               
                                      "public".sym_node_disabled(),                                                                                                                   
                                      null,                                                                                                                                               
                                      CURRENT_TIMESTAMP                                                                                                                
                                    );                                                                                                                                                                 
                                  end if;                                                                                                                                                              
                                  end if;                                                                                                                                                              
                                                                                                                                                                               
                                  return null;                                                                                                                                                         
                                end;
$fun$;

