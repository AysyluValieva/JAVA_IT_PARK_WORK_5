CREATE FUNCTION create_call(xcall_dt integer, xcall_kind_id integer, xcall_type_id integer, xis_group_sufferer boolean, xis_psycho boolean, xsum_sufferer integer, xcaller_reason_id integer, xreason_diag integer, xreason_note character varying, xcall_place_id integer, xcall_place_note character varying, xplace_org_id integer, xplace_department_id integer, xaddress_id integer, xhouse character varying, xhousing character varying, xapartment character varying, xporch character varying, xfloor character varying, xdoor_code character varying, xdescription character varying, xto_org_id integer, xto_department_id integer, xto_address_id integer, xto_house character varying, xto_housing character varying, xto_apartment character varying, xto_porch character varying, xto_description character varying, xpatient_id integer, xsurname character varying, xname character varying, xpatrname character varying, xbirthdt date, xgender integer, xis_chronic boolean, xyears integer, xmonths integer, xdays integer, xphone_caller character varying, xcaller_id integer, xemployee_id integer, xcaller_note character varying, xpriority_id integer, xpriority integer, xcontrol integer, xnote character varying, xregistrator_id integer, xstation_id integer, xroute_id integer, xsubstation_id integer, xbrg_id integer, xemp_id integer, xparcal integer, xneed_exit_through integer, xuser integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
                xnum integer;
                i integer;
                dt TIMESTAMP  WITHOUT TIME ZONE;
                xstatehist integer;
                priorsum integer;
                xduble integer;

                resroute record;
                xroute_id integer;
                xroutehist integer;

                --госпитализация
                xcallnote integer;

                --АМБ
                xstate integer;
                xcall_prior integer;
                xcall_reason_id integer;
                xreason_accident_id integer;
                xtransmit_state integer;
                -- для случая
                xcase integer;
                xfunding integer;
                xcase_type integer;
                xcare_regimen integer;
                xcare_level integer;
                xcare_providing_form integer;
                xinit_goal integer;
                xinit_type integer;
                xadmission_type integer;
                xpayment_method integer;

              begin
                    xnum = (select amb.num_value(xstation_id,xcall_dt,xsubstation_id));
                    if (xpatient_id is null)
                        then
                            xpatient_id = amb.create_pat_vrem (xsurname,xname,xpatrname,xbirthdt,xgender);
                            update public.pci_patient set
                                note = note||', '||(select short_name from pim_organization where id = xstation_id)||', вызов №'||cast(xnum as varchar(6))||' от '||(select to_char(from_data,'dd.mm.yyyy') from amb.md_ambulance_change where id = xcall_dt)
                                where id = xpatient_id;
                    end if;
                    i = nextval('amb.md_ambulance_call_seq');
                    dt  = now();
                    insert into amb.md_ambulance_call (id,call_number,call_dt,call_kind_id,call_type_id,is_group_sufferer,sum_sufferer,
                                                    from_time,caller_reason_id,reason_diag,reason_note,
                                                    call_place_id,call_place_note,place_org_id,place_department_id,
                                                    address_id,house,housing,apartment,porch,floor,door_code,description,
                                                    to_org_id,to_department_id,to_address_id,to_house,to_housing,to_apartment,to_porch,to_description,
                                                    patient_id,is_chronic,age_years,age_months,age_days,
                                                    phone_caller,caller_id,employee_id,caller_note,
                                                    priority_id,priority,control,note,registrator_id,
                                                    station_id,route_id,substation_id,brg_id,emp_id)

                    values (i,xnum,xcall_dt,xcall_kind_id,xcall_type_id,xis_group_sufferer,xsum_sufferer,
                            dt,xcaller_reason_id,xreason_diag,xreason_note,
                            xcall_place_id,xcall_place_note,xplace_org_id,xplace_department_id,
                            xaddress_id,xhouse,xhousing,xapartment,xporch,xfloor,xdoor_code,xdescription,
                            xto_org_id,xto_department_id,xto_address_id,xto_house,xto_housing,xto_apartment,xto_porch,xto_description,
                            xpatient_id,xis_chronic,xyears,xmonths,xdays,
                            xphone_caller,xcaller_id,xemployee_id,xcaller_note,
                            xpriority_id,xpriority,xcontrol,xnote,xregistrator_id,
                            xstation_id,xroute_id,xsubstation_id,xbrg_id,xemp_id);

                    xstatehist = amb.add_ambcall_state_hist (i,dt,1,null,xregistrator_id);
                    priorsum = amb.priority_calculation(i,xregistrator_id);
                    if (xcall_type_id = 2) and (xparcal is not null)
                        then
                            execute amb.add_amb_call_double(i,9,true,xregistrator_id,xparcal);
                            update amb.md_ambulance_call set call_mark  = 2 where id = i;
                    end if;

                    if amb.check_call_double(i) = false
                        then update amb.md_ambulance_call set call_mark  = 1 where id = i;
                    end if;

                    for resroute in
                        select ra.id as id, ra.address_id as address_id,ra.building_pattent as building_pattent,ra.route_id as route_id
                            from amb.md_ambulance_route_area ra
                            left join amb.md_ambulance_route r on r.id = ra.route_id
                            where r.org_id = xstation_id and (r.to_time is null or r.to_time >= now()) and (ra.to_time is null or ra.to_time >= now())
                    loop
                        if amb.check_address_in_district (xaddress_id,resroute.address_id,xhouse,resroute.building_pattent)
                            then
                                xroute_id = resroute.route_id;
                                xroutehist = amb.add_ambcall_route_hist (i,dt,xstation_id,xroute_id,xsubstation_id,NULL,xregistrator_id);
                                xstatehist = amb.add_ambcall_state_hist (i,dt,2,null,xregistrator_id);
                        end if;
                    end loop;

                    --госпитализация, устанавливаем отметку по виду вызова
                    IF (xcall_kind_id in (3,4)) or (xto_org_id is not null)
                        THEN
                            xcallnote = amb.add_call_note(i,21,true,null,'а/у госпитализация',xregistrator_id,null);
                    END IF;

                    --АМБ, в пути
                    IF xcall_kind_id = 7 or xcall_type_id =4
                    THEN
                        -- приоритет
                        select into xcall_prior	priority_id from amb.md_ambulance_call where id = i;

                        --причина вызова, причина несчастного случая
                        select into xcall_reason_id,xreason_accident_id call_reason_id,reason_accident_id
                            from amb.md_ambulance_caller_reason where id = xcaller_reason_id;

                        -- Случай
                        xcare_providing_form = (select id from md_care_providing_form  where e_code =
                            case when xcall_kind_id in (4,6) then '3' else case when xcall_prior in (1,2) then '1' else '2' end end);
                        xinit_type = (select id from mc_case_init_type where e_code =
                            case when xcall_kind_id in (3,4,6) then '2' else '1' end);
                        xfunding = (select id from fin_funding_source_type where e_code = 'OMS');
                        if not exists (select id from amb.md_ambulance_call_result where id = i)
                            then
                                -- создаем "Случай"
                                if xcall_type_id =4
                                    then
                                        xcase_type = (select id from mc_case_type where e_code = '7');
                                    else
                                        -- для АМБ -  тип случая "Случай оказания амбулаторной помощи СНМП"
                                        xcase_type = (select id from mc_case_type where e_code = '8');
                                end if;
                                xcare_regimen = (select id from mc_care_regimen where e_code = '6');
                                xcare_level = (select id from mc_care_level where e_code = '2');
                                xinit_goal = (select id from mc_case_init_goal where e_code = '03');
                                xadmission_type = (select id from mc_admission_type where e_code = '2');
                                xpayment_method = (select id from mc_payment_method where code='15');  -- системный справочник, в эталоне не заполнено e_code

                                xcase = nextval('mc_case_seq');
                                insert into mc_case(id,case_type_id,care_regimen_id,uid,care_level_id,care_providing_form_id,init_goal_id,init_type_id,admission_type_id,funding_id
                                    ,open_date,create_date,clinic_id, patient_id,payment_method_id)
                                values(xcase,xcase_type,xcare_regimen,xnum,xcare_level,xcare_providing_form,xinit_goal,xinit_type,xadmission_type,xfunding
                                    ,cast(dt as date),cast(dt as date),xstation_id,xpatient_id,xpayment_method);

                                xtransmit_state = (select id from amb.md_ambulance_transmit_state where e_code = '1');
                                -- записываем данные в "Результат вызова"
                                insert into amb.md_ambulance_call_result (id,case_id,transmit_state_id,call_reason_id,reason_accident_id,registrator_id)
                                    values (i,xcase,xtransmit_state,xcall_reason_id,xreason_accident_id,xregistrator_id);
                        end if;

                        /*if xbrg_id is not null
                            then*/
                                update amb.md_ambulance_call set brg_id = xbrg_id,emp_id = xemp_id where id = i;
                                -- состояние вызова - "Назначена бригада"
                                xstate :=  amb.add_ambcall_state_hist (i,dt + '1 second',4,1,xregistrator_id);
                                -- состояние вызова - "Вызов передан бригаде"
                                xstate :=  amb.add_ambcall_state_hist (i,dt + '2 second',15,xtransmit_state,xregistrator_id);
                                -- состояние вызова - "Вызов принят бригадой"
                                xstate :=  amb.add_ambcall_state_hist (i,dt + '3 second',5,xtransmit_state,xregistrator_id);
                                -- надо ли состояние выезд на вызов = 6 не понятно
                                xstate :=  amb.add_ambcall_state_hist (i,dt + '4 second',7,xtransmit_state,xregistrator_id);
                                -- состояние бригады - "На вызове"
                        if xbrg_id is not null
                            then
                                execute amb.add_team_job_status_hist (xbrg_id,dt + '5 second',2,xregistrator_id,CAST(xnum as varchar(10))||'/'||coalesce(adr__get_element_as_text(xaddress_id,'(6,s,0)(7,s,0)(8,s,0)'),xdescription),xuser);
                        end if;
                                -- запись в историю диспетчерезации - "бригада"
                                xstate := amb.add_ambcall_route_hist (i,dt + '5 second',null,null,null,coalesce(xbrg_id,xemp_id),xregistrator_id);
                        /*end if;
                        if xemp_id is not null
                            then update amb.md_ambulance_call set emp_id = xemp_id where id = i;
                        end if;*/

                    END IF;

                    -- спц, активный, в пути, скм
                    if (xparcal is not null) and (( xcall_kind_id = 5) or (xcall_type_id = 3) or (xcall_type_id = 4) or (xcall_kind_id = 6))
                        then
                            insert into amb.md_ambulance_call_on_base (id,call_on_base_id)
                                values (i,xparcal);
                    end if;

                    -- активный
                    if (xcall_type_id = 3)
                        then
                            -- Случай
                            xcare_providing_form = (select id from md_care_providing_form  where e_code =
                                case when xcall_kind_id in (4,6) then '3' else case when xcall_prior in (1,2) then '1' else '2' end end);
                            xinit_type = (select id from mc_case_init_type where e_code =
                                case when xcall_kind_id in (3,4,6) then '2' else '1' end);
                            xfunding = (select id from fin_funding_source_type where e_code = 'OMS');
                            if not exists (select id from amb.md_ambulance_call_result where id = i)
                            then
                                -- создаем "Случай"
                                xcase_type = (select id from mc_case_type where e_code = '7');
                                xcare_regimen = (select id from mc_care_regimen where e_code = '6');
                                xcare_level = (select id from mc_care_level where e_code = '2');
                                xinit_goal = (select id from mc_case_init_goal where e_code = '03');
                                xadmission_type = (select id from mc_admission_type where e_code = '2');
                                xpayment_method = (select id from mc_payment_method where code='15');  -- системный справочник, в эталоне не заполнено e_code

                                xcase = nextval('mc_case_seq');
                                insert into mc_case(id,case_type_id,care_regimen_id,uid,care_level_id,care_providing_form_id,init_goal_id,init_type_id,admission_type_id,funding_id
                                        ,open_date,create_date,clinic_id, patient_id,payment_method_id)
                                    values(xcase,xcase_type,xcare_regimen,xnum,xcare_level,xcare_providing_form,xinit_goal,xinit_type,xadmission_type,xfunding
                                        ,cast(dt as date),cast(dt as date),xstation_id,xpatient_id,xpayment_method);

                                -- записываем данные в "Результат вызова"
                                insert into amb.md_ambulance_call_result (id,case_id,transmit_state_id,registrator_id,need_exit_through)
                                    values (i,xcase,1,xregistrator_id,xneed_exit_through);
                            end if;
                    end if;

                    -- автодобавление отметок
                    execute amb.auto_add_call_note (i,xcaller_reason_id,xreason_diag,xis_psycho,xregistrator_id,xplace_org_id,xplace_department_id,xaddress_id,xhouse);

                    return i;
              end;
$$;

