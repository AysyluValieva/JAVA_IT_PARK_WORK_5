CREATE FUNCTION typing_gen_res_group(integer, integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare rec record;
      dctr_id integer;
 -- $1 - doctor_id, $2 - res_group_id
begin
if $2 is null then
   for rec in
    with t as (
     select
      nextval('sr_res_group_seq') id, current_date bdate, pn.name rg_name, e.organization_id org_id, ep.id resp_id, epr.id res_id, p.department_id dep_id
     from pim_employee_position_resource epr
     join pim_employee_position ep on epr.employee_position_id = ep.id
     join pim_employee e on ep.employee_id = e.id
     join pim_individual i on e.individual_id = i.id
     join pim_position p on ep.position_id = p.id
     left join pim_position_name pn on p.id = pn.position_id and i.gender_id = pn.sex_id
      where epr.id = $1
    ),

    ins_to_rg as (
    insert into sr_res_group(id, bdate, is_system, name, org_id, responsible_id, department_id)
     select id, bdate, true, rg_name, org_id, resp_id, dep_id from t returning *
    ),

    ins_to_rgr as (
     insert into sr_res_group_relationship(id, resource_id, group_id, bdatetime, role_id)
     select nextval('sr_res_group_relationship_seq'), res_id, id, now(), (select id from sr_res_role where code = 'DOCTOR') from t returning *
    )
    select id from ins_to_rg
     loop
     end loop;
     return rec.id;
end if;

if $2 is not null then
    for rec in
     with t as (
      select id, nextval('sr_res_group_seq') new_id, bdate, edate, is_system, name, org_id, department_id, responsible_id, is_available_in_electronic_queue, label_id from sr_res_group rg
      where id = $2
     ),

     t1 as (
      insert into sr_res_group(id, bdate, edate, is_system, name, org_id, department_id, responsible_id, is_available_in_electronic_queue, label_id)
      select new_id,  bdate, edate, true, name, org_id, department_id, responsible_id, is_available_in_electronic_queue, label_id from t
      returning *
     ),

     t2 as (
      insert into sr_res_group_relationship(id, bdatetime, edatetime, resource_id, group_id, role_id, is_disabled)
      select nextval('sr_res_group_relationship_seq'), rgr.bdatetime, rgr.edatetime, rgr.resource_id, t1.id, rgr.role_id, is_disabled from sr_res_group_relationship rgr
      cross join t1
      where rgr.group_id = $2
      returning *
     )
     select group_id id from t2
     loop
     end loop;
     return rec.id;
end if;

end;
$$;

