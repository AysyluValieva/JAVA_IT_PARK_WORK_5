CREATE FUNCTION get_count_quotas(orgid integer, profileid integer, date date)
  RETURNS text
LANGUAGE plpgsql
AS $$
BEGIN
  RETURN (select 'Доступно квот: '||coalesce(
      (SELECT sum(q.count_quotas) - sum(q.using_quotas) FROM  vmp.vmp_quotas q
          JOIN vmp.vmp_setting_hospital l ON q.setting_id = l.id
          WHERE l.profile_id = $2
          AND $3 between coalesce(l.from_dt,'-infinity') and coalesce(l.to_dt, 'infinity')
          AND l.clinic_id = $1), 0));
END;
$$;

