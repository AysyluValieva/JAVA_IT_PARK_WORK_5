CREATE FUNCTION apda_check_district_by_reg_and_criterion_type(info apda_reg_info, district_id integer, type_code character varying)
  RETURNS boolean
LANGUAGE plpgsql
AS $$
BEGIN
  CASE $3
    WHEN 'ADDRESS'
    THEN RETURN apda_check_district_by_address_criterion((info).patient.address_info, (info).reg_dt, $2);
    WHEN 'ORGANIZATION'
    THEN RETURN apda_check_district_by_organization_criterion((info).patient.org_ids, $2);
    WHEN 'DIAGNOSIS'
    THEN RETURN apda_check_district_by_diagnosis_criterion((info).patient.diagnos_codes, $2);
    WHEN 'AGE'
    THEN RETURN apda_check_district_by_age_criterion((info).patient.age, $2);
    WHEN 'GENDER'
    THEN RETURN apda_check_district_by_gender_criterion((info).patient.gender_id, $2);
    WHEN 'BENEFIT'
    THEN RETURN apda_check_district_by_benefit_criterion((info).patient.benefit_ids, $2);
  END CASE;

  RETURN TRUE;
END;
$$;

