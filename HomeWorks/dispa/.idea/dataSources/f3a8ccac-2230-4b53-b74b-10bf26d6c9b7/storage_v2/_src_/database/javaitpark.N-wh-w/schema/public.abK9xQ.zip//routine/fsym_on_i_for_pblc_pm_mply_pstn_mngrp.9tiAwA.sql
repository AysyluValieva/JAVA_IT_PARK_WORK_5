CREATE FUNCTION fsym_on_i_for_pblc_pm_mply_pstn_mngrp()
  RETURNS trigger
LANGUAGE plpgsql
AS $fun$
begin                                                                                                                                                                  
                                   
                                  if 1=1 and "public".sym_triggers_disabled() = 0 then                                                                                                 
                                    insert into "public".sym_data                                                                                                                     
                                    (table_name, event_type, trigger_hist_id, row_data, channel_id, transaction_id, source_node_id, external_data, create_time)                                        
                                    values(                                                                                                                                                            
                                      'pim_employee_position',                                                                                                                                            
                                      'I',                                                                                                                                                             
                                      18285,                                                                                                                                             
                                      
          case when new."id" is null then '' else '"' || cast(cast(new."id" as numeric) as varchar) || '"' end||','||
          case when new."dismissal_order_code" is null then '' else '"' || replace(replace(cast(new."dismissal_order_code" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."start_date" is null then '' else '"' || to_char(new."start_date", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when new."hiring_order_code" is null then '' else '"' || replace(replace(cast(new."hiring_order_code" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."rate" is null then '' else '"' || cast(cast(new."rate" as numeric) as varchar) || '"' end||','||
          case when new."end_date" is null then '' else '"' || to_char(new."end_date", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when new."dismissal_reason_id" is null then '' else '"' || cast(cast(new."dismissal_reason_id" as numeric) as varchar) || '"' end||','||
          case when new."employee_id" is null then '' else '"' || cast(cast(new."employee_id" as numeric) as varchar) || '"' end||','||
          case when new."employment_type_id" is null then '' else '"' || cast(cast(new."employment_type_id" as numeric) as varchar) || '"' end||','||
          case when new."hiring_type_id" is null then '' else '"' || cast(cast(new."hiring_type_id" as numeric) as varchar) || '"' end||','||
          case when new."position_id" is null then '' else '"' || cast(cast(new."position_id" as numeric) as varchar) || '"' end||','||
          case when new."position_type_id" is null then '' else '"' || cast(cast(new."position_type_id" as numeric) as varchar) || '"' end||','||
          case when new."unit_id" is null then '' else '"' || cast(cast(new."unit_id" as numeric) as varchar) || '"' end||','||
          case when new."code" is null then '' else '"' || replace(replace(cast(new."code" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."pref_prescription" is null then '' when new."pref_prescription" then '"1"' else '"0"' end||','||
          case when new."extra_payment" is null then '' when new."extra_payment" then '"1"' else '"0"' end||','||
          case when new."target_training" is null then '' when new."target_training" then '"1"' else '"0"' end||','||
          case when new."leaving_reason_id" is null then '' else '"' || cast(cast(new."leaving_reason_id" as numeric) as varchar) || '"' end,                                                                                                                                                      
                                      'public_pim_employee_position_default',                                                                                                                                                
                                      txid_current(),                                                                                                                                               
                                      "public".sym_node_disabled(),                                                                                                                   
                                      null,                                                                                                                                               
                                      CURRENT_TIMESTAMP                                                                                                                
                                    );                                                                                                                                                                 
                                  end if;                                                                                                                                                              
                                                                                                                                                                               
                                  return null;                                                                                                                                                         
                                end;
$fun$;

