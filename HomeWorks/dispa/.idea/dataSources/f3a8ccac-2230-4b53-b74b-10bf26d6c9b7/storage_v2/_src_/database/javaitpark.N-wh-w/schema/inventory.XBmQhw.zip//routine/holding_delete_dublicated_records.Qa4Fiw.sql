CREATE FUNCTION holding_delete_dublicated_records()
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
  rec record;
BEGIN

FOR rec IN (select min(id) as min_id, name, org_id FROM "inventory"."holding" h group by  h."name", h.org_id having count(1)>1)
   loop
       update inventory.hold_modif set holding_id = rec.min_id
              where holding_id in (select id FROM "inventory"."holding" h1 where h1.name=rec.name and h1.org_id=rec.org_id);
   end loop;
END;
$$;

