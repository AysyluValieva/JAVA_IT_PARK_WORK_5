CREATE FUNCTION partition_insert_sr_scgenerated_y2018_m05_r38(r sr_scgenerated)
  RETURNS integer
LANGUAGE plpgsql
AS $$
BEGIN INSERT INTO schedule.sr_scgenerated_y2018_m05_r38 SELECT r.*; RETURN 1;END
$$;

