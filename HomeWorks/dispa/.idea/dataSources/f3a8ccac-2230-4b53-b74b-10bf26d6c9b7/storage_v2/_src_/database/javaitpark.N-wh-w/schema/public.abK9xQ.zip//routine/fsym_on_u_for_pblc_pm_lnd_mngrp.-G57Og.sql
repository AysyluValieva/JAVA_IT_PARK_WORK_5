CREATE FUNCTION fsym_on_u_for_pblc_pm_lnd_mngrp()
  RETURNS trigger
LANGUAGE plpgsql
AS $fun$
declare var_row_data text; 
                                declare var_old_data text; 
                                begin
                                   
                                  if 1=1 and "public".sym_triggers_disabled() = 0 then                                                                                                 
                                    var_row_data := 
          case when new."id" is null then '' else '"' || cast(cast(new."id" as numeric) as varchar) || '"' end||','||
          case when new."area" is null then '' else '"' || cast(cast(new."area" as numeric) as varchar) || '"' end||','||
          case when new."code" is null then '' else '"' || replace(replace(cast(new."code" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."note" is null then '' else '"' || replace(replace(cast(new."note" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."title_right_support" is null then '' else '"' || replace(replace(cast(new."title_right_support" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."address_id" is null then '' else '"' || cast(cast(new."address_id" as numeric) as varchar) || '"' end||','||
          case when new."ownership_pattern_id" is null then '' else '"' || cast(cast(new."ownership_pattern_id" as numeric) as varchar) || '"' end||','||
          case when new."org_id" is null then '' else '"' || cast(cast(new."org_id" as numeric) as varchar) || '"' end||','||
          case when new."from_dt" is null then '' else '"' || to_char(new."from_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when new."to_dt" is null then '' else '"' || to_char(new."to_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when new."name" is null then '' else '"' || replace(replace(cast(new."name" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."okato" is null then '' else '"' || replace(replace(cast(new."okato" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."territory_code" is null then '' else '"' || replace(replace(cast(new."territory_code" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."nearest_station_name" is null then '' else '"' || replace(replace(cast(new."nearest_station_name" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."nearest_station_distance" is null then '' else '"' || cast(cast(new."nearest_station_distance" as numeric) as varchar) || '"' end||','||
          case when new."nearest_airport_name" is null then '' else '"' || replace(replace(cast(new."nearest_airport_name" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."nearest_airport_distance" is null then '' else '"' || cast(cast(new."nearest_airport_distance" as numeric) as varchar) || '"' end||','||
          case when new."nearest_bus_station_name" is null then '' else '"' || replace(replace(cast(new."nearest_bus_station_name" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."nearest_bus_station_distance" is null then '' else '"' || cast(cast(new."nearest_bus_station_distance" as numeric) as varchar) || '"' end||','||
          case when new."nearest_helipad_name" is null then '' else '"' || replace(replace(cast(new."nearest_helipad_name" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."nearest_helipad_distance" is null then '' else '"' || cast(cast(new."nearest_helipad_distance" as numeric) as varchar) || '"' end||','||
          case when new."main_road_name" is null then '' else '"' || replace(replace(cast(new."main_road_name" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end; 
                                    var_old_data := 
          case when old."id" is null then '' else '"' || cast(cast(old."id" as numeric) as varchar) || '"' end||','||
          case when old."area" is null then '' else '"' || cast(cast(old."area" as numeric) as varchar) || '"' end||','||
          case when old."code" is null then '' else '"' || replace(replace(cast(old."code" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when old."note" is null then '' else '"' || replace(replace(cast(old."note" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when old."title_right_support" is null then '' else '"' || replace(replace(cast(old."title_right_support" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when old."address_id" is null then '' else '"' || cast(cast(old."address_id" as numeric) as varchar) || '"' end||','||
          case when old."ownership_pattern_id" is null then '' else '"' || cast(cast(old."ownership_pattern_id" as numeric) as varchar) || '"' end||','||
          case when old."org_id" is null then '' else '"' || cast(cast(old."org_id" as numeric) as varchar) || '"' end||','||
          case when old."from_dt" is null then '' else '"' || to_char(old."from_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when old."to_dt" is null then '' else '"' || to_char(old."to_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when old."name" is null then '' else '"' || replace(replace(cast(old."name" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when old."okato" is null then '' else '"' || replace(replace(cast(old."okato" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when old."territory_code" is null then '' else '"' || replace(replace(cast(old."territory_code" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when old."nearest_station_name" is null then '' else '"' || replace(replace(cast(old."nearest_station_name" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when old."nearest_station_distance" is null then '' else '"' || cast(cast(old."nearest_station_distance" as numeric) as varchar) || '"' end||','||
          case when old."nearest_airport_name" is null then '' else '"' || replace(replace(cast(old."nearest_airport_name" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when old."nearest_airport_distance" is null then '' else '"' || cast(cast(old."nearest_airport_distance" as numeric) as varchar) || '"' end||','||
          case when old."nearest_bus_station_name" is null then '' else '"' || replace(replace(cast(old."nearest_bus_station_name" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when old."nearest_bus_station_distance" is null then '' else '"' || cast(cast(old."nearest_bus_station_distance" as numeric) as varchar) || '"' end||','||
          case when old."nearest_helipad_name" is null then '' else '"' || replace(replace(cast(old."nearest_helipad_name" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when old."nearest_helipad_distance" is null then '' else '"' || cast(cast(old."nearest_helipad_distance" as numeric) as varchar) || '"' end||','||
          case when old."main_road_name" is null then '' else '"' || replace(replace(cast(old."main_road_name" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end; 
                                    if 1=1 then 
                                    insert into "public".sym_data                                                                                                                     
                                    (table_name, event_type, trigger_hist_id, pk_data, row_data, old_data, channel_id, transaction_id, source_node_id, external_data, create_time)                     
                                    values(                                                                                                                                                            
                                      'pim_land',                                                                                                                                            
                                      'U',                                                                                                                                                             
                                      29,                                                                                                                                             
                                      
          case when old."id" is null then '' else '"' || cast(cast(old."id" as numeric) as varchar) || '"' end,                                                                                                                                                      
                                      var_row_data,                                                                                                                                                      
                                      var_old_data,                                                                                                                                                   
                                      'public_pim_land_default',                                                                                                                                                
                                      txid_current(),                                                                                                                                               
                                      "public".sym_node_disabled(),                                                                                                                   
                                      null,                                                                                                                                               
                                      CURRENT_TIMESTAMP                                                                                                                
                                    );                                                                                                                                                                 
                                  end if;                                                                                                                                                              
                                  end if;                                                                                                                                                              
                                                                                                                                                                               
                                  return null;                                                                                                                                                         
                                end;
$fun$;

