CREATE FUNCTION save_account_complication(xid integer, xaccountid integer, xcompid integer, xcompyear integer, xcomatypeid integer, xaccidentcount integer, xstageid integer, xisvitrectomy boolean, xislaser boolean, xisantivegf boolean, xisblindness boolean, xisglaucoma boolean, xhbpstagebyskfid integer, xhbpstagebyalbid integer, xhbpc5treatid integer, xsclerosistypeid integer, xstenocardiatypeid integer, xinfarctiontypeid integer, xnyhaclassid integer, xcerebroaccidenttypeid integer, xdiabneurotypeid integer, xarterialdegreeid integer, xdiabfoottypeid integer, xisdiagwithdrawn boolean, xwithdrawnyear integer, xamputationtypeid integer, xosteoporosistypeid integer, xlocalization text, xhyperparattypeid integer, xanemiatypeid integer, xisartifakia boolean)
  RETURNS integer
LANGUAGE plpgsql
AS $$
DECLARE
  _id INTEGER;
BEGIN
  _id = xid;

  IF (_id IS NULL)
  THEN
    INSERT INTO d_accounting.account_complication (id, account_id, comp_id, comp_year, coma_type_id, accident_count, stage_id, is_vitrectomy, is_laser, is_antivegf,
                                                   is_blindness, is_glaucoma, hbp_by_skf_id, hbp_by_alb_id, hbp_c5_treat_id, sclerosis_type_id, stenocardia_type_id,
                                                   infarction_type_id, nyha_class_id, cerebro_accident_type_id, diab_neuro_type_id, arterial_degree_id, diab_foot_type_id,
                                                   is_diag_withdrawn, withdrawn_year, amputation_type_id, osteoporosis_type_id, localization, hyperparat_type_id, anemia_type_id, is_artifakia)
    VALUES
      (nextval('d_accounting.account_complication_seq'), xAccountId, xCompId, xCompYear, xComaTypeId, xAccidentCount,
                                                         xStageId, xIsVitrectomy, xIsLaser, xIsAntivegf,
                                                         xIsBlindness, xIsGlaucoma, xHbpStageBySkfId, xHbpStageByAlbId,
                                                                       xHbpC5TreatId, xSclerosisTypeId,
                                                                       xStenocardiaTypeId,
                                                                       xInfarctionTypeId, xNyhaClassId,
                                                                       xCerebroAccidentTypeId, xDiabNeuroTypeId,
        xArterialDegreeId, xDiabFootTypeId,
        xIsDiagWithdrawn, xWithdrawnYear, xAmputationTypeId, xOsteoporosisTypeId, xLocalization, xHyperparatTypeId,
        xAnemiaTypeId, xIsArtifakia)
    RETURNING id
      INTO _id;
  ELSE
    UPDATE d_accounting.account_complication
    SET comp_id                = xCompId, comp_year = xCompYear, coma_type_id = xComaTypeId,
      accident_count           = xAccidentCount,
      stage_id                 = xStageId,
      is_vitrectomy            = xIsVitrectomy, is_laser = xIsLaser, is_antivegf = xIsAntivegf,
      is_blindness             = xIsBlindness, is_glaucoma = xIsGlaucoma,
      hbp_by_skf_id            = xHbpStageBySkfId, hbp_by_alb_id = xHbpStageByAlbId,
      hbp_c5_treat_id          = xHbpC5TreatId, sclerosis_type_id = xSclerosisTypeId,
      stenocardia_type_id      = xStenocardiaTypeId,
      infarction_type_id       = xInfarctionTypeId, nyha_class_id = xNyhaClassId,
      cerebro_accident_type_id = xCerebroAccidentTypeId, diab_neuro_type_id = xDiabNeuroTypeId,
      arterial_degree_id       = xArterialDegreeId, diab_foot_type_id = xDiabFootTypeId,
      is_diag_withdrawn        = xIsDiagWithdrawn, withdrawn_year = xWithdrawnYear,
      amputation_type_id       = xAmputationTypeId,
      osteoporosis_type_id     = xOsteoporosisTypeId, localization = xLocalization,
      hyperparat_type_id       = xHyperparatTypeId, anemia_type_id = xAnemiaTypeId, is_artifakia = xIsArtifakia
    WHERE id = _id;
  END IF;

  RETURN _id;
END;
$$;

