CREATE FUNCTION updateorphansbeforeresult(xid integer, xhg integer, xrec character varying, xav boolean, xvm integer, xvmv integer, xghpe integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
    i integer;
    vacid integer;
  begin
    IF (select count(id) from disp.md_disp_orphans_result where id = xid) = 0 THEN
      i = xid;
      insert into disp.md_disp_orphans_result (id, health_group_id, vac_id, recommendation, is_after, health_group_physical_education_id)
        values (i, xhg, vacid, xrec, FALSE, xghpe);
    ELSE
      update disp.md_disp_orphans_result set health_group_id = xhg, recommendation = xrec, is_after = FALSE, health_group_physical_education_id = xghpe
        where id = xid;
      --update disp.md_disp_orphans_vac_patient set already_vac = xav, vac_mode_id = xvm, vac_mode_value_id = CASE WHEN xvm=1 THEN NULL ELSE xvmv END
      --  where id = (select vac_id from disp.md_disp_orphans_result where id = xid);
    END IF;
    return 1;
    end;
$$;

