CREATE FUNCTION create_refusal_decree1788(case_id_i integer, cert_num_i character varying, clinic_id_i integer, creation_date_i character varying, empl_issued_id_i integer, patient_id_i integer, receiver_id_i integer, remark_i character varying)
  RETURNS integer
LANGUAGE plpgsql
AS $$
DECLARE
  cert_id_l INTEGER;
BEGIN
  INSERT INTO billing.services_cost_certificate (
    case_id, clinic_id, creation_date, employee_issued_id, number, patient_id, receiver_id, refused, remark)
  VALUES (
    case_id_i, clinic_id_i, to_date(creation_date_i, 'DD.MM.YYYY'), empl_issued_id_i, cert_num_i, patient_id_i, receiver_id_i, true, remark_i)
  RETURNING id
    INTO cert_id_l;
  RETURN cert_id_l;
END;
$$;

