CREATE FUNCTION fsym_on_u_for_pblc_ddrss_lmnt_mngrp()
  RETURNS trigger
LANGUAGE plpgsql
AS $fun$
declare var_row_data text; 
                                declare var_old_data text; 
                                begin
                                   
                                  if 1=1 and "public".sym_triggers_disabled() = 0 then                                                                                                 
                                    var_row_data := 
          case when new."id" is null then '' else '"' || cast(cast(new."id" as numeric) as varchar) || '"' end||','||
          case when new."name" is null then '' else '"' || replace(replace(cast(new."name" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."display_format_id" is null then '' else '"' || cast(cast(new."display_format_id" as numeric) as varchar) || '"' end||','||
          case when new."level_id" is null then '' else '"' || cast(cast(new."level_id" as numeric) as varchar) || '"' end||','||
          case when new."parent_id" is null then '' else '"' || cast(cast(new."parent_id" as numeric) as varchar) || '"' end||','||
          case when new."type_id" is null then '' else '"' || cast(cast(new."type_id" as numeric) as varchar) || '"' end; 
                                    var_old_data := 
          case when old."id" is null then '' else '"' || cast(cast(old."id" as numeric) as varchar) || '"' end||','||
          case when old."name" is null then '' else '"' || replace(replace(cast(old."name" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when old."display_format_id" is null then '' else '"' || cast(cast(old."display_format_id" as numeric) as varchar) || '"' end||','||
          case when old."level_id" is null then '' else '"' || cast(cast(old."level_id" as numeric) as varchar) || '"' end||','||
          case when old."parent_id" is null then '' else '"' || cast(cast(old."parent_id" as numeric) as varchar) || '"' end||','||
          case when old."type_id" is null then '' else '"' || cast(cast(old."type_id" as numeric) as varchar) || '"' end; 
                                    if 1=1 then 
                                    insert into "public".sym_data                                                                                                                     
                                    (table_name, event_type, trigger_hist_id, pk_data, row_data, old_data, channel_id, transaction_id, source_node_id, external_data, create_time)                     
                                    values(                                                                                                                                                            
                                      'address_element',                                                                                                                                            
                                      'U',                                                                                                                                                             
                                      48,                                                                                                                                             
                                      
          case when old."id" is null then '' else '"' || cast(cast(old."id" as numeric) as varchar) || '"' end,                                                                                                                                                      
                                      var_row_data,                                                                                                                                                      
                                      var_old_data,                                                                                                                                                   
                                      'public_address_element_default',                                                                                                                                                
                                      txid_current(),                                                                                                                                               
                                      "public".sym_node_disabled(),                                                                                                                   
                                      null,                                                                                                                                               
                                      CURRENT_TIMESTAMP                                                                                                                
                                    );                                                                                                                                                                 
                                  end if;                                                                                                                                                              
                                  end if;                                                                                                                                                              
                                                                                                                                                                               
                                  return null;                                                                                                                                                         
                                end;
$fun$;

