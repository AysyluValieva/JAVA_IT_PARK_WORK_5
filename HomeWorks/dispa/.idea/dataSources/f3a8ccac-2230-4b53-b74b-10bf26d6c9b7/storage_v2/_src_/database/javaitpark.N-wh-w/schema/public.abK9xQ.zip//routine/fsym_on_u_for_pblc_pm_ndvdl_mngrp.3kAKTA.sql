CREATE FUNCTION fsym_on_u_for_pblc_pm_ndvdl_mngrp()
  RETURNS trigger
LANGUAGE plpgsql
AS $fun$
declare var_row_data text; 
                                declare var_old_data text; 
                                begin
                                   
                                  if 1=1 and "public".sym_triggers_disabled() = 0 then                                                                                                 
                                    var_row_data := 
          case when new."id" is null then '' else '"' || cast(cast(new."id" as numeric) as varchar) || '"' end||','||
          case when new."birth_dt" is null then '' else '"' || to_char(new."birth_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when new."death_dt" is null then '' else '"' || to_char(new."death_dt", 'YYYY-MM-DD HH24:MI:SS.US') || '"' end||','||
          case when new."has_citizenship" is null then '' when new."has_citizenship" then '"1"' else '"0"' end||','||
          case when new."name" is null then '' else '"' || replace(replace(cast(new."name" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."patr_name" is null then '' else '"' || replace(replace(cast(new."patr_name" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."surname" is null then '' else '"' || replace(replace(cast(new."surname" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."gender_id" is null then '' else '"' || cast(cast(new."gender_id" as numeric) as varchar) || '"' end||','||
          case when new."nationality_id" is null then '' else '"' || cast(cast(new."nationality_id" as numeric) as varchar) || '"' end||','||
          case when new."list_identity_doc" is null then '' else '"' || replace(replace(cast(new."list_identity_doc" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."list_oms_doc" is null then '' else '"' || replace(replace(cast(new."list_oms_doc" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."list_job_org" is null then '' else '"' || replace(replace(cast(new."list_job_org" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."list_reg_name" is null then '' else '"' || replace(replace(cast(new."list_reg_name" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."list_snils" is null then '' else '"' || replace(replace(cast(new."list_snils" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."list_uid" is null then '' else '"' || replace(replace(cast(new."list_uid" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."birth_place" is null then '' else '"' || replace(replace(cast(new."birth_place" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."age_year" is null then '' else '"' || cast(cast(new."age_year" as numeric) as varchar) || '"' end||','||
          case when new."age_month" is null then '' else '"' || cast(cast(new."age_month" as numeric) as varchar) || '"' end||','||
          case when new."age_day" is null then '' else '"' || cast(cast(new."age_day" as numeric) as varchar) || '"' end||','||
          case when new."list_main_contact" is null then '' else '"' || replace(replace(cast(new."list_main_contact" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end; 
                                    var_old_data := 
          case when old."id" is null then '' else '"' || cast(cast(old."id" as numeric) as varchar) || '"' end||','||
          case when old."birth_dt" is null then '' else '"' || to_char(old."birth_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when old."death_dt" is null then '' else '"' || to_char(old."death_dt", 'YYYY-MM-DD HH24:MI:SS.US') || '"' end||','||
          case when old."has_citizenship" is null then '' when old."has_citizenship" then '"1"' else '"0"' end||','||
          case when old."name" is null then '' else '"' || replace(replace(cast(old."name" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when old."patr_name" is null then '' else '"' || replace(replace(cast(old."patr_name" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when old."surname" is null then '' else '"' || replace(replace(cast(old."surname" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when old."gender_id" is null then '' else '"' || cast(cast(old."gender_id" as numeric) as varchar) || '"' end||','||
          case when old."nationality_id" is null then '' else '"' || cast(cast(old."nationality_id" as numeric) as varchar) || '"' end||','||
          case when old."list_identity_doc" is null then '' else '"' || replace(replace(cast(old."list_identity_doc" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when old."list_oms_doc" is null then '' else '"' || replace(replace(cast(old."list_oms_doc" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when old."list_job_org" is null then '' else '"' || replace(replace(cast(old."list_job_org" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when old."list_reg_name" is null then '' else '"' || replace(replace(cast(old."list_reg_name" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when old."list_snils" is null then '' else '"' || replace(replace(cast(old."list_snils" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when old."list_uid" is null then '' else '"' || replace(replace(cast(old."list_uid" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when old."birth_place" is null then '' else '"' || replace(replace(cast(old."birth_place" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when old."age_year" is null then '' else '"' || cast(cast(old."age_year" as numeric) as varchar) || '"' end||','||
          case when old."age_month" is null then '' else '"' || cast(cast(old."age_month" as numeric) as varchar) || '"' end||','||
          case when old."age_day" is null then '' else '"' || cast(cast(old."age_day" as numeric) as varchar) || '"' end||','||
          case when old."list_main_contact" is null then '' else '"' || replace(replace(cast(old."list_main_contact" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end; 
                                    if 1=1 then 
                                    insert into "public".sym_data                                                                                                                     
                                    (table_name, event_type, trigger_hist_id, pk_data, row_data, old_data, channel_id, transaction_id, source_node_id, external_data, create_time)                     
                                    values(                                                                                                                                                            
                                      'pim_individual',                                                                                                                                            
                                      'U',                                                                                                                                                             
                                      22,                                                                                                                                             
                                      
          case when old."id" is null then '' else '"' || cast(cast(old."id" as numeric) as varchar) || '"' end,                                                                                                                                                      
                                      var_row_data,                                                                                                                                                      
                                      var_old_data,                                                                                                                                                   
                                      'public_pim_individual_default',                                                                                                                                                
                                      txid_current(),                                                                                                                                               
                                      "public".sym_node_disabled(),                                                                                                                   
                                      null,                                                                                                                                               
                                      CURRENT_TIMESTAMP                                                                                                                
                                    );                                                                                                                                                                 
                                  end if;                                                                                                                                                              
                                  end if;                                                                                                                                                              
                                                                                                                                                                               
                                  return null;                                                                                                                                                         
                                end;
$fun$;

