CREATE FUNCTION migration_one_table()
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
  _table_id INT;
BEGIN
  SELECT id
  INTO _table_id
  FROM audit.migration_table
  WHERE status_id IN (SELECT id
                      FROM audit.migration_table_status
                      WHERE code IN ('NOT_PROCESSED', 'ERROR')
  )
  ORDER BY count_row
  LIMIT 1;

  IF _table_id ISNULL THEN RAISE EXCEPTION 'Migration table not found'; END IF;

  EXECUTE audit.migration_table_by_id(_table_id);
END;
$$;

