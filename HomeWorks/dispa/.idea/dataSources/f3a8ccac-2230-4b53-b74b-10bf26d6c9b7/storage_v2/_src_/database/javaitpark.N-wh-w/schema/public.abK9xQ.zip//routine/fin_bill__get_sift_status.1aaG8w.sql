CREATE FUNCTION fin_bill__get_sift_status(sift_code character varying)
  RETURNS boolean
STRICT
LANGUAGE plpgsql
AS $$
BEGIN
    RETURN (SELECT is_enabled FROM fin_bill_sift_list WHERE upper (code) = upper (sift_code))
    ;
END;
$$;

