CREATE FUNCTION attach_diagnosis()
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
          rec record;
          serviceid integer;
        begin
	for rec in
	  select ds.id, mep.id as mepid, mes.service_id as old_service from mc_diagnosis mc
	  join disp.md_dispr_diagnosis_service ds on ds.diagnosis_id = mc.id
	  join disp.md_event_patient mep on mep.case_id = mc.id
	  join disp.md_event me on me.id = mep.event_id
	  join disp.md_event_type met on me.event_type = met.id
	  join disp.md_event_service mes on mes.event_id = mep.event_id and mes.service_id = ds.service_id
	  join disp.md_event_service_patient mesp on mesp.event_patient_id = mep.id and mesp.service_id = mes.id
	  where mesp.status not in (3,4) and met.code in ('ДВ1', 'ДВ2')
	  union all
	  select ds.id, mep.id as mepid, null as old_service from  mc_diagnosis mc
	  join disp.md_dispr_diagnosis_service ds on ds.diagnosis_id = mc.id
	  join disp.md_event_patient mep on mep.case_id = mc.id
	  join disp.md_event me on me.id = mep.event_id
	  join disp.md_event_type met on me.event_type = met.id
	  where met.code in ('ДВ1', 'ДВ2') and ds.service_id is null
	loop
	  select mes.service_id into serviceid from disp.md_event_patient mep
	  join disp.md_event_service mes on mes.event_id = mep.event_id
	  join disp.md_event_service_patient mesp on mesp.event_patient_id = mep.id and mesp.service_id = mes.id
	  join disp.sr_srv_service_document sssd on sssd.service_id = mes.service_id
	  join md_norm_document_service mnds on mnds.id = sssd.document_service_id
	  where mnds.code = 'Д1.18' and mep.id = rec.mepid and mesp.status in (3,4);

	  if (serviceid is not null) then
	    update disp.md_dispr_diagnosis_service set service_id = serviceid
	    where id = rec.id;
	    insert into disp.for_attach_diagnosis (mep_id, diagnosis_service_id, old_service_id, new_service_id) values (rec.mepid, rec.id, rec.old_service, serviceid);
	  end if;
	end loop;

        end;
$$;

