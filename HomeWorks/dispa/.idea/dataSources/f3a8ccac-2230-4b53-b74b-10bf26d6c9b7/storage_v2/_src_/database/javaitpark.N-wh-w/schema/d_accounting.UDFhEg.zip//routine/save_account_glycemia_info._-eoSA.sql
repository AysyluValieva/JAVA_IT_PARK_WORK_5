CREATE FUNCTION save_account_glycemia_info(xid integer, xaccountid integer, xselfcontrol integer, xmainglucometerid integer, xsecondglucometerid integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
DECLARE
  _id INTEGER;
BEGIN
  _id = xid;

  IF (_id IS NULL)
  THEN
    INSERT INTO d_accounting.account_glycemia_info (id,account_id, self_control, main_glucometer_id, secondary_glucometer_id)
    VALUES (nextval('d_accounting.account_glycemia_info_seq'),xaccountId, xselfControl, xmainGlucometerId, xsecondGlucometerId)
    RETURNING id
      INTO _id;
  ELSE
    UPDATE d_accounting.account_glycemia_info
    SET self_control          = xselfControl, main_glucometer_id = xmainGlucometerId,
      secondary_glucometer_id = xsecondGlucometerId
    WHERE id = _id;
  END IF;

  IF (xselfControl <> 1)
  THEN
    UPDATE d_accounting.account_glycemia_info
    SET main_glucometer_id = NULL, secondary_glucometer_id = NULL
    WHERE id = xid;
  END IF;

  RETURN _id;
END;
$$;

