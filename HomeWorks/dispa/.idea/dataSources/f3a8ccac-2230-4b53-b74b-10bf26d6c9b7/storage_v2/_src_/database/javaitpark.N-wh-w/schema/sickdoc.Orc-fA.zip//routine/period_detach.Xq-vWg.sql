CREATE FUNCTION period_detach(p_id integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
  l_sickdoc_id INTEGER;
BEGIN

  SELECT sickdoc_id
  FROM sickdoc.period
  WHERE id = p_id
  INTO l_sickdoc_id;

  IF (SELECT count(1)
      FROM sickdoc.period
      WHERE sickdoc_id = l_sickdoc_id) = 1
  THEN
    RAISE 'Нельзя удалять единственный период у ЛН';
  END IF;

  DELETE FROM sickdoc.period
  WHERE id = p_id;

  PERFORM sickdoc.sickdoc_calculate_and_set_range_dates_and_duration(l_sickdoc_id);

END;
$$;

