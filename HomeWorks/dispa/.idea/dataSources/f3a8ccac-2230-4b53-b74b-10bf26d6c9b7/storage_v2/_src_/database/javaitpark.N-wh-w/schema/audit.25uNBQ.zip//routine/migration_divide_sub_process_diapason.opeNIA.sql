CREATE FUNCTION migration_divide_sub_process_diapason(_current_sub_process_id integer, _process_id integer, _table_name character varying, _from_id bigint, _to_id bigint, _count_row bigint)
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
  _row_in_first_diapason  BIGINT;
  _row_in_second_diapason BIGINT;
  _medium                 BIGINT;
BEGIN
  DELETE FROM audit.migration_batch_sub_process
  WHERE id = _current_sub_process_id;

  _medium = trunc((_from_id + _to_id) / 2);

  _row_in_first_diapason = audit.migration_get_count_row_by_id_diapason(_table_name, _from_id, _medium);

  IF _count_row ISNULL
  THEN
    _row_in_second_diapason = audit.migration_get_count_row_by_id_diapason(_table_name, _medium + 1, _to_id);
  ELSE
    _row_in_second_diapason = _count_row - _row_in_first_diapason;
  END IF;

  INSERT INTO audit.migration_batch_sub_process (process_id, from_row_id, to_row_id, count_row, is_executed)
  VALUES
    (_process_id, _from_id, _medium, _row_in_first_diapason, _row_in_first_diapason = 0),
    (_process_id, _medium + 1, _to_id, _row_in_second_diapason, _row_in_second_diapason = 0);
END;
$$;

