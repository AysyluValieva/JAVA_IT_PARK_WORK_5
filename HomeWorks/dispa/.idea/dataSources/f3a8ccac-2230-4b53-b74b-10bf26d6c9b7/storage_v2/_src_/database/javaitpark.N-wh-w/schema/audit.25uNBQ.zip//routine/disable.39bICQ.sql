CREATE FUNCTION disable(value boolean)
  RETURNS void
LANGUAGE plpgsql
AS $$
BEGIN
    PERFORM disable_trigger($1, 'audit_trigger_full');
  END;
$$;

