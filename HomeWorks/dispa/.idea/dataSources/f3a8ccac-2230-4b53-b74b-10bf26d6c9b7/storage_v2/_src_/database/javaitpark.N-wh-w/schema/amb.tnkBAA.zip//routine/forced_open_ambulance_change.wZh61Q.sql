CREATE FUNCTION forced_open_ambulance_change(xclin integer, xdep integer)
  RETURNS date
LANGUAGE plpgsql
AS $$
declare
                xset integer;
                xchange integer;
                yesterdaychange record;

                xroute integer;
                xchbegin TIME WITHOUT TIME ZONE;
                xchperiod INTERVAL;

                xtypeNum integer;
                xnumid integer;

                xval integer;
              begin
                select into xset id from amb.md_ambulance_change_setting where clinic_id = xclin and (department_id is null or department_id = xdep) order by department_id limit 1;
                select into xroute,xchbegin,xchperiod route_id,change_begin,change_period from amb.md_ambulance_change_setting where id = xset;

                xchange:= amb.insert_into_md_ambulance_change (cast(now() as date),xclin,xdep);
                -- возможно нужно сделать условие, что yt ghjcnj состояние смены = 1, а <> 2
                if exists(select id from amb.md_ambulance_change where clinic_id = xclin and COALESCE(department_id, 0) = COALESCE(xdep, 0) and ((from_data = cast(now() - cast('1 day' as interval) as date)) or (state = 1)) )
                  then
                    for yesterdaychange in select id from amb.md_ambulance_change where clinic_id = xclin and COALESCE(department_id, 0) = COALESCE(xdep, 0) and ((from_data = cast(now() - cast('1 day' as interval) as date)) or (state = 1))
                        loop
                            update amb.md_ambulance_change set state = 2 where id = yesterdaychange.id;
                        end loop;
                  end if;
                  update amb.md_ambulance_change set state = 1 where id = xchange;
                --execute amb.zeroing_number(xclin);
                select into xtypeNum,xnumid mans.type_num,mans.id from amb.md_ambulance_numb_setting mans left join amb.md_ambulance_numbers man on mans.id = man.numb_id
                        where mans.clinic_id = xclin;
                    if not exists (select * from amb.md_ambulance_numbers man left join amb.md_ambulance_numb_setting mans on mans.id = man.numb_id
                        where mans.clinic_id = xclin and man.change_id = xchange and man.dep_id = xdep)
                    THEN
                      if xtypeNum = 1
                        then
                            xval =0;
                            /*insert into amb.md_ambulance_numbers (change_id,numb_id, value,dep_id)
                                values (xchange,xnumid,0,xdep);*/
                        end if;
                      if (xtypeNum = 2)
                        then
                          if (EXTRACT(dow FROM now()) = 1)
                            then
                                xval = 0;
                            else
                                xval = (select value from amb.md_ambulance_numbers man left join amb.md_ambulance_numb_setting mans on mans.id = man.numb_id
                                            where mans.clinic_id = xclin and man.dep_id = xdep order by man.id desc limit 1);
                          end if;
                        end if;
                      if (xtypeNum = 3)
                        then
                          if (EXTRACT(day FROM now()) = 1)
                            then
                                xval = 0;
                            else
                                xval = (select value from amb.md_ambulance_numbers man left join amb.md_ambulance_numb_setting mans on mans.id = man.numb_id
                                            where mans.clinic_id = xclin and man.dep_id = xdep order by man.id desc limit 1);
                          end if;
                        end if;
                      if (xtypeNum = 4)
                        then
                          if (EXTRACT(doy FROM now()) = 1)
                            then
                                xval = 0;
                            else
                                xval = (select value from amb.md_ambulance_numbers man left join amb.md_ambulance_numb_setting mans on mans.id = man.numb_id
                                            where mans.clinic_id = xclin and man.dep_id = xdep order by man.id desc limit 1);
                          end if;
                        end if;
                      insert into amb.md_ambulance_numbers (change_id,numb_id, value,dep_id)
                                    values (xchange,xnumid,xval,xdep);
                    END if;

                return cast(now() as date);
              end;
$$;

