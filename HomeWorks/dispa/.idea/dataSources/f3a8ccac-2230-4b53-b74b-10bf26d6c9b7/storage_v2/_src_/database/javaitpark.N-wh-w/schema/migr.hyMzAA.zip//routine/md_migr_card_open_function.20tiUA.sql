CREATE FUNCTION md_migr_card_open_function(xcardid integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
begin
	      update migr.md_migr_card set status_id = 1, close_reason_id = null where id = xcardid;
            end;
$$;

