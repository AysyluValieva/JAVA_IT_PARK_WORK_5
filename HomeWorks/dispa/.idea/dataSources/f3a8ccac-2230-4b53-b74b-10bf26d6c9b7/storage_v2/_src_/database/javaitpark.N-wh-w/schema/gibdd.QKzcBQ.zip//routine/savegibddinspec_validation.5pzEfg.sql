CREATE FUNCTION savegibddinspec_validation(xepid integer, xservice integer, xemplpos_id integer)
  RETURNS boolean
LANGUAGE plpgsql
AS $$
declare
          orgId integer;
          xresource integer;

        begin

          select e.org_id into orgId from disp.md_event e join disp.md_event_patient ep on e.id = ep.event_id where ep.id = xepid;

          select mes.resource_id into xresource from disp.md_event_service mes join disp.md_event_service_patient mesp on mes.id = mesp.service_id where mesp.event_patient_id = xepid and mes.service_id = xservice;

          if (xresource is null) then
            select rg.id into xresource from sr_res_group rg join sr_res_group_relationship rgr on rgr.group_id = rg.id
                join pim_employee_position_resource epr on epr.id = rgr.resource_id
                join pim_employee_position ep on ep.id = epr.employee_position_id
                join sr_res_group_service srgs on rg.id = srgs.group_id
                where ep.id = xemplPos_id and rg.org_id = orgId
                and srgs.srv_type_id = xservice and rg.is_system = false limit 1;
          end if;

          if (xresource is null) then
            select case (select count(1)
                from SR_RES_GROUP_SERVICE srgs
                join SR_RES_GROUP srg on srg.id = srgs.group_id
                where srg.is_system = false
                and srg.org_id = orgId
                and srgs.srv_type_id = xservice)
              when 1 then
                (select srg.id
                from SR_RES_GROUP_SERVICE srgs
                join SR_RES_GROUP srg on srg.id = srgs.group_id
                where srg.is_system = false
                and srg.org_id = orgId
                and srgs.srv_type_id = xservice)
              else null end into xresource;
          end if;

          if (xresource is null) then
            return false;
          else
            return true;
          end if;
        end;
$$;

