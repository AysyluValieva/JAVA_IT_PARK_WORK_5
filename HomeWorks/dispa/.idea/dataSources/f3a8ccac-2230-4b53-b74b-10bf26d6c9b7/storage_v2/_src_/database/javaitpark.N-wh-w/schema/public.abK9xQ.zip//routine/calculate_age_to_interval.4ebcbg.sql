CREATE FUNCTION calculate_age_to_interval(birthdate date, deathdate date, ageyear integer, agemonth integer, ageday integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
DECLARE
  INT_RESULT integer;
  text_result varchar;
  result date;
BEGIN

  IF (birthDate IS NOT NULL)
    THEN
          result = birthdate;
  ELSIF (ageYear IS NOT NULL OR ageMonth IS NOT NULL OR ageDay IS NOT NULL)
    THEN
      IF(ageYear IS NOT NULL)
        THEN
          IF agemonth IS NOT NULL
            THEN
              text_result = cast(ageyear as varchar)||'-'||cast(agemonth as varchar);
          ELSE text_result = cast(ageyear as varchar)||'Y';
          END IF;
      ELSEIF (ageMonth IS NOT NULL)
          THEN
            text_result = '0-'||cast(agemonth as varchar);
        END IF;

      IF(ageDay IS NOT NULL)
        THEN
          text_result = text_result || ' ' ||cast(ageday as varchar)||'D';
      END IF;
      result=(current_date - cast(text_result as interval))::date;
  ELSE result = null;
  END IF;

  IF (deathdate is not null)
    then INT_RESULT=deathdate-result;
  ELSE
    INT_RESULT=CURRENT_DATE-result;
  END IF;
  RETURN INT_RESULT;
END;
$$;

