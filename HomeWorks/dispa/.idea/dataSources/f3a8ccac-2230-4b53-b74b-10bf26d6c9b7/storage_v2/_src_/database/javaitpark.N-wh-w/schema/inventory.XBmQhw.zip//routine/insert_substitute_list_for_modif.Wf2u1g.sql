CREATE FUNCTION insert_substitute_list_for_modif(modifid integer, substituteid integer, unitid integer, conv_rate_1 numeric)
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
conv_rate_2 numeric;
modif_subst_id integer;
subst_modif_id integer;
BEGIN
      conv_rate_2=1/conv_rate_1;
      select id from inventory.modif_substitute into modif_subst_id where modif_id=modifId and substitute_id=substituteId;
      if(modif_subst_id is null) then
        insert into inventory.modif_substitute values(nextval('inventory.modif_substitute_seq'), modifId, substituteId,conv_rate_1,unitId);
      else
         update inventory.modif_substitute set unit_id= unitId, conversion_rate=conv_rate_1 where id=modif_subst_id;
      end if;

      select id from inventory.modif_substitute into subst_modif_id  where modif_id=substituteId and substitute_id=modifId;
      if(subst_modif_id is null) then
         insert into inventory.modif_substitute values(nextval('inventory.modif_substitute_seq'),substituteId,modifId,conv_rate_2,unitId);
      else
         update inventory.modif_substitute set unit_id= unitId, conversion_rate=conv_rate_2 where id=subst_modif_id;
      end if;
END;
$$;

