CREATE FUNCTION apdam_validate_input_params(in_md_clinic_id integer, in_check_district boolean, in_type_id integer, in_update_type integer, in_detachment_type integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
BEGIN
  IF in_md_clinic_id ISNULL
  THEN RAISE EXCEPTION 'Идентификатор МО не задан'; END IF;
  IF in_check_district ISNULL
  THEN RAISE EXCEPTION 'Учет участков подразделений не задан'; END IF;
  IF in_type_id ISNULL
  THEN RAISE EXCEPTION 'Вид прикрепления не задан'; END IF;
  IF in_update_type ISNULL
  THEN RAISE EXCEPTION 'Порядок обновления участков не задан'; END IF;
  IF in_update_type < 0 OR in_update_type > 2
  THEN RAISE EXCEPTION 'Порядок обновления участков задан некорректно'; END IF;
  IF in_detachment_type ISNULL
  THEN RAISE EXCEPTION 'Порядок открепления не задан'; END IF;
  IF in_detachment_type < 0 OR in_detachment_type > 2
  THEN RAISE EXCEPTION 'Порядок открепления участков задан некорректно'; END IF;
END;
$$;

