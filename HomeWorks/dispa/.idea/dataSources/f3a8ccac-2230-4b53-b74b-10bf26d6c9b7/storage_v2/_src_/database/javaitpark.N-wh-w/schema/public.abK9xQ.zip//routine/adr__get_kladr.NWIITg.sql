CREATE FUNCTION adr__get_kladr(adr_id integer, lvl_id integer)
  RETURNS text
STRICT
LANGUAGE plpgsql
AS $$
DECLARE
                 return_kladr TEXT;
              BEGIN
                 SELECT
                  ac.value
                 FROM address_code ac
                 INNER JOIN address_element_data aed
                  ON ac.element_id = aed.id
                 INNER JOIN address_element ae
                  ON ae.id=aed.id
                 INNER JOIN address_element_type aet
                  ON ae.type_id=aet.id
                 WHERE aed.path @> (SELECT path
                  FROM address_element_data
                 WHERE id = adr_id) and book_id=1 and ae.level_id=lvl_id
                 INTO return_kladr;
                 RETURN return_kladr;
              END;
$$;

