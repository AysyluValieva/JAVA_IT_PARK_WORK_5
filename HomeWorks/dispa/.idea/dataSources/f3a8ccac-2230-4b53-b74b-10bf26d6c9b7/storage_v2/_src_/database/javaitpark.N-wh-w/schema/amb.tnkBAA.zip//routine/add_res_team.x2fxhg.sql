CREATE FUNCTION add_res_team(xorg integer, xdep integer, xname character varying, xbdate date, xedate date, xsetting integer, xkind integer, xjob integer, xtype integer, xradio character varying, xprof integer, xmedprof integer, xbtime time without time zone, xetime time without time zone)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
							xresid integer;
							calnotid integer;
							sr_id integer;
						  begin
							xresid = nextval('sr_res_group_seq');
							insert into sr_res_group (id,org_id,department_id,name, bdate,edate,is_system)
												values (xresid,xorg,xdep,xname,xbdate,xedate,false);
							insert into public.md_res_group (id) VALUES(xresid);
							if xmedprof is not null
								then
								  insert into public.sr_res_group_profile(id,res_group_id,profile_id)
									  values(nextval('sr_res_group_profile_seq'),xresid,xmedprof);
							end if;
							sr_id = nextval('amb.sr_res_team_id_seq');
							insert into amb.sr_res_team (id, resource_id,team_template_id,team_kind_id,job_kind_id,team_type_id,radio_code,btime,etime)
								VALUES(sr_id,xresid,xsetting,xkind,xjob,xtype,xradio,xbtime,xetime);
							if xprof is not null
							  then
								insert into public.md_resgroup_amb_profile (id,profile_id) values (xresid,xprof);
							end if;
							return sr_id;
						  end;

$$;

