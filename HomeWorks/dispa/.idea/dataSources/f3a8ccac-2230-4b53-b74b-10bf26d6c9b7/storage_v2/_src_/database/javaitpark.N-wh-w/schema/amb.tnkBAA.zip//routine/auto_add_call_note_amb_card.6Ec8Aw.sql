CREATE FUNCTION auto_add_call_note_amb_card(xcall integer, xreason integer, xdiagreason integer, xreg integer, xorg integer, xdep integer, xdiag integer, xpsycho boolean)
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
    i integer;
    ps integer;
    note integer;
    xcnote integer;
    cnote integer;
    danger boolean;
    calnotid integer;
    j integer;
	begin
    	/*автодобавление отметок пожар, криминал, ДТП по поводу*/
		SELECT INTO note mara.note_id from amb.md_ambulance_caller_reason cr
               left join amb.md_ambulance_call_reason macr on cr.call_reason_id = macr.id
               left join amb.md_ambulance_reason_accident mara on cr.reason_accident_id = mara.id
               where cr.id = xreason;

        if (note is NOT NULL) then
            if exists (select * from amb.md_ambulance_call_note where call_id = xcall and (note_id = 3 or note_id = 5 or note_id = 6 or note_id = 15) and note_description = 'а/у' and note_type = true and note_active = true)
                then
                select into i note_id from amb.md_ambulance_call_note where call_id = xcall and (note_id = 3 or note_id = 5 or note_id = 6 or note_id = 15) and note_description = 'а/у' and note_type = true and note_active = true;
                cnote = amb.add_call_note (xcall, i, FALSE, NULL,NULL,xreg,NULL);
            end if;
            if exists (select * from amb.md_ambulance_call_note where call_id = xcall and (note_id = note) and note_description = 'р/у' and note_type = true and note_active = true)
            	then
                select into i note_id from amb.md_ambulance_call_note where call_id = xcall and (note_id = note) and note_description = 'р/у' and note_type = true and note_active = true;
                calnotid = amb.add_call_note (xcall, i, FALSE, NULL, NULL, xreg, NULL);
            end if;
               	xcnote = amb.add_call_note (xcall, note, TRUE, NULL,'а/у',xreg,NULL);
        end if;

        /*добавление отметки псих (по наличию галочки на вызове)*/

        -- спорно, так как если уже есть, зачем снимаем и ставим вновь?
        if (xpsycho is TRUE)
        	then
            	if exists (select * from amb.md_ambulance_call_note where call_id = xcall and note_id = 15 and note_type = true and note_active = true)
                        then
                        select into i note_id from amb.md_ambulance_call_note where call_id = xcall and note_id = 15 and note_type = true and note_active = true;
                        cnote = amb.add_call_note (xcall, i, FALSE, NULL,NULL,xreg,NULL);
                    end if;
            	cnote = amb.add_call_note (xcall, 15, TRUE, NULL,'р/у',xreg,NULL);
            else
            -- в таком виде неоткуда брать значение i = note_id
            	--cnote = amb.add_call_note (xcall, i, FALSE, NULL,NULL,xreg,NULL);
            if exists (select * from amb.md_ambulance_call_note where call_id = xcall and note_id = 15 and note_description = 'р/у' and note_type = true and note_active = true)
            	then
                	select into i note_id from amb.md_ambulance_call_note where call_id = xcall and note_id = 15 and note_description = 'р/у' and note_type = true and note_active = true;
                    cnote = amb.add_call_note (xcall, i, FALSE, NULL,NULL,xreg,NULL);
            end if;
        end if;

        /*автодобавление отметки псих по поводу*/
        SELECT INTO ps p.e_code from amb.md_ambulance_caller_reason cr
               left join public.md_profile p on cr.profile_id = p.id
               where cr.id = xreason and p.id = 138;

			if (ps = '72') then
                    if exists (select * from amb.md_ambulance_call_note where call_id = xcall and (note_id = 3 or note_id = 5 or note_id = 6 or note_id = 15) and note_description = 'а/у' and note_type = true and note_active = true)
                        then
                        select into j note_id from amb.md_ambulance_call_note where call_id = xcall and (note_id = 3 or note_id = 5 or note_id = 6 or note_id = 15) and note_description = 'а/у' and note_type = true and note_active = true;
                        cnote = amb.add_call_note (xcall, j, FALSE, NULL, NULL, xreg, NULL);
                    end if;
                    if exists (select * from amb.md_ambulance_call_note where call_id = xcall and (note_id = 15) and note_description = 'р/у' and note_type = true and note_active = true)
            			then
                		select into i note_id from amb.md_ambulance_call_note where call_id = xcall and (note_id = 15) and note_description = 'р/у' and note_type = true and note_active = true;
                		calnotid = amb.add_call_note (xcall, i, FALSE, NULL, NULL, xreg, NULL);
            		end if;
            	xcnote = amb.add_call_note (xcall, 15, TRUE, NULL,'а/у',xreg,NULL);
        	end if;

        if (note is null or ps != '72')
        	then
            	if exists (select * from amb.md_ambulance_call_note where call_id = xcall and (note_id = 3 or note_id = 5 or note_id = 6 or note_id = 15) and note_description = 'а/у' and note_type = true and note_active = true)
            		then
            		select into i note_id from amb.md_ambulance_call_note where call_id = xcall and (note_id = 3 or note_id = 5 or note_id = 6 or note_id = 15) and note_description = 'а/у' and note_type = true and note_active = true;
            		cnote = amb.add_call_note (xcall, i, FALSE, NULL,NULL,xreg,NULL);
            	end if;
        end if;


        /*автодобавление ОПАС*/
        /*if exists (select * from amb.pim_org_dangerous_area da where
            		(da.org_id = xorg and xdep is null and da.dep_id is null)
                    or (da.org_id is null and xorg is null and da.dep_id = xdep)
                    or (da.org_id = xorg and da.dep_id = xdep)) then danger = true;
        end if;

        if (danger is true)
        		then
                	if exists (select * from amb.md_ambulance_call_note where call_id = xcall and (note_id = 12))
                        then
                        select into i note_id from amb.md_ambulance_call_note where call_id = xcall and (note_id = 12);
                        cnote = amb.add_call_note (xcall, i, FALSE, NULL,NULL,xreg,NULL);
                    end if;
                xcnote = amb.add_call_note (xcall, 12, TRUE, NULL,NULL,xreg,NULL);
            	else
                	if exists (select * from amb.md_ambulance_call_note where call_id = xcall and (note_id = 12))
                        then
                        select into i note_id from amb.md_ambulance_call_note where call_id = xcall and (note_id = 12);
                        cnote = amb.add_call_note (xcall, i, FALSE, NULL,NULL,xreg,NULL);
                    end if;
        end if;
        */

        /*автодобавление ПСИХ по диагноз-поводу*/
        if xdiagreason is not null then
            if exists (SELECT * from md_diagnosis where id = xdiagreason and code like ('F%'))
                    then
                        if exists (select * from amb.md_ambulance_call_note where call_id = xcall and (note_id = 15) and note_description = 'а/у' and note_type = true and note_active = true)
                            then
                                select into i note_id from amb.md_ambulance_call_note where call_id = xcall and (note_id = 15) and note_description = 'а/у' and note_type = true and note_active = true;
                                cnote = amb.add_call_note (xcall, i, FALSE, NULL,NULL,xreg,NULL);
                        end if;
                        if exists (select * from amb.md_ambulance_call_note where call_id = xcall and (note_id = 15) and note_description = 'р/у' and note_type = true and note_active = true)
                            then
                            select into i note_id from amb.md_ambulance_call_note where call_id = xcall and (note_id = 15) and note_description = 'р/у' and note_type = true and note_active = true;
                            calnotid = amb.add_call_note (xcall, i, FALSE, NULL, NULL, xreg, NULL);
                        end if;
                    xcnote = amb.add_call_note (xcall, 15, TRUE, NULL,'а/у',xreg,NULL);
                    else
                    if exists (select * from amb.md_ambulance_call_note where call_id = xcall and (note_id = 15) and note_description = 'а/у' and note_type = true and note_active = true)
                            then
                            select into i note_id from amb.md_ambulance_call_note where call_id = xcall and (note_id = 15) and note_description = 'а/у' and note_type = true and note_active = true;
                            cnote = amb.add_call_note (xcall, i, FALSE, NULL,NULL,xreg,NULL);
                    end if;
            end if;
        end if;

        /*автодобавление ПСИХ по диагнозу*/
    	if exists (SELECT * from md_diagnosis where id = xdiag and code like ('F%'))
                then
	                if exists (select * from amb.md_ambulance_call_note where call_id = xcall and (note_id = 15))
                        then
                        	select into i note_id from amb.md_ambulance_call_note where call_id = xcall and (note_id = 15);
                        	cnote = amb.add_call_note (xcall, i, FALSE, NULL,NULL,xreg,NULL);
                    end if;
            	xcnote = amb.add_call_note (xcall, 15, TRUE, NULL,'Диагноз а/у',xreg,NULL);
        end if;

	end;
$$;

