CREATE FUNCTION save_account_registration_info(xid integer, xaccountid integer, xheight integer, xweight integer, xsysbloodpress integer, xdiasbloodpress integer, xglychemoglobin double precision, xcreatinine double precision, xtotalcholesterol double precision, xlowdensitylip double precision, xskfepi double precision)
  RETURNS integer
LANGUAGE plpgsql
AS $$
DECLARE
  _id INTEGER;
BEGIN
  _id = xid;

  IF (_id IS NULL)
  THEN
    INSERT INTO d_accounting.account_registration_info (id, account_id, height, weight, sys_blood_press,
                                                        dias_blood_press, glyc_hemoglobin, creatinine, total_cholesterol, low_density_lipoproteins, skf_epi)
    VALUES (nextval('d_accounting.account_registration_info_seq'), xaccountId, xheight, xweight, xsysBloodPress,
                                                                   xdiasBloodPress,
                                                                   round(cast(xglycHemoglobin AS NUMERIC), 1),
                                                                   round(cast(xcreatinine AS NUMERIC), 2),
                                                                   round(cast(xtotalCholesterol AS NUMERIC), 2),
                                                                   round(cast(xlowDensityLip AS NUMERIC), 2),
                                                                   round(cast(xSKFEPI AS NUMERIC), 2))
    RETURNING id
      INTO _id;
  ELSE
    UPDATE d_accounting.account_registration_info
    SET height                 = xheight, weight = xweight,
      sys_blood_press          = xsysBloodPress,
      dias_blood_press         = xdiasBloodPress, glyc_hemoglobin = round(cast(xglycHemoglobin AS NUMERIC), 1),
      creatinine               = round(cast(xcreatinine AS NUMERIC), 2),
      total_cholesterol        = round(cast(xtotalCholesterol AS NUMERIC), 2),
      low_density_lipoproteins = round(cast(xlowDensityLip AS NUMERIC), 2),
      skf_epi                  = round(cast(xSKFEPI AS NUMERIC), 2)
    WHERE id = _id;
  END IF;

  RETURN _id;
END;
$$;

