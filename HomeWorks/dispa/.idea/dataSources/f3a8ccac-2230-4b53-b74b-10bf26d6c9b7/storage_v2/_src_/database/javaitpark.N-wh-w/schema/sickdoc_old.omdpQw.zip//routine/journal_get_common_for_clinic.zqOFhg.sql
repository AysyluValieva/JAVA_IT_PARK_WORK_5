CREATE FUNCTION journal_get_common_for_clinic(p_clinic_id integer)
  RETURNS integer
IMMUTABLE
LANGUAGE plpgsql
AS $$
BEGIN

  RETURN
  (SELECT id
   FROM sickdoc.journal
   WHERE clinic_id = p_clinic_id AND is_common_for_clinic);

END;
$$;

