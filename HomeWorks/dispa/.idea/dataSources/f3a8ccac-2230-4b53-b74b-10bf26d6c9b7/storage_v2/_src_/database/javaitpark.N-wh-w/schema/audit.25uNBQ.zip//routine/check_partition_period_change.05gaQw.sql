CREATE FUNCTION check_partition_period_change(_table_setting_id integer, _from_partition_period_id integer, _to_partition_period_id integer)
  RETURNS boolean
LANGUAGE plpgsql
AS $$
DECLARE
                  partition_max_size BIGINT;
                  table_name         VARCHAR;
                  cur_table_name     VARCHAR;
                  old_period_code    VARCHAR;
                  new_period_code    VARCHAR;
                  dates              DATE [];
                  start_date         DATE;
                  end_date           DATE;
                  cur_date           DATE;
                  next_date          DATE;
                  result             BOOLEAN;
                  interval_shift     INTEGER;
                BEGIN
                  IF _from_partition_period_id = _to_partition_period_id
                  THEN RETURN TRUE;
                  END IF;

                  SELECT value
                  INTO partition_max_size
                  FROM audit.param_setting
                  WHERE code = 'partition_max_size'
                  LIMIT 1;

                  SELECT concat(t.table_schema, '.', t.table_name)
                  INTO table_name
                  FROM audit.table_setting t
                  WHERE t.id = _table_setting_id
                  LIMIT 1;

                  table_name = replace(table_name, '.', '$');

                  EXECUTE format('SELECT %1$s > count(*) FROM audit."%2$s"', partition_max_size, table_name)
                  INTO result;
                  IF result = TRUE
                  THEN RETURN TRUE; END IF;

                  SELECT lower(code)
                  INTO new_period_code
                  FROM audit.partition_period
                  WHERE id = _to_partition_period_id;

                  IF new_period_code = 'none'
                  THEN
                    RETURN result;
                  END IF;

                  SELECT lower(code)
                  INTO old_period_code
                  FROM audit.partition_period
                  WHERE id = _from_partition_period_id;

                  dates = audit.get_audit_table_aud_when_interval(table_name, old_period_code, new_period_code);
                  start_date = dates[1];
                  end_date = dates[2];

                  cur_date = start_date;
                  IF new_period_code = 'quarter'
                  THEN
                    interval_shift = 3;
                    new_period_code = 'month';
                  ELSE interval_shift = 1;
                  END IF;

                  WHILE cur_date < end_date LOOP
                    EXECUTE
                    format('SELECT DATE ''%1$s'' + interval ''%2$s''', cur_date, concat(interval_shift, ' ',
                        new_period_code))
                    INTO next_date;

                    EXECUTE
                    format('SELECT count(*) < %1$s FROM audit."%2$s" WHERE aud_when >= ''%3$s'' AND aud_when < ''%4$s''',
                           partition_max_size,
                           table_name,
                           cur_date,
                           next_date)
                    INTO result;

                    IF result = FALSE
                    THEN RETURN FALSE; END IF;
                    cur_date = next_date;
                  END LOOP;

                  RETURN TRUE;
                END;
$$;

