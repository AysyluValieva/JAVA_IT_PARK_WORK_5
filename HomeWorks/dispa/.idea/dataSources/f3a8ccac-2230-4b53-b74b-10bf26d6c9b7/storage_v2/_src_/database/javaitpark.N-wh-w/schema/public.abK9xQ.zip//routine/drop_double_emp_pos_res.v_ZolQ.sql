CREATE FUNCTION drop_double_emp_pos_res()
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
    dbls integer[];
    begin
		for dbls in
		SELECT array_agg(id)
		FROM pim_employee_position_resource
		group by employee_position_id
		having count(id) > 1
		loop
			for i in 2..array_length(dbls,1)
			loop
			begin
				perform upd_fk('pim_employee_position_resource',dbls[i], dbls[1]);
				delete from pim_employee_position_resource where id = dbls[i];
			end;
			end loop;
		end loop;
    end;
$$;

