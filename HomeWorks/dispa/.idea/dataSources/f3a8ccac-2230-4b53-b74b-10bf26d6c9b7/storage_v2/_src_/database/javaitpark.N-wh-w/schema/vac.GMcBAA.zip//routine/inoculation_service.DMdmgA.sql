CREATE FUNCTION inoculation_service(xnumberid integer, xvaccineid integer, xorgid integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
            serviceId integer;
            prototypeId integer;
            existOrg integer;

            begin

            select into prototypeId sv.service_prototype_id from vac.service_vaccination sv where sv.number_id = xnumberid
            and sv.disease_id = (select v.disease_id from vac_vaccine v where v.id = xvaccineid);

            select into serviceId s.id from sr_service s where s.type_id = (select p.type_id from sr_srv_prototype p where p.id = prototypeId) and
            s.prototype_id = prototypeId;

            select into existOrg id from pim_organization where id = xorgid;

            if (serviceId is null and existOrg is not null and prototypeId is not null)
            then
            insert into sr_service (id, code, is_independent, name, org_id, type_id, prototype_id) values
            (nextval('sr_service_id_seq'),
            (select sv.code from vac.service_vaccination sv where sv.disease_id = (select v.disease_id from vac_vaccine v where v.id = xvaccineid) and sv.number_id = xnumberid),
            true,
            (select sp.name from sr_srv_prototype sp where sp.id = prototypeId),
            xorgid,
            (select ssp.type_id from sr_srv_prototype ssp where ssp.id = prototypeId),
            prototypeId) returning id
            into serviceId;
            end if;

            return serviceId;
            end;
$$;

