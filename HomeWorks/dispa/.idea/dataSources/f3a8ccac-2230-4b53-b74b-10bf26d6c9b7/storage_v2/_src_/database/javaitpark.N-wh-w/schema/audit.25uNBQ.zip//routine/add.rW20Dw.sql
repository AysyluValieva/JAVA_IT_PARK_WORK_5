CREATE FUNCTION add(table_name text)
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
    count_trigger integer;
  BEGIN
    select count(*) into count_trigger from information_schema.triggers
    where trigger_name = 'audit_trigger'
          and (event_object_schema ||'."'|| event_object_table||'"' = $1 OR event_object_schema ||'.'|| event_object_table = $1 OR event_object_table = $1);
    IF(count_trigger = 0)
    THEN
      PERFORM aud_add_audit($1);
    END IF;
    PERFORM audit.add_table($1);
    PERFORM audit.add_trigger($1);
  END;
$$;

