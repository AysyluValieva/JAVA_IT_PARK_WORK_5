CREATE FUNCTION searchtop10patient(_name text DEFAULT NULL::text, _secondname text DEFAULT NULL::text, _surname text DEFAULT NULL::text, _department_id integer DEFAULT NULL::integer)
  RETURNS TABLE(arianumber integer, birthday date, cellphone text, document_n text, document_s text, homephone text, idpat text, name text, polis_n text, polis_s text, secondname text, surname text)
LANGUAGE plpgsql
AS $$
BEGIN
 

return query ( select * from "jenkins"."searchtop10patient_v2"( "_name" ,  "_secondname",  "_surname" ,  "_department_id" ) );

 
 
END;
$$;

