CREATE FUNCTION denidisprforpatient(xstatus integer, xagreedate character varying, xepid integer, xdenialservice character varying, xappropiatservices character varying, realservices character varying, xcase integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
          i integer;
          q_seq integer;
          pci integer;
          rstatus integer;
          mmcrid integer;
          eventcode text;
          mviews record;
          xservices character varying;
          xserviceid json;
          mesp1 integer;
          status_service integer;
          service_rendered_id integer;
        begin


if realServices is  NULL THEN
PERFORM disp.agreement (xagreedate, xepid, xappropiatservices);

xservices=(select array_to_json(array_agg(row_to_json(serv))) from (select id from disp.md_event_service_patient  where event_patient_id = xepid) as serv);
	IF xstatus=1 THEN
		foreach xserviceid in array array(select value from json_array_elements(cast(xdenialservice as json)))
		LOOP
			mesp1=(select id from disp.md_event_service_patient where service_id=xserviceid::text::int and event_patient_id=xepid);
			status_service = (select status from  disp.md_event_service_patient where  id=mesp1);
		service_rendered_id=(select CASE status_service WHEN 4 THEN (select ssr.id                                              
                                              from disp.md_event_service_patient mesp
                                              left join disp.md_event_service mes on mes.id=mesp.service_id
                                              inner join SR_SRV_RENDERED ssr on ssr.service_id = mes.service_id
                                              left join  MD_SRV_RENDERED msr on ssr.id = msr.id
                                              where msr.case_id = xcase and mesp.id=mesp1 limit 1)
                WHEN 3 THEN (select ssr.id
                             
                             from disp.md_event_service_patient mesp
                                              left join disp.md_event_service mes on mes.id=mesp.service_id
                                              left join disp.md_event_service_link mesl on mesl.event_service_id = mes.id
                                               inner join SR_SRV_RENDERED ssr on ssr.id = mesl.service_id
                                               where mesl.case_id = xcase and mesl.event_service_id =  (select mes.service_id from disp.md_event_service mes
                                                left join disp.md_event_service_patient mesp on mesp.service_id=mes.id where mesp.id = mesp1)limit 1
                                              
                                              )
                ELSE NULL
                END);

			PERFORM disp.clearService(service_rendered_id, mesp1, xcase, (select mes.id from disp.md_event_service mes
                                                left join disp.md_event_service_patient mesp on mesp.service_id=mes.id where mesp.id = mesp1));

			
			
			update disp.md_event_service_patient  set status = 2 where  id =mesp1;
			update disp.md_event_service_patient_agreement set agree=False, denial=True, agree_date=to_date(xagreeDate, 'DD.MM.YYYY')  where service_id=mesp1;
		END LOOP;
	ELSIF xstatus = 2 THEN
		foreach xserviceid in array array(select value from json_array_elements(cast(xservices as json)))
		LOOP

		status_service = (select status from  disp.md_event_service_patient where  id=cast(xserviceid::json->>'id' as integer));
		service_rendered_id=(select CASE status_service WHEN 4 THEN (select ssr.id                                              
                                              from disp.md_event_service_patient mesp
                                              left join disp.md_event_service mes on mes.id=mesp.service_id
                                              inner join SR_SRV_RENDERED ssr on ssr.service_id = mes.service_id
                                              left join  MD_SRV_RENDERED msr on ssr.id = msr.id
                                           where msr.case_id = xcase and mesp.id=cast(xserviceid::json->>'id' as integer) limit 1
                                               )
                WHEN 3 THEN (select ssr.id
                             
                             from disp.md_event_service_patient mesp
                                              left join disp.md_event_service mes on mes.id=mesp.service_id
                                              left join disp.md_event_service_link mesl on mesl.event_service_id = mes.id
                                               inner join SR_SRV_RENDERED ssr on ssr.id = mesl.service_id
                                               where mesl.case_id = xcase and mesl.event_service_id =  (select mes.service_id from disp.md_event_service mes
                                                left join disp.md_event_service_patient mesp on mesp.service_id=mes.id where mesp.id = cast(xserviceid::json->>'id' as integer))limit 1                                              
                                              )
                ELSE NULL
                END);

			PERFORM disp.clearService(service_rendered_id, cast(xserviceid::json->>'id' as integer), xcase, (select mes.id from disp.md_event_service mes
                                                left join disp.md_event_service_patient mesp on mesp.service_id=mes.id where mesp.id = cast(xserviceid::json->>'id' as integer)));

			
			update disp.md_event_service_patient  set status = 2 where  id =cast(xserviceid::json->>'id' as integer);
			update disp.md_event_service_patient_agreement set agree=False, denial=True, agree_date=to_date(xagreeDate, 'DD.MM.YYYY')  where service_id=cast(xserviceid::json->>'id' as integer);
		END LOOP;
		if (select count(1) from disp.md_event_agreement where event_patient_id = xepid) > 0 then
        update disp.md_event_agreement set agree = false, denial = true, adate = to_date(xagreeDate, 'DD.MM.YYYY') where event_patient_id = xepid;
    else
        insert into disp.md_event_agreement(id, event_patient_id, agree, denial, adate) values(nextval('disp.md_event_agreement_id_seq'), xepid, false, true, to_date(xagreeDate, 'DD.MM.YYYY'));
    end if;
	END IF;

	END IF;

if realServices is  NOT NULL THEN
xservices=(select array_to_json(array_agg(row_to_json(serv))) from (select id from disp.md_event_service_patient  where event_patient_id =xepid) as serv);
PERFORM disp.agreement (xagreedate, xepid, xservices);
IF xstatus=1 THEN
		foreach xserviceid in array array(select value from json_array_elements(cast(realServices as json)))
		LOOP
			mesp1=xserviceid::text::int ;		
			status_service = (select status from  disp.md_event_service_patient where  id=mesp1);
		service_rendered_id=(select CASE status_service WHEN 4 THEN (select ssr.id                                              
                                              from disp.md_event_service_patient mesp
                                              left join disp.md_event_service mes on mes.id=mesp.service_id
                                              inner join SR_SRV_RENDERED ssr on ssr.service_id = mes.service_id
                                              left join  MD_SRV_RENDERED msr on ssr.id = msr.id
                                              where msr.case_id = xcase and mesp.id=mesp1 limit 1                                           
                                               )
                WHEN 3 THEN (select ssr.id
                             
                             from disp.md_event_service_patient mesp
                                              left join disp.md_event_service mes on mes.id=mesp.service_id
                                              left join disp.md_event_service_link mesl on mesl.event_service_id = mes.id
                                               inner join SR_SRV_RENDERED ssr on ssr.id = mesl.service_id
                                               where mesl.case_id = xcase and mesl.event_service_id =  (select mes.service_id from disp.md_event_service mes
                                                left join disp.md_event_service_patient mesp on mesp.service_id=mes.id where mesp.id = mesp1)limit 1
                                              
                                              )
                ELSE NULL
                END);

			PERFORM disp.clearService(service_rendered_id, mesp1, xcase, (select mes.id from disp.md_event_service mes
                                                left join disp.md_event_service_patient mesp on mesp.service_id=mes.id where mesp.id = mesp1));
                                              
			update disp.md_event_service_patient  set status = 2 where id =mesp1;
			update disp.md_event_service_patient_agreement set agree=False, denial=True, agree_date=to_date(xagreeDate, 'DD.MM.YYYY')  where service_id=mesp1;
		END LOOP;
	ELSIF xstatus = 2 THEN
		foreach xserviceid in array array(select value from json_array_elements(cast(xservices as json)))
		LOOP
		status_service = (select status from  disp.md_event_service_patient where id=mesp1);
		service_rendered_id=(select CASE status_service WHEN 4 THEN (select ssr.id                                              
                                              from disp.md_event_service_patient mesp
                                              left join disp.md_event_service mes on mes.id=mesp.service_id
                                              inner join SR_SRV_RENDERED ssr on ssr.service_id = mes.service_id
                                              left join  MD_SRV_RENDERED msr on ssr.id = msr.id
                                              where msr.case_id = xcase and mesp.id=mesp1 limit 1
                                               )
                WHEN 3 THEN ( select ssr.id
                             
                             from disp.md_event_service_patient mesp
                                              left join disp.md_event_service mes on mes.id=mesp.service_id
                                              left join disp.md_event_service_link mesl on mesl.event_service_id = mes.id
                                               inner join SR_SRV_RENDERED ssr on ssr.id = mesl.service_id
                                               where mesl.case_id = xcase and mesl.event_service_id =  (select mes.service_id from disp.md_event_service mes
                                                left join disp.md_event_service_patient mesp on mesp.service_id=mes.id where mesp.id = mesp1)limit 1
                                              
                                              )
                ELSE NULL
                END);

			PERFORM disp.clearService(service_rendered_id, mesp1, xcase, (select mes.id from disp.md_event_service mes
                                                left join disp.md_event_service_patient mesp on mesp.service_id=mes.id where mesp.id = mesp1));
			
			update disp.md_event_service_patient set status = 2 where id =cast(xserviceid::json->>'id' as integer);
			update disp.md_event_service_patient_agreement set agree=False, denial=True, agree_date=to_date(xagreeDate, 'DD.MM.YYYY')  where service_id=cast(xserviceid::json->>'id' as integer);
		END LOOP;
		if (select count(1) from disp.md_event_agreement where event_patient_id = xepid) > 0 then
        update disp.md_event_agreement set agree = false, denial = true, adate = to_date(xagreeDate, 'DD.MM.YYYY') where event_patient_id = xepid;
    else
        insert into disp.md_event_agreement(id, event_patient_id, agree, denial, adate) values(nextval('disp.md_event_agreement_id_seq'), xepid, false, true, to_date(xagreeDate, 'DD.MM.YYYY'));
    end if;
	END IF;
END IF;
return i;
end;
$$;

