CREATE FUNCTION savegibddinspec_3(xepid integer, xssrid integer, xcaseid integer, xbdate character varying, xresource integer, xmd integer, xdis integer, xservice integer, xsuspicion boolean, xvalida integer, xvalida1 integer, xvalidb integer, xvalidb1 integer, xvalidbe integer, xvalidc integer, xvalidc1 integer, xvalidce integer, xvalidc1e integer, xvalidd integer, xvalidd1 integer, xvalidde integer, xvalidd1e integer, xvalidm integer, xvalidtm integer, xvalidtb integer, xvisiblea boolean, xvisiblea1 boolean, xvisibleb boolean, xvisibleb1 boolean, xvisiblebe boolean, xvisiblec boolean, xvisiblec1 boolean, xvisiblece boolean, xvisiblec1e boolean, xvisibled boolean, xvisibled1 boolean, xvisiblede boolean, xvisibled1e boolean, xvisiblem boolean, xvisibletm boolean, xvisibletb boolean, xspecial_notes character varying)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
          serviceid integer;
          srrid integer;
          stepid integer;
          sysresid integer;
          gibddserviceid integer;
          mcdiagid integer;
          diagnosId integer;
          mesp_id integer;
        begin
          serviceid = xservice;
          if (select count(mep.id) from disp.md_event_patient mep
                left join MD_SRV_RENDERED msr on msr.case_id = mep.case_id
                inner join SR_SRV_RENDERED ssr on ssr.id = msr.id and ssr.service_id = serviceid
                where mep.id = xepid) > 0 then
              if xssrid IS NULL then
                xssrid = (select ssr.id from disp.md_event_patient mep
                left join MD_SRV_RENDERED msr on msr.case_id = mep.case_id
                inner join SR_SRV_RENDERED ssr on ssr.id = msr.id and ssr.service_id = serviceid
                where mep.id = xepid);
              end if;
              srrid = xssrid;
              update mc_step set admission_date = COALESCE(to_date(xbdate, 'DD.MM.YYYY'), current_date), outcome_date = COALESCE(to_date(xbdate, 'DD.MM.YYYY'), current_date)
                where id = (select step_id from gibdd.md_gibdd_service where service_id = xssrid);

              if xresource != (select res_group_id from SR_SRV_RENDERED where id = xssrid) then
                sysresid = nextval('sr_res_group_seq');
                insert into SR_RES_GROUP (id, bdate, edate, is_system, name, department_id, org_id, responsible_id, is_available_in_electronic_queue, label_id)
                  select sysresid as id, bdate, edate, TRUE as is_system, name, department_id, org_id, responsible_id, is_available_in_electronic_queue, label_id
                  from SR_RES_GROUP
                  where id = xresource;

                  insert into sr_res_group_relationship (id, bdatetime, enddatetime, resource_id, group_id, role_id, is_disabled)
                    select nextval('sr_res_group_relationship_seq') as id, bdatetime, edatetime, resource_id, sysresid as group_id, role_id, is_disabled from sr_res_group_relationship where group_id = xresource;

                update mc_step set res_group_id = sysresid,
                        profile_id = (select
                          case when (select count(*) from sr_res_group_profile where res_group_id = xresource) = 1
                          then (select profile_id from sr_res_group_profile where res_group_id = xresource)
                          else null
                          end)
                  where id = (select step_id from gibdd.md_gibdd_service where service_id = xssrid);
              end if;

	      select diagnos_id into diagnosId from gibdd.md_gibdd_service where service_id = xssrid;
	      if (xmd is null) then
		if (diagnosId is not null) then
		  update gibdd.md_gibdd_service set diagnos_id = null where service_id = xssrid;
		  delete from MC_DIAGNOSIS where id = diagnosId;
		  update mc_step set main_diagnosis_id=null where id = (select step_id from gibdd.md_gibdd_service where service_id = xssrid);
		end if;
	      else
		if (diagnosId is null) then
		  mcdiagid = nextval('mc_diagnosis_seq');
		  insert into MC_DIAGNOSIS (id, case_id, patient_id, establishment_date, diagnos_id, disease_type_id, type_id, is_suspicion, is_main, step_id)
                  values (mcdiagid, xcaseId, (select indiv_id from disp.md_event_patient where id = xepid), COALESCE(to_date(xbdate, 'DD.MM.YYYY'), current_date), xmd,
                      xdis, (select id from mc_diagnosis_type where code = '1'), xsuspicion, TRUE, (select step_id from gibdd.md_gibdd_service where service_id = xssrid));
                  update gibdd.md_gibdd_service set diagnos_id = mcdiagid where service_id = xssrid;
                  update mc_step set main_diagnosis_id=mcdiagid where id = (select step_id from gibdd.md_gibdd_service where service_id = xssrid);
		else
		  update mc_diagnosis set diagnos_id =  xmd, disease_type_id = xdis, establishment_date = COALESCE(to_date(xbdate, 'DD.MM.YYYY'), current_date)
                  where id = diagnosId;
		end if;
	      end if;

              update SR_SRV_RENDERED set bdate=COALESCE(to_date(xbdate, 'DD.MM.YYYY'), current_date), edate=COALESCE(to_date(xbdate, 'DD.MM.YYYY'), current_date), res_group_id=xresource
               where id = xssrid;
              update MD_SRV_RENDERED set diagnosis_id = xmd where id = xssrid;
              if (select count(id) from gibdd.md_gibdd_service where service_id = xssrid) > 0 then
                update gibdd.md_gibdd_service set main_diagnosis_id=xmd, disease_type_id=xdis, is_surmise = xsuspicion, rendered_date = to_date(xbdate, 'DD.MM.YYYY'), special_notes = xspecial_notes
                  where service_id = xssrid;
                gibddserviceid = (select id from gibdd.md_gibdd_service where service_id = xssrid);
              else
                gibddserviceid = nextval('gibdd.md_gibdd_service_seq');
                insert into gibdd.md_gibdd_service (id, event_patient_id, service_id, main_diagnosis_id, disease_type_id, is_surmise, res_group_id, rendered_date, special_notes)
                  values (gibddserviceid, xepid, srrid, xmd, xdis, xsuspicion, sysresid, to_date(xbdate, 'DD.MM.YYYY'), xspecial_notes);
              end if;
          else
            srrid = nextval('sr_srv_rendered_seq');
            stepid =  nextval('mc_step_seq');
            sysresid = nextval('sr_res_group_seq');
            -- insert newsysres, step, visit, diag

            insert into SR_RES_GROUP (id, bdate, edate, is_system, name, department_id, org_id, responsible_id, is_available_in_electronic_queue, label_id)
              select sysresid as id, bdate, edate, TRUE as is_system, name, department_id, org_id, responsible_id, is_available_in_electronic_queue, label_id
              from SR_RES_GROUP
              where id = xresource;

            insert into sr_res_group_relationship (id, bdatetime, edatetime, resource_id, group_id, role_id, is_disabled)
              select nextval('sr_res_group_relationship_seq') as id, bdatetime, edatetime, resource_id, sysresid as group_id, role_id, is_disabled from sr_res_group_relationship where group_id = xresource;

            insert into mc_step (id, admission_date, outcome_date, case_id, regimen_id, res_group_id, outcome_id, profile_id)
              values (stepid, COALESCE(to_date(xbdate, 'DD.MM.YYYY'), current_date), COALESCE(to_date(xbdate, 'DD.MM.YYYY'), current_date), xcaseId, (select id from mc_care_regimen where code = 1), xresource, (select id from mc_step_care_result where code = '306' and to_dt is null),
                      (select
                        case when (select count(*) from sr_res_group_profile where res_group_id = xresource) = 1
                        then (select profile_id from sr_res_group_profile where res_group_id = xresource)
                        else null
                        end)
                      );
            insert into plc_visit (id, goal_id, place_id) values (stepid, (select mett.case_init_goal_id from disp.md_event_patient mep left join disp.md_event me on me.id = mep.event_id left join disp.md_event_type_target mett on mett.event_type_id = me.event_type where mep.id = xepid and mett.stage = 1 and (mett.begin_date is null or mett.begin_date <= current_date) and (mett.end_date is null or mett.end_date >= current_date)), (select id from plc_visit_place where code = '1'));

            mcdiagid = null;
            if (xmd is not null) then
              mcdiagid = nextval('mc_diagnosis_seq');
              insert into MC_DIAGNOSIS (id, case_id, patient_id, establishment_date, diagnos_id, disease_type_id, type_id, is_suspicion, is_main, step_id)
              values (mcdiagid, xcaseId, (select indiv_id from disp.md_event_patient where id = xepid), COALESCE(to_date(xbdate, 'DD.MM.YYYY'), current_date), xmd,
                      xdis, (select id from mc_diagnosis_type where code = '1'), xsuspicion, TRUE, stepid);
              update mc_step set main_diagnosis_id=mcdiagid where id = stepid;
            end if;

            insert into SR_SRV_RENDERED (id, service_id, bdate, res_group_id, customer_id, is_rendered, edate, quantity, funding_id, org_id, payment_status_id)
              values (srrid, serviceid, COALESCE(to_date(xbdate, 'DD.MM.YYYY'), current_date), sysresid, (select indiv_id from disp.md_event_patient where id = xepid), TRUE, COALESCE(to_date(xbdate, 'DD.MM.YYYY'), current_date), 1,
              (select me.pay_type from disp.md_event me left join disp.md_event_patient mep on mep.event_id=me.id  where mep.id=xepid),
              (select me.org_id from disp.md_event_patient mep left join disp.md_event me on me.id = mep.event_id where mep.id = xepid), 1);
            insert into MD_SRV_RENDERED (id, case_id, step_id, diagnosis_id) values (srrid, xcaseId, stepid, xmd);
            gibddserviceid = nextval('gibdd.md_gibdd_service_seq');
            insert into gibdd.md_gibdd_service (id, event_patient_id, service_id, main_diagnosis_id, disease_type_id, is_surmise, res_group_id, rendered_date, step_id, diagnos_id, special_notes)
              values (gibddserviceid, xepid, srrid, xmd, xdis, xsuspicion, sysresid, to_date(xbdate, 'DD.MM.YYYY'), stepid, mcdiagid, xspecial_notes);
          end if;

          -- change STATUS
          select mesp.id into mesp_id from disp.md_event_patient mep
                left join disp.md_event_service_patient mesp on mesp.event_patient_id = mep.id
                inner join disp.md_event_service mes on mes.id = mesp.service_id and mes.service_id = serviceid
                where mep.id = xepid;
          update disp.md_event_service_patient set status = 4
              where id = mesp_id;


	  delete from gibdd.md_gibdd_service_category where gibdd_service_id = (select id from gibdd.md_gibdd_service where service_id = xssrid);
	  if xvisiblea = true then
	    insert into gibdd.md_gibdd_service_category (gibdd_service_id, category_id, is_valid) values (gibddserviceid, 1, cast(xvalidA as boolean));
	  end if;
	  if xvisiblea1 = true then
	    insert into gibdd.md_gibdd_service_category (gibdd_service_id, category_id, is_valid) values (gibddserviceid, 2, cast(xvalidA1 as boolean));
	  end if;
	  if xvisibleb = true then
            insert into gibdd.md_gibdd_service_category (gibdd_service_id, category_id, is_valid) values (gibddserviceid, 3, cast(xvalidB as boolean));
          end if;
	  if xvisibleb1 = true then
            insert into gibdd.md_gibdd_service_category (gibdd_service_id, category_id, is_valid) values (gibddserviceid, 4, cast(xvalidB1 as boolean));
          end if;
          if xvisiblebe = true then
            insert into gibdd.md_gibdd_service_category (gibdd_service_id, category_id, is_valid) values (gibddserviceid, 5, cast(xvalidBE as boolean));
          end if;
          if xvisiblec = true then
	    insert into gibdd.md_gibdd_service_category (gibdd_service_id, category_id, is_valid) values (gibddserviceid, 6, cast(xvalidC as boolean));
	  end if;
	  if xvisiblec1 = true then
	    insert into gibdd.md_gibdd_service_category (gibdd_service_id, category_id, is_valid) values (gibddserviceid, 7, cast(xvalidC1 as boolean));
	  end if;
	  if xvisiblece = true then
	    insert into gibdd.md_gibdd_service_category (gibdd_service_id, category_id, is_valid) values (gibddserviceid, 8, cast(xvalidCE as boolean));
	  end if;
	  if xvisiblec1e = true then
	    insert into gibdd.md_gibdd_service_category (gibdd_service_id, category_id, is_valid) values (gibddserviceid, 9, cast(xvalidC1E as boolean));
	  end if;
	  if xvisibled = true then
	    insert into gibdd.md_gibdd_service_category (gibdd_service_id, category_id, is_valid) values (gibddserviceid, 10, cast(xvalidD as boolean));
	  end if;
	  if xvisibled1 = true then
	    insert into gibdd.md_gibdd_service_category (gibdd_service_id, category_id, is_valid) values (gibddserviceid, 11, cast(xvalidD1 as boolean));
	  end if;
	  if xvisiblede = true then
	    insert into gibdd.md_gibdd_service_category (gibdd_service_id, category_id, is_valid) values (gibddserviceid, 12, cast(xvalidDE as boolean));
	  end if;
	  if xvisibled1e = true then
	    insert into gibdd.md_gibdd_service_category (gibdd_service_id, category_id, is_valid) values (gibddserviceid, 13, cast(xvalidD1E as boolean));
	  end if;
	  if xvisiblem = true then
	    insert into gibdd.md_gibdd_service_category (gibdd_service_id, category_id, is_valid) values (gibddserviceid, 14, cast(xvalidM as boolean));
	  end if;
	  if xvisibletm = true then
	    insert into gibdd.md_gibdd_service_category (gibdd_service_id, category_id, is_valid) values (gibddserviceid, 15, cast(xvalidTm as boolean));
	  end if;
	  if xvisibletb = true then
	    insert into gibdd.md_gibdd_service_category (gibdd_service_id, category_id, is_valid) values (gibddserviceid, 16, cast(xvalidTb as boolean));
	  end if;

          perform gibdd.set_contraindication(xepid);

                if (select med_commission_res_group_id is not null from gibdd.md_gibdd_reference where id = xepid) then
                update gibdd.md_gibdd_reference_category rc set is_valid = (select not exists(select 1 from gibdd.md_gibdd_service_category sc join gibdd.md_gibdd_service s on sc.gibdd_service_id = s.id
		        where s.event_patient_id = xepid and sc.category_id = rc.category_id and sc.is_valid = false))
		        where rc.reference_id = xepid;
		        end if;

		        PERFORM gibdd.gibdd_refresh_case_main_diagnisis(xcaseid);

	  return mesp_id;
        end;
$$;

