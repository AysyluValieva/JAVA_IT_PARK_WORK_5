CREATE FUNCTION migration_get_count_row_by_id_diapason(_table_name character varying, _from_id bigint, _to_id bigint)
  RETURNS bigint
LANGUAGE plpgsql
AS $$
DECLARE
  _count BIGINT;
BEGIN
  EXECUTE format(
      ' SELECT count(*)
        FROM %1$s
        WHERE id >= %2$s AND id <= %3$s',
      _table_name, _from_id, _to_id) INTO _count;
  RETURN _count;
END;
$$;

