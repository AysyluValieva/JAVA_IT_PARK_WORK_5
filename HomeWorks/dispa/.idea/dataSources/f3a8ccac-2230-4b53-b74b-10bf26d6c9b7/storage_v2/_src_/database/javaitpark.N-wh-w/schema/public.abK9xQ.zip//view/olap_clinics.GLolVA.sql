CREATE VIEW olap_clinics AS
  SELECT o.id,
    o.short_name AS name
   FROM (pim_organization o
     JOIN md_clinic c ON ((c.id = o.id)));

