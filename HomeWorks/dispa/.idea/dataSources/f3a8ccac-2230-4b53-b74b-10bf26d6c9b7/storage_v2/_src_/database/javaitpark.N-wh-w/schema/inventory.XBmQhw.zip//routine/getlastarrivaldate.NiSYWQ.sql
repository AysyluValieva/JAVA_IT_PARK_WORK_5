CREATE FUNCTION getlastarrivaldate(storesupplyid integer, documentdate date)
  RETURNS date
LANGUAGE plpgsql
AS $$
DECLARE
  lastExpSpecDate DATE;
  lastArrSpecDate DATE;
  lastProdDate    DATE;
BEGIN

  SELECT ias.status_dt
  INTO lastArrSpecDate
  FROM inventory.arrival_spec ias
  WHERE ias.store_sup_id = storeSupplyId AND ias.status_dt <= documentDate
  ORDER BY ias.status_dt DESC
  LIMIT 1;

  SELECT ies.exec_arr_dt
  INTO lastExpSpecDate
  FROM inventory.exp_spec ies
    JOIN inventory.exp_invoice iei ON iei.id = ies.doc_id
    JOIN inventory.document id ON iei.id = id.id
    JOIN inventory.store_supply iss ON iss.store_id = iei.rec_store_id AND
                                       iss.batch_id = ies.batch_id AND
                                       iss.funding_source_id = coalesce(iei.new_fund_source_id, ies.fund_source_id) AND
                                       iss.price = ies.price_vat
  WHERE iss.id = storeSupplyId AND ies.exec_arr_dt <= documentDate AND id.int_doc_type_id in (2, 11);

  SELECT idoc.execute_dt
  INTO lastProdDate
  FROM inventory.production_doc ipd
    JOIN inventory.document idoc ON ipd.id = idoc.id
  WHERE ipd.store_sup_id = storeSupplyId AND idoc.execute_dt <= documentDate
  ORDER BY ipd.prod_date DESC
  LIMIT 1;

  IF lastExpSpecDate IS NULL OR lastExpSpecDate < lastArrSpecDate
  THEN IF lastProdDate IS NULL OR lastProdDate < lastArrSpecDate
  THEN
    RETURN lastArrSpecDate;
  ELSE RETURN lastProdDate;
  END IF;
  ELSE IF lastProdDate IS NULL OR lastProdDate < lastExpSpecDate
  THEN
    RETURN lastExpSpecDate;
  ELSE RETURN lastProdDate;
  END IF;
  END IF;

END;
$$;

