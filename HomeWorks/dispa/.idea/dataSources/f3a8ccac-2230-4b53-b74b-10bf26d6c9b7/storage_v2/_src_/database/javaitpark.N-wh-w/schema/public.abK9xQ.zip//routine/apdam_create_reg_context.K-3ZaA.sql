CREATE FUNCTION apdam_create_reg_context(in_md_clinic_id integer, in_check_district boolean, in_department_id integer, in_type_id integer, in_reg_date date, in_active_address_code character varying)
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
  query     VARCHAR;
  sub_query VARCHAR := '';
  i         RECORD;
BEGIN
  IF in_department_id NOTNULL
  THEN sub_query = ' AND r.department_id = ' || in_department_id;
  ELSEIF in_check_district = FALSE
    THEN sub_query = ' AND r.department_id ISNULL';
  END IF;

  --создаем таблицу с информацией о заявке
  DROP TABLE IF EXISTS apdam_regs;
  query = '
    CREATE UNLOGGED TABLE apdam_regs WITH (AUTOVACUUM_ENABLED = FALSE) AS
    SELECT
      r.id                                      AS reg_id,
      r.patient_id                              AS patient_id,
      apda_get_patient_reg_info(r.id, $4)       AS reg_info,
      r.district_id                             AS current_district_id,
      NULL :: INT                               AS new_district_id
    FROM pci_patient_reg r
      JOIN pim_individual i ON i.id = r.patient_id
    WHERE (i.death_dt ISNULL OR i.death_dt > $3)
      AND i.birth_dt NOTNULL
      AND r.state_id = 1
      AND r.clinic_id = $1
      AND r.type_id = $2
      AND (r.is_assertion ISNULL OR r.is_assertion = FALSE)
      AND ($3 >= r.reg_dt OR r.reg_dt ISNULL)
      AND ($3 <= r.unreg_dt OR r.unreg_dt ISNULL)' || sub_query;

  EXECUTE query
  USING in_md_clinic_id, in_type_id, in_reg_date, in_active_address_code;

  CREATE INDEX ON apdam_regs USING BTREE (reg_id);
  CREATE INDEX ON apdam_regs USING BTREE (current_district_id);

  --удаляем из таблицы записи с пациентами у которых больше одной заявки
  FOR i IN (SELECT patient_id
            FROM apdam_regs
            GROUP BY patient_id
            HAVING count(DISTINCT reg_id) > 1) LOOP
    RAISE WARNING 'У пациента (id=%) больше одного активного прикрепления на заданную дату', i.patient_id;
    DELETE FROM apdam_regs
    WHERE patient_id = i.patient_id;
  END LOOP;

  RAISE NOTICE 'count regs - %', (SELECT count(1) FROM apdam_regs);
END;
$$;

