CREATE FUNCTION getworkingtime(_iddoc integer, _department_id integer, _bdate date, _edate date)
  RETURNS TABLE(bdatetime timestamp without time zone, edatetime timestamp without time zone)
LANGUAGE plpgsql
AS $$
BEGIN
 

return query ( select * from "jenkins"."getworkingtime_v3"( "_iddoc" ,  "_department_id" ,  "_bdate" ,  "_edate" ) );

 
 
END;
$$;

