CREATE RULE delete_user_party AS
    ON DELETE TO public.sec_user_party_own_org DO INSTEAD NOTHING;

