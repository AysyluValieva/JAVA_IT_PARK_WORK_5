CREATE VIEW olap_mc_case_step_care_result AS
  WITH m AS (
         SELECT max(mc_step.id) AS id,
            mc_step.case_id
           FROM mc_step
          GROUP BY mc_step.case_id
        )
 SELECT m.case_id,
    r.name
   FROM mc_step s,
    mc_step_care_result r,
    m
  WHERE ((s.outcome_id = r.id) AND (s.id = m.id));

