CREATE FUNCTION delete_diagnosis(xid integer, xcaseid integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
      _isMain BOOLEAN;
      _stepId INTEGER;
      _serviceId INTEGER;
      _ssrId INTEGER;
      _newDiagnosisId INTEGER;
BEGIN
      _isMain = FALSE;
      SELECT is_main,step_id INTO _isMain,_stepId FROM mc_diagnosis WHERE id = xid;
      UPDATE  md_srv_rendered SET diagnosis_id = null
      WHERE id = (SELECT msr.id FROM md_srv_rendered msr
            JOIN sr_srv_rendered ssr ON msr.id = ssr.id
            JOIN disp.md_dispr_diagnosis_service mdds ON mdds.service_id = ssr.service_id AND msr.case_id = xcaseid
      WHERE mdds.diagnosis_id = xid);
      IF (_isMain) THEN
            SELECT mdds.service_id INTO _serviceId FROM mc_diagnosis md
                  JOIN disp.md_dispr_diagnosis_service mdds ON  md.id = mdds.diagnosis_id WHERE md.id = xid LIMIT 1;

            SELECT ssr.id INTO _ssrId FROM mc_case mc JOIN md_srv_rendered msr ON msr.case_id = mc.id
                  JOIN sr_srv_rendered ssr ON msr.id = ssr.id AND ssr.service_id = _serviceId WHERE mc.id = xcaseId LIMIT 1;

                  WITH maxDate as (
                      SELECT max(edate) as dt FROM md_srv_rendered zmsr JOIN sr_srv_rendered zssr ON zmsr.id = zssr.id
                      WHERE step_id = _stepId AND zmsr.id !=_ssrId and
                            exists(SELECT 1 from disp.md_dispr_diagnosis_service mdds JOIN mc_diagnosis md ON mdds.diagnosis_id = md.id
                            where mdds.service_id = zssr.service_id and md.type_id = 1  and md.step_id = _stepId)
                  ), maxSsrID AS (
                      SELECT max(msr.id) as mid FROM maxDate md, md_srv_rendered msr JOIN sr_srv_rendered ssr ON msr.id = ssr.id
                      WHERE step_id = _stepId AND msr.id != _ssrId AND edate = (md.dt) and
                            exists(SELECT 1 from disp.md_dispr_diagnosis_service mdds JOIN mc_diagnosis md ON mdds.diagnosis_id = md.id
                            where mdds.service_id = ssr.service_id and md.type_id = 1  and md.step_id = _stepId)
                  ), serviceMax AS (
                      SELECT service_id FROM maxSsrID msi, sr_srv_rendered ssr2 WHERE ssr2.id = msi.mid
                  ), diagnosisList as (
                      SELECT mdds2.diagnosis_id FROM serviceMax sm, disp.md_dispr_diagnosis_service mdds2
                      WHERE mdds2.service_id = sm.service_id
                            and exists(select 1 from mc_diagnosis mc where mc.id = mdds2.diagnosis_id and mc.step_id = _stepId )
                  )
                  SELECT md.id into _newDiagnosisId FROM mc_diagnosis md JOIN diagnosisList dl ON md.id = dl.diagnosis_id
                  WHERE md.type_id =1 AND md.step_id = _stepId;

                  UPDATE mc_step SET main_diagnosis_id = _newDiagnosisId WHERE id = _stepId;
                  IF (SELECT max(id) = _stepId FROM mc_step WHERE case_id = xcaseid AND admission_date =
                                                                                        (SELECT max(admission_date) FROM mc_step WHERE case_id = xcaseid))
                  THEN
                        update mc_case set main_diagnos_id = _newDiagnosisId WHERE id = xcaseid;
                  END IF;

                  update mc_diagnosis set is_main = true where mc_diagnosis.id = _newDiagnosisId;
      END IF;
      DELETE FROM mc_diagnosis WHERE id = xid;
END;
$$;

