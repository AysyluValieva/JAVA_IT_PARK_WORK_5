CREATE FUNCTION orphans_agreement(xcheckservices character varying, xepid integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare

          checkserviceId json;
          i integer;
          count_service integer;
        begin
count_service=(select count(*) from disp.md_event_service_patient where event_patient_id =xepid);
        if count_service = 0 Then
if xcheckservices IS NOT NULL THEN
--проставляют услуги по назначению (автомат)
 foreach checkserviceId in array array(select value from json_array_elements(cast(xcheckservices as json)))

                LOOP
                 if checkserviceId::text::text !='null' THEN
                 insert into disp.md_event_service_patient (id, service_id, indiv_id, event_id,event_patient_id)
              values (
              nextval('disp.md_event_service_patient_id_seq'),
              (select id from disp.md_event_service where id=checkserviceId::text::int and event_id=(select event_id from disp.md_event_patient where id=xepid)),
               (select indiv_id from disp.md_event_patient where id=xepid),
               (select event_id from disp.md_event_patient where id=xepid),
               xepid);
               END IF;
                END LOOP;
END IF;
END IF;
          return i;
        end;
$$;

