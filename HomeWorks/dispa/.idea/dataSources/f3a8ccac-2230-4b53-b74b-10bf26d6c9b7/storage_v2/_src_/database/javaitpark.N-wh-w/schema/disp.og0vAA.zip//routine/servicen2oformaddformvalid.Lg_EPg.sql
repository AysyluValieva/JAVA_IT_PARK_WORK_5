CREATE FUNCTION servicen2oformaddformvalid(xcode character varying, xform character varying)
  RETURNS text
LANGUAGE plpgsql
AS $$
DECLARE

BEGIN
  IF xform NOT IN ('disprCardRenderingServiceTherapeutist', 'orphansDisprCardInspecPediatr')
  THEN RETURN 'true'; END IF;
  IF xform = 'disprCardRenderingServiceTherapeutist' AND xcode NOT IN ('Д1.18', 'Д2.06')
  THEN RETURN 'Форма "Прием терапевта (disprCardRenderingServiceTherapeutist )" может быть назначена только услугам Д1.18, Д2.06'; END IF;
  IF xform = 'orphansDisprCardInspecPediatr' AND xcode NOT IN ('ДС1.1', 'ОН1.1', 'ДС1.1_2', 'ОН1.1_2')
  THEN RETURN 'Форма "Осмотр (orphansDisprCardInspecPediatr)" может быть назначена только услугам ДС1.1, ОН1.1, ДС1.1_2, ОН1.1_2'; END IF;


  RETURN 'true';
END;
$$;

