CREATE FUNCTION apdam_detach_dead(in_md_clinic_id integer, in_check_district boolean, in_department_id integer, in_type_id integer, in_reg_date date)
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
  query VARCHAR;
BEGIN
  query = '
    WITH ctex AS (
        SELECT r.id, i.death_dt
        FROM pci_patient_reg r
          JOIN pim_individual i ON i.id = r.patient_id
        WHERE r.state_id = 1
          AND r.clinic_id = $1
          AND r.type_id = $2
          AND i.death_dt NOTNULL
          AND i.death_dt <= $3';

  IF in_department_id NOTNULL
  THEN query = query || ' AND r.department_id = ' || in_department_id;
  ELSEIF in_check_district = FALSE
    THEN query = query || ' AND r.department_id ISNULL';
  END IF;

  query = query || ')
  UPDATE pci_patient_reg reg
  SET
    state_id = 2,
    unreg_cause_id = 4,
    unreg_dt = ctex.death_dt
  FROM ctex
  WHERE reg.id = ctex.id;
  ';

  EXECUTE query || query
  USING in_md_clinic_id, in_type_id, in_reg_date;
END;
$$;

