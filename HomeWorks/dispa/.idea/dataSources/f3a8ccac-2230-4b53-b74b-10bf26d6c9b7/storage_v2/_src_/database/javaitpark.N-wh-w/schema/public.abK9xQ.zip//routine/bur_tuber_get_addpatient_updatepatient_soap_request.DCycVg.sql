CREATE FUNCTION bur_tuber_get_addpatient_updatepatient_soap_request(pat_id integer)
  RETURNS text[]
LANGUAGE plpgsql
AS $$
declare a text[];
  begin
   with t as (
select
  i.id
 ,'<tub:idPatientMIS>' || i.id || '</tub:idPatientMIS>' id_patient_mis
 ,'<tub:familyname>' || text_to_alt_codes(i.surname) || '</tub:familyname>' family_name 
 ,'<tub:firstname>' || text_to_alt_codes(i.name) || '</tub:firstname>' first_name 
 ,coalesce('<tub:middlename>' || text_to_alt_codes(i.patr_name) || '</tub:middlename>', '') middle_name
 ,'<tub:birthDate>' || to_char(i.birth_dt, 'yyyy-mm-dd') || '</tub:birthDate>' birth_Date
 ,'<tub:deathDate>' || to_char(i.death_dt, 'yyyy-mm-dd') || '</tub:deathDate>' death_date
 ,coalesce((select '<tub:snils>' || format_snils(code) || '</tub:snils>' from pim_indiv_code ic where ic.indiv_id = i.id and type_id = 1 limit 1), '') snils
 ,'<tub:sex>' || i.gender_id || '</tub:sex>' sex

,(
 select '<tub:socialStatus>' ||
   case social_group_id 
    when 1 then 1 
    when 2 then 3 
    when 5 then 2 
    when 8 then 4 
   end || '</tub:socialStatus>'
 from pci_patient_social_group sg where sg.social_group_id in (1,5,2,8) and current_date between sg.from_dt and coalesce(sg.to_dt, 'infinity') and sg.patient_id = i.id limit 1) social_status
 
,(
 select 
  id.id 
 from pim_individual_doc id 
 join pim_doc_type dt on dt.id = id.type_id and dt.code in ('MHI_OLDER', 'MHI_UNIFORM', 'MHI_TEMP') and id.indiv_id = i.id and current_date between coalesce(id.issue_dt, '-infinity') and coalesce(id.expire_dt, 'infinity')
order by 
 case dt.code 
  when 'MHI_TEMP' then 0 
  when 'MHI_UNIFORM' then 1
  when 'MHI_OLDER' then 2
 end, coalesce(id.is_active, true) desc limit 1
) polis_id

,(
 select r.id from pci_patient_reg r 
 join md_reg_state rs on rs.id = r.state_id and rs.code = '1' and r.patient_id = i.id and 
 current_date between coalesce(r.reg_dt, '-infinity') and coalesce(r.unreg_dt, 'infinity') 
 join md_reg_type rt on rt.id = r.type_id and rt.code = '1'
 order by r.reg_dt desc, r.clinic_id limit 1
) reg_id

,i.gender_id

,(
 select 
  string_agg(
   lpad(' ', 12) || '<tub:tuberGroups>' || chr(10) ||
   lpad(' ', 15) || '<tub:group>' || cp.code_group_of_people || '</tub:group>' || chr(10) ||
   lpad(' ', 15) || '<tub:dateStart>' || to_char(pc.from_dt, 'yyyy-mm-dd') || '</tub:dateStart>' || chr(10) ||
   coalesce(
   lpad(' ', 15) || '<tub:dateEnd>' || to_char(pc.to_dt, 'yyyy-mm-dd') || '</tub:dateEnd>' || chr(10), '') ||
   lpad(' ', 12) || '</tub:tuberGroups>' || chr(10)
   ,'')
 from pci_patient_category pc 
 join pci_ref_book_categor_pat cp on pc.patient_id = i.id and code_group_of_people is not null and pc.category_id = cp.id and
 pc.from_dt is not null
 ) tuber_groups

,(
 select 
  string_agg(
   lpad(' ', 12) || '<tub:socialRiskGroups>' || chr(10) ||
   lpad(' ', 15) || '<tub:group>' || cp.code_social_groups || '</tub:group>' || chr(10) ||
   lpad(' ', 15) || '<tub:dateStart>' || to_char(pc.from_dt, 'yyyy-mm-dd') || '</tub:dateStart>' || chr(10) ||
   coalesce(
   lpad(' ', 15) || '<tub:dateEnd>' || to_char(pc.to_dt, 'yyyy-mm-dd') || '</tub:dateEnd>' || chr(10), '') ||
   lpad(' ', 12) || '</tub:socialRiskGroups>'
   ,'') social_risk_groups
 from pci_patient_category pc 
 join pci_ref_book_categor_pat cp on pc.patient_id = i.id and code_social_groups is not null and pc.category_id = cp.id and
 pc.from_dt is not null
 ) social_risk_groups

,'<tub:testLastDate>' || (select bdate from sr_srv_rendered r 
 join sr_service s on s.id = r.service_id
 join sr_srv_type st on st.code = 'DIAGNOSTICS' and s.type_id = st.id and r.customer_id = i.id
 join sr_srv_prototype pr on pr.id = r.prototype_id and (pr.code like 'A06.09.006%' or pr.code = 'A06.09.006')
limit 1
) || '</tub:testLastDate>' test_last_date

from pim_individual i

where 
i.name is not null and i.surname is not null and i.birth_dt is not null and i.gender_id is not null and exists (select 1 from pci_patient p where p.id = i.id)

-- есть полис
and
exists (select 1 from pim_individual_doc id join pim_doc_type dt on dt.id = id.type_id and 
 dt.code in ('MHI_OLDER', 'MHI_UNIFORM', 'MHI_TEMP') and id.indiv_id = i.id and current_date between coalesce(id.issue_dt, '-infinity') and coalesce(id.expire_dt, 'infinity')) 
-- прикреплен
and
exists (
 select 1 from pci_patient_reg r 
 join md_reg_state rs on rs.id = r.state_id and rs.code = '1' and r.patient_id = i.id and 
  current_date between coalesce(r.reg_dt, '-infinity') and coalesce(r.unreg_dt, 'infinity') 
 join md_reg_type rt on rt.id = r.type_id and rt.code = '1' and r.clinic_id is not null
)

-- соц статус

and 
exists (
 select 1 from pci_patient_social_group sg where sg.social_group_id in (1,5,2,8) and current_date between sg.from_dt and coalesce(sg.to_dt, 'infinity') and sg.patient_id = i.id
)


-- есть хотя бы одна флюорография

and exists (
select 1 from sr_srv_rendered r 
 join sr_service s on s.id = r.service_id
 join sr_srv_type st on st.code = 'DIAGNOSTICS' and s.type_id = st.id and r.customer_id = i.id
 join sr_srv_prototype pr on pr.id = r.prototype_id and (pr.code like 'A06.09.006%' or pr.code = 'A06.09.006')
)

and ID = pat_id


),


tt as (
select 
  t.id
 ,id_patient_mis
 ,social_status
 ,birth_Date
 ,death_date
 ,snils
 ,family_name
 ,first_name
 ,middle_name
 ,sex
 ,test_last_date
 ,tuber_groups
 ,coalesce('<tub:attachDate>' || to_char(r.reg_dt, 'yyyy-mm-dd') || '</tub:attachDate>', '') attach_date
 ,coalesce('<tub:detachDate>' || to_char(r.unreg_dt, 'yyyy-mm-dd') || '</tub:detachDate>', '') detach_date
 ,(select '         <tub:idOrg>' || oc.code || '</tub:idOrg>' from pim_org_code oc 
   join pim_code_type ct on ct.id = oc.type_id and ct.code = 'OID' and oc.org_id = r.clinic_id limit 1) id_org

--полис
 ,lpad(' ', 12) || '<tub:insurancePolicy>' || chr(10) ||

  coalesce((select lpad(' ', 15) || '<tub:companyCode>' || oc.code || '</tub:companyCode>' || chr(10) from pim_org_code oc 
   join pim_code_type ct on ct.id = oc.type_id and ct.code = 'OID' and oc.org_id = id.issuer_id limit 1), '') ||
   
  lpad(' ', 15) || '<tub:number>' || id.number || '</tub:number>' || chr(10) ||
  
  coalesce(lpad(' ', 15) || '<tub:serial>' || text_to_alt_codes(id.series) || '</tub:serial>' || chr(10), '') ||
  
  lpad(' ', 15) || '<tub:type>' || case dt.code 
                     when 'MHI_TEMP' then 3 
                     when 'MHI_UNIFORM' then 1
                     when 'MHI_OLDER' then 2
                    end || '</tub:type>' || chr(10) ||

   lpad(' ', 12) || '</tub:insurancePolicy>' insurance_policy,
   social_risk_groups

 ,'<tub:isTBInfected>' || exists (select 1 from pci_dispensary disp join md_diagnosis d on d.id = disp.diagnosis_id and current_date between disp.reg_in_dt and coalesce(reg_out_dt, 'infinity') and d.code between 'A15' and 'A19.999' and disp.patient_id = t.id) || '</tub:isTBInfected>' is_tb_infected

from t
left join pci_patient_reg r on r.id = reg_id
join pim_individual_doc id on id.id = polis_id
join pim_doc_type dt on id.type_id = dt.id
where exists
 (select 1 from pim_org_code oc 
   join pim_code_type ct on ct.id = oc.type_id and ct.code = 'OID' and oc.org_id = r.clinic_id)
)

select
array[
concat(
'<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tub="http://tuberws.burmiac.ru">', chr(10),
'   <soapenv:Header/>', chr(10),
'   <soapenv:Body>', chr(10),
'      <tub:AddPatient>', chr(10),
'         <tub:guid>ca68db30-8944-4548-ad38-69b14160e2fb</tub:guid>', chr(10),
id_org, chr(10),

'         <tub:patient>', chr(10),
lpad(' ', 12) || id_patient_mis || chr(10),
lpad(' ', 12) || family_name || chr(10),
lpad(' ', 12) || first_name || chr(10),
lpad(' ', 12) || middle_name || chr(10),
lpad(' ', 12) || birth_Date || chr(10),
lpad(' ', 12) || sex || chr(10),
lpad(' ', 12) || death_Date || chr(10),
lpad(' ', 12) || social_status || chr(10),

insurance_policy || chr(10),
lpad(' ', 12) || snils || chr(10),
lpad(' ', 12) || attach_date || chr(10),
lpad(' ', 12) || detach_date || chr(10),
lpad(' ', 12) || test_last_date || chr(10),

lpad(' ', 12) || is_tb_infected || chr(10),
social_risk_groups || chr(10),
tuber_groups || chr(10),
id_org, chr(10),

'         </tub:patient>', chr(10),
'      </tub:AddPatient>', chr(10),
'   </soapenv:Body>', chr(10),
'</soapenv:Envelope>'

),

concat(
'<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tub="http://tuberws.burmiac.ru">', chr(10),
'   <soapenv:Header/>', chr(10),
'   <soapenv:Body>', chr(10),
'      <tub:UpdatePatient>', chr(10),
'         <tub:guid>ca68db30-8944-4548-ad38-69b14160e2fb</tub:guid>', chr(10),
id_org, chr(10),


'         <tub:patient>', chr(10),
lpad(' ', 12) || id_patient_mis || chr(10),
lpad(' ', 12) || family_name || chr(10),
lpad(' ', 12) || first_name || chr(10),
lpad(' ', 12) || middle_name || chr(10),
lpad(' ', 12) || birth_Date || chr(10),
lpad(' ', 12) || sex || chr(10),
lpad(' ', 12) || death_Date || chr(10),
lpad(' ', 12) || social_status || chr(10),

insurance_policy || chr(10),
lpad(' ', 12) || snils || chr(10),
lpad(' ', 12) || attach_date || chr(10),
lpad(' ', 12) || detach_date || chr(10),
lpad(' ', 12) || test_last_date || chr(10),

lpad(' ', 12) || is_tb_infected || chr(10),
social_risk_groups || chr(10),
tuber_groups || chr(10),
id_org, chr(10),
'         </tub:patient>', chr(10),
'      </tub:UpdatePatient>', chr(10),
'   </soapenv:Body>', chr(10),
'</soapenv:Envelope>'

)]

from tt
 into a;
   return a;
  end;
$$;

