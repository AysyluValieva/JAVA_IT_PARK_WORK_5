CREATE FUNCTION apda_check_district_by_benefit_criterion(ids integer[], district_id integer)
  RETURNS boolean
LANGUAGE plpgsql
AS $$
BEGIN
  RETURN (SELECT exists(SELECT 1
                        FROM pci_district_benefit b
                        WHERE b.district_id = $2 AND b.benefit_definition_id = ANY ($1)
                        LIMIT 1));
END;
$$;

