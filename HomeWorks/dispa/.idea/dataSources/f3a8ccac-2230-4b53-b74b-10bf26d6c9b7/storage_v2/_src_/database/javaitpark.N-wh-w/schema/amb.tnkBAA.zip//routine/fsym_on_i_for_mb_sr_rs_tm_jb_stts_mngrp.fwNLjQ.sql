CREATE FUNCTION fsym_on_i_for_mb_sr_rs_tm_jb_stts_mngrp()
  RETURNS trigger
LANGUAGE plpgsql
AS $fun$
begin                                                                                                                                                                  
                                   
                                  if 1=1 and "public".sym_triggers_disabled() = 0 then                                                                                                 
                                    insert into "public".sym_data                                                                                                                     
                                    (table_name, event_type, trigger_hist_id, row_data, channel_id, transaction_id, source_node_id, external_data, create_time)                                        
                                    values(                                                                                                                                                            
                                      'sr_res_team_job_status',                                                                                                                                            
                                      'I',                                                                                                                                                             
                                      27,                                                                                                                                             
                                      
          case when new."id" is null then '' else '"' || cast(cast(new."id" as numeric) as varchar) || '"' end||','||
          case when new."code" is null then '' else '"' || replace(replace(cast(new."code" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."name" is null then '' else '"' || replace(replace(cast(new."name" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."color" is null then '' else '"' || replace(replace(cast(new."color" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."time" is null then '' else '"' || to_char(new."time", 'HH24:MI:SS.US') || '"' end||','||
          case when new."e_code" is null then '' else '"' || replace(replace(cast(new."e_code" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end,                                                                                                                                                      
                                      'amb_sr_res_team_job_status_default',                                                                                                                                                
                                      txid_current(),                                                                                                                                               
                                      "public".sym_node_disabled(),                                                                                                                   
                                      null,                                                                                                                                               
                                      CURRENT_TIMESTAMP                                                                                                                
                                    );                                                                                                                                                                 
                                  end if;                                                                                                                                                              
                                                                                                                                                                               
                                  return null;                                                                                                                                                         
                                end;
$fun$;

