CREATE FUNCTION service_validate2(xmespid integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
	      caseid integer;
	      mnds_code character varying;
	      is_case_closed boolean;
	      is_service_in_bill boolean;
	      is_service_last boolean;
        begin
          select case_id into caseid
          from disp.md_event_service_patient mesp
	      join disp.md_event_patient mep on mep.id = mesp.event_patient_id
          where mesp.id = xmespid;
	      select mnds.code into mnds_code
	      from disp.md_event_service_patient mesp
	      join disp.md_event_service mes on mes.id = mesp.service_id
          join disp.sr_srv_service_document sssd on sssd.service_id = mes.service_id
          join md_norm_document_service mnds on mnds.id = sssd.document_service_id
          inner join disp.md_standard_prescription_extended mspe on mspe.id = mes.standard_prescription_id and mspe.norm_doc_service_id = mnds.id and mspe.stage_number = 1
          where mesp.id = xmespid;

	      select exists(select 1 from mc_case mc where mc.id = caseid and mc.closing_step_id is not null) into is_case_closed;
	      select (case when is_case_closed then
                (select exists(select 1 from fin_bill_spec_item fbsi
                join fin_bill fb on fb.id = fbsi.bill_id
                join fin_bill_status fbs on fb.status_id = fbs.id
                join md_srv_rendered ren on ren.id = fbsi.service_id and ren.case_id = caseid
                where fbs.code not in ('NEW', 'GENERATED', 'RETURNED') and
                fbsi.id = (select max(fbsi2.id) from fin_bill_spec_item fbsi2 where fbsi2.service_id = fbsi.service_id)))
                else false end) into is_service_in_bill;
          select (case when mnds_code in ('Д1.18', 'ОН1.1', 'ДС1.1') then true else false end) into is_service_last;

          if (is_case_closed and not is_service_in_bill and is_service_last) then
	        return 1;
	      else
	        return 0;
	      end if;
        end;
$$;

