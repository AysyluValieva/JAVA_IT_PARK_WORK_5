CREATE FUNCTION check_refbooks(xeventtype integer)
  RETURNS character varying
LANGUAGE plpgsql
AS $$
declare
    eventtypefund boolean;
    eventtypetarget boolean;
    eventtypehealthgroup boolean;
    rec record;
    message_eventtypehealthgroup character varying;
    message_eventtypetarget character varying;
    message_eventtypefund character varying;
    message_end character varying;
    message character varying;
    delim boolean;
    is2stage boolean;
  begin
    is2stage = (select is_2_stage from disp.md_event_type where id = xeventtype);
    eventtypefund = (select exists(select 1 from disp.md_event_type_fund where event_type_id = xeventtype and (begin_date is null or current_date >= begin_date) and (end_date is null or current_date <= end_date)));
    eventtypetarget = (select exists(select 1 from disp.md_event_type_target where event_type_id = xeventtype and stage = 1 and (begin_date is null or current_date >= begin_date) and (end_date is null or current_date <= end_date)));
    if (is2stage) then
      eventtypetarget = eventtypetarget and (select exists(select 1 from disp.md_event_type_target where event_type_id = xeventtype and stage = 2 and (begin_date is null or current_date >= begin_date) and (end_date is null or current_date <= end_date)));
    end if;
    eventtypehealthgroup = true;
    for rec in
    select health_group_id from disp.md_event_type_health_group where event_type_id = xeventtype
    loop
      eventtypehealthgroup = eventtypehealthgroup and (select exists(select 1 from disp.md_result_health_group where event_type_id = xeventtype and health_group_id = rec.health_group_id and stage = 1 and (begin_date is null or current_date >= begin_date) and (end_date is null or current_date <= end_date)));
      eventtypehealthgroup = eventtypehealthgroup and (select exists(select 1 from disp.md_result_health_group where event_type_id = xeventtype and health_group_id = rec.health_group_id and is_2_stage = true and stage = 1 and (begin_date is null or current_date >= begin_date) and (end_date is null or current_date <= end_date)));
      if (is2stage) then
        eventtypehealthgroup = eventtypehealthgroup and (select exists(select 1 from disp.md_result_health_group where event_type_id = xeventtype and health_group_id = rec.health_group_id and stage = 2 and (begin_date is null or current_date >= begin_date) and (end_date is null or current_date <= end_date)));
        eventtypehealthgroup = eventtypehealthgroup and (select exists(select 1 from disp.md_result_health_group where event_type_id = xeventtype and health_group_id = rec.health_group_id and is_2_stage = true and stage = 2 and (begin_date is null or current_date >= begin_date) and (end_date is null or current_date <= end_date)));
      end if;
    end loop;
    if (eventtypefund and eventtypetarget and eventtypehealthgroup) then
      return '';
    end if;
    message_eventtypehealthgroup = '"Результат обращения, группа здоровья, вид мероприятия" ';
    message_eventtypetarget = '"Вид мероприятия, цель обращения" ';
    message_eventtypefund = '"Вид мероприятия, вид финансирования" ';
    message_end = 'в "Настройки/справочники".';
    message = 'Для корректного формирования случая проверьте наличие записей в таблице(-ах) соответствия ';
    delim = false;
    if (eventtypefund = false) then
      message = concat(message, message_eventtypefund);
      delim = true;
    end if;
    if (eventtypetarget = false) then
      if (delim) then
        message = concat_ws(', ', message, message_eventtypetarget);
      else
        message = concat(message, message_eventtypetarget);
      end if;
      delim = true;
    end if;
    if (eventtypehealthgroup = false) then
      if (delim) then
        message = concat_ws(', ', message, message_eventtypehealthgroup);
      else
        message = concat(message, message_eventtypehealthgroup);
      end if;
    end if;
    message = concat(message, message_end);
    return message;
  end;
$$;

