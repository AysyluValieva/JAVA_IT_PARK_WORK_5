CREATE FUNCTION fin_fill_pivot_policy_table(p1_bill_id integer)
  RETURNS void
STRICT
LANGUAGE plpgsql
AS $$
DECLARE 
    _code_grn_id INTEGER := (SELECT id FROM public.pim_code_type WHERE code = 'OGRN'    );
    _code_oms_id INTEGER := (SELECT id FROM public.pim_code_type WHERE code = 'CODE_OMS');
BEGIN
    /*
        version: 2015-06-22
    */
    IF EXISTS (SELECT 1 FROM billing.fin_bill_policy WHERE bill_id = p1_bill_id) THEN DELETE FROM billing.fin_bill_policy WHERE bill_id = p1_bill_id; END IF;
    -------------------------первичное добавление--------------------------------------------------
    INSERT INTO billing.fin_bill_policy (bill_id, id, customer_id, belonging_type, item_id_arr)
        SELECT 
            bill_id, coalesce (active_policy_id, 0), CASE WHEN active_policy_id IS NULL THEN NULL ELSE customer_id END, belonging_type, array_agg (fin_bill_spec_item_id)
        FROM 
            billing.fin_bill_generate 
        WHERE 
            bill_id = p1_bill_id AND NOT is_sifted
        GROUP BY 1, 2, 3, 4
    ;
    -------------------------информация по полису--------------------------------------------------
    WITH t AS 
    (
        SELECT 
            f.bill_id,
            f.id,
            i.type,
            CASE WHEN i.type = 'MHI_UNIFORM' THEN '' ELSE i.series     END AS series,
            CASE WHEN i.type = 'MHI_UNIFORM' THEN i.code ELSE i.number END AS number,
            i.issue_dt,
            i.issuer_id,
            o.work_territory_id,
            coalesce (trim (o.short_name), '') AS issuer_short_name,
            left (coalesce (trim (public.address__get_nearest_okato (o.work_territory_id)), ''), 5) AS issuer_okato,
            coalesce (trim (s.code), '')  AS issuer_code_oms,
            coalesce (trim (n.code), '')  AS issuer_ogrn
        FROM 
            billing.fin_bill_policy            AS f
            JOIN LATERAL 
            ( 
                SELECT 
                    i.issue_dt,
                    i.issuer_id,
                    coalesce (trim ((SELECT code FROM public.pim_indiv_code WHERE id = i.code_id LIMIT 1)), '') AS code, 
                    coalesce (trim (upper (i.series)), '') AS series, 
                    coalesce (trim (upper (i.number)), '') AS number, 
                    coalesce (trim (upper ((SELECT code FROM public.pim_doc_type WHERE id = i.type_id LIMIT 1))), '') AS type
                FROM
                    public.pim_individual_doc AS i 
                WHERE
                    id = f.id 
                LIMIT 1
            ) AS i ON TRUE
            LEFT JOIN LATERAL (SELECT short_name, work_territory_id FROM public.pim_organization WHERE id = i.issuer_id LIMIT 1) AS o ON TRUE
            LEFT JOIN LATERAL (SELECT code FROM public.pim_org_code WHERE type_id = _code_grn_id AND org_id = i.issuer_id ORDER BY issue_dt DESC NULLS LAST LIMIT 1) AS n ON TRUE
            LEFT JOIN LATERAL (SELECT code FROM public.pim_org_code WHERE type_id = _code_oms_id AND org_id = i.issuer_id ORDER BY issue_dt DESC NULLS LAST LIMIT 1) AS s ON TRUE
        WHERE
            f.bill_id = p1_bill_id
    )
    UPDATE billing.fin_bill_policy AS f
    SET
        type                     = t.type             ,
        series                   = t.series           ,
        number                   = t.number           ,
        issue_dt                 = t.issue_dt         ,
        issuer_id                = t.issuer_id        ,
        issuer_work_territory_id = t.work_territory_id,
        issuer_code_oms          = t.issuer_code_oms  ,
        issuer_ogrn              = t.issuer_ogrn      ,
        issuer_okato             = t.issuer_okato     ,
        issuer_short_name        = t.issuer_short_name 
    FROM t 
    WHERE 
        f.bill_id = t.bill_id AND f.id = t.id
    ;
END;
$$;

