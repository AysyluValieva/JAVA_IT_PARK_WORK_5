CREATE FUNCTION get_count_refbook_value(xtable_name character varying, xid integer, xname character varying)
  RETURNS bigint
LANGUAGE plpgsql
AS $$
DECLARE
    result BIGINT;
    q VARCHAR;
BEGIN

IF $1 ISNULL OR $2 NOTNULL
THEN RETURN (SELECT 1::BIGINT);
END IF;

q = 'SELECT count(*)::BIGINT FROM ' || $1;
IF $3 NOTNULL
THEN
	q = concat(q, ' WHERE UPPER(name) LIKE UPPER(''%' || $3 || '%'')');
END IF;

EXECUTE q
INTO result;

RETURN result;
END;
$$;

