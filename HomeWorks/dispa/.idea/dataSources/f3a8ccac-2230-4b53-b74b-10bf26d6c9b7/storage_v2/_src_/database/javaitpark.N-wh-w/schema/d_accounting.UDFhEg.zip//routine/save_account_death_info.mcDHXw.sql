CREATE FUNCTION save_account_death_info(xid integer, xaccountid integer, xdeadinhospital boolean, xdeathreasonid integer, xanotherdeathreason text, xdeathdiseaseid integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
DECLARE
  _id INTEGER;
BEGIN
  _id = xid;

  IF (_id IS NULL)
  THEN
    INSERT INTO d_accounting.account_death_info (id, account_id, dead_in_hospital, death_reason_id, another_death_reason, death_disease_id)
    VALUES
      (nextval('d_accounting.account_death_info_seq'), xAccountId, xDeadInHospital, xDeathReasonId, xAnotherDeathReason,
       xDeathDiseaseId)
    RETURNING id
      INTO _id;
  ELSE
    UPDATE d_accounting.account_death_info
    SET dead_in_hospital   = xDeadInHospital, death_reason_id = xDeathReasonId,
      another_death_reason = xAnotherDeathReason,
      death_disease_id     = xDeathDiseaseId
    WHERE id = _id;
  END IF;
  IF (xDeathReasonId <> 8)
  THEN
    UPDATE d_accounting.account_death_info
    SET another_death_reason = NULL, death_disease_id = NULL
    WHERE id = _id;
  END IF;

  RETURN _id;
END;
$$;

