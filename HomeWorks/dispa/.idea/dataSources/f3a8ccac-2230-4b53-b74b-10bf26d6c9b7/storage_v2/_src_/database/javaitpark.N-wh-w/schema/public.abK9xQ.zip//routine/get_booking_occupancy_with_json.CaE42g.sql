CREATE FUNCTION get_booking_occupancy_with_json(_in_org_id integer, _in_degin_dt character varying, _in_end_dt character varying, _in_care_regimen_id integer, _in_department_id integer, _in_profile_id integer, _in_bed_profile_id integer, _in_patient_sex_id integer, OUT id bigint, OUT org_id integer, OUT org_name character varying, OUT care_regimen_id integer, OUT care_regimen_name character varying, OUT dates_json character varying)
  RETURNS SETOF record
LANGUAGE plpgsql
AS $$
begin
    /* v02 - добавлены исключения подразделений/профилей подразделений/профилей/палат/коек/статусов коек*/
    return query
    WITH param(
           in_org_id,
           in_degin_dt,
           in_end_dt,
           in_care_regimen_id,
           in_department_id,
           in_profile_id,
           in_bed_profile_id,
           in_patient_sex_id
       ) AS (
       VALUES (_in_org_id :: INTEGER,
               _in_degin_dt :: date + interval '0 hours 0 minute 0 second' ,
               _in_end_dt :: date + interval '23 hours 59 minute 59 second',-- _in_end_dt :: date + interval '23 hours 59 minute 59 second',
               _in_care_regimen_id :: INTEGER,
               _in_department_id :: INTEGER,
               _in_profile_id :: INTEGER,
               _in_bed_profile_id :: INTEGER,
               _in_patient_sex_id :: INTEGER)
                   ),
    interval_dt as (
        SELECT  row_number() OVER (ORDER BY dt ) - 1 AS id,
                dt AS from_dt,
                dt + interval '1 day -1 sec' AS to_dt,
                to_char(dt, 'DD.MM.YYYY') AS from_dt_str,
                case when dt < in_end_dt then true else false end as from_dt_view
        FROM    param,
                LATERAL generate_series(in_degin_dt, /*in_degin_dt + INTERVAL '13 day'*/ in_end_dt, '1 day') dt
                ORDER BY dt),
    bed_tree as (
        SELECT  distinct
                d.id as d_id,
                p.id as p_id,
                room.id as r_id,
                b.id as b_id,
                bp.id as bp_id,
                o.id AS org_id,
                cr.id AS care_regimen_id,
                nullif(g.id, 3) AS g_id,
                mbr.id as res_id,
                d.id :: TEXT :: LTREE || p.id :: TEXT || p.id :: TEXT || room.id :: TEXT || b.id :: TEXT AS bed_tree, -- для использования исключений
                -- добавляем из за return out
                case when sr.power > 0 then sr.power else 0 end as power,
                o.full_name AS org_name,
                cr.name AS care_regimen_name,
                b.number,
                d.name as d_name,
                p.name as p_name,
                rt.name as rt_name,
                room.name as pr_name,
                g.name as g_name,
                bp.name as bp_name,
                b.additional_bed
        FROM    param
                JOIN md_bed b on TRUE
                JOIN lateral (select mbr.id from md_bed_resource mbr where mbr.bed_id = b.id) mbr on TRUE
                JOIN LATERAL (select from pim_room_resource prr where prr.room_id = b.room_id limit 1) prr on true -- палата является ресурсом
                JOIN md_room mr ON b.room_id = mr.id
                JOIN pim_room room ON b.room_id = room.id and room.department_id = coalesce(nullif(in_department_id, -1), room.department_id)
                --join pim_room r on r.id = b.room_id
                JOIN pim_department d ON d.id = room.department_id
                JOIN md_department_profile dp ON d.id = dp.department_id
                JOIN md_profile p ON p.id = dp.profile_id and p.id = coalesce(nullif(in_profile_id, -1), p.id)
                JOIN pim_organization o on o.id = d.org_id and o.id = coalesce(nullif(in_org_id, -1), o.id )
                JOIN mc_care_regimen cr ON b.regimen_id = cr.id and b.regimen_id = coalesce(nullif(in_care_regimen_id, -1), b.regimen_id)
                JOIN pim_room_type rt ON room.type_id = rt.id
                JOIN md_bed_profile bp ON bp.id = b.bed_profile_id and bp.id = coalesce(nullif(in_bed_profile_id, -1), bp.id)
                LEFT OUTER JOIN pim_gender g ON room.gender_id = g.id
                LEFT JOIN sr_resource sr on sr.id = mbr.id
        WHERE   coalesce(g.id, -1) = coalesce(nullif(in_patient_sex_id, -1), g.id, -1)
        ),
    bed_room_profile as (
        select r.r_id, rp.profile_id from bed_tree r join md_room_profile rp on rp.room_id = r.r_id group by 1, 2
        ),
    bed_room_tree as (
        select distinct r.* from bed_tree r where not exists (select from bed_room_profile rp where rp.r_id = r.r_id)
        union all
        select distinct r.* from param join bed_tree r on true join bed_room_profile rp on r.r_id = rp.r_id and r.p_id = rp.profile_id and rp.profile_id = coalesce(nullif(in_profile_id, -1), rp.profile_id)
        )
    /*bed_used as (
        select  b, d.
        from    bed_room_tree b group by b_id, r_id, p_id, d_id, bed_tree)
                join generate_series(_from_dt::date, _to_dt::date, '1 day') dd(dt) on true
                left join hospital.unused_bed unused on b.bed_tree @> unused.bed_tree and unused.date_range @> dd.dt::date
        )*/


    SELECT -- группировка на уровне МО
        row_number() over() as id,
        t_mo.org_id, t_mo.org_name::character varying, null::int, null::character varying ,
        json_agg(dep_state ORDER BY dep_state)::character varying as mo_state
    from (
        SELECT -- группировка на уровне отделения
            t_dep.org_id, t_dep.org_name::character varying,
            jsonb_object('{dep_name, dep_id}',
                array[
                    dep_name,
                    dep_id::text
                   ]
                )
            ||jsonb_build_object('dep_state', json_agg(profile_state ORDER BY profile_state)) as dep_state
        from (
            SELECT -- группировка на уровне профиля
                t_profile.org_id, t_profile.org_name, t_profile.dep_id, t_profile.dep_name,
                jsonb_object('{profile_name, profile_id}',
                    array[
                        profile_name,
                        profile_id::text
                        ]
                    )
                ||jsonb_build_object('profile_state', json_agg(bed_profile_state ORDER BY bed_profile_state)) as profile_state
            from (
                SELECT -- группировка на уровне профиля коек
                    t_bed_profile.org_id, t_bed_profile.org_name, t_bed_profile.dep_id, t_bed_profile.dep_name, t_bed_profile.profile_id, t_bed_profile.profile_name,
                    jsonb_object('{bed_profile_name, bed_profile_id}',
                        array[
                            bed_profile_name,
                            bed_profile_id::text
                            ]
                        )
                        ||jsonb_build_object('bed_profile_state', json_agg(room_state ORDER BY room_state)) as bed_profile_state
                from (
                    SELECT -- группировка на уровне палат
                        t_room.org_id, t_room.org_name, t_room.dep_id, t_room.dep_name, t_room.profile_id, t_room.profile_name, t_room.bed_profile_id, t_room.bed_profile_name,
                        jsonb_object('{room_name, room_id, room_sex}',
                            array[
                                room_name,
                                room_id::text,
                                null::text
                                ]
                            )
                            ||jsonb_build_object('room_state', json_agg(bed_state ORDER BY bed_state)) as room_state
                    from ( -- группировка на уровне коек
                        SELECT
                            b.org_id,
                            b.org_name,
                            b.care_regimen_id,
                            b.care_regimen_name,
                            b.d_id AS dep_id,
                            b.d_name AS dep_name,
                            b.p_id AS profile_id,
                            b.p_name AS profile_name,
                            b.r_id AS room_id,
                            nullif(concat(nullif(regexp_replace(b.rt_name, '\s+$', ''), '') || ': ' ||
                                nullif(regexp_replace(b.pr_name, '\s+$', ''), ''),
                                ' (' || nullif(regexp_replace(left(b.g_name, 1), '\s+$', ''), '') || ')'), '') AS room_name,
                            b.bp_id AS bed_profile_id,
                            b.bp_name AS bed_profile_name,
                            b.b_id AS bed_id,
                            case when b.power > 0 then b.power else 0 end as bed_count_shift, -- общее количество смен согласно настройке
                            case b.additional_bed when true then coalesce(('Койка №' || nullif(regexp_replace(b.number, '\s+$', ''), '')),'койка без названия')||' (доп. койка)' else  coalesce(('Койка №' || nullif(regexp_replace(b.number, '\s+$', ''), '')),'койка без названия') end AS bed_name,
                            /*jsonb_build_object(
                                coalesce(('Койка №' || nullif(regexp_replace(b.number, '\s+$', ''), '')),'койка без названия')::text,
                                json_agg( -- группируем по одному дню все записи броней
                                    s.date_state
                                    )
                                ) as bed_state
                            */
                            jsonb_object('{bed_name, bed_id, bed_sex, bed_resource_id, bed_count_shift_max}',
                                array[
                                    (case b.additional_bed when true then coalesce(('Койка №' || nullif(regexp_replace(b.number, '\s+$', ''), '')),'койка без названия')||' (доп. койка)' else  coalesce(('Койка №' || nullif(regexp_replace(b.number, '\s+$', ''), '')),'койка без названия') end)::text,
                                        b.b_id::text,
                                        nullif(b.g_id, 3)::text,
                                        b.res_id::text,
                                        case when b.power > 0 then b.power::text else '0' end
                                    ]
                                ) ||
                                jsonb_build_object('bed_state', json_agg(s.date_state ORDER BY s.date_state)) as bed_state
                        FROM
                            param
                            JOIN bed_room_tree b ON TRUE
                            LEFT JOIN LATERAL ( -- группировка на уровне дат
                                SELECT
                                    b.b_id,
                                    ii.from_dt,
                                    jsonb_object('{date}',
                                        array[
                                            ii.from_dt::date::text
                                            ]
                                        )
                                    ||jsonb_build_object('state',
                                        json_agg( -- группируем по одному дню все записи броней
                                            jsonb_object( -- формируем статистику по одной брони в разрезе одного дня
                                                '{label, sex, type, count_shift, booking, seq}', -- сюда можно добавить любую статистику
                                                array[boo.patient_name, boo.patient_sex_id, boo.type, boo.count_shift, boo.boo_id, /*boo.rg_rel_id, */boo.seq]::text[]
                                                )
                                            order by boo.seq
                                            )
                                        ) as date_state
                                FROM
                                    interval_dt ii
                                    join lateral ( -- если есть step_id
                                        with w_busy_shift as (
                                            select
                                                bo.id as boo_id, -- все смены по которым указан step_id
                                                bo.rg_rel_id,
                                                b.b_id as b_id,
                                                b.bed_tree,
                                                ii.from_dt,
                                                i.id AS patient_id,
                                                nullif(concat(initcap(i.surname), ' ' || upper(left(i.name, 1)) || '.', ' ' || upper(left(i.patr_name, 1)) || '.'), '') AS patient_name,
                                                nullif(i.gender_id, 3) AS patient_sex_id,
                                                bsh.count_shift,
                                                'busy' AS type, -- независимо от статуса считаем что Бронь реализована
                                                case when ii.from_dt::date > bo.begin_dt::date then 0 else 1 end as is_begining_dt, -- эта запись первая в текущий день
                                                case when ii.from_dt::date < bo.end_dt::date then 1 else 0 end as is_ending_dt -- эта запись крайняя в текущий день
                                                    -- возможные варианты для is_begining_dt, is_ending_dt:
                                                    -- 00 запись началась раньше чем ii.from_dt и закончилась в этот день
                                                    -- 01 началась раньше ii.from_dt и закончилась позже чем ii.from_dt
                                                    -- 10 началась в ii.from_dt и закончилась в ii.from_dt
                                                    -- 11 началась в ii.from_dt и закончилась позже чем ii.from_dt
                                                    -- сортировка такая: 00, 10, 01, 11, следовательно сортируем по is_ending_dt, is_begining_dt
                                            from
                                                hospital.booking bo
                                                join hospital.booking_status bs ON bo.status_id = bs.id
                                                join mc_step s ON s.id = bo.step_id
                                                JOIN mc_case mc ON mc.id = s.case_id
                                                JOIN pim_individual i ON mc.patient_id = i.id
                                                LEFT JOIN LATERAL (
                                                    SELECT sum(bsh.count_shift) AS count_shift
                                                    FROM hospital.booking_shift bsh
                                                    WHERE bsh.booking_id = bo.id and bsh.dt = ii.from_dt) bsh ON TRUE
                                            where
                                                bo.bed_id = b.b_id AND ii.from_dt :: DATE BETWEEN bo.begin_dt AND bo.end_dt
                                                and coalesce(bo.isCurrent, true) = true
                                            UNION ALL -- нет step_id, но есть reservation_id
                                            select
                                                bo.id as boo_id,
                                                bo.rg_rel_id,
                                                b.b_id as b_id,
                                                b.bed_tree,
                                                ii.from_dt,
                                                i.id AS patient_id,
                                                nullif(concat(initcap(i.surname), ' ' || upper(left(i.name, 1)) || '.', ' ' || upper(left(i.patr_name, 1)) || '.'), '') AS patient_name,
                                                nullif(i.gender_id, 3) AS patient_sex_id,
                                                bsh.count_shift,
                                                case bs.code
                                                    when '1' then 'extra'
                                                    when '2' then 'unconf'
                                                    when '3' then 'conf'
                                                    when '5' then 'busy'
                                                    else 'free'
                                                end as type,
                                                case when ii.from_dt::date > bo.begin_dt::date then 0 else 1 end as is_begining_dt, -- эта запись первая в текущий день
                                                case when ii.from_dt::date < bo.end_dt::date then 1 else 0 end as is_ending_dt -- эта запись крайняя в текущий день
                                            from
                                                hospital.booking bo
                                                join hospital.booking_status bs ON bo.status_id = bs.id and bs.code in (values('1'), ('2'), ('3')) -- на рассмотрении только три статуса с бронью
                                                join hsp_reservation hsr ON hsr.id = nullif(bo.reservation_id, 0) --and hsr.bed_profile_id = bp.id
                                                JOIN md_referral mref ON mref.id = hsr.referral_id
                                                JOIN pim_individual i on i.id = mref.patient_id
                                                LEFT JOIN LATERAL (
                                                    SELECT sum(bsh.count_shift) AS count_shift
                                                    FROM hospital.booking_shift bsh
                                                    WHERE bsh.booking_id = bo.id and bsh.dt = ii.from_dt) bsh ON TRUE
                                            where
                                                bo.bed_id = b.b_id AND ii.from_dt :: DATE BETWEEN bo.begin_dt AND bo.end_dt
                                                and bo.step_id is null
                                                and coalesce(bo.isCurrent, true) = true
                                            UNION ALL -- все смены без указанных step_id и reservation_id
                                            select
                                                bo.id as boo_id,
                                                bo.rg_rel_id,
                                                b.b_id as b_id,
                                                b.bed_tree,
                                                ii.from_dt,
                                                null AS patient_id,
                                                null AS patient_name,
                                                null AS patient_sex_id,
                                                bsh.count_shift,
                                                case bs.code
                                                    when '1' then 'extra'
                                                    when '2' then 'unconf'
                                                    when '3' then 'conf'
                                                    when '5' then 'busy'
                                                    else 'free'
                                                end as type,
                                                case when ii.from_dt::date > bo.begin_dt::date then 0 else 1 end as is_begining_dt, -- эта запись первая в текущий день
                                                case when ii.from_dt::date < bo.end_dt::date then 1 else 0 end as is_ending_dt -- эта запись крайняя в текущий день
                                            from
                                                hospital.booking bo
                                                join hospital.booking_status bs ON bo.status_id = bs.id and bs.code in (values('1'), ('2'), ('3')) -- на рассмотрении только три статуса с бронью
                                                join lateral (
                                                     SELECT sum(bsh.count_shift) AS count_shift
                                                     FROM hospital.booking_shift bsh
                                                     WHERE bsh.booking_id = bo.id and bsh.dt = ii.from_dt) bsh on true
                                            where
                                                bo.step_id is null and nullif(bo.reservation_id, 0) is null
                                                and bo.bed_id = b.b_id AND ii.from_dt :: DATE BETWEEN bo.begin_dt AND bo.end_dt
                                                and coalesce(bo.isCurrent, true) = true
                                            )
                                        select
                                            row_number() over (partition by b_id, from_dt order by is_begining_dt, is_ending_dt) as seq,
                                            boo_id,
                                            rg_rel_id,
                                            b.b_id,
                                            from_dt,
                                            patient_id,
                                            --coalesce(u.comment, patient_name) AS patient_name,
                                            patient_name,
                                            patient_sex_id,
                                            count_shift,
                                            --coalesce(u.type, type) as type,
                                            w.type,
                                            is_begining_dt,
                                            is_ending_dt
                                        from
                                            w_busy_shift w
                                            left join lateral (select 'unused'::text as type, u.comment from hospital.unused_bed u where u.bed_tree @> w.bed_tree and u.date_range @> w.from_dt::date order by nlevel(u.bed_tree) limit 1) u on true
                                        union all -- добавляем свободные смены на остаток от койкасмен из настройки минус занятых койкосмен (кроме ИСКЛЮЧЕНИЙ)
                                        select
                                            9998,
                                            null,
                                            null,
                                            b.b_id,
                                            ii.from_dt,
                                            null AS patient_id,
                                            u.comment AS patient_name,
                                            null AS patient_sex_id,
                                            b.power - coalesce(w.count_shift,0) as count_shift,
                                            coalesce(u.type, 'free'::text) as type,
                                            null,
                                            null
                                        from
                                            lateral (select sum(w.count_shift) as count_shift from w_busy_shift w where w.from_dt = ii.from_dt and w.b_id = b.b_id) w
                                            --join hospital.used_bed_tree ub on ub.bed_id = b.b_id
                                            left join lateral (select 'unused'::text as type, u.comment from hospital.unused_bed u where u.bed_tree @> b.bed_tree and u.date_range @> ii.from_dt::date order by nlevel(u.bed_tree) limit 1) u on true
                                        where
                                            b.power > 0
                                            and b.power - coalesce(w.count_shift,0) > 0
                                        union all -- добавляем первую СВОБОДНУЮ смену на случай когда мощность койки = 1 и на начало смены нет БРОНИ стартовавшей раньше dt
                                            -- в случае если за текущий день есть экстренная бронь СВОБОДНУЮ смену на начало дня не добавляем (MEDDEV-6992)
                                        select
                                            0,
                                            null,
                                            null,
                                            b.b_id,
                                            ii.from_dt,
                                            null AS patient_id,
                                            u.comment AS patient_name,
                                            null AS patient_sex_id,
                                            1 as count_shift,
                                            coalesce(u.type, 'free'::text) as type,
                                            0,
                                            0
                                        from param
                                            left join lateral (select 'unused'::text as type, u.comment from hospital.unused_bed u where u.bed_tree @> b.bed_tree and u.date_range @> ii.from_dt::date order by nlevel(u.bed_tree) limit 1) u on true
                                        where
                                            not exists (
                                                select 1 as is_begining
                                                from w_busy_shift w
                                                where
                                                    w.from_dt = ii.from_dt
                                                    and w.b_id = b.b_id
                                                    and w.is_begining_dt = 0)
                                            and not exists (select true as check_extra from w_busy_shift w where w.from_dt = ii.from_dt and w.b_id = b.b_id and w.type = 'extra' and w.count_shift>0)
                                        union all -- добавляем КРАЙНЮЮ СВОБОДНУЮ смену на случай когда мощность койки = 1 и на конец смены нет брони завершающающая после dt, и на эту дату нет броней
                                            -- в случае если за текущий день есть экстренная бронь СВОБОДНУЮ смену на конец дня не добавляем (MEDDEV-6992)
                                        select
                                            9999,
                                            null,
                                            null,
                                            b_id,
                                            ii.from_dt,
                                            null AS patient_id,
                                            u.comment AS patient_name,
                                            null AS patient_sex_id,
                                            1 as count_shift,
                                            coalesce(u.type, 'free'::text) as type,
                                            0,
                                            0
                                        from param
                                            left join lateral (select 'unused'::text as type, u.comment from hospital.unused_bed u where u.bed_tree @> b.bed_tree and u.date_range @> ii.from_dt::date limit 1) u on true
                                        where
                                            not exists (
                                                select 1 as is_begining
                                                from w_busy_shift w
                                                where w.from_dt = ii.from_dt
                                                      and w.b_id = b.b_id
                                                      and w.is_ending_dt = 1)
                                            and exists (select 1 from w_busy_shift w where w.from_dt = ii.from_dt and w.b_id = b.b_id)
                                            and not exists (select true as check_extra from w_busy_shift w where w.from_dt = ii.from_dt and w.b_id = b.b_id and w.type = 'extra' and w.count_shift>0)
                                            --and not exists (select 1 as is_begining from w_busy_shift w where w.from_dt = ii.from_dt and w.b_id = b.b_id)
                                            --and not exists (select 1 as is_begining from w_busy_shift w where w.from_dt = ii.from_dt and w.b_id = b.b_id and w.is_begining_dt = 0 and w.is_ending_dt = 1)
                                    )boo on true
                                group by b.b_id, ii.from_dt
                                )s on true
                        WHERE   TRUE
                            --b.room_id BETWEEN 162 AND 200/*roomId*/ --AND :where
                            ---b.org_id = coalesce(nullif(param.in_org_id, -1), o.id )
                            ---AND b.regimen_id = coalesce(nullif(param.in_care_regimen_id, -1), b.regimen_id)
                            ---AND pr.department_id = coalesce(nullif(param.in_department_id, -1), pr.department_id)
                            ---AND p.id = coalesce(nullif(param.in_profile_id, -1), p.id)
                            ---AND bp.id = coalesce(nullif(param.in_bed_profile_id, -1), bp.id)
                            ---and coalesce(g.id, -1) = coalesce(nullif(param.in_patient_sex_id, -1), g.id, -1)
                        group by b.org_id,
                            b.org_name,
                            b.care_regimen_id,
                            b.care_regimen_name,
                            b.d_id,
                            b.d_name,
                            b.p_id,
                            b.p_name,
                            b.r_id,
                            nullif(concat(nullif(regexp_replace(b.rt_name, '\s+$', ''), '') || ': ' ||
                                nullif(regexp_replace(b.pr_name, '\s+$', ''), ''),
                                ' (' || nullif(regexp_replace(left(b.g_name, 1), '\s+$', ''), '') || ')'), ''),
                            b.bp_id,
                            b.bp_name,
                            b.b_id,
                            b.power, -- общее количество смен согласно настройке
                            coalesce(('Койка №' || nullif(regexp_replace(b.number, '\s+$', ''), '')),'койка без названия'),
                            b.g_id,
                            b.res_id,
                            b.additional_bed
                           --ORDER BY 1 ASC
                        )t_room
                    group by t_room.org_id, t_room.org_name, t_room.dep_id, t_room.dep_name, t_room.profile_id, t_room.profile_name, t_room.bed_profile_id, t_room.bed_profile_name, t_room.room_name, t_room.room_id
                    )t_bed_profile
                group by t_bed_profile.org_id, t_bed_profile.org_name, t_bed_profile.dep_id, t_bed_profile.dep_name, t_bed_profile.profile_id, t_bed_profile.profile_name, t_bed_profile.bed_profile_id, t_bed_profile.bed_profile_name
                )t_profile
            group by t_profile.org_id, t_profile.org_name, t_profile.dep_id, t_profile.dep_name, t_profile.profile_id, t_profile.profile_name
            )t_dep
        group by t_dep.org_id, t_dep.org_name, t_dep.dep_id, t_dep.dep_name
        )t_mo
    group by t_mo.org_id, t_mo.org_name;
    end;
$$;

