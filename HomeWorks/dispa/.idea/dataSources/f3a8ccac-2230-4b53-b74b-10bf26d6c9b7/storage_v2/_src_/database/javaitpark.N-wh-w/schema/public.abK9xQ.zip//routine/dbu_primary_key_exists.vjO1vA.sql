CREATE FUNCTION dbu_primary_key_exists(pkname character varying, tablename character varying)
  RETURNS boolean
LANGUAGE plpgsql
AS $$
declare result boolean;
            begin

            select count(*) > 0 into result
            from pg_constraint
            inner join pg_class table_owner on pg_constraint.conrelid = table_owner.oid
            inner join pg_namespace on pg_constraint.connamespace = pg_namespace.oid
            and pg_namespace.nspname !~ '^(pg_|information_schema)'
            where pg_constraint.contype = 'p'
            and pg_constraint.conname = lower($1)
            and table_owner.relname = lower($2);

            return result;
            end;
$$;

