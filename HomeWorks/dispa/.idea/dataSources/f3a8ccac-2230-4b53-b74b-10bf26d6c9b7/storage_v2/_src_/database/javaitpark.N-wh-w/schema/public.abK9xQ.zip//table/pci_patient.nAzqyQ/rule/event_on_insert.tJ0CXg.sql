CREATE RULE event_on_insert AS
    ON INSERT TO public.pci_patient DO ( INSERT INTO event_handler.db_event_log (id, event_code, create_event_time, params)  SELECT nextval('event_handler.db_event_log_seq'::regclass) AS nextval,
            'PUBLIC.PCI_PATIENT|INSERT',
            now() AS now,
            row_to_json(new.*) AS row_to_json
          WHERE (current_setting('app.source'::text) <> 'DB'::text);
 SELECT pg_notify('db_event'::text, ('PUBLIC.PCI_PATIENT|INSERT^'::text || currval('event_handler.db_event_log_seq'::regclass))) AS pg_notify
  WHERE (current_setting('app.source'::text) <> 'DB'::text);
);

