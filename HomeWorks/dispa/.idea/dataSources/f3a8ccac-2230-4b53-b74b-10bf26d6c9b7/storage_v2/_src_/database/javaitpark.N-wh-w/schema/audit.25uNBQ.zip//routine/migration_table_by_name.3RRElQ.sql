CREATE FUNCTION migration_table_by_name(_name character varying)
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
  _table_id INT;
BEGIN
  _name = lower(_name);

  IF _name NOT LIKE '%.%' THEN _name = concat('public.', _name); END IF;

  SELECT id
  INTO _table_id
  FROM audit.migration_table
  WHERE status_id IN (SELECT id
                      FROM audit.migration_table_status
                      WHERE code IN ('NOT_PROCESSED', 'ERROR')
  ) AND _name = table_name;

  IF _table_id ISNULL THEN RAISE EXCEPTION 'Migration table not found'; END IF;

  EXECUTE audit.migration_table_by_id(_table_id);
END;
$$;

