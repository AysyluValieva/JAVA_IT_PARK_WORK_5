CREATE FUNCTION deleteindividual(xid integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
begin
                delete from pim_indiv_code where indiv_id = xid;
                delete from pim_indiv_doc where indiv_id = xid;
                delete from pim_indiv_contact where indiv_id = xid;
                delete from pim_workplace where indiv_id = xid;
                delete from pci_patient where id = xid;
                delete from pim_individual where id = xid;
                delete from pim_party where id = xid;
                return null;
            end;
$$;

