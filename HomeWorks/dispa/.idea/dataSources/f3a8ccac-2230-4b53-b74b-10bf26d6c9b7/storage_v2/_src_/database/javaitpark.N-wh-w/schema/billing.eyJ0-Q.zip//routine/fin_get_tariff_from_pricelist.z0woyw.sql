CREATE FUNCTION fin_get_tariff_from_pricelist(p1_srv_rendered_id integer, p2_position_id integer, OUT tariff numeric, OUT code text, OUT name text, OUT is_from_mod boolean)
  RETURNS record
STABLE
STRICT
LANGUAGE plpgsql
AS $$
DECLARE 
    _rec RECORD;
    _price_list_id INTEGER;
BEGIN
    /*
        version: 2015-06-03
    */
    SELECT 
        coalesce (p.price, 0), coalesce (trim (p.code), ''), coalesce (trim (p.name), ''), FALSE, price_list_id INTO STRICT tariff, code, name, is_from_mod, _price_list_id
    FROM 
        public.fin_pl_position AS p
    WHERE 
        p.id = p2_position_id
    ;
    FOR _rec IN 
        SELECT 
            m.condition, m.type, m.value, m.code, m.name, m.id
        FROM 
            public.fin_price_modifier               AS m
            LEFT JOIN public.fin_modifier_to_pl_pos AS t ON t.pl_position_id = p2_position_id AND t.price_modifier_id = m.id
        WHERE 
            m.price_list_id = _price_list_id AND (m.scope_id = 1 OR (m.scope_id = 2 AND t.id IS NOT NULL))
        ORDER BY m.apply_order, m.id
    LOOP
        BEGIN
            IF 
                billing.fin_price_modifier_need_apply (p1_srv_rendered_id, _rec.condition) 
            THEN
                IF    _rec.type = 1 THEN tariff := tariff * cast (_rec.value AS DECIMAL); code := _rec.code; name := _rec.name; is_from_mod := TRUE;
                ELSIF _rec.type = 2 THEN tariff := tariff + cast (_rec.value AS DECIMAL); code := _rec.code; name := _rec.name; is_from_mod := TRUE;
                ELSIF _rec.type = 3 THEN tariff := cast (_rec.value AS DECIMAL); code := _rec.code; name := _rec.name; is_from_mod := TRUE;
                ELSIF _rec.type = 4 THEN EXECUTE replace (_rec.value::TEXT, '?', p1_srv_rendered_id::TEXT) INTO tariff; code := _rec.code; name := _rec.name; is_from_mod := TRUE;
                END IF;
            END IF;
        EXCEPTION
            WHEN SQLSTATE '42601' THEN RAISE EXCEPTION USING MESSAGE = concat ('Ошибка в SQL коде модификатора с названием "', _rec.name, '" и id = ', _rec.id);
        END;
    END LOOP;
END;
$$;

