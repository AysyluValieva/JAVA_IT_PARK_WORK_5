CREATE FUNCTION get_audit_periods_count_by_filters(_table_setting_id integer, _record_id character varying)
  RETURNS bigint
LANGUAGE plpgsql
AS $$
DECLARE
                  base_query    VARCHAR;
                  error_message VARCHAR;
                  count_record  INTEGER;
                BEGIN
                  BEGIN
                    base_query = audit.get_audit_periods_by_filters_query(_table_setting_id, _record_id);
                    EXCEPTION
                    WHEN raise_exception
                      THEN
                        GET STACKED DIAGNOSTICS error_message = MESSAGE_TEXT;
                        IF error_message = 'BAD_REQUEST'
                        THEN
                          RETURN 0 :: BIGINT;
                        ELSEIF error_message = 'ALL_TIME'
                          THEN
                            RETURN 1 :: BIGINT;
                        END IF;
                  END;

                  base_query = replace(base_query, ':select', 'count(*)');

                  EXECUTE base_query INTO count_record;

                  RETURN count_record :: BIGINT;
                END;
$$;

