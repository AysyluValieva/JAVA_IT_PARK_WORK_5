CREATE FUNCTION fin_spec_validate_patients(p1_bill_id integer, p2_user_id integer)
  RETURNS void
STRICT
LANGUAGE plpgsql
AS $$
DECLARE
    _r RECORD;
    _v VARCHAR;
    _validation_representative_code VARCHAR[];
    _validation_representative_enabled BOOLEAN[];
    _validation_representative_title VARCHAR[];
    _validation_docs_code VARCHAR[];
    _validation_docs_enabled BOOLEAN[];
    _validation_docs_title VARCHAR[];
    _validation_patient_code VARCHAR[];
    _validation_patient_enabled BOOLEAN[];
    _validation_patient_title VARCHAR[];
BEGIN
    /*
        version: 2015-07-01
    */
    --representative
    _validation_representative_code := ARRAY 
    [
        'ATTENDANT_IS_REQUIRED',            --1
        'ATTENDANT_SURNAME_IS_EMPTY',       --2
        'ATTENDANT_SURNAME_MAX_LENGTH',     --3
        'ATTENDANT_NAME_IS_EMPTY',          --4
        'ATTENDANT_NAME_MAX_LENGTH',        --5
        'ATTENDANT_PATRONYMIC_IS_EMPTY',    --6
        'ATTENDANT_PATRONYMIC_MAX_LENGTH'   --7
    ];
    FOREACH _v IN ARRAY _validation_representative_code 
    LOOP 
        SELECT 
            coalesce (u.enabled, v.enabled) AS enabled, title INTO _r 
        FROM 
            public.fin_bill_validation                AS v 
            LEFT JOIN public.fin_bill_validation_user AS u ON u.validation_id = v.id AND u.user_id = p2_user_id
        WHERE 
            v.code = _v;
        _validation_representative_enabled := _validation_representative_enabled || _r.enabled;
        _validation_representative_title   := _validation_representative_title   || _r.title  ;
    END LOOP;
    --docs
    _validation_docs_code := ARRAY 
    [
        'NO_IDENTITY',                  --1
        'IDENTITY_SERIES_REQUIRED',     --2
        'IDENTITY_SERIES_MAX_LENGTH',   --3
        'IDENTITY_NUMBER_MAX_LENGTH',   --4
        'SNILS_LENGTH'                  --5
    ];
    FOREACH _v IN ARRAY _validation_docs_code 
    LOOP 
        SELECT 
            coalesce (u.enabled, v.enabled) AS enabled, title INTO _r 
        FROM 
            public.fin_bill_validation                AS v 
            LEFT JOIN public.fin_bill_validation_user AS u ON u.validation_id = v.id AND u.user_id = p2_user_id
        WHERE 
            v.code = _v;
        _validation_docs_enabled := _validation_docs_enabled || _r.enabled;
        _validation_docs_title   := _validation_docs_title   || _r.title  ;
    END LOOP;
    --patient
    _validation_patient_code := ARRAY 
    [
        'PATIENT_IS_NULL',                  --1
        'PATIENT_SURNAME_IS_REQUIRED',      --2
        'PATIENT_SURNAME_MAX_LENGTH',       --3
        'PATIENT_NAME_IS_REQUIRED',         --4
        'PATIENT_NAME_MAX_LENGTH',          --5
        'PATIENT_PATRONYMIC_IS_REQUIRED',   --6
        'PATIENT_PATRONYMIC_MAX_LENGTH',    --7
        'PATIENT_GENDER_IS_NULL',           --8
        'PATIENT_BIRTH_DATE_IS_NULL'        --9
    ];
    FOREACH _v IN ARRAY _validation_patient_code 
    LOOP 
        SELECT 
            coalesce (u.enabled, v.enabled) AS enabled, title INTO _r 
        FROM 
            public.fin_bill_validation                AS v 
            LEFT JOIN public.fin_bill_validation_user AS u ON u.validation_id = v.id AND u.user_id = p2_user_id
        WHERE 
            v.code = _v;
        _validation_patient_enabled := _validation_patient_enabled || _r.enabled;
        _validation_patient_title   := _validation_patient_title   || _r.title  ;
    END LOOP;
    
    DELETE FROM public.fin_bill_spec_item_error AS e USING public.fin_bill_spec_item AS i 
    WHERE 
        i.bill_id = p1_bill_id AND i.id = e.item_id AND e.code = ANY (_validation_representative_code || _validation_docs_code || _validation_patient_code) 
    ;
    FOR _r IN 
        SELECT 
            patient_id, new_born, 
            pat_surname, pat_name, pat_patr_name, pat_gender_code, pat_birth_dt, 
            pat_identity_type, pat_identity_series, pat_identity_number, pat_snils, pat_os_sluch, 
            representative_id, 
            rep_surname, rep_name, rep_patr_name, 
            rep_identity_type, rep_identity_series, rep_identity_number, rep_snils, rep_os_sluch, 
            item_id_arr,
            ARRAY (SELECT type::TEXT FROM billing.fin_bill_policy WHERE bill_id = p1_bill_id AND customer_id = coalesce (p.representative_id, p.patient_id)) AS policy_types
        FROM 
            billing.fin_bill_patients AS p
        WHERE
            bill_id = p1_bill_id
    LOOP
        ---------------------------------------------------------------------------------------------------------------------------------------------
        --representative
        IF 
            _validation_representative_enabled[1] AND _r.representative_id IS NULL AND _r.new_born
        THEN 
            INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id)
                SELECT nextval ('public.fin_bill_spec_item_error_seq'), _validation_representative_title[1], 'ATTENDANT_IS_REQUIRED', unnest (_r.item_id_arr)
            ;
        ELSE 
            IF 
                _validation_representative_enabled[2] AND _r.rep_surname = '' AND _r.new_born AND '02' <> ALL (_r.rep_os_sluch)
            THEN 
                INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id)
                    SELECT nextval ('public.fin_bill_spec_item_error_seq'), _validation_representative_title[2], 'ATTENDANT_SURNAME_IS_EMPTY', unnest (_r.item_id_arr)
                ;
            ELSIF 
                _validation_representative_enabled[3] AND length (_r.rep_surname) > 40 AND _r.new_born
            THEN 
                INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id)
                    SELECT nextval ('public.fin_bill_spec_item_error_seq'), _validation_representative_title[3], 'ATTENDANT_SURNAME_MAX_LENGTH', unnest (_r.item_id_arr)
                ;
            END IF;
            IF 
                _validation_representative_enabled[4] AND _r.rep_name = '' AND _r.new_born AND '03' <> ALL (_r.rep_os_sluch)
            THEN 
                INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id)
                    SELECT nextval ('public.fin_bill_spec_item_error_seq'), _validation_representative_title[4], 'ATTENDANT_NAME_IS_EMPTY', unnest (_r.item_id_arr)
                ;
            ELSIF 
                _validation_representative_enabled[5] AND length (_r.rep_name) > 40 AND _r.new_born
            THEN 
                INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id)
                    SELECT nextval ('public.fin_bill_spec_item_error_seq'), _validation_representative_title[5], 'ATTENDANT_NAME_MAX_LENGTH', unnest (_r.item_id_arr)
                ;
            END IF;
            IF 
                _validation_representative_enabled[6] AND _r.rep_patr_name = '' AND _r.new_born AND '2' <> ALL (_r.rep_os_sluch)
            THEN 
                INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id)
                    SELECT nextval ('public.fin_bill_spec_item_error_seq'), _validation_representative_title[6], 'ATTENDANT_PATRONYMIC_IS_EMPTY', unnest (_r.item_id_arr)
                ;
            ELSIF 
                _validation_representative_enabled[7] AND length (_r.rep_patr_name) > 40 AND _r.new_born
            THEN 
                INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id)
                    SELECT nextval ('public.fin_bill_spec_item_error_seq'), _validation_representative_title[7], 'ATTENDANT_PATRONYMIC_MAX_LENGTH', unnest (_r.item_id_arr)
                ;
            END IF;
        END IF;
        ---------------------------------------------------------------------------------------------------------------------------------------------
        --docs
        IF
            NOT (_r.policy_types && ARRAY ['ENP', 'MHI_UNIFORM']) AND '7' <> ALL (CASE WHEN _r.new_born THEN _r.rep_os_sluch ELSE _r.pat_os_sluch END)
        THEN
            IF 
                _validation_docs_enabled[1] AND (CASE WHEN _r.new_born THEN _r.rep_identity_type ELSE _r.pat_identity_type END) IS NULL
            THEN 
                INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id)
                    SELECT nextval ('public.fin_bill_spec_item_error_seq'), _validation_docs_title[1], 'NO_IDENTITY', unnest (_r.item_id_arr)
                ;
            ELSE
                IF 
                    _validation_docs_enabled[2] AND (CASE WHEN _r.new_born THEN _r.rep_identity_series ELSE _r.pat_identity_series END) = ''
                THEN 
                    INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id)
                        SELECT nextval ('public.fin_bill_spec_item_error_seq'), _validation_docs_title[2], 'IDENTITY_SERIES_REQUIRED', unnest (_r.item_id_arr)
                    ;
                ELSIF 
                    _validation_docs_enabled[3] AND (CASE WHEN _r.new_born THEN length (_r.rep_identity_series) ELSE length (_r.pat_identity_series) END) > 10
                THEN 
                    INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id)
                        SELECT nextval ('public.fin_bill_spec_item_error_seq'), _validation_docs_title[3], 'IDENTITY_SERIES_MAX_LENGTH', unnest (_r.item_id_arr)
                    ;
                END IF;
                IF 
                    _validation_docs_enabled[4] AND (CASE WHEN _r.new_born THEN length (_r.rep_identity_number) ELSE length (_r.pat_identity_number) END) > 20
                THEN 
                    INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id)
                        SELECT nextval ('public.fin_bill_spec_item_error_seq'), _validation_docs_title[4], 'IDENTITY_NUMBER_MAX_LENGTH', unnest (_r.item_id_arr)
                    ;
                END IF;
            END IF;
        END IF;
        IF 
            _validation_docs_enabled[5] AND (CASE WHEN _r.new_born THEN length (_r.rep_snils) ELSE length (_r.pat_snils) END) NOT IN (0, 14)
        THEN 
            INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id)
                SELECT nextval ('public.fin_bill_spec_item_error_seq'), _validation_docs_title[5], 'SNILS_LENGTH', unnest (_r.item_id_arr)
            ;
        END IF;
        ---------------------------------------------------------------------------------------------------------------------------------------------
        --patient
        IF 
            _validation_patient_enabled[1] AND _r.patient_id IS NULL 
        THEN 
            INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id)
                SELECT nextval ('public.fin_bill_spec_item_error_seq'), _validation_patient_title[1], 'PATIENT_IS_NULL', unnest (_r.item_id_arr)
            ;
        ELSE 
            IF 
                _validation_patient_enabled[2] AND _r.pat_surname = '' AND NOT _r.new_born AND '02' <> ALL (_r.pat_os_sluch)
            THEN 
                INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id)
                    SELECT nextval ('public.fin_bill_spec_item_error_seq'), _validation_patient_title[2], 'PATIENT_SURNAME_IS_REQUIRED', unnest (_r.item_id_arr)
                ;
            ELSIF 
                _validation_patient_enabled[3] AND length (_r.pat_surname) > 40 AND NOT _r.new_born
            THEN 
                INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id)
                    SELECT nextval ('public.fin_bill_spec_item_error_seq'), _validation_patient_title[3], 'PATIENT_SURNAME_MAX_LENGTH', unnest (_r.item_id_arr)
                ;
            END IF;
            IF 
                _validation_patient_enabled[4] AND _r.pat_name = '' AND NOT _r.new_born AND '03' <> ALL (_r.pat_os_sluch)
            THEN 
                INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id)
                    SELECT nextval ('public.fin_bill_spec_item_error_seq'), _validation_patient_title[4], 'PATIENT_NAME_IS_REQUIRED', unnest (_r.item_id_arr)
                ;
            ELSIF 
                _validation_patient_enabled[5] AND length (_r.pat_name) > 40 AND NOT _r.new_born
            THEN 
                INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id)
                    SELECT nextval ('public.fin_bill_spec_item_error_seq'), _validation_patient_title[5], 'PATIENT_NAME_MAX_LENGTH', unnest (_r.item_id_arr)
                ;
            END IF;
            IF 
                _validation_patient_enabled[6] AND _r.pat_patr_name = '' AND NOT _r.new_born AND '2' <> ALL (_r.pat_os_sluch)
            THEN 
                INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id)
                    SELECT nextval ('public.fin_bill_spec_item_error_seq'), _validation_patient_title[6], 'PATIENT_PATRONYMIC_IS_REQUIRED', unnest (_r.item_id_arr)
                ;
            ELSIF 
                _validation_patient_enabled[7] AND length (_r.pat_patr_name) > 40 AND NOT _r.new_born
            THEN
                INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id)
                    SELECT nextval ('public.fin_bill_spec_item_error_seq'), _validation_patient_title[7], 'PATIENT_PATRONYMIC_MAX_LENGTH', unnest (_r.item_id_arr)
                ;
            END IF;
            IF 
                _validation_patient_enabled[8] AND _r.pat_gender_code = '' OR _r.pat_gender_code = 'UNKNOWN'
            THEN
                INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id)
                    SELECT nextval ('public.fin_bill_spec_item_error_seq'), _validation_patient_title[8], 'PATIENT_GENDER_IS_NULL', unnest (_r.item_id_arr)
                ;
            END IF;
            IF 
                _validation_patient_enabled[9] AND _r.pat_birth_dt IS NULL 
            THEN 
                INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id)
                    SELECT nextval ('public.fin_bill_spec_item_error_seq'), _validation_patient_title[9], 'PATIENT_BIRTH_DATE_IS_NULL', unnest (_r.item_id_arr)
                ;
            END IF;
        END IF;
    END LOOP;
END;
$$;

