CREATE FUNCTION search_team_job_status(xtjid integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
    xtime timestamp;
    cs record;
    xstatus integer;
    xstath integer;
  begin
    select into xstath,xtime,xstatus id,date_time,job_status_id
    	from amb.sr_res_team_job_status_history where team_job_id = xtjid order by date_time asc limit 1;
    for cs in
    	select id,date_time,job_status_id from amb.sr_res_team_job_status_history where team_job_id = xtjid order by date_time asc
    loop
        if (cs.date_time >= xtime) and (cs.job_status_id <> xstatus)
        THEN
        	xtime = cs.date_time;
            xstatus = cs.job_status_id;
            xstath = cs.id;
        end if;
    end loop;
    return xstath;
  end;
$$;

