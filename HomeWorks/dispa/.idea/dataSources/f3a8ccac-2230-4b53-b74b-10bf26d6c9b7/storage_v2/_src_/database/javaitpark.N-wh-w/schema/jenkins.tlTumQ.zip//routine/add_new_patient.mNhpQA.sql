CREATE FUNCTION add_new_patient(_birth_dt character varying, _surname character varying, _name character varying, _patr_name character varying, _snils character varying)
  RETURNS integer
LANGUAGE plpgsql
AS $$
DECLARE
  _r RECORD;
  _patient_id_result integer;
    _id_doc integer;
    _code_id INTEGER;
BEGIN
    _patient_id_result=null;
if exists (select 1 from pim_individual_doc where regexp_replace(number, '-|\s|\/|\\', '', 'g') = regexp_replace(_snils, '-|\s|\/|\\', '', 'g'))
then
        select indiv_id into _patient_id_result from pim_individual_doc where regexp_replace(number, '-|\s|\/|\\', '', 'g') = regexp_replace(_snils, '-|\s|\/|\\', '', 'g') limit 1;   
        RETURN _patient_id_result;
end if;
 
if exists (select 1 from pim_individual where upper(name)=upper(_name) and upper(surname)=upper(_surname)  and upper(patr_name)=upper(_patr_name) and birth_dt=_birth_dt::date)
then
        select id into _patient_id_result
                    from pim_individual
                            where upper(name)=upper(_name) and upper(surname)=upper(_surname)  and upper(patr_name)=upper(_patr_name) and birth_dt=_birth_dt::date limit 1;
        --РґРѕР±Р°РІРёС‚СЊ РµРЅРї РёР»Рё РѕР±РЅРѕРІРёС‚СЊ
        if(exists(select 1 from pim_individual_doc
                                                        where regexp_replace(number, '-|\s|\/|\\', '', 'g') <> regexp_replace(_snils, '-|\s|\/|\\', '', 'g')
                                                                    and indiv_id=_patient_id_result
                                                                    and type_id=26
                                )
            )
        then
            update pim_individual_doc set number=_snils where indiv_id=_patient_id_result and type_id=26;
            update pim_indiv_code set code=_snils where  indiv_id=_patient_id_result and type_id=3;
        else
                _code_id=nextval('"public"."pim_indiv_code_id_seq"');
            insert into pim_indiv_code (id, code, type_id, indiv_id)
                    values(_code_id, _snils, 3, _patient_id_result);
            insert into pim_individual_doc (id, type_id, number, indiv_id,code_id)
                values (_id_doc, 26, _snils, _patient_id_result,_code_id );
        end if;
        RETURN _patient_id_result;
end if;
        --РґРѕР±Р°РІРёС‚СЊ РїР°С†РёРµРЅС‚Р°
    _patient_id_result=nextval('pim_party_id_seq');
    _id_doc = nextval('pim_individual_doc_id_seq');
    insert into pim_party(id, type_id )
            values(_patient_id_result,1 );
    insert into pim_individual (id, surname, name, patr_name, birth_dt)
            values(_patient_id_result, _surname, _name, _patr_name, _birth_dt::date);
    insert into pim_indiv_code (id, code, type_id, indiv_id)
                    values(nextval('"public"."pim_indiv_code_id_seq"'), "public"."random_string"(16), 8, _patient_id_result);
--РґРѕР±Р°РІРёС‚СЊ РґРѕРєСѓРјРµРЅС‚
    if(_snils is not null and _snils <> '')
        then
            _code_id=nextval('"public"."pim_indiv_code_id_seq"');
            insert into pim_indiv_code (id, code, type_id, indiv_id)
                    values(_code_id, _snils, 3, _patient_id_result);
            insert into pim_individual_doc (id, type_id, number, indiv_id,code_id)
                values (_id_doc, 26, _snils, _patient_id_result,_code_id );
        end if;
    insert into pci_patient(id, note)
    values(_patient_id_result, 'РёРЅС‚РµРіСЂР°С†РёСЏ');
    RETURN _patient_id_result;
END;
$$;

