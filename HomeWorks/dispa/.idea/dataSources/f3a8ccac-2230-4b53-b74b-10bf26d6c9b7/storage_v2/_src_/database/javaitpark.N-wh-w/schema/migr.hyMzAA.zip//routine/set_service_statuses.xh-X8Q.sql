CREATE FUNCTION set_service_statuses()
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
                rec record;
            begin
                for rec in
                  select ms.event_service_patient_id, (case when ms.service_id is null then 1 else 4 end) as status from migr.md_migr_service ms
                  where not exists(select 1 from disp.md_event_service_patient_status esps where esps.service_id = ms.event_service_patient_id)
                loop

                  insert into disp.md_event_service_patient_status (id, service_id, status) values (nextval('disp.md_event_service_patient_status_seq'), 
		      rec.event_service_patient_id, rec.status);                

                end loop;
            end;
$$;

