CREATE FUNCTION aud_add_audit_columns(table_name text)
  RETURNS void
LANGUAGE plpgsql
AS $$
BEGIN
  BEGIN
    EXECUTE format('ALTER TABLE %s ADD COLUMN aud_who varchar;', $1);
    EXCEPTION
    WHEN duplicate_column THEN RAISE NOTICE 'column aud_who already exists in %', $1;
  END;

  BEGIN
    EXECUTE format('ALTER TABLE %s ADD COLUMN aud_when timestamp;', $1);
    EXCEPTION
    WHEN duplicate_column THEN RAISE NOTICE 'column aud_when already exists in %', $1;
  END;

  BEGIN
    EXECUTE format('ALTER TABLE %s ADD COLUMN aud_source varchar;', $1);
    EXCEPTION
    WHEN duplicate_column THEN RAISE NOTICE 'column aud_source already exists in %', $1;
  END;

  BEGIN
    EXECUTE format('ALTER TABLE %s ADD COLUMN aud_who_create varchar;', $1);
    EXCEPTION
    WHEN duplicate_column THEN RAISE NOTICE 'column aud_who_create already exists in %', $1;
  END;

  BEGIN
    EXECUTE format('ALTER TABLE %s ADD COLUMN aud_when_create timestamp;', $1);
    EXCEPTION
    WHEN duplicate_column THEN RAISE NOTICE 'column aud_when_create already exists in %', $1;
  END;

  BEGIN
    EXECUTE format('ALTER TABLE %s ADD COLUMN aud_source_create varchar;', $1);
    EXCEPTION
    WHEN duplicate_column THEN RAISE NOTICE 'column aud_source_create already exists in %', $1;
  END;

END;
$$;

