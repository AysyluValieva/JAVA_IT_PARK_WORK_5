CREATE FUNCTION fsym_on_i_for_mb_md_mblnc_cll_knd_t_typ_mngrp()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
begin                                                                                                                                                                  
                                   
                                  if 1=1 and "public".sym_triggers_disabled() = 0 then                                                                                                 
                                    insert into "public".sym_data                                                                                                                     
                                    (table_name, event_type, trigger_hist_id, row_data, channel_id, transaction_id, source_node_id, external_data, create_time)                                        
                                    values(                                                                                                                                                            
                                      'md_ambulance_call_kind_to_type',                                                                                                                                            
                                      'I',                                                                                                                                                             
                                      51,                                                                                                                                             
                                      
          case when new."id" is null then '' else '"' || cast(cast(new."id" as numeric) as varchar) || '"' end||','||
          case when new."kind_id" is null then '' else '"' || cast(cast(new."kind_id" as numeric) as varchar) || '"' end||','||
          case when new."type_id" is null then '' else '"' || cast(cast(new."type_id" as numeric) as varchar) || '"' end,                                                                                                                                                      
                                      'amb_md_ambulance_call_kind_to_type_default',                                                                                                                                                
                                      txid_current(),                                                                                                                                               
                                      "public".sym_node_disabled(),                                                                                                                   
                                      null,                                                                                                                                               
                                      CURRENT_TIMESTAMP                                                                                                                
                                    );                                                                                                                                                                 
                                  end if;                                                                                                                                                              
                                                                                                                                                                               
                                  return null;                                                                                                                                                         
                                end;
$$;

