CREATE FUNCTION add_def_addr_level_setting(xscope_type integer, xsetting character varying, xscope integer, xval integer, xstation integer, xsubstation integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
                                xsc integer;
                              begin
                                if ((xscope = 1) or (xsubstation is not null or xstation is not null))
                                    then
                                        xsc = nextval('public.cmn_scope_seq');
                                        if xsubstation is not null
                                            then
                                                insert into public.cmn_scope (id,type_id)
                                                    values(xsc,xscope_type);
                                                update public.pim_department set scope_id = xsc where id  = xsubstation;
                                            else
                                                if xstation is not null
                                                    then
                                                        insert into public.cmn_scope (id,type_id)
                                                            values(xsc,xscope_type);
                                                        update public.md_clinic set scope_id = xsc where id  = xstation;
                                                end if;
                                        end if;
                                    else
                                        xsc = xscope;
                                end if;
                                if xscope_type != 1 and not exists(select * from cmn_setting_to_scope_type where setting_id = xsetting and scope_type_id = xscope_type)
                                    then
                                        insert into public.cmn_setting_to_scope_type(scope_type_id,setting_id)
                                            values (xscope_type,xsetting);
                                end if;
                                insert into public.cmn_setting_value(scope_id,setting_id,value)
                                    values (xsc,xsetting,cast(xval as text));
                              return xsc;
							  end;
$$;

