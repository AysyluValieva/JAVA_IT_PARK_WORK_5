CREATE FUNCTION get_spesiality_list_v4(_department_id integer, idpat text)
  RETURNS TABLE(countfreeparticipantie bigint, countfreeticket bigint, feridspesiality character varying, idspesiality character varying, lastdate character varying, namespesiality character varying, nearestdate character varying)
LANGUAGE plpgsql
AS $$
/*
Изменения внесены по TAS000000314423  19-09-2017 
Предыдущая версия: "jenkins"."get_spesiality_list_v3"
Суть изменения: 
											join PIM_SPECIALITY ps on ps.id=COALESCE (pim_employee_to_speciality.speciality_id,pp.speciality_id)


*/ 
DECLARE
idpatent integer;
_id_lpu integer;
BEGIN
idpatent:= null;

--если  _department_id > 10 000 000, то это _department_id,  иначе _id_lpu
if(_department_id > 10000000)
then 
	_id_lpu=null;
	_department_id = substr(_department_id::text, 2, 8)::integer;
else 
	_id_lpu = _department_id;
	_department_id=null;
end if;


if (select idpat is not null) and (select idpat <> '')  then 
idpatent:=(select idpat::integer);
end if;
return  QUERY  with  other as(
select   count(sr_ses.id) as CountFreeTicket, --Общее количество свободных талонов по врачебной специальности
			ps.e_code FerIdSpesiality, --Идентификатор врачебной специальности в федеральном справочнике специальностей
			ps.code IdSpesiality, --Идентификатор врачебной специальности
			cast(max(shift.bdatetime) as timestamp)::varchar LastDate, --Дата приема по последнему свободному талону врачебной специальности
			ps.name NameSpesiality,  --Наименование врачебной специальности
			cast(min(shift.bdatetime) as timestamp)::varchar NearestDate --Дата приема по ближайшему свободному талону врачебной специальности
			from sr_res_group srg 
			left join pim_department pd on pd.id = srg.department_id
			join  sr_timetable_res_group strg on strg.res_group_id=srg.id
			join sr_timetable st on st.id=strg.id
			join sr_shift  shift on shift.timetable_id= st.id
			left join sr_session sr_ses on sr_ses.shift_id = shift.id and sr_ses.time_type_id!=2
					and cast(sr_ses.edatetime as date)<=(CURRENT_DATE + INTERVAL '1 month')::date and CURRENT_TIMESTAMP::TIMESTAMP < sr_ses.bdatetime --CURRENT_TIMESTAMP
			left join sr_session_ticket sst on sst.session_id=sr_ses.id 
			join pim_employee_position  pep on pep.id=srg.responsible_id
			join pim_employee pe on pe.id=pep.employee_id
			join pim_individual pi on pi.id=pe.individual_id
						left join PIM_POSITION pp on pp.id=pep.position_id
						left join pim_employee_to_speciality on pim_employee_to_speciality.employee_id=pe.id
								join PIM_SPECIALITY ps on ps.id=COALESCE (pim_employee_to_speciality.speciality_id,pp.speciality_id)
			left join sr_session_source_na sssn on sssn.session_id= sr_ses.id 
			left join  sr_session_quotum ssq on sr_ses.id=ssq.session_id 
			join md_clinic mc on mc.id=srg.org_id
			where st.edate > CURRENT_DATE 
			and shift.time_type_id is not null --требование
			and   case  when _department_id is null then srg.org_id =_id_lpu  else   srg.department_id=_department_id::integer end 
			and  sssn.session_id is null --не учитывать недоступные записи
			 and ssq.session_id is null --не учитывать квоты
			and sst.session_id is null --не учитывать занятые сеансы
			and shift.time_type_id!=2 
			
			group by   ps.name, ps.e_code, ps.code)

select 
	other.CountFreeTicket as CountFreeParticipantIE ,
	other.CountFreeTicket,
  other.FerIdSpesiality, 
	other.IdSpesiality,
	other.LastDate, 
	other.NameSpesiality,  
	other.NearestDate 
from other;


  
END;
$$;

