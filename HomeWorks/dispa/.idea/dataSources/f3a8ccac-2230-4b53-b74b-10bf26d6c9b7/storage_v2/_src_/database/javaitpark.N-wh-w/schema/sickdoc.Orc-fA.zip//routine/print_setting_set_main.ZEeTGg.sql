CREATE FUNCTION print_setting_set_main(p_id integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
  l_registrator_id INTEGER;
BEGIN
  SELECT registrator_id
    FROM sickdoc.print_settings
    WHERE id = p_id
    INTO l_registrator_id;

  UPDATE sickdoc.print_settings
    SET is_main = FALSE
    WHERE registrator_id = l_registrator_id;

  UPDATE sickdoc.print_settings
    SET is_main = TRUE
    WHERE id = p_id;

END;
$$;

