CREATE FUNCTION adr__get_path(param_id integer)
  RETURNS ltree
STRICT
LANGUAGE plpgsql
AS $$
DECLARE
    el_parent INT4;
  BEGIN
    SELECT
      ae.parent_id
    FROM address_element AS ae
    WHERE ae.id = param_id
    INTO el_parent;
    IF el_parent IS NULL
    THEN
      BEGIN
        RETURN param_id :: TEXT :: ltree;
      END;
    ELSE
      BEGIN
        RETURN (adr__get_path(el_parent) || param_id :: TEXT);
      END;
    END IF;
  END;
$$;

