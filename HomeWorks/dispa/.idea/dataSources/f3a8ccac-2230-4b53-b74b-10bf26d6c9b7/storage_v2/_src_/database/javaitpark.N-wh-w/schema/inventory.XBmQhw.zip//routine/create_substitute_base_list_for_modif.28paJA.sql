CREATE FUNCTION create_substitute_base_list_for_modif(modifid integer, holdingid integer, formtypeid integer, orgid integer, innid integer, mneiid integer, OUT id integer)
  RETURNS SETOF integer
LANGUAGE plpgsql
AS $$
DECLARE
v_rec record;
BEGIN
  if innId = 0 then
         return query select hm.id as id from inventory.hold_modif hm
                             where hm.holding_id = holdingId
                             and hm.form_type_id = formTypeId
                             and hm.mnei_id = mneiId
                             and hm.id!=modifId
                             and ((hm.org_owner_id = orgId or hm.org_owner_id is null) or orgId is null);
   else
         return query select hm.id as id from inventory.hold_modif hm
                             left outer join inventory.holding h on h.id= hm.holding_id
                             where h.inn_id = innId
                             and hm.form_type_id = formTypeId
                             and hm.mnei_id = mneiId
                             and hm.id!=modifId
                             and h.id!=holdingId
                             and ((hm.org_owner_id = orgId or hm.org_owner_id is null) or orgId is null);
   end if;
END;
$$;

