CREATE FUNCTION fsym_on_i_for_pblc_pm_dprtmnt_mngrp()
  RETURNS trigger
LANGUAGE plpgsql
AS $fun$
begin                                                                                                                                                                  
                                   
                                  if 1=1 and "public".sym_triggers_disabled() = 0 then                                                                                                 
                                    insert into "public".sym_data                                                                                                                     
                                    (table_name, event_type, trigger_hist_id, row_data, channel_id, transaction_id, source_node_id, external_data, create_time)                                        
                                    values(                                                                                                                                                            
                                      'pim_department',                                                                                                                                            
                                      'I',                                                                                                                                                             
                                      18286,                                                                                                                                             
                                      
          case when new."id" is null then '' else '"' || cast(cast(new."id" as numeric) as varchar) || '"' end||','||
          case when new."accounting_center_id" is null then '' else '"' || cast(cast(new."accounting_center_id" as numeric) as varchar) || '"' end||','||
          case when new."code" is null then '' else '"' || replace(replace(cast(new."code" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."from_dt" is null then '' else '"' || to_char(new."from_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when new."name" is null then '' else '"' || replace(replace(cast(new."name" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."to_dt" is null then '' else '"' || to_char(new."to_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when new."type_id" is null then '' else '"' || cast(cast(new."type_id" as numeric) as varchar) || '"' end||','||
          case when new."funding_id" is null then '' else '"' || cast(cast(new."funding_id" as numeric) as varchar) || '"' end||','||
          case when new."org_id" is null then '' else '"' || cast(cast(new."org_id" as numeric) as varchar) || '"' end||','||
          case when new."parent_id" is null then '' else '"' || cast(cast(new."parent_id" as numeric) as varchar) || '"' end||','||
          case when new."sphere_id" is null then '' else '"' || cast(cast(new."sphere_id" as numeric) as varchar) || '"' end||','||
          case when new."is_available_diagnosis" is null then '' when new."is_available_diagnosis" then '"1"' else '"0"' end||','||
          case when new."is_payment" is null then '' when new."is_payment" then '"1"' else '"0"' end||','||
          case when new."unit_id" is null then '' else '"' || cast(cast(new."unit_id" as numeric) as varchar) || '"' end||','||
          case when new."kind_id" is null then '' else '"' || cast(cast(new."kind_id" as numeric) as varchar) || '"' end||','||
          case when new."e_code" is null then '' else '"' || replace(replace(cast(new."e_code" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."scope_id" is null then '' else '"' || cast(cast(new."scope_id" as numeric) as varchar) || '"' end||','||
          case when new."is_separate" is null then '' when new."is_separate" then '"1"' else '"0"' end||','||
          case when new."is_social_significant" is null then '' else '"' || cast(cast(new."is_social_significant" as numeric) as varchar) || '"' end||','||
          case when new."age_group_id" is null then '' else '"' || cast(cast(new."age_group_id" as numeric) as varchar) || '"' end||','||
          case when new."is_branch_type" is null then '' when new."is_branch_type" then '"1"' else '"0"' end||','||
          case when new."visits_per_shift" is null then '' else '"' || cast(cast(new."visits_per_shift" as numeric) as varchar) || '"' end||','||
          case when new."departures_per_shift" is null then '' else '"' || cast(cast(new."departures_per_shift" as numeric) as varchar) || '"' end||','||
          case when new."visits_per_day" is null then '' else '"' || cast(cast(new."visits_per_day" as numeric) as varchar) || '"' end||','||
          case when new."necropsies_per_day" is null then '' else '"' || cast(cast(new."necropsies_per_day" as numeric) as varchar) || '"' end||','||
          case when new."clinical_trials_per_shift" is null then '' else '"' || cast(cast(new."clinical_trials_per_shift" as numeric) as varchar) || '"' end||','||
          case when new."brigades_amount" is null then '' else '"' || cast(cast(new."brigades_amount" as numeric) as varchar) || '"' end||','||
          case when new."ose" is null then '' else '"' || replace(replace(cast(new."ose" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."ose_reject" is null then '' else '"' || replace(replace(cast(new."ose_reject" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."at_home" is null then '' when new."at_home" then '"1"' else '"0"' end,                                                                                                                                                      
                                      'public_pim_department_default',                                                                                                                                                
                                      txid_current(),                                                                                                                                               
                                      "public".sym_node_disabled(),                                                                                                                   
                                      null,                                                                                                                                               
                                      CURRENT_TIMESTAMP                                                                                                                
                                    );                                                                                                                                                                 
                                  end if;                                                                                                                                                              
                                                                                                                                                                               
                                  return null;                                                                                                                                                         
                                end;
$fun$;

