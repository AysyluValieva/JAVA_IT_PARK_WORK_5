CREATE FUNCTION update_measure_user_value(_values json, _sec_user_id integer, _clinic_id integer, _value text, _calc_dt timestamp without time zone)
  RETURNS json
IMMUTABLE
LANGUAGE plpgsql
AS $$
DECLARE rec record;
				        result text := '[';

			        BEGIN

                        IF _sec_user_id IS NULL THEN
                            RAISE EXCEPTION 'Не задан параметр _sec_user_id';
                        END IF;

                        IF _clinic_id IS NULL THEN
                            RAISE EXCEPTION 'Не задан параметр _clinic_id';
                        END IF;

                        FOR rec IN SELECT json_array_elements(CASE WHEN _values ISNULL THEN '[]'::json ELSE _values END) as item LOOP

                            IF NOT (json_extract_path_text(rec.item, 'sec_user_id')::text = _sec_user_id::text
                                           AND json_extract_path_text(rec.item, 'clinic_id')::text = _clinic_id::text) THEN

                                IF result != '[' THEN
                                    result := result || ',';
                                END IF;

                                result := result || rec.item::text;

                            END IF;

                        END LOOP;

                        IF _value NOTNULL THEN

                            IF result != '[' THEN
                                result := result || ',';
                            END IF;

                            result := result || '{"sec_user_id": '|| _sec_user_id::text ||', "clinic_id": '|| _clinic_id::text ||', "value": "'|| _value ||'", "calc_dt": "'|| _calc_dt::text ||'"}';

                        END IF;

				        RETURN (result || ']')::json;

			        END;
$$;

