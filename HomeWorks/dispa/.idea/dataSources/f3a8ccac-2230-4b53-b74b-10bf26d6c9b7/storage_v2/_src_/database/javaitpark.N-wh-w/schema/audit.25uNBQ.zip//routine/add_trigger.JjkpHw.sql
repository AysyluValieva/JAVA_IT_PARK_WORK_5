CREATE FUNCTION add_trigger(table_name text)
  RETURNS void
LANGUAGE plpgsql
AS $$
BEGIN
    EXECUTE format('CREATE TRIGGER audit_trigger_full
			AFTER INSERT OR UPDATE OR DELETE
      ON %s
      FOR EACH ROW
      EXECUTE PROCEDURE audit.trigger_fun();', $1);
  END;
$$;

