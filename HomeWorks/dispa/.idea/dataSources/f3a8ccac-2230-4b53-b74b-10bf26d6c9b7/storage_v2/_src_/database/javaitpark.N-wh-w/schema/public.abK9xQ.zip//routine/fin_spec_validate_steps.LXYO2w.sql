CREATE FUNCTION fin_spec_validate_steps(p1_bill_id integer, p2_user_id integer)
  RETURNS void
STRICT
LANGUAGE plpgsql
AS $$
DECLARE
    _r RECORD;
    _v VARCHAR;
    _validation_code VARCHAR[];
    _validation_enabled BOOLEAN[];
    _validation_title VARCHAR[];
BEGIN
    /*
        current version date 2014-12-22
    */
    _validation_code := ARRAY 
    [
        'DOCTOR_IS_REQUIRED',                   --1
        'DOCTOR_EMPTY_PROFILE',                 --2
        'DOCTOR_WRONG_PROFILE',                 --3
        'DOCTOR_SPECIALITY_IS_NULL',            --4
        'DOCTOR_SPECIALITY_CODE_MAX_LENGTH',    --5
        'EMPLOYEE_NUMBER_MAX_LENGTH',           --6
        'NO_PRICE_POSITION',                    --7
        'PRICE_POSITION_CODE_IS_REQUIRED',      --8
        'SERVICE_CODE_IS_REQUIRED'              --9
    ];
    FOREACH _v IN ARRAY _validation_code 
    LOOP 
        SELECT 
            coalesce (u.enabled, v.enabled) AS enabled, title INTO _r 
        FROM 
            fin_bill_validation                AS v 
            LEFT JOIN fin_bill_validation_user AS u ON u.validation_id = v.id AND u.user_id = p2_user_id
        WHERE 
            v.code = _v;
        _validation_enabled := _validation_enabled || _r.enabled;
        _validation_title   := _validation_title   || _r.title  ;
    END LOOP;
    
    DELETE FROM fin_bill_spec_item_error AS e WHERE e.code = ANY (_validation_code) AND EXISTS (SELECT 1 FROM fin_bill_spec_item WHERE bill_id = p1_bill_id AND id = e.item_id)
    ;
    FOR _r IN 
        SELECT 
            res_group_id, doctor_code, step_profile_code, speciality_code_arr, doctor_code_regional, price_pos_id, price_pos_code, service_code, spec_item_id AS id 
        FROM 
            fin_bill_steps
        WHERE
            bill_id = p1_bill_id
    LOOP
        IF 
            _validation_enabled[1] AND (_r.res_group_id IS NULL OR _r.doctor_code = '') 
        THEN 
            INSERT INTO fin_bill_spec_item_error (id, error, code, item_id)
                SELECT nextval ('fin_bill_spec_item_error_seq'), _validation_title[1], 'DOCTOR_IS_REQUIRED', _r.id
            ;
        ELSIF 
            _validation_enabled[2] AND _r.step_profile_code = ''
        THEN 
            INSERT INTO fin_bill_spec_item_error (id, error, code, item_id)
                SELECT nextval ('fin_bill_spec_item_error_seq'), _validation_title[2], 'DOCTOR_EMPTY_PROFILE', _r.id
            ;
        ELSIF 
            _validation_enabled[3] AND _r.step_profile_code::INTEGER NOT BETWEEN 1 AND 182
        THEN 
            INSERT INTO fin_bill_spec_item_error (id, error, code, item_id)
                SELECT nextval ('fin_bill_spec_item_error_seq'), _validation_title[3], 'DOCTOR_WRONG_PROFILE', _r.id
            ;
        END IF;
        IF 
            _validation_enabled[4] AND _r.speciality_code_arr[1] = ''
        THEN 
            INSERT INTO fin_bill_spec_item_error (id, error, code, item_id)
                SELECT nextval ('fin_bill_spec_item_error_seq'), _validation_title[4], 'DOCTOR_SPECIALITY_IS_NULL', _r.id
            ;
        ELSIF 
            _validation_enabled[5] AND length (_r.speciality_code_arr[1]) > 9 
        THEN 
            INSERT INTO fin_bill_spec_item_error (id, error, code, item_id)
                SELECT nextval ('fin_bill_spec_item_error_seq'), _validation_title[5], 'DOCTOR_SPECIALITY_CODE_MAX_LENGTH', _r.id
            ;
        END IF;
        IF 
            _validation_enabled[6] AND length (_r.doctor_code_regional) > 6 
        THEN 
            INSERT INTO fin_bill_spec_item_error (id, error, code, item_id)
                SELECT nextval ('fin_bill_spec_item_error_seq'), _validation_title[6], 'EMPLOYEE_NUMBER_MAX_LENGTH', _r.id
            ;
        END IF;
        IF 
            _validation_enabled[7] AND _r.price_pos_id IS NULL
        THEN 
            INSERT INTO fin_bill_spec_item_error (id, error, code, item_id)
                SELECT nextval ('fin_bill_spec_item_error_seq'), _validation_title[7], 'NO_PRICE_POSITION', _r.id
            ;
        ELSIF 
            _validation_enabled[8] AND _r.price_pos_code = ''
        THEN 
            INSERT INTO fin_bill_spec_item_error (id, error, code, item_id)
                SELECT nextval ('fin_bill_spec_item_error_seq'), _validation_title[8], 'PRICE_POSITION_CODE_IS_REQUIRED', _r.id
            ;
        END IF;
        IF 
            _validation_enabled[9] AND _r.service_code = ''
        THEN 
            INSERT INTO fin_bill_spec_item_error (id, error, code, item_id)
                SELECT nextval ('fin_bill_spec_item_error_seq'), _validation_title[9], 'SERVICE_CODE_IS_REQUIRED', _r.id
            ;
        END IF;
    END LOOP;
END;
$$;

