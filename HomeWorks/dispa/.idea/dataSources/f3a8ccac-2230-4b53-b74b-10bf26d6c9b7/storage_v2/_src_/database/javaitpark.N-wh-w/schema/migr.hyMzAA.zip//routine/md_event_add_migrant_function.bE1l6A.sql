CREATE FUNCTION md_event_add_migrant_function(xeid integer, xpid integer, xlatinsurname character varying, xlatinname character varying, xlatinpatrname character varying, xcountryid integer, xpurposeid integer, xplanperiodid integer, xbegin date, xend date, xcertificate character varying, xconclusion character varying)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
                i integer;
                categoryid json;
                service record;
            begin
                i = nextval('disp.md_event_patient_id_seq');
                insert into disp.md_event_patient (id, event_id, indiv_id) values (i, xeid, xpid);
                insert into migr.md_migr_patient (id, latin_name, latin_surname, latin_patrname) values (xpid, xlatinname, xlatinsurname, xlatinpatrname);
                insert into migr.md_migr_card (id, plan_period_id, begin_date, end_date, purpose_id, certificate_number, conclusion_number, country_id, status_id) values (nextval('migr.md_migr_service_seq'), xplanperiodid,
                xbegin, xend, xpurposeid, xcertificate, xconclusion, xcountryid, 1);

		for service in select id from disp.md_event_service es where event_id = xeid
		loop
		    insert into disp.md_event_service_patient (id, service_id, indiv_id, event_id, event_patient_id) values (nextval('disp.md_event_service_patient_id_seq'), service.id, xpid, xeid, i);
		end loop;

                PERFORM disp.orphansagreedisprforpatient(null::integer, to_char(current_date, 'DD-MM-YYYY'), i);
                return i;
            end;
$$;

