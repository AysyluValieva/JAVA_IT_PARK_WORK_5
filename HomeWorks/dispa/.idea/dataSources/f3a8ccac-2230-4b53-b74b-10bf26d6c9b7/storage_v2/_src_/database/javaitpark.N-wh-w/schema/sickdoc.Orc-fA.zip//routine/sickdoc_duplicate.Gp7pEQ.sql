CREATE FUNCTION sickdoc_duplicate(p_parent_id integer, p_annual_reason_id integer, p_number character varying, p_journal_id integer, p_registrator_id integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
DECLARE
  c_sickdoc_type_code CONSTANT VARCHAR = '3';  --Дубликат
  c_parent_sickdoc_state_code CONSTANT VARCHAR = '5'; --Аннулирован
  l_parent_sickdock sickdoc.sickdoc%ROWTYPE;
  l_parent_sickdock_extended sickdoc.sickdoc_extended%ROWTYPE;
  l_sickdoc_type_id INTEGER;
  l_parent_sickdoc_state_id INTEGER;
  l_dublicate_sickdoc_id INTEGER;
  l_parent_id INTEGER;
  l_family_member1 sickdoc.family_member%ROWTYPE;
  l_family_member2 sickdoc.family_member%ROWTYPE;
  l_disability_reason_code VARCHAR;
  l_issue_dt DATE = current_date;
BEGIN
-- Достаем id аннулированной зписи
  l_parent_sickdoc_state_id := (SELECT id FROM public.md_sicklist_state WHERE code = c_parent_sickdoc_state_code);

-- Ищем запись на основе которой делаем дубликат по p_parent_id
  SELECT * INTO STRICT l_parent_sickdock FROM sickdoc.sickdoc WHERE id = p_parent_id ;
  --SELECT * INTO STRICT l_parent_sickdock_extended FROM sickdoc.sickdoc_extended WHERE id = p_parent_id ;
  IF (select state_id FROM sickdoc.sickdoc WHERE id=p_parent_id) = l_parent_sickdoc_state_id
  THEN RAISE EXCEPTION 'Нельзя создать дубликат аннулированного ЛН';
  END IF ;

  l_sickdoc_type_id := (SELECT id from public.md_sicklist_type WHERE code = c_sickdoc_type_code);
-- Если дубликат на дубликат, то ставим parent_id изначального документа, на который выдан самый первый дубликат
  l_parent_id := CASE
                  WHEN l_parent_sickdock.type_id = l_sickdoc_type_id --Если дубликат
                    THEN l_parent_sickdock.parent_id --Оставляем parent_id изначального документа
                  ELSE
                    l_parent_sickdock.id
                END ;

-- Создаем дубликат в БД
  INSERT INTO sickdoc.sickdoc (
    id,
    begin_dt,
    case_id,
    clinic_id,
    days,
    end_dt,
    final_diagnosis_id,
    hospital_from_dt,
    hospital_to_dt,
    individual_id,
    initial_diagnosis_id,
    issue_dt,
    journal_id, kind_id,
    number,
    parent_id,
    ready_to_work_dt,
    ready_to_work_other_dt,
    ready_to_work_other_id,
    registrator_id,
    state_id,
    transfer_to_o_clinic,
    transfer_from_clinic,
    workplace_id,
    workplace_print,
    workplace_type_id,
    type_id
  )
  VALUES (
    DEFAULT,
    l_parent_sickdock.begin_dt,
    l_parent_sickdock.case_id,
    l_parent_sickdock.clinic_id,
    l_parent_sickdock.days,
    l_parent_sickdock.end_dt,
    l_parent_sickdock.final_diagnosis_id,
    l_parent_sickdock.hospital_from_dt,
    l_parent_sickdock.hospital_to_dt,
    l_parent_sickdock.individual_id,
    l_parent_sickdock.initial_diagnosis_id,
    l_issue_dt,
    p_journal_id,
    l_parent_sickdock.kind_id,
    p_number,
    l_parent_id,
    l_parent_sickdock.ready_to_work_dt,
    l_parent_sickdock.ready_to_work_other_dt,
    l_parent_sickdock.ready_to_work_other_id,
    p_registrator_id,
    l_parent_sickdock.state_id,
    l_parent_sickdock.transfer_to_o_clinic,
    l_parent_sickdock.transfer_from_clinic,
    l_parent_sickdock.workplace_id,
    l_parent_sickdock.workplace_print,
    l_parent_sickdock.workplace_type_id,
    l_sickdoc_type_id
  )
  RETURNING id INTO l_dublicate_sickdoc_id;

  -- Создаем дубликат в БД
  INSERT INTO sickdoc.sickdoc_extended (
    id,
    disability_from_dt,
    disability_reason_edited_id,
    disability_reason_ext_id,
    disability_reason_id,
    disability_to_dt,
    is_disability_group_changed,
    is_early_pregnancy_register,
    mse_examination_dt,
    mse_referral_dt,
    mse_register_dt,
    on_placement_service,
    regimen_id,
    regimen_violation_doctor_id,
    regimen_violation_dt,
    regimen_violation_id,
    sanatorium_id,
    sanatorium_ogrn_code,
    voucher_code,
    family_member_1_relation_id_lsd,
    family_member_1_age_lsd,
    family_member_1_age_month_lsd,
    family_member_1_name_lsd,
    family_member_2_relation_id_lsd,
    family_member_2_age_lsd,
    family_member_2_age_month_lsd,
    family_member_2_name_lsd
  )
    SELECT
      l_dublicate_sickdoc_id,
      disability_from_dt,
      disability_reason_edited_id,
      disability_reason_ext_id,
      disability_reason_id,
      disability_to_dt,
      is_disability_group_changed,
      is_early_pregnancy_register,
      mse_examination_dt,
      mse_referral_dt,
      mse_register_dt,
      on_placement_service,
      regimen_id,
      regimen_violation_doctor_id,
      regimen_violation_dt,
      regimen_violation_id,
      sanatorium_id,
      sanatorium_ogrn_code,
      voucher_code,
      family_member_1_relation_id_lsd,
      family_member_1_age_lsd,
      family_member_1_age_month_lsd,
      family_member_1_name_lsd,
      family_member_2_relation_id_lsd,
      family_member_2_age_lsd,
      family_member_2_age_month_lsd,
      family_member_2_name_lsd
    FROM sickdoc.sickdoc_extended WHERE id = p_parent_id;

-- Копируем родственников, по уходу за которыми выдан ЛН
    SELECT *
      FROM sickdoc.sickdoc_extended
      WHERE id = p_parent_id
      INTO l_parent_sickdock_extended;

    l_disability_reason_code = (SELECT code
                              FROM md_sl_disability_reason
                              WHERE id = l_parent_sickdock_extended.disability_reason_id);

    SELECT *
      FROM sickdoc.family_member
      WHERE id = l_parent_sickdock_extended.family_member_1_id
      INTO l_family_member1;

    SELECT *
      FROM sickdoc.family_member
      WHERE id = l_parent_sickdock_extended.family_member_2_id
      INTO l_family_member2;

    PERFORM sickdoc.family_member_update(
      l_dublicate_sickdoc_id, l_disability_reason_code, l_family_member1.patient_id, l_family_member2.patient_id, l_family_member1.relation_id, l_family_member2.relation_id);

  -- Привязка периода
  INSERT INTO sickdoc.period (
    clinic_id, from_dt, issued_employee_id, issued_employee_position, sickdoc_id, step_id, to_dt, witness_employee_id, witness_employee_position
  )
    SELECT
      clinic_id, from_dt, issued_employee_id, issued_employee_position, l_dublicate_sickdoc_id, step_id, to_dt, witness_employee_id, witness_employee_position
        FROM sickdoc.period
          WHERE sickdoc_id = p_parent_id;

-- Проставляем признак АННУЛИРОВАН в родителький ЛН
  UPDATE sickdoc.sickdoc
  SET state_id = l_parent_sickdoc_state_id
  WHERE id = p_parent_id;

-- Возвращаем ID созданного нами дубликата
  RETURN l_dublicate_sickdoc_id;
END;
$$;

