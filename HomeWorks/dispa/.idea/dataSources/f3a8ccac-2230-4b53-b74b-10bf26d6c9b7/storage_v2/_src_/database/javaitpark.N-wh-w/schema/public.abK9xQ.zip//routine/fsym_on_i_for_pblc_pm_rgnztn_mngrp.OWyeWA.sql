CREATE FUNCTION fsym_on_i_for_pblc_pm_rgnztn_mngrp()
  RETURNS trigger
LANGUAGE plpgsql
AS $fun$
begin                                                                                                                                                                  
                                   
                                  if 1=1 and "public".sym_triggers_disabled() = 0 then                                                                                                 
                                    insert into "public".sym_data                                                                                                                     
                                    (table_name, event_type, trigger_hist_id, row_data, channel_id, transaction_id, source_node_id, external_data, create_time)                                        
                                    values(                                                                                                                                                            
                                      'pim_organization',                                                                                                                                            
                                      'I',                                                                                                                                                             
                                      18282,                                                                                                                                             
                                      
          case when new."id" is null then '' else '"' || cast(cast(new."id" as numeric) as varchar) || '"' end||','||
          case when new."close_dt" is null then '' else '"' || to_char(new."close_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when new."code" is null then '' else '"' || replace(replace(cast(new."code" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."full_name" is null then '' else '"' || replace(replace(cast(new."full_name" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."reg_dt" is null then '' else '"' || to_char(new."reg_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when new."short_name" is null then '' else '"' || replace(replace(cast(new."short_name" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."legal_form_id" is null then '' else '"' || cast(cast(new."legal_form_id" as numeric) as varchar) || '"' end||','||
          case when new."sphere_id" is null then '' else '"' || cast(cast(new."sphere_id" as numeric) as varchar) || '"' end||','||
          case when new."work_territory_id" is null then '' else '"' || cast(cast(new."work_territory_id" as numeric) as varchar) || '"' end||','||
          case when new."version" is null then '' else '"' || to_char(new."version", 'YYYY-MM-DD HH24:MI:SS.US') || '"' end||','||
          case when new."parent_id" is null then '' else '"' || cast(cast(new."parent_id" as numeric) as varchar) || '"' end||','||
          case when new."country_jurisdiction_id" is null then '' else '"' || cast(cast(new."country_jurisdiction_id" as numeric) as varchar) || '"' end||','||
          case when new."unit_id" is null then '' else '"' || cast(cast(new."unit_id" as numeric) as varchar) || '"' end||','||
          case when new."own_form_id" is null then '' else '"' || cast(cast(new."own_form_id" as numeric) as varchar) || '"' end||','||
          case when new."scope_id" is null then '' else '"' || cast(cast(new."scope_id" as numeric) as varchar) || '"' end||','||
          case when new."e_code" is null then '' else '"' || replace(replace(cast(new."e_code" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."from_dt" is null then '' else '"' || to_char(new."from_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when new."to_dt" is null then '' else '"' || to_char(new."to_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when new."max_distant_point" is null then '' else '"' || cast(cast(new."max_distant_point" as numeric) as varchar) || '"' end||','||
          case when new."longitude" is null then '' else '"' || cast(cast(new."longitude" as numeric) as varchar) || '"' end||','||
          case when new."latitude" is null then '' else '"' || cast(cast(new."latitude" as numeric) as varchar) || '"' end,                                                                                                                                                      
                                      'public_pim_organization_default',                                                                                                                                                
                                      txid_current(),                                                                                                                                               
                                      "public".sym_node_disabled(),                                                                                                                   
                                      null,                                                                                                                                               
                                      CURRENT_TIMESTAMP                                                                                                                
                                    );                                                                                                                                                                 
                                  end if;                                                                                                                                                              
                                                                                                                                                                               
                                  return null;                                                                                                                                                         
                                end;
$fun$;

