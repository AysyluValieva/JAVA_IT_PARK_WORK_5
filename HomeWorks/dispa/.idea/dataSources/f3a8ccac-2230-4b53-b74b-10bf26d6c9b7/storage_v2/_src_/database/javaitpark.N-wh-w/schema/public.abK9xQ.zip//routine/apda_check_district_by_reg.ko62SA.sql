CREATE FUNCTION apda_check_district_by_reg(info apda_reg_info, separation_id integer, district_id integer)
  RETURNS boolean
LANGUAGE plpgsql
AS $$
DECLARE
  valid_simple   BOOLEAN := NULL;
  valid_termimal BOOLEAN := NULL;
  it             RECORD;
BEGIN
  FOR it IN
  (SELECT
     terminal.code :: INTEGER AS terminal_code,
     type.code                AS type_code
   FROM md_district_criterion c
     JOIN md_district_criterion_type type ON c.type_id = type.id
     JOIN md_district_criterion_terminal terminal ON c.terminal_id = terminal.id
   WHERE c.separation_id = $2
   ORDER BY terminal.code DESC, c.priority) LOOP
    IF it.terminal_code = 2
    THEN
      IF apda_check_district_by_reg_and_criterion_type($1, $3, it.type_code) = FALSE
      THEN
        RETURN FALSE;
      END IF;
    ELSEIF valid_termimal ISNULL OR valid_termimal = FALSE
      THEN
        IF it.terminal_code = 1
        THEN
          valid_termimal = apda_check_district_by_reg_and_criterion_type($1, $3, it.type_code);
        ELSEIF valid_simple ISNULL OR valid_simple = TRUE
          THEN
            valid_simple = apda_check_district_by_reg_and_criterion_type($1, $3, it.type_code);
        END IF;
    END IF;
  END LOOP;

  IF valid_termimal OR valid_simple OR (valid_termimal ISNULL AND valid_simple ISNULL)
  THEN RETURN TRUE;
  END IF;

  RETURN FALSE;
END;
$$;

