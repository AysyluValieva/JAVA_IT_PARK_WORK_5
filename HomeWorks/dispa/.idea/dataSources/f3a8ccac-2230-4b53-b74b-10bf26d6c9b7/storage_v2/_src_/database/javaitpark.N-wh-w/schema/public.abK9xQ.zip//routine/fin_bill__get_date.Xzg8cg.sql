CREATE FUNCTION fin_bill__get_date(bill_id integer)
  RETURNS date
LANGUAGE plpgsql
AS $$
declare
                main_bill_id integer;
                from_date date;
            begin
                from_date = (select fin_bill_main.from_date from fin_bill_main where fin_bill_main.id = bill_id);
                if from_date is not null then return from_date;
                end if;
                from_date = (select fin_bill_additional.from_date from fin_bill_additional where fin_bill_additional.id = bill_id);
                if from_date is not null then return from_date;
                end if;
                main_bill_id = (select fin_bill_correctional.base_id from fin_bill_correctional where fin_bill_correctional.id = bill_id);
                if main_bill_id is not null then return fin_bill__get_date(main_bill_id);
                end if;
                return null;
            end;
$$;

