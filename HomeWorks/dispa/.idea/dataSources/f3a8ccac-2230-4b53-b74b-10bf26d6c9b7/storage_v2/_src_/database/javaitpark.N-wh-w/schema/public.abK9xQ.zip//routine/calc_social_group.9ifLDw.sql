CREATE FUNCTION calc_social_group()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
declare
            begin
                if (TG_OP = 'DELETE')
                then
                    update pci_patient set
                        social_group_id = (
                            select psg.social_group_id
                            from pci_patient_social_group psg
                            where psg.patient_id = OLD.patient_id and
                            (psg.from_dt is null or current_date >= date(psg.from_dt)) and (psg.to_dt is null or date(psg.to_dt)> current_date) order by psg.from_dt desc limit 1
                        )
                    where id = OLD.patient_id;

                    return OLD;
                else
                    update pci_patient set
                        social_group_id = (
                            select psg.social_group_id
                            from pci_patient_social_group psg
                            where psg.patient_id = NEW.patient_id and
                            (psg.from_dt is null or current_date >= date(psg.from_dt)) and (psg.to_dt is null or date(psg.to_dt)> current_date) order by psg.from_dt desc limit 1
                        )
                    where id = NEW.patient_id;

                    return NEW;
                end if;
            end;
$$;

