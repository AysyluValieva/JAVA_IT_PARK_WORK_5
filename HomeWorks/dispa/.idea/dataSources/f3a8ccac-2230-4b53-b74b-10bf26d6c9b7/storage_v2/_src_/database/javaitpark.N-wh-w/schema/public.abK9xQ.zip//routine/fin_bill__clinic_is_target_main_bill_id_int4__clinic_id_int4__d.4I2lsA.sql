CREATE FUNCTION "fin_bill__clinic_is_target(main_bill_id int4, clinic_id int4, d"(main_bill_id integer, clinic_id integer, department_id integer)
  RETURNS boolean
LANGUAGE plpgsql
AS $$
declare
    flag boolean;
begin
    flag = (
        select count(*) > 0 from fin_bill_main
        where fin_bill_main.clinic_id = fin_bill__clinic_is_target.clinic_id
        and fin_bill_main.id = fin_bill__clinic_is_target.main_bill_id
    );
    if flag then return true; end if;
    flag = (
            select count(*) > 0 from fin_bill_main_child_clinic
            where fin_bill_main_child_clinic.clinic_id = fin_bill__clinic_is_target.clinic_id
            and fin_bill_main_child_clinic.main_bill_id = fin_bill__clinic_is_target.main_bill_id
        );
    if flag then return true; end if;
    flag = (
            select count(*) > 0 from fin_bill_main_department
            where fin_bill_main_department.department_id = fin_bill__clinic_is_target.department_id
            and fin_bill_main_department.main_bill_id = fin_bill__clinic_is_target.main_bill_id
        );
    if flag then return true; end if;
    return false;
end;
$$;

