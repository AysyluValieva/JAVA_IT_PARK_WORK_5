CREATE FUNCTION add_zabbixuser()
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
_user_id integer;
_role_id integer;
_user_role_id integer;
begin
_user_id=(select id from sec_user where login='zabbixuser');  --поиск юзера по логину
_role_id=(select id from sec_role where name='Полный доступ');  --поиск необходимой роли
if _user_id is null then
     insert into sec_user(id,login,password) select nextval('sec_user_seq'),'zabbixuser','911c30ab7864b21511dede182e94b940';--создаем пользователя, если его нет
     _user_id=(select id from sec_user where login='zabbixuser');--поиск юзера по логину
end if;
if not exists(select 1 from sec_passhash_history where user_id=_user_id and hash='911c30ab7864b21511dede182e94b940') then
insert into sec_passhash_history(id,user_id,hash,issue_date) select nextval('sec_passhash_history_seq'),_user_id,'911c30ab7864b21511dede182e94b940',now()::date;--запись о пароле
end if;
if not exists(select 1 from sec_user_party where id=_user_id) then
	insert into pim_party(id,type_id) select nextval('pim_party_id_seq'),id from pim_party_type where name='физическое лицо';--создаем контрагента
	insert into sec_user_party(id,party_id) select _user_id,currval('pim_party_id_seq');--связываем контрагента и юзера
end if;
insert into sec_user_org (id, user_id, org_id) 
select nextval ('sec_user_org_seq'), _user_id, id from md_clinic where id not in (select org_id from sec_user_org where user_id = _user_id);--добавление всех доступных ЛПУ пользователю
if not exists (select 1 from sec_user_role where user_id=_user_id and role_id=_role_id) then
     	 insert into sec_user_role (id,user_id,role_id) values (nextval('sec_user_role_seq'),_user_id,_role_id);
		 insert into sec_user_role_ext(id) select currval('sec_user_role_seq');
end if; --проставляем пользователю роль "Полный доступ"   
_user_role_id=(select id from sec_user_role where user_id=_user_id and role_id=_role_id);--связь роли и пользователя
insert into sec_user_role_party (id,user_role_id,party_id) 
select nextval('sec_user_role_party_seq'),_user_role_id,org_id from sec_user_org 
where user_id=_user_id and org_id not in (select party_id from sec_user_role_party where user_role_id=_user_role_id);--проставляем полный доступ пользователю, в доступных ему ЛПУ
end;
$$;

