CREATE RULE delete_cron_event AS
    ON DELETE TO event_handler.event
   WHERE (old.period IS NOT NULL) DO  SELECT pg_notify('cron_event'::text, format('{"action":"REMOVE", "event":{"cron":"%s", "event":"%s"}}'::text, old.period, old.id)) AS pg_notify;

