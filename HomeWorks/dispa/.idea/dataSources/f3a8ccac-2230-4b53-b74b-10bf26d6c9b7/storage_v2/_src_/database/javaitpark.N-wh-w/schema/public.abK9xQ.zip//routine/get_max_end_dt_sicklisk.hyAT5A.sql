CREATE FUNCTION get_max_end_dt_sicklisk(ssicklist_id integer)
  RETURNS date
LANGUAGE plpgsql
AS $$
DECLARE
                next_id integer;
                max_id integer;
            BEGIN
                next_id = null;
                max_id = ssicklist_id;
                select id from md_sicklist where parent_id = ssicklist_id into next_id;
                while (next_id is not null)
                loop
                    max_id = next_id;
                    select id from md_sicklist where parent_id = next_id into next_id;
                end loop;
                return (select max(to_dt) from md_sicklist_period where sicklist_id = max_id);
            END;
$$;

