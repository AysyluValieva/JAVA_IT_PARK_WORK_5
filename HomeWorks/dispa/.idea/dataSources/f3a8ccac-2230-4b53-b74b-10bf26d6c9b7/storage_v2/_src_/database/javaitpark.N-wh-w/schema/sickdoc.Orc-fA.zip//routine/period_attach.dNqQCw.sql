CREATE FUNCTION period_attach(p_sickdoc_id integer, p_cur_clinic_id integer, p_from_dt date, p_is_other_clinic boolean, p_issued_employee_id integer, p_issued_employee_position character varying, p_other_clinic_id integer, p_to_dt date, p_witness_employee_id integer, p_witness_employee_position character varying)
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
  l_clinic_id INTEGER;
BEGIN
  IF (sickdoc.sickdoc_has_max_available_count_of_periods(p_sickdoc_id))
  THEN
    RAISE 'Невозможно добавить новый период освобождения от работы, т.к. максимально допустимое количество периодов для одного ЛН равно %', c_max_period_count;
  END IF;

  IF p_from_dt <= (SELECT p.to_dt
                  FROM sickdoc.period p
                  WHERE p.sickdoc_id = p_sickdoc_id
                  ORDER BY p.from_dt DESC
                  LIMIT 1)
  THEN
    RAISE 'Невозможно добавить новый период освобождения от работы, т.к. начало нового периода не может быть ранее конца предыдущего';
  END IF;

  l_clinic_id = CASE WHEN p_is_other_clinic THEN p_other_clinic_id
                ELSE p_cur_clinic_id END;

  INSERT INTO sickdoc.period (
    clinic_id, from_dt, issued_employee_id, issued_employee_position, sickdoc_id, to_dt, witness_employee_id, witness_employee_position)
  VALUES (
    l_clinic_id, p_from_dt, p_issued_employee_id, p_issued_employee_position, p_sickdoc_id, p_to_dt, p_witness_employee_id, p_witness_employee_position);

  PERFORM sickdoc.sickdoc_calculate_and_set_range_dates_and_duration(p_sickdoc_id);
END;
$$;

