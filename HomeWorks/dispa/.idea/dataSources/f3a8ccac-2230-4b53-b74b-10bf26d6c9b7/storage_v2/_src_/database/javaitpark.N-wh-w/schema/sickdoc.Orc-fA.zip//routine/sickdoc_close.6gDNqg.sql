CREATE FUNCTION sickdoc_close(p_id integer, p_ready_to_work_dt date, p_ready_to_work_other_id integer, p_ready_to_work_other_dt date, p_was_in_hospital boolean, p_hospital_from_dt date, p_hospital_to_dt date)
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
  l_hospital_from_dt DATE;
  l_hospital_to_dt DATE;
  l_state_id INTEGER;
  l_cur_number VARCHAR;
BEGIN

  IF (p_ready_to_work_other_id ISNULL) AND (p_ready_to_work_dt ISNULL)
  THEN RAISE EXCEPTION 'Для закрытия ЛН должна быть задана дата "Приступить к работе" или код "Иное"'; END IF;

  IF p_was_in_hospital
  THEN
    l_hospital_from_dt = p_hospital_from_dt;
    l_hospital_to_dt = p_hospital_to_dt;
  END IF;

  SELECT id
  FROM md_sicklist_state
  WHERE code = '3'
  INTO l_state_id;

  IF l_state_id ISNULL
  THEN RAISE EXCEPTION 'Не удалось найти статус ЗАКРЫТ документа нетрудоспособности'; END IF;

  SELECT number
  FROM sickdoc.sickdoc
  WHERE id = p_id
  INTO l_cur_number;

  IF l_cur_number ISNULL
    THEN RAISE EXCEPTION 'Нельзя закрыть ЛН, у которого не задан номер'; END IF;

  UPDATE sickdoc.sickdoc
  SET
    ready_to_work_dt       = p_ready_to_work_dt,
    ready_to_work_other_id = p_ready_to_work_other_id,
    ready_to_work_other_dt = p_ready_to_work_other_dt,
    hospital_from_dt       = l_hospital_from_dt,
    hospital_to_dt         = l_hospital_to_dt,
    state_id               = l_state_id
  WHERE id = p_id;

END;
$$;

