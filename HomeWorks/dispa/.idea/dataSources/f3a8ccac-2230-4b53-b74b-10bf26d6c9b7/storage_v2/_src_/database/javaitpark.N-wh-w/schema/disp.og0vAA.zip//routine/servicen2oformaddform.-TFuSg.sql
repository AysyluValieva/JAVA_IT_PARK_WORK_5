CREATE FUNCTION servicen2oformaddform(xcode character varying, xform character varying, xquery character varying)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
            seq integer;
        begin
             seq = nextval('disp.service_n2o_form_id_seq');
             insert into disp.service_n2o_form (id,service_code, n2o_form, n2o_query) values (seq,xcode,xform, xquery);
             return seq;
        end;
$$;

