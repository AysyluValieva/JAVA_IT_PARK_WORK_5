CREATE FUNCTION fsym_on_i_for_sym_fl_trggr_mngrp()
  RETURNS trigger
LANGUAGE plpgsql
AS $fun$
begin                                                                                                                                                                  
                                   
                                  if 1=1 and 1=1 then                                                                                                 
                                    insert into "public".sym_data                                                                                                                     
                                    (table_name, event_type, trigger_hist_id, row_data, channel_id, transaction_id, source_node_id, external_data, create_time)                                        
                                    values(                                                                                                                                                            
                                      'sym_file_trigger',                                                                                                                                            
                                      'I',                                                                                                                                                             
                                      64,                                                                                                                                             
                                      
          case when new."trigger_id" is null then '' else '"' || replace(replace(cast(new."trigger_id" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."channel_id" is null then '' else '"' || replace(replace(cast(new."channel_id" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."reload_channel_id" is null then '' else '"' || replace(replace(cast(new."reload_channel_id" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."base_dir" is null then '' else '"' || replace(replace(cast(new."base_dir" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."recurse" is null then '' else '"' || cast(cast(new."recurse" as numeric) as varchar) || '"' end||','||
          case when new."includes_files" is null then '' else '"' || replace(replace(cast(new."includes_files" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."excludes_files" is null then '' else '"' || replace(replace(cast(new."excludes_files" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."sync_on_create" is null then '' else '"' || cast(cast(new."sync_on_create" as numeric) as varchar) || '"' end||','||
          case when new."sync_on_modified" is null then '' else '"' || cast(cast(new."sync_on_modified" as numeric) as varchar) || '"' end||','||
          case when new."sync_on_delete" is null then '' else '"' || cast(cast(new."sync_on_delete" as numeric) as varchar) || '"' end||','||
          case when new."sync_on_ctl_file" is null then '' else '"' || cast(cast(new."sync_on_ctl_file" as numeric) as varchar) || '"' end||','||
          case when new."delete_after_sync" is null then '' else '"' || cast(cast(new."delete_after_sync" as numeric) as varchar) || '"' end||','||
          case when new."before_copy_script" is null then '' else '"' || replace(replace(cast(new."before_copy_script" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."after_copy_script" is null then '' else '"' || replace(replace(cast(new."after_copy_script" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."create_time" is null then '' else '"' || to_char(new."create_time", 'YYYY-MM-DD HH24:MI:SS.US') || '"' end||','||
          case when new."last_update_by" is null then '' else '"' || replace(replace(cast(new."last_update_by" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."last_update_time" is null then '' else '"' || to_char(new."last_update_time", 'YYYY-MM-DD HH24:MI:SS.US') || '"' end,                                                                                                                                                      
                                      'config',                                                                                                                                                
                                      txid_current(),                                                                                                                                               
                                      "public".sym_node_disabled(),                                                                                                                   
                                      null,                                                                                                                                               
                                      CURRENT_TIMESTAMP                                                                                                                
                                    );                                                                                                                                                                 
                                  end if;                                                                                                                                                              
                                                                                                                                                                               
                                  return null;                                                                                                                                                         
                                end;
$fun$;

