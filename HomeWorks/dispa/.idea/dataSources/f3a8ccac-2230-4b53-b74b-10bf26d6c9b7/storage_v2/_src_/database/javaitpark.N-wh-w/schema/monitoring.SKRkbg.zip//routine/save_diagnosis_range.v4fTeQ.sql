CREATE FUNCTION save_diagnosis_range(xid integer, xjournal_id integer, xdiagnosis_id integer, xstage text, xmain boolean)
  RETURNS integer
LANGUAGE plpgsql
AS $$
DECLARE
  _id INTEGER;
  BEGIN
      if (xid is null) then
          INSERT INTO monitoring.mn_journal_diagnosis
          (journal_id, diagnosis_id, main_diagnos)
          VALUES
            (xjournal_id, xdiagnosis_id, xmain) returning id into _id;

        ELSE
          UPDATE monitoring.mn_journal_diagnosis SET
            diagnosis_id = xdiagnosis_id,
            main_diagnos = xmain
          WHERE id = xid;

        DELETE FROM monitoring.mn_journal_diagnosis_stage WHERE diagnos_range_id = xid;
          _id = xid;
      END IF;

    INSERT INTO monitoring.mn_journal_diagnosis_stage
    (stage_id, diagnos_range_id)
      (SELECT t.id, _id from (select unnest(array(select value::int from json_array_elements_text(cast(xstage as json)))) as id ) t);

    return _id;
  END;
$$;

