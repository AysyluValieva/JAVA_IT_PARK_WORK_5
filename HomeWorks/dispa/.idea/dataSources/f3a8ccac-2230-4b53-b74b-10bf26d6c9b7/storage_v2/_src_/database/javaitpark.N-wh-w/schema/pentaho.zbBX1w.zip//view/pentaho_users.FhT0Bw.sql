CREATE VIEW pentaho_users AS
  SELECT sec_user.login AS username,
    ''::character varying AS password,
    (NOT sec_user.blocked) AS enabled,
    sec_user.comment AS description
   FROM sec_user;

