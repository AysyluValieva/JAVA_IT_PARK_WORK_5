CREATE FUNCTION fin_bill__get_regions(id integer)
  RETURNS character varying
LANGUAGE plpgsql
AS $$
declare
  element record;
  result text := '';
begin

  for element in
    select r.name
      from fin_bill_main_to_region br
      left join fin_bill_region r on r.id = br.region_id
      where br.main_bill_id = fin_bill__get_regions.id
  loop

    if result <> '' then
      result := result || ', ' || element.name;
    else
      result := element.name;
    end if;

  end loop;

  return result;

end;
$$;

