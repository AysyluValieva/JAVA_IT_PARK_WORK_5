CREATE FUNCTION create_pat_vrem(xsurname character varying, xname character varying, xpatrname character varying, xbirthdt date, xgender integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
	                xpatient_id integer;
	                xindiv_id integer;
	                xuid varchar(50);
                begin
            	    xpatient_id = nextval('pim_party_id_seq');
            	    xindiv_id = nextval('pim_indiv_code_id_seq');
            	    xuid = (SELECT upper(array_to_string(array(( SELECT SUBSTRING('abcdefghijklmnopqrstuvwxyz0123456789' FROM mod(cast((random()*36) as integer), 36)+1 FOR 1)FROM generate_series(1,16))),'')));
                    insert into pim_party (id,note,version,type_id)
                	    values(xpatient_id,'пациент скорой',now(),1);
                	insert into pim_individual (id, surname, name, patr_name, birth_dt,gender_id, list_uid)
                	    values (xpatient_id, xsurname, xname, xpatrName, cast(xbirthdt as date),case when xgender is null then 3 else xgender end, xuid);
                    insert into pim_indiv_code(id, code, issue_dt, type_id, indiv_id) values (xindiv_id, xuid, now(), 8, xpatient_id);
        		    insert into pci_patient (id,created_dt,note)
                	    values (xpatient_id,now(),'пациент скорой');
                    insert into pci_patient_part_case (patient_id, part_case_id,from_dt)
                	    values(xpatient_id,(select id from pci_part_case where part_case_internal_id = (select id from pci_part_case_internal where code = '8')),now());
    	        return xpatient_id;
                end;
$$;

