CREATE VIEW md_osvid_migrants AS
  SELECT mdsrvren.id,
    srvren.bdate AS begin_date,
    (((((COALESCE(indiv.surname, ''::character varying))::text || ' '::text) || (COALESCE(indiv.name, ''::character varying))::text) || ' '::text) || (COALESCE(indiv.patr_name, ''::character varying))::text) AS pat_fio,
    indiv.birth_dt AS pat_birth_date,
    btrim((org.short_name)::text) AS org_short_name,
    (((COALESCE(pd.series, ''::character varying))::text || ' '::text) || (COALESCE(pd.number, ''::character varying))::text) AS pat_nat_passport,
    ( SELECT ehr_protocol_query_result.value
           FROM ehr_protocol_query_result
          WHERE ((ehr_protocol_query_result.query_id = ( SELECT ehp.id
                   FROM ehr_protocol_query ehp
                  WHERE ((ehp.code)::text = 'osvMigrantsDoctor'::text))) AND (ehr_protocol_query_result.protocol_id = srvpr.protocol_id))
          ORDER BY ehr_protocol_query_result.id DESC
         LIMIT 1) AS doctor,
    ( SELECT ehr_protocol_query_result.value
           FROM ehr_protocol_query_result
          WHERE ((ehr_protocol_query_result.query_id = ( SELECT ehp.id
                   FROM ehr_protocol_query ehp
                  WHERE ((ehp.code)::text = 'osvMigrantsCertificateNumber'::text))) AND (ehr_protocol_query_result.protocol_id = srvpr.protocol_id))
          ORDER BY ehr_protocol_query_result.id DESC
         LIMIT 1) AS certif_num,
    ( SELECT ehr_protocol_query_result.value
           FROM ehr_protocol_query_result
          WHERE ((ehr_protocol_query_result.query_id = ( SELECT ehp.id
                   FROM ehr_protocol_query ehp
                  WHERE ((ehp.code)::text = 'osvMigrantsCertificateIssueDate'::text))) AND (ehr_protocol_query_result.protocol_id = srvpr.protocol_id))
          ORDER BY ehr_protocol_query_result.id DESC
         LIMIT 1) AS certif_issue_date,
    ( SELECT ehr_protocol_query_result.value
           FROM ehr_protocol_query_result
          WHERE ((ehr_protocol_query_result.query_id = ( SELECT ehp.id
                   FROM ehr_protocol_query ehp
                  WHERE ((ehp.code)::text = 'osvMigrantsActNumber'::text))) AND (ehr_protocol_query_result.protocol_id = srvpr.protocol_id))
          ORDER BY ehr_protocol_query_result.id DESC
         LIMIT 1) AS act_num
   FROM ((((((((md_srv_rendered mdsrvren
     JOIN sr_srv_rendered srvren ON ((srvren.id = mdsrvren.id)))
     LEFT JOIN sr_service srv ON ((srvren.service_id = srv.id)))
     JOIN md_spj_srv_prototype jprot ON (((jprot.spc_journal_id = ( SELECT md_specialized_journal.id
           FROM md_specialized_journal
          WHERE ((md_specialized_journal.code)::text = 'mom'::text))) AND (jprot.srv_prototype_id = srv.prototype_id))))
     LEFT JOIN md_srv_protocol srvpr ON ((srvpr.srv_rendered_id = srvren.id)))
     LEFT JOIN pim_individual indiv ON ((indiv.id = srvren.customer_id)))
     LEFT JOIN pim_doc pd ON ((pd.indiv_id = indiv.id)))
     LEFT JOIN pim_indiv_doc pid ON ((pd.id = pid.doc_id)))
     LEFT JOIN pim_organization org ON ((srvren.org_id = org.id)))
  WHERE (pid.is_active IS TRUE)
  ORDER BY mdsrvren.id;

