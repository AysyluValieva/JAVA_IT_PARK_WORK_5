CREATE FUNCTION add_res_team_job(xteam integer, xchange integer, xreg integer, xplanbt time without time zone, xplanet time without time zone)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
                job integer;
                xplanbd TIMESTAMP WITHOUT TIME ZONE;
                xplanbchange TIMESTAMP WITHOUT TIME ZONE;
                xplaned TIMESTAMP WITHOUT TIME ZONE;
				xplanechange TIMESTAMP WITHOUT TIME ZONE;
              begin

                select into xplanbchange,xplanechange cast(from_data+from_time as TIMESTAMP),cast(to_data+to_time as TIMESTAMP)
                    from amb.md_ambulance_change where id =  xchange;

                -- определение времени работы наряда по настройкам смены и времени работы бригады
                if (xplanbt is not null)
                    then
                        select into xplanbd cast(from_data+xplanbt as TIMESTAMP)
                            from amb.md_ambulance_change where id =  xchange;
                        if (xplanbchange > xplanbd)
							then
								xplanbd = xplanbchange;
						end if;
                    else
                        xplanbd = xplanbchange;
                end if;
                if (xplanet is not null)
                    then
                        select into xplaned cast(to_data+xplanet as TIMESTAMP)
                            from amb.md_ambulance_change where id =  xchange;
                    if (xplaned > xplanechange)
							then
								xplaned = xplanechange;
						end if;
                    else
                        xplaned = xplanechange;
                end if;

                if not exists (select * from amb.sr_res_team_job where team_id = xteam and change_id = xchange)
                  then
                    job := nextval('amb.sr_res_team_job_id_seq');
                    insert into amb.sr_res_team_job (id,team_id,change_id,planned_bdate,planned_edate,registrator_id)
                        values (job,xteam,xchange,xplanbd,xplaned,xreg);
                  else
                    job := (select id from amb.sr_res_team_job where team_id = xteam and change_id = xchange);
                end if;
                return job;
              end;
$$;

