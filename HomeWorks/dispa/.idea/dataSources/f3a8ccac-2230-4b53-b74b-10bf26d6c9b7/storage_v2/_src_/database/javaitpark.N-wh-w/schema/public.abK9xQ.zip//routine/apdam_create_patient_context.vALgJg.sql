CREATE FUNCTION apdam_create_patient_context(in_type_id integer, in_reg_date date, in_active_address_code character varying)
  RETURNS void
LANGUAGE plpgsql
AS $$
BEGIN
  RAISE NOTICE '----Получаем пациентов которых нужно проверить на возможность прикрепления ...';
  EXECUTE apdam_get_patients(in_type_id, in_reg_date);

  RAISE NOTICE '----Расширяем контекст пациента адресом ...';
  EXECUTE apdam_add_address_to_patients(in_reg_date, in_active_address_code);
END;
$$;

