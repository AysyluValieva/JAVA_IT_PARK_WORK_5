CREATE FUNCTION apda_check_district_by_gender_criterion(gender_id integer, district_id integer)
  RETURNS boolean
LANGUAGE plpgsql
AS $$
BEGIN
  RETURN (SELECT exists(SELECT 1
                        FROM md_district_gender g
                        WHERE g.district_id = $2 AND g.gender_id = $1
                        LIMIT 1));
END;
$$;

