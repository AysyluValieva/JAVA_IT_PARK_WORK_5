CREATE FUNCTION copy_employee_position_resources(source_resource_id integer, destination_resource_id integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
begin
                    insert into sr_resource_service (id, resource_id, service_id)
                        select nextval('sr_resource_service_seq'), destination_resource_id, i.service_id
                        from (select service_id from sr_resource_service where resource_id=source_resource_id ) i
                        left join sr_resource_service rs on rs.service_id=i.service_id and rs.resource_id=destination_resource_id
                        where rs.id is null;
                    return;
                end
$$;

