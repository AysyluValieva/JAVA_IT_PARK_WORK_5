CREATE FUNCTION deleteorphansdiagnosis(xresult_id integer, xid integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
    i integer;
  begin
    if (select exists(select 1 from disp.md_disp_orphans_diagnosis_extended where id = xid and result_id = xresult_id)) then
      delete from disp.md_disp_orphans_diagnosis_extended where id = xid;
    else
      delete from disp.md_disp_orphans_diagnosis_extended_copied where id = xid;
    end if;
    if (select not exists(select 1 from disp.md_disp_orphans_diagnosis_extended where id = xid)
        and not exists(select 1 from disp.md_disp_orphans_diagnosis_extended_copied where id = xid)) then
      delete from MC_DIAGNOSIS where id = xid;
    end if;
  end;
$$;

