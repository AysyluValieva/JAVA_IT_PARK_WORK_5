CREATE FUNCTION fin_get_tariff_from_pricelist(i1_srv_rendered_id integer, i2_position_id integer, i3_price_list_id integer, OUT tariff numeric, OUT code character varying)
  RETURNS record
STABLE
STRICT
LANGUAGE plpgsql
AS $$
DECLARE 
    _rec RECORD;
    _tariff DECIMAL;
    _code TEXT;
BEGIN
    /*
        current version date 28.10.2014
        
        changelog 
    */
    SELECT coalesce (p.price, 0), coalesce (trim (p.code), '') INTO STRICT _tariff, _code FROM fin_pl_position AS p WHERE p.id = i2_position_id
    ;
    FOR _rec IN 
        SELECT 
            m.condition, m.type, m.value, m.code  
        FROM 
            fin_price_modifier               AS m
            LEFT JOIN fin_modifier_to_pl_pos AS t ON t.pl_position_id = i2_position_id AND t.price_modifier_id = m.id
        WHERE 
            m.price_list_id = i3_price_list_id AND (m.scope_id = 1 OR (m.scope_id = 2 AND t.id IS NOT NULL))
        ORDER BY m.apply_order, m.id
    LOOP
        IF 
            fin_price_modifier_need_apply (i1_srv_rendered_id, _rec.condition) 
        THEN
            IF    _rec.type = 1 THEN _tariff := _tariff * cast (_rec.value AS DECIMAL); _code := _rec.code; 
            ELSIF _rec.type = 2 THEN _tariff := _tariff + cast (_rec.value AS DECIMAL); _code := _rec.code; 
            ELSIF _rec.type = 3 THEN _tariff := cast (_rec.value AS DECIMAL); _code := _rec.code; 
            ELSIF _rec.type = 4 THEN EXECUTE replace (_rec.value::TEXT, '?', i1_srv_rendered_id::TEXT) INTO _tariff; _code := _rec.code;
            END IF;
            EXIT;
        END IF;
    END LOOP;
    
    tariff := _tariff;
    code := _code;
END;
$$;

