CREATE FUNCTION fsym_on_u_for_pblc_pc_ptnt_mngrp()
  RETURNS trigger
LANGUAGE plpgsql
AS $fun$
declare var_row_data text; 
                                declare var_old_data text; 
                                begin
                                   
                                  if 1=1 and "public".sym_triggers_disabled() = 0 then                                                                                                 
                                    var_row_data := 
          case when new."id" is null then '' else '"' || cast(cast(new."id" as numeric) as varchar) || '"' end||','||
          case when new."created_dt" is null then '' else '"' || to_char(new."created_dt", 'YYYY-MM-DD HH24:MI:SS.US') || '"' end||','||
          case when new."note" is null then '' else '"' || replace(replace(cast(new."note" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."vip" is null then '' when new."vip" then '"1"' else '"0"' end||','||
          case when new."rh_blood_group_id" is null then '' else '"' || cast(cast(new."rh_blood_group_id" as numeric) as varchar) || '"' end||','||
          case when new."ethnic_group_id" is null then '' else '"' || cast(cast(new."ethnic_group_id" as numeric) as varchar) || '"' end||','||
          case when new."social_group_id" is null then '' else '"' || cast(cast(new."social_group_id" as numeric) as varchar) || '"' end||','||
          case when new."death_src_inf_id" is null then '' else '"' || cast(cast(new."death_src_inf_id" as numeric) as varchar) || '"' end||','||
          case when new."empl_state_death_id" is null then '' else '"' || cast(cast(new."empl_state_death_id" as numeric) as varchar) || '"' end||','||
          case when new."unidentified_dt" is null then '' else '"' || to_char(new."unidentified_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when new."newborn_number" is null then '' else '"' || cast(cast(new."newborn_number" as numeric) as varchar) || '"' end||','||
          case when new."education_type_id" is null then '' else '"' || cast(cast(new."education_type_id" as numeric) as varchar) || '"' end||','||
          case when new."birthweight" is null then '' else '"' || cast(cast(new."birthweight" as numeric) as varchar) || '"' end||','||
          case when new."employee_reg_death_position_id" is null then '' else '"' || cast(cast(new."employee_reg_death_position_id" as numeric) as varchar) || '"' end||','||
          case when new."last_fluorography_date" is null then '' else '"' || to_char(new."last_fluorography_date", 'YYYY-MM-DD HH24:MI:SS') || '"' end; 
                                    var_old_data := 
          case when old."id" is null then '' else '"' || cast(cast(old."id" as numeric) as varchar) || '"' end||','||
          case when old."created_dt" is null then '' else '"' || to_char(old."created_dt", 'YYYY-MM-DD HH24:MI:SS.US') || '"' end||','||
          case when old."note" is null then '' else '"' || replace(replace(cast(old."note" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when old."vip" is null then '' when old."vip" then '"1"' else '"0"' end||','||
          case when old."rh_blood_group_id" is null then '' else '"' || cast(cast(old."rh_blood_group_id" as numeric) as varchar) || '"' end||','||
          case when old."ethnic_group_id" is null then '' else '"' || cast(cast(old."ethnic_group_id" as numeric) as varchar) || '"' end||','||
          case when old."social_group_id" is null then '' else '"' || cast(cast(old."social_group_id" as numeric) as varchar) || '"' end||','||
          case when old."death_src_inf_id" is null then '' else '"' || cast(cast(old."death_src_inf_id" as numeric) as varchar) || '"' end||','||
          case when old."empl_state_death_id" is null then '' else '"' || cast(cast(old."empl_state_death_id" as numeric) as varchar) || '"' end||','||
          case when old."unidentified_dt" is null then '' else '"' || to_char(old."unidentified_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when old."newborn_number" is null then '' else '"' || cast(cast(old."newborn_number" as numeric) as varchar) || '"' end||','||
          case when old."education_type_id" is null then '' else '"' || cast(cast(old."education_type_id" as numeric) as varchar) || '"' end||','||
          case when old."birthweight" is null then '' else '"' || cast(cast(old."birthweight" as numeric) as varchar) || '"' end||','||
          case when old."employee_reg_death_position_id" is null then '' else '"' || cast(cast(old."employee_reg_death_position_id" as numeric) as varchar) || '"' end||','||
          case when old."last_fluorography_date" is null then '' else '"' || to_char(old."last_fluorography_date", 'YYYY-MM-DD HH24:MI:SS') || '"' end; 
                                    if 1=1 then 
                                    insert into "public".sym_data                                                                                                                     
                                    (table_name, event_type, trigger_hist_id, pk_data, row_data, old_data, channel_id, transaction_id, source_node_id, external_data, create_time)                     
                                    values(                                                                                                                                                            
                                      'pci_patient',                                                                                                                                            
                                      'U',                                                                                                                                                             
                                      17,                                                                                                                                             
                                      
          case when old."id" is null then '' else '"' || cast(cast(old."id" as numeric) as varchar) || '"' end,                                                                                                                                                      
                                      var_row_data,                                                                                                                                                      
                                      var_old_data,                                                                                                                                                   
                                      'public_pci_patient_default',                                                                                                                                                
                                      txid_current(),                                                                                                                                               
                                      "public".sym_node_disabled(),                                                                                                                   
                                      null,                                                                                                                                               
                                      CURRENT_TIMESTAMP                                                                                                                
                                    );                                                                                                                                                                 
                                  end if;                                                                                                                                                              
                                  end if;                                                                                                                                                              
                                                                                                                                                                               
                                  return null;                                                                                                                                                         
                                end;
$fun$;

