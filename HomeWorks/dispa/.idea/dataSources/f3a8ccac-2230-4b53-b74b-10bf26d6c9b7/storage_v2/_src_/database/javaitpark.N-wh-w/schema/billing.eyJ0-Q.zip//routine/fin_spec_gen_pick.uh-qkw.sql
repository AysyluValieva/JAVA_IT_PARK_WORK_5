CREATE FUNCTION fin_spec_gen_pick(p1_bill_id integer, p2_status text)
  RETURNS void
STRICT
LANGUAGE plpgsql
AS $$
DECLARE 
    _main_bill_id INTEGER := public.fin_bill__get_main_bill (p1_bill_id);
    _base_bill_id INTEGER := (SELECT base_id FROM public.fin_bill_correctional WHERE id = p1_bill_id);
    _p RECORD;
BEGIN
    /*
        version: 2015-09-14
    */
    --------------------------------------------------очистка от предыдущего формирования------------------------------------------------------------
    IF 
        p2_status IN ('VALIDATE', 'RECALCULATE')
    THEN
        WITH t AS 
        (
            SELECT 
                s.bill_id, s.spec_item_id AS id 
            FROM 
                billing.fin_bill_steps AS s LEFT JOIN public.fin_bill_spec_item AS i ON s.spec_item_id = i.id AND s.bill_id = i.bill_id 
            WHERE 
                s.bill_id = p1_bill_id AND i.id IS NULL
        )
        DELETE FROM billing.fin_bill_steps AS s USING t WHERE s.bill_id = t.bill_id AND s.spec_item_id = t.id
        ;
    END IF;
    DELETE FROM billing.fin_bill_generate WHERE bill_id = p1_bill_id
    ;
    DELETE FROM public.fin_bill_spec_item WHERE bill_id = p1_bill_id
    ;
    ------------------------------------------------------------------параметры----------------------------------------------------------------------
    SELECT 
        coalesce (a.from_date, m.from_date) AS from_dt, coalesce (a.to_date, m.to_date) AS to_dt, m.clinic_id, m.price_list_id INTO _p
    FROM
        public.fin_bill_main AS m LEFT JOIN public.fin_bill_additional AS a ON m.id = a.base_id AND a.id = p1_bill_id
    WHERE
        m.id = _main_bill_id
    ;
    IF
        p2_status IN ('CORRECT', 'RECALCULATE') AND _base_bill_id <> _main_bill_id
    THEN
        SELECT 
            coalesce (a.from_date, m.from_date), coalesce (a.to_date, m.to_date) INTO _p.from_dt, _p.to_dt
        FROM
            public.fin_bill_main AS m LEFT JOIN public.fin_bill_additional AS a ON m.id = a.base_id AND a.id = _base_bill_id
        WHERE
            m.id = _main_bill_id
        ;
    END IF;
    -----------------------------------------------------------первичное добавление------------------------------------------------------------------
    IF
        p2_status = 'CORRECT'
    THEN
        UPDATE public.fin_bill_spec_item
        SET 
            correctional_bill_id = p1_bill_id
        WHERE
            bill_id = _base_bill_id AND correctional_bill_id IS NULL AND status_id IN (3, 4)
        ;
    END IF;
    EXECUTE
        concat
        (
            'INSERT INTO billing.fin_bill_generate ',
            '(',
                'id, bdate, edate, service_id, comment, tooth_number, funding_id, step_id, res_group_id, rdd_diagnosis_id, ',
                'case_id, case_type_id, care_level_id, care_regimen_id, provision_condition_id, init_goal_id, payment_method_id, ',
                'patient_id, closing_step_id, case_open_date, case_close_date, ',
                'org_id, contract_id, bill_id, price_list_id, from_date, to_date',
            ') ',
                'SELECT ',
                    's.id, s.bdate, s.edate, s.service_id, s.comment, s.tooth_number, coalesce (s.funding_id, c.funding_id, 0), m.step_id, s.res_group_id, m.diagnosis_id, ',
                    'c.id, c.case_type_id, c.care_level_id, c.care_regimen_id, c.provision_condition_id, c.init_goal_id, c.payment_method_id, ',
                    'c.patient_id, c.closing_step_id, c.open_date, c.close_date, ',
                    'coalesce (s.org_id, c.clinic_id), coalesce (s.contract_id, 0), ', p1_bill_id, ', ', _p.price_list_id, ', ''', _p.from_dt, ''', ''', _p.to_dt, ''' ',
                'FROM ',
                    CASE
                        WHEN
                            p2_status = 'GENERATE'
                        THEN
                            concat
                            (
                                'public.mc_case AS c ',
                                'JOIN public.md_srv_rendered AS m ON m.case_id = c.id AND NOT EXISTS (SELECT 1 FROM public.fin_bill_spec_item WHERE service_id = m.id) ',
                                'JOIN public.sr_srv_rendered AS s ON s.id = m.id ',
                            'WHERE ',
                                'c.closing_step_id IS NOT NULL AND c.clinic_id = ', _p.clinic_id, ' AND c.close_date BETWEEN ''', _p.from_dt, ''' AND ''', _p.to_dt, ''' ', billing.fin_get_bill_restrictions (p1_bill_id)
                            )
                        WHEN
                            p2_status IN ('VALIDATE', 'RECALCULATE')
                        THEN
                            concat
                            (
                                'billing.fin_bill_steps AS f ', 
                                'JOIN public.md_srv_rendered AS m ON m.id = f.srv_rendered_id ', 
                                'JOIN public.sr_srv_rendered AS s ON s.id = m.id ', 
                                'JOIN public.mc_case AS c ON c.id = m.case_id ',
                            'WHERE ', 
                                'f.bill_id = ', p1_bill_id
                            )
                        WHEN
                            p2_status = 'CORRECT'
                        THEN
                            concat
                            (
                                'public.fin_bill_spec_item AS i ', 
                                'JOIN public.md_srv_rendered AS m ON m.id = i.service_id ', 
                                'JOIN public.sr_srv_rendered AS s ON s.id = m.id ', 
                                'JOIN public.mc_case AS c ON c.id = m.case_id ', 
                            'WHERE ', 
                                'i.bill_id = ', _base_bill_id, ' AND i.correctional_bill_id = ', p1_bill_id
                            )
                        ELSE
                            NULL
                    END
        )
    ;
EXCEPTION
    WHEN NO_DATA_FOUND THEN RAISE EXCEPTION 'Не заполнены необходимые параметры, либо неправильные данные счёта';
END;
$$;

