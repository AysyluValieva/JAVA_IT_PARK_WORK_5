CREATE FUNCTION apdam_detach_reg(in_reg_date date, in_detachment_type integer, in_specific_criteria character varying)
  RETURNS void
LANGUAGE plpgsql
AS $$
BEGIN
  IF in_detachment_type = 2
  THEN
    WITH cte AS (
        SELECT *
        FROM apdam_regs r
        WHERE r.new_district_id ISNULL
    )
    UPDATE pci_patient_reg r
    SET
      state_id = 2,
      unreg_cause_id = 1,
      unreg_dt = in_reg_date
    FROM cte
    WHERE cte.reg_id = r.id;
  ELSE
    WITH cte AS (
        SELECT *
        FROM apdam_regs r
        WHERE r.current_district_id ISNULL AND r.new_district_id ISNULL
    )
    UPDATE pci_patient_reg r
    SET
      state_id       = 2,
      unreg_cause_id = 1,
      unreg_dt       = in_reg_date
    FROM cte
    WHERE cte.reg_id = r.id;

    IF in_specific_criteria NOTNULL AND in_specific_criteria != ''
    THEN
      EXECUTE apdam_detach_regs_by_specific_criteria(in_reg_date, in_specific_criteria);
    END IF;
  END IF;
END;
$$;

