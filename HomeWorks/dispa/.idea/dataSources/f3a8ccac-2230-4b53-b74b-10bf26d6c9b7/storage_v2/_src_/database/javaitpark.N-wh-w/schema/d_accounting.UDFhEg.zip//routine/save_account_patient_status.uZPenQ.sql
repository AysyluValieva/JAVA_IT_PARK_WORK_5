CREATE FUNCTION save_account_patient_status(xid integer, xaccountid integer, xdis integer, xdisid integer, xpsdisabilityid integer, xdisreasonid integer, xbenefitid integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
DECLARE
  _id                  INTEGER;
  _accountDisabilityId INTEGER;
BEGIN
  _id = xid;

  IF (xpsDisabilityId IS NOT NULL)
  THEN
    _accountDisabilityId = xpsDisabilityId;
  ELSE
    _accountDisabilityId = xdisId;
  END IF;

  IF (_accountDisabilityId IS NOT NULL)
  THEN
    UPDATE public.md_disability
    SET disability_reason_id = xdisReasonId
    WHERE id = _accountDisabilityId;
  END IF;

  IF (_id IS NULL)
  THEN
    INSERT INTO d_accounting.patient_status (id,account_id, disability, disability_id, benefit_id)
    VALUES (nextval('d_accounting.patient_status_seq'),xaccountId, xdis, _accountDisabilityId, xbenefitId)
    RETURNING id
      INTO _id;
  ELSE
    UPDATE d_accounting.patient_status
    SET disability = xdis, benefit_id = xbenefitId, disability_id = _accountDisabilityId
    WHERE id = _id;
  END IF;

  IF (xdis <> 1)
  THEN
    UPDATE d_accounting.patient_status
    SET disability_id = NULL
    WHERE id = _id;
  END IF;

  RETURN _id;
END;
$$;

