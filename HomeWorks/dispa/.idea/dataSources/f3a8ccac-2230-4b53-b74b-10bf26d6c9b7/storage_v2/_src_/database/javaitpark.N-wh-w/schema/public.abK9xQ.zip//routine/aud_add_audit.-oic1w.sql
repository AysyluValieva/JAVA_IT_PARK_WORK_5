CREATE FUNCTION aud_add_audit(table_name text)
  RETURNS void
LANGUAGE plpgsql
AS $$
BEGIN
	EXECUTE format('select aud_add_audit_columns(''%s'');
			select aud_add_audit_trigger(''%s'')', $1, $1);
    END;
$$;

