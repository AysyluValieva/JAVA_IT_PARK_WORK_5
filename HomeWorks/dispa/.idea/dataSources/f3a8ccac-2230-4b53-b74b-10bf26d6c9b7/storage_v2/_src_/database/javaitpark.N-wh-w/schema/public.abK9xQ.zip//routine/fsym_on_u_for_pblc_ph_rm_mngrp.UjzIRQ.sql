CREATE FUNCTION fsym_on_u_for_pblc_ph_rm_mngrp()
  RETURNS trigger
LANGUAGE plpgsql
AS $fun$
declare var_row_data text; 
                                declare var_old_data text; 
                                begin
                                   
                                  if 1=1 and "public".sym_triggers_disabled() = 0 then                                                                                                 
                                    var_row_data := 
          case when new."id" is null then '' else '"' || cast(cast(new."id" as numeric) as varchar) || '"' end||','||
          case when new."bathroom_quantity" is null then '' else '"' || cast(cast(new."bathroom_quantity" as numeric) as varchar) || '"' end||','||
          case when new."ceiling_area" is null then '' else '"' || cast(cast(new."ceiling_area" as numeric) as varchar) || '"' end||','||
          case when new."equipment_area" is null then '' else '"' || cast(cast(new."equipment_area" as numeric) as varchar) || '"' end||','||
          case when new."furniture_area" is null then '' else '"' || cast(cast(new."furniture_area" as numeric) as varchar) || '"' end||','||
          case when new."shower_quantity" is null then '' else '"' || cast(cast(new."shower_quantity" as numeric) as varchar) || '"' end||','||
          case when new."sink_quantity" is null then '' else '"' || cast(cast(new."sink_quantity" as numeric) as varchar) || '"' end||','||
          case when new."toilet_sink_quantity" is null then '' else '"' || cast(cast(new."toilet_sink_quantity" as numeric) as varchar) || '"' end||','||
          case when new."wall_area" is null then '' else '"' || cast(cast(new."wall_area" as numeric) as varchar) || '"' end||','||
          case when new."danger_category_id" is null then '' else '"' || cast(cast(new."danger_category_id" as numeric) as varchar) || '"' end||','||
          case when new."kitchen_quantity" is null then '' else '"' || cast(cast(new."kitchen_quantity" as numeric) as varchar) || '"' end||','||
          case when new."balcony_quantity" is null then '' else '"' || cast(cast(new."balcony_quantity" as numeric) as varchar) || '"' end||','||
          case when new."room_quantity" is null then '' else '"' || cast(cast(new."room_quantity" as numeric) as varchar) || '"' end||','||
          case when new."window_view" is null then '' else '"' || replace(replace(cast(new."window_view" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end; 
                                    var_old_data := 
          case when old."id" is null then '' else '"' || cast(cast(old."id" as numeric) as varchar) || '"' end||','||
          case when old."bathroom_quantity" is null then '' else '"' || cast(cast(old."bathroom_quantity" as numeric) as varchar) || '"' end||','||
          case when old."ceiling_area" is null then '' else '"' || cast(cast(old."ceiling_area" as numeric) as varchar) || '"' end||','||
          case when old."equipment_area" is null then '' else '"' || cast(cast(old."equipment_area" as numeric) as varchar) || '"' end||','||
          case when old."furniture_area" is null then '' else '"' || cast(cast(old."furniture_area" as numeric) as varchar) || '"' end||','||
          case when old."shower_quantity" is null then '' else '"' || cast(cast(old."shower_quantity" as numeric) as varchar) || '"' end||','||
          case when old."sink_quantity" is null then '' else '"' || cast(cast(old."sink_quantity" as numeric) as varchar) || '"' end||','||
          case when old."toilet_sink_quantity" is null then '' else '"' || cast(cast(old."toilet_sink_quantity" as numeric) as varchar) || '"' end||','||
          case when old."wall_area" is null then '' else '"' || cast(cast(old."wall_area" as numeric) as varchar) || '"' end||','||
          case when old."danger_category_id" is null then '' else '"' || cast(cast(old."danger_category_id" as numeric) as varchar) || '"' end||','||
          case when old."kitchen_quantity" is null then '' else '"' || cast(cast(old."kitchen_quantity" as numeric) as varchar) || '"' end||','||
          case when old."balcony_quantity" is null then '' else '"' || cast(cast(old."balcony_quantity" as numeric) as varchar) || '"' end||','||
          case when old."room_quantity" is null then '' else '"' || cast(cast(old."room_quantity" as numeric) as varchar) || '"' end||','||
          case when old."window_view" is null then '' else '"' || replace(replace(cast(old."window_view" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end; 
                                    if var_old_data is null or var_row_data != var_old_data then 
                                    insert into "public".sym_data                                                                                                                     
                                    (table_name, event_type, trigger_hist_id, pk_data, row_data, old_data, channel_id, transaction_id, source_node_id, external_data, create_time)                     
                                    values(                                                                                                                                                            
                                      'pha_room',                                                                                                                                            
                                      'U',                                                                                                                                                             
                                      469,                                                                                                                                             
                                      
          case when old."id" is null then '' else '"' || cast(cast(old."id" as numeric) as varchar) || '"' end,                                                                                                                                                      
                                      var_row_data,                                                                                                                                                      
                                      var_old_data,                                                                                                                                                   
                                      'public_pha_room_default',                                                                                                                                                
                                      txid_current(),                                                                                                                                               
                                      "public".sym_node_disabled(),                                                                                                                   
                                      null,                                                                                                                                               
                                      CURRENT_TIMESTAMP                                                                                                                
                                    );                                                                                                                                                                 
                                  end if;                                                                                                                                                              
                                  end if;                                                                                                                                                              
                                                                                                                                                                               
                                  return null;                                                                                                                                                         
                                end;
$fun$;

