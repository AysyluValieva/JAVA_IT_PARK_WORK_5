CREATE VIEW sr_service_node_v AS
  WITH RECURSIVE service_node(top_node_id, parent_node_id, id, name, is_required, is_default) AS (
         SELECT s.id,
            NULL::integer AS int4,
            s.id,
            s.name,
            true AS bool,
            true AS bool
           FROM sr_service s
        UNION
         SELECT n.top_node_id,
            c.complex_id,
            c.service_id,
            s.name,
            COALESCE(c.is_required, false) AS "coalesce",
            COALESCE(c.is_default, false) AS "coalesce"
           FROM sr_srv_composition c,
            sr_service s,
            service_node n
          WHERE ((c.service_id = s.id) AND (c.complex_id = n.id))
        )
 SELECT service_node.top_node_id,
    service_node.parent_node_id,
    service_node.id,
    service_node.name,
    service_node.is_required,
    service_node.is_default
   FROM service_node;

