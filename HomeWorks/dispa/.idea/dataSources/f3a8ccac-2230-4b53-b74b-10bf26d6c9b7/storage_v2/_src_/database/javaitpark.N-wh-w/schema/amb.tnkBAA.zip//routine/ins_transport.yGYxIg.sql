CREATE FUNCTION ins_transport(xorg_id integer, xcode character varying, xinventory_number character varying, xinventory_code character varying, xokof_code character varying, xcategory_id integer, xtype_id integer, xtransport_equipment_id integer, xbrand_name_id integer, xmodel_id integer, xmodel character varying, xmanufacturer_id integer, xcountry_id integer, xissue_dt date, xdepartment_id integer, xpurchase_dt date, xownership_pattern_id integer, xwarranty_dt date, xservice_period integer, xservice_measure_id integer, xbuilding_id integer, xroom_id integer, xres boolean, xcontract_id integer, xfrom_dt date, xto_dt date, xunit_id integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
                        xid integer;
                        xresid integer;
                        xstate integer;
                  begin
                    xid = nextval('amb.pim_transport_id_seq');
                    insert into amb.pim_transport (id,org_id,code,inventory_number,okof_code,category_id,type_id,transport_equipment_id,-- Тип транспортного средства по паспорту
                                                brand_name_id,model_id,model,manufacturer_id,country_id,issue_dt,department_id,purchase_dt,
                                                ownership_pattern_id,warranty_dt,service_period,service_measure_id,building_id,room_id,
                                                contract_id,from_dt,to_dt,unit_id,inventory_code)
                        values (xid,xorg_id,xcode,xinventory_number,xokof_code,xcategory_id,xtype_id,xtransport_equipment_id,-- Тип транспортного средства по паспорту
                                                xbrand_name_id,xmodel_id,xmodel,xmanufacturer_id,xcountry_id,xissue_dt,xdepartment_id,xpurchase_dt,
                                                xownership_pattern_id,xwarranty_dt,xservice_period,xservice_measure_id,xbuilding_id,xroom_id,
                                                xcontract_id,xfrom_dt,xto_dt,xunit_id,xinventory_code);
                    xstate = (select id from pim_stock_unit_state where code = '54');
                    insert into amb.pim_transport_state (transport_id,state_id,from_dt)
                        values(xid,xstate,xfrom_dt);
                    execute amb.res_transport(xres,xid,xfrom_dt);
                    return xid;
                  end;
$$;

