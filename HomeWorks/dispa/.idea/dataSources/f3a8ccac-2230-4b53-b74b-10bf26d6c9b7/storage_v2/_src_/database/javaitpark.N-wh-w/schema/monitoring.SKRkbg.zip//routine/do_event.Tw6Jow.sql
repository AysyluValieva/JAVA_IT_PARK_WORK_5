CREATE FUNCTION do_event(params hstore, event character varying)
  RETURNS character varying
LANGUAGE plpgsql
AS $$
DECLARE
arg VARCHAR;
args VARCHAR[];
result VARCHAR;
test text;
BEGIN

SELECT ARRAY(SELECT DISTINCT (regexp_matches(event, '\:+[\w]+', 'g'))[1]::varchar) INTO args;

FOREACH arg IN ARRAY args
LOOP
  IF(LENGTH (SUBSTRING (arg FROM '\:+')) = 1) THEN
	  event = regexp_replace(event, arg, (params -> regexp_replace(arg, ':', '')::varchar)::varchar, 'g');
	  END IF;
END LOOP;

EXECUTE event
INTO result;
RETURN result::VARCHAR;
EXCEPTION
  WHEN others THEN
   RAISE NOTICE 'SQLSTATE: %. QUERY: %. ARGS: %', SQLSTATE, event, args;
   RETURN NULL;
END;
$$;

