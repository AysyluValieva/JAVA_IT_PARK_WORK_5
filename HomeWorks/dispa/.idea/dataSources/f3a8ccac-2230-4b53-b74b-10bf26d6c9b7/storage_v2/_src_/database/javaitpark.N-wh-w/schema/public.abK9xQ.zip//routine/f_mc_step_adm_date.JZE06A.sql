CREATE FUNCTION f_mc_step_adm_date()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
	if NEW.admission_date is null then 
		  NEW.admission_date := current_date;
	end if;
	return new;
END
$$;

