CREATE FUNCTION get_audit_data_by_filters_query(_table_setting_id integer, _aud_record_id character varying, _record_id character varying, _sec_user_login character varying, _periods character varying)
  RETURNS character varying
LANGUAGE plpgsql
AS $$
DECLARE
                  setting_record        RECORD;
                  select_id_query       VARCHAR = 'concat(''id: '', a.id)';
                  where_period_query    VARCHAR = '';
                  where_id_query        VARCHAR = '';
                  partition_period_code VARCHAR;
                  shift                 VARCHAR;
                  base_query            VARCHAR;
                  empty_query           VARCHAR;
                BEGIN
                  IF _table_setting_id NOTNULL
                  THEN
                    SELECT *
                    INTO setting_record
                    FROM audit.table_setting t
                    WHERE t.id = _table_setting_id;
                  ELSE
                    SELECT *
                    INTO setting_record
                    FROM audit.table_setting t
                    WHERE concat('audit.', table_schema, '$', table_name) = split_part(_aud_record_id, ':', 1);
                  END IF;

                  empty_query = 'SELECT :select ' ||
                                'FROM audit.' || setting_record.table_schema || '$' || setting_record.table_name || ' a '
                                'WHERE 1 = 0 ';

                  IF setting_record.is_has_default_primary_key
                  THEN
                    IF _record_id NOTNULL
                    THEN
                      IF _record_id LIKE 'id:%' THEN _record_id = split_part(trim(_record_id), ':', 2); END IF;
                      IF _record_id ~ '^[0-9]+$' = FALSE THEN RETURN empty_query; END IF;
                      where_id_query = concat(' AND a.id = ', _record_id, ' ');
                    END IF;
                  ELSE
                    SELECT concat('concat(', string_agg(c1, ', '';'', '), ')')
                    INTO select_id_query
                    FROM (
                           SELECT concat('''', column_name, ': '', ', column_name) AS c1
                           FROM information_schema.columns
                           WHERE table_schema = 'audit' AND
                                 table_name = concat(setting_record.table_schema, '$', setting_record.table_name) AND
                                 column_name NOT IN ('aud_rec', 'type', 'delta', 'aud_when', 'aud_who', 'aud_source')) t;
                    IF _record_id NOTNULL
                    THEN
                      BEGIN
                        where_id_query = concat(' AND ', replace(replace(_record_id, '[;]', ''' AND '), '[:]', '::VARCHAR = '''), '''');
                        EXECUTE format('SELECT 1 FROM %1$s WHERE 1=1 %2$s',
                                       concat(setting_record.table_schema, '.', setting_record.table_name), where_id_query);
                        EXCEPTION WHEN OTHERS THEN
                        RETURN empty_query;
                      END;
                    END IF;
                  END IF;

                  SELECT lower(code)
                  INTO partition_period_code
                  FROM audit.partition_period
                  WHERE id = setting_record.partition_period_id;

                  IF partition_period_code != 'none'
                  THEN
                    IF _periods = '0'
                    THEN
                      RETURN empty_query;
                    END IF;

                    IF partition_period_code = 'quarter'
                    THEN shift = '3 month';
                    ELSE shift = concat('1 ', partition_period_code);
                    END IF;

                    EXECUTE format('
                      SELECT concat('' AND ('', string_agg(it, '' OR ''), '')'')
                      FROM
                        (SELECT concat(''a.aud_when BETWEEN '''''', t.begin, '''''' AND '''''', (t.begin + INTERVAL ''%1$s'') :: DATE,
                          '''''''') AS it
                          FROM (SELECT to_date(x, ''YYYYMMDD'') AS begin
                            FROM (SELECT unnest(string_to_array(''%2$s'', '','')) x) t) t) t', shift, _periods)
                    INTO where_period_query;
                    ELSE
                      IF _periods != '0'
                      THEN
                        RETURN empty_query;
                      END IF;
                  END IF;

                  base_query = 'SELECT :select ' ||
                               'FROM audit.' || setting_record.table_schema || '$' || setting_record.table_name || ' a '
                               'WHERE 1=1 ' || where_id_query;

                  IF _sec_user_login NOTNULL THEN
                    base_query = concat(base_query, ' AND a.aud_who = ''' || _sec_user_login || '''');
                  END IF;

                  base_query = concat(base_query, where_period_query);

                  RETURN base_query;
                END;
$$;

