CREATE FUNCTION add_new_patient(_birth_dt character varying, _surname character varying, _name character varying, _patr_name character varying, _snils character varying, _mobilephone character varying, _lpu_id character varying)
  RETURNS integer
LANGUAGE plpgsql
AS $$
DECLARE
  _r RECORD;
  _patient_id_result integer;
	_id_doc integer;
	_code_id INTEGER;
BEGIN
	_patient_id_result=null;
	--ищем по енп
if exists (select 1 from pim_individual_doc where regexp_replace(number, '-|\s|\/|\\', '', 'g') = regexp_replace(_snils, '-|\s|\/|\\', '', 'g'))
then 
		select indiv_id into _patient_id_result from pim_individual_doc where regexp_replace(number, '-|\s|\/|\\', '', 'g') = regexp_replace(_snils, '-|\s|\/|\\', '', 'g') limit 1;	
		--RETURN _patient_id_result;
end if;	
--если по енп не нашли, то ищем пациента по фио
if  ( _patient_id_result is null and exists(select 1 from pim_individual where upper(name)=upper(_name) and upper(surname)=upper(_surname)  and upper(patr_name)=upper(_patr_name) and birth_dt=_birth_dt::date))
then 
		select id into _patient_id_result 
					from pim_individual 
							where upper(name)=upper(_name) and upper(surname)=upper(_surname)  and upper(patr_name)=upper(_patr_name) and birth_dt=_birth_dt::date limit 1;	
		RETURN _patient_id_result;
end if;	

--если и по енп не нашли, то добавляем пациента
if (_patient_id_result is null)
then 
		--добавить пациента
	_patient_id_result=nextval('pim_party_id_seq');
	_id_doc = nextval('pim_individual_doc_id_seq');
	insert into pim_party(id, type_id ) 
			values(_patient_id_result,1 );
	insert into pim_individual (id, surname, name, patr_name, birth_dt)
			values(_patient_id_result, _surname, _name, _patr_name, _birth_dt::date);
	insert into pim_indiv_code (id, code, type_id, indiv_id) 
					values(nextval('"public"."pim_indiv_code_id_seq"'), "public"."random_string"(16), 8, _patient_id_result);
	insert into pci_patient(id, note)
	values(_patient_id_result, 'интеграция');
end if;


--добавить енп или обновить
if(_snils is not null )
then
		if(  exists(select 1 from pim_individual_doc 
														where regexp_replace(number, '-|\s|\/|\\', '', 'g') <> regexp_replace(_snils, '-|\s|\/|\\', '', 'g') 
																	and indiv_id=_patient_id_result 
																	and type_id=26
								)
			)
		then 
			update pim_individual_doc set number=_snils where indiv_id=_patient_id_result and type_id=26;
			update pim_indiv_code set code=_snils where  indiv_id=_patient_id_result and type_id=3;
		else 
				_code_id=nextval('"public"."pim_indiv_code_id_seq"');
			insert into pim_indiv_code (id, code, type_id, indiv_id) 
					values(_code_id, _snils, 3, _patient_id_result);
			insert into pim_individual_doc (id, type_id, number, indiv_id,code_id)
				values (_id_doc, 26, _snils, _patient_id_result,_code_id );
		end if;
end if;
		--добавить телефон
	if(_mobilephone is not null and not exists (select 1 from pim_indiv_contact where indiv_id=_patient_id_result and regexp_replace(value, '-|\s|\/|\\', '', 'g') like '%'||_mobilephone and type_id=3))
	THEN
			insert into pim_indiv_contact (id, indiv_id , value , type_id)
				values(nextval('"public"."pim_indiv_contact_id_seq"'),_patient_id_result, _mobilephone, 2);
	end if;

if(_lpu_id is not null and not exists(select 1 from pci_patient_reg where patient_id=_lpu_id::integer and state_id=1 and (unreg_dt is null or unreg_dt>=CURRENT_DATE)))
THEN
		insert into pci_patient_reg (id, clinic_id,patient_id, state_id,type_id )
			values(nextval('"public"."pci_patient_reg_id_seq"'),_lpu_id::integer, _patient_id_result, 1,1);
end if;

RETURN _patient_id_result;



END;
$$;

