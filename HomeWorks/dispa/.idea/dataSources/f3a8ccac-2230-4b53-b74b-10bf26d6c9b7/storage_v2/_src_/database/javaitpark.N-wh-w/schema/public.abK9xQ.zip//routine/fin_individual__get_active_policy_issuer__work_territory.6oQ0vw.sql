CREATE FUNCTION fin_individual__get_active_policy_issuer__work_territory(individual_id integer, date date)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
    i integer;
begin
    i = (select fin_individual__get_active_policy(individual_id, date));
    if i is null then return null;
    end if;
    i = (select issuer_id from pim_individual_doc where id = i);
    if i is null then return null;
    end if;
    return (select work_territory_id from pim_organization where id = i);
end;
$$;

