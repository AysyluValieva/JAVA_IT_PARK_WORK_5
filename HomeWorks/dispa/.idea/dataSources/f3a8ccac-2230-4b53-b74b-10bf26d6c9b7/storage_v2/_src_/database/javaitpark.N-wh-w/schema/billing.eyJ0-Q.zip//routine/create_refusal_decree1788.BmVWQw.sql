CREATE FUNCTION create_refusal_decree1788(case_id_i integer, cert_num_i character varying, clinic_id_i integer, creation_date_i character varying, empl_issued_id_i integer, patient_id_i integer, period_begin_i character varying, period_end_i character varying, receiver_id_i integer, remark_i character varying)
  RETURNS integer
LANGUAGE plpgsql
AS $$
DECLARE
  cert_id_l  INTEGER;
  date_fmt_l VARCHAR = 'DD.MM.YYYY';
BEGIN
  INSERT INTO billing.services_cost_certificate (
    case_id, clinic_id, creation_date, employee_issued_id, number, patient_id, period_begin, period_end, receiver_id, refused, remark)
  VALUES (
    case_id_i, clinic_id_i, to_date(creation_date_i, date_fmt_l), empl_issued_id_i, cert_num_i, patient_id_i,
    CASE WHEN period_begin_i IS NOT NULL THEN to_date(period_begin_i, date_fmt_l) END,
    CASE WHEN period_end_i IS NOT NULL THEN to_date(period_end_i, date_fmt_l) END, receiver_id_i, true, remark_i)
  RETURNING id
    INTO cert_id_l;
  PERFORM billing.calc_certificate_costs_decree1788(cert_id_l);
  RETURN cert_id_l;
END;
$$;

