CREATE FUNCTION agreement(xid integer, xserviceid integer, xagreedate character varying, xepid integer, xcheckservices character varying, xservices character varying)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
          i integer;
          q_seq integer;
          pci integer;
          rstatus integer;
          mmcrid integer;
          eventcode text;
          checkserviceId json;
		  l_pay_method integer;
        begin
		
if xservices IS NULL THEN
--проставляют услуги по назначению (автомат)
 foreach checkserviceId in array array(select value from json_array_elements(cast(xcheckservices as json)))

                LOOP
                 if checkserviceId::text::text !='null' THEN
                 insert into disp.md_event_service_patient (id, service_id, indiv_id, event_id,event_patient_id)
              values (
              nextval('disp.md_event_service_patient_id_seq'),
              (select id from disp.md_event_service where service_id=checkserviceId::text::int and event_id=(select event_id from disp.md_event_patient where id=xepid)),
               (select indiv_id from disp.md_event_patient where id=xepid),
               (select event_id from disp.md_event_patient where id=xepid),
               xepid);
               END IF;
                END LOOP;
--назначенные услуги
xservices=(select array_to_json(array_agg(row_to_json(serv)))
                from (select id from disp.md_event_service_patient  where event_patient_id = xepid) as serv);
END IF;

          l_pay_method = (select me.pay_method from disp.md_event_patient mep join disp.md_event me on me.id = mep.event_id where mep.id = xepid);
          eventcode = (select met.code from disp.md_event_patient mep
          left join disp.md_event me on me.id = mep.event_id
          left join disp.md_event_type met on met.id = me.event_type
          where mep.id = xepid);

          IF (select count(id) from disp.md_event_eq_case where event_patient_id = xepid) = 0 then
              q_seq = nextval('mc_case_seq');
              pci = (select indiv_id from disp.md_event_patient where id = xepid);
              -- clinic id - ЗАШИТО - плохо (16 ГБ)
              mmcrid = nextval('mc_med_case_result_id');
              insert into MC_MED_CASE_RESULT (id) values (mmcrid);
              insert into MC_CASE (id, uid, create_date, patient_id, case_type_id, clinic_id, care_level_id, funding_id, init_goal_id, care_regimen_id, payment_method_id, open_date, result_id, soc_group_id)
                values (q_seq, eventcode||'_'||CAST(nextval('disp.md_event_case_number') as text), current_date, pci, 1,
                (select me.org_id from disp.md_event_patient mep left join disp.md_event me on me.id = mep.event_id where mep.id = xepid),
                (select id from mc_care_level where code = '1'), (select id from fin_funding_source_type where code = 'OMS'), 46,
                (select id from mc_care_regimen where code = '1'), 
				(CASE WHEN l_pay_method IS NOT NULL THEN l_pay_method ELSE (SELECT id FROM mc_payment_method WHERE CODE = '11') END),
				current_date, mmcrid,
                (select social_group_id from pci_patient where id = pci));
              insert into disp.md_event_eq_case (id, event_patient_id, case_id) values (nextval('disp.md_event_eq_case_id_seq'), xepid, q_seq);
          END IF;

--по новоназначенным  услугам
       foreach checkserviceId in array array(select value from json_array_elements(cast(xservices as json)))
                LOOP
          IF xid IS NULL THEN
            i = nextval('disp.md_event_service_patient_agreement_id_seq');
            -- agree ALL
            PERFORM disp.agreeServiceForPatientAll(1, 1, TRUE, TRUE, xagreeDate, xepid);
            -- added STATUS
            IF (select count(ssr.id)
                  from disp.md_event_eq_case meec
                  left join MD_SRV_RENDERED msr on msr.case_id = meec.case_id
                  inner join SR_SRV_RENDERED ssr on ssr.id = msr.id and ssr.service_id = (SELECT mes.service_id FROM disp.md_event_service_patient mesp
                                                                                          left join disp.md_event_service mes on mes.id = mesp.service_id
                                                                                          where mesp.id =
                                                                                          cast(checkserviceId::json->>'id' as integer)
                                                                                          )
                  where meec.event_patient_id = xepid) > 0 THEN
              rstatus = 4;
            ELSE
              rstatus = 1;
            END IF;
            IF (select count(id) from disp.md_event_service_patient_status where service_id = cast(checkserviceId::json->>'id' as integer)) > 0 then
              update disp.md_event_service_patient_status set status = rstatus
                where service_id = cast(checkserviceId::json->>'id' as integer);
            ELSE
              insert into disp.md_event_service_patient_status (id, service_id, status)
                values (nextval('disp.md_event_service_patient_status_seq'),cast(checkserviceId::json->>'id' as integer), rstatus);
            END IF;

            IF (select count(id) from disp.md_event_service_patient_agreement where service_id = cast(checkserviceId::json->>'id' as integer)) = 0 THEN

                insert into disp.md_event_service_patient_agreement (id, service_id, agree, denial, agree_date)
                  values (i,cast(checkserviceId::json->>'id' as integer), TRUE, FALSE, to_date(xagreeDate, 'DD.MM.YYYY'));

              END IF;



          ELSE
            -- agree all
            PERFORM disp.agreeServiceForPatientAll(1, 1, TRUE, TRUE, xagreeDate, xepid);
            -- added STATUS
            IF (select count(ssr.id)
                  from disp.md_event_eq_case meec
                  left join MD_SRV_RENDERED msr on msr.case_id = meec.case_id
                  inner join SR_SRV_RENDERED ssr on ssr.id = msr.id and ssr.service_id = (SELECT mes.service_id FROM disp.md_event_service_patient mesp
                                                                                          left join disp.md_event_service mes on mes.id = mesp.service_id
                                                                                          where mesp.id =cast(checkserviceId::json->>'id' as integer))
                  where meec.event_patient_id = xepid) > 0 THEN
              rstatus = 4;
            ELSE
              rstatus = 1;
            END IF;
            IF (select count(id) from disp.md_event_service_patient_status where service_id = cast(checkserviceId::json->>'id' as integer)) > 0 then
              update disp.md_event_service_patient_status set status = rstatus
                where service_id = cast(checkserviceId::json->>'id' as integer);
            ELSE
              insert into disp.md_event_service_patient_status (id, service_id, status)
                values (nextval('disp.md_event_service_patient_status_seq'), cast(checkserviceId::json->>'id' as integer), rstatus);
            END IF;
            update disp.md_event_service_patient_agreement set service_id=cast(checkserviceId::json->>'id' as integer), agree=TRUE, denial=FALSE,
              agree_date=to_date(xagreeDate, 'DD.MM.YYYY')
            where id=xid;
          END IF;
          END LOOP;
          return i;
        end;
$$;

