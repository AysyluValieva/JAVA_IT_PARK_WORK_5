CREATE FUNCTION open_ambulance_change(xtime time without time zone)
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
                                el record;
                                xchange integer;
                                --yesterdaychange integer;
                                yesterdaychange record;

                                xtypeNum integer;
                                xnumid integer;

                                xval integer;

                                xbrg record;
                              begin
                              -- пока что в лоб проставление подстанции, но позже напишу, что если настройка только для станции, то для всех подстанций этой станции должны счётчики номеров продвинуться
                                  -- выбираем все подходящие смены
                                for el in
                                    select id,clinic_id,route_id,department_id,change_begin,change_period
                                        from amb.md_ambulance_change_setting where change_begin = xtime --or change_begin = xtime + change_period
                                loop
                                    xchange:= amb.insert_into_md_ambulance_change (cast(now() as date),el.clinic_id,el.department_id);

                                    --select into xtypeNum,xnumid mans.type_num,mans.id from amb.md_ambulance_numb_setting mans left join amb.md_ambulance_numbers man on mans.id = man.numb_id
                                    select into xtypeNum,xnumid mans.type_num,mans.id from amb.md_ambulance_numb_setting mans left join amb.md_ambulance_numbers man on mans.id = man.numb_id
                                          where mans.clinic_id = el.clinic_id;
                                    --if exists (select * from amb.md_ambulance_numb_setting mans left join amb.md_ambulance_numbers man on mans.id = man.numb_id
                                    IF not exists (select * from amb.md_ambulance_numbers man left join amb.md_ambulance_numb_setting mans on mans.id = man.numb_id
                                          where mans.clinic_id = el.clinic_id and man.change_id = xchange and man.dep_id = el.department_id)
                                    THEN
                                      if xtypeNum = 1
                                        then
                                            xval =0;
                                            /*insert into amb.md_ambulance_numbers (change_id,numb_id, value,dep_id)
                                                values (xchange,xnumid,0,el.department_id);*/
                                        end if;
                                      if (xtypeNum = 2)
                                        then
                                          if (EXTRACT(dow FROM now()) = 1)
                                             or not exists(select * from amb.md_ambulance_numbers man
                                                            left join amb.md_ambulance_numb_setting mans on mans.id = man.numb_id
                                                            where mans.clinic_id = el.clinic_id and man.dep_id = el.department_id)
                                             or (
                                                  (select extract(week from mac.from_data) from  amb.md_ambulance_change mac
                                                      where mac.clinic_id = el.clinic_id and mac.department_id = el.department_id and mac.state = 1
                                                      order by mac.from_data desc
                                                      limit 1
                                                   ) < EXTRACT(week FROM now())
                                               or
                                                  (select extract(year from mac.from_data) from  amb.md_ambulance_change mac
                                                      where mac.clinic_id = el.clinic_id and mac.department_id = el.department_id and mac.state = 1
                                                      order by mac.from_data desc
                                                      limit 1
                                                   )< EXTRACT(year FROM now())
                                                )
                                            then
                                                xval = 0;
                                            else
                                                xval = (select value from amb.md_ambulance_numbers man left join amb.md_ambulance_numb_setting mans on mans.id = man.numb_id
                                                            where mans.clinic_id = el.clinic_id and man.dep_id = el.department_id order by man.id desc limit 1);
                                          end if;
                                        end if;
                                      if (xtypeNum = 3)
                                        then
                                          if (EXTRACT(day FROM now()) = 1)
                                            or not exists(select * from amb.md_ambulance_numbers man
                                                            left join amb.md_ambulance_numb_setting mans on mans.id = man.numb_id
                                                            where mans.clinic_id = el.clinic_id and man.dep_id = el.department_id)
                                            or (
                                                  (select extract(month from mac.from_data) from  amb.md_ambulance_change mac
                                                      where mac.clinic_id = el.clinic_id and mac.department_id = el.department_id and mac.state = 1
                                                      order by mac.from_data desc
                                                      limit 1
                                                   ) < EXTRACT(month FROM now())
                                               or
                                                  (select extract(year from mac.from_data) from  amb.md_ambulance_change mac
                                                      where mac.clinic_id = el.clinic_id and mac.department_id = el.department_id and mac.state = 1
                                                      order by mac.from_data desc
                                                      limit 1
                                                   )< EXTRACT(year FROM now())
                                               )
                                            then
                                                xval = 0;
                                            else
                                                xval = (select value from amb.md_ambulance_numbers man left join amb.md_ambulance_numb_setting mans on mans.id = man.numb_id
                                                            where mans.clinic_id = el.clinic_id and man.dep_id = el.department_id order by man.id desc limit 1);
                                          end if;
                                        end if;
                                      if (xtypeNum = 4)
                                        then
                                          if (EXTRACT(doy FROM now()) = 1)
                                            or not exists(select * from amb.md_ambulance_numbers man
                                                            left join amb.md_ambulance_numb_setting mans on mans.id = man.numb_id
                                                            where mans.clinic_id = el.clinic_id and man.dep_id = el.department_id)
                                            or (
                                                  (select extract(year from mac.from_data) from  amb.md_ambulance_change mac
                                                      where mac.clinic_id = el.clinic_id and mac.department_id = el.department_id and mac.state = 1
                                                      order by mac.from_data desc
                                                      limit 1
                                                   )< EXTRACT(year FROM now())
                                               )
                                            then
                                                xval = 0;
                                            else
                                                xval = (select value from amb.md_ambulance_numbers man left join amb.md_ambulance_numb_setting mans on mans.id = man.numb_id
                                                            where mans.clinic_id = el.clinic_id and man.dep_id = el.department_id order by man.id desc limit 1);
                                          end if;
                                        end if;

                            if (xnumid is null) then
                                RAISE EXCEPTION 'Не настроен нумератор для смены с id = %', xchange;
                            end if;

                                      insert into amb.md_ambulance_numbers (change_id,numb_id, value,dep_id)
                                                    values (xchange,xnumid,xval,el.department_id);
                                    END if;
                                    if exists(select id from amb.md_ambulance_change where clinic_id = el.clinic_id and COALESCE(department_id, 0) = COALESCE(el.department_id, 0) and ((from_data = cast(now() - cast('1 day' as interval) as date)) or (state = 1)) )
                                      then
                                          for yesterdaychange in select id from amb.md_ambulance_change where clinic_id = el.clinic_id and COALESCE(department_id, 0) = COALESCE(el.department_id, 0) and ((from_data = cast(now() - cast('1 day' as interval) as date)) or (state = 1))
                                            loop
                                                update amb.md_ambulance_change set state = 2 where id = yesterdaychange.id;
                                            end loop;
                                      end if;
                                    update amb.md_ambulance_change set state = 1 where id = xchange;

                                    -- автозавершение работы всем бригадам в статусе свободна
                                    execute  amb.team_job_close (
                                                            array(select srtj.id
                                                                from amb.sr_res_team_job srtj
                                                                join amb.md_ambulance_change mac on mac.id = srtj.change_id
                                                                join amb.sr_res_team srt on srt.id = srtj.team_id
                                                                join sr_res_group srg on srg.id = srt.resource_id
                                                                join pim_organization po on po.id = srg.org_id
                                                                join pim_department pd on pd.id = srg.department_id
                                                                where po.id=el.clinic_id
                                                                and pd.id = el.department_id
                                                                and srtj.edate is null
                                                                and srtj.planned_edate <= now()
                                                                and ((select srtjsh.job_status_id from amb.sr_res_team_job_status_history srtjsh where srtjsh.team_job_id = srtj.id order by srtjsh.date_time desc limit 1) not in (2,3,4,5) or
                                                                (select srtjsh.job_status_id from amb.sr_res_team_job_status_history srtjsh where srtjsh.team_job_id = srtj.id order by srtjsh.date_time desc limit 1) is null)
                                                                order by 1)
                                                        ,null,0);

                                end loop;
                                insert into amb.change_test(b) values ('');
                              end;
$$;

