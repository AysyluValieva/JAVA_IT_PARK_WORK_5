CREATE FUNCTION fin_bill__get_clinic(bill_id integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
    main_bill_id integer;
    clinic_id integer;
begin
    main_bill_id = (select fin_bill__get_main_bill(bill_id));
    clinic_id = (select fin_bill_main.clinic_id from fin_bill_main where fin_bill_main.id = main_bill_id);
    return clinic_id;
end;
$$;

