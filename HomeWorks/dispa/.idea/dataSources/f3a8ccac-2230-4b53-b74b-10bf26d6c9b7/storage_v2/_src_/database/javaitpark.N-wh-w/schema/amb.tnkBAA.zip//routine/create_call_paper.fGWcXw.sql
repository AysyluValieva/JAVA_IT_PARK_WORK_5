CREATE FUNCTION create_call_paper(xcall_num integer, xcall_dt integer, xcall_kind_id integer, xcall_type_id integer, xis_group_sufferer boolean, xis_psycho boolean, xsum_sufferer integer, xcaller_reason_id integer, xreason_diag integer, xreason_note character varying, xcall_place_id integer, xcall_place_note character varying, xplace_org_id integer, xplace_department_id integer, xaddress_id integer, xhouse character varying, xhousing character varying, xapartment character varying, xporch character varying, xfloor character varying, xdoor_code character varying, xdescription character varying, xto_org_id integer, xto_department_id integer, xto_address_id integer, xto_house character varying, xto_housing character varying, xto_apartment character varying, xto_porch character varying, xto_description character varying, xpatient_id integer, xsurname character varying, xname character varying, xpatrname character varying, xbirthdt date, xgender integer, xis_chronic boolean, xyears integer, xmonths integer, xdays integer, xphone_caller character varying, xcaller_id integer, xemployee_id integer, xcaller_note character varying, xpriority_id integer, xpriority integer, xcontrol integer, xnote character varying, xregistrator_id integer, xstation_id integer, xroute_id integer, xsubstation_id integer, xbrg_id integer, xemp_id integer, xparcal integer, xneed_exit_through integer, xtransregistrator_id integer, xreceipt_time time without time zone, xtransmit_time time without time zone, xtransmit_state integer, xexit_time time without time zone, xcoming_time time without time zone, xto_time time without time zone, xuser integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
                -- время приёма вызова
                xfrom_dt date;
                xfrom_time timestamp without time zone;
                xreceipt_time_id integer;
                -- время передачи бригаде
                xtrans_time timestamp without time zone;
                xtransmit_time_id integer;

                xstatehist integer;
                priorsum integer;
                xduble integer;

                resroute record;
                xroute_id integer;
                xroutehist integer;

                -- из посыла
                xreg integer;   -- вычисляемое значение диспетчера направления в зависимости от вида и типа вызова и наличия информации по диспетчеризации
                xbol boolean;

                --xdate timestamp without time zone;
                xstate integer;
                xcall_prior integer;
                -- из завершения
                xend_time timestamp without time zone;
                xend_time_id integer;
                -- преобразования временных полей
                xexit_t timestamp without time zone;-- выезд с п/ст
                xcoming_t timestamp without time zone;-- прибытие на вызов
                xexit_time_id integer;
                xcoming_time_id integer;

                xcall integer;

                --госпитализация
                xcallnote integer;

                --АМБ
                xcall_reason_id integer;
                xreason_accident_id integer;
                xtransmit_state integer;
                -- для случая
                xcase integer;
                xfunding integer;
                xcase_type integer;
                xcare_regimen integer;
                xcare_level integer;
                xcare_providing_form integer;
                xinit_goal integer;
                xinit_type integer;
                xadmission_type integer;
                xpayment_method integer;

                -- для системного составного ресурса
                xgroup integer;
                resel record;
                xrelationship_id integer;

                xtrans timestamp without time zone;
                xrole integer;
                xres integer;
                xresrole integer;

                -- шаг
                xstep integer;
                xprof integer;
                -- посещение
                --xvisit integer; т.к. = xstep
                xvisit_place integer;
                xvisit_goal integer;
                xvisit_type integer;
                xinitiator integer;
                -- для услуги
                xrendered integer;
                xservice integer;
                xduration integer;
                xmeasure integer;

              begin
                    --преобразование времени приёма в timestamp
                    xfrom_dt = (select from_data from amb.md_ambulance_change where id = xcall_dt);
                    --xreceipt_time time		-- приём
                    /*
                    xfrom_time = case when xreceipt_time between cast('00:00' as time) and
                                    (select change_begin from amb.md_ambulance_change_setting where clinic_id = xstation_id and coalesce(department_id, 0) = coalesce(xsubstation_id, 0))
                                then cast(cast(xfrom_dt + cast('1 day' as interval) as date)||' '|| xreceipt_time  as timestamp without time zone)
                                else cast(xfrom_dt ||' ' ||xreceipt_time  as timestamp without time zone)
                                end;
                    */
                    xfrom_time = case when xreceipt_time >= cast('00:00' as time) and
                                    xreceipt_time < (select change_begin from amb.md_ambulance_change_setting where clinic_id = xstation_id and coalesce(department_id, 0) = coalesce(xsubstation_id, 0))
                                then cast(cast(xfrom_dt + cast('1 day' as interval) as date)||' '|| xreceipt_time  as timestamp without time zone)
                                else cast(xfrom_dt ||' ' ||xreceipt_time  as timestamp without time zone)
                                end;
                    -- создаем пациента
                    if (xpatient_id is null)
                        then
                            xpatient_id = amb.create_pat_vrem (xsurname,xname,xpatrname,xbirthdt,xgender);
                            update public.pci_patient set
                                note = note||', '||(select short_name from pim_organization where id = xstation_id)||', вызов №'||cast(xcall_num as varchar(6))||' от '||(select to_char(from_data,'dd.mm.yyyy') from amb.md_ambulance_change where id = xcall_dt)
                                where id = xpatient_id;
                    end if;

                    xcall = nextval('amb.md_ambulance_call_seq');
                    --dt  = now();
                    insert into amb.md_ambulance_call (id,call_number,call_dt,call_kind_id,call_type_id,is_group_sufferer,sum_sufferer,
                                                    from_time,caller_reason_id,reason_diag,reason_note,
                                                    call_place_id,call_place_note,place_org_id,place_department_id,
                                                    address_id,house,housing,apartment,porch,floor,door_code,description,
                                                    to_org_id,to_department_id,to_address_id,to_house,to_housing,to_apartment,to_porch,to_description,
                                                    patient_id,is_chronic,age_years,age_months,age_days,
                                                    phone_caller,caller_id,employee_id,caller_note,
                                                    priority_id,priority,control,note,registrator_id,
                                                    station_id,route_id,substation_id,brg_id,emp_id)

                    values (xcall,xcall_num,xcall_dt,xcall_kind_id,xcall_type_id,xis_group_sufferer,xsum_sufferer,
                            xfrom_time,xcaller_reason_id,xreason_diag,xreason_note,
                            xcall_place_id,xcall_place_note,xplace_org_id,xplace_department_id,
                            xaddress_id,xhouse,xhousing,xapartment,xporch,xfloor,xdoor_code,xdescription,
                            xto_org_id,xto_department_id,xto_address_id,xto_house,xto_housing,xto_apartment,xto_porch,xto_description,
                            xpatient_id,xis_chronic,xyears,xmonths,xdays,
                            xphone_caller,xcaller_id,xemployee_id,xcaller_note,
                            xpriority_id,xpriority,xcontrol,xnote,xregistrator_id,
                            xstation_id,xroute_id,xsubstation_id,xbrg_id,xemp_id);

                    xstatehist = amb.add_ambcall_state_hist (xcall,xfrom_time,1,null,xregistrator_id);
                    priorsum = amb.priority_calculation(xcall,xregistrator_id);

                    if (xcall_type_id = 2) and (xparcal is not null)
                        then
                            execute amb.add_amb_call_double(xcall,9,true,xregistrator_id,xparcal);
                            update amb.md_ambulance_call set call_mark  = 2 where id = xcall;
                    end if;

                    if amb.check_call_double(xcall) = false
                        then update amb.md_ambulance_call set call_mark  = 1 where id = xcall;
                    end if;

                    /* убрала, дублирует
                    -- принят диспетчером
                    --xstatehist = amb.add_ambcall_state_hist (i,xfrom_time,1,null,xregistrator_id);
                    IF xreceipt_time is not null
                    THEN
                        select into xreceipt_time_id mash.id from amb.md_ambcall_state_history mash
                                    left join amb.md_ambulance_call_state macs on macs.id = mash.state_id
                                        where macs.code = '1' and mash.call_id = i;
                        if xreceipt_time_id is null
                        then
                            --select
                            xstate := amb.add_ambcall_state_hist (i,xfrom_time,1,null,xregistrator_id);
                        else
                            update amb.md_ambcall_state_history set date_time = xfrom_time where id = xreceipt_time_id;
                        end if;
                    END IF;
                    */
                    for resroute in
                        select ra.id as id, ra.address_id as address_id,ra.building_pattent as building_pattent,ra.route_id as route_id
                            from amb.md_ambulance_route_area ra
                            left join amb.md_ambulance_route r on r.id = ra.route_id
                            where r.org_id = xstation_id and (r.to_time is null or r.to_time >= now()) and (ra.to_time is null or ra.to_time >= now())
                    loop
                        if amb.check_address_in_district (xaddress_id,resroute.address_id,xhouse,resroute.building_pattent)
                            then
                                xroute_id = resroute.route_id;
                                xroutehist = amb.add_ambcall_route_hist (xcall,xfrom_time,xstation_id,xroute_id,xsubstation_id,NULL,xregistrator_id);
                                xstatehist = amb.add_ambcall_state_hist (xcall,xfrom_time,2,null,xregistrator_id);
                        end if;
                    end loop;

                    --госпитализация, устанавливаем отметку по виду вызова
                    IF (xcall_kind_id in (3,4)) or (xto_org_id is not null)
                        THEN
                            xcallnote = amb.add_call_note(xcall,21,true,null,'а/у госпитализация',xregistrator_id,null);
                    END IF;

                    -- определяется диспетчер(направления), в зависимости от вида, типа вызова и информации по обслужившей бригаде
                    if (xtransregistrator_id is not null) and (xcall_kind_id <> 7) and (xcall_type_id <> 4)
                            then
                                xreg = xtransregistrator_id;
                            else
                                xreg = xregistrator_id;
                        end if;

                    --АМБ, в пути, указана обслужившая бригада
                    IF (xcall_kind_id = 7) or (xcall_type_id = 4) or (xbrg_id is not null)
                    THEN
                        -- приоритет
                        select into xcall_prior	priority_id from amb.md_ambulance_call where id = xcall;

                        --причина вызова, причина несчастного случая
                        select into xcall_reason_id,xreason_accident_id call_reason_id,reason_accident_id
                            from amb.md_ambulance_caller_reason where id = xcaller_reason_id;

                        -- Случай
                        xcare_providing_form = (select id from md_care_providing_form  where e_code =
                            case when xcall_kind_id in (4,6) then '3' else case when xcall_prior in (1,2) then '1' else '2' end end);
                        xinit_type = (select id from mc_case_init_type where e_code =
                            case when xcall_kind_id in (3,4,6) then '2' else '1' end);
                        xfunding = (select id from fin_funding_source_type where e_code = 'OMS');
                        if not exists (select id from amb.md_ambulance_call_result where id = xcall)
                            then
                                -- создаем "Случай"
                                if xcall_type_id =4
                                    then
                                        xcase_type = (select id from mc_case_type where e_code = '7');
                                    else
                                        -- для АМБ -  тип случая "Случай оказания амбулаторной помощи СНМП"
                                        xcase_type = (select id from mc_case_type where e_code = '8');
                                end if;
                                xcare_regimen = (select id from mc_care_regimen where e_code = '6');
                                xcare_level = (select id from mc_care_level where e_code = '2');
                                xinit_goal = (select id from mc_case_init_goal where e_code = '03');
                                xadmission_type = (select id from mc_admission_type where e_code = '2');
                                xpayment_method = (select id from mc_payment_method where code='15');  -- системный справочник, в эталоне не заполнено e_code

                                xcase = nextval('mc_case_seq');
                                insert into mc_case(id,case_type_id,care_regimen_id,uid,care_level_id,care_providing_form_id,init_goal_id,init_type_id,admission_type_id,funding_id
                                    ,open_date,create_date,clinic_id, patient_id,payment_method_id)
                                values(xcase,xcase_type,xcare_regimen,xcall_num,xcare_level,xcare_providing_form,xinit_goal,xinit_type,xadmission_type,xfunding
                                    ,cast(xfrom_time as date),cast(xfrom_time as date),xstation_id,xpatient_id,xpayment_method);

                                xtransmit_state = (select id from amb.md_ambulance_transmit_state where e_code = '1');
                                -- записываем данные в "Результат вызова"
                                insert into amb.md_ambulance_call_result (id,case_id,transmit_state_id,call_reason_id,reason_accident_id,registrator_id)
                                    values (xcall,xcase,xtransmit_state,xcall_reason_id,xreason_accident_id,xreg);
                        end if;

                        -- передан бригаде --преобразование времени передачи в timestamp
                        -- transmit_time time		-- передача
                        if (xtransmit_time is not null) and ((xcall_kind_id <> 7) and (xcall_type_id <> 4))
                            THEN
                                /*
                                xtrans_time = case when xtransmit_time between cast('00:00' as time) and
                                    (select change_begin from amb.md_ambulance_change_setting where clinic_id = xstation_id and coalesce(department_id, 0) = coalesce(xsubstation_id, 0))
                                    or xfrom_time >= cast(cast(xfrom_dt + cast('1 day' as interval) as date)||' '|| cast('00:00' as time)  as timestamp without time zone)
                                then cast(cast(xfrom_dt + cast('1 day' as interval) as date)||' '|| xtransmit_time  as timestamp without time zone)
                                else cast(xfrom_dt ||' ' ||xtransmit_time  as timestamp without time zone)
                                end;
                                */
                                xtrans_time = case when xtransmit_time >= cast('00:00' as time) and
                                    xtransmit_time < (select change_begin from amb.md_ambulance_change_setting where clinic_id = xstation_id and coalesce(department_id, 0) = coalesce(xsubstation_id, 0))
                                    or xfrom_time >= cast(cast(xfrom_dt + cast('1 day' as interval) as date)||' '|| cast('00:00' as time)  as timestamp without time zone)
                                then cast(cast(xfrom_dt + cast('1 day' as interval) as date)||' '|| xtransmit_time  as timestamp without time zone)
                                else cast(xfrom_dt ||' ' ||xtransmit_time  as timestamp without time zone)
                                end;
                                /*
                                select into xtransmit_time_id mash.id from amb.md_ambcall_state_history mash
                                    left join amb.md_ambulance_call_state macs on macs.id = mash.state_id
                                        where macs.code = '5' and mash.call_id = i;
                                if xtransmit_time_id is null
                                    then
                                        xstate := amb.add_ambcall_state_hist (i,xtrans_time,5,xtransmit_state,xtransregistrator_id);
                                    else
                                        update amb.md_ambcall_state_history set date_time = xtrans_time, transmit_id = xtransmit_state where id = xtransmit_time_id;
                                end if;
                                */
                            ELSE
                                xtrans_time = xfrom_time;
                        end if;
                                update amb.md_ambulance_call set brg_id = xbrg_id,emp_id = xemp_id where id = xcall;
                                -- состояние вызова - "Назначена бригада"
                                xstate :=  amb.add_ambcall_state_hist (xcall,xtrans_time,4,1,xreg);
                                -- состояние вызова - "Вызов передан бригаде"
                                xstate :=  amb.add_ambcall_state_hist (xcall,xtrans_time + '1 second',15,xtransmit_state,xreg);
                                -- состояние вызова - "Вызов принят бригадой"
                                xstate :=  amb.add_ambcall_state_hist (xcall,xtrans_time + '2 second',5,xtransmit_state,xreg);
                                -- надо ли состояние выезд на вызов = 6 не понятно
                                xstate :=  amb.add_ambcall_state_hist (xcall,xtrans_time + '3 second',6,xtransmit_state,xreg);
                        -- состояние бригады - "На вызове"
                        if xbrg_id is not null
                            then
                                execute amb.add_team_job_status_hist (xbrg_id,xtrans_time + '4 second',2,xreg,CAST(xcall_num as varchar(10))||'/'||coalesce(adr__get_element_as_text(xaddress_id,'(6,s,0)(7,s,0)(8,s,0)'),xdescription),xuser);
                        end if;
                                -- запись в историю диспетчерезации - "бригада"
                                xstate := amb.add_ambcall_route_hist (xcall,xtrans_time + '4 second',null,null,null,coalesce(xbrg_id,xemp_id),xreg);
                    END IF;

                    -- спц, активный, в пути, скм
                    if (xparcal is not null) and (( xcall_kind_id = 5) or (xcall_type_id = 4) or (xcall_type_id = 3) or (xcall_kind_id = 6))
                        then
                            insert into amb.md_ambulance_call_on_base (id,call_on_base_id)
                                values (xcall,xparcal);
                    end if;

                    -- активный
                    if (xcall_type_id = 3)
                        then
                            -- Случай
                            xcare_providing_form = (select id from md_care_providing_form  where e_code =
                                case when xcall_kind_id in (4,6) then '3' else case when xcall_prior in (1,2) then '1' else '2' end end);
                            xinit_type = (select id from mc_case_init_type where e_code =
                                case when xcall_kind_id in (3,4,6) then '2' else '1' end);
                            xfunding = (select id from fin_funding_source_type where e_code = 'OMS');
                            if not exists (select id from amb.md_ambulance_call_result where id = xcall)
                            then
                                -- создаем "Случай"
                                xcase_type = (select id from mc_case_type where e_code = '7');
                                xcare_regimen = (select id from mc_care_regimen where e_code = '6');
                                xcare_level = (select id from mc_care_level where e_code = '2');
                                xinit_goal = (select id from mc_case_init_goal where e_code = '03');
                                xadmission_type = (select id from mc_admission_type where e_code = '2');
                                xpayment_method = (select id from mc_payment_method where code='15');  -- системный справочник, в эталоне не заполнено e_code

                                xcase = nextval('mc_case_seq');
                                insert into mc_case(id,case_type_id,care_regimen_id,uid,care_level_id,care_providing_form_id,init_goal_id,init_type_id,admission_type_id,funding_id
                                        ,open_date,create_date,clinic_id, patient_id,payment_method_id)
                                    values(xcase,xcase_type,xcare_regimen,xcall_num,xcare_level,xcare_providing_form,xinit_goal,xinit_type,xadmission_type,xfunding
                                        ,cast(xfrom_time as date),cast(xfrom_time as date),xstation_id,xpatient_id,xpayment_method);

                                -- записываем данные в "Результат вызова"
                                insert into amb.md_ambulance_call_result (id,case_id,transmit_state_id,registrator_id,need_exit_through)
                                    values (xcall,xcase,1,xregistrator_id,xneed_exit_through);
                            end if;
                    end if;

                    -- автодобавление отметок
                    execute amb.auto_add_call_note (xcall,xcaller_reason_id,xreason_diag,xis_psycho,xregistrator_id,xplace_org_id,xplace_department_id,xaddress_id,xhouse);


                    -- отсюда начинаются проверки на введенные данные по диспетчеризации
                    --xexit_time  -- выезд с п/ст
                    if xexit_time is not null
                        then
                            /*
                            xexit_t = case when xexit_time between cast('00:00' as time) and
                                        (select change_begin from amb.md_ambulance_change_setting where clinic_id = xstation_id and coalesce(department_id, 0) = coalesce(xsubstation_id, 0))
                                        or xfrom_time >= cast(cast(xfrom_dt + cast('1 day' as interval) as date)||' '|| cast('00:00' as time)  as timestamp without time zone)
                                      then cast(cast(xfrom_dt + cast('1 day' as interval) as date)||' '|| xexit_time  as timestamp without time zone)
                                      else cast(xfrom_dt ||' ' ||xexit_time  as timestamp without time zone)
                                      end;
                            */
                            xexit_t = case when xexit_time >= cast('00:00' as time) and
                                        xexit_time < (select change_begin from amb.md_ambulance_change_setting where clinic_id = xstation_id and coalesce(department_id, 0) = coalesce(xsubstation_id, 0))
                                        or xfrom_time >= cast(cast(xfrom_dt + cast('1 day' as interval) as date)||' '|| cast('00:00' as time)  as timestamp without time zone)
                                      then cast(cast(xfrom_dt + cast('1 day' as interval) as date)||' '|| xexit_time  as timestamp without time zone)
                                      else cast(xfrom_dt ||' ' ||xexit_time  as timestamp without time zone)
                                      end;
                            select into xexit_time_id mash.id from amb.md_ambcall_state_history mash
                                    left join amb.md_ambulance_call_state macs on macs.id = mash.state_id
                                        where macs.code = '6' and mash.call_id = xcall;
                            if xexit_time_id is null
                                then
                                    xstate := amb.add_ambcall_state_hist (xcall,xexit_t,6,xtransmit_state,xtransregistrator_id);
                                else
                                    -- обновить состояние выезд на вызов = 6
                                    update amb.md_ambcall_state_history set date_time = xexit_t where id = xexit_time_id;
                            end if;
                    end if;
                    --xcoming_time -- прибытие на вызов
                    if xcoming_time is not null
                        then
                            /*
                            xcoming_t = case when xcoming_time between cast('00:00' as time) and
                                    (select change_begin from amb.md_ambulance_change_setting where clinic_id = xstation_id and coalesce(department_id, 0) = coalesce(xsubstation_id, 0))
                                    or xfrom_time >= cast(cast(xfrom_dt + cast('1 day' as interval) as date)||' '|| cast('00:00' as time)  as timestamp without time zone)
                                then cast(cast(xfrom_dt + cast('1 day' as interval) as date)||' '|| xcoming_time  as timestamp without time zone)
                                else cast(xfrom_dt ||' ' ||xcoming_time  as timestamp without time zone)
                                end;
                            */
                            xcoming_t = case when xcoming_time >= cast('00:00' as time) and
                                    xcoming_time < (select change_begin from amb.md_ambulance_change_setting where clinic_id = xstation_id and coalesce(department_id, 0) = coalesce(xsubstation_id, 0))
                                    or xfrom_time >= cast(cast(xfrom_dt + cast('1 day' as interval) as date)||' '|| cast('00:00' as time)  as timestamp without time zone)
                                then cast(cast(xfrom_dt + cast('1 day' as interval) as date)||' '|| xcoming_time  as timestamp without time zone)
                                else cast(xfrom_dt ||' ' ||xcoming_time  as timestamp without time zone)
                                end;
                            select into xcoming_time_id mash.id from amb.md_ambcall_state_history mash
                                    left join amb.md_ambulance_call_state macs on macs.id = mash.state_id
                                        where macs.code = '7' and mash.call_id = xcall;
                            if xcoming_time_id is null
                                then
                                    xstate := amb.add_ambcall_state_hist (xcall,xcoming_t,7,xtransmit_state,xtransregistrator_id);
                                else
                                    -- обновить состояние прибытие на вызов = 7
                                    update amb.md_ambcall_state_history set date_time = xcoming_t where id = xcoming_time_id;
                            end if;
                    end if;

                    -- если отмечено завершение вызова
                    IF xto_time is not null
                        THEN
                            -- время завершения    --преобразование времени окончания в timestamp
                            --xto_time time		-- окончание
                            /*
                            xend_time = case when xto_time between cast('00:00' as time) and
                                    (select change_begin from amb.md_ambulance_change_setting where clinic_id = xstation_id and coalesce(department_id, 0) = coalesce(xsubstation_id, 0))
                                    or xfrom_time >= cast(cast(xfrom_dt + cast('1 day' as interval) as date)||' '|| cast('00:00' as time)  as timestamp without time zone)
                                then cast(cast(xfrom_dt + cast('1 day' as interval) as date)||' '|| xto_time  as timestamp without time zone)
                                else cast(xfrom_dt ||' ' ||xto_time  as timestamp without time zone)
                                end;
                            */
                            xend_time = case when xto_time >= cast('00:00' as time) and
                                    xto_time <(select change_begin from amb.md_ambulance_change_setting where clinic_id = xstation_id and coalesce(department_id, 0) = coalesce(xsubstation_id, 0))
                                    or xfrom_time >= cast(cast(xfrom_dt + cast('1 day' as interval) as date)||' '|| cast('00:00' as time)  as timestamp without time zone)
                                then cast(cast(xfrom_dt + cast('1 day' as interval) as date)||' '|| xto_time  as timestamp without time zone)
                                else cast(xfrom_dt ||' ' ||xto_time  as timestamp without time zone)
                                end;
                            select into xend_time_id mash.id from amb.md_ambcall_state_history mash
                                left join amb.md_ambulance_call_state macs on macs.id = mash.state_id
                                        where macs.code = '10' and mash.call_id = xcall;
                            if xend_time_id is null
                                then
                                    xstate := amb.add_ambcall_state_hist (xcall,xend_time,10,xtransmit_state,xtransregistrator_id);
                                else
                                    update amb.md_ambcall_state_history set date_time = xend_time where id = xend_time_id;
                            end if;

                            update amb.md_ambulance_call set to_time = xend_time where id = xcall;
                            execute amb.add_team_job_status_hist (xbrg_id,xend_time,1,xtransregistrator_id,'завершен: '||CAST(xcall_num as varchar(10))||'/'||(select adr__get_element_as_text(xaddress_id,'(6,s,0)(7,s,0)(8,s,0)')),xuser);

                            IF (xbrg_id is not null)
                            THEN
                                --select into xfromdate date_time from amb.md_ambcall_state_history where call_id = brg_list.id and state_id = 5;
                                -- создаём системный составной ресурс
                                xgroup = nextval('sr_res_group_seq');
                                insert into sr_res_group (id,bdate,edate,is_system,name,org_id,department_id)
                                    select xgroup,xtrans_time,xend_time,true,name,org_id,department_id from sr_res_group
                                        where id = (select resource_id from amb.sr_res_team rt left join amb.sr_res_team_job rtj on rtj.team_id = rt.id where rtj.id = xbrg_id);
                                --insert into md_res_group (id) values (xgroup);
                                insert into public.sr_res_group_profile(id,res_group_id,profile_id)
                                    values(nextval('sr_res_group_profile_seq'),xgroup,(select profile_id from sr_res_group_profile where res_group_id = (select resource_id from amb.sr_res_team rt left join amb.sr_res_team_job rtj on rtj.team_id = rt.id where rtj.id = xbrg_id)));

                                -- пишем состав бригады на момент обслуживания вызова
                                xtrans = (select date_time from amb.md_ambcall_state_history where call_id = xcall and state_id = 5 order by date_time desc limit 1);
                                for resel in
                                    select srtjr.resource_id as xres, srtte.res_role_id as xroleE,srttt.res_role_id as xroleT,srr.id as xrole,srtjr.is_head as head
                                    from amb.sr_res_team_job_resourse srtjr
                                    join sr_resource sr on sr.id = srtjr.resource_id
                                    join amb.sr_res_team_job srtj on srtjr.team_job_id = srtj.id
                                    join amb.sr_res_team srt on srtj.team_id = srt.id
                                    left join amb.sr_res_team_template srtt on srt.team_template_id = srtt.id
                                    left join amb.sr_res_team_template_employer srtte on srtt.id = srtte.team_template_id and srtte.work_place = srtjr.workplace
                                    left join amb.sr_res_team_template_transport srttt on srtt.id = srttt.team_template_id and (srttt.work_place = srtjr.workplace or upper(srttt.work_place) = upper('Транспорт')) and sr.res_kind_id = (select id from sr_res_kind where upper(name) = upper('Транспорт'))
                                    left join sr_res_role srr on srtte.res_role_id = srr.id or srttt.res_role_id = srr.id or srtjr.role_id = srr.id
                                        where srtjr.team_job_id = xbrg_id and (srtjr.deviation_id is null or srtjr.deviation_id in (2,7))
                                            and (srtjr.bdate <= xtrans) and (srtjr.edate >= xend_time or srtjr.edate is null)
                                loop
                                    xrelationship_id :=nextval('sr_res_group_relationship_seq');
                                    if (resel.head = true or coalesce(resel.xroleE,resel.xroleT,resel.xrole) = (select id from sr_res_role where upper(code) = upper('TRANSPORT')))
                                        then xrole := coalesce(resel.xroleE,resel.xroleT,resel.xrole);
                                        else xrole :=
                                                case
                                                    when (select upper(code) from sr_res_role where id = coalesce(resel.xroleE,resel.xroleT,resel.xrole)) = upper('DOCTOR') then (select id from sr_res_role where upper(code) = upper('DOCTOR_ASST'))
                                                    when (select upper(code) from sr_res_role where id = coalesce(resel.xroleE,resel.xroleT,resel.xrole)) = upper('PARAMEDIC') then (select id from sr_res_role where upper(code) = upper('PARAMEDIC_ASST'))
                                                    when (select upper(code) from sr_res_role where id = coalesce(resel.xroleE,resel.xroleT,resel.xrole)) = upper('DISPATCHER') then (select id from sr_res_role where upper(code) = upper('DISPATCHER_ASST'))
                                                    when (select upper(code) from sr_res_role where id = coalesce(resel.xroleE,resel.xroleT,resel.xrole)) = upper('DRIVER') then (select id from sr_res_role where upper(code) = upper('DRIVER_ASST'))
                                                end;
                                    end if;
                                    INSERT INTO public.sr_res_group_relationship (id,bdatetime,edatetime,resource_id,group_id,role_id)
                                        VALUES (xrelationship_id,xtrans_time,xend_time,resel.xres,xgroup,xrole);
                                end loop;
                                if (select upper(srr.e_code)
                                        from public.sr_res_group_relationship srgr
                                        join public.sr_res_role srr on srr.id = srgr.role_id
                                        where srgr.group_id = xgroup and srr.kind_id = 1) = upper('DOCTOR')
                                then
                                    insert into public.md_resgroup_amb_profile (id,profile_id)
                                        select xgroup,profile_id from public.md_resgroup_amb_profile where id = (select resource_id from amb.sr_res_team rt left join amb.sr_res_team_job rtj on rtj.team_id = rt.id where rtj.id = xbrg_id);
                                else
                                    insert into public.md_resgroup_amb_profile (id,profile_id)
                                        values(xgroup, (select id from public.md_ambulance_profile where e_code = '3'));
                                end if;
                            ELSE
                                xname := (select srtjr.workplace||' '||pi.surname||' '||left(initcap(pi.name),1)||'. '||left(initcap(pi.patr_name),1)||'.'
                                            from amb.sr_res_team_job_resourse srtjr
                                            join sr_resource sr on sr.id = srtjr.resource_id
                                            join pim_employee_position_resource pepr on pepr.id = sr.id
                                            join pim_employee_position pep on pep.id = pepr.employee_position_id
                                            join pim_employee pe on pe.id = pep.employee_id
                                            join pim_individual pi on pi.id = pe.individual_id
                                            join pim_position ppos on ppos.id = pep.position_id
                                            where srtjr.id = xbrg_id);

                                -- создаём системный составной ресурс
                                xgroup = nextval('sr_res_group_seq');
                                insert into sr_res_group (id,bdate,edate,is_system,name,org_id,department_id)
                                    values(xgroup,xtrans_time,xend_time,true,xname,xstation_id,xsubstation_id);
                                --insert into md_res_group (id) values (xgroup);
                                insert into public.sr_res_group_profile(id,res_group_id,profile_id)
                                    values(nextval('sr_res_group_profile_seq'),xgroup
                                        ,(select profile_id from sr_res_group_profile
                                            where res_group_id = (select resource_id
                                                    from amb.sr_res_team rt
                                                    join amb.sr_res_team_job rtj on rtj.team_id = rt.id and rtj.edate is null
                                                    where rtj.id = xbrg_id)));

                                -- пишем в состав системного составного ресурса
                                select into xres, xresrole resource_id, role_id
                                    from  amb.sr_res_team_job_resourse where id = xbrg_id;
                                -- //изменить так, чтоб транспорта не было
                                xrelationship_id :=nextval('sr_res_group_relationship_seq');
                                xrole :=
                                    case
                                        when (select upper(code) from sr_res_role where id = xresrole) = upper('DOCTOR') or (select upper(code) from sr_res_role where id = xresrole) = upper('DOCTOR_ASST')
                                            then (select id from sr_res_role where upper(code) = upper('DOCTOR'))
                                        when (select upper(code) from sr_res_role where id = xresrole) = upper('PARAMEDIC') or (select upper(code) from sr_res_role where id = xresrole) = upper('PARAMEDIC_ASST')
                                            then (select id from sr_res_role where upper(code) = upper('PARAMEDIC'))
                                        when (select upper(code) from sr_res_role where id = xresrole) = upper('DISPATCHER') or (select upper(code) from sr_res_role where id = xresrole) = upper('DISPATCHER_ASST')
                                            then (select id from sr_res_role where upper(code) = upper('DISPATCHER'))
                                    end;
                                INSERT INTO public.sr_res_group_relationship (id,bdatetime,edatetime,resource_id,group_id,role_id)
                                    VALUES (xrelationship_id,xtrans_time,xend_time,xres,xgroup,xrole);
                            END IF;

                            -- создаем шаг
                            xstep = nextval('mc_step_seq');
                            xprof = (select id from md_profile where e_code = '84');
                            xcare_regimen = (select id from mc_care_regimen where e_code = '6');
                            insert into mc_step(id,case_id, admission_date, admission_time,res_group_id,profile_id,is_continue,is_continue_editable)
                                VALUES(xstep,xcase, cast(xfrom_time as date),cast(xfrom_time as time),xgroup,xprof,false,false);

                            -- закрытие случая уходит в создание КВ
                            --xcase_state = (select id from mc_case_state where e_code = '1');
                            --update mc_case set closing_step_id = xstep, state_id = xcase_state where id = xcase;
                            update mc_case set closing_step_id = xstep where id = xcase;

                            -- создаем посещение
                            xvisit_place = (select id from plc_visit_place where e_code = '3');
                            xvisit_goal = (select init_goal_id from mc_case where id = xcase);
                            xvisit_type =(select id from plc_visit_type where e_code ='1');
                            xinitiator =(select id from plc_initiator where e_code =
                                case when xcall_kind_id in (4,6) or xcaller_id in (6)			-- условие очень спорно, нужно будет переписать для однозначности
                                then '2' else '1' end);
                            insert into plc_visit (id,place_id,goal_id,type_id,initiator_id)
                                values (xstep,xvisit_place,xvisit_goal,xvisit_type,xinitiator);

                            --записываем "Оказанную услугу"
                            xrendered = nextval('sr_srv_rendered_seq');
                            xservice = (select id from sr_service where org_id = xstation_id and code = 'SNMP');
                            xduration = (select cast(EXTRACT(EPOCH FROM AGE(to_time, from_time))/60 as integer) from amb.md_ambulance_call where id = xcall);
                            xmeasure = (select id from sr_srv_duration_unit where measure_id = (select id from cmn_measure where e_code = '1'));
                            xfunding = (select funding_id from mc_case where id = xcase);
                            insert into public.sr_srv_rendered(id,is_rendered,customer_id,res_group_id,org_id,service_id,bdate,begin_time,edate
                                                                ,duration,duration_measure_unit_id,quantity,funding_id )
                                values (xrendered,true,xpatient_id,xgroup,xstation_id,xservice
                                            ,cast(xfrom_time as date), cast(xfrom_time as time),CAST(xend_time as date),xduration,xmeasure,1,xfunding);

                            -- md_srv_rendered
                            insert into md_srv_rendered (id,case_id,step_id,is_urgent)
                                values(xrendered,xcase,xstep,true);

                            -- в посещение фиксируем длительность
                            update plc_visit set duration = xduration where id = xstep;

                            -- записываем данные об спц бригаде в результат вызова
                            update amb.md_ambulance_call_result set srv_rendered_id = xrendered where id = xcall;

                            -- отметка о доезде бригаде, которая поехала на спц вызов по текущему
                            if exists (select child.id from amb.md_ambulance_call_on_base cob
                                        join amb.md_ambulance_call child on child.id = cob.id
                                        where cob.call_on_base_id = xcall and child.call_kind_id = 5)
                                then
                                    xstate := amb.add_ambcall_state_hist ((select child.id from amb.md_ambulance_call_on_base cob
                                                                            join amb.md_ambulance_call child on child.id = cob.id
                                                                            where cob.call_on_base_id = xcall and child.call_kind_id = 5),xend_time,7,2,xreg);
                            end if;


                        END IF;
                    return xcall;
              end;
$$;

