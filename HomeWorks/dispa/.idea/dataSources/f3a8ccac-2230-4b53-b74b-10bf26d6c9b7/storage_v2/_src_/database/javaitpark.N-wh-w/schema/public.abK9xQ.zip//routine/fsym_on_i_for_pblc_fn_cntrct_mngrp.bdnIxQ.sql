CREATE FUNCTION fsym_on_i_for_pblc_fn_cntrct_mngrp()
  RETURNS trigger
LANGUAGE plpgsql
AS $fun$
begin                                                                                                                                                                  
                                   
                                  if 1=1 and "public".sym_triggers_disabled() = 0 then                                                                                                 
                                    insert into "public".sym_data                                                                                                                     
                                    (table_name, event_type, trigger_hist_id, row_data, channel_id, transaction_id, source_node_id, external_data, create_time)                                        
                                    values(                                                                                                                                                            
                                      'fin_contract',                                                                                                                                            
                                      'I',                                                                                                                                                             
                                      38,                                                                                                                                             
                                      
          case when new."id" is null then '' else '"' || cast(cast(new."id" as numeric) as varchar) || '"' end||','||
          case when new."comment" is null then '' else '"' || replace(replace(cast(new."comment" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."date" is null then '' else '"' || to_char(new."date", 'YYYY-MM-DD HH24:MI:SS.US') || '"' end||','||
          case when new."number" is null then '' else '"' || replace(replace(cast(new."number" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."period" is null then '' else '"' || to_char(new."period", 'YYYY-MM-DD HH24:MI:SS.US') || '"' end||','||
          case when new."sum" is null then '' else '"' || cast(cast(new."sum" as numeric) as varchar) || '"' end||','||
          case when new."termination_date" is null then '' else '"' || to_char(new."termination_date", 'YYYY-MM-DD HH24:MI:SS.US') || '"' end||','||
          case when new."price_list_id" is null then '' else '"' || cast(cast(new."price_list_id" as numeric) as varchar) || '"' end||','||
          case when new."type_id" is null then '' else '"' || cast(cast(new."type_id" as numeric) as varchar) || '"' end||','||
          case when new."financing_type_id" is null then '' else '"' || cast(cast(new."financing_type_id" as numeric) as varchar) || '"' end||','||
          case when new."beginning_date" is null then '' else '"' || to_char(new."beginning_date", 'YYYY-MM-DD HH24:MI:SS.US') || '"' end||','||
          case when new."is_executed" is null then '' when new."is_executed" then '"1"' else '"0"' end||','||
          case when new."status_id" is null then '' else '"' || cast(cast(new."status_id" as numeric) as varchar) || '"' end||','||
          case when new."status_dt" is null then '' else '"' || to_char(new."status_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when new."name" is null then '' else '"' || replace(replace(cast(new."name" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."inv_fund_source_id" is null then '' else '"' || cast(cast(new."inv_fund_source_id" as numeric) as varchar) || '"' end||','||
          case when new."payment_plan_id" is null then '' else '"' || cast(cast(new."payment_plan_id" as numeric) as varchar) || '"' end,                                                                                                                                                      
                                      'public_fin_contract_default',                                                                                                                                                
                                      txid_current(),                                                                                                                                               
                                      "public".sym_node_disabled(),                                                                                                                   
                                      null,                                                                                                                                               
                                      CURRENT_TIMESTAMP                                                                                                                
                                    );                                                                                                                                                                 
                                  end if;                                                                                                                                                              
                                                                                                                                                                               
                                  return null;                                                                                                                                                         
                                end;
$fun$;

