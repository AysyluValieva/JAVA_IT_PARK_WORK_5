CREATE FUNCTION inheritance_report_cell(in_report_id integer, in_year_ integer)
  RETURNS void
SECURITY DEFINER
LANGUAGE plpgsql
AS $$
DECLARE _report_cell_inhname varchar;

                BEGIN

	                _report_cell_inhname := 'indicators_inh.report_cell_y'|| CAST(in_year_ as varchar) || '_r' || CAST(in_report_id as varchar);

                    -- создаем унаследованную таблицу indicators_inh.report_cell_yYYYY_rRRRR
                    EXECUTE 'CREATE TABLE '|| _report_cell_inhname ||'() INHERITS (indicators.report_cell_master)';

                    EXECUTE 'ALTER TABLE ONLY '|| _report_cell_inhname ||' ADD CONSTRAINT pk_'|| substring(_report_cell_inhname, 16) || ' PRIMARY KEY(id)';

                    --регистрация факта создания
                    INSERT INTO indicators.inherited_report_cell (report_id, year_) VALUES (in_report_id, in_year_);

                    EXECUTE 'CREATE SEQUENCE '|| _report_cell_inhname ||'_seq INCREMENT 1 MINVALUE 0 MAXVALUE 999999999999 START 0 CACHE 1';

                    -- создание проверки
                    EXECUTE 'ALTER TABLE ONLY '|| _report_cell_inhname ||' ADD CONSTRAINT id__min_max CHECK (id BETWEEN '|| CAST(in_report_id AS TEXT) || SUBSTRING(CAST(in_year_ AS TEXT), 2) || '000000000000' ||' AND '|| CAST(in_report_id AS TEXT) || SUBSTRING(CAST(in_year_ AS TEXT), 2) || '999999999999' ||')';

                    --создание внешних ключей
                    EXECUTE 'ALTER TABLE ONLY '|| _report_cell_inhname ||' ADD CONSTRAINT fk_'|| SUBSTRING(_report_cell_inhname, 16) ||'_partition FOREIGN KEY (partition_id) REFERENCES indicators.report_partitions(id) MATCH SIMPLE ON UPDATE NO ACTION ON DELETE NO ACTION';

                    EXECUTE 'ALTER TABLE ONLY '|| _report_cell_inhname ||' ADD CONSTRAINT fk_'|| SUBSTRING(_report_cell_inhname, 16) ||'_dimension FOREIGN KEY (dimension_id) REFERENCES indicators.dimension(id) MATCH SIMPLE ON UPDATE NO ACTION ON DELETE NO ACTION';

                    EXECUTE 'ALTER TABLE ONLY '|| _report_cell_inhname ||' ADD CONSTRAINT fk_'|| SUBSTRING(_report_cell_inhname, 16) ||'_dimension_date FOREIGN KEY (dimension_date_id) REFERENCES indicators.dimension_date(id) MATCH SIMPLE ON UPDATE NO ACTION ON DELETE NO ACTION';

                    --создание индекса
                    EXECUTE 'CREATE INDEX report_cell_y'|| in_year_::text ||'_r'|| in_report_id::text ||'_idx ON '|| _report_cell_inhname ||' USING btree (partition_id, dimension_source_id)';

                END;
$$;

