CREATE FUNCTION auto_add_call_note(xcall integer, xreason integer, xdiagreason integer, xpsycho boolean, xreg integer, xorg integer, xdep integer, xaddr integer, xbuild character varying)
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
                calnotid integer;
                note integer;
                xcnote integer;
                cnote integer;
                i integer;
                ps integer;
                danger boolean;
                j integer;
                check1 boolean:= false;
                check2 boolean:= false;
                begin
                   /*автодобавление отметок пожар, криминал, ДТП по поводу*/
                    SELECT INTO note mara.note_id from amb.md_ambulance_caller_reason cr
                           left join amb.md_ambulance_call_reason macr on cr.call_reason_id = macr.id
                           left join amb.md_ambulance_reason_accident mara on cr.reason_accident_id = mara.id
                           where cr.id = xreason;

                    if (note is NOT NULL) then
                        if exists (select * from amb.md_ambulance_call_note where call_id = xcall and (note_id = 3 or note_id = 5 or note_id = 6 or note_id = 15) and note_description = 'а/у' and note_type = true and note_active = true)
                            then
                            select into i note_id from amb.md_ambulance_call_note where call_id = xcall and (note_id = 3 or note_id = 5 or note_id = 6 or note_id = 15) and note_description = 'а/у' and note_type = true and note_active = true;
                            cnote = amb.add_call_note (xcall, i, FALSE, NULL,NULL,xreg,NULL);
                        end if;
                        if exists (select * from amb.md_ambulance_call_note where call_id = xcall and (note_id = note) and note_description = 'р/у' and note_type = true and note_active = true)
                            then
                            select into i note_id from amb.md_ambulance_call_note where call_id = xcall and (note_id = note) and note_description = 'р/у' and note_type = true and note_active = true;
                            calnotid = amb.add_call_note (xcall, i, FALSE, NULL, NULL, xreg, NULL);
                        end if;
                            xcnote = amb.add_call_note (xcall, note, TRUE, NULL,'а/у',xreg,NULL);
                    end if;

                    /*автодобавление отметки псих по поводу*/
                    SELECT INTO ps p.e_code from amb.md_ambulance_caller_reason cr
                           left join public.md_profile p on cr.profile_id = p.id
                           where cr.id = xreason and p.id = 138;

                        if (ps = '72' and xpsycho is TRUE) then
                                if exists (select * from amb.md_ambulance_call_note where call_id = xcall and (note_id = 3 or note_id = 5 or note_id = 6 or note_id = 15) and note_description = 'а/у' and note_type = true and note_active = true)
                                    then
                                    select into j note_id from amb.md_ambulance_call_note where call_id = xcall and (note_id = 3 or note_id = 5 or note_id = 6 or note_id = 15) and note_description = 'а/у' and note_type = true and note_active = true;
                                    cnote = amb.add_call_note (xcall, j, FALSE, NULL, NULL, xreg, NULL);
                                end if;
                                if exists (select * from amb.md_ambulance_call_note where call_id = xcall and (note_id = 15) and note_description = 'р/у' and note_type = true and note_active = true)
                                    then
                                    select into i note_id from amb.md_ambulance_call_note where call_id = xcall and (note_id = 15) and note_description = 'р/у' and note_type = true and note_active = true;
                                    calnotid = amb.add_call_note (xcall, i, FALSE, NULL, NULL, xreg, NULL);
                                end if;
                            check1 = true;
                            xcnote = amb.add_call_note (xcall, 15, TRUE, NULL,'а/у',xreg,NULL);
                        end if;

                    if (note is null or ps != '72')
                        then
                            if exists (select * from amb.md_ambulance_call_note where call_id = xcall and (note_id = 3 or note_id = 5 or note_id = 6 or note_id = 15) and note_description = 'а/у' and note_type = true and note_active = true)
                                then
                                select into i note_id from amb.md_ambulance_call_note where call_id = xcall and (note_id = 3 or note_id = 5 or note_id = 6 or note_id = 15) and note_description = 'а/у' and note_type = true and note_active = true;
                                cnote = amb.add_call_note (xcall, i, FALSE, NULL,NULL,xreg,NULL);
                            end if;
                    end if;

                    /*автодобавление ПСИХ по диагноз-поводу*/
                    if (xdiagreason is not null and xpsycho is true) then
                        if exists (SELECT * from md_diagnosis where id = xdiagreason and code like ('F%'))
                                then
                                    if exists (select * from amb.md_ambulance_call_note where call_id = xcall and (note_id = 15) and note_description = 'а/у' and note_type = true and note_active = true)
                                        then
                                            select into i note_id from amb.md_ambulance_call_note where call_id = xcall and (note_id = 15) and note_description = 'а/у' and note_type = true and note_active = true;
                                            cnote = amb.add_call_note (xcall, i, FALSE, NULL,NULL,xreg,NULL);
                                    end if;
                                    if exists (select * from amb.md_ambulance_call_note where call_id = xcall and (note_id = 15) and note_description = 'р/у' and note_type = true and note_active = true)
                                        then
                                        select into i note_id from amb.md_ambulance_call_note where call_id = xcall and (note_id = 15) and note_description = 'р/у' and note_type = true and note_active = true;
                                        calnotid = amb.add_call_note (xcall, i, FALSE, NULL, NULL, xreg, NULL);
                                    end if;
                                xcnote = amb.add_call_note (xcall, 15, TRUE, NULL,'а/у',xreg,NULL);
                                else
                                if exists (select * from amb.md_ambulance_call_note where call_id = xcall and (note_id = 15) and note_description = 'а/у' and note_type = true and note_active = true)
                                        then
                                        select into i note_id from amb.md_ambulance_call_note where call_id = xcall and (note_id = 15) and note_description = 'а/у' and note_type = true and note_active = true;
                                        cnote = amb.add_call_note (xcall, i, FALSE, NULL,NULL,xreg,NULL);
                                end if;
                            check2 = true;
                        end if;
                    end if;

                    /*добавление отметки псих (по наличию галочки на вызове)*/
                    if (xpsycho is TRUE and (check1 is false OR check2 is false))
                        then
                            if exists (select * from amb.md_ambulance_call_note where call_id = xcall and note_id = 15 and note_type = true and note_active = true)
                                    then
                                    select into i note_id from amb.md_ambulance_call_note where call_id = xcall and note_id = 15 and note_type = true and note_active = true;
                                    cnote = amb.add_call_note (xcall, i, FALSE, NULL,NULL,xreg,NULL);
                                end if;
                            cnote = amb.add_call_note (xcall, 15, TRUE, NULL,'р/у',xreg,NULL);
                        else
                        if exists (select * from amb.md_ambulance_call_note where call_id = xcall and note_id = 15 and note_description = 'р/у' and note_type = true and note_active = true)
                                    then
                                    select into i note_id from amb.md_ambulance_call_note where call_id = xcall and note_id = 15 and note_description = 'р/у' and note_type = true and note_active = true;
                                    cnote = amb.add_call_note (xcall, i, FALSE, NULL,NULL,xreg,NULL);
                        end if;
                    end if;

                    /*автодобавление ОПАС*/
                    if exists (select * from amb.pim_org_dangerous_area da where
                                (da.org_id = xorg and xdep is null and da.dep_id is null)
                                or (da.org_id is null and xorg is null and da.dep_id = xdep)
                                or (da.org_id = xorg and da.dep_id = xdep)
            /*                    or (da.address_id = xaddr and xorg is null and xdep is null)*/
                                or ((da.address_id = xaddr)
                                        or (amb.check_address_in_district(xaddr, da.address_id, xbuild, da.building_pattent) is true)))
                                then danger = true;
                    end if;

                    if (danger is true)
                            then
                                if exists (select * from amb.md_ambulance_call_note where call_id = xcall and (note_id = 12) and note_type = true and note_active = true)
                                    then
                                    select into i note_id from amb.md_ambulance_call_note where call_id = xcall and (note_id = 12) and note_type = true and note_active = true;
                                    cnote = amb.add_call_note (xcall, i, FALSE, NULL,NULL,xreg,NULL);
                                end if;
                            xcnote = amb.add_call_note (xcall, 12, TRUE, NULL,'а/у',xreg,NULL);
                            else
                                if exists (select * from amb.md_ambulance_call_note where call_id = xcall and (note_id = 12) and note_description = 'а/у' and note_type = true and note_active = true)
                                    then
                                    select into i note_id from amb.md_ambulance_call_note where call_id = xcall and (note_id = 12) and note_description = 'а/у' and note_type = true and note_active = true;
                                    cnote = amb.add_call_note (xcall, i, FALSE, NULL,NULL,xreg,NULL);
                                end if;
                    end if;

                end;
$$;

