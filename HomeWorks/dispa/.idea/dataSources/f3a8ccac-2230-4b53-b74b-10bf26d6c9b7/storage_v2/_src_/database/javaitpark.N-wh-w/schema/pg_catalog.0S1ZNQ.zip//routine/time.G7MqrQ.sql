CREATE FUNCTION time(abstime)
  RETURNS time without time zone
STABLE
STRICT
PARALLEL SAFE
COST 1
LANGUAGE SQL
AS $$
select cast(cast($1 as timestamp without time zone) as pg_catalog.time)
$$;

