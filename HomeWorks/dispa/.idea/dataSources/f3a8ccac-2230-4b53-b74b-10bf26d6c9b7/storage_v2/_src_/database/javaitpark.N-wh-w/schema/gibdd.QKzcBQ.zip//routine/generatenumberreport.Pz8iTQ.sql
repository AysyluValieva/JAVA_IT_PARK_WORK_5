CREATE FUNCTION generatenumberreport(xcaseid integer)
  RETURNS character varying
LANGUAGE plpgsql
AS $$
declare
            number character varying;
            mepId integer;
            orgId integer;
        begin
              mepId:=(select mep.id from disp.md_event_patient mep where mep.case_id=xcaseId);
             number:= (select number_report from disp.md_event_patient mep
              where mep.id= mepId);
              orgId:=(select me.org_id from disp.md_event_patient mep
              left join disp.md_event me on me.id=mep.event_id
              where mep.id=mepId);
              if (number is null) then
              number:=(select number_report from disp.md_organization_number_report where org_id=orgId);
              update disp.md_event_patient set number_report=number where id=mepId;
              update disp.md_organization_number_report set number_report=(number::integer+1) where org_id=orgId;
              end if;

             return number;
        end;
$$;

