CREATE FUNCTION address__get_nearest_okato(xid integer)
  RETURNS character varying
LANGUAGE plpgsql
AS $$
declare
  retval varchar;
begin
    select okato into retval from (with recursive temp1(id, parent_id, path, cycle, rownum, okato) as (
        select ae.id,ae.parent_id,array[ae.id],false,1,ac.value
        from address_element ae left join address_code ac on (ac.element_id = ae.id and ac.book_id = 2)
            where ae.id = xid
      union all
        select ae2.id, ae2.parent_id,path||ae2.id,ae2.id=any(path),rownum+1,ac2.value
        from address_element ae2
        left join address_code ac2 on (ac2.element_id = ae2.id and ac2.book_id = 2)
        inner join temp1 on (temp1.parent_id = ae2.id) and not cycle
      )
      select id, parent_id, rownum, okato
        from  temp1 where okato is not null order by rownum asc limit 1) t1;
  return retval;
end;
$$;

