CREATE FUNCTION repartitioning_task(_task_id integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
                  task_record     RECORD;
                  message         TEXT;
                  dates           DATE [];
                  start_date      DATE;
                  end_date        DATE;
                  cur_date        DATE;
                  next_date       DATE;
                  table_name      VARCHAR;
                  old_period_code VARCHAR;
                  new_period_code VARCHAR;
                  interval_shift  INTEGER;
                  period_shift    VARCHAR;
                  table_postfix   VARCHAR;
                BEGIN
                  RAISE NOTICE 'Start repartitioning task [id = %]', _task_id;

                  SELECT *
                  INTO task_record
                  FROM audit.repartitioning_task
                  WHERE id = _task_id;

                  IF task_record.from_partition_period_id = task_record.to_partition_period_id
                  THEN
                    UPDATE audit.repartitioning_task
                    SET
                      status_id     = 4,
                      updated_at    = current_timestamp,
                      error_message = 'New period of partitions can not be equal to the previous'
                    WHERE id = _task_id;
                    RETURN;
                  END IF;

                  IF (SELECT audit.check_partition_period_change(task_record.table_setting_id,
                                                                 task_record.from_partition_period_id,
                                                                 task_record.to_partition_period_id)) = FALSE
                  THEN
                    UPDATE audit.repartitioning_task
                    SET status_id = 4, updated_at = current_timestamp, error_message = 'Exceeding the maximum partition size'
                    WHERE id = _task_id;
                    RETURN;
                  END IF;

                  SELECT concat(t.table_schema, '$', t.table_name)
                  INTO table_name
                  FROM audit.table_setting t
                  WHERE t.id = task_record.table_setting_id;

                  SELECT lower(code)
                  INTO old_period_code
                  FROM audit.partition_period
                  WHERE id = task_record.from_partition_period_id;

                  SELECT lower(code)
                  INTO new_period_code
                  FROM audit.partition_period
                  WHERE id = task_record.to_partition_period_id;

                  dates = audit.get_audit_table_aud_when_interval(table_name, old_period_code, new_period_code);
                  start_date = dates [1];
                  end_date = dates [2];

                  IF new_period_code = 'none'
                  THEN
                    EXECUTE format('DELETE FROM ONLY audit."%1$s"', table_name);
                    EXECUTE format('INSERT INTO audit."%1$s" SELECT * FROM audit."%1$s"', table_name);
                  ELSE
                    cur_date = start_date;

                    IF new_period_code = 'quarter'
                    THEN
                      interval_shift = 3;
                      period_shift = 'month';
                    ELSE
                      interval_shift = 1;
                      period_shift = new_period_code;
                    END IF;

                    WHILE cur_date < end_date LOOP
                      EXECUTE
                      format('SELECT DATE ''%1$s'' + interval ''%2$s''', cur_date, concat(interval_shift, ' ', period_shift))
                      INTO next_date;

                      table_postfix = (SELECT concat('$', left(new_period_code, 1), '_', to_char(cur_date, 'YYYY_MM_DD')));

                      EXECUTE format(
                          'CREATE TABLE audit."%1$s" (CHECK (aud_when >= ''%2$s''::TIMESTAMP AND aud_when < ''%3$s''::TIMESTAMP))
                            INHERITS (audit."%4$s")',
                          concat(table_name, table_postfix) :: TEXT, cur_date, next_date, table_name);

                      EXECUTE format(
                          'INSERT INTO audit."%1$s"
                           SELECT * FROM audit."%2$s"
                           WHERE aud_when >= ''%3$s'' AND aud_when < ''%4$s''',
                          concat(table_name, table_postfix) :: TEXT, table_name, cur_date :: TIMESTAMP, next_date :: TIMESTAMP);

                      cur_date = next_date;
                    END LOOP;
                  END IF;

                  IF old_period_code = 'none'
                  THEN
                    EXECUTE format('DELETE FROM ONLY audit."%1$s"', table_name);
                  ELSE
                    cur_date = date_trunc(old_period_code, start_date);

                    IF old_period_code = 'quarter'
                    THEN
                      interval_shift = 3;
                      period_shift = 'month';
                    ELSE
                      interval_shift = 1;
                      period_shift = old_period_code;
                    END IF;

                    WHILE cur_date < end_date LOOP
                      EXECUTE
                      format('SELECT DATE ''%1$s'' + interval ''%2$s''', cur_date, concat(interval_shift, ' ', period_shift))
                      INTO next_date;

                      table_postfix = (SELECT concat('$', left(old_period_code, 1), '_', to_char(cur_date, 'YYYY_MM_DD')));

                      EXECUTE format('DROP TABLE IF EXISTS audit."%1$s"', concat(table_name, table_postfix) :: TEXT);

                      cur_date = next_date;
                    END LOOP;
                  END IF;

                  EXECUTE format('DROP TRIGGER IF EXISTS audit_partitioning_trigger ON %1$s', replace(table_name, '$', '.'));

                  EXECUTE format('
                      CREATE TRIGGER audit_partitioning_trigger
                      AFTER INSERT OR UPDATE OR DELETE
                      ON %s
                      FOR EACH ROW
                      EXECUTE PROCEDURE audit.partitioning_trigger_fun(%s)', replace(table_name, '$', '.'), new_period_code
                  );

                  UPDATE audit.repartitioning_task
                  SET status_id = 3, updated_at = current_timestamp
                  WHERE id = _task_id;

                  UPDATE audit.table_setting
                  SET partition_period_id = task_record.to_partition_period_id
                  WHERE id = task_record.table_setting_id;
                END;
$$;

