CREATE FUNCTION update_service_prescription_status_on_delete_sr_srv_rendered()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN
     perform update_prescription_status(OLD.md_prescription_id);
  END IF;
  RETURN NULL;
END;
$$;

