CREATE FUNCTION document(integer, text, text)
  RETURNS pim_individual_doc
LANGUAGE SQL
AS $$
select * from pim_individual_doc where 
		(type_id, upper(((COALESCE(series, ''::character varying))::text || ("number")::text)))=
				($1, upper(((coalesce($2, ''::character varying))::text || $3::text)))
		and issuer_id is null;
$$;

