CREATE FUNCTION no_doubling_on_create_new_mc_step()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE
                                  r RECORD;
                                BEGIN
								IF EXISTS(SELECT 1
											FROM public.mc_step ms WHERE
										  (((ms.admission_date IS NULL AND NEW.admission_date IS NULL) OR ms.admission_date = NEW.admission_date))

										  AND (((ms.outcome_date IS NULL AND NEW.outcome_date IS NULL) OR ms.outcome_date = NEW.outcome_date))
										  AND (((ms.case_id IS NULL AND NEW.case_id IS NULL) OR ms.case_id = NEW.case_id))
										  AND (((ms.regimen_id IS NULL AND NEW.regimen_id IS NULL) OR ms.regimen_id = NEW.regimen_id))
										  AND (((ms.res_group_id IS NULL AND NEW.res_group_id IS NULL) OR ms.res_group_id = NEW.res_group_id))
										  AND (((ms.outcome_id IS NULL AND NEW.outcome_id IS NULL) OR ms.outcome_id = NEW.outcome_id))
										  AND (((ms.profile_id IS NULL AND NEW.profile_id IS NULL) OR ms.profile_id = NEW.profile_id))
										  AND (((ms.plc_goal_id IS NULL AND NEW.plc_goal_id IS NULL) OR ms.plc_goal_id = NEW.plc_goal_id))
										  AND (((ms.plc_place_id IS NULL AND NEW.plc_place_id IS NULL) OR ms.plc_place_id = NEW.plc_place_id))
										  AND ((current_timestamp - ms.aud_when_create) < '3s' :: INTERVAL)

										  order by id desc limit 1000
										  )
                                  THEN
                                    RAISE EXCEPTION 'Произошло автоматическое дублирование строк, дубль не сохранен';
                                  END IF;
                                  RETURN NEW;
                                END;
$$;

