CREATE MATERIALIZED VIEW mv_step AS SELECT c.clinic_id,
    h.department_id,
    s.profile_id,
        CASE
            WHEN (date_part('year'::text, age((s.outcome_date)::timestamp with time zone, (i.birth_dt)::timestamp with time zone)) < (1)::double precision) THEN 1
            WHEN ((date_part('year'::text, age((s.outcome_date)::timestamp with time zone, (i.birth_dt)::timestamp with time zone)) >= (1)::double precision) AND (date_part('year'::text, age((s.outcome_date)::timestamp with time zone, (i.birth_dt)::timestamp with time zone)) <= (17)::double precision)) THEN 2
            WHEN ((date_part('year'::text, age((s.outcome_date)::timestamp with time zone, (i.birth_dt)::timestamp with time zone)) >= (18)::double precision) AND (date_part('year'::text, age((s.outcome_date)::timestamp with time zone, (i.birth_dt)::timestamp with time zone)) <= (59)::double precision)) THEN 3
            WHEN (date_part('year'::text, age((s.outcome_date)::timestamp with time zone, (i.birth_dt)::timestamp with time zone)) >= (60)::double precision) THEN 4
            ELSE NULL::integer
        END AS age_category_id,
    i.gender_id,
    dia.diagnos_id,
    c.funding_id,
    c.care_regimen_id,
    s.outcome_date,
    x.id AS democube_days_id,
    count(DISTINCT s.id) AS step_cnt,
    count(DISTINCT c.patient_id) AS patient_cnt,
    count(DISTINCT
        CASE
            WHEN r.is_death THEN s.id
            ELSE NULL::integer
        END) AS death_step_cnt
   FROM ((((((mc_step s
     JOIN mc_case c ON ((c.closing_step_id = s.id)))
     LEFT JOIN mc_step_result r ON ((s.result_id = r.id)))
     JOIN hsp_record h ON ((h.id = s.id)))
     JOIN pim_individual i ON (((c.patient_id = i.id) AND (i.gender_id = ANY (ARRAY[1, 2])) AND (i.birth_dt IS NOT NULL))))
     LEFT JOIN mc_diagnosis dia ON ((c.main_diagnos_id = dia.id)))
     JOIN cube_days x ON ((s.outcome_date = x.calendar_date)))
  GROUP BY c.clinic_id, h.department_id, s.profile_id,
        CASE
            WHEN (date_part('year'::text, age((s.outcome_date)::timestamp with time zone, (i.birth_dt)::timestamp with time zone)) < (1)::double precision) THEN 1
            WHEN ((date_part('year'::text, age((s.outcome_date)::timestamp with time zone, (i.birth_dt)::timestamp with time zone)) >= (1)::double precision) AND (date_part('year'::text, age((s.outcome_date)::timestamp with time zone, (i.birth_dt)::timestamp with time zone)) <= (17)::double precision)) THEN 2
            WHEN ((date_part('year'::text, age((s.outcome_date)::timestamp with time zone, (i.birth_dt)::timestamp with time zone)) >= (18)::double precision) AND (date_part('year'::text, age((s.outcome_date)::timestamp with time zone, (i.birth_dt)::timestamp with time zone)) <= (59)::double precision)) THEN 3
            WHEN (date_part('year'::text, age((s.outcome_date)::timestamp with time zone, (i.birth_dt)::timestamp with time zone)) >= (60)::double precision) THEN 4
            ELSE NULL::integer
        END, i.gender_id, dia.diagnos_id, c.funding_id, c.care_regimen_id, s.outcome_date, x.id;

CREATE INDEX mv_step_clinic_id_inx
  ON mv_step (clinic_id);

CREATE INDEX mv_step_department_id_inx
  ON mv_step (department_id);

CREATE INDEX mv_step_profile_id_inx
  ON mv_step (profile_id);

CREATE INDEX mv_step_age_category_id_inx
  ON mv_step (age_category_id);

CREATE INDEX mv_step_gender_id_inx
  ON mv_step (gender_id);

CREATE INDEX mv_step_diagnos_id_inx
  ON mv_step (diagnos_id);

CREATE INDEX mv_step_funding_id_inx
  ON mv_step (funding_id);

CREATE INDEX mv_step_care_regimen_id_inx
  ON mv_step (care_regimen_id);

CREATE INDEX mv_step_outcome_date_inx
  ON mv_step (outcome_date);

CREATE INDEX mv_step_democube_days_id_inx
  ON mv_step (democube_days_id);

