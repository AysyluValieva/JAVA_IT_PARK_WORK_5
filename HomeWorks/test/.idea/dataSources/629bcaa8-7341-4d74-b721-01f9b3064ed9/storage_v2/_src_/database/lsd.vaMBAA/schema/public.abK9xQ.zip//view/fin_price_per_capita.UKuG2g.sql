CREATE VIEW fin_price_per_capita AS
  SELECT fin_price_per_capita.org_id,
    fin_price_per_capita.org_name,
    fin_price_per_capita.norm,
    fin_price_per_capita.ratio,
    fin_price_per_capita.per_capita_norm,
    fin_price_per_capita.salary_percent,
    fin_price_per_capita.consumable_percent,
    fin_price_per_capita.inventory_percent,
    fin_price_per_capita.maintenance_percent,
    fin_price_per_capita.from_dt,
    fin_price_per_capita.to_dt
   FROM billing.fin_price_per_capita;

