CREATE FUNCTION get_last_hospital_record_for_case(caseid integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
    recordId integer;

  begin
     select id  into recordId  from mc_step ms where ms.case_id = caseId order by ms.admission_date desc, ms.admission_time desc limit 1;
     return recordId;
  end;
$$;

