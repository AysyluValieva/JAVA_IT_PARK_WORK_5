CREATE FUNCTION upd_department_id_at_mc_step_fn()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE
                  departmentId INTEGER;
                BEGIN
                  UPDATE mc_step
                  SET _department_id = NEW.department_id WHERE id = new.id and coalesce(_department_id, -1) <> coalesce(NEW.department_id, -1);
                  RETURN NULL;
                END;
$$;

