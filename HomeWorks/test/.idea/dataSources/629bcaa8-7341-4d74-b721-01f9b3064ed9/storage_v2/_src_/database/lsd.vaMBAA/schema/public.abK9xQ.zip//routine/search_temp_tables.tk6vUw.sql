CREATE FUNCTION search_temp_tables(sch character varying, kl character varying)
  RETURNS SETOF text
STRICT
LANGUAGE plpgsql
AS $$
declare
    dl integer;
        r text;
        sc text;
        _schema text[];
        _key text[];
        tab record;
    begin
                if trim($2)='' then raise exception 'Введите хотя бы одно ключевое слово'; end if;
                select string_to_array($2, ',') into _key;
        select string_to_array($1, ',') into _schema;
        select array_length(_schema,1) into dl;
                for i in 1..array_length(_key,1) loop
                        for tab in select * from pg_tables where tablename ilike '%'||replace(trim(_key[i]),'_','\_')||'%' and case when dl is not null then schemaname=any(_schema) else 1=1 end  loop
                                return next 'ALTER TABLE '||tab.schemaname||'.'||tab.tablename||' SET SCHEMA supp;';
                        end loop;
                end loop;
        end;
$$;

