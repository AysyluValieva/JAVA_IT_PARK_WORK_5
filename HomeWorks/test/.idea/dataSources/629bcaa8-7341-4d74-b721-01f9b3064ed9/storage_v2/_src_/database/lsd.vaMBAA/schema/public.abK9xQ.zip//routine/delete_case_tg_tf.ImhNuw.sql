CREATE FUNCTION delete_case_tg_tf()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
                    IF (2 = (select case_mode_id from mc_case_type where id = OLD.case_type_id)) THEN
                      delete from sr_srv_rendered where md_case_id = OLD.id;
                    END IF;
                    RETURN OLD;
                  END;
$$;

