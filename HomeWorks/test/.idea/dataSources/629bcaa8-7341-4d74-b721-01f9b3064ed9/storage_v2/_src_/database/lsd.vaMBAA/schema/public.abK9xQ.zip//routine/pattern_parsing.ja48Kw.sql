CREATE FUNCTION pattern_parsing(patt character varying)
  RETURNS character varying[]
LANGUAGE plpgsql
AS $$
declare
result text [];
_b integer;
_e integer;
begin
if patt ~ '^Ч\(\d+-\d+\)$' then 
	select substring (patt from '^Ч\((\d+)-\d+\)$')::integer into _b;
  select substring (patt from '^Ч\(\d+-(\d+)\)$')::integer into _e;
  if _b%2=0 then 
		select array_agg(g::text) into result from generate_series(_b, _e, 2) g; 
  else 
		select array_agg(g::text) into result from generate_series(_b+1, _e, 2) g; 
  end if;
elsif patt ~ '^Н\(\d+-\d+\)$' then 
	select substring (patt from '^Н\((\d+)-\d+\)$') into _b;
  select substring (patt from '^Н\(\d+-(\d+)\)$') into _e;
		if _b%2=0 then 
			select array_agg(g::text) into result from generate_series(_b+1, _e, 2) g; 
    else 
			select array_agg(g::text) into result from generate_series(_b, _e, 2) g; 
    end if;
elsif patt ~ '^\d+-\d+$' then 
	select substring (patt from '^(\d+)-\d+$') into _b;
	select substring (patt from '^\d+-(\d+)$') into _e;
	select array_agg(g::text) into result from generate_series(_b, _e) g;
else 
	select array[patt] into result;
end if;
return result;
end;
$$;

