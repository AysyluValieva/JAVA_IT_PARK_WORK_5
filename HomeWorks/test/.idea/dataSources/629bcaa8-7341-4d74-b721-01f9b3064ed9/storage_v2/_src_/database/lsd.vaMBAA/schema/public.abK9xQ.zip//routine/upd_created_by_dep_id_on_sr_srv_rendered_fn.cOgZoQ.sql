CREATE FUNCTION upd_created_by_dep_id_on_sr_srv_rendered_fn()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
                        IF TG_OP = 'INSERT' OR TG_OP = 'UPDATE'
                        THEN
                            UPDATE sr_srv_rendered ssr
                            SET _created_by_dep_id = ms._department_id
                            FROM mc_step ms
                            WHERE NEW.id = ssr.id and NEW.md_step_id = ms.id;
                        END IF;
                        RETURN NULL;
                    END;
$$;

