CREATE VIEW md_diagnosis_for_validation AS
  SELECT unnest(t.code_arr) AS code
   FROM ( SELECT v.code_arr
           FROM supp.validation_tambov_visit_diag_not_paid_mhi v
          ORDER BY v.to_dt DESC
         LIMIT 1) t;

