CREATE RULE insert_user_party AS
    ON INSERT TO sec_user_party_own_org DO INSTEAD NOTHING;

