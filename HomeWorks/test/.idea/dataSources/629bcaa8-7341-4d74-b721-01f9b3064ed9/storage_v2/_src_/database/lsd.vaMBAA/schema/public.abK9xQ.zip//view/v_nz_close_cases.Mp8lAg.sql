CREATE VIEW v_nz_close_cases AS
  SELECT mv_nz_close_cases.clinic_id,
    mv_nz_close_cases.gender_id,
    mv_nz_close_cases.soc_group_id,
    mv_nz_close_cases.care_regimen_id,
    mv_nz_close_cases.result_id,
    mv_nz_close_cases.care_result_id,
    mv_nz_close_cases.department_id,
    mv_nz_close_cases.diagnos_id,
    mv_nz_close_cases.profile_id,
    mv_nz_close_cases.democube_days_id,
    mv_nz_close_cases.age_category_2_id,
    mv_nz_close_cases.age_category_3_id,
    mv_nz_close_cases.mc_cnt
   FROM mv_nz_close_cases;

