CREATE MATERIALIZED VIEW mv_nz_cases_by_categories AS WITH smo AS (
         SELECT pid.indiv_id,
            pid.issuer_id,
            pid.issue_dt,
            pid.expire_dt,
                CASE t.code
                    WHEN 'MHI_UNIFORM'::text THEN 0
                    WHEN 'MHI_TEMP'::text THEN 1
                    WHEN 'MHI_OLDER'::text THEN 2
                    ELSE 3
                END AS fl
           FROM ((pim_individual_doc pid
             JOIN pim_doc_type t ON ((t.id = pid.type_id)))
             JOIN pim_doc_type_category cat ON (((cat.type_id = t.id) AND (cat.category_id = 2))))
        ), dset AS (
         SELECT mc.clinic_id,
            i.gender_id,
            mc.soc_group_id,
            mc.care_regimen_id,
            mc.funding_id,
            x.id AS democube_days_id,
            mc.open_date,
            mc.patient_id,
            date_part('year'::text, age((
                CASE
                    WHEN (mc.closing_step_id IS NOT NULL) THEN COALESCE(ms.outcome_date, ms.admission_date)
                    ELSE mc.open_date
                END)::timestamp with time zone, (i.birth_dt)::timestamp with time zone)) AS age,
            mc.id AS open_case,
            ms.id AS close_case,
            r.is_death,
            smo.issuer_id AS smo_issuer_id,
            row_number() OVER (PARTITION BY mc.id ORDER BY smo.fl) AS rn
           FROM (((((mc_case mc
             LEFT JOIN mc_step ms ON ((ms.id = mc.closing_step_id)))
             JOIN cube_days x ON (((x.calendar_date = mc.open_date) OR (x.calendar_date = COALESCE(ms.outcome_date, ms.admission_date)))))
             JOIN pim_individual i ON (((i.id = mc.patient_id) AND (i.gender_id = ANY (ARRAY[1, 2])) AND (i.birth_dt IS NOT NULL))))
             LEFT JOIN mc_step_result r ON ((r.id = ms.result_id)))
             LEFT JOIN smo ON (((smo.indiv_id = i.id) AND (mc.open_date >= COALESCE(smo.issue_dt, mc.open_date)) AND (mc.open_date <= COALESCE(smo.expire_dt, mc.open_date)))))
        )
 SELECT dset.clinic_id,
    dset.care_regimen_id,
    dset.funding_id,
    dset.soc_group_id,
    dset.gender_id,
    b.benefit_type_id,
    b.benefit_def_id,
    b.disability_type_id,
    dset.democube_days_id,
    dset.smo_issuer_id,
        CASE
            WHEN ((dset.gender_id = 1) AND (dset.age >= (16)::double precision) AND (dset.age <= (59)::double precision)) THEN 1
            WHEN ((dset.gender_id = 1) AND (dset.age >= (60)::double precision)) THEN 2
            WHEN ((dset.gender_id = 1) AND (dset.age < (16)::double precision)) THEN 5
            WHEN ((dset.gender_id = 2) AND (dset.age >= (16)::double precision) AND (dset.age <= (54)::double precision)) THEN 3
            WHEN ((dset.gender_id = 2) AND (dset.age >= (55)::double precision)) THEN 4
            WHEN ((dset.gender_id = 2) AND (dset.age < (16)::double precision)) THEN 7
            ELSE NULL::integer
        END AS age_category_2_id,
        CASE
            WHEN (dset.age = (0)::double precision) THEN 1
            WHEN (dset.age <= (3)::double precision) THEN 2
            WHEN (dset.age <= (5)::double precision) THEN 3
            WHEN (dset.age <= (7)::double precision) THEN 4
            WHEN (dset.age <= (14)::double precision) THEN 5
            WHEN (dset.age <= (15)::double precision) THEN 6
            WHEN (dset.age <= (17)::double precision) THEN 7
            ELSE 8
        END AS age_category_3_id,
    count(DISTINCT dset.open_case) AS open_case,
    count(DISTINCT
        CASE
            WHEN (NOT dset.is_death) THEN dset.close_case
            ELSE NULL::integer
        END) AS close_case,
    count(DISTINCT
        CASE
            WHEN dset.is_death THEN dset.close_case
            ELSE NULL::integer
        END) AS death_case
   FROM (dset
     LEFT JOIN pci_benefit b ON (((b.patient_id = dset.patient_id) AND (dset.open_date >= COALESCE(b.from_dt, dset.open_date)) AND (dset.open_date <= COALESCE(((b.to_dt - '1 day'::interval))::date, dset.open_date)))))
  WHERE (dset.rn = 1)
  GROUP BY dset.clinic_id, dset.care_regimen_id, dset.funding_id, dset.soc_group_id, dset.gender_id, b.benefit_type_id, b.benefit_def_id, b.disability_type_id, dset.democube_days_id, dset.smo_issuer_id,
        CASE
            WHEN ((dset.gender_id = 1) AND (dset.age >= (16)::double precision) AND (dset.age <= (59)::double precision)) THEN 1
            WHEN ((dset.gender_id = 1) AND (dset.age >= (60)::double precision)) THEN 2
            WHEN ((dset.gender_id = 1) AND (dset.age < (16)::double precision)) THEN 5
            WHEN ((dset.gender_id = 2) AND (dset.age >= (16)::double precision) AND (dset.age <= (54)::double precision)) THEN 3
            WHEN ((dset.gender_id = 2) AND (dset.age >= (55)::double precision)) THEN 4
            WHEN ((dset.gender_id = 2) AND (dset.age < (16)::double precision)) THEN 7
            ELSE NULL::integer
        END,
        CASE
            WHEN (dset.age = (0)::double precision) THEN 1
            WHEN (dset.age <= (3)::double precision) THEN 2
            WHEN (dset.age <= (5)::double precision) THEN 3
            WHEN (dset.age <= (7)::double precision) THEN 4
            WHEN (dset.age <= (14)::double precision) THEN 5
            WHEN (dset.age <= (15)::double precision) THEN 6
            WHEN (dset.age <= (17)::double precision) THEN 7
            ELSE 8
        END;

CREATE INDEX mv_nz_cases_by_categories_clinic_id_inx
  ON mv_nz_cases_by_categories (clinic_id);

CREATE INDEX mv_nz_cases_by_categories_care_regimen_id_inx
  ON mv_nz_cases_by_categories (care_regimen_id);

CREATE INDEX mv_nz_cases_by_categories_funding_id_inx
  ON mv_nz_cases_by_categories (funding_id);

CREATE INDEX mv_nz_cases_by_categories_soc_group_id_inx
  ON mv_nz_cases_by_categories (soc_group_id);

CREATE INDEX mv_nz_cases_by_categories_gender_id_inx
  ON mv_nz_cases_by_categories (gender_id);

CREATE INDEX mv_nz_cases_by_categories_benefit_type_id_inx
  ON mv_nz_cases_by_categories (benefit_type_id);

CREATE INDEX mv_nz_cases_by_categories_benefit_def_id_inx
  ON mv_nz_cases_by_categories (benefit_def_id);

CREATE INDEX mv_nz_cases_by_categories_disability_type_id_inx
  ON mv_nz_cases_by_categories (disability_type_id);

CREATE INDEX mv_nz_cases_by_categories_democube_days_id_inx
  ON mv_nz_cases_by_categories (democube_days_id);

CREATE INDEX mv_nz_cases_by_categories_smo_issuer_id_inx
  ON mv_nz_cases_by_categories (smo_issuer_id);

CREATE INDEX mv_nz_cases_by_categories_age_category_2_id_inx
  ON mv_nz_cases_by_categories (age_category_2_id);

CREATE INDEX mv_nz_cases_by_categories_age_category_3_id_inx
  ON mv_nz_cases_by_categories (age_category_3_id);

