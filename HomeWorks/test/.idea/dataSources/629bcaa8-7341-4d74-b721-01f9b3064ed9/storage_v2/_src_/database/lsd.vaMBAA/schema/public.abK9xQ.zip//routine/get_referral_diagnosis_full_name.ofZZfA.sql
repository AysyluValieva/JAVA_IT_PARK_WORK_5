CREATE FUNCTION get_referral_diagnosis_full_name(ref_id integer)
  RETURNS text
LANGUAGE plpgsql
AS $$
DECLARE
    full_name text;
  BEGIN
    SELECT concat_ws(' ', code,tt.subcode, concat_ws(', ', name, tt.subname)) into full_name
    FROM  
        public.md_referral ref 
        join public.md_diagnosis md_d ON md_d.id = ref.diagnosis_id
        left join (select rda.referral_id,
                    array_to_string(array_agg(av.value order by ap.pos), '.') as subcode,
					array_to_string(array_agg(av.name order by ap.pos), '; ') as subname
                    from mc_referral_diag_attr rda
                    join md_referral r on r.id=rda.referral_id
                    join md_attr_value av on av.id=rda.attr_value_id
                    join md_diag_attr mda on mda.id=av.diag_attr_id
                    join md_attr_pos ap on ap.diag_attr_id=mda.id and ap.diagnosis_id=r.diagnosis_id
                    group by rda.referral_id) as tt on tt.referral_id = ref.id    
        WHERE ref.id=ref_id;
    RETURN full_name;
  END;
$$;

