CREATE FUNCTION get_diagnosis_init(_diagnosis_id integer, _attrs integer[])
  RETURNS json
LANGUAGE plpgsql
AS $$
DECLARE result json;
                    begin
                         select row_to_json(data) into result from (
                            SELECT  _diagnosis_id as id,
                                get_diagnosis_full_name(_diagnosis_id, _attrs) as name,
                                (select json_agg(tt) from (
                                            select  v.diag_attr_id as attr_id, v.id as value_id, v.value as code
                                            from md_attr_value v inner join md_attr_pos p
                                     on p.diag_attr_id = v.diag_attr_id and p.diagnosis_id = _diagnosis_id
                                            where v.id =ANY(_attrs)
                                            order by pos
                                ) as tt) as attr
                         ) as data;
                         return result;
                    end;
$$;

