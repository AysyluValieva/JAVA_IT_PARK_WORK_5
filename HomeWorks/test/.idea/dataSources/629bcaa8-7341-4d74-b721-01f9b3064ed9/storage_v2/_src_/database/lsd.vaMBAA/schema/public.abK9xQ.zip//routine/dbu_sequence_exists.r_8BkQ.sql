CREATE FUNCTION dbu_sequence_exists(sequencename character varying, schemaname character varying)
  RETURNS boolean
LANGUAGE plpgsql
AS $$
declare result boolean;
            begin

            select count(*) > 0 into result
            from pg_class
            inner join pg_namespace on pg_class.relnamespace = pg_namespace.oid
            where pg_class.relkind = 'S'
            and pg_class.relname = lower($1)
            and pg_namespace.nspname = lower($2);

            return result;
            end;
$$;

