CREATE VIEW v_nz_department AS
  SELECT pd.id,
    pd.name,
    concat(pd.name, ((' ('::text || (o.short_name)::text) || ')'::text)) AS org_name
   FROM (pim_department pd
     JOIN pim_organization o ON ((o.id = pd.org_id)))
  ORDER BY o.short_name, pd.name;

