CREATE FUNCTION update_md_diagnosis_ts()
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
row record;
begin
--очищаем паренты
update md_diagnosis set parent_id=null;
--очищаем уровни
update md_diagnosis set level=null;
--очищаем лифы
update md_diagnosis set is_leaf=null;
for row in 
select id from md_diagnosis s1 where not exists
(select 1 from md_diagnosis where substring(s1.code,1,3)>=substring(code,1,3) and substring(s1.code,5,3)<=substring(code,5,3) and code like '%-%' and s1.id<>id)
and code like '%-%' loop
perform upd_md_diagnosis_for_interval(row.id,0,null);--проставляем уровни и паренты для интервалов
end loop;
perform upd_md_diagnosis_for_diag_bt();--проставляем уровни и паренты для диагнозов типа 'А00'
perform upd_md_diagnosis_for_diag_st();--проставляем уровни и паренты для диагнозов типа 'А00.0'
perform upd_md_diagnosis_for_is_leaf();--проставляем признак is_leaf для диагнозов
end;
$$;

