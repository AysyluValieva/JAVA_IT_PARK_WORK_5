CREATE FUNCTION get_patient_full_age(birth_dt date, open_dt date)
  RETURNS character varying
LANGUAGE plpgsql
AS $$
declare
                  age VARCHAR := '0';
                  year integer;
                  month integer;
                begin
                  if birth_dt IS NULL or open_dt IS NULL
                    then
                        return age;
                  end if;
                  year = DATE_PART('year', open_dt) - DATE_PART('year', birth_dt) - (CASE TO_CHAR(open_dt, 'MMDD') < TO_CHAR(birth_dt, 'MMDD') WHEN TRUE THEN 1 ELSE 0 END);
                  month = date_part('month', open_dt) - date_part('month',birth_dt) - (CASE TO_CHAR(open_dt, 'DD') < TO_CHAR(birth_dt, 'DD') WHEN TRUE THEN 1 ELSE 0 END);
                  if month < 0 then month = month + 12; end if;
                  IF year <= 0
                    THEN
                        if month <= 0
                            then
                            age = cast(open_dt - birth_dt ||' дн.' AS VARCHAR);
                            ELSE
                                age = cast(cast(month as varchar(2))||' мес.' as VARCHAR);
                        end if;
                    ELSE
                    if year in (11,12,13,14) or cast(right(cast(year as varchar(3)), 1) AS INT) in (0,5,6,7,8,9) then
                        age = cast(cast(year as varchar(3))||' л.' as VARCHAR);
                    else
                        age = cast(cast(year as varchar(3))||' г.' as VARCHAR);
                    end if;
                    if year < 18 then
                        age = cast(age||' '||cast(month as varchar(2))||' мес.' as VARCHAR);
                    end if;
                  END IF;
                  return age;
                end;
$$;

