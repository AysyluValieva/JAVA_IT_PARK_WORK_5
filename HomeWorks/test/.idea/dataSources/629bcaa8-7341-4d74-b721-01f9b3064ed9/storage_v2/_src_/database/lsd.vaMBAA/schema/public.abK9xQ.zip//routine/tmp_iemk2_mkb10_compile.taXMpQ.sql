CREATE FUNCTION tmp_iemk2_mkb10_compile(mapping_id integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
 _r RECORD;
 _int_ref INTEGER;
 _nsi_ref INTEGER;
 _nsi_code_col INTEGER;
 _int_id INTEGER;
BEGIN
  SELECT
     v_int.id,
    v_nsi.id,
    nsi_code_c.id
 INTO
     _int_ref,
    _nsi_ref,
    _nsi_code_col
 FROM
     mdm_refbook_mapping m
     JOIN mdm_refbook_version v_int ON m.target_refbook_id = v_int.id
     JOIN mdm_refbook_version v_nsi ON m.source_refbook_id = v_nsi.id
    JOIN mdm_refbook_column nsi_code_c ON v_nsi.id = nsi_code_c.refbook_version_id AND upper(trim(nsi_code_c.name))='NAME'
 WHERE
     m.id = mapping_id
 ; 
  
 FOR _r IN
     SELECT
        r.id as rec_id,
        c.value as code
    FROM
        mdm_record r 
        JOIN mdm_record_column c ON c.record_id = r.id
    WHERE
        r.refbook_version_id = _nsi_ref AND c.column_id = _nsi_code_col 
 LOOP 
     SELECT
        d.id 
    INTO
        _int_id    
    FROM
        pim_department d 
    WHERE
        upper(trim(d.name)) = upper(trim(_r.code))
    LIMIT 1;
     
    IF (_int_id IS NOT NULL) THEN
        IF (NOT EXISTS(SELECT 1 FROM mdm_record_mapping m WHERE m.source_refbook_id = _int_ref 
                              AND m.target_record_id = _r.rec_id AND m.source_record_id::integer = _int_id)) THEN
           INSERT INTO mdm_record_mapping (target_record_id,source_record_id,source_refbook_id)
               VALUES (_r.rec_id,_int_id,_int_ref);                   
        END IF;                      
    END IF;

 END LOOP;
  

END;
$$;

