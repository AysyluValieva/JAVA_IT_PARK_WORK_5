CREATE FUNCTION get_prescription_department(integer)
  RETURNS character varying
LANGUAGE plpgsql
AS $$
declare
                department varchar;
            begin

               select  coalesce(pd.name,'')
                      from md_srv_rendered msren  into department
                          left outer join mc_step ms on msren.step_id=ms.id
                          left outer join pim_department pd on pd.id=ms.hsp_department_id
                      where msren.patient_prescription_id = $1;

               return department;
            end;
$$;

