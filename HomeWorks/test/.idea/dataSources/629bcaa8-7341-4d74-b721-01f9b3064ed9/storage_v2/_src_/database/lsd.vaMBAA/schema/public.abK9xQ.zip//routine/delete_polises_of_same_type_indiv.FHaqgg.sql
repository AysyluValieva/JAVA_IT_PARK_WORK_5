CREATE FUNCTION delete_polises_of_same_type_indiv(_polis pim_individual_doc, _id integer)
  RETURNS text[]
LANGUAGE plpgsql
AS $$
declare
	_r pim_individual_doc%rowtype;
	_d text;
	_msg text[];
begin
	select "name" into _d from pim_doc_type where id = _polis.type_id;
	_msg := _msg || concat('Удаляю другие полисы у физ лица типа ', _d)::text;
	if exists (select 1 from pim_individual_doc where type_id = _polis.type_id and indiv_id = _polis.indiv_id and id <> _polis.id)
	then 
		for _r in select * from pim_individual_doc where type_id = _polis.type_id and indiv_id = _polis.indiv_id and id <> _polis.id
		loop
			_msg := _msg || 'Удаляю полис'::text || row_to_json(_r)::text;
			perform delete_document_by_id(_r.id);
		end loop;
		_msg := _msg || concat('Удаление других полисов типа ', _d, ' завершено')::text;
	else
		_msg := _msg || concat('У физ лица нет других полисов типа ', _d)::text;
	end if;
	return _msg;
end;
$$;

