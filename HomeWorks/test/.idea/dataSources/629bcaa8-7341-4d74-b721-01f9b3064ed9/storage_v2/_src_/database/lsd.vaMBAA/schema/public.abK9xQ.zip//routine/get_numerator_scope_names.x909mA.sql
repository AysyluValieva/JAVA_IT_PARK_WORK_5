CREATE FUNCTION get_numerator_scope_names(integer, boolean DEFAULT true)
  RETURNS character varying
LANGUAGE plpgsql
AS $$
DECLARE
                    scope_names character varying;
                BEGIN
                    select string_agg(get_scope_name(scope_id, $2), ', ') into scope_names from cmn_num_scope_current_value scv where scv.current_value_id = $1 group by scv.current_value_id;
                    RETURN scope_names;
                END;
$$;

