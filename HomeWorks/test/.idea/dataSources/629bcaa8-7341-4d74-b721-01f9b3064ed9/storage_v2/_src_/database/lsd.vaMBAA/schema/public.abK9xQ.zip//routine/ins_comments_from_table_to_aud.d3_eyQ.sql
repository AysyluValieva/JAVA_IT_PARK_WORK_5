CREATE FUNCTION ins_comments_from_table_to_aud()
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
            aud_table_name varchar; -- таблица с суффиксом aud
            aud_col_name varchar; -- колонка в таблице aud_table_name
            table_name varchar; -- основная таблица
            col_name varchar; -- колонка в основной таблице
            index int;
            BEGIN

            FOR aud_table_name IN
                SELECT aud.table_name FROM audit_log aud  -- для каждой таблицы_aud из audit_log
             loop
                FOR aud_col_name IN -- для всех колонок таблицы_aud
                     SELECT * FROM get_columns_of_table('public', aud_table_name)
                loop
                 index = index + 1;
                table_name := substring(aud_table_name from 0 for char_length(aud_table_name)-3); -- основная таблица
                index = 1;
                -- если такая колонка есть в основной таблице
                    FOR col_name IN SELECT * FROM get_columns_of_table('public', table_name)
                        loop
                         IF col_name = aud_col_name THEN
                            PERFORM  copy_comment(table_name,index,aud_table_name, col_name); -- копируем комментарий
                         END IF;
                             index = index+1;
                         END loop;
                         index = 0;
                     END loop;
            END loop;
            END;
$$;

