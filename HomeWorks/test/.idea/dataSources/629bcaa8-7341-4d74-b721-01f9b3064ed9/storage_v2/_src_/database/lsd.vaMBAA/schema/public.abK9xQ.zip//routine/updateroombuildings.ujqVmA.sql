CREATE FUNCTION updateroombuildings()
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
    queryText			VARCHAR;
    orgs_rec            RECORD;
    rooms_rec           RECORD;
    buildingId   		integer;
    floorId   			integer;
begin

for orgs_rec in
	select distinct pim_department.org_id as org_id
    from pim_room, pim_department
	where 
	pim_room.building_id in (select id from pim_building where org_id is null)
	and pim_department.id = pim_room.department_id

LOOP
  buildingId := nextval('pim_building_seq');
  floorId := nextval('pim_building_floor_seq');
  
  insert into pim_building (id, name, org_id) values (buildingId, 'Здание_'||orgs_rec.org_id, orgs_rec.org_id);
  insert into pim_building_floor (id, name, building_id) values (floorId, 'Этаж 1',  buildingId);
  
  for rooms_rec in 
	select 
    pim_room.id as room_id 
    from pim_room, pim_department
	where 
    pim_room.building_id in (select id from pim_building where org_id is null)
	and pim_department.id = pim_room.department_id
	and pim_department.org_id = orgs_rec.org_id

    LOOP
	  update pim_room set building_id = buildingId, floor_id = floorId where id = rooms_rec.room_id;
	END LOOP;
    
END LOOP;

end;
$$;

