CREATE FUNCTION tambov_loader_ident_download_person_process()
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
	_id int;
	_row tambov_loader_ident_download_person%rowtype;
	spliter constant text := '----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------';
	_msg text[];
begin


		for _row in select * from tambov_loader_ident_download_person where indiv_exists order by id
	loop

		_id := _row.id;
		
		_msg := array['Начинаю процесс обработки записи'];

		if _row.status <> '0' and _row.source = 'R' then 
			_msg := _msg || 'Обработка записи пропускается'::text || 'Данные переданы в центральный сегмент'::text;
			continue;
		end if;


		_msg := _msg || 'Физ лицо с ID указнным в поле ID_PAC найдено в БД'::text || 'Приступаю к обновлению данных.'::text;

				_msg := _msg || spliter || 'Идент.документы начало'::text;
		if _row.doctype is null or _row.docnum is null then 
			_msg := _msg || 'Не указан тип или номер идентификационного документа в XML документе'::text || 'Пропускаю обновление идентификационных документов'::text;
		else
			_msg := _msg || update_ident_document(_row)::text[];
		end if;
		_msg := _msg || 'Идент.документы конец'::text;


				

		_msg := _msg || spliter || 'Обработка записи завершена.'::text;
		update tambov_loader_ident_download_person set msg = msg || _msg where id = _id;
		_msg := null;
	end loop;
end;
$$;

