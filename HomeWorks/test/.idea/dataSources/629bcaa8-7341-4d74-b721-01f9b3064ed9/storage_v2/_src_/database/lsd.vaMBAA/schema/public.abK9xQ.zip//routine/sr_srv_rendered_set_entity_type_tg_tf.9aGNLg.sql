CREATE FUNCTION sr_srv_rendered_set_entity_type_tg_tf()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  if NEW.entity_type is null then
    NEW.entity_type := 1;
  else
    NEW.entity_type_aware := true;
  end if;
  RETURN NEW;
END;
$$;

