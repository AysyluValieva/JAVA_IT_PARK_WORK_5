CREATE FUNCTION tmp_xor(boolean, boolean)
  RETURNS boolean
LANGUAGE plpgsql
AS $$
begin
RETURN ( $1 and not $2) or ( not $1 and $2);
end;
$$;

