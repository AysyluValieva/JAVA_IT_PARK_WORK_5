CREATE FUNCTION audit_trigger_fun()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE
    app_user   TEXT;
    app_source TEXT;
    cur_time TIMESTAMP;
  BEGIN
    cur_time := now();
    --uses coalesce because have problem to equal with null
    IF (TG_OP = 'UPDATE' AND (coalesce(NEW.aud_who_create, 'empty') != coalesce(OLD.aud_who_create, 'empty')
                              OR coalesce(NEW.aud_when_create, cur_time) != coalesce(OLD.aud_when_create, cur_time)
                              OR coalesce(NEW.aud_source_create, 'empty') != coalesce(OLD.aud_source_create, 'empty')
                              OR coalesce(NEW.aud_who, 'empty') != coalesce(OLD.aud_who, 'empty')
                              OR coalesce(NEW.aud_when, cur_time) != coalesce(OLD.aud_when, cur_time)
                              OR coalesce(NEW.aud_source, 'empty') != coalesce(OLD.aud_source, 'empty'))
        OR TG_OP = 'INSERT' AND (NEW.aud_who_create IS NOT NULL OR NEW.aud_when_create IS NOT NULL OR NEW.aud_source_create IS NOT NULL
                                 OR NEW.aud_who IS NOT NULL OR NEW.aud_when IS NOT NULL  OR NEW.aud_source IS NOT NULL)
    )
    THEN
      RAISE EXCEPTION 'AUDIT COLUMNS NOT EDITABLE';
      RETURN NULL;
    END IF;
    -- set value for extended_aud_trigger
    PERFORM set_config('aud.when'::TEXT, to_char(cur_time, 'YYYY-MM-DD HH24:MI:SS:MS'), true);
    BEGIN
      SELECT current_setting('app.user')
      INTO app_user;
      IF (app_user = 'unknown')
      THEN
        app_user:= CURRENT_USER;
      END IF;
      EXCEPTION
      WHEN OTHERS THEN
        app_user:= CURRENT_USER;
    END;

    BEGIN
      SELECT current_setting('app.source')
      INTO app_source;
      EXCEPTION
      WHEN OTHERS THEN
        app_source := 'DB';
    END;
    NEW.aud_when:= cur_time;
    NEW.aud_who:= app_user;
    NEW.aud_source:= app_source;
    IF (TG_OP = 'INSERT')
    THEN
      NEW.aud_when_create:=NEW.aud_when;
      NEW.aud_who_create:=NEW.aud_who;
      NEW.aud_source_create:=NEW.aud_source;

    END IF;

    RETURN NEW;
  END;
$$;

