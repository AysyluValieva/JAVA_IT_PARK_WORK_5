CREATE FUNCTION aud_add_audit()
  RETURNS void
LANGUAGE plpgsql
AS $$
BEGIN
	perform aud_add_audit(ta.*) from aud_tables_to_audit() ta;
    END;
$$;

