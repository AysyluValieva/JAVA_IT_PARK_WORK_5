CREATE FUNCTION update_responsible_on_save_res_role()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
     PERFORM update_responsible(relationships.group_id) from (select * from sr_res_group_relationship where role_id = NEW.id and group_id is not null) as relationships ;
     RETURN NEW;
END;
$$;

