CREATE FUNCTION tambov_loader_ident_download_snils()
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
	_row tambov_loader_ident_download_person%rowtype;
	_i pim_individual%rowtype;
	_msg text[];
begin
	for _row in select * from tambov_loader_ident_download_person where ss is not null and indiv_exists
	loop

		if _row.status <> '0' and _row.source = 'R' then 
			_msg := _msg || 'Обработка записи пропускается'::text || 'Данные переданы в центральный сегмент'::text;
			continue;
		end if;

		select * into _i from pim_individual where id = _row.id_pac;

		if FOUND then 
			select * into _msg from update_snils(_row);
		else 
			_msg := _msg || 'Физ лицо с ID указанным в поле ID_PAC отсутствует в БД'::text || 'Обрабока записи пропускается.'::text;
		end if;

		update tambov_loader_ident_download_person set msg = msg || _msg where id = _row.id;
		_msg := null;
	end loop;
end;
$$;

