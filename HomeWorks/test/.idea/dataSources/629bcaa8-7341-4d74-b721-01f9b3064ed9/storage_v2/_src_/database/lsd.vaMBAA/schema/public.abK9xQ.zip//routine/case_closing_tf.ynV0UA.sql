CREATE FUNCTION case_closing_tf()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE
        closing_step_id integer;
        is_closed_new_result boolean;
BEGIN
        is_closed_new_result = (select is_closed from mc_step_result where id = NEW.result_id);

        if (is_closed_new_result) then
            update mc_case set closing_step_id = NEW.id, close_date = NEW.outcome_date where id = NEW.case_id;
        else
             closing_step_id = (select c.closing_step_id from mc_case c where c.id = NEW.case_id);
             if (NEW.id = closing_step_id) then
                update mc_case set closing_step_id = null, close_date = null where id = NEW.case_id;
             end if;
        end if;
        if(TG_OP = 'UPDATE' and OLD.case_id <> NEW.case_id) then
          with last_step(id, outcome_date, is_closed) as (select ms.id, ms.outcome_date, res.is_closed  from mc_step ms
                    inner join mc_step_result res on res.id = ms.result_id
                    where ms.case_id = OLD.case_id and res.is_closed = true
                    order by ms.admission_date desc, ms.admission_time desc limit 1 )
          update mc_case set closing_step_id = (select id from last_step where is_closed = true),
          close_date = (select close_date from last_step where is_closed = true)
          where id = OLD.case_id;
        end if;
  RETURN NULL;
END;
$$;

