CREATE FUNCTION typing_gen_rendered_services(integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare ttt integer;
begin

with t0 as (
 select c.id case_id, st.id, mr.id mr_id, st.admission_date dt, row_number() over(order by st.admission_date) rn, st.res_group_id rg_id, c.patient_id, c.clinic_id from mc_case c
 join mc_step st on st.case_id = c.id and c.id = $1
 left join md_srv_rendered mr on mr.step_id = st.id
),

t1 as (
select
 case_id, id, dt, rg_id,
 case
  when mr_id is null and rn = 1 then (select s.id from sr_service s join sr_srv_prototype p on p.id = s.prototype_id and p.code = 'СПО1' limit 1)
  when mr_id is null and rn > 1 then (select s.id from sr_service s join sr_srv_prototype p on p.id = s.prototype_id and p.code = 'СПО2' limit 1)
 end srv_id,
 case when mr_id is null then nextval('sr_srv_rendered_seq') end new_r_id, clinic_id, patient_id
from t0
),

t2 as (
 insert into sr_srv_rendered(id, bdate, res_group_id, service_id, quantity, is_rendered, customer_id, org_id)
  select new_r_id, dt, rg_id, srv_id, 1, true, patient_id, clinic_id from t1 where new_r_id is not null returning *
)

insert into md_srv_rendered(step_id, id, case_id)
select t1.id, t1.new_r_id, t1.case_id from t2
join t1 on t2.id = t1.new_r_id
;

update sr_srv_rendered r set funding_id = c.funding_id
from md_srv_rendered mr, mc_case c
where c.id = mr.case_id and mr.id = r.id and c.id = $1;

 return 0;
end;
$$;

