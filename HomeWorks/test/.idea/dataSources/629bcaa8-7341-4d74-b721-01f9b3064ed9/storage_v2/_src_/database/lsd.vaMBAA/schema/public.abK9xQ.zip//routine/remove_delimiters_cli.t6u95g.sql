CREATE FUNCTION remove_delimiters_cli(dbls integer[])
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
--        dbls integer[];
        origin integer;
        i integer;
    begin
--        i=0;
--        for dbls in
--                select array_agg(id) from pim_individual_doc
--                group by (type_id, COALESCE(issuer_id, 0), upper(COALESCE(regexp_replace(series, '-|\s|\/|\\', '','g'), '')|| regexp_replace(number, '-|\s|\/|\\', '','g')))
--                having count(id) > 1
--                loop
         
            select id.id from pim_individual_doc id ,fin_bill_spec_item si
                where id.id in (select unnest(dbls)) and si.doc_id = id.id
            union all
            select id from pim_individual_doc where id in (select unnest(dbls))
                and issuer_id is not null
            union all
            select id from pim_individual_doc where id in (select unnest(dbls))
                and code_id is not null
            union all
            select id from pim_individual_doc where id in (select unnest(dbls))
                and issue_dt is not null
            union all
            select id from pim_individual_doc where id in (select unnest(dbls))
                and expire_dt is not null
            union all
            select id from pim_individual_doc where id in (select unnest(dbls))
                and is_active='t'
            union all
            select id from pim_individual_doc where id in (select unnest(dbls))
                and issuer_text is not null
            union all
            select id from pim_individual_doc where id in (select unnest(dbls))
                and surname is not null
            union all
            select id from pim_individual_doc where id in (select unnest(dbls))
                and name is not null
            union all
            select id from pim_individual_doc where id in (select unnest(dbls))
                and patr_name is not null
            union all
            select id from pim_individual_doc where id in (select unnest(dbls))
                limit 1 into origin;

            insert into dropped_individual_doc_temp (uid, name,surname,patr_name, birth_dt,/*type_name,*/ series, number,issue_id,issue_dt, expire_dt/*, issue_name*/)
            (select ic.code, i.name, i.surname, i.patr_name, i.birth_dt, /*dt.name,*/ id.series, id.number, id.issuer_id, id.issue_dt, id.expire_dt/*, o.short_name*/ from pim_individual_doc id
            left join pim_individual i on (i.id = id.indiv_id)
            left join pim_indiv_code ic on (ic.indiv_id = i.id)
            left join pim_code_type ct on (ct.id = ic.type_id)
            --left join pim_organization o on (o.id = id.issuer_id)
            --left join pim_doc_type dt on (dt.id = id.type_id)
            where id.id != origin and id.id in (select unnest(dbls)) and ct.code = 'UID' limit 1);

            delete from pim_individual_doc where id != origin and id in (select unnest(dbls));

--            i=i+1;
--            if (select(i%1000) = 0) then
--                raise notice 'executed:%', i;
--            end if;
--        end loop;
    end;
$$;

