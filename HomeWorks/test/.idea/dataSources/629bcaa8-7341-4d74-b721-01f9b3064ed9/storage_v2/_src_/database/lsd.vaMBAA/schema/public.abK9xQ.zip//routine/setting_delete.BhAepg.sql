CREATE FUNCTION setting_delete(code character varying)
  RETURNS void
LANGUAGE plpgsql
AS $$
begin

delete from cmn_setting_value where (select cmn_setting.code from cmn_setting where setting_id = cmn_setting.id) = setting_delete.code;
delete from cmn_setting where cmn_setting.code = setting_delete.code;
delete from cmn_domain where cmn_domain.code = setting_delete.code;

end;
$$;

