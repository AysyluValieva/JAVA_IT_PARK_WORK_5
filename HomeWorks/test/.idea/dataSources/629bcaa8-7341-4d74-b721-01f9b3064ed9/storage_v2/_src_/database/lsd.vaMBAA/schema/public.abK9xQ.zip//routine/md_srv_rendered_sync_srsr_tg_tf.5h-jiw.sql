CREATE FUNCTION md_srv_rendered_sync_srsr_tg_tf()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE
  syncRequired boolean := false;
  noChanges boolean;
BEGIN
if TG_OP='INSERT' then
  if NEW.entity_sync_num is null then
    syncRequired := true;--is not caused by sync trigger
  end if;
  --query from sync trigger: interrupt recursion
end if;

if TG_OP='UPDATE' then
  if coalesce(NEW.entity_sync_num, -1) = coalesce(OLD.entity_sync_num, -1) then
    --is not caused by sync trigger
    noChanges := (OLD.is_urgent = NEW.is_urgent or OLD.is_urgent is null and NEW.is_urgent is null)
AND (OLD.is_use_cryogenic = NEW.is_use_cryogenic or OLD.is_use_cryogenic is null and NEW.is_use_cryogenic is null)
AND (OLD.is_use_endoscopic = NEW.is_use_endoscopic or OLD.is_use_endoscopic is null and NEW.is_use_endoscopic is null)
AND (OLD.is_use_laser = NEW.is_use_laser or OLD.is_use_laser is null and NEW.is_use_laser is null)
AND (OLD.anesthesia_type_id = NEW.anesthesia_type_id or OLD.anesthesia_type_id is null and NEW.anesthesia_type_id is null)
AND (OLD.step_id = NEW.step_id or OLD.step_id is null and NEW.step_id is null)
AND (OLD.complication_type_id = NEW.complication_type_id or OLD.complication_type_id is null and NEW.complication_type_id is null)
AND (OLD.diagnosis_id = NEW.diagnosis_id or OLD.diagnosis_id is null and NEW.diagnosis_id is null)
AND (OLD.case_id = NEW.case_id or OLD.case_id is null and NEW.case_id is null)
AND (OLD.referral_id = NEW.referral_id or OLD.referral_id is null and NEW.referral_id is null)
AND (OLD.result_category_id = NEW.result_category_id or OLD.result_category_id is null and NEW.result_category_id is null)
AND (OLD.patient_prescription_id = NEW.patient_prescription_id or OLD.patient_prescription_id is null and NEW.patient_prescription_id is null)
AND (OLD.health_group_id = NEW.health_group_id or OLD.health_group_id is null and NEW.health_group_id is null)
AND (OLD.vmp_type_id = NEW.vmp_type_id or OLD.vmp_type_id is null and NEW.vmp_type_id is null)
AND (OLD.vmp_method_id = NEW.vmp_method_id or OLD.vmp_method_id is null and NEW.vmp_method_id is null)
AND (OLD.anatomic_zone_id = NEW.anatomic_zone_id or OLD.anatomic_zone_id is null and NEW.anatomic_zone_id is null)
AND (OLD.prescription_id = NEW.prescription_id or OLD.prescription_id is null and NEW.prescription_id is null);
    noChanges := coalesce(noChanges, false);
    syncRequired := not noChanges;
  end if;
  --caused by sync trigger: interrupt recursion
end if;

if syncRequired then
UPDATE sr_srv_rendered SET
entity_sync_num = coalesce(entity_sync_num, 0) + 1,--prevent recursion
md_is_urgent = NEW.is_urgent,
md_is_use_cryogenic = NEW.is_use_cryogenic,
md_is_use_endoscopic = NEW.is_use_endoscopic,
md_is_use_laser = NEW.is_use_laser,
md_anesthesia_type_id = NEW.anesthesia_type_id,
md_step_id = NEW.step_id,
md_complication_type_id = NEW.complication_type_id,
md_diagnosis_id = NEW.diagnosis_id,
md_case_id = NEW.case_id,
md_referral_id = NEW.referral_id,
md_result_category_id = NEW.result_category_id,
md_patient_prescription_id = NEW.patient_prescription_id,
md_health_group_id = NEW.health_group_id,
md_vmp_type_id = NEW.vmp_type_id,
md_vmp_method_id = NEW.vmp_method_id,
md_anatomic_zone_id = NEW.anatomic_zone_id,
md_prescription_id = NEW.prescription_id
WHERE id = NEW.id;
end if;

return NEW;
END;
$$;

