CREATE FUNCTION to_numeric(text)
  RETURNS numeric
LANGUAGE plpgsql
AS $$
begin
            if $1 ='' then return null;
            -- end if; if $1 ~ '\D' then return 0;
            else return $1::numeric;
            end if;
            end;
$$;

