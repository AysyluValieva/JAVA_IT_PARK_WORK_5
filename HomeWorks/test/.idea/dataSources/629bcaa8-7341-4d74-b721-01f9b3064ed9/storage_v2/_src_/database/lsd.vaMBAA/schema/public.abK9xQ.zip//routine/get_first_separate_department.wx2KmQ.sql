CREATE FUNCTION get_first_separate_department(department_id integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
BEGIN
            IF department_id IS NULL THEN RETURN NULL;
            ELSEIF  (SELECT is_separate  FROM pim_department  WHERE id=department_id)=TRUE THEN RETURN department_id;
            ELSE RETURN get_first_separate_department((SELECT parent_id FROM pim_department  WHERE id=department_id));
            END IF;
            END;
$$;

