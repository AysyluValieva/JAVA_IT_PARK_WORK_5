CREATE VIEW fin_bill_case_preliminary_cost AS
  SELECT fin_bill_case_preliminary_cost.id,
    fin_bill_case_preliminary_cost.dt,
    fin_bill_case_preliminary_cost.case_id,
    fin_bill_case_preliminary_cost.step_id,
    fin_bill_case_preliminary_cost.srv_rendered_id,
    fin_bill_case_preliminary_cost.service_code,
    fin_bill_case_preliminary_cost.item_type,
    fin_bill_case_preliminary_cost.quantity,
    fin_bill_case_preliminary_cost.position_id,
    fin_bill_case_preliminary_cost.position_code,
    fin_bill_case_preliminary_cost.tariff,
    fin_bill_case_preliminary_cost.tariff_code,
    fin_bill_case_preliminary_cost.tariff_name,
    fin_bill_case_preliminary_cost.price,
    fin_bill_case_preliminary_cost.error_id,
    fin_bill_case_preliminary_cost.region_data
   FROM billing.fin_bill_case_preliminary_cost;

