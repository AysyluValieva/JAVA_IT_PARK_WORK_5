CREATE FUNCTION res_group_system_copy(integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
DECLARE
    res_group_source sr_res_group%ROWTYPE;
    relationship_source sr_res_group_relationship%ROWTYPE;
    service_source sr_res_group_service%ROWTYPE;
    service_fund_type_source sr_resgroup_srv_fundsrctype%ROWTYPE;
    system_copy_id integer;

BEGIN

    select * into res_group_source from sr_res_group where id = $1;

    if (res_group_source is  null) then
	    return null;
    end if;

    insert into sr_res_group (id, is_system, bdate, edate, name, org_id, department_id, label_id)
			values(NEXTVAL('sr_res_group_seq'), true, res_group_source.bdate, res_group_source.edate, res_group_source.name, res_group_source.org_id, res_group_source.department_id, res_group_source.label_id);

    select CURRVAL('sr_res_group_seq') into system_copy_id;

    --copy sr_res_group_relationship
    FOR relationship_source IN SELECT * FROM sr_res_group_relationship
    WHERE group_id = $1
    LOOP
        insert into sr_res_group_relationship (id, resource_id, group_id, role_id)
         values(NEXTVAL('sr_res_group_relationship_seq'), relationship_source.resource_id, system_copy_id, relationship_source.role_id);
    END LOOP;

    --copy sr_res_group_service
    FOR service_source IN SELECT * FROM sr_res_group_service
    WHERE group_id = $1
    LOOP
        insert into sr_res_group_service (id, bdatetime, edatetime, power, group_id, default_service, referral_required, moderation_required, patient_multiple_appointment_per_day, srv_type_id)
         values(NEXTVAL('sr_res_group_service_id_seq'), service_source.bdatetime, service_source.edatetime,  service_source.power, system_copy_id,
			          service_source.default_service, service_source.referral_required, service_source.moderation_required, service_source.patient_multiple_appointment_per_day, service_source.srv_type_id);

	      FOR service_fund_type_source IN SELECT * FROM sr_resgroup_srv_fundsrctype
        WHERE resgroup_service_id = service_source.id
        LOOP
            insert into sr_resgroup_srv_fundsrctype (id, resgroup_service_id, fundsource_type_id)
              values(NEXTVAL('sr_resgroup_srv_fundsrctype_seq'), CURRVAL('sr_res_group_service_id_seq'), service_fund_type_source.fundsource_type_id);
        END LOOP;

    END LOOP;
    RETURN system_copy_id;
END;
$$;

