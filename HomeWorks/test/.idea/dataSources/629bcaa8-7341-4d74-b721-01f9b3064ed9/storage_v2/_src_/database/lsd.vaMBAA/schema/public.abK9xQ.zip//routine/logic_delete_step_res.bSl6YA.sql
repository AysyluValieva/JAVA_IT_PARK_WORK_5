CREATE FUNCTION logic_delete_step_res(i integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
DECLARE
            d date;
            BEGIN
                d = now();
                IF ((select count(*)  from mc_step where result_id = i) > 0) THEN
                        update mc_step_result set to_dt = d where id = i;
                        update mc_step_result_to_care_regimen set to_dt = d where step_result_id = i;
                    ELSE
                        delete from mc_step_result where id = i;
                END IF;
                return i;
            END
$$;

