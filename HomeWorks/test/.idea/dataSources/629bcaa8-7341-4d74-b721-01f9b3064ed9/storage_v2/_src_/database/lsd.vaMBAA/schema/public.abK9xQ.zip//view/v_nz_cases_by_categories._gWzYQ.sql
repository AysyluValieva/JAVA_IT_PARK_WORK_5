CREATE VIEW v_nz_cases_by_categories AS
  SELECT mv_nz_cases_by_categories.clinic_id,
    mv_nz_cases_by_categories.care_regimen_id,
    mv_nz_cases_by_categories.funding_id,
    mv_nz_cases_by_categories.soc_group_id,
    mv_nz_cases_by_categories.gender_id,
    mv_nz_cases_by_categories.benefit_type_id,
    mv_nz_cases_by_categories.benefit_def_id,
    mv_nz_cases_by_categories.disability_type_id,
    mv_nz_cases_by_categories.democube_days_id,
    mv_nz_cases_by_categories.smo_issuer_id,
    mv_nz_cases_by_categories.age_category_2_id,
    mv_nz_cases_by_categories.age_category_3_id,
    mv_nz_cases_by_categories.open_case,
    mv_nz_cases_by_categories.close_case,
    mv_nz_cases_by_categories.death_case
   FROM mv_nz_cases_by_categories;

