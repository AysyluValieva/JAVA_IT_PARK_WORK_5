CREATE MATERIALIZED VIEW cube_days_simple AS SELECT cube_days.id,
    cube_days.calendar_date,
    cube_days.year_,
    cube_days.month_of_year,
    cube_days.name_month_of_year
   FROM cube_days
  WHERE (cube_days.day_of_month = 1);

CREATE INDEX s_id_inx
  ON cube_days_simple (id);

CREATE INDEX s_date_inx
  ON cube_days_simple (calendar_date);

CREATE INDEX s_year_inx
  ON cube_days_simple (year_);

CREATE INDEX s_month_inx
  ON cube_days_simple (month_of_year);

