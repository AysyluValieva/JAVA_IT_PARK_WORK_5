CREATE VIEW v_cube_days AS
  SELECT cube_days.id,
    cube_days.calendar_date,
    cube_days.year_,
    cube_days.quarter_of_year,
    cube_days.month_of_year,
    cube_days.week_of_year,
    cube_days.day_of_month,
    cube_days.day_of_week,
    cube_days.day_of_year,
    cube_days.name_quarter_of_year,
    cube_days.name_month_of_year,
    cube_days.name_day_of_week
   FROM cube_days;

