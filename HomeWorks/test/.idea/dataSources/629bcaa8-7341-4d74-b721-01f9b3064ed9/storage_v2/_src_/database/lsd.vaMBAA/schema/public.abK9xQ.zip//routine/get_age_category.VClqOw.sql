CREATE FUNCTION get_age_category(birth_dt date, open_dt date, gender integer DEFAULT 3)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
  age integer;
  gender_code character varying;
begin
  if birth_dt IS NULL or open_dt IS NULL then return -1;
  end if;
  age = DATE_PART('year', open_dt) - DATE_PART('year', birth_dt) -
  (CASE TO_CHAR(open_dt, 'MMDD') < TO_CHAR(birth_dt, 'MMDD') WHEN TRUE THEN 1 ELSE 0 END);
  gender_code = (select code from pim_gender where id = gender);
  if age < 14 then return 1;
  else if age >= 15 and age <= 18 then return 2;
  else if age >= 55 and gender_code = 'FEMALE' then return 4;
  else if age >= 60 and gender_code = 'MALE' then return 4;
  else if age > 18 then return 3;
  else return 0;
  end if;
  end if;
  end if;
  end if;
  End if;
end;
$$;

