CREATE FUNCTION fun_del_indiv(_id integer, _flag integer)
  RETURNS text
LANGUAGE plpgsql
AS $$
declare 
		_srv_arr integer[];
begin

if (_flag is null) then return 'Необходимо указать тип: 1-физ.лицо, 2-пациент, 3-сотрудник'; end if;
if (_id is null)   then return 'Необходимо указать ID'; end if;

_srv_arr = ARRAY(select fbsi.service_id  from mc_case c 
join mc_step s on s.case_id=c.id
join md_srv_rendered msr on msr.step_id=s.id
join fin_bill_spec_item fbsi on fbsi.service_id=msr.id
where c.patient_id=_id) ;

IF ARRAY_LENGTH(_srv_arr, 1) IS NOT NULL THEN return 'У данного физ.лица имеются услуги, которые попали в счет';
else 
	if _flag=1 then 
	delete from md_ambulance_call where registrator_id=_id;
				delete from pci_patient_reg where patient_id=_id;
				delete from pim_party_addr_to_addr_type where party_address_id in (select id from pim_party_address where party_id=_id); 
		delete from pim_party_address where party_id=_id;
		delete from pim_party_role_to_party where party_id=_id;
				update sec.demo set patient_id=null where patient_id=_id;
				update mc_attendant set individual_id=null where individual_id=_id;
				update disp.md_dispr set indiv_id=null where indiv_id=_id;
				update disp.md_dispr_research set indiv_id=null where indiv_id=_id;
				update disp.md_dispr_risk_factor set indiv_id=null where indiv_id=_id;
				update disp.md_event_service_patient set indiv_id=null where indiv_id=_id;
				update migr.md_migr_card set indiv_id=null where indiv_id=_id;
				delete from migr.md_migr_patient where id=_id;
				update pci_benefit_request set patient_id=null where patient_id=_id;
						delete from fin_contract_to_patient where patient_id=_id;
						update fin_patient_contract set patient_id=null where patient_id=_id;
						delete from hospital.prescription where patient_id=_id;
						update inventory.store_opr_jur set patient_id=null where patient_id=_id;
				delete from pci_patient where id=_id;
				delete from pim_citizenship where individual_id=_id;
						update fin_contractor set employee_id=null where employee_id=_id;
								update inv_opr set authorization_id=null where authorization_id in (select id from inv_authorization where employee_id=_id);
						delete from inv_authorization where employee_id=_id;
								update inv_opr set base_opr_id=null where base_opr_id in (select id from inv_opr where init_employee_id=_id);
										update inv_remains_h set prev_id=null where prev_id in (select id from inv_remains_h where opr_id in (select id from inv_opr where init_employee_id=_id));
								delete from inv_remains_h where opr_id in (select id from inv_opr where init_employee_id=_id);
										delete from mc_inv_spec_consumable where inv_opr_srv_id in (select id from mc_inv_opr_srv where opr_id in (select id from inv_opr where init_employee_id=_id));
								delete from mc_inv_opr_srv where opr_id in (select id from inv_opr where init_employee_id=_id);
								delete from md_sicklist_opr where opr_id in (select id from inv_opr where init_employee_id=_id);
						delete from inv_opr where init_employee_id=_id;
						delete from md_employee_resource where employee_id=_id;
						delete from md_quotum_refer_employee where employee_id=_id;
						update pci_patient set empl_state_death_id=null where empl_state_death_id=_id;
						update pci_patient_job set employee_id=null where employee_id=_id;
				delete from pim_employee where individual_id=_id;
				delete from pim_indiv_agreement where indiv_id=_id;
						update pim_individual_doc set code_id=null where code_id in (select id from pim_indiv_code where indiv_id=_id);
				delete from pim_indiv_code where indiv_id=_id;
				delete from pim_indiv_contact where indiv_id=_id;
						update qos_examination_case set document_id=null  where document_id in (select id from pim_individual_doc where indiv_id=_id);
				delete from pim_individual_doc where indiv_id=_id;
				delete from pim_indiv_marital_status where individual_id=_id;
				delete from pim_pseudonym where individual_id=_id;
				delete from pim_workplace where indiv_id=_id;
		delete from pim_individual where id=_id;
	delete from pim_party where id=_id;
	RETURN 'Физ.лицо удален';

	else 
			if _flag=2 then 
						delete from hsp_reservation h
where exists(select 1 from md_referral m  where m.id=h.referral_id and m.patient_id = _id);
						delete from fin_contract_to_patient where patient_id=_id;
						update fin_patient_contract set patient_id=null where patient_id=_id;
						delete from hospital.prescription where patient_id=_id;
						update inventory.store_opr_jur set patient_id=null where patient_id=_id;
			delete from pci_patient where id=_id;
			RETURN 'Пациент удален';
			else 
					if _flag=3 then
							update fin_contractor set employee_id=null where employee_id=_id;
									update inv_opr set authorization_id=null where authorization_id in (select id from inv_authorization where employee_id=_id);
							delete from inv_authorization where employee_id=_id;
									update inv_opr set base_opr_id=null where base_opr_id in (select id from inv_opr where init_employee_id=_id);
											update inv_remains_h set prev_id=null where prev_id in (select id from inv_remains_h where opr_id in (select id from inv_opr where init_employee_id=_id));
									delete from inv_remains_h where opr_id in (select id from inv_opr where init_employee_id=_id);
											delete from mc_inv_spec_consumable where inv_opr_srv_id in (select id from mc_inv_opr_srv where opr_id in (select id from inv_opr where init_employee_id=_id));
									delete from mc_inv_opr_srv where opr_id in (select id from inv_opr where init_employee_id=_id);
									delete from md_sicklist_opr where opr_id in (select id from inv_opr where init_employee_id=_id);
							delete from inv_opr where init_employee_id=_id;
							delete from md_employee_resource where employee_id=_id;
							delete from md_quotum_refer_employee where employee_id=_id;
							update pci_patient set empl_state_death_id=null where empl_state_death_id=_id;
							update pci_patient_job set employee_id=null where employee_id=_id;
					delete from pim_employee where individual_id=_id;
					RETURN 'Сотрудник удален';
					end if;
			end if;
	end if;
end if ;
end;
$$;

