CREATE VIEW fin_bill_policy AS
  SELECT fin_bill_policy.bill_id,
    fin_bill_policy.id,
    fin_bill_policy.item_id_arr,
    fin_bill_policy.type,
    fin_bill_policy.series,
    fin_bill_policy.number,
    fin_bill_policy.issuer_id,
    fin_bill_policy.issuer_short_name,
    fin_bill_policy.issuer_code_oms,
    fin_bill_policy.issuer_ogrn,
    fin_bill_policy.issuer_okato,
    fin_bill_policy.issue_dt,
    fin_bill_policy.belonging_type,
    fin_bill_policy.issuer_work_territory_id,
    fin_bill_policy.region_data,
    fin_bill_policy.customer_id
   FROM billing.fin_bill_policy;

