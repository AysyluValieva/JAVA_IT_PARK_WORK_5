CREATE FUNCTION sync_data_f()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE
v_user_id         sec_user.id%type;
v_user_login      sec_user.login%type;
v_tab_id          i_sync_tab.id%type;
c_source_template text := '.KIR_RMIS.1.';
v_is_exists boolean := false;
v_obj_id          i_sync_ver_map.obj_id%type;
v_entity_ver_id   i_sync_entity_ver.id%type;
v_is_update       boolean := false;
v_main_tab_id     i_sync_tab.id%type;
v_fk_col          i_sync_map.fk_col%type;
v_entity_id       i_sync_ext_entity.id%type;
v_euid_entity_id  i_sync_ext_entity.euid_entity_id%type;
v_entity_euid     i_sync_entity_ver.euid%type;
v_main_obj_id     i_sync_ver_map.obj_id%type;
v_main_map_found  boolean := true;
v_source          i_sync_entity_ver.source%type;
v_cust_name       text;
v_expr            i_sync_tab.expr%type;
BEGIN
return new;
END;
$$;

