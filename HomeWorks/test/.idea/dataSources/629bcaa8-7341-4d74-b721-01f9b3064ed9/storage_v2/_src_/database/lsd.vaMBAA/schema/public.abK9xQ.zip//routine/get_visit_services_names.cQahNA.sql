CREATE FUNCTION get_visit_services_names(visit_id integer)
  RETURNS text
LANGUAGE plpgsql
AS $$
declare
  names text := '';
  visit_service_name text := '';
begin
  for visit_service_name in(          

	select coalesce(ss.name)
	       from sr_service ss join sr_srv_rendered ssr on ss.id=ssr.service_id
	                          inner join md_srv_rendered msr on ssr.id=msr.id
	       where msr.step_id = $1
	)	                                 

    loop
       if names = '' then
          names := visit_service_name;
       elseif (visit_service_name is not null) then
          names := names || ', ' || visit_service_name;
       end if;
    end loop;
  return names;
end;
$$;

