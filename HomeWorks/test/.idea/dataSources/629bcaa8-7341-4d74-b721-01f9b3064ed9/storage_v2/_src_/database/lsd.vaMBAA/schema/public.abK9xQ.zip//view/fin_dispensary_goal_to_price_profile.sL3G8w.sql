CREATE VIEW fin_dispensary_goal_to_price_profile AS
  SELECT dispensary_goal_to_price_profile.init_goal_code,
    dispensary_goal_to_price_profile.init_goal_name,
    dispensary_goal_to_price_profile.code_usl,
    dispensary_goal_to_price_profile.age_from,
    dispensary_goal_to_price_profile.age_to,
    dispensary_goal_to_price_profile.gender_id,
    dispensary_goal_to_price_profile.division,
    dispensary_goal_to_price_profile.name,
    dispensary_goal_to_price_profile.age_note,
    dispensary_goal_to_price_profile.ext_age_from,
    dispensary_goal_to_price_profile.ext_age_to
   FROM billing.dispensary_goal_to_price_profile;

