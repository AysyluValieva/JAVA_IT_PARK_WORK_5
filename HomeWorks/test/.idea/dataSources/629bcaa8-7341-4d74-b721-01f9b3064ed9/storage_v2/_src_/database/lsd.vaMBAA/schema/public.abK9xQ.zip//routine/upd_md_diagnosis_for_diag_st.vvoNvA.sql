CREATE FUNCTION upd_md_diagnosis_for_diag_st()
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
row record;
begin
for row in
select s1.id,s2.id parent_id,s2.level from md_diagnosis s1
left join md_diagnosis s2 on substring(s1.code,1,3) = substring(s2.code,1,3)
where (s1.code similar to '\w{1}\d{2}.\d{1,2}' and s2.code similar to '\w{1}\d{2}')
or (s1.code similar to '\w{1}\d{2}.\d{1,2}\W' and s2.code similar to '\w{1}\d{2}\W') loop
update md_diagnosis set parent_id=row.parent_id,level=row.level+1 where id=row.id;
end loop;
end;
$$;

