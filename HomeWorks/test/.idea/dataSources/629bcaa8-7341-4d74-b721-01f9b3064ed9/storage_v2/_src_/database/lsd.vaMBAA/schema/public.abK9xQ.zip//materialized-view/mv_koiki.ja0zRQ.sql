CREATE MATERIALIZED VIEW mv_koiki AS SELECT w.step_id,
    w.bed_id,
    w.room_id,
    w.bed_profile_id
   FROM ( SELECT s.id AS step_id,
            b.id AS bed_id,
            b.room_id,
            b.bed_profile_id,
            row_number() OVER (PARTITION BY s.id ORDER BY rr.id) AS rn
           FROM ((((mc_step s
             JOIN sr_res_group g ON (((s.res_group_id = g.id) AND (date_part('year'::text, s.admission_date) >= (2013)::double precision))))
             JOIN sr_res_group_relationship rr ON ((rr.group_id = g.id)))
             JOIN md_bed_resource br ON ((rr.resource_id = br.id)))
             JOIN md_bed b ON ((br.bed_id = b.id)))) w
  WHERE (w.rn = 1);

CREATE INDEX mv_koiki_step_id_inx
  ON mv_koiki (step_id);

CREATE INDEX mv_koiki_bed_id_inx
  ON mv_koiki (bed_id);

CREATE INDEX mv_koiki_room_id_inx
  ON mv_koiki (room_id);

CREATE INDEX mv_koiki_bed_profile_id_inx
  ON mv_koiki (bed_profile_id);

