CREATE FUNCTION add_prescription_execution()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE
    percent_execution_var integer;
BEGIN
    IF    TG_OP = 'INSERT' THEN
        IF (NEW.md_patient_prescription_id is not null) THEN
            percent_execution_var = prescribed_services_execution(NEW.md_patient_prescription_id);
            IF(percent_execution_var is null) THEN
               percent_execution_var := 0;
            END IF;
            UPDATE md_patient_prescription SET percent_execution = percent_execution_var WHERE id = NEW.md_patient_prescription_id;
        END IF;
        RETURN NEW;
    ELSIF TG_OP = 'UPDATE' THEN
       IF (NEW.md_patient_prescription_id is not null) THEN
            percent_execution_var := prescribed_services_execution(NEW.md_patient_prescription_id);
            IF(percent_execution_var is null) THEN
               percent_execution_var := 0;
            END IF;
            UPDATE md_patient_prescription SET percent_execution = percent_execution_var WHERE id = NEW.md_patient_prescription_id;
        END IF;
        RETURN NEW;
    ELSIF TG_OP = 'DELETE' THEN
        IF (OLD.md_patient_prescription_id is not null) THEN
            percent_execution_var := prescribed_services_execution(OLD.md_patient_prescription_id);
            IF(percent_execution_var is null) THEN
               percent_execution_var := 0;
            END IF;
            UPDATE md_patient_prescription SET percent_execution = percent_execution_var WHERE id = OLD.md_patient_prescription_id;
        END IF;
        RETURN OLD;
    END IF;
END;
$$;

