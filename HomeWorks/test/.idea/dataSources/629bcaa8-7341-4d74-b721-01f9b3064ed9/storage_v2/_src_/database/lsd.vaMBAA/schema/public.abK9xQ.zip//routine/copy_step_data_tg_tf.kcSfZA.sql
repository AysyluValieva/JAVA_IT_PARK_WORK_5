CREATE FUNCTION copy_step_data_tg_tf()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE
                          _app_code TEXT;
                            BEGIN
                        SELECT current_setting('app.source') INTO _app_code;

                        IF ('typing2' <> _app_code AND 'n2o'<>_app_code) THEN
                            _app_code := 'lsd';
                        END IF;

                        IF(SELECT NOT EXISTS(SELECT 1 FROM cmn_app_using_mc_step_only WHERE cmn_app_using_mc_step_only.app_code = _app_code) ) THEN
                            RETURN NEW;
                        END IF;

                        IF(TG_OP = 'INSERT') THEN
                          IF(NEW._case_mode_id = 1) THEN
                            INSERT INTO plc_visit (id, goal_id, initiator_id, is_needed, is_sanitized, is_viewed, place_id, type_id, appointment_id, planned_date)
                            VALUES(NEW.id, NEW.plc_goal_id, NEW.plc_initiator_id, NEW.plc_is_needed, NEW.plc_is_sanitized, NEW.plc_is_viewed, NEW.plc_place_id, NEW.plc_type_id, NEW.plc_appointment_id, NEW.plc_planned_date);
                          ELSEIF (NEW._case_mode_id = 2) THEN
                            INSERT INTO hsp_record(id, bed_days_amount, bed_profile_id, complexity_level_id, days_comp_algo_id, department_id, funding_id, is_admission_day_counts, is_diag_not_eq, is_set_diagnosis, issue_planned_date, mes_id, missed_days_amount, plan_department_id, previous_id, refusal_employee_id)
                            VALUES (NEW.id, NEW.hsp_bed_days_amount, NEW.hsp_bed_profile_id, NEW.hsp_complexity_level_id, NEW.hsp_days_comp_algo_id, NEW.hsp_department_id, NEW.hsp_funding_id, NEW.hsp_is_admission_day_counts, NEW.hsp_is_diag_not_eq, NEW.hsp_is_set_diagnosis, NEW.hsp_issue_planned_date, NEW.hsp_mes_id, NEW.hsp_missed_days_amount, NEW.hsp_plan_department_id, NEW.hsp_previous_id, NEW.hsp_refusal_employee_id);
                          END IF;
                        ELSEIF (TG_OP = 'UPDATE') THEN
                          IF(NEW._case_mode_id = 1) THEN
                            UPDATE plc_visit SET
                            goal_id = NEW.plc_goal_id,
                            initiator_id = NEW.plc_initiator_id,
                            is_needed = NEW.plc_is_needed,
                            is_sanitized = NEW.plc_is_sanitized,
                            is_viewed = NEW.plc_is_viewed,
                            place_id = NEW.plc_place_id,
                            type_id = NEW.plc_type_id,
                            appointment_id = NEW.plc_appointment_id,
                            planned_date = NEW.plc_planned_date
                            WHERE id = NEW.id;
                          ELSEIF (NEW._case_mode_id = 2) THEN
                            UPDATE hsp_record SET
                            bed_days_amount =NEW.hsp_bed_days_amount,
                            bed_profile_id = NEW.hsp_bed_profile_id,
                            complexity_level_id = NEW.hsp_complexity_level_id,
                            days_comp_algo_id = NEW.hsp_days_comp_algo_id,
                            department_id = NEW.hsp_department_id,
                            funding_id = NEW.hsp_funding_id,
                            is_admission_day_counts = NEW.hsp_is_admission_day_counts,
                            is_diag_not_eq = NEW.hsp_is_diag_not_eq,
                            is_set_diagnosis = NEW.hsp_is_set_diagnosis,
                            issue_planned_date = NEW.hsp_issue_planned_date,
                            mes_id = NEW.hsp_mes_id,
                            missed_days_amount = NEW.hsp_missed_days_amount,
                            plan_department_id = NEW.hsp_plan_department_id,
                            previous_id = NEW.hsp_previous_id,
                            refusal_employee_id = NEW.hsp_refusal_employee_id
                            WHERE id = NEW.id;
                          END IF;
                        END IF;

                            RETURN NEW;
                            END;
$$;

