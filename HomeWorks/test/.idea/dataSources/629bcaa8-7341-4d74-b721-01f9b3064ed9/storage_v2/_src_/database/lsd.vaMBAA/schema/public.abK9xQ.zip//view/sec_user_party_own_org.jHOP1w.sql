CREATE VIEW sec_user_party_own_org AS
  SELECT row_number() OVER () AS id,
    ownorgs.party_user_id,
    ownorgs.organization_id
   FROM ( SELECT up.id AS party_user_id,
            e.organization_id
           FROM ((((pim_employee e
             JOIN pim_employee_position etp ON ((etp.employee_id = e.id)))
             JOIN pim_position p ON ((p.id = etp.position_id)))
             JOIN sec_user_party up ON ((up.party_id = e.individual_id)))
             JOIN pim_party pp ON ((up.party_id = pp.id)))
          WHERE (((etp.end_date IS NULL) OR (etp.end_date > ('now'::text)::date)) AND (p.organization_id = e.organization_id) AND (pp.type_id = 1))
          GROUP BY up.id, e.organization_id
        UNION ALL
         SELECT up.id AS party_user_id,
            pp.id AS organization_id
           FROM (sec_user_party up
             JOIN pim_party pp ON ((up.party_id = pp.id)))
          WHERE (pp.type_id = 2)) ownorgs;

