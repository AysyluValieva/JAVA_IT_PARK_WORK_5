CREATE FUNCTION mdm_table__get_last_refbook_version_id(oid character varying)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
  obj text;
  sour integer;
  ref_id integer;
  act_ver integer;
begin

select substring(oid from '\d{1,}$') into obj;
select id into sour from mdm_refbook_source where object_id=left(oid,char_length(oid)-char_length(obj)-1);
select id into ref_id from mdm_refbook where object_id=obj and source_id=sour;
select id into act_ver from mdm_refbook_version where refbook_id=ref_id order by date desc,id desc limit 1;

return act_ver;

end;
$$;

