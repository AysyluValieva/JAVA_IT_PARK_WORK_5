CREATE FUNCTION adr__element_is_city_contains(id integer)
  RETURNS boolean
LANGUAGE plpgsql
AS $$
declare
            element_id integer := id;
            element record;
            city boolean;
            begin

            select aed.is_city into city from address_element_data aed where aed.id = element_id;
            if city is not null then return city; end if;

            for element in
            select aed.id as element_id, t.short_name as type_sname
            from address_element_data aed, address_element ae, address_element_type t
            where ae.id = aed.id
            and aed.path @> (select path from address_element_data aed2 where aed2.id = element_id)
            and ae.type_id = t.id
            loop

            if element.type_sname = 'г' or element.type_sname = 'городок' then
            return true;
            end if;

            end loop;

            return false;

            end;
$$;

