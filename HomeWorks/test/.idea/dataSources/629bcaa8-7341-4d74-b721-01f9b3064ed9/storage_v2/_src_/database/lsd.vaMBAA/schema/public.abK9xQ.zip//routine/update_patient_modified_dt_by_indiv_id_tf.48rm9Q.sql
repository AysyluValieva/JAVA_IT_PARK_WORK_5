CREATE FUNCTION update_patient_modified_dt_by_indiv_id_tf()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
                    IF ( TG_OP = 'INSERT' )
                    THEN
                        UPDATE pci_patient set _modified_dt = now() where id = NEW.indiv_id;
                        RETURN NEW;
                    END IF;

                    IF ( TG_OP = 'UPDATE' )
                    THEN
                        IF (NEW.indiv_id <> OLD.indiv_id)
                        THEN
                          UPDATE pci_patient set _modified_dt = now() where id = NEW.indiv_id;
                          UPDATE pci_patient set _modified_dt = now() where id = OLD.indiv_id;
                        ELSE
                          UPDATE pci_patient set _modified_dt = now() where id = NEW.indiv_id;
                        END IF;
                        RETURN NEW;
                    END IF;

                    IF ( TG_OP = 'DELETE' )
                    THEN
                        UPDATE pci_patient set _modified_dt = now() where id = OLD.indiv_id;
                        RETURN OLD;
                    END IF;
                    RETURN NULL;
                  END;
$$;

