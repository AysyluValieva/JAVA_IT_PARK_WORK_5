CREATE VIEW inv_remains_h_export_v AS
  SELECT rh.remains_id,
    re.sn_id,
    rh.val,
    rh.amount,
    re.fin_type_id,
    re.contractor_id,
    rh.opr_id,
    rh.dt,
    rh.d_val,
    rh.d_amount
   FROM inv_remains_export_v re,
    inv_remains_h rh
  WHERE (rh.remains_id = re.remains_id);

