CREATE FUNCTION adr_get_element_as_text_new(p1_element_id integer, p2_prm_text text, OUT addr_arr text[], OUT addr_result text)
  RETURNS record
STABLE
STRICT
LANGUAGE plpgsql
AS $$
DECLARE
    _r RECORD;
    _address HSTORE := '';
    _prm TEXT;
    _disp_type TEXT;
    _side_type TEXT;
    _pre_result TEXT[];
BEGIN
    --version: 2015-06-16
    FOR _r IN
        SELECT 
            hstore 
            (
                a.level_id::TEXT, 
                concat_ws ('][', a.name, lower (t.name), lower (t.short_name) || CASE WHEN lower (t.name) = lower (t.short_name) THEN '' ELSE '.' END)
            ) AS adr
        FROM 
            adr_get_hierarchy_array (p1_element_id) AS h, address_element AS a, address_element_type AS t
        WHERE
            a.type_id = t.id AND a.id = ANY (h.hierarchy_array)
        ORDER BY a.level_id
    LOOP
        _address := _address || _r.adr;
    END LOOP;
    
    FOREACH _prm IN ARRAY string_to_array (trim (p2_prm_text, ')('), ')(')
    LOOP
        _pre_result := string_to_array (_address -> (string_to_array (_prm, ','))[1], '][');
        IF
            _pre_result IS NOT NULL
        THEN
            _disp_type := (string_to_array (_prm, ','))[2];
            _side_type := (string_to_array (_prm, ','))[3];
            IF
                _disp_type = 'n'
            THEN
                addr_arr := addr_arr || _pre_result[1];
            ELSIF
                _disp_type = 'f'
            THEN
                IF
                    _side_type = 'f'
                THEN
                    addr_arr := addr_arr || concat (_pre_result[2], ' ', _pre_result[1]);
                ELSIF
                    _side_type = 'b'
                THEN
                    addr_arr := addr_arr || concat (_pre_result[1], ' ', _pre_result[2]);
                END IF;
            ELSIF
                _disp_type = 's'
            THEN
                IF
                    _side_type = 'f'
                THEN
                    addr_arr := addr_arr || concat (_pre_result[3], ' ', _pre_result[1]);
                ELSIF
                    _side_type = 'b'
                THEN
                    addr_arr := addr_arr || concat (_pre_result[1], ' ', _pre_result[3]);
                END IF;
            END IF;
        ELSE
            addr_arr := addr_arr || NULL::TEXT;
        END IF;
    END LOOP;
    
    addr_result := array_to_string (addr_arr, ', ');
END;
$$;

