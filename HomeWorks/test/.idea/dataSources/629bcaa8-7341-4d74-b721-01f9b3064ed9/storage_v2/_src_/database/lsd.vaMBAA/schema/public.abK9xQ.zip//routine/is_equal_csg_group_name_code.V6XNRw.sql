CREATE FUNCTION is_equal_csg_group_name_code(groupid integer, str character varying)
  RETURNS boolean
LANGUAGE plpgsql
AS $$
declare
    count integer = null;
begin
    select count(t) into count from
    (
        WITH RECURSIVE temp1 (id, parent_id, code, name, PATH, LEVEL, cycle ) AS (
            select
                cg.id,
                cg.parent_id,
                CAST(cg.name as VARCHAR (250)),
                CAST(cg.code as VARCHAR (250)),
                array[cg.id],
                1,
                FALSE
            FROM md_csg_group cg
        union all
            select
                cg2.id,
                cg2.parent_id,
                CAST(temp1.code || ' ' || cg2.code as VARCHAR (250)),
                CAST(temp1.name || ' ' || cg2.name as VARCHAR (250)),
                temp1.PATH || cg2.id,
                LEVEL + 1 ,
                cg2.id = any (temp1.PATH)
            from md_csg_group cg2
            inner join temp1 on ( temp1.id= cg2.parent_id) AND NOT CYCLE
        )

        select code, name from temp1 where id = groupId and level = (select max(level) from temp1 where id = groupId)
        and (upper(code) like '%'||upper(str)||'%' or upper(name) like '%'||upper(str)||'%')
        ) t;

    if count = 1 then return true;
    end if;
return false;
end;
$$;

