CREATE FUNCTION insert_mc_case_type_init_goal()
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
  goalId integer;
  typeId integer;
BEGIN
  FOR typeId IN
   SELECT t.id FROM  mc_case_type t
   loop
      FOR goalId IN
        SELECT cg.id FROM mc_case_init_goal cg
        loop
           INSERT INTO mc_case_type_init_goal VALUES (nextval('mc_case_type_init_goal_id_seq'),typeId,goalId,false);
        END loop;
  END loop;
END;
$$;

