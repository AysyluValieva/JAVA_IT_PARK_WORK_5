CREATE FUNCTION extract_age_particularly(birth_dt date)
  RETURNS character varying
LANGUAGE plpgsql
AS $$
BEGIN
				  IF extract(YEAR FROM age(now(), birth_dt)) >= 1
				  THEN
					RETURN EXTRACT(YEAR FROM age(now(), birth_dt));
				  ELSEIF extract(MONTH FROM age(now(), birth_dt)) >= 1
					THEN
					  RETURN EXTRACT(MONTH FROM age(now(), birth_dt)) || ' мес.';
				  ELSE RETURN EXTRACT(DAY FROM age(now(), birth_dt)) || ' дн.';
				  END IF;
				END;

$$;

