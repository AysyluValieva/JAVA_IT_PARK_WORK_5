CREATE FUNCTION get_table_bill_process_duration(p1_check_date date)
  RETURNS TABLE(hour integer, cnt bigint, avg_time integer)
STABLE
STRICT
LANGUAGE plpgsql
AS $$
BEGIN
    RETURN QUERY
        WITH timetable AS (SELECT generate_series (0, 23) AS hour),
        stat AS 
        (
            SELECT
                date_part ('hour', b.date)::INTEGER AS hour, count (b.id) AS cnt, extract (epoch from avg (age (e.date, b.date)))::INTEGER AS avg_time
            FROM
                fin_bill_status_log AS b, 
                LATERAL 
                (
                    SELECT 
                        date
                    FROM 
                        fin_bill_status_log 
                    WHERE 
                        status_id = 1 AND bill_id = b.bill_id AND user_id = b.user_id AND date > b.date
                    ORDER BY age (date, b.date)
                    LIMIT 1
                ) AS e
            WHERE
                b.status_id = 7 AND b.date <@ tsrange (p1_check_date, p1_check_date + 1, '[]') 
            GROUP BY 1
        )
        SELECT
            t.hour, coalesce (s.cnt, 0), coalesce (s.avg_time, 0)
        FROM
            timetable AS t NATURAL LEFT JOIN stat AS s
    ;
END;
$$;

