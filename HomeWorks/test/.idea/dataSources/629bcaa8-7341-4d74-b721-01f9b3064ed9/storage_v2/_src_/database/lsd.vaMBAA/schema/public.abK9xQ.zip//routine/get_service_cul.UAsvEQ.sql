CREATE FUNCTION get_service_cul(service_id_val integer, with_default boolean)
  RETURNS numeric
LANGUAGE plpgsql
AS $$
DECLARE
	    culVal numeric;

    BEGIN
      IF(with_default) THEN
        SELECT sum(coalesce(cul, 0)) from sr_service  into culVal where (id in(select service_id from sr_srv_composition where complex_id  = $1 and (is_required = true or is_default = true)) or id = $1) and (cul is not null or is_actual_cul = true);
      ELSE
        SELECT sum(coalesce(cul, 0)) from sr_service  into culVal where (id in(select service_id from sr_srv_composition where complex_id  = $1 and is_required = true) or id = $1) and (cul is not null or is_actual_cul = true);
      END IF;
      return culVal;

    END;
$$;

