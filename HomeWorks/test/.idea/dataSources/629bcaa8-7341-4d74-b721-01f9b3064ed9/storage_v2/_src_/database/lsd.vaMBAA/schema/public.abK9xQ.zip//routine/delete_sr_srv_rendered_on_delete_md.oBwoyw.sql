CREATE FUNCTION delete_sr_srv_rendered_on_delete_md()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
                IF TG_OP = 'DELETE' THEN
                    IF (OLD.id is not null) THEN
                        delete from sr_srv_rendered where id = OLD.id;
                    END IF;
                    RETURN OLD;
                END IF;
            END;
$$;

