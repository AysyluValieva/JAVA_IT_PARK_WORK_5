CREATE VIEW v_age_category_simple AS
  SELECT 1 AS id,
    'до 1 года'::text AS name
UNION
 SELECT 2 AS id,
    '1-17 лет'::text AS name
UNION
 SELECT 3 AS id,
    '18-59 лет'::text AS name
UNION
 SELECT 4 AS id,
    'от 60 лет'::text AS name;

