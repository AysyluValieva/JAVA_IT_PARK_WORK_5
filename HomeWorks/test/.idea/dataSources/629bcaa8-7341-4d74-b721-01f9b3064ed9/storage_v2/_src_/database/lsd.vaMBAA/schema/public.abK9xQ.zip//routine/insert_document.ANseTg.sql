CREATE FUNCTION insert_document()
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
x int;
num constant bigint := 1000000000000;
enp text;
st timestamp;
en timestamp;
sec float;
begin
	st := clock_timestamp();
	for x in 1..999
	loop
		enp := num::text || lpad(x::text, 3, '0');
		--raise notice '%', enp;
		with cte as (
			select 
				nextval('pim_indiv_code_id_seq') as id, 
				(select id from pim_code_type where code='ENP') as type_id, 
				1186790 as indiv_id, 
				current_date as issue_dt, 
				enp as code
			), bs as (
				insert into pim_indiv_code (id, type_id, indiv_id, issue_dt, code)
				select * from cte 
				returning id, indiv_id, issue_dt
			), ms as (
				select 
					nextval('pim_individual_doc_id_seq') as id, 
					(select id from pim_doc_type where code='MHI_UNIFORM') as type_id, 
					null::text as series, 
					enp as "number", 
					bs.indiv_id, 
					bs.id as code_id, 
					bs.issue_dt, 
					true as is_active,
					(select o.id from pim_organization o limit 1) as issuer_id
				from bs
			)
			insert into pim_individual_doc (id, type_id, series, "number", indiv_id, code_id, issue_dt, is_active, issuer_id)
			select * from ms;
	end loop;
	en := clock_timestamp();
	sec := extract(epoch from (en-st));
	raise notice 'Total time spend in execution : %', sec;
	raise notice 'Time spend per each record : %', sec/1000.0;
end;
$$;

