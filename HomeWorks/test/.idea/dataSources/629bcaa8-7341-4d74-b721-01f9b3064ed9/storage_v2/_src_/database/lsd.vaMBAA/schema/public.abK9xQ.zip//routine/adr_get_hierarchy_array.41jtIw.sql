CREATE FUNCTION adr_get_hierarchy_array(p1_element_id integer, OUT hierarchy_array integer[])
  RETURNS integer[]
STABLE
STRICT
LANGUAGE plpgsql
AS $$
BEGIN
    --version: 2015-04-14
    hierarchy_array :=
    (
        WITH RECURSIVE address_hierarchy AS 
        (
            SELECT a.id, a.id AS source_adr_id, a.parent_id, a.level_id FROM address_element AS a WHERE a.id = p1_element_id 
            UNION ALL
            SELECT a.id, t.source_adr_id, a.parent_id, a.level_id FROM address_element AS a, address_hierarchy AS t WHERE a.id = t.parent_id
        )
        SELECT array_agg (id ORDER BY level_id) FROM address_hierarchy
    );
END;
$$;

