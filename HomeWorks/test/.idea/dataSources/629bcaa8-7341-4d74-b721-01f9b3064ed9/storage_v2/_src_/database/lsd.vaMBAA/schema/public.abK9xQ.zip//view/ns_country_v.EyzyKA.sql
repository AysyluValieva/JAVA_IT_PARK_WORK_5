CREATE VIEW ns_country_v AS
  SELECT address_element.id,
    address_element.name
   FROM address_element
  WHERE (address_element.type_id = 1);

