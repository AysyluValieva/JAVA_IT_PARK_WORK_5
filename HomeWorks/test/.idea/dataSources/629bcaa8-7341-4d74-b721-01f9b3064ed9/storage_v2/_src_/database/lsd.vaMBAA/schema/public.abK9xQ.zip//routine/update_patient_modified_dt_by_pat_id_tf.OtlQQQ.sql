CREATE FUNCTION update_patient_modified_dt_by_pat_id_tf()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
                    IF ( TG_OP = 'INSERT' )
                    THEN
                        UPDATE pci_patient set _modified_dt = now() where id = NEW.patient_id;
                        RETURN NEW;
                    END IF;

                    IF ( TG_OP = 'UPDATE' )
                    THEN
                        IF (NEW.patient_id <> OLD.patient_id)
                        THEN
                          UPDATE pci_patient set _modified_dt = now() where id = NEW.patient_id;
                          UPDATE pci_patient set _modified_dt = now() where id = OLD.patient_id;
                        ELSE
                          UPDATE pci_patient set _modified_dt = now() where id = NEW.patient_id;
                        END IF;
                        RETURN NEW;
                    END IF;

                    IF ( TG_OP = 'DELETE' )
                    THEN
                        UPDATE pci_patient set _modified_dt = now() where id = OLD.patient_id;
                        RETURN OLD;
                    END IF;
                    RETURN NULL;
                  END;
$$;

