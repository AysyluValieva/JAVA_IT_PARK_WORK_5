CREATE FUNCTION upd_md_diagnosis_for_diag_bt()
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
row record;
begin
for row in
select s1.id,(array_agg(s2.id order by s2.level desc))[1] parent_id,(array_agg(s2.level order by s2.level desc))[1] parent_level from md_diagnosis s1 
join md_diagnosis s2 on substring(s1.code,1,3) between substring(s2.code,1,3) and substring(s2.code,5,3)
where s1.code similar to '\w{1}\d{2}\W?' 
group by s1.id,s1.code loop
update md_diagnosis set parent_id=row.parent_id,level=row.parent_level+1 where id=row.id;
end loop;
end;
$$;

