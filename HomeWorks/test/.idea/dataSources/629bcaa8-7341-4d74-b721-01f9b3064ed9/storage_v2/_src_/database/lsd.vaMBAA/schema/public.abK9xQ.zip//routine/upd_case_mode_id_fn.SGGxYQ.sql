CREATE FUNCTION upd_case_mode_id_fn()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE
    caseModeId integer;
    caseId integer;
BEGIN
    caseModeId = (select case_mode_id from mc_case_type ct where ct.id = (select case_type_id from mc_case c where c.id = NEW.case_id));
    NEW._case_mode_id := caseModeId;
    RETURN NEW;
END;
$$;

