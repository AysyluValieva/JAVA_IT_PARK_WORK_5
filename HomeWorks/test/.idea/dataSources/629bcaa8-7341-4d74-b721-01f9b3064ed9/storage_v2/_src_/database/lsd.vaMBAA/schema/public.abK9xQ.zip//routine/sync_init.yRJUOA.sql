CREATE FUNCTION sync_init(p_tab regclass, p_cnt integer DEFAULT NULL::integer)
  RETURNS bigint
LANGUAGE plpgsql
AS $$
declare
v_q               text;
v_cust_name       text;
v_entity_id       i_sync_ext_entity.id%type;
v_euid_entity_id  i_sync_ext_entity.euid_entity_id%type;
v_aud_tab_expr    text;
v_entity_id_expr  text;
v_row_cnt         int8;
v_lock_res        boolean;
c_lock_id         constant int := 20140625;

begin
v_lock_res := pg_try_advisory_lock(c_lock_id);
if not v_lock_res then
raise exception 'locked (execution in progress by other session)';
end if;

select relname into v_aud_tab_expr from pg_class where relkind = 'r' and relname = p_tab||'_aud' and relnamespace = (select oid from pg_namespace where nspname = current_schema());
if not found then
v_aud_tab_expr := '(select -1 id, -1 rev)'; -- fake audit table for non-auditable tables
end if;
select expr into v_entity_id_expr from i_sync_tab where lower(code) = lower(p_tab::text) and (expr is not null or length(expr) > 0);
if not found then
   select entity_id into strict v_entity_id from i_sync_map where tab_id = (select id from i_sync_tab where lower(code) = lower(p_tab::text));
   v_entity_id_expr := '$1';
else
   v_entity_id_expr := replace(v_entity_id_expr, '$1', ''''||p_tab::text||'''');
   v_entity_id_expr := '('||replace(v_entity_id_expr, '$2', 'i.id')||')';
end if;

select value into v_cust_name from cmn_setting_value where setting_id = 'cz.atria.lsd.zero.server.api.ServerSettings.host' limit 1;
if not found then
   select default_value into v_cust_name from cmn_setting where id = 'cz.atria.lsd.zero.server.api.ServerSettings.host';
end if;

if v_cust_name is null or v_cust_name = '' then
   v_cust_name := '[undef_host]';
else
   v_cust_name := replace(v_cust_name, '.', '_');
end if;

if v_entity_id is not null then
    select euid_entity_id into v_euid_entity_id from i_sync_ext_entity where id = v_entity_id;
end if;

v_q := format('
insert into i_sync_entity_ver(%1$s id, entity_id, ver, source, obj_id)
select %2$s
nextval(''i_sync_entity_ver_seq''), '||v_entity_id_expr||' as entity_id,
coalesce(last_dt, to_date(''01.01.2000'', ''DD.MM.YYYY'')) as dt,
'''||v_cust_name||'.KIR_RMIS.1.''||
coalesce((select login from sec_user su, sec_audit_entry sae, '||v_aud_tab_expr||' pia1
where sae.user_id = su.id and last_dt = sae."date" and pia1.id = i.id and pia1.rev = sae.id), ''undef'') as source,
i.id as obj_id
from '||p_tab||' i %3$s
left outer join (select max("date") as last_dt, pia.id from '||v_aud_tab_expr||' pia, sec_audit_entry sae2 where sae2.id = pia.rev group by pia.id) as last_rev on i.id = last_rev.id
where not exists (select 1 from i_sync_entity_ver where entity_id = '||v_entity_id_expr||' and i.id = obj_id)'
||coalesce(' limit '||p_cnt, ''),
    (case v_euid_entity_id is not null when true then  'euid,' else '' end),
    (case v_euid_entity_id is not null when true then  'ev2.euid,' else '' end),
    (case v_euid_entity_id is not null when true then  format(' join (select euid, obj_id from i_sync_entity_ver where entity_id = %1$s) ev2 on ev2.obj_id = i.id', v_euid_entity_id) else '' end)
);
begin
if current_setting('common.is_log_statement')::boolean then
raise notice '%', v_q;
raise notice 'entity_id=%', v_entity_id;
end if;
exception when others then raise notice '%:%', sqlstate, sqlerrm;
end;

execute v_q using v_entity_id;
get diagnostics v_row_cnt = ROW_COUNT;
return v_row_cnt;
exception when others then
v_lock_res := pg_advisory_unlock(c_lock_id);
raise;
end;
$$;

