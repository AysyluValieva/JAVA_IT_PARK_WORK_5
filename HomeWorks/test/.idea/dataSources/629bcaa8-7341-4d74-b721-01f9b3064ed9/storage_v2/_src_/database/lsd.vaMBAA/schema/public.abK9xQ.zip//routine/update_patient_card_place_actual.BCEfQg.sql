CREATE FUNCTION update_patient_card_place_actual()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE
        patientId integer;
        clinicId integer;
BEGIN
	 IF TG_OP in ('INSERT', 'UPDATE') THEN
     	patientId = NEW.patient_id;
		clinicId = NEW.clinic_id;
     ELSIF TG_OP = 'DELETE' THEN
		patientId = OLD.patient_id;
		clinicId = OLD.clinic_id;
	ELSE
		RETURN NULL;
    END IF;

	UPDATE PCI_PATIENT_CARD_PLACE SET is_actual=false 
    WHERE patient_id=patientId AND clinic_id=clinicId;
    
    UPDATE PCI_PATIENT_CARD_PLACE SET is_actual=TRUE
    WHERE id IN
        ( SELECT p.id
         FROM pci_patient_card_place p
         INNER JOIN
           ( SELECT p2.patient_id AS patient_id, p2.clinic_id AS clinic_id, max(p2.date) AS max_date
            FROM pci_patient_card_place p2
            WHERE p2.patient_id=patientId AND p2.clinic_id=clinicId
            GROUP BY 1,2
             ) a ON p.patient_id=a.patient_id AND p.clinic_id=a.clinic_id AND a.max_date = p.date );
    RETURN NULL;
END;
$$;

