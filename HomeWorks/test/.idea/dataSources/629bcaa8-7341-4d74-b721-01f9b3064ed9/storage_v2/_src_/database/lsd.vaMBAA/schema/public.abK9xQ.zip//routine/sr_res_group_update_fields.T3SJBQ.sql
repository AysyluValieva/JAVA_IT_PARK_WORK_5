CREATE FUNCTION sr_res_group_update_fields()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
                UPDATE sr_res_group_relationship SET _is_system = NEW.is_system WHERE group_id = NEW.id AND _is_system != NEW.is_system;
                RETURN NULL;
            END;
$$;

