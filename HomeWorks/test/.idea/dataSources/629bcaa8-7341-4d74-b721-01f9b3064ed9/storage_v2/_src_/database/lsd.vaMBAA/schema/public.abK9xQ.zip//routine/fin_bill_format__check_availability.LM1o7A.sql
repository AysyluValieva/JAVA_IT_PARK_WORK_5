CREATE FUNCTION fin_bill_format__check_availability(bill_id integer, format_id integer)
  RETURNS boolean
LANGUAGE plpgsql
AS $$
DECLARE
                _result      BOOLEAN;
                _cond        VARCHAR;
                _export_mark BOOLEAN;
            BEGIN
                SELECT cond, export_mark INTO _cond, _export_mark FROM fin_bill_main_format WHERE id = format_id;
                IF (_cond IS NULL OR _cond = '') THEN
                    EXECUTE 'SELECT (status_id <> 0 AND NOT $1) OR status_id IN (1,5) FROM fin_bill where id = $2'
                        INTO _result USING _export_mark, bill_id;
                ELSE
                    EXECUTE _cond INTO _result USING bill_id;
                END IF;
                RETURN _result IS NOT NULL AND _result = true;
            END;
$$;

