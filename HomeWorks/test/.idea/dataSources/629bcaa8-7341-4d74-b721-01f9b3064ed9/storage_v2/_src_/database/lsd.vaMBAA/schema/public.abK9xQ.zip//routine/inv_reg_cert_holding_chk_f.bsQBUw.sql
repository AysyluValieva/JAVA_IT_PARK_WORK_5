CREATE FUNCTION inv_reg_cert_holding_chk_f()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
declare
v_holding_id inv_holding.id%type;
v_holding_id2 inv_holding.id%type;
begin
   case TG_RELNAME
      when 'inv_reg_cert' then
         select into v_holding_id f.holding_id from inv_reg_cert_form rcf, inv_form f where rcf.reg_cert_id = new.id and rcf.form_id = f.id;
         if v_holding_id is not null and new.md_holding_id <> v_holding_id then
            raise exception 'holding_id not correspond:% != %',new.md_holding_id, v_holding_id;
         end if;
      when 'inv_reg_cert_form' then
         select into v_holding_id rc.md_holding_id from inv_reg_cert rc where new.reg_cert_id = rc.id;
         select into v_holding_id2 holding_id from inv_form f where f.id = new.form_id;
         if v_holding_id <> v_holding_id2 then
            raise exception 'holding_id not correspond:% != %', v_holding_id, v_holding_id2;
         end if;
      else null;
   end case;
   return new;
end;
$$;

