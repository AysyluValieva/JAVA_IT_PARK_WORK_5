CREATE FUNCTION copy_hsp_data_to_step_tg_tf()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE
                        _app_code TEXT;
                    BEGIN
                        SELECT current_setting('app.source') INTO _app_code;

                        IF ('typing2' <> _app_code AND 'n2o'<>_app_code) THEN
                            _app_code := 'lsd';
                        END IF;

                        IF(SELECT EXISTS(SELECT 1 FROM cmn_app_using_mc_step_only WHERE cmn_app_using_mc_step_only.app_code = _app_code) ) THEN
                            RETURN NEW;
                        END IF;

                        UPDATE mc_step SET
                            hsp_bed_days_amount =hr.bed_days_amount,
                            hsp_bed_profile_id = hr.bed_profile_id,
                            hsp_complexity_level_id = hr.complexity_level_id,
                            hsp_days_comp_algo_id = hr.days_comp_algo_id,
                            hsp_department_id = hr.department_id,
                            hsp_funding_id = hr.funding_id,
                            hsp_is_admission_day_counts = hr.is_admission_day_counts,
                            hsp_is_diag_not_eq = hr.is_diag_not_eq,
                            hsp_is_set_diagnosis = hr.is_set_diagnosis,
                            hsp_issue_planned_date = hr.issue_planned_date,
                            hsp_mes_id = hr.mes_id,
                            hsp_missed_days_amount = hr.missed_days_amount,
                            hsp_plan_department_id = hr.plan_department_id,
                            hsp_refusal_employee_id = hr.refusal_employee_id,
                            hsp_previous_id = hr.previous_id
                        FROM ( SELECT bed_days_amount, bed_profile_id, complexity_level_id, days_comp_algo_id, department_id, funding_id, is_admission_day_counts, is_diag_not_eq, is_set_diagnosis, issue_planned_date, mes_id, missed_days_amount, plan_department_id, refusal_employee_id, previous_id FROM hsp_record WHERE id = NEW.id) hr
                    WHERE id = NEW.id;
                    RETURN NEW;
                    END;
$$;

