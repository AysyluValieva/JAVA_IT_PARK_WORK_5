CREATE VIEW v_pim_doc_and_code AS
  SELECT individual2_.indiv_id,
    document3_.number
   FROM (pim_indiv_doc_detail individual2_
     CROSS JOIN pim_individual_doc document3_)
  WHERE (individual2_.doc_id = document3_.id)
UNION
 SELECT individual4_.indiv_id,
    individual4_.code AS number
   FROM pim_indiv_code individual4_;

