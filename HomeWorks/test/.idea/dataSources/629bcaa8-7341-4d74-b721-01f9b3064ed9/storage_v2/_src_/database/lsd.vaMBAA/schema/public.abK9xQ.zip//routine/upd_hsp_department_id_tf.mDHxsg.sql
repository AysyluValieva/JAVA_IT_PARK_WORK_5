CREATE FUNCTION upd_hsp_department_id_tf()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
                    UPDATE mc_step SET _department_id = NEW.hsp_department_id WHERE id = NEW.id;
                    RETURN NEW;
                    END;
$$;

