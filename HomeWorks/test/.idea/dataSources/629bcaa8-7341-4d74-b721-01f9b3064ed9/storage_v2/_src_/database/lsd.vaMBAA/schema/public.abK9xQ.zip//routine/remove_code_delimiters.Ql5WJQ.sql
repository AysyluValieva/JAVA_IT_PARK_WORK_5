CREATE FUNCTION remove_code_delimiters()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
declare
            begin
                if (NEW.code is not null) then
                NEW.code = regexp_replace(NEW.code, '-|\s|\/|\\', '', 'g');
                end if;
                return NEW;
            end;
$$;

