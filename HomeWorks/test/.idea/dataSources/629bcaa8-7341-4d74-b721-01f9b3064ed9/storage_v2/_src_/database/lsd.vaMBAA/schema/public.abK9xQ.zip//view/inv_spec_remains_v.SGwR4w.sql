CREATE VIEW inv_spec_remains_v AS
  SELECT sc.id,
    sc.opr_id,
    sc.holding_id,
    sc.form_id,
    sc.pos,
    sc.prod_dt,
    sc.expire_dt,
    sc.unit_id,
    sc.val,
    sc.price,
    sc.amount,
    sc.fin_type_id,
    sc.note,
    sc.is_refused,
    sc.approve_note,
    sc.base_spec_id,
    sc.init_remains_id,
    sc.contractor_remains_id,
    COALESCE((s.expire_dt < ('now'::text)::date), false) AS is_expired,
    ( SELECT count(1) AS count
           FROM inv_series_restriction sr
          WHERE ((sr.series_id = s.id) AND (sr.cancel_letter_id IS NULL))) AS restriction_count,
        CASE (rn.val IS NOT NULL)
            WHEN true THEN ((r.val - sc.val) < rn.val)
            ELSE NULL::boolean
        END AS is_over_norm,
    rn.val AS norm_val,
    rn.is_min,
    s2.val_proc,
    s2.amount_proc
   FROM ((((inv_spec sc
     LEFT JOIN inv_remains r ON ((((sc.init_remains_id IS NOT NULL) AND (sc.init_remains_id = r.id)) OR ((sc.init_remains_id IS NULL) AND (sc.contractor_remains_id IS NOT NULL) AND (sc.contractor_remains_id = r.id)))))
     LEFT JOIN inv_series s ON ((r.series_id = s.id)))
     LEFT JOIN inv_remains_norm rn ON (((rn.store_nomenclature_id = r.store_nomenclature_id) AND ((rn.store_id IS NULL) OR (rn.store_id = r.store_id)))))
     LEFT JOIN ( SELECT inv_spec.base_spec_id,
            sum(inv_spec.val) AS val_proc,
            sum(inv_spec.amount) AS amount_proc
           FROM inv_spec
          WHERE (inv_spec.base_spec_id IS NOT NULL)
          GROUP BY inv_spec.base_spec_id) s2 ON ((sc.id = s2.base_spec_id)));

