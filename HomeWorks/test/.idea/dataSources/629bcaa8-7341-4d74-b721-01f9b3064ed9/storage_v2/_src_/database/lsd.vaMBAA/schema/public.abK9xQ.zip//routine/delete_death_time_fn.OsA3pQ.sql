CREATE FUNCTION delete_death_time_fn()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
            update pim_individual set death_time = null WHERE id = OLD.id;
            RETURN NULL;
            END;
$$;

