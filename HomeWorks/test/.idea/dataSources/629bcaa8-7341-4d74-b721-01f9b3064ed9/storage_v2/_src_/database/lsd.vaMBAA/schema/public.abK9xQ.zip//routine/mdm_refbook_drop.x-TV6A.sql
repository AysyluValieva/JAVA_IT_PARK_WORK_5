CREATE FUNCTION mdm_refbook_drop(xtable_name character varying)
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
  xrefbook_id integer;
  xversion_count integer;
  xcurrent_version_id integer;
begin

select id into xrefbook_id from mdm_internal_refbook where table_name = xtable_name;

select count(1) into xversion_count from mdm_refbook_version where refbook_id = xrefbook_id and version is not null;
if (xversion_count = 0)
then
  delete from mdm_refbook where id = xrefbook_id;
else
  select id into xcurrent_version_id from mdm_refbook_version where refbook_id = xrefbook_id and version is null;
  if (xcurrent_version_id is not null)
  then
    delete from mdm_refbook_version where id = xcurrent_version_id;
  end if;
end if;

end;
$$;

