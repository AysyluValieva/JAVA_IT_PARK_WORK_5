CREATE FUNCTION fin_price__get_price(r_id integer, plid integer)
  RETURNS numeric
LANGUAGE plpgsql
AS $$
declare rec record;
        p numeric;
        q numeric;
        b numeric;
        a numeric;
        f integer;
        c numeric;
        cc numeric;
        ff boolean;
        posId integer;
        tariff numeric;
begin
if r_id is null then return null; end if;
--смотрю цену в услуге
 select cost*quantity from sr_srv_rendered where id= r_id into c;
--определяю приоритет того, откуда брать цену, t - из sr_srv_rendered, f - из прейскуранта
 select is_has_service_priority from sr_srv_rendered r left join fin_bill_price_formation f on f.id=r.funding_id where r.id= r_id into ff;
--если есть цена в sr_srv_rendered и у нее приоритет, берем эту цену, выход
--в противном случае берем цену из прейскуранта
 if ff and c is not null then return c; end if;
 if (select count(1) from fin_pl_position plp where plp.price_list_id = plId and
 	exists (select 1 from sr_srv_rendered sr left join fin_pl_pos_to_clinic_srv pptc on pptc.clinic_service_id = sr.service_id where sr.id = r_id and pptc.pl_position_id = plp.id)) <> 1
 then return null; end if;

 select plp.id, plp.price into posId, tariff from fin_pl_position plp where plp.price_list_id = plId and
 	exists (select 1 from sr_srv_rendered sr left join fin_pl_pos_to_clinic_srv pptc on pptc.clinic_service_id = sr.service_id where sr.id = r_id and pptc.pl_position_id = plp.id);

for rec in
select * from fin_price_modifier pm
	where (scope_id = 1 and price_list_id = plId)
	or (scope_id = 2 and exists (select 1 from fin_modifier_to_pl_pos where pl_position_id = posId and pm.id = price_modifier_id))
	order by pm.apply_order, pm.id
loop

if fin_price_modifier__need_apply(r_id, rec.condition) then

	if rec.type=1 then tariff := tariff * cast(rec.value as numeric); end if;

	if rec.type=2 then tariff := tariff + cast(rec.value as numeric); end if;

	if rec.type=3 then tariff := cast(rec.value as numeric); end if;

	if rec.type=4 then execute replace(rec.value::text, '?', r_id::text) into tariff; end if;

end if;


end loop;

return tariff;

end;
$$;

