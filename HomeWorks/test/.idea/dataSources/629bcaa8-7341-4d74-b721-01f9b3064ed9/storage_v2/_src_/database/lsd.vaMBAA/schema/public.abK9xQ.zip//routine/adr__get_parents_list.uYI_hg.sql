CREATE FUNCTION adr__get_parents_list(param_id integer)
  RETURNS text
LANGUAGE plpgsql
AS $$
DECLARE
                      el_parent int4;
                    BEGIN
                    SELECT ae.parent_id FROM address_element as ae WHERE ae.id = param_id into el_parent;
                    IF el_parent IS NULL THEN
                                              BEGIN
                                                RETURN ' ';
                                              END;
                    ELSE
                                              BEGIN

                                                RETURN (adr__get_parents_list(el_parent)  ||' '|| el_parent::text);
                                              END;
                    END IF;
                    END;
$$;

