CREATE FUNCTION calc_identity_doc()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
declare
                            is_oms_doc boolean;
                            is_id_doc  boolean;
                            xdata varchar[] := array[]::varchar[];
                            rec record;
                            xret record;
                        begin
                            if (TG_OP = 'DELETE')
                            then
                                xdata := xdata || 'OLD'::varchar;
                                xret := OLD;
                            else
                                xdata := xdata || 'NEW'::varchar;
                                --нужно обновлять и "старого" владельца документа, если меняется indiv_id
                                if (TG_OP = 'UPDATE' AND NEW.indiv_id <> OLD.indiv_id) then
                                    xdata := xdata || 'OLD'::varchar;
                                end if;
                                xret := NEW;
                            end if;
                            FOR i IN array_lower(xdata, 1) .. array_upper(xdata, 1)
                            LOOP
                                if (xdata[i] = 'NEW') then rec := NEW; else rec := OLD; end if;
                                select count(*) > 0 into is_id_doc from pim_doc_type_category dtc where
                                    dtc.type_id in (rec.type_id) and dtc.category_id = 1;
                                select count(*) > 0 into is_oms_doc from pim_doc_type_category dtc where
                                    dtc.type_id in (rec.type_id) and dtc.category_id = 2;
                                if (is_id_doc) then
                                    update pim_individual set list_identity_doc =(
                                        select coalesce(id.series,' ') || ',' || coalesce(id.number,' ') || ',' || coalesce(dt.name,' ')
                                        from pim_individual_doc id
                                        join pim_doc_type dt on (id.type_id = dt.id)
                                        left join pim_doc_type_category dtc on (dtc.type_id = dt.id)
                                        where id.indiv_id = rec.indiv_id and dtc.category_id = 1
                                        order by dt.priority
                                        limit 1)
                                    where id = rec.indiv_id;
                                end if;
                                if (is_oms_doc) then
                                    update pim_individual set list_oms_doc = (
                                        select coalesce(id.series,' ') || ',' || coalesce(id.number,' ') || ',' || coalesce(o.short_name,' ') || ','
                                        || coalesce(oc.code,' ')
                                        from pim_individual_doc id
                                        join pim_doc_type dt on (id.type_id = dt.id)
                                        left join pim_organization o on (o.id = id.issuer_id)
                                        left join pim_org_code oc on (oc.org_id = o.id)
                                        left join pim_doc_type_category dtc on (dtc.type_id = dt.id)
                                        where id.indiv_id = rec.indiv_id and dtc.category_id = 2
                                        order by dt.priority
                                        limit 1)
                                    where id = rec.indiv_id;
                                end if;
                            END LOOP;
                            return xret;
                        end;
$$;

