CREATE FUNCTION get_holding_full_name(p_sn_id integer)
  RETURNS text
IMMUTABLE
LANGUAGE plpgsql
AS $$
declare
            v_res text := '';
            v_form_id inv_form.id%type;
            r record;
            begin
            select h.name_trade, sn.form_id
            into v_res, v_form_id
            from inv_store_nomenclature sn, inv_holding h
            where sn.holding_id = h.id
              and sn.id = p_sn_id;

            if v_form_id is not null then
                v_res := v_res || ' ' ||get_form_full_name(v_form_id);
            end if;
            return v_res;
            end;
$$;

