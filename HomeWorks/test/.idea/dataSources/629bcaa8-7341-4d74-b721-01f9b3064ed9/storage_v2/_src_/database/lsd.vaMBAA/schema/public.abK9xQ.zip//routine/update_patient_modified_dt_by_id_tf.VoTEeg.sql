CREATE FUNCTION update_patient_modified_dt_by_id_tf()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
                    UPDATE pci_patient set _modified_dt = now() where id = NEW.id;
                    RETURN NEW;
                  END;
$$;

