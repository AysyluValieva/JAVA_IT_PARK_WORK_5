CREATE VIEW fin_bill_spec_item_returned_error AS
  SELECT fin_bill_spec_item_returned_error.bill_id,
    fin_bill_spec_item_returned_error.text_bill_id,
    fin_bill_spec_item_returned_error.text_case_id,
    fin_bill_spec_item_returned_error.item_id_arr,
    fin_bill_spec_item_returned_error.code,
    fin_bill_spec_item_returned_error.comment,
    fin_bill_spec_item_returned_error.code_regional,
    fin_bill_spec_item_returned_error.comment_regional,
    fin_bill_spec_item_returned_error.payment_status_code,
    fin_bill_spec_item_returned_error.insurance_case_id,
    fin_bill_spec_item_returned_error.sank
   FROM billing.fin_bill_spec_item_returned_error;

