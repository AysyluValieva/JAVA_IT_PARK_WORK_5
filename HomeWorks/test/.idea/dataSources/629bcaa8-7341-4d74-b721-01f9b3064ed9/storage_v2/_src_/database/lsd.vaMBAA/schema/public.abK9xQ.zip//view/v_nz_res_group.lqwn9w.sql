CREATE VIEW v_nz_res_group AS
  SELECT srg.id,
    srg.name,
    concat(srg.name, ' (', ((pd.name)::text || ', '::text), o.short_name, ')') AS srg_name
   FROM ((((sr_res_group srg
     JOIN pim_organization o ON (((o.id = srg.org_id) AND (NOT srg.is_system))))
     LEFT JOIN pim_employee_position pep ON ((pep.id = srg.responsible_id)))
     LEFT JOIN pim_position pp ON ((pp.id = pep.position_id)))
     LEFT JOIN pim_department pd ON ((pd.id = COALESCE(srg.department_id, pp.department_id))))
  ORDER BY o.short_name, pd.name, srg.name;

