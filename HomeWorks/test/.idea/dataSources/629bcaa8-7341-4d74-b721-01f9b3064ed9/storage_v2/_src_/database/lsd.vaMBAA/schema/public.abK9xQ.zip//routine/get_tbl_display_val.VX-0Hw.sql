CREATE FUNCTION get_tbl_display_val(table_name text, id_val text)
  RETURNS SETOF record
LANGUAGE plpgsql
AS $$
begin
                  return query EXECUTE format('select name::varchar from %s where id = %s', table_name, id_val);
                end;
$$;

