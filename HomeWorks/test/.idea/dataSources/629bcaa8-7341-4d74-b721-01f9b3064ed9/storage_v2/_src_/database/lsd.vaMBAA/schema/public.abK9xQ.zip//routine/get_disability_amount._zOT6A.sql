CREATE FUNCTION get_disability_amount(caseid integer)
  RETURNS character varying
LANGUAGE plpgsql
AS $$
declare
    days integer;
    sickListId integer;
begin
     sickListId=(select id from md_sicklist sl where sl.case_id=caseId and sl.workplace_type_id=1 and sl.type_id=1 and
                                                       not (exists (select sl1.id from md_sicklist sl1
                                                            where sl1.parent_id=sl.id and sl1.workplace_type_id=1)) LIMIT 1);
     days = (select max(slp.to_dt)::date - min(slp.from_dt)::date from md_sicklist_period slp where slp.sicklist_id=sickListId);
     days = days+1;
     return days||' дн.';
end;
$$;

