CREATE FUNCTION find_snils(text)
  RETURNS pim_individual_doc
STABLE
LANGUAGE plpgsql
AS $$
declare
	dtype int;
	_doc pim_individual_doc;
begin
	select id into dtype from pim_doc_type where code = 'SNILS';
	select * into _doc from pim_individual_doc where
		(type_id, (COALESCE(issuer_id, 0)), upper(((COALESCE(series, ''::character varying))::text || (number)::text)))=
				(dtype, (coalesce(null::int, 0)), upper(((coalesce(null::text, ''::character varying))::text || ($1)::text)));
	return _doc;
end;
$$;

