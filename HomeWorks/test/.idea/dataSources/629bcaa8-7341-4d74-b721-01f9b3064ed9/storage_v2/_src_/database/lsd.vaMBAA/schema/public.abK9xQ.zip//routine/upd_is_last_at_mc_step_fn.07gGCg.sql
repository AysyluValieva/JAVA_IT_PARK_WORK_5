CREATE FUNCTION upd_is_last_at_mc_step_fn()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE
    caseId integer;
BEGIN

    IF TG_OP = 'INSERT' OR TG_OP = 'UPDATE' THEN
	       caseId = NEW.case_id;
    ELSE
         caseId = OLD.case_id;
    END IF;

    update mc_step set _is_last = NULL where case_id = caseId and _is_last = TRUE;
    update mc_step set _is_last = TRUE where id =
	      (select id from mc_step where case_id = caseId order by admission_date desc, admission_time desc, id desc limit 1);

    RETURN NULL;
END;
$$;

