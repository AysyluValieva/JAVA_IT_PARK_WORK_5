CREATE FUNCTION diag_in_diap(d1 character varying, d2 character varying, d3 character varying)
  RETURNS boolean
LANGUAGE plpgsql
AS $$
declare
  
begin
if (substring($1,1,1)>=substring($2,1,1)) then 
    if (substring($1,1,1)=substring($3,1,1)) then
        if (substring($1 ,2)>=substring($2 ,2)) and (substring($1 ,2)<=substring($3 ,2)) then return true; else return false; end if;
    else 
        if (substring($1,1,1)<substring($3,1,1)) then return true; else return false; end if;
    end if;
else return false; 
end if;
end;
$$;

