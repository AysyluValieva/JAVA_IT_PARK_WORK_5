CREATE FUNCTION reopen_case(ccase_id integer, user_id integer)
  RETURNS boolean
LANGUAGE plpgsql
AS $$
declare
                                case_data RECORD;
                            begin
                                select result_id, closing_step_id, case_type_id from mc_case into case_data where id = ccase_id;

                                if(case_data.closing_step_id is null) then
                                return false;
                                end if;

                                update mc_step set result_id = null, outcome_id = null, outcome_clinic_id = null, outcome_regimen_id = null
                                where id = case_data.closing_step_id;

                                update mc_case set closing_step_id = null, result_id = null, deviation_reason_id = null where id = ccase_id;

                                if(case_data.case_type_id = 2) then
                                    update mc_step set outcome_date = null, outcome_time = null, hsp_complexity_level_id = null where id = case_data.closing_step_id;
                                end if;

                                delete from mc_med_case_result where id = case_data.result_id;
                                delete from mc_diagnosis where case_id = ccase_id and (stage_id = 4 or stage_id = 5);

                                insert into sec_audit_entry values(nextval('sec_audit_entry_seq'), CURRENT_TIMESTAMP, user_id);
                                insert into mc_case_aud(id, rev, revtype) values(ccase_id, currval('sec_audit_entry_seq'), 1);

                                return true;
                            end;
$$;

