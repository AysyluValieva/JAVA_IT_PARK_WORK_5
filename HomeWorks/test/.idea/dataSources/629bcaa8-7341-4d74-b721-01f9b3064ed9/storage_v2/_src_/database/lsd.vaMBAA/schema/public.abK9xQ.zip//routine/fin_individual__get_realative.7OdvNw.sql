CREATE FUNCTION fin_individual__get_realative(xindiv_id integer, dt date)
  RETURNS integer
LANGUAGE plpgsql
AS $$
begin
    return (SELECT
                prp2.party_id
            FROM pim_party_relation_party prp1
                LEFT JOIN  pim_party_relation_party prp2 ON prp2.rel_id = prp1.rel_id
                LEFT JOIN pim_party_relation r ON r.id = prp2.rel_id
            WHERE prp1.party_id = xindiv_id and prp2.party_id <> xindiv_id
                AND dt BETWEEN coalesce(r.from_dt, '-infinity') AND coalesce(r.to_dt, 'infinity') LIMIT 1);
end;
$$;

