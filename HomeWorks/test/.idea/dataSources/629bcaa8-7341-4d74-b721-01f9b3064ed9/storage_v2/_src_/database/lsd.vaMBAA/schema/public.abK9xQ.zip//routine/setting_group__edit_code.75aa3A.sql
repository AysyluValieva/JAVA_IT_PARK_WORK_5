CREATE FUNCTION setting_group__edit_code(oldcode character varying, newcode character varying)
  RETURNS void
LANGUAGE plpgsql
AS $$
begin

update cmn_setting_group set code = newcode where code = oldcode;
update cmn_setting set code = replace(code, oldcode, newcode) where code like oldcode||'%';
update cmn_domain set code = replace(code, oldcode, newcode), name = replace(name, oldcode, newcode) where code like oldcode||'%';

end;
$$;

