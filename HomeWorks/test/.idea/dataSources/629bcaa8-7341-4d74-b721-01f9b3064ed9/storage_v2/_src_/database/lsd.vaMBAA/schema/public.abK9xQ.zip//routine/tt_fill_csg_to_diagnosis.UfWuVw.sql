CREATE FUNCTION tt_fill_csg_to_diagnosis()
  RETURNS void
STRICT
LANGUAGE plpgsql
AS $$
declare
_r  record;
_id INTEGER;
begin
_id := 1;
for _r in 
   select distinct d.id as id_from, d.id as id_to, g.id as csg_id
     from tt_csg_group_detail gd
     join md_diagnosis d on lower(translate(d.code, '*+', '')) = lower(gd.diagnosis_code)
     join md_clinical_statistical_group g on g.code = gd.csg_code
    where nullif(gd.diagnosis_code, '') is not null
      and g.to_dt is null
      --and gd.csg_id in (158)
    order by g.id, d.id
loop
   if (_r.id_to = (select to_diagnosis_id + 1 from tt_md_csg_to_diagnosis where id = _id - 1))
      and
      (_r.csg_id = (select csg_id from tt_md_csg_to_diagnosis where id = _id - 1)) then
      update tt_md_csg_to_diagnosis set to_diagnosis_id = _r.id_from where id = _id - 1;
--      _id := _id + 1;
   else
      insert into tt_md_csg_to_diagnosis values (_id, _r.csg_id, _r.id_from, _r.id_to, null);
      _id := _id + 1;
   end if;
end loop;
end;
$$;

