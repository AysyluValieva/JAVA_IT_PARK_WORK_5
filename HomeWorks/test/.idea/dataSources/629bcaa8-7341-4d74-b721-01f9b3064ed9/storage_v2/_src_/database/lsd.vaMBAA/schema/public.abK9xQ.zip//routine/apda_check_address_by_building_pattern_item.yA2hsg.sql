CREATE FUNCTION apda_check_address_by_building_pattern_item(h_name character varying, f_name character varying, item character varying)
  RETURNS boolean
LANGUAGE plpgsql
AS $$
DECLARE
  d                apda_houses_diapason;
  digit_house_name INTEGER;
BEGIN
  digit_house_name = substring($1 FROM '^[0-9]+');
  d = apda_get_houses_diapason($3);

  IF (d).diapason_type = 'О'
  THEN
    IF (d).single_number = $1
    THEN
      IF (d).flats.number_from ISNULL
      THEN RETURN TRUE;
      ELSEIF $2 ISNULL OR $2 = ''
        THEN RETURN FALSE;
      ELSEIF $2 :: INTEGER >= (d).flats.number_from AND $2 :: INTEGER <= (d).flats.number_to
        THEN RETURN TRUE;
      END IF;
    ELSEIF digit_house_name :: VARCHAR = (d).single_number AND (d).flats.number_from ISNULL
      THEN RETURN TRUE;
    END IF;
  ELSEIF digit_house_name >= (d).number_from AND digit_house_name <= (d).number_to
    THEN
      IF (d).diapason_type = 'И'
      THEN RETURN TRUE;
      ELSEIF (d).diapason_type = 'Н' AND digit_house_name % 2 = 1
        THEN RETURN TRUE;
      ELSEIF (d).diapason_type = 'Ч' AND digit_house_name % 2 = 0
        THEN RETURN TRUE;
      END IF;
  END IF;

  RETURN FALSE;
END;
$$;

