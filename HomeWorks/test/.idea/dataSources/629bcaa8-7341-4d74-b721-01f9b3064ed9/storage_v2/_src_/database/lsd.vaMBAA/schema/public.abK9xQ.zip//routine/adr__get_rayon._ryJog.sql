CREATE FUNCTION adr__get_rayon(element_id integer)
  RETURNS integer
LANGUAGE SQL
AS $$
WITH RECURSIVE all_elements AS (
  SELECT  id, parent_id, level_id
    FROM address_element
    WHERE id = element_id
  UNION
  SELECT ae.id, ae.parent_id, ae.level_id
    FROM address_element ae
    JOIN all_elements a
      ON (ae.id = a.parent_id)
)
SELECT id FROM all_elements WHERE level_id = 2 LIMIT 100;
$$;

