CREATE VIEW v_nz_smo AS
  SELECT o.id,
    o.short_name AS name
   FROM ((pim_organization o
     JOIN pim_party_role_to_party prr ON ((prr.party_id = o.id)))
     JOIN pim_party_role r ON (((r.id = prr.role_id) AND ((r.code)::text = ANY (ARRAY[('HIF_ORGANIZATION'::character varying)::text, ('MEDICAL_INSURANCE_ORGANIZATION'::character varying)::text])))))
  ORDER BY o.short_name;

