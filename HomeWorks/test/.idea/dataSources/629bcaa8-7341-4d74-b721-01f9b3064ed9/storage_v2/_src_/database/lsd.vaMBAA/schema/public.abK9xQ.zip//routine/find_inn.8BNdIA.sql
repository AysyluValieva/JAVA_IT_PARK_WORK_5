CREATE FUNCTION find_inn(org_id integer)
  RETURNS text
STABLE
STRICT
LANGUAGE SQL
AS $$
select poc.code from pim_org_code poc join pim_code_type pct on pct.id = poc.type_id
	where pct.code = 'INN_ORGANIZATION' and poc.org_id = $1
	order by poc.issue_dt desc nulls last, poc.id desc limit 1
$$;

