CREATE FUNCTION get_visit_caption(integer)
  RETURNS character varying
LANGUAGE plpgsql
AS $$
declare

                caption RECORD;

            begin

                select
                    to_char(mc_step.admission_date, 'dd.mm.yyyy') as bdate,
                    coalesce((select pim_speciality.name from sr_res_group_relationship
                                  inner join sr_resource on sr_resource.id = sr_res_group_relationship.resource_id
                                inner join pim_employee_position_resource on pim_employee_position_resource.id = sr_resource.id
                                inner join pim_employee_position on pim_employee_position.id = pim_employee_position_resource.employee_position_id
                                inner join pim_position on pim_position.id = pim_employee_position.position_id
                                inner join pim_speciality on pim_speciality.id = pim_position.speciality_id
                                inner join sr_res_role on sr_res_role.id = sr_res_group_relationship.role_id
                                    where mc_step.res_group_id is not null and group_id = mc_step.res_group_id and sr_resource.res_kind_id =1  and sr_res_role.kind_id = 1  limit 1 ), 'Специальность не указана') as speciality,
                    coalesce((select md_diagnosis.code from mc_diagnosis  inner join md_diagnosis on md_diagnosis.id = mc_diagnosis.diagnos_id
                                    where mc_diagnosis.is_main is not null and mc_diagnosis.is_main = true and mc_diagnosis.step_id = mc_step.id limit 1), 'Основной диагноз не указан') as diagnosis
                  from mc_step into caption
                  where mc_step.id = $1;
                  if (caption is not null) then
                  return  caption.bdate || ' '||caption.speciality || ' ' ||caption.diagnosis;
                end if;
                return '';
            end;
$$;

