CREATE FUNCTION update_price(price text, mo integer)
  RETURNS SETOF text[]
LANGUAGE plpgsql
AS $$
declare 
	_msg text[];
	_price fin_price_list%rowtype;
	_position fin_pl_position%rowtype;
begin
	for _price in select * from fin_price_list where commentary = 'hospital' and to_dt is null and (clinic_id = mo or mo is null)
	loop
		_msg := null::text[] || 'Начало обработки.'::text || concat('Клиника № ', _price.clinic_id)::text;
		_msg := _msg || concat(_price."name", '   ',  _price.commentary, '   ',coalesce(_price.to_dt::text, 'Дата закрытия Открыта'))::text;
		
		return next _msg;
	end loop;
end;
$$;

