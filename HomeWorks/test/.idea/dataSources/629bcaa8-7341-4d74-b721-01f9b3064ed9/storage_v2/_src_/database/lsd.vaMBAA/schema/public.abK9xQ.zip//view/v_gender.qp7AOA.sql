CREATE VIEW v_gender AS
  SELECT pim_gender.id,
    pim_gender.name
   FROM pim_gender
  WHERE (pim_gender.id = ANY (ARRAY[1, 2]));

