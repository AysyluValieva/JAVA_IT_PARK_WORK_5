CREATE FUNCTION get_scope_name(integer, boolean)
  RETURNS character varying
LANGUAGE plpgsql
AS $$
DECLARE
                finder_id integer;
                finder_query character varying;
                value_id integer;
                value_name character varying;
                value_record record;
                type_name character varying;
                table_name character varying;

            BEGIN
            	if ($1 is null) then
            		return 'scope is null';
            	end if;

            	select st.finder_id, st.table_name, st.name into finder_id, table_name, type_name from cmn_scope_type st join cmn_scope s on s.type_id = st.id where s.id = $1;

            	if (table_name is null) then
            		return 'Global';
            	end if;

            	execute('select st.id from ' || table_name || ' st where st.scope_id = ' || $1) into value_id;

            	if (finder_id is not null and value_id is not null) then
            		execute('select replace(f.query, '' :mdm'', '''') || '' '' || replace(f.where_by_id, '':id'', ' || value_id || '::text)
            			from cmn_finder f where f.id = ' || finder_id) into finder_query;
            		execute(finder_query) into value_id, value_name;
            	else value_name := value_id;
            	end if;

            	if ($2) then
            		value_name := type_name || ': ' || value_name;
            	end if;

            	RETURN value_name;
            END;
$$;

