CREATE FUNCTION copy_comment(src_tbl character varying, src_col integer, dst_tbl character varying, dst_col character varying)
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
        src_tbl ALIAS FOR $1;
        src_col ALIAS FOR $2;
        dst_tbl ALIAS FOR $3;
        dst_col ALIAS FOR $4;
        row RECORD;
        oid INT;
        comment VARCHAR;
        BEGIN
            FOR row IN EXECUTE 'SELECT DISTINCT tableoid FROM ' || quote_ident(src_tbl) LOOP --получаем oid исходной таблицы, переданной параметром
            oid := row.tableoid;
            END LOOP;
            IF oid IS NOT NULL THEN -- если iod для текущей таблицы существует
                 FOR row IN EXECUTE 'SELECT col_description(' || quote_literal(oid) || ',' || quote_literal(src_col) || ')' LOOP -- получаем комментарий для исходной таблицы и колонки, переданной параментром
                     comment := row.col_description;
                END LOOP;
                 EXECUTE 'COMMENT ON COLUMN ' || quote_ident(dst_tbl) || '.' || quote_ident(dst_col) || ' IS ' || quote_literal(concat('',comment)); -- записываем комментарий на целевую таблицу, в колонку с именем, переданной параметром
            END IF;
        END;
$$;

