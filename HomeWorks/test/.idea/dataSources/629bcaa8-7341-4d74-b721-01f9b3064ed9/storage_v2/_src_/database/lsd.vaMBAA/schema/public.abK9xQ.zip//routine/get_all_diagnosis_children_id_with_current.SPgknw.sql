CREATE FUNCTION get_all_diagnosis_children_id_with_current(diagnosis_id_list integer[])
  RETURNS SETOF integer
LANGUAGE plpgsql
AS $$
BEGIN
RETURN QUERY
   WITH RECURSIVE temp1 ( id, parent_id, is_leaf ) AS (
      SELECT d.id, d.parent_id, d.is_leaf
          FROM md_diagnosis d
          WHERE d.id = ANY(diagnosis_id_list)
      union
      select d2.id, d2.parent_id, d2.is_leaf
           FROM md_diagnosis d2
           INNER JOIN temp1 ON( temp1.id = d2.parent_id))
      SELECT id from temp1;
END;
$$;

