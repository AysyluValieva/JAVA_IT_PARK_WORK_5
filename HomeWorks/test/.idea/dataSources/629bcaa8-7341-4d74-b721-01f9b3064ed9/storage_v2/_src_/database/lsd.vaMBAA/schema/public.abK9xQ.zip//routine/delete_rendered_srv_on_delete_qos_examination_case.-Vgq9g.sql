CREATE FUNCTION delete_rendered_srv_on_delete_qos_examination_case()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN

    IF TG_OP = 'DELETE' THEN
        IF (OLD.expertise_service_id is not null) THEN
            delete from sr_srv_rendered where id = OLD.expertise_service_id;
        END IF;
        RETURN OLD;

    END IF;
END;
$$;

