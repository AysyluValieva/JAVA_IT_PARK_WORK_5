CREATE FUNCTION fin_funding_source_type_is_parent(parent_id integer, child_id integer)
  RETURNS boolean
LANGUAGE plpgsql
AS $$
declare
  element integer;
begin

  if fin_funding_source_type_is_parent.parent_id = fin_funding_source_type_is_parent.child_id
      then return true; end if;

  select f.parent_id into element
      from fin_funding_source_type f
      where f.id = fin_funding_source_type_is_parent.child_id;

  if element is not null and fin_funding_source_type_is_parent (fin_funding_source_type_is_parent.parent_id, element)
      then return true; end if;

  return false;
end;
$$;

