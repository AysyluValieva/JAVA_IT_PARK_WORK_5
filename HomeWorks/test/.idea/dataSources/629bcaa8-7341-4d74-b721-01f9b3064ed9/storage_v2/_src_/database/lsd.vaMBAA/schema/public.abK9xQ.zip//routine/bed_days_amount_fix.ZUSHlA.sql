CREATE FUNCTION bed_days_amount_fix(hsprecordid integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
begin
   update hsp_record set bed_days_amount = null where id = hspRecordId;
end;
$$;

