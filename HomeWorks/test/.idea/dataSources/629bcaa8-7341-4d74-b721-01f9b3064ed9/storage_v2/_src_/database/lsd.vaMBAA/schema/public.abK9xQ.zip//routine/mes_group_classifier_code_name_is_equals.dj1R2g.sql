CREATE FUNCTION mes_group_classifier_code_name_is_equals(groupid integer, str character varying)
  RETURNS boolean
LANGUAGE plpgsql
AS $$
declare
  count integer = null;
begin
select count(t) into count from
(
    WITH RECURSIVE temp1 (id, parent_id, code, name, PATH, LEVEL, cycle ) AS (
      SELECT mgc.id, mgc.parent_id, CAST(mgc.name as VARCHAR (250)), CAST(mgc.code as VARCHAR (250)), array[mgc.id], 1 , FALSE
      FROM mc_mes_group_classifier mgc
   union all
      select mgc2.id,
        mgc2.parent_id,
        CAST(temp1.code || ' ' || mgc2.code as VARCHAR (250)),
        CAST(temp1.name || ' ' || mgc2.name as VARCHAR (250)),
        temp1.PATH || mgc2.id,
        LEVEL + 1 ,
        mgc2.id = any (temp1.PATH)
      from mc_mes_group_classifier mgc2
      INNER JOIN temp1 ON( temp1.id= mgc2.parent_id) AND NOT CYCLE
      )

    select code, name from temp1 where id = groupId and level = (select max(level) from temp1 where id = groupId)
    and (upper(code) like '%'||upper(str)||'%' or upper(name) like '%'||upper(str)||'%')
) t;

if count = 1 then return true;
end if;
return false;
end;
$$;

