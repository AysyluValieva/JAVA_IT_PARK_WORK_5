CREATE FUNCTION upd_template_id_fn()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE
    templateId integer;
    cardId integer;
BEGIN
    templateId = (select id from public.qos_exam_card_template where is_active is true limit 1);
    NEW.template_id := templateId;
    RETURN NEW;
END;
$$;

