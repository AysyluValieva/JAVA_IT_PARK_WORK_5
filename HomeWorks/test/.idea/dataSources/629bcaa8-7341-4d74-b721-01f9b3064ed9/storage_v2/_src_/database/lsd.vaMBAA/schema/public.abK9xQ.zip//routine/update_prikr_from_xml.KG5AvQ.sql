CREATE FUNCTION update_prikr_from_xml()
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
	_zap record;
	_prikr pci_patient_reg%rowtype;	
	cnt int;
	dtype int;
	y_dstate int;
	n_dstate int;
	_msg text[];
begin

	select id into dtype from md_reg_type where code = '1';
	select id into y_dstate from md_reg_state where code = '1';
	select id into n_dstate from md_reg_state where code = '2';

			for _zap in select * from tambov_loader_prikr_download t where t.org_id is not null and t.n_zap is not null and exists (select 1 from pim_individual i where i.id = t.id_pac) order by id loop
		_prikr := null;
				_msg := array['Начинаю обработку записи'::text];
		select count(*) into cnt from pci_patient_reg ppr where clinic_id = _zap.org_id and patient_id = _zap.id_pac and type_id = dtype;
		_msg := _msg || 'Найдено '::text || cnt::text || ' соотвествующих прикреплений'::text;
		if cnt = 0 then 
			_msg := _msg || 'Регистрирую новое прикрепление.'::text;
			with cte as (
				select
					nextval('pci_patient_reg_id_seq') as id,
					dtype as type_id, 
					case when _zap.close_date is null or _zap.close_date > current_date then y_dstate else n_dstate end state_id,
					_zap.id_pac as patient_id,
					_zap.org_id as clinic_id,
					'-' as request_uid,
					_zap.start_date as request_dt,
					_zap.start_date as reg_dt,
					_zap.close_date as unreg_dt,	
					true as is_assertion, 
					'Загрузчик прикреплений ' || current_date::text as number_attach
			), bs as (
				insert into pci_patient_reg(id, type_id, state_id, patient_id, clinic_id, request_uid, request_dt, reg_dt, unreg_dt, is_assertion, number_attach)
				select * from cte
			)
			update tambov_loader_prikr_download d set nprikr = ppr from pci_patient_reg ppr, cte where ppr.id = cte.id and d.id = _zap.id;			
			_msg := _msg || 'Прикрепление зарегистрировано.'::text;
		elsif cnt = 1 then

									_msg := _msg || 'Поиск соотвествующего прикрепления'::text;
			select ppr.* into _prikr from pci_patient_reg ppr where ppr.clinic_id =_zap.org_id and ppr.patient_id = _zap.id_pac and type_id = dtype;
			
			if FOUND then 
				_msg := _msg || row_to_json(_prikr)::text || 'Обновляю данные этого прикрепления'::text;
				if _prikr.state_id <> y_dstate or _prikr.request_uid <> '-' 
					or coalesce(_prikr.request_dt, '1900-01-01'::date) <> coalesce(_zap.start_date, '1900-01-01'::date) 
					or coalesce(_prikr.reg_dt, '1900-01-01'::date) <> coalesce(_zap.start_date, '1900-01-01'::date)
					or coalesce(_prikr.unreg_dt, '1900-01-01'::date) <> coalesce(_zap.close_date, '1900-01-01'::date) 
				then 

					update pci_patient_reg ppr set 
						number_attach = coalesce(regexp_replace(nullif(trim(number_attach), ''), '\s?Загрузчик прикреплений\s\d{4}-\d{2}-\d{2}\s?', '') || ' ', '') || 'Загрузчик прикреплений ' || current_date::text,
						state_id = case when _zap.close_date is null or _zap.close_date > current_date then y_dstate else n_dstate end,
						request_uid = '-',
						request_dt = _zap.start_date,
						reg_dt = _zap.start_date,
						unreg_dt = _zap.close_date
					where ppr.id = _prikr.id;
				else
					_msg := _msg || 'Данные совпадают. Нет необходимости обновлять что либо.'::text;
				end if;
			else
				_msg := _msg || 'Ошибка cnt=1, но запись не найдена.'::text;
			end if;
		elsif cnt > 1 then 
			
												select ppr.* into _prikr from pci_patient_reg ppr 
			where type_id = dtype and clinic_id = _zap.org_id and patient_id = _zap.id_pac and ppr.district_id is not null order by reg_dt desc nulls last limit 1;

			if FOUND then 
				
												_msg := _msg || 'Найдно прикрепление с указнным участком прикрепления'::text || row_to_json(_prikr)::text || 'Обновляю данные'::text;
				if _prikr.state_id <> y_dstate or _prikr.request_uid <> '-' 
					or coalesce(_prikr.request_dt, '1900-01-01'::date) <> coalesce(_zap.start_date, '1900-01-01'::date) 
					or coalesce(_prikr.reg_dt, '1900-01-01'::date) <> coalesce(_zap.start_date, '1900-01-01'::date)
					or coalesce(_prikr.unreg_dt, '1900-01-01'::date) <> coalesce(_zap.close_date, '1900-01-01'::date) 
				then 
					update pci_patient_reg ppr set
						number_attach = coalesce(regexp_replace(nullif(trim(number_attach), ''), '\s?Загрузчик прикреплений\s\d{4}-\d{2}-\d{2}\s?', '') || ' ', '') || 'Загрузчик прикреплений ' || current_date::text,
						state_id = case when _zap.close_date is null or _zap.close_date > current_date then y_dstate else n_dstate end, 
						request_uid = '-',
						request_dt = _zap.start_date,
						reg_dt = _zap.start_date,
						unreg_dt = _zap.close_date
					where ppr.id = _prikr.id;
					_msg := _msg || 'Данные обновлены удаляю другие прикрепления'::text;

				else
					_msg := _msg || 'Данные совпадают. Нет необходимости обновлять что либо.'::text;
				end if;

												with cte as (
					select ppr from pci_patient_reg ppr 
					where ppr.clinic_id = _zap.org_id and patient_id = _zap.id_pac and ppr.id <> _prikr.id and type_id = dtype
				), bs as (
					update tambov_loader_prikr_download d set dprikr = c.agg 
					from (select array_agg(row_to_json(cte.ppr)) agg from cte) c where d.id = _zap.id
				)
				delete from pci_patient_reg where id in (select (ppr).id from cte);
				_msg := _msg || 'Обработка окончена'::text;
			else
				
																_msg := _msg || 'Найдено более одного подходящего прикрепления но ни в одном не указан участок прикрепления'::text || 'Выбираю прикрепление с наиболее поздней датой прикрепления.'::text;

				select * into _prikr from pci_patient_reg ppr
				where type_id = dtype and clinic_id = _zap.org_id and patient_id = _zap.id_pac order by reg_dt desc nulls last limit 1;
			
				if FOUND then 
					_msg := _msg || row_to_json(_prikr)::text || 'Обновляю данные.'::text;

					if _prikr.state_id <> y_dstate or _prikr.request_uid <> '-' 
						or coalesce(_prikr.request_dt, '1900-01-01'::date) <> coalesce(_zap.start_date, '1900-01-01'::date) 
						or coalesce(_prikr.reg_dt, '1900-01-01'::date) <> coalesce(_zap.start_date, '1900-01-01'::date)
						or coalesce(_prikr.unreg_dt, '1900-01-01'::date) <> coalesce(_zap.close_date, '1900-01-01'::date) 
					then
						update pci_patient_reg ppr set 
							number_attach = coalesce(regexp_replace(nullif(trim(number_attach), ''), '\s?Загрузчик прикреплений\s\d{4}-\d{2}-\d{2}\s?', '') || ' ', '') || 'Загрузчик прикреплений ' || current_time::text,
							state_id = case when _zap.close_date is null or _zap.close_date > current_date then y_dstate else n_dstate end,
							request_uid = '-', 
							request_dt = _zap.start_date, 
							reg_dt = _zap.start_date,
							unreg_dt = _zap.close_date
						where ppr.id = _prikr.id;
					else
						_msg := _msg || 'Данные совпадают. Нет необходимости обновлять что либо.'::text;
					end if;

															_msg := _msg || 'Данные обновлены, удаляю другие прикрепления того же пациента в той же клинике.'::text;
					with cte as (
						select ppr from pci_patient_reg ppr 
						where ppr.clinic_id = _zap.org_id and patient_id = _zap.id_pac and ppr.id <> _prikr.id and type_id = dtype
					), bs as (
						update tambov_loader_prikr_download d set dprikr = c.agg
						from (select array_agg(row_to_json(cte.ppr)) agg from cte) c where d.id = _zap.id
					)
					delete from pci_patient_reg ppr where ppr.id in (select (ppr).id from cte);
					_msg := _msg || 'Обработка закончена'::text;
				end if;
			end if;
		end if;

						with cte as (
			select distinct org_id from tambov_loader_prikr_download where id_pac = _zap.id_pac
		), tz as (
			select ppr.id from pci_patient_reg ppr 
			left join cte on ppr.clinic_id = cte.org_id
			where ppr.patient_id = _zap.id_pac 
				and type_id = (select id from md_reg_type where code='1')
				and cte.org_id is null
		)
		delete from pci_patient_reg where id in (select id from tz);
		update tambov_loader_prikr_download set msg = msg || _msg where id = _zap.id;
	end loop;
end;
$$;

