CREATE FUNCTION calc_patient_reg()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
declare
                begin
                    if (TG_OP = 'DELETE')
                    then
                        update pim_individual set
                        list_reg_name =(
                                select coalesce(rs.name,' ') || ',' || coalesce(pr.reg_dt || '',' ')
                                from md_reg_state rs
                                join pci_patient_reg pr on (pr.state_id = rs.id and pr.patient_id = OLD.patient_id) where pr.state_id = 1
                                union
                                select coalesce(rs.name,' ') || ',' || coalesce(pr.unreg_dt || '',' ')
                                from md_reg_state rs
                                join pci_patient_reg pr on (pr.state_id = rs.id and pr.patient_id = OLD.patient_id) where pr.state_id = 2 limit 1
                        )
                        where id = OLD.patient_id;

                        return OLD;
                    else
                        update pim_individual set
                        list_reg_name =(

                                select coalesce(rs.name,' ') || ',' || coalesce(pr.reg_dt || '',' ')
                                from md_reg_state rs
                                join pci_patient_reg pr on (pr.state_id = rs.id and pr.patient_id = NEW.patient_id) where pr.state_id = 1
                                union
                                select coalesce(rs.name,' ') || ',' || coalesce(pr.unreg_dt || '',' ')
                                from md_reg_state rs
                                join pci_patient_reg pr on (pr.state_id = rs.id and pr.patient_id = NEW.patient_id) where pr.state_id = 2 limit 1

                        )
                        where id = NEW.patient_id;
                        --обновить и "старого" пациента, если меняется patient_id
                        if (TG_OP = 'UPDATE' AND NEW.patient_id <> OLD.patient_id) then
                            update pim_individual set
                            list_reg_name =(
                                    select coalesce(rs.name,' ') || ',' || coalesce(pr.reg_dt || '',' ')
                                    from md_reg_state rs
                                    join pci_patient_reg pr on (pr.state_id = rs.id and pr.patient_id = OLD.patient_id) where pr.state_id = 1
                                    union
                                    select coalesce(rs.name,' ') || ',' || coalesce(pr.unreg_dt || '',' ')
                                    from md_reg_state rs
                                    join pci_patient_reg pr on (pr.state_id = rs.id and pr.patient_id = OLD.patient_id) where pr.state_id = 2 limit 1
                            )
                            where id = OLD.patient_id;
                        end if;

                        return NEW;
                    end if;
                end;
$$;

