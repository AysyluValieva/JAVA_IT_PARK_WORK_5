CREATE FUNCTION check_address_in_district(patient_address_id integer, district_address_id integer, building_number character varying, building_template text)
  RETURNS boolean
LANGUAGE plpgsql
AS $$
DECLARE
    addresses_id integer[];
    buildings text[];
    addresses text;
    building text;
    address_count integer := 0;
    building_count integer := 0;
BEGIN
	if patient_address_id is null or district_address_id is null then
    	return false;
    end if;

    select into addresses_id array_agg(aed.id) from address_element_data aed
    where aed.path <@
    (select path from address_element_data aed2 where aed2.id = district_address_id);

    -- проверка адреса пациента на вхождение в дочерние адреса участка
    select count(*) into address_count from unnest(addresses_id) a where a = patient_address_id;

    -- адрес пациента не входит в дочерние адреса участка
    if address_count = 0 then
    	return false;
    end if;

    -- есть номер дома и есть шаблон
    if building_number is not null and trim(building_number) <> ''
    	and building_template is not null and trim(building_template) <> '' then
        return exists_address_in_building_template(building_number, building_template);
    end if;

    -- есть номер дома и нет шаблона
    if building_number is not null and trim(building_number) <> ''
    	and (building_template is null or trim(building_template) = '') then
        select into buildings array_agg(trim(ae.name))
        from address_element_data aed
        inner join address_element ae
        	inner join address_element_level ael on ael.id = ae.level_id and ael.id = 7
            on ae.id = aed.id
	    where aed.path <@
    	(select path from address_element_data aed2 where aed2.id = district_address_id);
        -- проверка на пустоту массива
        select (select array_length(buildings, 1)) into building_count;
        if building_count = 0 then
        	return false;
        else
        	select array_to_string(buildings, ',') into addresses;
            return exists_address_in_building_template(building_number, addresses);
        end if;
    end if;

    -- нет номера дома и есть шаблон
    if (building_number is null or trim(building_number) = '')
    	and building_template is not null and trim(building_template) <> '' then
        select into building trim(ae.name)
        from address_element ae
        	inner join address_element_level ael on ael.id = ae.level_id and ael.id = 7
	    where ae.id = patient_address_id;

        if building is null or building = '' then
        	return false;
        else
        	return exists_address_in_building_template(building, building_template);
        end if;
    end if;

    -- нет номера дома и нет шаблона
    if address_count <> 0 then
    	return true;
    end if;

    return false;
END;
$$;

