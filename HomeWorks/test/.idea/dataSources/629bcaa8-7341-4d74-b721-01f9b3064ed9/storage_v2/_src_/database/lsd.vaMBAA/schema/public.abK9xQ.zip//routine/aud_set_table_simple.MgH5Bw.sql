CREATE FUNCTION aud_set_table_simple(target_table regclass)
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
BEGIN
   perform aud_set_table(target_table, true, true, null);
END;
$$;

