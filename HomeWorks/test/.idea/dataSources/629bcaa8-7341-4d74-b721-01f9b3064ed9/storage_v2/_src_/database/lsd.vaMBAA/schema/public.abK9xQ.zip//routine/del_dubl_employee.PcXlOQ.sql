CREATE FUNCTION del_dubl_employee(pid_del integer, pid_upd integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
BEGIN
UPDATE pim_employee e SET callup_subject_id = ee.callup_subject_id
FROM pim_employee ee
WHERE ee.callup_subject_id is not null AND ee.id = pid_del 
   AND e.callup_subject_id is null AND e.id = pid_upd;
    
UPDATE pim_employee e SET number = ee.number
FROM pim_employee ee
WHERE ee.number is not null AND ee.id = pid_del 
   AND e.number is null AND e.id = pid_upd;
 
UPDATE pim_employee e SET employment_dt = ee.employment_dt
FROM pim_employee ee
WHERE ee.employment_dt is not null AND ee.id = pid_del 
   AND e.employment_dt is null AND e.id = pid_upd;
 
UPDATE pim_employee e SET is_dismissed = ee.is_dismissed
FROM pim_employee ee
WHERE ee.is_dismissed = TRUE AND ee.id = pid_del 
   AND e.is_dismissed = FALSE AND e.id = pid_upd;
 
UPDATE pim_employee e SET note = ee.note
FROM pim_employee ee
WHERE ee.note is not null AND ee.id = pid_del 
   AND e.note is null AND e.id = pid_upd;
 
UPDATE fin_contractor as c SET employee_id = pid_upd WHERE employee_id = pid_del;
 
UPDATE inv_authorization as a SET employee_id = pid_upd WHERE employee_id = pid_del;
 
UPDATE inv_opr as o SET init_employee_id = pid_upd WHERE init_employee_id = pid_del;
 
UPDATE inv_opr as o SET contractor_employee_id = pid_upd WHERE contractor_employee_id = pid_del;
 
UPDATE pim_employee_position SET employee_id = pid_upd WHERE employee_id = pid_del;
 
UPDATE md_employee_resource as r SET employee_id = pid_upd WHERE r.employee_id = pid_del; 
 
UPDATE pci_patient as p SET empl_state_death_id = pid_upd WHERE empl_state_death_id = pid_del; 
 
UPDATE pci_patient_job SET employee_id = pid_upd WHERE employee_id = pid_del; 
 
UPDATE pim_employee_certificate as c SET employee_id = pid_upd WHERE employee_id = pid_del;
 
UPDATE pim_employee_education SET employee_id = pid_upd WHERE employee_id = pid_del;
 
UPDATE pim_employee_reward SET employee_id = pid_upd WHERE employee_id = pid_del;
 
UPDATE pim_employee_to_speciality SET employee_id = pid_upd WHERE employee_id = pid_del;
 
UPDATE md_quotum_refer_employee SET employee_id = pid_upd WHERE employee_id = pid_del;
 
DELETE FROM pim_employee WHERE id = pid_del;
 
END;
$$;

