CREATE VIEW pim_indiv_doc AS
  SELECT pim_indiv_doc_detail.id,
    pim_indiv_doc_detail.is_active,
    pim_indiv_doc_detail.expire_dt,
    pim_indiv_doc_detail.issue_dt,
    pim_indiv_doc_detail.issuer_text,
    pim_indiv_doc_detail.note,
    pim_indiv_doc_detail.birth_dt,
    pim_indiv_doc_detail.contract_number,
    pim_indiv_doc_detail.name,
    pim_indiv_doc_detail.patr_name,
    pim_indiv_doc_detail.surname,
    pim_indiv_doc_detail.issuer_id,
    pim_indiv_doc_detail.doc_id,
    pim_indiv_doc_detail.verific_dt,
    pim_indiv_doc_detail.birth_place,
    pim_individual_doc.code_id,
    pim_individual_doc.indiv_id
   FROM (pim_indiv_doc_detail
     LEFT JOIN pim_individual_doc ON ((pim_individual_doc.id = pim_indiv_doc_detail.doc_id)));

COMMENT ON VIEW pim_indiv_doc IS 'deprecated;Документы индивида';

COMMENT ON COLUMN pim_indiv_doc.id IS 'Идентификатор';

COMMENT ON COLUMN pim_indiv_doc.is_active IS 'Действующий?';

COMMENT ON COLUMN pim_indiv_doc.expire_dt IS 'Дата истечения срога действия';

COMMENT ON COLUMN pim_indiv_doc.issue_dt IS 'Дата выдачи';

COMMENT ON COLUMN pim_indiv_doc.issuer_text IS 'Выдавшая организация, текст';

COMMENT ON COLUMN pim_indiv_doc.note IS 'Примечание';

COMMENT ON COLUMN pim_indiv_doc.birth_dt IS 'Дата рождения';

COMMENT ON COLUMN pim_indiv_doc.contract_number IS 'Номер контракта';

COMMENT ON COLUMN pim_indiv_doc.name IS 'Имя';

COMMENT ON COLUMN pim_indiv_doc.patr_name IS 'Отчество';

COMMENT ON COLUMN pim_indiv_doc.surname IS 'Фамилия';

COMMENT ON COLUMN pim_indiv_doc.issuer_id IS 'Выдавшая организация';

COMMENT ON COLUMN pim_indiv_doc.doc_id IS 'deprecated;';

COMMENT ON COLUMN pim_indiv_doc.verific_dt IS 'deprecated;';

COMMENT ON COLUMN pim_indiv_doc.birth_place IS 'deprecated;';

COMMENT ON COLUMN pim_indiv_doc.code_id IS 'deprecated;';

COMMENT ON COLUMN pim_indiv_doc.indiv_id IS 'deprecated;';

