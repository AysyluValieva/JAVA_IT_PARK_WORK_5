CREATE FUNCTION select_pim_department_children_list(integer)
  RETURNS SETOF integer
LANGUAGE SQL
AS $$
WITH RECURSIVE included_departments(id) AS (
                SELECT id FROM pim_department WHERE parent_id = $1
                    UNION
                SELECT idep.id
                FROM included_departments idep, pim_department pd
                WHERE pd.parent_id = idep.id
            )
            SELECT id FROM included_departments;
$$;

