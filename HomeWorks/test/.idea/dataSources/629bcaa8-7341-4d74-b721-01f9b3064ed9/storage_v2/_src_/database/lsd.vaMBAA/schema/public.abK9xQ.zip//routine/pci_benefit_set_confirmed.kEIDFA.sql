CREATE FUNCTION pci_benefit_set_confirmed()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
            IF
            new.benefit_reg_in_id IS NOT NULL
            THEN
            NEW.is_confirmed = TRUE;
            ELSE
            NEW.is_confirmed = FALSE;
            END IF;
            RETURN new;
            END;
$$;

