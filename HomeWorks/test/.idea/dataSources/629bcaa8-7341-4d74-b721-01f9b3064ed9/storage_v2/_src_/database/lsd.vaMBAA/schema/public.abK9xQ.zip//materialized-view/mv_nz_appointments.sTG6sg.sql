CREATE MATERIALIZED VIEW mv_nz_appointments AS WITH srg AS (
         SELECT srg.id,
            srg.org_id,
            COALESCE(srg.department_id, pp.department_id) AS department_id,
            pp.speciality_id
           FROM ((sr_res_group srg
             LEFT JOIN pim_employee_position pep ON ((pep.id = srg.responsible_id)))
             LEFT JOIN pim_position pp ON ((pp.id = pep.position_id)))
          WHERE (NOT srg.is_system)
        ), dset AS (
         SELECT ma.id,
            ma.executor_id,
            ma.state_id,
            ma.source_id,
            x.id AS democube_days_id,
            i.gender_id,
            srg.org_id,
            srg.department_id,
            srg.speciality_id,
            date_part('year'::text, age(((ma.bdatetime)::date)::timestamp with time zone, (i.birth_dt)::timestamp with time zone)) AS age
           FROM (((md_appointment ma
             JOIN cube_days x ON ((x.calendar_date = (ma.bdatetime)::date)))
             JOIN pim_individual i ON (((i.id = ma.customer_id) AND (i.gender_id = ANY (ARRAY[1, 2])) AND (i.birth_dt IS NOT NULL))))
             JOIN srg ON ((srg.id = ma.executor_id)))
        )
 SELECT dset.org_id,
    dset.gender_id,
    dset.state_id,
    dset.source_id,
    dset.department_id,
    dset.speciality_id,
    dset.executor_id,
    dset.democube_days_id,
        CASE
            WHEN ((dset.gender_id = 1) AND (dset.age >= (16)::double precision) AND (dset.age <= (59)::double precision)) THEN 1
            WHEN ((dset.gender_id = 1) AND (dset.age >= (60)::double precision)) THEN 2
            WHEN ((dset.gender_id = 1) AND (dset.age < (16)::double precision)) THEN 5
            WHEN ((dset.gender_id = 2) AND (dset.age >= (16)::double precision) AND (dset.age <= (54)::double precision)) THEN 3
            WHEN ((dset.gender_id = 2) AND (dset.age >= (55)::double precision)) THEN 4
            WHEN ((dset.gender_id = 2) AND (dset.age < (16)::double precision)) THEN 7
            ELSE NULL::integer
        END AS age_category_2_id,
        CASE
            WHEN (dset.age = (0)::double precision) THEN 1
            WHEN (dset.age <= (3)::double precision) THEN 2
            WHEN (dset.age <= (5)::double precision) THEN 3
            WHEN (dset.age <= (7)::double precision) THEN 4
            WHEN (dset.age <= (14)::double precision) THEN 5
            WHEN (dset.age <= (15)::double precision) THEN 6
            WHEN (dset.age <= (17)::double precision) THEN 7
            ELSE 8
        END AS age_category_3_id,
    count(dset.id) AS ma_cnt
   FROM dset
  GROUP BY dset.org_id, dset.gender_id, dset.state_id, dset.source_id, dset.department_id, dset.speciality_id, dset.executor_id, dset.democube_days_id,
        CASE
            WHEN ((dset.gender_id = 1) AND (dset.age >= (16)::double precision) AND (dset.age <= (59)::double precision)) THEN 1
            WHEN ((dset.gender_id = 1) AND (dset.age >= (60)::double precision)) THEN 2
            WHEN ((dset.gender_id = 1) AND (dset.age < (16)::double precision)) THEN 5
            WHEN ((dset.gender_id = 2) AND (dset.age >= (16)::double precision) AND (dset.age <= (54)::double precision)) THEN 3
            WHEN ((dset.gender_id = 2) AND (dset.age >= (55)::double precision)) THEN 4
            WHEN ((dset.gender_id = 2) AND (dset.age < (16)::double precision)) THEN 7
            ELSE NULL::integer
        END,
        CASE
            WHEN (dset.age = (0)::double precision) THEN 1
            WHEN (dset.age <= (3)::double precision) THEN 2
            WHEN (dset.age <= (5)::double precision) THEN 3
            WHEN (dset.age <= (7)::double precision) THEN 4
            WHEN (dset.age <= (14)::double precision) THEN 5
            WHEN (dset.age <= (15)::double precision) THEN 6
            WHEN (dset.age <= (17)::double precision) THEN 7
            ELSE 8
        END;

CREATE INDEX mv_nz_appointments_org_id_inx
  ON mv_nz_appointments (org_id);

CREATE INDEX mv_nz_appointments_gender_id_inx
  ON mv_nz_appointments (gender_id);

CREATE INDEX mv_nz_appointments_state_id_inx
  ON mv_nz_appointments (state_id);

CREATE INDEX mv_nz_appointments_source_id_inx
  ON mv_nz_appointments (source_id);

CREATE INDEX mv_nz_appointments_department_id_inx
  ON mv_nz_appointments (department_id);

CREATE INDEX mv_nz_appointments_speciality_id_inx
  ON mv_nz_appointments (speciality_id);

CREATE INDEX mv_nz_appointments_executor_id_inx
  ON mv_nz_appointments (executor_id);

CREATE INDEX mv_nz_appointments_democube_days_id_inx
  ON mv_nz_appointments (democube_days_id);

CREATE INDEX mv_nz_appointments_age_category_2_id_inx
  ON mv_nz_appointments (age_category_2_id);

CREATE INDEX mv_nz_appointments_age_category_3_id_inx
  ON mv_nz_appointments (age_category_3_id);

