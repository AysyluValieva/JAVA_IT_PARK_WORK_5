CREATE FUNCTION temp_ts_dn_1(individual_id integer, date date)
  RETURNS character varying
LANGUAGE plpgsql
AS $$
declare
    i integer;
begin
    i = (select fin_individual__get_active_policy(individual_id, date));
    if i is null then return null;
    end if;
    return (select coalesce(pic.code, coalesce(pid.number,'')) from pim_individual_doc pid
              left join pim_indiv_code pic on pic.id = pid.code_id
              where pid.id = i);
end;
$$;

