CREATE MATERIALIZED VIEW mv_reg AS SELECT r.clinic_id,
    COALESCE(r.district_by_addr_id, r.district_id) AS district_id,
        CASE i.gender_id
            WHEN 1 THEN
            CASE
                WHEN (date_part('year'::text, age((x.calendar_date)::timestamp with time zone, (i.birth_dt)::timestamp with time zone)) <= (17)::double precision) THEN 1
                WHEN ((date_part('year'::text, age((x.calendar_date)::timestamp with time zone, (i.birth_dt)::timestamp with time zone)) >= (18)::double precision) AND (date_part('year'::text, age((('now'::text)::date)::timestamp with time zone, (i.birth_dt)::timestamp with time zone)) <= (59)::double precision)) THEN 2
                WHEN (date_part('year'::text, age((x.calendar_date)::timestamp with time zone, (i.birth_dt)::timestamp with time zone)) >= (60)::double precision) THEN 3
                ELSE NULL::integer
            END
            WHEN 2 THEN
            CASE
                WHEN (date_part('year'::text, age((x.calendar_date)::timestamp with time zone, (i.birth_dt)::timestamp with time zone)) <= (17)::double precision) THEN 4
                WHEN ((date_part('year'::text, age((x.calendar_date)::timestamp with time zone, (i.birth_dt)::timestamp with time zone)) >= (18)::double precision) AND (date_part('year'::text, age((('now'::text)::date)::timestamp with time zone, (i.birth_dt)::timestamp with time zone)) <= (54)::double precision)) THEN 5
                WHEN (date_part('year'::text, age((x.calendar_date)::timestamp with time zone, (i.birth_dt)::timestamp with time zone)) >= (55)::double precision) THEN 6
                ELSE NULL::integer
            END
            ELSE NULL::integer
        END AS age_category_id,
    i.gender_id,
    r.type_id,
    p.social_group_id,
    x.calendar_date,
    x.id AS democube_days_id,
    count(DISTINCT
        CASE
            WHEN (((r.reg_dt <= (((x.calendar_date + '1 mon'::interval) - '1 day'::interval))::date) OR (r.reg_dt IS NULL)) AND ((r.unreg_dt >= (((x.calendar_date + '1 mon'::interval) - '1 day'::interval))::date) OR (r.unreg_dt IS NULL))) THEN r.id
            ELSE NULL::integer
        END) AS registration_cnt,
    count(DISTINCT
        CASE
            WHEN (((r.reg_dt <= (((x.calendar_date + '1 mon'::interval) - '1 day'::interval))::date) OR (r.reg_dt IS NULL)) AND ((r.unreg_dt >= (((x.calendar_date + '1 mon'::interval) - '1 day'::interval))::date) OR (r.unreg_dt IS NULL))) THEN r.patient_id
            ELSE NULL::integer
        END) AS patient_cnt,
    count(DISTINCT
        CASE
            WHEN ((date_part('year'::text, r.reg_dt) = (x.year_)::double precision) AND (date_part('month'::text, r.reg_dt) = (x.month_of_year)::double precision)) THEN r.id
            ELSE NULL::integer
        END) AS new_registration_cnt,
    count(DISTINCT
        CASE
            WHEN ((date_part('year'::text, r.reg_dt) = (x.year_)::double precision) AND (date_part('month'::text, r.reg_dt) = (x.month_of_year)::double precision)) THEN r.patient_id
            ELSE NULL::integer
        END) AS new_patient_cnt,
    count(DISTINCT
        CASE
            WHEN ((date_part('year'::text, r.unreg_dt) = (x.year_)::double precision) AND (date_part('month'::text, r.unreg_dt) = (x.month_of_year)::double precision)) THEN r.id
            ELSE NULL::integer
        END) AS unregistration_cnt,
    count(DISTINCT
        CASE
            WHEN ((date_part('year'::text, r.unreg_dt) = (x.year_)::double precision) AND (date_part('month'::text, r.unreg_dt) = (x.month_of_year)::double precision)) THEN r.patient_id
            ELSE NULL::integer
        END) AS unreg_patient_cnt
   FROM (((pci_patient_reg r
     JOIN pim_individual i ON (((r.patient_id = i.id) AND (i.gender_id = ANY (ARRAY[1, 2])) AND (i.birth_dt IS NOT NULL))))
     JOIN cube_days_simple x ON (((((r.reg_dt <= (((x.calendar_date + '1 mon'::interval) - '1 day'::interval))::date) OR (r.reg_dt IS NULL)) AND ((r.unreg_dt >= (((x.calendar_date + '1 mon'::interval) - '1 day'::interval))::date) OR (r.unreg_dt IS NULL))) OR ((date_part('year'::text, r.reg_dt) = (x.year_)::double precision) AND (date_part('month'::text, r.reg_dt) = (x.month_of_year)::double precision)) OR ((date_part('year'::text, r.unreg_dt) = (x.year_)::double precision) AND (date_part('month'::text, r.unreg_dt) = (x.month_of_year)::double precision)))))
     JOIN pci_patient p ON ((i.id = p.id)))
  GROUP BY r.clinic_id, COALESCE(r.district_by_addr_id, r.district_id),
        CASE i.gender_id
            WHEN 1 THEN
            CASE
                WHEN (date_part('year'::text, age((x.calendar_date)::timestamp with time zone, (i.birth_dt)::timestamp with time zone)) <= (17)::double precision) THEN 1
                WHEN ((date_part('year'::text, age((x.calendar_date)::timestamp with time zone, (i.birth_dt)::timestamp with time zone)) >= (18)::double precision) AND (date_part('year'::text, age((('now'::text)::date)::timestamp with time zone, (i.birth_dt)::timestamp with time zone)) <= (59)::double precision)) THEN 2
                WHEN (date_part('year'::text, age((x.calendar_date)::timestamp with time zone, (i.birth_dt)::timestamp with time zone)) >= (60)::double precision) THEN 3
                ELSE NULL::integer
            END
            WHEN 2 THEN
            CASE
                WHEN (date_part('year'::text, age((x.calendar_date)::timestamp with time zone, (i.birth_dt)::timestamp with time zone)) <= (17)::double precision) THEN 4
                WHEN ((date_part('year'::text, age((x.calendar_date)::timestamp with time zone, (i.birth_dt)::timestamp with time zone)) >= (18)::double precision) AND (date_part('year'::text, age((('now'::text)::date)::timestamp with time zone, (i.birth_dt)::timestamp with time zone)) <= (54)::double precision)) THEN 5
                WHEN (date_part('year'::text, age((x.calendar_date)::timestamp with time zone, (i.birth_dt)::timestamp with time zone)) >= (55)::double precision) THEN 6
                ELSE NULL::integer
            END
            ELSE NULL::integer
        END, i.gender_id, r.type_id, p.social_group_id, x.calendar_date, x.id;

CREATE INDEX mv_reg_clinic_id_inx
  ON mv_reg (clinic_id);

CREATE INDEX mv_reg_district_id_inx
  ON mv_reg (district_id);

CREATE INDEX mv_reg_age_category_id_inx
  ON mv_reg (age_category_id);

CREATE INDEX mv_reg_gender_id_inx
  ON mv_reg (gender_id);

CREATE INDEX mv_reg_social_group_id_inx
  ON mv_reg (type_id);

CREATE INDEX mv_reg_type_id_inx
  ON mv_reg (type_id);

CREATE INDEX mv_reg_calendar_date_inx
  ON mv_reg (calendar_date);

CREATE INDEX mv_reg_democube_days_id_inx
  ON mv_reg (democube_days_id);

