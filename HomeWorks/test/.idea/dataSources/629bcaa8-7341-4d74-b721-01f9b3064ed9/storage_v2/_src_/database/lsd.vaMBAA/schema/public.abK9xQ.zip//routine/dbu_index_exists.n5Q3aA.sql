CREATE FUNCTION dbu_index_exists(tablename character varying, schemaname character varying, columnname character varying)
  RETURNS boolean
LANGUAGE plpgsql
AS $$
DECLARE result boolean;
            BEGIN
            SELECT count(ci.relname) into result
            FROM pg_index i, pg_class ci, pg_attribute a, pg_class c, pg_namespace n
            WHERE c.relname ~~ $1
            AND n.nspname ~~ $2
            AND n.oid = c.relnamespace
            AND ci.oid = i.indexrelid
            AND i.indrelid = c.oid
            AND i.indnatts = 1
            AND a.attname = $3
            AND a.attrelid = c.oid
            AND not i.indisprimary
            AND string_to_array(i.indkey::text, ' ')::int2[] = ARRAY[a.attnum];

            RETURN result;

            END;
$$;

