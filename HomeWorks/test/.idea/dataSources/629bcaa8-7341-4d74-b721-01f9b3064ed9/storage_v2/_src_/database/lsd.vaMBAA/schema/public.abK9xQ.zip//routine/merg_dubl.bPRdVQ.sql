CREATE FUNCTION merg_dubl(pid_upd integer, pid_del integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
_r record;
_code integer[];
_tab text[]:=array['mc_case','mc_diagnosis','md_patient_prescription','md_referral','md_sicklist','md_receipt','fin_contract_to_patient','sr_srv_rendered','md_appointment','pci_dispensary','pim_indiv_agreement'];
begin
--Проверка на сотрудников
if exists(select 1 from pim_employee where individual_id in ($2)) then
raise exception 'Пациент не должен является сотрудником';  
end if;
--перенос случаев,диагнозов,назначений,направлений,больничных листов,рецептов,контрактов,услуг,талонов,диспансерного учета,соглашений
for _r in
select tc.constraint_schema, tc.table_name, kcu.column_name
from information_schema.table_constraints as tc
join information_schema.key_column_usage as kcu on tc.constraint_name = kcu.constraint_name
join information_schema.constraint_column_usage as ccu on ccu.constraint_name = tc.constraint_name
where 1=1
and constraint_type = 'FOREIGN KEY'
and ccu.table_name in('pim_individual','pci_patient')
and tc.table_name=any(_tab)
loop
--raise notice 'update %',_r.table_name;
execute 'update '||_r.table_name||' set '||_r.column_name||'='||$1||' where '||_r.column_name||'='||$2||';';
end loop;
--Перенос кодов и связанных с ними информации в доках со второго на первого пациента
--если код у второго присутствует у первого, то не переносим
for _r in select distinct type_id from pim_indiv_code where indiv_id=$2 order by 1 loop
if
    not exists(select 1 from pim_indiv_code where type_id=_r.type_id and indiv_id=$1)
then
    select array_agg(id) into _code from pim_indiv_code where indiv_id=$2 and type_id=_r.type_id;
    update pim_indiv_code set indiv_id=$1 where id=any(_code);
    update pim_individual_doc set indiv_id=$1 where code_id=any(_code);
end if;
end loop;
--Для ИЭМК2 апдейт отдельно поскольку изменяем два поля
if exists(select 1 from iehr_pix_registry where patient_id=$2) then
--raise notice 'Удаляемый пациент присутсвует в ИЭМК2';
update iehr_pix_registry set patient_id=$1,
pix_uid=substring(pix_uid,1, strpos(pix_uid,'^'))||(select code from pim_indiv_code where indiv_id=$1 and type_id=(select id from pim_code_type where code='UID') limit 1)
where patient_id=$2;
end if;
--Удаление второго пациента
delete from pim_individual_doc where indiv_id=$2;
delete from pim_indiv_code where indiv_id=$2;
delete from pim_party_addr_to_addr_type where exists(select 1 from pim_party_address where id=pim_party_addr_to_addr_type.party_address_id and party_id=$2);
update pci_patient_reg set address_id=null where address_id in(select id from pim_party_address where party_id=$2);
delete from pim_party_address where party_id=$2;
delete from pim_party_role_to_party where party_id=$2;
delete from pim_citizenship where individual_id=$2;
delete from pci_patient where id=$2;
delete from pim_individual where id=$2;
delete from pim_party where id=$2;
end;
$$;

