CREATE FUNCTION is_case_in_bills(case_id integer)
  RETURNS boolean
LANGUAGE plpgsql
AS $$
begin
return (select EXISTS (
        SELECT
            billspecif23_. ID
        FROM
            fin_bill_spec_item billspecif23_
        INNER JOIN sr_srv_rendered medicalser24_ ON billspecif23_.service_id = medicalser24_. ID
        CROSS JOIN fin_bill bill25_
        WHERE
            billspecif23_.bill_id = bill25_. ID
        AND medicalser24_.md_case_id = case_id
        AND bill25_.status_id <> 0));
end;
$$;

