CREATE FUNCTION add_user_role_all_clinics_full_access(id_user integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
begin
insert into sec_user_org (id, user_id, org_id) select nextval ('sec_user_org_seq'), $1, id from md_clinic where id not in (select org_id from sec_user_org where user_id = $1);
end;
$$;

