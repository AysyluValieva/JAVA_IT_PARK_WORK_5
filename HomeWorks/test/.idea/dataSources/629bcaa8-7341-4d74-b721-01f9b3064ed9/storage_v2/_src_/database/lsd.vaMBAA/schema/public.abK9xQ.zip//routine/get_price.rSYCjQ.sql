CREATE FUNCTION get_price(r_id integer)
  RETURNS numeric
LANGUAGE plpgsql
AS $$
declare rec record;
        p numeric;
        q numeric;
        b numeric;
        a numeric;
        f integer;
        c numeric;
        cc numeric;
        ff boolean;
begin
 execute 'select cost*quantity from sr_srv_rendered where id='|| r_id into c;
 execute 'select is_has_service_priority from sr_srv_rendered r left join fin_bill_price_formation f on f.id=r.funding_id where r.id='|| r_id into ff;
 if ff and c is not null then return c; end if;
 
 b:=1;
 a:=0;
 for rec in 
 (
 with
sp as
(select clinic_service_id srv_id, pl_position_id pos_id, row_number() over(partition by clinic_service_id order by pl_position_id desc) rn from fin_pl_pos_to_clinic_srv)

select pm.type, value,p.price, condition, quantity, cost, row_number() over(partition by 1 order by 1) rn  from sr_srv_rendered r
join sp on sp.srv_id=r.service_id
join fin_pl_position p on p.id=sp.pos_id 
join fin_price_list pl on pl.id=p.price_list_id
join fin_price_modifier pm on pm.price_list_id=pl.id 
where r.id=r_id
)

loop 

p:=rec.price;
q:=rec.quantity;
if rec.type=1 and rec.condition='' then b:=b*rec.value; end if;
  if rec.type=1 and rec.condition!='' then 
    execute 'select 1 from sr_srv_rendered where '||rec.condition || ' and id='||r_id into f; 
    if f!=1 then b:=b*rec.value; end if;
  end if;

if rec.type=2 and rec.condition='' then a:=a+rec.value; end if;
  if rec.type=2 and rec.condition!='' then 
    execute 'select 1 from sr_srv_rendered where '||rec.condition || ' and id='||r_id into f; 
    if f!=1 then a:=a+rec.value; end if;
  end if;

end loop;

cc:=(p+a)*b*q;

if (ff=false or ff is null) and (cc=0 or cc is null) then return c; end if;
return cc;

end;
$$;

