CREATE FUNCTION adr__get_parent_id_with_some_lvl(adr_id integer, lvl_id integer)
  RETURNS integer
STRICT
LANGUAGE plpgsql
AS $$
DECLARE
                 return_adr integer;
              BEGIN
                 SELECT
                  ae.id
                 FROM address_code ac
                 INNER JOIN address_element_data aed
                  ON ac.element_id = aed.id
                 INNER JOIN address_element ae
                  ON ae.id=aed.id
                 INNER JOIN address_element_type aet
                  ON ae.type_id=aet.id
                 WHERE aed.path @> (SELECT path
                  FROM address_element_data
                 WHERE id = adr_id) and book_id=1 and ae.level_id=lvl_id
                 INTO return_adr;
                 RETURN return_adr;
              END;
$$;

