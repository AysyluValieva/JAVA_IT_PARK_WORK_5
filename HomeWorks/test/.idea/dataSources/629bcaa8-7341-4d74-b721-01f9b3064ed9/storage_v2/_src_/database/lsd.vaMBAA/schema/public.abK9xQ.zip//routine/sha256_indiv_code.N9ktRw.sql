CREATE FUNCTION sha256_indiv_code()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE

            BEGIN
            IF    TG_OP = 'INSERT' THEN
            IF (NEW.type_id is not null) THEN
            IF ((select code from pim_code_type where id = NEW.type_id) = 'ENP') THEN
            NEW.sha256 = encode(digest(NEW.code, 'sha256'), 'hex');
            END IF;
            END IF;
            RETURN NEW;
            ELSIF TG_OP = 'UPDATE' THEN
            IF (NEW.type_id is not null) THEN
            IF ((select code from pim_code_type where id = NEW.type_id) = 'ENP') THEN
            NEW.sha256 = encode(digest(NEW.code, 'sha256'), 'hex');
            END IF;
            END IF;
            RETURN NEW;
            END IF;
            END;
$$;

