CREATE VIEW sec_user_session_counter AS
  SELECT su.id,
    cut.count
   FROM (cas_user_tgt_counter cut
     JOIN sec_user su ON (((cut.username)::text = (su.login)::text)));

