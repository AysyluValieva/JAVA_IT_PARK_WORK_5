CREATE FUNCTION mdm_table_record__get(xversion_id integer, xid character varying)
  RETURNS record
LANGUAGE plpgsql
AS $$
declare
  retval record;
begin

  select * into retval from mdm_table_record
    where record_id = xid and xversion_id = refbook_id;

  return retval;

end;
$$;

