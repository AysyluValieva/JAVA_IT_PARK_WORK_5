CREATE FUNCTION insert_enp_polis(npolis text, stdate date, enddate date, id_pac integer, smo_org_id integer, _note text)
  RETURNS pim_individual_doc
LANGUAGE plpgsql
AS $$
declare
	_id int;
	_iid int;
	_polis pim_individual_doc%rowtype;
begin
	_id := nextval('pim_indiv_code_id_seq');
	_iid := nextval('pim_individual_doc_id_seq');
	
	with cte as (select 
		_id as id,
		$1 as code, 
		$2 as issue_dt, 
		(select id from pim_code_type where code='ENP') as type_id, 
		$4 as indiv_id
	)
	insert into pim_indiv_code(id, code, issue_dt, type_id, indiv_id) 
	select * from cte;

	with cte as ( select 
		_iid id, 
		$1 as "number", 
		$2 as issue_dt, 
		$3 as expire_dt, 
		$4 as indiv_id, 
		$5 as issuer_id, 
		$6 as note,
		(select id from pim_doc_type where code='MHI_UNIFORM') as type_id,
		case when $3 < current_date then false else true end as is_active
	)
	insert into pim_individual_doc(id, "number", issue_dt, expire_dt, indiv_id, issuer_id, note, type_id, is_active)
	select * from cte;

	select * into _polis from pim_individual_doc where id = _iid;
	return _polis;
end;
$$;

