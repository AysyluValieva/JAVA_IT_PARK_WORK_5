CREATE FUNCTION get_columns_of_table(schema_name character varying, tbl_name character varying)
  RETURNS SETOF character varying
LANGUAGE SQL
AS $$
SELECT cols.column_name FROM information_schema.columns as cols WHERE table_schema = $1 AND table_name = $2 ;
$$;

