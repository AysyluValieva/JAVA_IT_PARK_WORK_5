CREATE FUNCTION mc_step_trigger_update_trgf()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE
        clinic_id integer;
        patient_id integer;
BEGIN
        select into clinic_id, patient_id c.clinic_id, c.patient_id from mc_case c where id = NEW.case_id;
        NEW._clinic_id := clinic_id;
        NEW._patient_id := patient_id;

        RETURN NEW;
END;
$$;

