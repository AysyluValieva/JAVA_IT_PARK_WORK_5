CREATE FUNCTION get_case_duration(caseid integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
begin
                        return (
                            select (case when c.case_type_id in (2, 10, 11)
                                    then (select get_bed_day_amount_n2o(c.id))
                                    else (case when c.closing_step_id is not null then c.close_date - c.open_date else now()::date - c.open_date end ) + 1
                                end)
                            from mc_case c
                            where c.id = caseId
                        );
                    end;
$$;

