CREATE FUNCTION upd_pat_address(xid integer, xpatient integer, xreg_type integer, xaddress integer, xfrom_date date, xto_date date, xis_valid boolean, xtext_addr character varying, xnote character varying, xaddr_type integer[])
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
                xaddr integer;
                res record;
                xtype integer;
                is_val boolean;
              begin
                  is_val = case when xfrom_date is null and xto_date is null
                            then xis_valid
                            else null
                         end;
                  update public.pim_party_address set register_type_id = xreg_type,addr_id = xaddress,from_date = xfrom_date,to_date = xto_date,is_valid = is_val,
                    text_addr = xtext_addr,note = xnote where id = xid;
                  -- добавлено условие , что address_type_id in ('ACTUAL','REGISTER'), так как "затачиваем под адреса пациента из панели пациента"
                  foreach xtype in array xaddr_type loop
                     if array_length(xaddr_type, 1) = 1
                        then
                            if (select count(*) from public.pim_party_addr_to_addr_type where party_address_id = xid and address_type_id in (select id from public.pim_address_type where code in ('ACTUAL','REGISTER'))) = 1
                                then update public.pim_party_addr_to_addr_type set address_type_id = xtype where party_address_id = xid and address_type_id in (select id from public.pim_address_type where code in ('ACTUAL','REGISTER'));
                                else delete from public.pim_party_addr_to_addr_type where party_address_id = xid and address_type_id <> xtype
                                        and address_type_id in (select id from public.pim_address_type where code in ('ACTUAL','REGISTER'));
                            end if;
                        else
                            if (select count(*) from public.pim_party_addr_to_addr_type where party_address_id = xid and address_type_id in (select id from public.pim_address_type where code in ('ACTUAL','REGISTER'))) = 1
                                then
                                    if xtype <> (select address_type_id from public.pim_party_addr_to_addr_type where party_address_id = xid and address_type_id in (select id from public.pim_address_type where code in ('ACTUAL','REGISTER')))
                                        then insert into public.pim_party_addr_to_addr_type(id,party_address_id,address_type_id)
                                                values (nextval('public.pim_party_addr_to_addr_type_seq'),xid,xtype);
                                    end if;
                            end if;
                     end if;

                     if (cast(now() as date) >= xfrom_date and (xto_date >= cast(now() as date) or xto_date is null))
                      then
                          for res in (select ppa.id from public.pim_party_address ppa
                                  join pim_party_addr_to_addr_type ppatat on ppatat.party_address_id = ppa.id
                                  where ppa.party_id = xpatient
                                      and ppatat.address_type_id = xtype
                                      and (ppa.is_valid is true or ppa.from_date is not null and ppa.to_date is null)
                                      and ppa.id <> xid
                                  )
                          loop
                              update public.pim_party_address set is_valid = null,to_date = cast(xfrom_date - cast('1 day' as interval) as date) where id = res.id;
                          end loop;
                     end if;
                   end loop;
                  return xid;
              end;
$$;

