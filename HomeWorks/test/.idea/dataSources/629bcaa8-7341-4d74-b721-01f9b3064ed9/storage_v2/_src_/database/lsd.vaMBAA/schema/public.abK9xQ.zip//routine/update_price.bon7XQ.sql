CREATE FUNCTION update_price(n_price text, _mo text)
  RETURNS SETOF text[]
LANGUAGE plpgsql
AS $$
declare 
	mo int;
	_msg text[];
	new_price numeric;
	_price fin_price_list%rowtype;
	_position fin_pl_position%rowtype;
begin
	mo := nullif(_mo, '');
	n_price := regexp_replace(n_price, ',', '.');
	new_price := n_price::numeric(19,2);
	for _price in select * from fin_price_list where commentary = 'hospital' and to_dt is null and (clinic_id = mo or mo is null)
	loop
		_msg := array['---------------------------------------------------------------------------------------------------------'];
		_msg:=  _msg || 'Начало обработки.'::text || concat('Клиника № ', _price.clinic_id)::text;
		_msg := _msg || concat(_price."name", '   ',  _price.commentary, '   ',coalesce(_price.to_dt::text, 'Дата закрытия Открыта'))::text;
		_msg := _msg || 'Ищу позиции для этого прейскуранта'::text;
		for _position in select * from fin_pl_position 
			where price_list_id = _price.id and upper(code) = 'HCSG' and upper("name") = upper('Пребывание в круглосуточном стационаре (КСГ)')
		loop
			_msg := _msg || concat('Обрабатываю позицию № ', _position.id::text)::text;
			_msg := _msg || 'Старое значение цены услуги'::text || _position.price::text;
			if _position.price = new_price then 
				_msg := _msg || 'Цена услуги совпадает'::text || 'Необходимости в обновлении нет'::text || 'Пропускаю обновление цены услуги позиции'::text;
			else 
				_msg := _msg || 'Значение не совпадает'::text || 'Обновляю цену услуги'::text;
				update fin_pl_position set price = new_price where id = _position.id;
				_msg := _msg || 'Успешно обновлено'::text || 'Новое значение цены услуги'::text || new_price::text;
			end if;
			_msg := _msg || 'Завершено'::text;
		end loop;
		return next _msg;
	end loop;
end;
$$;

