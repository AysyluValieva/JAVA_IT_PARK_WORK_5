CREATE FUNCTION mdm_table_record__get(tbl_name character varying, xid character varying)
  RETURNS record
LANGUAGE plpgsql
AS $$
declare
  retval record;
begin

  select * into retval from mdm_table_record
    where record_id = xid and mdm_table__get_refbook_version_id(tbl_name) = refbook_id;

  return retval;

end;
$$;

