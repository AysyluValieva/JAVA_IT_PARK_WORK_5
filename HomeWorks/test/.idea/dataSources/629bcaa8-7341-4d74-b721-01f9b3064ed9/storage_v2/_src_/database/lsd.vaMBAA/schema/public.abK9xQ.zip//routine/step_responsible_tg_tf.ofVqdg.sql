CREATE FUNCTION step_responsible_tg_tf()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
      IF (TG_TABLE_NAME = 'mc_step') THEN
        UPDATE mc_step set _responsible_id = g.responsible_id FROM sr_res_group g  WHERE mc_step.id = NEW.id and g.id = NEW.res_group_id;
      ELSEIF (TG_TABLE_NAME = 'sr_res_group') THEN
        UPDATE mc_step set _responsible_id = NEW.responsible_id WHERE res_group_id = NEW.id;
      END IF;
      RETURN NEW;
END;
$$;

