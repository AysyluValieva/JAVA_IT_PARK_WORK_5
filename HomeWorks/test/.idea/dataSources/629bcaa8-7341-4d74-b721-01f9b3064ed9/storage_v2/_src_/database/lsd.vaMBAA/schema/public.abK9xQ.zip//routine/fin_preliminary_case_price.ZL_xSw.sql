CREATE FUNCTION fin_preliminary_case_price(p1_case_id integer)
  RETURNS void
STRICT
LANGUAGE plpgsql
AS $$
BEGIN
    PERFORM billing.preliminary_case_price (p1_case_id);
END;
$$;

