CREATE FUNCTION fin_update_rendered_services_to_res_group(p1_clinic_id integer, p2_from_dt date, p3_to_dt date, p4_case_type_id integer, OUT cnt integer)
  RETURNS integer
STRICT
LANGUAGE plpgsql
AS $$
DECLARE
    _r RECORD;
BEGIN
    cnt := 0
    ;
    FOR _r IN
        SELECT
            r.id, s.res_group_id
        FROM
            sr_srv_rendered AS r, md_srv_rendered AS m, mc_case AS c, mc_step AS s, mc_step AS t
        WHERE
            r.id = m.id AND m.case_id = c.id AND m.step_id = s.id AND c.closing_step_id = t.id
            AND c.clinic_id = p1_clinic_id
            AND t.outcome_date BETWEEN p2_from_dt AND p3_to_dt
            AND c.case_type_id = p4_case_type_id
            AND r.res_group_id IS NULL AND s.res_group_id IS NOT NULL
    LOOP
        UPDATE sr_srv_rendered SET res_group_id = _r.res_group_id WHERE id = _r.id
        ;
        cnt := cnt + 1
        ;
    END LOOP;
END;
$$;

