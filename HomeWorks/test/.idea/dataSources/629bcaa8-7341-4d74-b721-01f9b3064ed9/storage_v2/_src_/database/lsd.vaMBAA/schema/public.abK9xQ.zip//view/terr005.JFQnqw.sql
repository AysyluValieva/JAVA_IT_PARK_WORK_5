CREATE VIEW terr005 AS
  SELECT terr005.cod,
    terr005.short_name,
    terr005.full_name,
    terr005.cod_region,
    terr005.region,
    terr005.cod_f002,
    terr005.dt,
    terr005.org_id
   FROM billing.terr005;

