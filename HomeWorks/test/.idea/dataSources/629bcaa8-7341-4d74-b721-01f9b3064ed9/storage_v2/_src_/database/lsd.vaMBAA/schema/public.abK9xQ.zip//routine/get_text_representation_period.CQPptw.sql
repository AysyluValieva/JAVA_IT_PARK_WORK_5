CREATE FUNCTION get_text_representation_period(measure_id integer, count integer)
  RETURNS character varying
IMMUTABLE
LANGUAGE plpgsql
AS $$
DECLARE
    DAY_MEASURE_ID CONSTANT integer := 8;
    WEEK_MEASURE_ID CONSTANT integer := 7;
    MONTH_MEASURE_ID CONSTANT integer := 6;
    QUARTER_MEASURE_ID CONSTANT integer := 5;
    YEAR_MEASURE_ID CONSTANT integer := 4;
BEGIN
    if (measure_id = DAY_MEASURE_ID) then
        if (count = 1) then
            return 'ежедневно';
        elseif (count > 1) then
            return 'каждые '||count||' дня(ей)';
        end if;
    elseif (measure_id = WEEK_MEASURE_ID) then
        if (count = 1) then
            return 'еженедельно';
        elseif (count > 1) then
            return 'каждые '||count||' недели(ь)';
        end if;
    elseif (measure_id = MONTH_MEASURE_ID) then
        if (count = 1) then
            return 'ежемесячно';
        elseif (count > 1) then
            return 'каждые '||count||' месяца(ев)';
        end if;
    elseif (measure_id = QUARTER_MEASURE_ID) then
        if (count = 1) then
            return 'ежеквартально';
        elseif (count = 2) then
            return 'каждое полугодие';
        end if;
    elseif (measure_id = YEAR_MEASURE_ID) then
        if (count = 1) then
            return 'ежегодно';
        elseif (count > 1) then
            return 'каждые '||count||' лет(года)';
        end if;
    end if;

    return '';
END;
$$;

