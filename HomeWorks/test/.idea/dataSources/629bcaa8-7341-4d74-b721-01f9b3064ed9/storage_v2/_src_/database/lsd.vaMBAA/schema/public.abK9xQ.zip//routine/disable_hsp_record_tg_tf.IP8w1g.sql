CREATE FUNCTION disable_hsp_record_tg_tf()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
                   RAISE EXCEPTION 'hsp_record is deprecated, use mc_step table';
                END;
$$;

