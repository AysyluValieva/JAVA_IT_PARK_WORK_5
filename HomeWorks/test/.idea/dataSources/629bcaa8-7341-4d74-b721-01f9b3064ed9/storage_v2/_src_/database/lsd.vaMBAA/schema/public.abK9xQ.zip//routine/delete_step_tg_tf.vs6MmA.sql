CREATE FUNCTION delete_step_tg_tf()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
                IF ( OLD._case_mode_id = 2 )
                THEN
                    delete from sr_srv_rendered where md_step_id = OLD.id;
                END IF;
                RETURN OLD;
              END;
$$;

