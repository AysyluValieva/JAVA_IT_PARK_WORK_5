CREATE FUNCTION mdm_table_record__is_actual(xtable character varying, xid character varying, xdate date)
  RETURNS boolean
LANGUAGE plpgsql
AS $$
declare
  rec record;
begin
  rec := mdm_table_record__get(xtable, xid);
  if rec is null then
    return true;
  end if;
  return xdate between coalesce(rec.create_dt, '-infinity') and coalesce(rec.close_dt, 'infinity');
end;
$$;

