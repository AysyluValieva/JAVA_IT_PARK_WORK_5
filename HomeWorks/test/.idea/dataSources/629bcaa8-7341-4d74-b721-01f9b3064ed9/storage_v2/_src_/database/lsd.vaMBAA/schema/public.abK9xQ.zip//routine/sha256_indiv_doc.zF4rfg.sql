CREATE FUNCTION sha256_indiv_doc()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE

            BEGIN
            IF    TG_OP = 'INSERT' THEN
            IF (NEW.type_id is not null) THEN
            IF ((select code from pim_doc_type where id = NEW.type_id) = 'MHI_UNIFORM') THEN
            NEW.sha256 = encode(digest(NEW.number, 'sha256'), 'hex');
            END IF;
            END IF;
            RETURN NEW;
            ELSIF TG_OP = 'UPDATE' THEN
            IF (NEW.type_id is not null) THEN
            IF ((select code from pim_code_type where id = NEW.type_id) = 'MHI_UNIFORM') THEN
            NEW.sha256 = encode(digest(NEW.number, 'sha256'), 'hex');
            END IF;
            END IF;
            RETURN NEW;
            END IF;
            END;
$$;

