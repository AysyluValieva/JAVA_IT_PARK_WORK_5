CREATE FUNCTION md_receipt__get_medicines(id integer)
  RETURNS character varying
LANGUAGE plpgsql
AS $$
declare
  element record;
  result text := '';
begin

  for element in
    select coalesce(h.name_trade, i.name_rus) as name
      from md_receipt_medicine m
      left join inv_holding h on h.id = m.holding_id
      left join inv_inn i on i.id = m.inn_id
      where m.receipt_id = md_receipt__get_medicines.id
  loop

    if result <> '' then
      result := result || '; ' || element.name;
    else
      result := element.name;
    end if;

  end loop;

  if result = '' then
    return null;
  end if;

  return result;

end;
$$;

