CREATE FUNCTION adr__get_element_as_text(id integer, format text)
  RETURNS character varying
LANGUAGE plpgsql
AS $$
declare
  substr record;
  type_code char;
  arr text[];
  b boolean;
  i integer := 0;
  level_id integer;
  format_id integer;
  element_id integer := id;
  element record;
  result text := '';
  index TEXT;
begin

  for substr in
    select cast(regexp_matches(format, E'([(][1-9][,][nfs][,][0-9]+[)])', 'g') as text) as el
  loop
    i := i + 1;
    arr[i] := substr.el;
  end loop;

  for element in
with recursive 

t as (select ae.id, ae.id source_adr_id, ae.parent_id from address_element ae where ae.id=element_id union all
select ae.id, source_adr_id, ae.parent_id from address_element ae join t on ae.id=t.parent_id
)


select ae.id, ae.name, ae.display_format_id el_fmt,
    aet.name as type, aet.short_name short_type, aet.display_format_id as type_fmt, ae.level_id as level
     from t 
join address_element ae on ae.id=t.id 
join address_element_type aet on aet.id=ae.type_id
order by ae.level_id
loop

    b := false;
    for j in coalesce(array_lower(arr,1),0) .. coalesce(array_upper(arr,1),-1) loop
      level_id := cast(substring(arr[j],4,1) as integer);
      if level_id = element.level then
        b := true;
        i := j;
        exit;
      
      end if;
    end loop;

    if b = true then
      if element.id <> cast(substring(arr[i],8,arr[i].length-10) as integer) then
        if result <> '' then
          result := result || ', ';
        end if;
        type_code := cast(substring(arr[i],6,1) as char);
        if element.el_fmt <> 0 then
          format_id := element.el_fmt;
        else
          format_id := element.type_fmt;
        end if;
        case type_code
          when 'f' then
            if format_id = 2 then
              result := result || element.name || ' ' || element.type;
            else
              result := result || element.type || ' ' || element.name;
            end if;
          when 's' then
            if format_id = 2 then
              result := result || element.name || ' ' || element.short_type;
            else
              result := result || element.short_type || ' ' || element.name;
            end if;
          else
            result := result || element.name;
        end case;
      end if;
    end if;

  end loop;

  if result = '' then
    return null;
  end if;
  
  index := (SELECT
              adr__get_index(element_id));
  IF index IS NOT NULL
  THEN
    for j in coalesce(array_lower(arr,1),0) .. coalesce(array_upper(arr,1),-1) loop
      level_id := cast(substring(arr[j],4,1) as integer);
      if level_id = 9 then
        RETURN index || ', ' || result;
        exit;
      end if;
    end loop;
  END IF;
  RETURN result;

end;
$$;

