CREATE FUNCTION update_prescription_status(prescriptionid integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
  servicesCount integer;
  renderedServicesCount integer;
  state integer;
begin

 IF prescriptionId is not null THEN
    servicesCount = (select count(1) from sr_srv_rendered msr where msr.md_prescription_id = prescriptionId);
    renderedServicesCount = (select count(1) from sr_srv_rendered msr where msr.md_prescription_id = prescriptionId and bdate is not null);

    IF renderedServicesCount = 0 THEN state = 2; END IF;
    IF renderedServicesCount = servicesCount THEN state = 4; END IF;
    IF renderedServicesCount != 0 and renderedServicesCount < servicesCount THEN state = 3; END IF;
    IF servicesCount = 0 THEN state = 1; END IF;

    update hospital.prescription set status_id = state where id = prescriptionId;
  END IF;

end;
$$;

