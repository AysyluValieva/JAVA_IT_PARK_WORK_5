CREATE FUNCTION recursive_update_level_to_diagnosis(diagnosis_id integer, level_value integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE next_level_value integer;
DECLARE row record;
begin
 IF ($1 is not null and $2 is not null) THEN
  UPDATE md_diagnosis SET level = $2 WHERE id = $1;
  next_level_value:= $2+1;
  for row in select id  FROM md_diagnosis where parent_id = $1
  loop
   PERFORM recursive_update_level_to_diagnosis(row.id, next_level_value);
  end loop;
 END IF;
end;
$$;

