CREATE VIEW v_step AS
  SELECT mv_step.clinic_id,
    mv_step.department_id,
    mv_step.profile_id,
    mv_step.age_category_id,
    mv_step.gender_id,
    mv_step.diagnos_id,
    mv_step.funding_id,
    mv_step.care_regimen_id,
    mv_step.outcome_date,
    mv_step.democube_days_id,
    mv_step.step_cnt,
    mv_step.patient_cnt,
    mv_step.death_step_cnt
   FROM mv_step;

