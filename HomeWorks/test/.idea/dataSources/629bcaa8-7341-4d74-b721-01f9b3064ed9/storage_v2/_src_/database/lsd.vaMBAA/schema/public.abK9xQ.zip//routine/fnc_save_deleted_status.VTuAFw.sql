CREATE FUNCTION fnc_save_deleted_status()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
    RETURN NULL;
END;
$$;

