CREATE FUNCTION update_plc_goal_id_tg_tf()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
                        IF((SELECT _case_mode_id FROM mc_step where id=NEW.id)=1) THEN
                           IF(
                               ((SELECT init_goal_id  is null FROM MC_CASE where id= NEW.case_id) and (SELECT plc_goal_id  is not null FROM mc_step where id= NEW.id))
                             or (
                               SELECT init_goal_id is not null FROM MC_CASE where id= NEW.case_id
                               and (
                                    (SELECT plc_goal_id is null FROM mc_step where id= NEW.id )
                                    or ((SELECT init_goal_id FROM MC_CASE where id= NEW.case_id) <> (SELECT plc_goal_id FROM mc_step where id= NEW.id))
                                   )
                                )
                             ) THEN
                                 IF ((not exists (select value from cmn_setting_value  where setting_id = 'cz.atria.medcase.ui.MedicalCaseUISettings.useVisitGoal')) or
                                    (select value from cmn_setting_value  where setting_id = 'cz.atria.medcase.ui.MedicalCaseUISettings.useVisitGoal') = 'false') THEN
                                    UPDATE mc_step SET plc_goal_id =(SELECT init_goal_id FROM MC_CASE where id= NEW.case_id) where id=NEW.id;
                                 END IF;
                           END IF;
                        END IF;
                        RETURN NEW;
                   END;
$$;

