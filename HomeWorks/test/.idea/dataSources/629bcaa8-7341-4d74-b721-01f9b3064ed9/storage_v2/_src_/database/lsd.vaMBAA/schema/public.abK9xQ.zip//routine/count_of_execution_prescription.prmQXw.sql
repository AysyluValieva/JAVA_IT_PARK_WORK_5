CREATE FUNCTION count_of_execution_prescription(integer)
  RETURNS character varying
LANGUAGE plpgsql
AS $$
declare
    count_service_prescribed integer;
    count_service_rendered integer;
    prescription_data RECORD;

begin
count_service_rendered=0;
count_service_prescribed=count_service_prescribed($1);

  select coalesce(sum(coalesce(sr_srv_rendered.quantity, 1)), 0)
  from sr_srv_rendered into count_service_rendered
  where md_patient_prescription_id = $1;

  return coalesce(cast(count_service_prescribed as text))||'/'||coalesce(cast(count_service_rendered AS  text));

end;
$$;

