CREATE FUNCTION sr_scgenerated_from_sr_res_group_update_tg_tf()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
            update sr_scgenerated ss set department_id=s.department_id
            from (
            select aps.id,s.department_id FROM sr_scgenerated aps JOIN sr_res_group s ON aps.res_group_id = s.id where s.id=NEW.id)
            s where ss.id=s.id;
            RETURN new;
            END;
$$;

