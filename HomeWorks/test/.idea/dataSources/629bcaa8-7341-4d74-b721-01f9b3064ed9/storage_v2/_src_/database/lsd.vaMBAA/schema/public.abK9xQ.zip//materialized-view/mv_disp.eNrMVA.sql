CREATE MATERIALIZED VIEW mv_disp AS SELECT d.clinic_id,
        CASE i.gender_id
            WHEN 1 THEN
            CASE
                WHEN (date_part('year'::text, age((('now'::text)::date)::timestamp with time zone, (i.birth_dt)::timestamp with time zone)) <= (17)::double precision) THEN 1
                WHEN ((date_part('year'::text, age((('now'::text)::date)::timestamp with time zone, (i.birth_dt)::timestamp with time zone)) >= (18)::double precision) AND (date_part('year'::text, age((('now'::text)::date)::timestamp with time zone, (i.birth_dt)::timestamp with time zone)) <= (59)::double precision)) THEN 2
                WHEN (date_part('year'::text, age((('now'::text)::date)::timestamp with time zone, (i.birth_dt)::timestamp with time zone)) >= (60)::double precision) THEN 3
                ELSE NULL::integer
            END
            WHEN 2 THEN
            CASE
                WHEN (date_part('year'::text, age((('now'::text)::date)::timestamp with time zone, (i.birth_dt)::timestamp with time zone)) <= (17)::double precision) THEN 4
                WHEN ((date_part('year'::text, age((('now'::text)::date)::timestamp with time zone, (i.birth_dt)::timestamp with time zone)) >= (18)::double precision) AND (date_part('year'::text, age((('now'::text)::date)::timestamp with time zone, (i.birth_dt)::timestamp with time zone)) <= (54)::double precision)) THEN 5
                WHEN (date_part('year'::text, age((('now'::text)::date)::timestamp with time zone, (i.birth_dt)::timestamp with time zone)) >= (55)::double precision) THEN 6
                ELSE NULL::integer
            END
            ELSE NULL::integer
        END AS age_category_id,
    i.gender_id,
    p.social_group_id,
    d.dispensary_group_id,
    d.nosol_registr_id,
    d.diagnosis_id AS disp_diagnosis_id,
    d.reg_out_reason_id,
    d.reg_stage_id,
    x.calendar_date,
    x.id AS democube_days_id,
    count(DISTINCT
        CASE
            WHEN (((d.reg_in_dt <= (((x.calendar_date + '1 mon'::interval) - '1 day'::interval))::date) OR (d.reg_in_dt IS NULL)) AND ((d.reg_out_dt >= (((x.calendar_date + '1 mon'::interval) - '1 day'::interval))::date) OR (d.reg_out_dt IS NULL))) THEN d.id
            ELSE NULL::integer
        END) AS disp_cnt,
    count(DISTINCT
        CASE
            WHEN (((d.reg_in_dt <= (((x.calendar_date + '1 mon'::interval) - '1 day'::interval))::date) OR (d.reg_in_dt IS NULL)) AND ((d.reg_out_dt >= (((x.calendar_date + '1 mon'::interval) - '1 day'::interval))::date) OR (d.reg_out_dt IS NULL))) THEN d.patient_id
            ELSE NULL::integer
        END) AS patient_cnt,
    count(DISTINCT
        CASE
            WHEN ((date_part('year'::text, d.reg_in_dt) = (x.year_)::double precision) AND (date_part('month'::text, d.reg_in_dt) = (x.month_of_year)::double precision)) THEN d.id
            ELSE NULL::integer
        END) AS new_disp_cnt,
    count(DISTINCT
        CASE
            WHEN ((date_part('year'::text, d.reg_in_dt) = (x.year_)::double precision) AND (date_part('month'::text, d.reg_in_dt) = (x.month_of_year)::double precision)) THEN d.patient_id
            ELSE NULL::integer
        END) AS new_patient_cnt,
    count(DISTINCT
        CASE
            WHEN ((date_part('year'::text, d.reg_out_dt) = (x.year_)::double precision) AND (date_part('month'::text, d.reg_out_dt) = (x.month_of_year)::double precision)) THEN d.id
            ELSE NULL::integer
        END) AS undisp_cnt,
    count(DISTINCT
        CASE
            WHEN ((date_part('year'::text, d.reg_out_dt) = (x.year_)::double precision) AND (date_part('month'::text, d.reg_out_dt) = (x.month_of_year)::double precision)) THEN d.patient_id
            ELSE NULL::integer
        END) AS undisp_patient_cnt
   FROM (((pci_dispensary d
     JOIN pim_individual i ON (((d.patient_id = i.id) AND (i.gender_id = ANY (ARRAY[1, 2])) AND (i.birth_dt IS NOT NULL))))
     JOIN cube_days_simple x ON (((((d.reg_in_dt <= (((x.calendar_date + '1 mon'::interval) - '1 day'::interval))::date) OR (d.reg_in_dt IS NULL)) AND ((d.reg_out_dt >= (((x.calendar_date + '1 mon'::interval) - '1 day'::interval))::date) OR (d.reg_out_dt IS NULL))) OR ((date_part('year'::text, d.reg_in_dt) = (x.year_)::double precision) AND (date_part('month'::text, d.reg_in_dt) = (x.month_of_year)::double precision)) OR ((date_part('year'::text, d.reg_out_dt) = (x.year_)::double precision) AND (date_part('month'::text, d.reg_out_dt) = (x.month_of_year)::double precision)))))
     JOIN pci_patient p ON ((i.id = p.id)))
  GROUP BY d.clinic_id,
        CASE i.gender_id
            WHEN 1 THEN
            CASE
                WHEN (date_part('year'::text, age((('now'::text)::date)::timestamp with time zone, (i.birth_dt)::timestamp with time zone)) <= (17)::double precision) THEN 1
                WHEN ((date_part('year'::text, age((('now'::text)::date)::timestamp with time zone, (i.birth_dt)::timestamp with time zone)) >= (18)::double precision) AND (date_part('year'::text, age((('now'::text)::date)::timestamp with time zone, (i.birth_dt)::timestamp with time zone)) <= (59)::double precision)) THEN 2
                WHEN (date_part('year'::text, age((('now'::text)::date)::timestamp with time zone, (i.birth_dt)::timestamp with time zone)) >= (60)::double precision) THEN 3
                ELSE NULL::integer
            END
            WHEN 2 THEN
            CASE
                WHEN (date_part('year'::text, age((('now'::text)::date)::timestamp with time zone, (i.birth_dt)::timestamp with time zone)) <= (17)::double precision) THEN 4
                WHEN ((date_part('year'::text, age((('now'::text)::date)::timestamp with time zone, (i.birth_dt)::timestamp with time zone)) >= (18)::double precision) AND (date_part('year'::text, age((('now'::text)::date)::timestamp with time zone, (i.birth_dt)::timestamp with time zone)) <= (54)::double precision)) THEN 5
                WHEN (date_part('year'::text, age((('now'::text)::date)::timestamp with time zone, (i.birth_dt)::timestamp with time zone)) >= (55)::double precision) THEN 6
                ELSE NULL::integer
            END
            ELSE NULL::integer
        END, i.gender_id, p.social_group_id, d.dispensary_group_id, d.nosol_registr_id, d.diagnosis_id, d.reg_out_reason_id, d.reg_stage_id, x.calendar_date, x.id;

CREATE INDEX mv_disp_clinic_id_inx
  ON mv_disp (clinic_id);

CREATE INDEX mv_disp_age_category_id_inx
  ON mv_disp (age_category_id);

CREATE INDEX mv_disp_gender_id_inx
  ON mv_disp (gender_id);

CREATE INDEX mv_disp_social_group_id_inx
  ON mv_disp (social_group_id);

CREATE INDEX mv_disp_dispensary_group_id_inx
  ON mv_disp (dispensary_group_id);

CREATE INDEX mv_disp_nosol_registr_id_inx
  ON mv_disp (nosol_registr_id);

CREATE INDEX mv_disp_disp_diagnosis_id_inx
  ON mv_disp (disp_diagnosis_id);

CREATE INDEX mv_disp_reg_out_reason_id_inx
  ON mv_disp (reg_out_reason_id);

CREATE INDEX mv_disp_reg_stage_id_inx
  ON mv_disp (reg_stage_id);

CREATE INDEX mv_disp_calendar_date_inx
  ON mv_disp (calendar_date);

CREATE INDEX mv_disp_democube_days_id_inx
  ON mv_disp (democube_days_id);

