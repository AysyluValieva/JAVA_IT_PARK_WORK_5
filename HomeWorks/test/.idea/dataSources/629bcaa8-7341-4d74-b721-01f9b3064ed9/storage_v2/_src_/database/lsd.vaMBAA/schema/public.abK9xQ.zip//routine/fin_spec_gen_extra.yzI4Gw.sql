CREATE FUNCTION fin_spec_gen_extra(p1_bill_id integer, p2_status text)
  RETURNS void
STRICT
LANGUAGE plpgsql
AS $$
DECLARE 
    _main_bill_id INTEGER := public.fin_bill__get_main_bill (p1_bill_id);
    _base_bill_id INTEGER := (SELECT base_id FROM public.fin_bill_correctional WHERE id = p1_bill_id);
    _bill_period DATERANGE;
    _price_type TEXT := public.fin_get_price_type (p1_bill_id);
    _r RECORD;
    _s RECORD;
    _mo_info RECORD;
    _csg_full_payment_codes TEXT[];
    _bill_info HSTORE;
    _policy_id INTEGER;
    _issuer_id INTEGER;
    _territory_id INTEGER;
    _enp_type_id INTEGER := (SELECT id FROM public.pim_doc_type WHERE code = 'MHI_UNIFORM');
    _clinic_id INTEGER;
    _financing_type_id INTEGER;
    _payer_id INTEGER;
    _payer_role TEXT;
    _payer_territory LTREE;
    _regions_arr INTEGER[];
    _is_local BOOLEAN;
    _is_foreign BOOLEAN;
    _is_nopolicy BOOLEAN;
    _all_region BOOLEAN;
BEGIN
    ---------------------------------------------------обнуление фильтра для стационаров-------------------------------------------------------------
    IF 
        p2_status = 'GENERATE' AND EXISTS (SELECT 1 FROM public.fin_bill_main_department WHERE main_bill_id = _main_bill_id) AND _price_type LIKE '%hospital'
    THEN
        UPDATE fin_bill_generate 
        SET
           is_sifted = FALSE, sifting_cause = NULL
        WHERE
            bill_id = p1_bill_id AND is_sifted AND sifting_cause = 'Применён фильтр по подразделениям'
        ;
    END IF;
    -----------------------------------------------------------тип позиции счёта---------------------------------------------------------------------
    UPDATE fin_bill_generate SET item_type = _price_type WHERE bill_id = p1_bill_id;
    
    SELECT 
        daterange (coalesce (a.from_date, m.from_date), coalesce (a.to_date, m.to_date), '[]') INTO _bill_period
    FROM
        fin_bill_main AS m LEFT JOIN fin_bill_additional AS a ON m.id = a.base_id AND a.id = p1_bill_id
    WHERE
        m.id = _main_bill_id
    ;
    IF
        _base_bill_id <> _main_bill_id
    THEN
        SELECT 
            daterange (coalesce (a.from_date, m.from_date), coalesce (a.to_date, m.to_date), '[]') INTO _bill_period
        FROM
            fin_bill_main AS m LEFT JOIN fin_bill_additional AS a ON m.id = a.base_id AND a.id = _base_bill_id
        WHERE
            m.id = _main_bill_id
        ;
    END IF;
    ----------------------------------------------------правила подбора полиса региона---------------------------------------------------------------
    UPDATE fin_bill_generate
    SET
        active_policy_id = fin_individual__get_active_policy (customer_id, case_close_date)
    WHERE
        bill_id = p1_bill_id AND NOT is_sifted
    ;
    WITH t AS 
    (
        SELECT 
            bill_id, id, fin_individual__get_active_policy (customer_id, case_open_date) AS policy_id
        FROM
            fin_bill_generate
        WHERE
            bill_id = p1_bill_id AND NOT is_sifted AND active_policy_id <> coalesce (fin_individual__get_active_policy (customer_id, case_open_date), 0)
    )
    UPDATE fin_bill_generate AS f
    SET
        active_policy_id = t.policy_id
    FROM t
    WHERE
        f.bill_id = t.bill_id AND f.id = t.id
    ;
    UPDATE fin_bill_generate AS f
    SET
        active_policy_issuer_id = i.issuer_id
    FROM
        pim_individual_doc AS i
    WHERE
        f.bill_id = p1_bill_id AND NOT f.is_sifted AND f.active_policy_id = i.id
    ;
    UPDATE fin_bill_generate AS f
    SET
        smo_work_territory_id = o.work_territory_id
    FROM
        pim_organization AS o
    WHERE
        f.bill_id = p1_bill_id AND NOT f.is_sifted AND f.active_policy_issuer_id = o.id
    ;
    ----------------------------------------------------параметры для страховой принадлежности-------------------------------------------------------
    SELECT clinic_id, financing_type_id, payer_id INTO _clinic_id, _financing_type_id, _payer_id FROM fin_bill_main WHERE id = _main_bill_id
    ;
    IF
        (SELECT code FROM fin_funding_source_type WHERE id = _financing_type_id LIMIT 1) = 'OMS'
    THEN
        _payer_role := coalesce 
                        (
                            (
                                SELECT 
                                    r.code 
                                FROM 
                                    pim_party_role_to_party AS t, pim_party_role AS r 
                                WHERE 
                                    r.id = t.role_id AND t.party_id = _payer_id 
                                ORDER BY 
                                    r.code = 'HIF_ORGANIZATION' DESC NULLS LAST, r.code = 'MEDICAL_INSURANCE_ORGANIZATION' DESC NULLS LAST 
                                LIMIT 1
                            ), ''
                        )
        ;
    END IF;
    _regions_arr := ARRAY (SELECT region_id FROM fin_bill_main_to_region WHERE main_bill_id = _main_bill_id)
    ;
    IF 
        array_length (_regions_arr, 1) IS NOT NULL
    THEN
        _is_local    := (0 = ANY (_regions_arr));
        _is_foreign  := (1 = ANY (_regions_arr));
        _is_nopolicy := (2 = ANY (_regions_arr));
        _all_region  := _is_local AND _is_foreign AND _is_nopolicy;
    ELSE
        _is_local := TRUE; _is_foreign := TRUE; _is_nopolicy := TRUE; _all_region := TRUE;
    END IF;
    -------------------------------------------------------отсеивание по полису----------------------------------------------------------------------
    IF
        (SELECT code FROM fin_funding_source_type WHERE id = _financing_type_id) = 'OMS'
    THEN
        UPDATE fin_bill_generate SET belonging_type = 'nopolicy' WHERE bill_id = p1_bill_id AND NOT is_sifted AND active_policy_id IS NULL
        ;
        UPDATE fin_bill_generate SET belonging_type = 'nopolicy_issuer' WHERE bill_id = p1_bill_id AND NOT is_sifted AND belonging_type IS NULL AND active_policy_issuer_id IS NULL
        ;
        IF 
            _payer_role = 'MEDICAL_INSURANCE_ORGANIZATION' 
        THEN
            UPDATE fin_bill_generate
            SET 
                belonging_type = CASE WHEN active_policy_issuer_id = _payer_id THEN 'local' ELSE 'foreign' END
            WHERE
                bill_id = p1_bill_id AND NOT is_sifted AND belonging_type IS NULL
            ;
            IF
                p2_status = 'GENERATE'
            THEN
                UPDATE fin_bill_generate
                SET
                    is_sifted = TRUE, sifting_cause = 'Страховая принадлежность не подходит под выбранного плательщика'
                WHERE
                    bill_id = p1_bill_id AND NOT is_sifted AND belonging_type <> 'local'
                ;
            END IF;
        ELSE
            _payer_territory = 
            CASE 
                WHEN 
                    _payer_role = 'HIF_ORGANIZATION' 
                THEN 
                    (SELECT a.path FROM pim_organization AS o, address_element_data AS a WHERE o.work_territory_id = a.id AND o.id = _payer_id) 
                ELSE 
                    (SELECT a.path FROM pim_organization AS o, address_element_data AS a WHERE o.work_territory_id = a.id AND o.id = _clinic_id) 
            END;
            IF 
                p2_status = 'GENERATE' AND _payer_territory IS NULL
            THEN 
                UPDATE fin_bill_generate
                SET 
                    is_sifted = TRUE, sifting_cause = 'Пустая территория обслуживания ' || CASE WHEN _payer_role = 'HIF_ORGANIZATION' THEN 'ТФОМС' ELSE 'ЛПУ' END
                WHERE 
                    bill_id = p1_bill_id AND NOT is_sifted
                ;
            ELSE
                WITH t AS 
                (
                    SELECT
                        f.bill_id, 
                        f.id,
                        CASE WHEN _payer_territory <@ a.path OR _payer_territory @> a.path THEN 'local' ELSE 'foreign' END AS belonging_type
                    FROM
                        fin_bill_generate AS f
                        LEFT JOIN LATERAL (SELECT path FROM address_element_data WHERE id = f.smo_work_territory_id LIMIT 1) AS a ON TRUE
                    WHERE
                        f.bill_id = p1_bill_id AND NOT f.is_sifted AND f.belonging_type IS NULL
                )
                UPDATE fin_bill_generate AS f
                SET 
                    belonging_type = t.belonging_type
                FROM t
                WHERE
                    f.bill_id = t.bill_id AND f.id = t.id
                ;
            END IF;
            IF
                p2_status = 'GENERATE' AND NOT _all_region
            THEN
                IF
                    _is_nopolicy AND _is_foreign
                THEN
                    UPDATE fin_bill_generate
                    SET
                        is_sifted = TRUE, sifting_cause = 'Тип региона не подходит под выбранные: без полиса, чужой'
                    WHERE
                        bill_id = p1_bill_id AND NOT is_sifted AND belonging_type = 'local'
                    ;
                ELSIF
                    _is_nopolicy AND _is_local
                THEN
                    UPDATE fin_bill_generate
                    SET
                        is_sifted = TRUE, sifting_cause = 'Тип региона не подходит под выбранные: без полиса, свой'
                    WHERE
                        bill_id = p1_bill_id AND NOT is_sifted AND belonging_type = 'foreign'
                    ;
                ELSIF
                     _is_foreign AND _is_local
                THEN
                    UPDATE fin_bill_generate
                    SET
                        is_sifted = TRUE, sifting_cause = 'Тип региона не подходит под выбранные: чужой, свой'
                    WHERE
                        bill_id = p1_bill_id AND NOT is_sifted AND belonging_type LIKE 'nopolicy%'
                    ;
                ELSIF
                    _is_nopolicy
                THEN
                    UPDATE fin_bill_generate
                    SET
                        is_sifted = TRUE, sifting_cause = 'Тип региона не подходит под выбранные: без полиса'
                    WHERE
                        bill_id = p1_bill_id AND NOT is_sifted AND belonging_type IN ('local', 'foreign')
                    ;
                ELSIF
                    _is_foreign
                THEN
                    UPDATE fin_bill_generate
                    SET
                        is_sifted = TRUE, sifting_cause = 'Тип региона не подходит под выбранные: чужой'
                    WHERE
                        bill_id = p1_bill_id AND NOT is_sifted AND belonging_type IN ('local', 'nopolicy', 'nopolicy_issuer')
                    ;
                ELSIF
                    _is_local
                THEN
                    UPDATE fin_bill_generate
                    SET
                        is_sifted = TRUE, sifting_cause = 'Тип региона не подходит под выбранные: свой'
                    WHERE
                        bill_id = p1_bill_id AND NOT is_sifted AND belonging_type IN ('foreign', 'nopolicy', 'nopolicy_issuer')
                    ;
                END IF;
            END IF;
        END IF;
    END IF;
    -------------------------------------------------------круглосуточный стационар------------------------------------------------------------------
    IF
        _price_type = 'hospital'
    THEN
        _bill_info := hstore ('srv_code', 'KSKSG') || hstore ('vmedpom_code', '1') || hstore ('vmedpom_number', '1');
        --отсеивание для стационара
        WITH t AS
        (
            SELECT 
                bill_id, case_id, array_agg (id) AS id_arr 
            FROM 
                fin_bill_generate 
            WHERE 
                bill_id = p1_bill_id AND NOT is_sifted 
            GROUP BY 1, 2 
            HAVING NOT bool_or (service_code = (_bill_info -> 'srv_code'))
        )
        UPDATE fin_bill_generate AS f
        SET 
            is_sifted = TRUE, sifting_cause = 'В случае отсутствует необходимая фиктивная услуга'
        FROM t
        WHERE 
            f.bill_id = t.bill_id AND f.id = ANY (t.id_arr)
        ;
        --набор первичной информации
        _csg_full_payment_codes := 
        ARRAY[
            '4', '5', '8', '9', '11', '13', '14', '20', '134', '135', '138', '159', '177', '226', '245', --обычные коды
            '111', '112', '113',                                                                         --лучевая терапия
            '35', '36', '108', '109', '110'                                                              --химиотерапия
        ];
        _mo_info := public.fin_get_mo_info (p1_bill_id);
        
        _bill_info := _bill_info || hstore ('code_of_relative_capacity_costs', concat ('KZ', CASE WHEN (_mo_info.extra_info -> 'org_terr_type') = 'village' THEN 's' ELSE NULL END));
        
        _bill_info := _bill_info || hstore ('pos_code', concat (CASE WHEN (_mo_info.extra_info -> 'org_terr_type') = 'village' THEN 'V' ELSE NULL END, 'HCSG'));
        --проставление дат, res_group_id, КСГ
        WITH t AS 
        (
            SELECT 
                f.bill_id, f.id, s.res_group_id, s.id AS idcase, s.csg_id, f.case_open_date AS dbeg, f.case_close_date AS dend
            FROM
                fin_bill_generate AS f
                JOIN LATERAL
                (
                    SELECT id, csg_id, res_group_id FROM mc_step WHERE csg_id IS NOT NULL AND case_id = f.case_id ORDER BY outcome_date DESC LIMIT 1
                ) AS s ON TRUE
            WHERE
                f.bill_id = p1_bill_id AND NOT f.is_sifted
        )
        UPDATE fin_bill_generate AS f 
        SET 
            res_group_id = t.res_group_id,
            region_data = coalesce (f.region_data, hstore ('')) || hstore ('idcase', t.idcase::TEXT) || hstore ('csg_id', t.csg_id::TEXT) || hstore ('dbeg', t.dbeg::TEXT) || hstore ('dend', t.dend::TEXT)
        FROM t
        WHERE 
            f.bill_id = t.bill_id AND f.id = t.id
        ;
        --проставление дат, КСГ в случаях с переводами
        FOR _r IN
            SELECT 
                f.bill_id, f.case_id, (f.region_data -> 'idcase')::INTEGER AS idcase, b.id, b.res_group_id, b.csg_id, b.outcome_date
            FROM 
                fin_bill_generate AS f 
                JOIN mc_step AS s ON s.case_id = f.case_id 
                LEFT JOIN LATERAL 
                (
                    SELECT 
                        id, res_group_id, csg_id, outcome_date 
                    FROM 
                        mc_step 
                    WHERE 
                        case_id = f.case_id AND csg_id IS NOT NULL AND id <> (f.region_data -> 'idcase')::INTEGER
                    ORDER BY outcome_date DESC 
                    LIMIT 1
                ) AS b ON TRUE
            WHERE 
                f.bill_id = p1_bill_id AND NOT f.is_sifted AND s.csg_id IS NOT NULL
            GROUP BY 1, 2, 3, 4, 5, 6, 7
            HAVING count (DISTINCT s.csg_id) > 1
        LOOP
            UPDATE fin_bill_generate AS f 
            SET 
                res_group_id = _r.res_group_id,
                region_data = coalesce (f.region_data, hstore ('')) || hstore ('idcase', _r.id::TEXT) || hstore ('csg_id', _r.csg_id::TEXT) || hstore ('dend', _r.outcome_date::TEXT)
            WHERE 
                f.bill_id = _r.bill_id AND f.case_id = _r.case_id AND NOT f.is_sifted AND f.bdate <= _r.outcome_date AND f.step_id <> _r.idcase
            ;
            UPDATE fin_bill_generate AS f 
            SET 
                region_data = coalesce (f.region_data, hstore ('')) || hstore ('dbeg', _r.outcome_date::TEXT) 
            WHERE 
                f.bill_id = _r.bill_id AND f.case_id = _r.case_id AND NOT f.is_sifted AND (f.bdate > _r.outcome_date OR f.step_id = _r.idcase)
            ;
        END LOOP;
        --фильтр по подразделениям
        IF 
            p2_status = 'GENERATE' AND EXISTS (SELECT 1 FROM fin_bill_main_department WHERE main_bill_id = _main_bill_id)
        THEN
            WITH t AS 
            (
                SELECT
                    f.bill_id, f.id
                FROM 
                    fin_bill_generate AS f
                    LEFT JOIN LATERAL (SELECT department_id AS id FROM hsp_record WHERE id = (f.region_data -> 'idcase')::INTEGER LIMIT 1) AS p ON TRUE
                WHERE
                    f.bill_id = p1_bill_id AND NOT f.is_sifted AND (p.id <> ALL (ARRAY (SELECT department_id FROM fin_bill_main_department WHERE main_bill_id = _main_bill_id)) OR p.id IS NULL)
            )
            UPDATE fin_bill_generate AS f
            SET
               is_sifted = TRUE, sifting_cause = 'Применён фильтр по подразделениям'
            FROM t
            WHERE
                f.bill_id = t.bill_id AND f.id = t.id AND NOT f.is_sifted
            ;
        END IF;
        WITH t AS 
        (
            SELECT 
                f.bill_id, 
                f.id,
                trim (c.code) AS csg_code, 
                trim (c.name) AS csg_name, 
                c.type_code AS csg_type_code, 
                (SELECT duration FROM mc_mes_duration WHERE md_mes = s.mes_id LIMIT 1) AS mes_duration,
                (SELECT code FROM mc_step_result WHERE id = s.result_id LIMIT 1) AS step_result_code,
                r.coefficient AS factor_of_relative_capacity_costs,
                p.code AS bed_profile_code,
                k.code AS kod_oper,
                replace (d.code, '*', '') AS dso
            FROM
                fin_bill_generate AS f
                JOIN LATERAL (SELECT mes_id, result_id FROM mc_step WHERE id = (f.region_data -> 'idcase')::INTEGER LIMIT 1) AS s ON TRUE
                JOIN LATERAL 
                (
                    SELECT 
                        c.code, c.name, t.code AS type_code 
                    FROM 
                        md_clinical_statistical_group AS c, md_csg_type AS t 
                    WHERE 
                        c.type_id = t.id AND c.id = (f.region_data -> 'csg_id')::INTEGER
                    LIMIT 1
                ) AS c ON TRUE
                LEFT JOIN LATERAL 
                (
                    SELECT 
                        replace (replace (c.value, ' ', ''), ',', '.')::DECIMAL AS coefficient 
                    FROM 
                        md_csg_cond AS c, md_csg_cond_type AS t 
                    WHERE 
                        c.type_id = t.id AND c.csg_id = (f.region_data -> 'csg_id')::INTEGER 
                        AND t.code = (_bill_info -> 'code_of_relative_capacity_costs') AND daterange (c.from_dt, c.to_dt, '[]') @> f.case_close_date
                    ORDER BY c.from_dt DESC NULLS LAST, c.to_dt DESC, c.id DESC
                    LIMIT 1
                ) AS r ON TRUE
                LEFT JOIN LATERAL (SELECT bed_profile_id FROM hsp_record WHERE id = (f.region_data -> 'idcase')::INTEGER LIMIT 1) AS h ON TRUE
                LEFT JOIN LATERAL (SELECT code FROM md_bed_profile WHERE id = h.bed_profile_id LIMIT 1) AS p ON TRUE 
                LEFT JOIN LATERAL (SELECT diagnos_id FROM mc_diagnosis WHERE is_main AND case_id = f.case_id ORDER BY stage_id DESC NULLS LAST, establishment_date DESC NULLS LAST, id DESC LIMIT 1) AS m ON TRUE
                LEFT JOIN LATERAL (SELECT code FROM md_diagnosis WHERE id = m.diagnos_id LIMIT 1) AS d ON TRUE
                LEFT JOIN LATERAL
                (
                    SELECT 
                        e.code 
                    FROM 
                        md_srv_rendered      AS m 
                        JOIN sr_srv_rendered AS r ON m.id = r.id
                        JOIN sr_service      AS e ON e.id = r.service_id 
                    WHERE 
                        m.case_id = f.case_id AND m.id <> f.id AND r.bdate <= (f.region_data -> 'dend')::DATE
                        AND EXISTS (SELECT 1 FROM md_csg_to_srv_prototype WHERE csg_id = (f.region_data -> 'csg_id')::INTEGER AND srv_prototype_id = e.prototype_id)
                    ORDER BY r.bdate DESC, m.id DESC
                    LIMIT 1
                ) AS k ON TRUE
            WHERE
                f.bill_id = p1_bill_id AND NOT f.is_sifted 
        )
        UPDATE fin_bill_generate AS f
        SET
            quantity = coalesce (nullif ((f.region_data -> 'dend')::DATE - (f.region_data -> 'dbeg')::DATE, 0), 1),
            region_data = coalesce (f.region_data, ''::HSTORE) ||
                          hstore ('csg_code', t.csg_code::TEXT) || 
                          hstore ('csg_name', t.csg_name::TEXT) || 
                          hstore ('csg_type_code', t.csg_type_code::TEXT) || 
                          hstore ('sts', t.mes_duration::TEXT) || 
                          hstore ('factor_of_level_of_hospital_care', coalesce (nullif ((_mo_info.extra_info -> 'factor_of_level_of_hospital_care'), ''), '1')) || 
                          hstore ('factor_of_relative_capacity_costs', coalesce (t.factor_of_relative_capacity_costs, '1')::TEXT) || 
                          hstore ('idprof', t.bed_profile_code::TEXT) || 
                          hstore ('kod_oper', t.kod_oper::TEXT) || 
                          hstore ('ishod', t.step_result_code::TEXT) || 
                          hstore ('dso', t.dso) 
        FROM t
        WHERE
            f.id = t.id AND f.bill_id = t.bill_id 
        ;
        FOR _r IN
            SELECT
                f.bill_id,
                f.id, 
                f.service_code,
                f.quantity, 
                f.attendant_id,
                p.price AS base_tariff,
                f.region_data -> 'csg_code' AS csg,
                f.region_data -> 'csg_type_code' AS csg_type,
                f.region_data -> 'idprof' AS bed_profile_code,
                (f.region_data -> 'idcase')::INTEGER AS step_id,
                (f.region_data -> 'sts')::DECIMAL AS mes_duration,
                (f.region_data -> 'dend')::DATE AS dend,
                (f.region_data -> 'factor_of_level_of_hospital_care')::DECIMAL AS factor_of_level_of_hospital_care,  --коэффициент уровня оказания стационарной медпомощи
                (f.region_data -> 'factor_of_relative_capacity_costs')::DECIMAL AS factor_of_relative_capacity_costs,--коэффициент относительной затратоёмкости
                coalesce (v.code, '') AS dv_code 
            FROM
                public.fin_bill_generate AS f
                JOIN LATERAL (SELECT deviation_reason_id FROM public.mc_step WHERE id = (f.region_data -> 'idcase')::INTEGER LIMIT 1) AS s ON TRUE
                LEFT JOIN LATERAL (SELECT code FROM public.mc_deviation_reason WHERE id = s.deviation_reason_id LIMIT 1) AS v ON TRUE
                LEFT JOIN LATERAL 
                (
                    SELECT price FROM public.fin_pl_position 
                    WHERE 
                        price_list_id = f.price_list_id AND daterange (from_dt::DATE, to_dt::DATE, '[]') @> (f.region_data -> 'dend')::DATE AND code = (_bill_info -> 'pos_code') 
                    ORDER BY to_dt DESC
                    LIMIT 1
                ) AS p ON TRUE
            WHERE
                f.bill_id = p1_bill_id AND NOT f.is_sifted
        LOOP
            --управленческий коэффициент
            _bill_info := _bill_info || hstore ('factor_of_management', '1');
            --1, 5
            --КСГ = 25 и Причина отклонения от стандарта = "Оказание помощи пациентам с острым деструктивным панкреатитом с наличием инфекционно-токсических осложнений и полиорганной недостаточности" (код 3)
            --или
            --КСГ = 3 ,4, 5 и Причина отклонения от стандарта = "Оказание новорождённому специализированной медицинской помощи с применением сурфактанта" (код 1)
            IF 
                (_r.csg = '25' AND _r.dv_code = '3') OR (_r.csg IN ('3', '4', '5') AND _r.dv_code = '1') 
            THEN
                _bill_info := _bill_info || hstore ('factor_of_management', '1.5');
            --3
            --КСГ = 79 и Уровень (подуровень) МО в стационаре = 2, 3
            ELSIF 
                _r.csg = '79' AND _mo_info.level IN ('2', '3') 
            THEN 
                _bill_info := _bill_info || hstore ('factor_of_management', '0.75');
            --4
            --КСГ = 3,4,5
            ELSIF 
                _r.csg IN ('3', '4', '5') 
            THEN 
                _bill_info := _bill_info || hstore ('factor_of_management', '1.15');
            --2, 6, 7
            --КСГ = 11 или КСГ = 226
            --или
            --КСГ = 257 и Причина отклонения от стандарта = "Обследование в круглосуточном стационаре лиц призывного возраста по направлениям военкоматов" (код 8)
            ELSIF 
                _r.csg IN ('11', '226') OR (_r.csg = '257' AND _r.dv_code = '8') 
            THEN 
                _bill_info := _bill_info || hstore ('factor_of_management', '0.5');
            --новые пункты (2016-02-20)
            --КСГ = 152 "Пневмония, плеврит, другие болезни плевры"
            ELSIF 
                _r.csg = '152'
            THEN 
                _bill_info := _bill_info || hstore ('factor_of_management', '1.1');
            --новые пункты (2016-02-20)
            --КСГ = 58 "Респираторные инфекции верхних дыхательный путей"
            ELSIF 
                _r.csg = '58'
            THEN 
                _bill_info := _bill_info || hstore ('factor_of_management', '1.5');
            END IF;
            --коэффициент сложности курации пациента
            _bill_info := _bill_info || hstore ('factor_of_difficulty_of_cure', '1') || hstore ('codes_of_difficulty_of_cure_arr', NULL::TEXT);
            --полная/неполная оплата
            IF
                _r.quantity > 3 OR _r.csg = ANY (_csg_full_payment_codes)
            THEN
                FOR _s IN 
                    SELECT 
                        c.value, c.code
                    FROM
                        mc_step_cur_coef_criteria AS s, mc_cur_coef_criteria AS c
                    WHERE
                        c.id = s.criteria_id AND s.step_id = _r.step_id
                LOOP
                    _bill_info := _bill_info || hstore ('codes_of_difficulty_of_cure_arr', concat (rtrim ((_bill_info -> 'codes_of_difficulty_of_cure_arr'), ',') || ',', _s.code));
                    IF
                        _s.code IN ('15', '16')
                    THEN
                        _bill_info := _bill_info || hstore ('special_mes_duration', CASE WHEN _r.csg IN ('32', '91', '92', '112', '113', '192', '232') THEN '45' ELSE '30' END::TEXT);
                        _bill_info := 
                            _bill_info || 
                            hstore 
                            (
                                'factor_of_difficulty_of_cure', 
                                (
                                    (_bill_info -> 'factor_of_difficulty_of_cure')::DECIMAL 
                                    * 
                                    (1 + (_r.quantity - (_bill_info -> 'special_mes_duration')::DECIMAL) / (_bill_info -> 'special_mes_duration')::DECIMAL * 0.25)
                                )::TEXT
                            )
                        ;
                    ELSE
                        _bill_info := _bill_info || hstore ('factor_of_difficulty_of_cure', ((_bill_info -> 'factor_of_difficulty_of_cure')::DECIMAL * _s.value)::TEXT);
                    END IF;
                END LOOP;
                
                _bill_info := _bill_info || hstore ('factor_of_difficulty_of_cure', round ((_bill_info -> 'factor_of_difficulty_of_cure')::DECIMAL, 2)::TEXT);
                
                IF (_bill_info -> 'factor_of_difficulty_of_cure')::DECIMAL > 1.8 THEN _bill_info := _bill_info || hstore ('factor_of_difficulty_of_cure', '1.8'); END IF;
                
                UPDATE fin_bill_generate 
                SET 
                    tariff = _r.base_tariff, 
                    price = CASE 
                                WHEN  _r.service_code ~ '[AB].+' THEN 0 
                                ELSE
                                    _r.base_tariff 
                                    *
                                    _r.factor_of_relative_capacity_costs
                                    *
                                    (_bill_info -> 'factor_of_management')::DECIMAL 
                                    * 
                                    _r.factor_of_level_of_hospital_care 
                                    *
                                    (_bill_info -> 'factor_of_difficulty_of_cure')::DECIMAL
                                END,
                    region_data = coalesce (region_data, ''::HSTORE) || 
                                  slice (_bill_info, ARRAY['factor_of_difficulty_of_cure', 'factor_of_management', 'vmedpom_code', 'vmedpom_number']) || 
                                  hstore ('osn_kskp', (_bill_info -> 'codes_of_difficulty_of_cure_arr')) || 
                                  hstore ('gs', CASE WHEN (_mo_info.extra_info -> 'org_terr_type') = 'village' THEN 'S' ELSE 'G' END) || 
                                  hstore ('kod_mo', _mo_info.code) || 
                                  hstore ('otcl_dn', (_r.quantity - _r.mes_duration)::TEXT) || 
                                  hstore 
                                  (
                                      'idotd', 
                                      CASE 
                                          WHEN _r.bed_profile_code IN ('107', '108') THEN 'КДНС'
                                          ELSE concat 
                                               (
                                                   'КСГ', 
                                                   CASE 
                                                       WHEN _r.bed_profile_code IN ('105', '106', '10550', '10650') THEN 'С'
                                                       WHEN (_mo_info.extra_info -> 'org_spec_type') = 'tc' OR _r.csg = '192' THEN 'Т' 
                                                       ELSE NULL 
                                                   END
                                               )
                                      END
                                  )
                WHERE
                    bill_id = _r.bill_id AND id = _r.id
                ;
            ELSE
                UPDATE fin_bill_generate 
                SET 
                    tariff = _r.base_tariff, 
                    price = CASE 
                                WHEN  _r.service_code ~ '[AB].+' THEN 0 
                                ELSE
                                    round 
                                    (
                                        _r.base_tariff * _r.factor_of_relative_capacity_costs * _r.factor_of_level_of_hospital_care 
                                        *
                                        (_bill_info -> 'factor_of_management')::DECIMAL 
                                        *
                                        (_bill_info -> 'factor_of_difficulty_of_cure')::DECIMAL,
                                        2
                                    )
                                    * 
                                    CASE 
                                        WHEN _r.dend < '2015-06-01'::DATE THEN 0.25
                                        ELSE
                                            CASE 
                                                WHEN _r.csg IN ('61', '77') AND (_mo_info.extra_info -> 'org_spec_type') = 'pvb_rvc' THEN 0.5
                                                WHEN _r.csg_type = '2' THEN 0.8 
                                                ELSE 0.1
                                            END
                                    END
                            END,
                    region_data = coalesce (region_data, ''::HSTORE) || 
                                  slice (_bill_info, ARRAY['factor_of_difficulty_of_cure', 'factor_of_management', 'vmedpom_code', 'vmedpom_number']) || 
                                  hstore ('osn_kskp', (_bill_info -> 'codes_of_difficulty_of_cure_arr')) || 
                                  hstore ('gs', CASE WHEN (_mo_info.extra_info -> 'org_terr_type') = 'village' THEN 'S' ELSE 'G' END) || 
                                  hstore ('kod_mo', _mo_info.code) || 
                                  hstore ('otcl_dn', (_r.quantity - _r.mes_duration)::TEXT) || 
                                  hstore 
                                  (
                                      'idotd', 
                                      CASE 
                                          WHEN _r.bed_profile_code IN ('105', '106', '10550', '10650') AND _r.csg IN ('61', '77') THEN 'КСТР'
                                          ELSE concat 
                                               (
                                                   'КДН', 
                                                   CASE 
                                                       WHEN (_mo_info.extra_info -> 'org_spec_type') = 'tc' THEN 'Т' 
                                                       WHEN _r.attendant_id IS NOT NULL THEN 'М'
                                                       ELSE NULL 
                                                   END
                                               )
                                      END
                                  )
                WHERE
                    bill_id = _r.bill_id AND id = _r.id
                ;
            END IF;
            IF
                exist (_bill_info, 'special_mes_duration')
            THEN
                UPDATE fin_bill_generate 
                SET 
                    region_data = coalesce (region_data, ''::HSTORE) || 
                                  hstore ('sts', _bill_info -> 'special_mes_duration') || 
                                  hstore ('otcl_dn', (_r.quantity - (_bill_info -> 'special_mes_duration')::DECIMAL)::TEXT) 
                WHERE
                    bill_id = _r.bill_id AND id = _r.id
                ;
                _bill_info := _bill_info - 'special_mes_duration'::TEXT;
            END IF;
        END LOOP;
    END IF;
    -------------------------------------------------------дневной стационар------------------------------------------------------------------
    IF
        _price_type LIKE 'day%hospital'
    THEN
        _bill_info := hstore ('srv_code', 'DSKSG');
        _bill_info := _bill_info || 
            hstore ('vmedpom_code', CASE WHEN _price_type = 'day_hospital' THEN '3' WHEN _price_type = 'day_home_hospital' THEN '6' WHEN _price_type = 'day_ambulatory_hospital' THEN '7' END) || 
            hstore ('vmedpom_number', CASE WHEN _price_type = 'day_hospital' THEN '3' WHEN _price_type = 'day_home_hospital' THEN '6' WHEN _price_type = 'day_ambulatory_hospital' THEN '7' END)
        ;
        --отсеивание для стационара
        WITH t AS
        (
            SELECT 
                bill_id, case_id, array_agg (id) AS id_arr 
            FROM 
                fin_bill_generate 
            WHERE 
                bill_id = p1_bill_id AND NOT is_sifted 
            GROUP BY 1, 2 
            HAVING NOT bool_or (service_code = (_bill_info -> 'srv_code'))
        )
        UPDATE fin_bill_generate AS f
        SET 
            is_sifted = TRUE, sifting_cause = 'В случае отсутствует необходимая фиктивная услуга'
        FROM t
        WHERE 
            f.bill_id = t.bill_id AND f.id = ANY (t.id_arr)
        ;
        --набор первичной информации
        _csg_full_payment_codes := 
        ARRAY[
            '9', '11', '18', '159', '177', '181', --обычные коды
            '111', '112', '113',                  --лучевая терапия
            '35', '36', '108', '109', '110',      --химиотерапия
            '12',                                 --случай ЭКО
            '99', '100'                           --процедуры гемодиализа и перитонеального диализа
        ];
        _mo_info := public.fin_get_mo_info (p1_bill_id);
        
        _bill_info := _bill_info || hstore ('pos_code', concat (CASE WHEN (_mo_info.extra_info -> 'org_terr_type') = 'village' THEN 'V' ELSE NULL END, 'DHCSG'));
        --проставление дат, res_group_id, КСГ
        WITH t AS 
        (
            SELECT 
                f.bill_id, f.id, s.res_group_id, s.id AS idcase, s.csg_id, f.case_open_date AS dbeg, f.case_close_date AS dend
            FROM
                fin_bill_generate AS f
                JOIN LATERAL
                (
                    SELECT id, csg_id, res_group_id FROM mc_step WHERE csg_id IS NOT NULL AND case_id = f.case_id ORDER BY outcome_date DESC LIMIT 1
                ) AS s ON TRUE
            WHERE
                f.bill_id = p1_bill_id AND NOT f.is_sifted
        )
        UPDATE fin_bill_generate AS f 
        SET 
            res_group_id = t.res_group_id,
            region_data = coalesce (f.region_data, hstore ('')) || hstore ('idcase', t.idcase::TEXT) || hstore ('csg_id', t.csg_id::TEXT) || hstore ('dbeg', t.dbeg::TEXT) || hstore ('dend', t.dend::TEXT)
        FROM t
        WHERE 
            f.bill_id = t.bill_id AND f.id = t.id
        ;
        --проставление дат, КСГ в случаях с переводами
        FOR _r IN
            SELECT 
                f.bill_id, f.case_id, (f.region_data -> 'idcase')::INTEGER AS idcase, b.id, b.res_group_id, b.csg_id, b.outcome_date
            FROM 
                fin_bill_generate AS f 
                JOIN mc_step AS s ON s.case_id = f.case_id 
                LEFT JOIN LATERAL 
                (
                    SELECT 
                        id, res_group_id, csg_id, outcome_date 
                    FROM 
                        mc_step 
                    WHERE 
                        case_id = f.case_id AND csg_id IS NOT NULL AND id <> (f.region_data -> 'idcase')::INTEGER
                    ORDER BY outcome_date DESC 
                    LIMIT 1
                ) AS b ON TRUE
            WHERE 
                f.bill_id = p1_bill_id AND NOT f.is_sifted AND s.csg_id IS NOT NULL
            GROUP BY 1, 2, 3, 4, 5, 6, 7
            HAVING count (DISTINCT s.csg_id) > 1
        LOOP
            UPDATE fin_bill_generate AS f 
            SET 
                res_group_id = _r.res_group_id,
                region_data = coalesce (f.region_data, hstore ('')) || hstore ('idcase', _r.id::TEXT) || hstore ('csg_id', _r.csg_id::TEXT) || hstore ('dend', _r.outcome_date::TEXT)
            WHERE 
                f.bill_id = _r.bill_id AND f.case_id = _r.case_id AND NOT f.is_sifted AND f.bdate <= _r.outcome_date AND f.step_id <> _r.idcase
            ;
            UPDATE fin_bill_generate AS f 
            SET 
                region_data = coalesce (f.region_data, hstore ('')) || hstore ('dbeg', _r.outcome_date::TEXT) 
            WHERE 
                f.bill_id = _r.bill_id AND f.case_id = _r.case_id AND NOT f.is_sifted AND (f.bdate > _r.outcome_date OR f.step_id = _r.idcase)
            ;
        END LOOP;
        UPDATE fin_bill_generate AS f
        SET
            patient_age = date_part ('year', age ((f.region_data -> 'dbeg')::DATE, i.birth_dt)), patient_gender_id = i.gender_id
        FROM 
            pim_individual AS i
        WHERE
            f.bill_id = p1_bill_id AND NOT f.is_sifted AND f.patient_id = i.id
        ;
        --фильтр по подразделениям
        IF 
            p2_status = 'GENERATE' AND EXISTS (SELECT 1 FROM fin_bill_main_department WHERE main_bill_id = _main_bill_id)
        THEN
            WITH t AS 
            (
                SELECT
                    f.bill_id, f.id
                FROM 
                    fin_bill_generate AS f
                    LEFT JOIN LATERAL (SELECT department_id AS id FROM hsp_record WHERE id = (f.region_data -> 'idcase')::INTEGER LIMIT 1) AS p ON TRUE
                WHERE
                    f.bill_id = p1_bill_id AND NOT f.is_sifted AND (p.id <> ALL (ARRAY (SELECT department_id FROM fin_bill_main_department WHERE main_bill_id = _main_bill_id)) OR p.id IS NULL)
            )
            UPDATE fin_bill_generate AS f
            SET
               is_sifted = TRUE, sifting_cause = 'Применён фильтр по подразделениям'
            FROM t
            WHERE
                f.bill_id = t.bill_id AND f.id = t.id AND NOT f.is_sifted
            ;
        END IF;
        WITH t AS
        (
            SELECT 
                f.bill_id, 
                f.id,
                trim (c.code) AS csg_code, 
                trim (c.name) AS csg_name, 
                c.type_code AS csg_type_code, 
                (SELECT id FROM sr_schedule_org WHERE org_id = f.org_id AND department_id IS NULL LIMIT 1) AS org_schedule_id, 
                h.department_id, 
                (SELECT duration FROM mc_mes_duration WHERE md_mes = s.mes_id LIMIT 1) AS mes_duration, 
                (SELECT code FROM mc_step_result WHERE id = s.result_id LIMIT 1) AS step_result_code, 
                r.coefficient AS factor_of_relative_capacity_costs, 
                p.code AS bed_profile_code, 
                k.code AS kod_oper, 
                replace (d.code, '*', '') AS dso
            FROM
                fin_bill_generate AS f
                JOIN LATERAL (SELECT mes_id, result_id FROM mc_step WHERE id = (f.region_data -> 'idcase')::INTEGER LIMIT 1) AS s ON TRUE
                JOIN LATERAL 
                (
                    SELECT 
                        c.code, c.name, t.code AS type_code 
                    FROM 
                        md_clinical_statistical_group AS c, md_csg_type AS t 
                    WHERE 
                        c.type_id = t.id AND c.id = (f.region_data -> 'csg_id')::INTEGER
                    LIMIT 1
                ) AS c ON TRUE
                LEFT JOIN LATERAL (SELECT bed_profile_id, department_id FROM hsp_record WHERE id = (f.region_data -> 'idcase')::INTEGER LIMIT 1) AS h ON TRUE
                LEFT JOIN LATERAL 
                (
                    SELECT 
                        nullif (trim (replace (replace (c.value, ' ', ''), ',', '.')), '') ::DECIMAL AS coefficient 
                    FROM 
                        md_csg_cond AS c, md_csg_cond_type AS t 
                    WHERE 
                        c.type_id = t.id AND c.csg_id = (f.region_data -> 'csg_id')::INTEGER AND daterange (c.from_dt, c.to_dt, '[]') @> f.case_close_date
                        AND t.code = concat 
                                    (
                                        'KZDS', CASE WHEN (_mo_info.extra_info -> 'org_terr_type') = 'village' THEN 's' ELSE NULL END, 
                                        CASE 
                                            WHEN 
                                                EXISTS 
                                                (
                                                    SELECT 1 FROM pim_department_code AS c, pim_department_code_type AS t 
                                                    WHERE 
                                                        c.type_id = t.id AND t.code = concat ((_bill_info -> 'vmedpom_code'), 'p')
                                                        AND c.department_id = coalesce (h.department_id, 0) 
                                                        AND daterange (c.from_dt, c.to_dt, '[]') && daterange (f.from_date, f.to_date, '[]') 
                                                )
                                            THEN
                                                'pit'
                                            WHEN
                                                EXISTS 
                                                (
                                                    SELECT 1 FROM pim_department_code AS c, pim_department_code_type AS t 
                                                    WHERE 
                                                        c.type_id = t.id AND t.code = concat ((_bill_info -> 'vmedpom_code'), 'bp')
                                                        AND c.department_id = coalesce (h.department_id, 0) 
                                                        AND daterange (c.from_dt, c.to_dt, '[]') && daterange (f.from_date, f.to_date, '[]') 
                                                )
                                            THEN
                                                NULL
                                            WHEN
                                                EXISTS 
                                                (
                                                    SELECT 1 FROM pim_org_coefficient AS c, pim_org_coefficient_type AS t 
                                                    WHERE 
                                                        c.type_id = t.id AND t.code = concat ((_bill_info -> 'vmedpom_code'), 'p')
                                                        AND c.org_id = f.org_id
                                                        AND daterange (c.from_dt, c.to_dt, '[]') && daterange (f.from_date, f.to_date, '[]') 
                                                )
                                            THEN 
                                                'pit' 
                                            ELSE 
                                                NULL 
                                        END
                                    )
                    ORDER BY c.from_dt DESC NULLS LAST, c.to_dt DESC, c.id DESC
                    LIMIT 1
                ) AS r ON TRUE
                LEFT JOIN LATERAL (SELECT code FROM md_bed_profile WHERE id = h.bed_profile_id LIMIT 1) AS p ON TRUE 
                LEFT JOIN LATERAL (SELECT diagnos_id FROM mc_diagnosis WHERE is_main AND case_id = f.case_id ORDER BY stage_id DESC NULLS LAST, establishment_date DESC NULLS LAST, id DESC LIMIT 1) AS m ON TRUE
                LEFT JOIN LATERAL (SELECT code FROM md_diagnosis WHERE id = m.diagnos_id LIMIT 1) AS d ON TRUE
                LEFT JOIN LATERAL
                (
                    SELECT 
                        e.code 
                    FROM 
                        md_srv_rendered      AS m 
                        JOIN sr_srv_rendered AS r ON m.id = r.id
                        JOIN sr_service      AS e ON e.id = r.service_id 
                    WHERE
                        m.case_id = f.case_id AND m.id <> f.id AND r.bdate <= (f.region_data -> 'dend')::DATE
                        AND EXISTS (SELECT 1 FROM md_csg_to_srv_prototype WHERE csg_id = (f.region_data -> 'csg_id')::INTEGER AND srv_prototype_id = e.prototype_id)
                    ORDER BY r.bdate DESC, m.id DESC
                    LIMIT 1
                ) AS k ON TRUE
            WHERE
                f.bill_id = p1_bill_id AND NOT f.is_sifted 
        )
        UPDATE fin_bill_generate AS f
        SET
            quantity = ((f.region_data -> 'dend')::DATE - (f.region_data -> 'dbeg')::DATE) + 1,
            region_data = coalesce (f.region_data, ''::HSTORE) ||
                          hstore ('csg_code', t.csg_code::TEXT) || 
                          hstore ('csg_name', t.csg_name::TEXT) || 
                          hstore ('csg_type_code', t.csg_type_code::TEXT) || 
                          hstore ('sts', t.mes_duration::TEXT) || 
                          hstore ('department_id', t.department_id::TEXT) || 
                          hstore ('org_schedule_id', t.org_schedule_id::TEXT) || 
                          hstore ('factor_of_level_of_hospital_care', coalesce (nullif ((_mo_info.extra_info -> 'factor_of_level_of_hospital_care'), ''), '1')) || 
                          hstore ('factor_of_relative_capacity_costs', coalesce (t.factor_of_relative_capacity_costs, '1')::TEXT) || 
                          hstore ('idprof', t.bed_profile_code::TEXT) || 
                          hstore ('kod_oper', t.kod_oper::TEXT) || 
                          hstore ('ishod', t.step_result_code::TEXT) || 
                          hstore ('dso', t.dso) 
        FROM t
        WHERE
            f.id = t.id AND f.bill_id = t.bill_id
        ;
        --перерасчёт койко-дней с учётом выходных и праздничных дней подразделения
        FOR _r IN 
            SELECT 
                bill_id, id, 
                (region_data -> 'department_id')::INTEGER AS department_id, 
                (region_data -> 'org_schedule_id')::INTEGER AS org_schedule_id, 
                (region_data -> 'dbeg')::DATE AS dbeg, 
                (region_data -> 'dend')::DATE AS dend
            FROM
                fin_bill_generate
            WHERE
                bill_id = p1_bill_id AND NOT is_sifted
        LOOP
            WITH RECURSIVE department_schedule AS 
            (
                SELECT d.id, d.parent_id, s.id AS schedule_id FROM pim_department AS d LEFT JOIN sr_schedule_org AS s ON s.department_id = d.id WHERE d.id = _r.department_id
                UNION ALL
                SELECT p.id, p.parent_id, s.id AS schedule_id FROM department_schedule AS t, pim_department AS p LEFT JOIN sr_schedule_org AS s ON s.department_id = p.id WHERE t.parent_id = p.id 
            )
            UPDATE fin_bill_generate AS f
            SET
                quantity  = f.quantity
                            - 
                            (
                                SELECT 
                                    count (DISTINCT date) 
                                FROM 
                                    sr_org_shift 
                                WHERE 
                                    schedule_org_id = coalesce ((SELECT schedule_id FROM department_schedule WHERE schedule_id IS NOT NULL LIMIT 1), _r.org_schedule_id)
                                    AND time_type_id = 2 
                                    AND date <@ daterange (_r.dbeg, _r.dend, '[]')
                            )
            WHERE
                f.bill_id = _r.bill_id AND f.id = _r.id
            ;
        END LOOP;
        FOR _r IN
            SELECT
                f.bill_id,
                f.id, 
                f.service_code,
                f.quantity, 
                (f.region_data -> 'idcase')::INTEGER AS step_id,
                (f.region_data -> 'dend')::DATE AS close_date,
                f.attendant_id,
                p.price AS base_tariff,
                f.region_data -> 'csg_code' AS csg,
                f.region_data -> 'csg_type_code' AS csg_type,
                f.region_data -> 'idprof' AS bed_profile_code,
                (f.region_data -> 'sts')::DECIMAL AS mes_duration,
                (f.region_data -> 'factor_of_level_of_hospital_care')::DECIMAL AS factor_of_level_of_hospital_care,  --коэффициент уровня оказания стационарной медпомощи
                (f.region_data -> 'factor_of_relative_capacity_costs')::DECIMAL AS factor_of_relative_capacity_costs,--коэффициент относительной затратоёмкости
                coalesce (v.code, '') AS dv_code 
            FROM
                fin_bill_generate AS f
                JOIN LATERAL (SELECT deviation_reason_id FROM mc_step WHERE id = (f.region_data -> 'idcase')::INTEGER LIMIT 1) AS s ON TRUE
                LEFT JOIN LATERAL (SELECT code FROM mc_deviation_reason WHERE id = s.deviation_reason_id LIMIT 1) AS v ON TRUE
                LEFT JOIN LATERAL 
                (
                    SELECT price FROM fin_pl_position 
                    WHERE 
                        price_list_id = f.price_list_id AND daterange (from_dt::DATE, to_dt::DATE, '[]') @> (f.region_data -> 'dend')::DATE AND code = (_bill_info -> 'pos_code') 
                    ORDER BY to_dt DESC 
                    LIMIT 1
                ) AS p ON TRUE
            WHERE
                f.bill_id = p1_bill_id AND NOT f.is_sifted
        LOOP
            --управленческий коэффициент
            _bill_info := _bill_info || hstore ('factor_of_management', '1');
            --1
            --КСГ = 12 «Экстракорпоральное оплодотворение»
            IF 
                _r.csg = '12'
            THEN
                IF
                    _r.close_date < '2015-10-01'::DATE
                THEN
                    _bill_info := _bill_info || hstore ('factor_of_management', '1.1');
                ELSIF
                    _r.close_date < '2015-11-01'::DATE
                THEN
                    _bill_info := _bill_info || hstore ('factor_of_management', '1');
                ELSIF
                    _r.close_date < '2015-12-01'::DATE
                THEN
                    _bill_info := _bill_info || hstore ('factor_of_management', '1.05');
                ELSE
                    _bill_info := _bill_info || hstore ('factor_of_management', '1.16');
                END IF;
            --2
            --КСГ = 99 «Гемодиализ»
            ELSIF 
                _r.csg = '99'
            THEN 
                 IF
                    _r.close_date < '2015-10-01'::DATE
                THEN
                    _bill_info := _bill_info || hstore ('factor_of_management', '1.075');
                ELSIF
                    _r.close_date < '2015-11-01'::DATE
                THEN
                    _bill_info := _bill_info || hstore ('factor_of_management', '1');
                ELSIF
                    _r.close_date < '2015-12-01'::DATE
                THEN
                    _bill_info := _bill_info || hstore ('factor_of_management', '1.05');
                ELSE
                    _bill_info := _bill_info || hstore ('factor_of_management', '1.13');
                END IF;
            --3
            --КСГ = 80 «Паралитические синдромы, травма спинного мозга» или КСГ = 250 «Сахарный диабет с осложнениями, взрослые»
            ELSIF 
                _r.csg IN ('80', '250') 
            THEN 
                _bill_info := _bill_info || hstore ('factor_of_management', '0.9');
            --4
            --КСГ = 100 «Перитонеальный диализ»
            ELSIF 
                _r.csg = '100'
            THEN 
                IF
                    _r.close_date < '2015-10-01'::DATE
                THEN
                    _bill_info := _bill_info || hstore ('factor_of_management', '0.95');
                ELSIF
                    _r.close_date < '2015-11-01'::DATE
                THEN
                    _bill_info := _bill_info || hstore ('factor_of_management', '0.9');
                ELSIF
                    _r.close_date < '2015-12-01'::DATE
                THEN
                    _bill_info := _bill_info || hstore ('factor_of_management', '0.95');
                ELSE
                    _bill_info := _bill_info || hstore ('factor_of_management', '1');
                END IF;
            END IF;
            --коэффициент сложности курации пациента
            _bill_info := _bill_info || hstore ('factor_of_difficulty_of_cure', '1') || hstore ('codes_of_difficulty_of_cure_arr', NULL::TEXT);
            --полная/неполная оплата
            IF
                _r.quantity > 3 OR _r.csg = ANY (_csg_full_payment_codes) OR _r.csg_type = '2'
            THEN
                FOR _s IN 
                    SELECT 
                        c.value, c.code
                    FROM
                        mc_step_cur_coef_criteria AS s, mc_cur_coef_criteria AS c
                    WHERE
                        c.id = s.criteria_id AND s.step_id = _r.step_id
                LOOP
                    _bill_info := _bill_info || hstore ('codes_of_difficulty_of_cure_arr', concat (rtrim ((_bill_info -> 'codes_of_difficulty_of_cure_arr'), ',') || ',', _s.code));
                    _bill_info := _bill_info || hstore ('factor_of_difficulty_of_cure', ((_bill_info -> 'factor_of_difficulty_of_cure')::DECIMAL * _s.value)::TEXT);
                END LOOP;
                
                _bill_info := _bill_info || hstore ('factor_of_difficulty_of_cure', round ((_bill_info -> 'factor_of_difficulty_of_cure')::DECIMAL, 2)::TEXT);
                
                IF (_bill_info -> 'factor_of_difficulty_of_cure')::DECIMAL > 1.8 THEN _bill_info := _bill_info || hstore ('factor_of_difficulty_of_cure', '1.8'); END IF;
                
                UPDATE fin_bill_generate 
                SET 
                    tariff = _r.base_tariff, 
                    price = CASE 
                                WHEN  _r.service_code ~ '[AB].+' THEN 0 
                                ELSE
                                    _r.base_tariff 
                                    *
                                    _r.factor_of_relative_capacity_costs
                                    *
                                    (_bill_info -> 'factor_of_management')::DECIMAL 
                                    * 
                                    _r.factor_of_level_of_hospital_care 
                                    *
                                    (_bill_info -> 'factor_of_difficulty_of_cure')::DECIMAL
                                END,
                    region_data = coalesce (region_data, ''::HSTORE) || 
                                  slice (_bill_info, ARRAY['factor_of_difficulty_of_cure', 'factor_of_management', 'vmedpom_code', 'vmedpom_number']) || 
                                  hstore ('osn_kskp', (_bill_info -> 'codes_of_difficulty_of_cure_arr')) || 
                                  hstore ('gs', CASE WHEN (_mo_info.extra_info -> 'org_terr_type') = 'village' THEN 'S' ELSE 'G' END) || 
                                  hstore ('kod_mo', _mo_info.code) || 
                                  hstore ('otcl_dn', (_r.quantity - _r.mes_duration)::TEXT) || 
                                  hstore ('idotd', 'КСГД')
                WHERE
                    bill_id = _r.bill_id AND id = _r.id
                ;
            ELSE
                UPDATE fin_bill_generate 
                SET 
                    tariff = _r.base_tariff, 
                    price = CASE 
                                WHEN  _r.service_code ~ '[AB].+' THEN 0 
                                ELSE
                                    round
                                    (
                                        _r.base_tariff * _r.factor_of_relative_capacity_costs * _r.factor_of_level_of_hospital_care
                                        *
                                        (_bill_info -> 'factor_of_management')::DECIMAL 
                                        *
                                        (_bill_info -> 'factor_of_difficulty_of_cure')::DECIMAL,
                                        2
                                    ) * 0.25
                                END,
                    region_data = coalesce (region_data, ''::HSTORE) || 
                                  slice (_bill_info, ARRAY['factor_of_difficulty_of_cure', 'factor_of_management', 'vmedpom_code', 'vmedpom_number']) || 
                                  hstore ('osn_kskp', (_bill_info -> 'codes_of_difficulty_of_cure_arr')) || 
                                  hstore ('gs', CASE WHEN (_mo_info.extra_info -> 'org_terr_type') = 'village' THEN 'S' ELSE 'G' END) || 
                                  hstore ('kod_mo', _mo_info.code) || 
                                  hstore ('otcl_dn', (_r.quantity - _r.mes_duration)::TEXT) || 
                                  hstore ('idotd', 'ПАЦД')
                WHERE
                    bill_id = _r.bill_id AND id = _r.id
                ;
            END IF;
        END LOOP;
    END IF;
    ----------------------------------------------------------------------ВМП------------------------------------------------------------------------
    IF
        _price_type = 'hightech'
    THEN
        _mo_info := public.fin_get_mo_info (p1_bill_id);
        --отсеивание для ВМП
        UPDATE fin_bill_generate
        SET 
            is_sifted = TRUE, sifting_cause = 'Услуга ВМП не из закрывающего ЗОГа'
        WHERE 
            bill_id = p1_bill_id AND coalesce (step_id, 0) <> closing_step_id
        ;
        WITH t AS 
        (
            SELECT 
                f.bill_id, 
                f.id, 
                f.case_id, 
                p.price AS tariff,
                (SELECT code FROM md_bed_profile WHERE id = h.bed_profile_id LIMIT 1) AS bed_profile_code,
                (SELECT duration FROM mc_mes_duration WHERE md_mes = s.mes_id LIMIT 1) AS mes_duration,
                (SELECT code FROM mc_step_result WHERE id = t.result_id LIMIT 1) AS step_result_code,
                (SELECT code FROM mc_vmp_type WHERE id = s.vmp_type_id LIMIT 1) AS type_code,
                m.code AS method_code,
                d.code AS ds
            FROM
                fin_bill_generate AS f
                JOIN LATERAL (SELECT vmp_type_id, vmp_method_id, mes_id FROM mc_step WHERE id = f.closing_step_id LIMIT 1) AS s ON TRUE
                JOIN LATERAL (SELECT result_id FROM mc_step WHERE id = f.closing_step_id LIMIT 1) AS t ON TRUE
                LEFT JOIN LATERAL (SELECT diagnos_id FROM mc_diagnosis WHERE is_main AND case_id = f.case_id ORDER BY stage_id DESC NULLS LAST, establishment_date DESC NULLS LAST, id DESC LIMIT 1) AS c ON TRUE
                LEFT JOIN LATERAL (SELECT code FROM md_diagnosis WHERE id = c.diagnos_id LIMIT 1) AS d ON TRUE
                LEFT JOIN LATERAL (SELECT bed_profile_id FROM hsp_record WHERE id = f.closing_step_id LIMIT 1) AS h ON TRUE
                LEFT JOIN LATERAL (SELECT e_code, code FROM mc_vmp_method WHERE id = s.vmp_method_id LIMIT 1) AS m ON TRUE
                LEFT JOIN LATERAL (SELECT price FROM fin_pl_position WHERE price_list_id = f.price_list_id AND daterange (from_dt::DATE, to_dt::DATE, '[]') @> f.case_close_date AND code = m.e_code LIMIT 1) AS p ON TRUE
            WHERE
                f.bill_id = p1_bill_id AND NOT f.is_sifted AND f.service_code = 'VMPSG'
        )
        UPDATE fin_bill_generate AS f
        SET
            quantity = coalesce (nullif (f.case_close_date - f.case_open_date, 0), 1), tariff = t.tariff, price = t.tariff,
            region_data = coalesce (f.region_data, ''::HSTORE) ||
                          hstore ('vmedpom_code', 'B') || 
                          hstore ('vmedpom_number', '11') || 
                          hstore ('idcase', t.case_id::TEXT) || 
                          hstore ('idprof', t.bed_profile_code::TEXT) || 
                          hstore ('idotd', 'ЗСЛ') || 
                          hstore ('sts', t.mes_duration::TEXT) || 
                          hstore ('otcl_dn', ((f.case_close_date - f.case_open_date) - t.mes_duration)::TEXT) || 
                          hstore ('ishod', t.step_result_code::TEXT) || 
                          hstore ('hvid', t.type_code::TEXT) || 
                          hstore ('hmet', t.method_code::TEXT) || 
                          hstore ('ds', t.ds::TEXT) || 
                          hstore ('gs', CASE WHEN (_mo_info.extra_info -> 'org_terr_type') = 'village' THEN 'S' ELSE 'G' END) || 
                          hstore ('kod_mo', _mo_info.code) 
        FROM t
        WHERE
            f.id = t.id AND f.bill_id = t.bill_id AND NOT f.is_sifted
        ;
    END IF;
    ------------------------------------------------------------------реабилитация-------------------------------------------------------------------
    IF
        _price_type = 'rehab'
    THEN
        _mo_info := public.fin_get_mo_info (p1_bill_id);
        --проставление дат
        UPDATE public.fin_bill_generate AS f 
        SET 
            region_data = coalesce (f.region_data, hstore ('')) || hstore ('dbeg', f.case_open_date::TEXT) || hstore ('dend', f.case_close_date::TEXT) || hstore ('idcase', f.case_id::TEXT)
        WHERE 
            f.bill_id = p1_bill_id AND NOT f.is_sifted
        ;
        --проставление дат в случаях с переводами
        FOR _r IN
            SELECT 
                f.bill_id, f.case_id, b.id, b.outcome_date
            FROM 
                public.fin_bill_generate AS f 
                JOIN public.mc_step AS s ON f.step_id = s.id 
                LEFT JOIN LATERAL (SELECT id, outcome_date FROM public.mc_step WHERE case_id = f.case_id AND id <> f.closing_step_id ORDER BY outcome_date DESC LIMIT 1) AS b ON TRUE
            WHERE 
                f.bill_id = p1_bill_id AND NOT f.is_sifted 
            GROUP BY 1, 2, 3, 4
            HAVING count (DISTINCT f.step_id) > 1
        LOOP
            UPDATE public.fin_bill_generate AS f 
            SET 
                region_data = coalesce (f.region_data, hstore ('')) || hstore ('dend', _r.outcome_date::TEXT)
            WHERE 
                f.bill_id = p1_bill_id AND f.case_id = _r.case_id AND NOT f.is_sifted AND f.bdate <= _r.outcome_date
            ;
            UPDATE public.fin_bill_generate AS f 
            SET 
                region_data = coalesce (f.region_data, hstore ('')) || hstore ('dbeg', _r.outcome_date::TEXT)
            WHERE 
                f.bill_id = p1_bill_id AND f.case_id = _r.case_id AND NOT f.is_sifted AND f.bdate > _r.outcome_date
            ;
        END LOOP;
        WITH t AS 
        (
            SELECT 
                f.bill_id, 
                f.id, 
                r.code AS hsp_code,
                r.idotd,
                p.code AS tariff_code,
                coalesce (p.tariff, 0) AS tariff,
                (SELECT code FROM public.md_bed_profile WHERE id = h.bed_profile_id LIMIT 1) AS bed_profile_code,
                (SELECT duration FROM public.mc_mes_duration WHERE md_mes = s.mes_id LIMIT 1) AS mes_duration,
                (SELECT code FROM public.mc_step_result WHERE id = s.result_id LIMIT 1) AS step_result_code
            FROM
                public.fin_bill_generate AS f
                JOIN LATERAL 
                (
                    SELECT 
                        concat ('R', CASE WHEN lower (name) LIKE '%дневн%' THEN 'D' ELSE NULL END) AS code,
                        CASE 
                            WHEN lower (name) NOT LIKE '%дневн%' THEN concat ('РС', CASE WHEN f.attendant_id IS NOT NULL THEN 'М' ELSE NULL END)
                            ELSE concat ('РДС', CASE WHEN lower (name) LIKE '%дом%' THEN 'Д' WHEN lower (name) LIKE '%поликлиник%' THEN 'П' ELSE 'С' END) 
                        END AS idotd
                    FROM 
                        public.mc_care_regimen 
                    WHERE 
                        id = f.care_regimen_id 
                    LIMIT 1
                ) AS r ON TRUE
                JOIN LATERAL (SELECT admission_date, outcome_date, mes_id, result_id FROM public.mc_step WHERE id = f.step_id LIMIT 1) AS s ON TRUE
                LEFT JOIN LATERAL (SELECT bed_profile_id FROM public.hsp_record WHERE id = f.step_id LIMIT 1) AS h ON TRUE
                LEFT JOIN public.fin_get_tariff_from_pricelist (f.id, f.price_pos_arr[1]) AS p ON TRUE
            WHERE
                f.bill_id = p1_bill_id AND NOT f.is_sifted
        )
        UPDATE public.fin_bill_generate AS f
        SET
            quantity = CASE 
                           WHEN 
                               t.hsp_code = 'RD' 
                           THEN 
                               ((f.region_data -> 'dend')::DATE - (f.region_data -> 'dbeg')::DATE) + 1
                           ELSE
                               coalesce (nullif ((f.region_data -> 'dend')::DATE - (f.region_data -> 'dbeg')::DATE, 0), 1)
                       END,
            tariff = t.tariff, 
            region_data = coalesce (f.region_data, ''::HSTORE) ||
                          hstore ('vmedpom_code', 'D') || 
                          hstore ('vmedpom_number', '13') || 
                          hstore ('tariff_code', t.tariff_code) || 
                          hstore ('idprof', t.bed_profile_code::TEXT) || 
                          hstore ('idotd', t.idotd) || 
                          hstore ('sts', t.mes_duration::TEXT) || 
                          hstore ('otcl_dn', ((f.case_close_date - f.case_open_date) - t.mes_duration)::TEXT) || 
                          hstore ('ishod', t.step_result_code::TEXT) || 
                          hstore ('gs', CASE WHEN (_mo_info.extra_info -> 'org_terr_type') = 'village' THEN 'S' ELSE 'G' END) || 
                          hstore ('kod_mo', _mo_info.code)
        FROM t
        WHERE
            f.id = t.id AND f.bill_id = t.bill_id AND NOT f.is_sifted
        ;
    END IF;
    ------------------------------------------------------------диспансеризация I этап---------------------------------------------------------------
    IF
        _price_type = 'dispensary_1'
    THEN
        _mo_info := public.fin_get_mo_info (p1_bill_id);
        _bill_info := hstore ('oms_id', (SELECT id FROM pim_code_type WHERE code = 'CODE_OMS' LIMIT 1)::TEXT) || hstore ('srv_code', '8804');
        
        WITH t AS 
        (
            SELECT
                f.bill_id, 
                f.id,
                f.case_id,
                f.case_open_date,
                f.case_close_date,
                t.tariff,
                t.code,
                t.name,
                e.code AS type_code,
                z.code AS grzd,
                (SELECT code FROM mc_care_regimen WHERE id = f.care_regimen_id LIMIT 1) AS regimen_code,
                (SELECT code FROM mc_step_result WHERE id = s.result_id LIMIT 1) AS step_result_code,
                o.mo_sub,
                coalesce (r.code, '0') AS srv_result_code,
                coalesce ((SELECT is_refused FROM sr_srv_rendered WHERE id = f.id LIMIT 1), FALSE) AS srv_is_refused
            FROM
                fin_bill_generate AS f
                JOIN LATERAL (SELECT t.code FROM sr_service AS s, sr_srv_type AS t WHERE s.type_id = t.id AND s.id = f.service_id LIMIT 1) AS e ON TRUE
                JOIN LATERAL (SELECT result_id FROM mc_step WHERE id = f.step_id LIMIT 1) AS s ON TRUE
                LEFT JOIN fin_get_tariff_from_pricelist (f.id, f.price_pos_arr[1]) AS t ON TRUE
                LEFT JOIN LATERAL (SELECT r.value AS code FROM sr_srv_result AS r, sr_srv_result_type AS y WHERE y.id = r.result_type_id AND r.service_id = f.id AND t.code = '20' LIMIT 1) AS r ON TRUE
                LEFT JOIN LATERAL (SELECT h.code FROM md_srv_rendered AS m, mc_health_group AS h WHERE m.health_group_id = h.id AND m.id = f.id LIMIT 1) AS z ON TRUE
                LEFT JOIN LATERAL 
                (
                    SELECT trim (code) AS mo_sub FROM pim_org_code WHERE org_id = f.org_id AND f.org_id <> _clinic_id AND type_id = (_bill_info -> 'oms_id')::INTEGER ORDER BY issue_dt DESC NULLS LAST LIMIT 1
                ) AS o ON TRUE
            WHERE
                f.bill_id = p1_bill_id AND NOT f.is_sifted
        )
        UPDATE fin_bill_generate AS f
        SET
            quantity = 1, tariff = t.tariff, price = t.tariff, tariff_code = t.code, tariff_name = t.name, 
            region_data = coalesce (f.region_data, ''::HSTORE) || 
                          hstore ('vmedpom_code', 'R') || 
                          hstore ('vmedpom_number', '27') || 
                          hstore ('idcase', t.case_id::TEXT) || 
                          hstore ('idotd', CASE WHEN t.regimen_code  = '123' THEN 'МОБ' ELSE NULL END::TEXT) || 
                          hstore ('ishod', t.step_result_code::TEXT) || 
                          hstore ('dbeg', t.case_open_date::TEXT) || 
                          hstore ('dend', t.case_close_date::TEXT) || 
                          hstore ('type', t.type_code::TEXT) || 
                          hstore ('grzd', t.grzd::TEXT) || 
                          hstore ('not_in_composition', CASE WHEN t.srv_result_code = '1' OR t.srv_is_refused THEN '1' ELSE '0' END::TEXT) || 
                          hstore ('mo_sub', t.mo_sub::TEXT) || 
                          hstore ('gs', CASE WHEN (_mo_info.extra_info -> 'org_terr_type') = 'village' THEN 'S' ELSE 'G' END) || 
                          hstore ('kod_mo', _mo_info.code)
        FROM t
        WHERE
            f.bill_id = t.bill_id AND f.id = t.id
        ;
        FOR _r IN
            SELECT 
                f.bill_id, 
                f.case_id, 
                coalesce ((SELECT sum (1) FROM sr_srv_composition WHERE complex_id = c.id), 0) AS cnt_of_composition,
                sum ((f.region_data -> 'not_in_composition')::INTEGER) AS cnt_of_not_composition,
                sum (CASE WHEN service_code NOT LIKE 'д1%' THEN 1 ELSE 0 END) AS cnt_of_services,
                sum (CASE WHEN service_code NOT LIKE 'д1%' THEN f.tariff ELSE 0 END) AS sum_of_services,
                sum (CASE WHEN service_code LIKE 'д1%' THEN f.tariff ELSE 0 END) AS sum_of_fiction
            FROM 
                fin_bill_generate AS f
                LEFT JOIN LATERAL 
                (
                    SELECT s.id FROM md_srv_rendered AS m, sr_srv_rendered AS r, sr_service AS s WHERE m.id = r.id AND r.service_id = s.id AND m.case_id = f.case_id AND s.code LIKE 'д1%' ORDER BY r.id DESC LIMIT 1
                ) AS c ON TRUE
            WHERE 
                bill_id = p1_bill_id AND NOT is_sifted 
            GROUP BY 1, 2, 3
        LOOP
            IF
                _r.cnt_of_composition <> 0 AND _r.cnt_of_services / _r.cnt_of_composition::DECIMAL > 0.85 AND _r.cnt_of_not_composition / _r.cnt_of_services::DECIMAL < 0.15
            THEN
                UPDATE fin_bill_generate AS f
                SET
                    tariff = CASE WHEN f.service_code = (_bill_info -> 'srv_code') THEN 0 ELSE f.tariff END,
                    price = CASE WHEN f.service_code = (_bill_info -> 'srv_code') THEN _r.sum_of_fiction ELSE 0 END
                WHERE
                    f.bill_id = _r.bill_id AND f.case_id = _r.case_id
                ;
            ELSE
                UPDATE fin_bill_generate AS f
                SET
                    price = CASE WHEN f.service_code = (_bill_info -> 'srv_code') THEN _r.sum_of_services ELSE f.price END
                WHERE
                    f.bill_id = _r.bill_id AND f.case_id = _r.case_id 
                ;
            END IF;
        END LOOP;
    END IF;
    ------------------------------------------------------------диспансеризация II этап--------------------------------------------------------------
    IF
        _price_type = 'dispensary_2'
    THEN
        _mo_info := public.fin_get_mo_info (p1_bill_id);
        _bill_info := hstore ('oms_id', (SELECT id FROM pim_code_type WHERE code = 'CODE_OMS' LIMIT 1)::TEXT) || hstore ('srv_code', '8804');
        
        WITH t AS 
        (
            SELECT
                f.bill_id, 
                f.id, 
                f.case_id,
                f.case_open_date,
                f.case_close_date,
                t.tariff,
                t.code,
                t.name,
                e.code AS type_code,
                z.code AS grzd,
                (SELECT code FROM mc_step_result WHERE id = s.result_id LIMIT 1) AS step_result_code,
                o.mo_sub
            FROM
                fin_bill_generate AS f
                JOIN LATERAL (SELECT t.code FROM sr_service AS s, sr_srv_type AS t WHERE s.type_id = t.id AND s.id = f.service_id LIMIT 1) AS e ON TRUE
                JOIN LATERAL (SELECT result_id FROM mc_step WHERE id = f.step_id LIMIT 1) AS s ON TRUE
                LEFT JOIN fin_get_tariff_from_pricelist (f.id, f.price_pos_arr[1]) AS t ON TRUE
                LEFT JOIN LATERAL (SELECT h.code FROM md_srv_rendered AS m, mc_health_group AS h WHERE m.health_group_id = h.id AND m.id = f.id LIMIT 1) AS z ON TRUE
                LEFT JOIN LATERAL 
                (
                    SELECT trim (code) AS mo_sub FROM pim_org_code WHERE org_id = f.org_id AND f.org_id <> _clinic_id AND type_id = (_bill_info -> 'oms_id')::INTEGER ORDER BY issue_dt DESC NULLS LAST LIMIT 1
                ) AS o ON TRUE
            WHERE
                f.bill_id = p1_bill_id AND NOT f.is_sifted
        )
        UPDATE fin_bill_generate AS f
        SET
            quantity = 1, tariff = t.tariff, price = t.tariff, tariff_code = t.code, tariff_name = t.name, 
            region_data = coalesce (f.region_data, ''::HSTORE) || 
                          hstore ('vmedpom_code', 'S') || 
                          hstore ('vmedpom_number', '28') || 
                          hstore ('idcase', t.case_id::TEXT) || 
                          hstore ('idotd', NULL::TEXT) || 
                          hstore ('ishod', t.step_result_code::TEXT) || 
                          hstore ('dbeg', t.case_open_date::TEXT) || 
                          hstore ('dend', t.case_close_date::TEXT) || 
                          hstore ('type', t.type_code::TEXT) || 
                          hstore ('grzd', t.grzd::TEXT) || 
                          hstore ('mo_sub', t.mo_sub::TEXT) || 
                          hstore ('gs', CASE WHEN (_mo_info.extra_info -> 'org_terr_type') = 'village' THEN 'S' ELSE 'G' END) || 
                          hstore ('kod_mo', _mo_info.code)
        FROM t
        WHERE
            f.bill_id = t.bill_id AND f.id = t.id
        ;
        WITH t AS (SELECT bill_id, case_id, sum (tariff) AS price FROM fin_bill_generate WHERE bill_id = p1_bill_id AND NOT is_sifted GROUP BY 1, 2)
        UPDATE fin_bill_generate AS f
        SET
            tariff = CASE WHEN f.service_code = (_bill_info -> 'srv_code') THEN 0 ELSE f.tariff END,
            price = CASE WHEN f.service_code = (_bill_info -> 'srv_code') THEN t.price ELSE 0 END
        FROM t
        WHERE
            f.bill_id = t.bill_id AND f.case_id = t.case_id
        ;
    END IF;
    --------------------------------------------------------диспансеризация детей-сирот--------------------------------------------------------------
    IF
        _price_type = 'dispensary_orphan'
    THEN
        _mo_info := public.fin_get_mo_info (p1_bill_id);
        _bill_info := hstore ('oms_id', (SELECT id FROM pim_code_type WHERE code = 'CODE_OMS' LIMIT 1)::TEXT) || hstore ('srv_code', '8601');
        
        WITH t AS 
        (
            SELECT
                f.bill_id, 
                f.id, 
                f.case_id, 
                f.case_open_date,
                f.case_close_date,
                t.tariff,
                t.code,
                t.name,
                e.code AS type_code,
                z.code AS grzd,
                (SELECT code FROM mc_step_result WHERE id = s.result_id LIMIT 1) AS step_result_code,
                o.mo_sub
            FROM
                fin_bill_generate AS f
                JOIN LATERAL (SELECT t.code FROM sr_service AS s, sr_srv_type AS t WHERE s.type_id = t.id AND s.id = f.service_id LIMIT 1) AS e ON TRUE
                JOIN LATERAL (SELECT result_id FROM mc_step WHERE id = f.step_id LIMIT 1) AS s ON TRUE
                LEFT JOIN fin_get_tariff_from_pricelist (f.id, f.price_pos_arr[1]) AS t ON TRUE
                LEFT JOIN LATERAL (SELECT h.code FROM md_srv_rendered AS m, mc_health_group AS h WHERE m.health_group_id = h.id AND m.id = f.id LIMIT 1) AS z ON TRUE
                LEFT JOIN LATERAL 
                (
                    SELECT trim (code) AS mo_sub FROM pim_org_code WHERE org_id = f.org_id AND f.org_id <> _clinic_id AND type_id = (_bill_info -> 'oms_id')::INTEGER ORDER BY issue_dt DESC NULLS LAST LIMIT 1
                ) AS o ON TRUE
            WHERE
                f.bill_id = p1_bill_id AND NOT f.is_sifted
        )
        UPDATE fin_bill_generate AS f
        SET
            quantity = 1, tariff = t.tariff, price = t.tariff, tariff_code = t.code, tariff_name = t.name, 
            region_data = coalesce (f.region_data, ''::HSTORE) || 
                          hstore ('vmedpom_code', 'W') || 
                          hstore ('vmedpom_number', '32') || 
                          hstore ('idcase', t.case_id::TEXT) || 
                          hstore ('idotd', NULL::TEXT) || 
                          hstore ('ishod', t.step_result_code::TEXT) || 
                          hstore ('dbeg', t.case_open_date::TEXT) || 
                          hstore ('dend', t.case_close_date::TEXT) || 
                          hstore ('type', t.type_code::TEXT) || 
                          hstore ('grzd', t.grzd::TEXT) || 
                          hstore ('mo_sub', t.mo_sub::TEXT) || 
                          hstore ('gs', CASE WHEN (_mo_info.extra_info -> 'org_terr_type') = 'village' THEN 'S' ELSE 'G' END) || 
                          hstore ('kod_mo', _mo_info.code)
        FROM t
        WHERE
            f.bill_id = t.bill_id AND f.id = t.id
        ;
        WITH t AS (SELECT bill_id, case_id, sum (tariff) AS price FROM fin_bill_generate WHERE bill_id = p1_bill_id AND NOT is_sifted GROUP BY 1, 2)
        UPDATE fin_bill_generate AS f
        SET
            tariff = CASE WHEN f.service_code = (_bill_info -> 'srv_code') THEN 0 ELSE f.tariff END,
            price = CASE WHEN f.service_code = (_bill_info -> 'srv_code') THEN t.price ELSE 0 END
        FROM t
        WHERE
            f.bill_id = t.bill_id AND f.case_id = t.case_id
        ;
    END IF;
    --------------------------профосмотры взрослых, периодические, предварительные осмотры и профосмотры несовершеннолетних--------------------------
    IF
        _price_type LIKE 'prophylaxis%'
    THEN
        _mo_info := public.fin_get_mo_info (p1_bill_id);
        _bill_info := 
            hstore ('srv_code', CASE WHEN _price_type = 'prophylaxis' THEN '8804' ELSE '8601' END::TEXT) || 
            hstore ('oms_id', (SELECT id FROM pim_code_type WHERE code = 'CODE_OMS' LIMIT 1)::TEXT) || 
            hstore 
            (
                'vmedpom_code', 
                CASE 
                    _price_type 
                    WHEN 'prophylaxis'                      THEN 'T' 
                    WHEN 'prophylaxis_underage'             THEN 'X' 
                    WHEN 'prophylaxis_underage_preliminary' THEN 'Y' 
                    WHEN 'prophylaxis_underage_periodic'    THEN 'Z' 
                    ELSE NULL 
                END::TEXT
            ) ||
            hstore
            (
                'vmedpom_number', 
                CASE 
                    _price_type 
                    WHEN 'prophylaxis'                      THEN '29' 
                    WHEN 'prophylaxis_underage'             THEN '33' 
                    WHEN 'prophylaxis_underage_preliminary' THEN '34' 
                    WHEN 'prophylaxis_underage_periodic'    THEN '35' 
                    ELSE NULL 
                END::TEXT
            )
        ;
        WITH t AS 
        (
            SELECT
                f.bill_id, 
                f.id, 
                f.case_id,
                f.case_open_date,
                f.case_close_date,
                t.tariff,
                t.code,
                t.name,
                e.code AS type_code,
                z.code AS grzd,
                (SELECT code FROM mc_step_result WHERE id = s.result_id LIMIT 1) AS step_result_code,
                o.mo_sub
            FROM
                fin_bill_generate AS f
                JOIN LATERAL (SELECT t.code FROM sr_service AS s, sr_srv_type AS t WHERE s.type_id = t.id AND s.id = f.service_id LIMIT 1) AS e ON TRUE
                JOIN LATERAL (SELECT result_id FROM mc_step WHERE id = f.step_id LIMIT 1) AS s ON TRUE
                LEFT JOIN fin_get_tariff_from_pricelist (f.id, f.price_pos_arr[1]) AS t ON TRUE
                LEFT JOIN LATERAL (SELECT h.code FROM md_srv_rendered AS m, mc_health_group AS h WHERE m.health_group_id = h.id AND m.id = f.id LIMIT 1) AS z ON TRUE
                LEFT JOIN LATERAL 
                (
                    SELECT trim (code) AS mo_sub FROM pim_org_code WHERE org_id = f.org_id AND f.org_id <> _clinic_id AND type_id = (_bill_info -> 'oms_id')::INTEGER ORDER BY issue_dt DESC NULLS LAST LIMIT 1
                ) AS o ON TRUE
            WHERE
                f.bill_id = p1_bill_id AND NOT f.is_sifted
        )
        UPDATE fin_bill_generate AS f
        SET
            quantity = 1, tariff = t.tariff, price = t.tariff, tariff_code = t.code, tariff_name = t.name, 
            region_data = coalesce (f.region_data, ''::HSTORE) || 
                          slice (_bill_info, ARRAY ['vmedpom_code', 'vmedpom_number']) || 
                          hstore ('idotd', NULL::TEXT) || 
                          hstore ('idcase', t.case_id::TEXT) || 
                          hstore ('ishod', t.step_result_code::TEXT) || 
                          hstore ('dbeg', t.case_open_date::TEXT) || 
                          hstore ('dend', t.case_close_date::TEXT) || 
                          hstore ('type', t.type_code::TEXT) || 
                          hstore ('grzd', t.grzd::TEXT) || 
                          hstore ('mo_sub', t.mo_sub::TEXT) || 
                          hstore ('gs', CASE WHEN (_mo_info.extra_info -> 'org_terr_type') = 'village' THEN 'S' ELSE 'G' END) || 
                          hstore ('kod_mo', _mo_info.code)
        FROM t
        WHERE
            f.bill_id = t.bill_id AND f.id = t.id
        ;
        WITH t AS (SELECT bill_id, case_id, sum (tariff) AS price FROM fin_bill_generate WHERE bill_id = p1_bill_id AND NOT is_sifted GROUP BY 1, 2)
        UPDATE fin_bill_generate AS f
        SET
            tariff = CASE WHEN f.service_code = (_bill_info -> 'srv_code') THEN 0 ELSE f.tariff END,
            price = CASE WHEN f.service_code = (_bill_info -> 'srv_code') THEN t.price ELSE 0 END
        FROM t
        WHERE
            f.bill_id = t.bill_id AND f.case_id = t.case_id
        ;
    END IF;
    ------------------------------------------------------------центры здоровья----------------------------------------------------------------------
    IF
        _price_type LIKE 'health_centre%'
    THEN
        _mo_info := public.fin_get_mo_info (p1_bill_id);
        _bill_info := 
            hstore ('vmedpom_code', CASE _price_type WHEN 'health_centre_complex' THEN 'H' WHEN 'health_centre_dynamic' THEN 'I' ELSE NULL END::TEXT) || 
            hstore ('vmedpom_number', CASE _price_type WHEN 'health_centre_complex' THEN '18' WHEN 'health_centre_dynamic' THEN '19' ELSE NULL END::TEXT) || 
            hstore ('srv_codes', CASE _price_type WHEN 'health_centre_complex' THEN '{8101, 8201}' WHEN 'health_centre_dynamic' THEN '{8102, 8202}' ELSE NULL END::TEXT) 
        ;
        WITH t AS 
        (
            SELECT
                f.bill_id, 
                f.id, 
                f.case_id,
                f.case_open_date,
                f.case_close_date,
                t.tariff,
                t.code,
                t.name,
                (SELECT code FROM mc_step_result WHERE id = s.result_id LIMIT 1) AS step_result_code
            FROM
                fin_bill_generate AS f
                JOIN LATERAL (SELECT result_id FROM mc_step WHERE id = f.step_id LIMIT 1) AS s ON TRUE
                LEFT JOIN fin_get_tariff_from_pricelist (f.id, f.price_pos_arr[1]) AS t ON TRUE
            WHERE
                f.bill_id = p1_bill_id AND NOT f.is_sifted
        )
        UPDATE fin_bill_generate AS f
        SET
            quantity = 1, tariff = t.tariff, price = t.tariff, tariff_code = t.code, tariff_name = t.name, 
            region_data = coalesce (f.region_data, ''::HSTORE) ||
                          slice (_bill_info, ARRAY ['vmedpom_code', 'vmedpom_number']) || 
                          hstore ('idotd', NULL::TEXT) || 
                          hstore ('idcase', t.case_id::TEXT) || 
                          hstore ('ishod', t.step_result_code::TEXT) || 
                          hstore ('dbeg', t.case_open_date::TEXT) || 
                          hstore ('dend', t.case_close_date::TEXT) || 
                          hstore ('gs', CASE WHEN (_mo_info.extra_info -> 'org_terr_type') = 'village' THEN 'S' ELSE 'G' END) || 
                          hstore ('kod_mo', _mo_info.code)
        FROM t
        WHERE
            f.bill_id = t.bill_id AND f.id = t.id
        ;
        WITH t AS 
        (
            SELECT 
                bill_id, case_id, sum (tariff) AS sum_of_services
            FROM 
                fin_bill_generate 
            WHERE 
                bill_id = p1_bill_id AND NOT is_sifted 
            GROUP BY 1, 2
        )
        UPDATE fin_bill_generate AS f
        SET
            price = CASE WHEN f.service_code = ANY ((_bill_info -> 'srv_codes')::TEXT[]) THEN t.sum_of_services ELSE 0 END
        FROM t
        WHERE
            f.bill_id = t.bill_id AND f.case_id = t.case_id
        ;
    END IF;
    ---------------------------------------------------------вызов выездной бригады (СНМП)-----------------------------------------------------------
    IF
        _price_type = 'emergency_brigade'
    THEN
        _mo_info := public.fin_get_mo_info (p1_bill_id);
        _bill_info := hstore ('vmedpom_code', 'O') || hstore ('vmedpom_number', '24') || hstore ('3', 'own') || hstore ('6', 'alien')
        ;
        WITH t AS 
        (
            SELECT
                f.bill_id, 
                f.id, 
                f.case_id,
                f.case_open_date,
                f.case_close_date,
                t.tariff,
                t.code,
                t.name,
                (SELECT code FROM mc_step_result WHERE id = s.result_id LIMIT 1) AS step_result_code
            FROM
                fin_bill_generate AS f
                JOIN LATERAL (SELECT result_id FROM mc_step WHERE id = f.step_id LIMIT 1) AS s ON TRUE
                LEFT JOIN LATERAL (SELECT p.code FROM plc_visit_place AS p, plc_visit AS v WHERE p.id = v.place_id AND v.id = f.step_id LIMIT 1) AS v ON TRUE
                LEFT JOIN LATERAL
                (
                    SELECT 
                        m.value::DECIMAL AS tariff, m.code, m.name
                    FROM 
                        fin_price_modifier AS m, fin_modifier_to_pl_pos AS t 
                    WHERE 
                        t.price_modifier_id = m.id AND t.pl_position_id = f.price_pos_arr[1] AND m.price_list_id = f.price_list_id
                        AND m.condition = concat 
                                            (
                                                'SELECT fin_mod_emergency_brigade (?, ''', 
                                                coalesce (CASE WHEN f.belonging_type = 'foreign' THEN 'foreign' ELSE NULL END, (_bill_info -> v.code)), ''', ''', 
                                                (_mo_info.extra_info -> 'org_terr_type'), ''')'
                                            )
                    LIMIT 1
                ) AS t ON TRUE
            WHERE
                f.bill_id = p1_bill_id AND NOT f.is_sifted
        )
        UPDATE fin_bill_generate AS f
        SET
            quantity = 1, tariff = t.tariff, price = t.tariff, tariff_code = t.code, tariff_name = t.name, 
            region_data = coalesce (f.region_data, ''::HSTORE) ||
                          slice (_bill_info, ARRAY ['vmedpom_code', 'vmedpom_number']) || 
                          hstore ('idotd', NULL::TEXT) || 
                          hstore ('idcase', t.case_id::TEXT) || 
                          hstore ('ishod', t.step_result_code::TEXT) || 
                          hstore ('dbeg', t.case_open_date::TEXT) || 
                          hstore ('dend', t.case_close_date::TEXT) || 
                          hstore ('gs', 'G') || 
                          hstore ('kod_mo', _mo_info.code)
        FROM t
        WHERE
            f.bill_id = t.bill_id AND f.id = t.id
        ;
    END IF;
    ------------------------------------------------------------передвижная стоматология-------------------------------------------------------------
    IF
        _price_type = 'mobile_dentist'
    THEN
        _mo_info := public.fin_get_mo_info (p1_bill_id);
        _bill_info := hstore ('vmedpom_code', 'A') || hstore ('vmedpom_number', '10');
        WITH t AS 
        (
            SELECT
                f.bill_id, 
                f.id, 
                f.case_id,
                f.case_open_date,
                f.case_close_date,
                t.tariff,
                t.code,
                t.name,
                (SELECT code FROM mc_step_result WHERE id = s.result_id LIMIT 1) AS step_result_code
            FROM
                fin_bill_generate AS f
                JOIN LATERAL (SELECT result_id FROM mc_step WHERE id = f.step_id LIMIT 1) AS s ON TRUE
                LEFT JOIN LATERAL (SELECT p.code FROM plc_visit_place AS p, plc_visit AS v WHERE p.id = v.place_id AND v.id = f.step_id LIMIT 1) AS v ON TRUE
                LEFT JOIN LATERAL
                (
                    SELECT 
                        m.value::DECIMAL AS tariff, m.code, m.name
                    FROM 
                        fin_price_modifier AS m, fin_modifier_to_pl_pos AS t 
                    WHERE 
                        t.price_modifier_id = m.id AND t.pl_position_id = f.price_pos_arr[1] AND m.price_list_id = f.price_list_id
                        AND m.condition = concat ('SELECT fin_mod_mobile_dentist (?, ''', (_mo_info.level), ''')')
                    LIMIT 1
                ) AS t ON TRUE
            WHERE
                f.bill_id = p1_bill_id AND NOT f.is_sifted
        )
        UPDATE fin_bill_generate AS f
        SET
            tariff = t.tariff, tariff_code = t.code, tariff_name = t.name, price = f.quantity * t.tariff, 
            region_data = coalesce (f.region_data, ''::HSTORE) ||
                          slice (_bill_info, ARRAY ['vmedpom_code', 'vmedpom_number']) || 
                          hstore ('idotd', NULL::TEXT) || 
                          hstore ('idcase', t.case_id::TEXT) || 
                          hstore ('ishod', t.step_result_code::TEXT) || 
                          hstore ('dbeg', t.case_open_date::TEXT) || 
                          hstore ('dend', t.case_close_date::TEXT) || 
                          hstore ('gs', CASE WHEN (_mo_info.extra_info -> 'org_terr_type') = 'village' THEN 'S' ELSE 'G' END) || 
                          hstore ('kod_mo', _mo_info.code)
        FROM t
        WHERE
            f.bill_id = t.bill_id AND f.id = t.id
        ;
    END IF;
    ----------------------------------------------------------стоматология (СТГ)---------------------------------------------------------------------
    IF
        _price_type = 'dentist_stat_groups'
    THEN
        --набор первичной информации
        _mo_info := public.fin_get_mo_info (p1_bill_id);
        _bill_info := hstore ('srv_code', 'GenUsl') || 
                      hstore ('pos_code', concat (CASE WHEN (_mo_info.extra_info -> 'org_terr_type') = 'village' THEN 'V' ELSE NULL END, 'DG')) ||
                      hstore 
                      (
                          'code_of_relative_capacity_costs', 
                          concat 
                          (
                              'KZSTG', 
                              CASE 
                                  WHEN lower (_bill_period) >= '2016-01-01'::DATE THEN CASE WHEN (_mo_info.extra_info -> 'org_terr_type') = 'village' THEN 'S' ELSE 'NS' END 
                                  ELSE NULL 
                              END
                          )
                      )
        ;
        --проставление СТГ
        WITH t AS 
        (
            SELECT 
                f.bill_id, f.case_id, s.csg_id
            FROM
                public.fin_bill_generate AS f
                JOIN LATERAL (SELECT csg_id FROM public.mc_step WHERE id = f.closing_step_id LIMIT 1) AS s ON TRUE
            WHERE
                f.bill_id = p1_bill_id AND NOT f.is_sifted
        )
        UPDATE public.fin_bill_generate AS f 
        SET 
            region_data = coalesce (f.region_data, hstore ('')) || hstore ('dsg_id', t.csg_id::TEXT) 
        FROM t
        WHERE 
            f.bill_id = t.bill_id AND f.case_id = t.case_id
        ;
        WITH t AS 
        (
            SELECT 
                f.bill_id, 
                f.id,
                f.case_id,
                f.price_position_code AS pos_code,
                f.rdd_quantity,
                f.srv_cul,
                f.patient_age,
                trim (c.code) AS dsg_code, 
                trim (c.name) AS dsg_name, 
                (SELECT code FROM public.mc_step_result WHERE id = s.result_id LIMIT 1) AS step_result_code,
                (SELECT code FROM public.mc_step_care_result WHERE id = s.outcome_id LIMIT 1) AS step_care_result_code,
                (SELECT code FROM public.sr_srv_prototype WHERE id = o.p_ids[1] LIMIT 1) AS kod_oper,
                coalesce ((SELECT e_code = '2' FROM public.plc_visit_place WHERE id = v.place_id LIMIT 1), FALSE) AS is_home_visit,
                r.coefficient AS factor_of_relative_capacity_costs,
                a.coefficient AS adult_cul,
                u.coefficient AS child_cul,
                e.tooths_surfaces
            FROM
                public.fin_bill_generate AS f
                JOIN LATERAL (SELECT result_id, outcome_id FROM public.mc_step WHERE id = f.closing_step_id LIMIT 1) AS s ON TRUE
                JOIN LATERAL 
                (
                    SELECT 
                        array_agg (r.service_id) AS srv_ids 
                    FROM 
                        public.md_srv_rendered AS m, public.sr_srv_rendered AS r 
                    WHERE 
                        r.id = m.id AND m.case_id = f.case_id 
                ) AS y ON TRUE
                LEFT JOIN LATERAL (SELECT place_id FROM public.plc_visit WHERE id = f.closing_step_id LIMIT 1) AS v ON TRUE
                JOIN LATERAL 
                (
                    SELECT 
                        code, name
                    FROM 
                        public.md_clinical_statistical_group
                    WHERE 
                        id = (f.region_data -> 'dsg_id')::INTEGER
                    LIMIT 1
                ) AS c ON TRUE
                LEFT JOIN LATERAL 
                (
                    SELECT 
                        replace (replace (c.value, ' ', ''), ',', '.')::DECIMAL AS coefficient 
                    FROM 
                        public.md_csg_cond AS c, public.md_csg_cond_type AS t 
                    WHERE 
                        c.type_id = t.id AND c.csg_id = (f.region_data -> 'dsg_id')::INTEGER 
                        AND t.code = (_bill_info -> 'code_of_relative_capacity_costs') AND daterange (c.from_dt, c.to_dt, '[]') @> f.case_close_date
                    ORDER BY c.from_dt DESC NULLS LAST, c.to_dt DESC, c.id DESC
                    LIMIT 1
                ) AS r ON TRUE
                LEFT JOIN LATERAL 
                (
                    SELECT 
                        replace (replace (c.value, ' ', ''), ',', '.')::DECIMAL AS coefficient 
                    FROM 
                        public.md_csg_cond AS c, public.md_csg_cond_type AS t 
                    WHERE 
                        c.type_id = t.id AND c.csg_id = (f.region_data -> 'dsg_id')::INTEGER 
                        AND t.code = 'YETstg' AND daterange (c.from_dt, c.to_dt, '[]') @> f.case_close_date
                    ORDER BY c.from_dt DESC NULLS LAST, c.to_dt DESC, c.id DESC
                    LIMIT 1
                ) AS a ON TRUE
                LEFT JOIN LATERAL 
                (
                    SELECT 
                        replace (replace (c.value, ' ', ''), ',', '.')::DECIMAL AS coefficient 
                    FROM 
                        public.md_csg_cond AS c, public.md_csg_cond_type AS t 
                    WHERE 
                        c.type_id = t.id AND c.csg_id = (f.region_data -> 'dsg_id')::INTEGER 
                        AND t.code = 'YETstgdet' AND daterange (c.from_dt, c.to_dt, '[]') @> f.case_close_date
                    ORDER BY c.from_dt DESC NULLS LAST, c.to_dt DESC, c.id DESC
                    LIMIT 1
                ) AS u ON TRUE
                LEFT JOIN LATERAL 
                (
                    SELECT 
                        string_agg (concat ('"', tooth_number, '"=>"', tooth_surfaces, '"'), ',') AS tooths_surfaces 
                    FROM 
                        (
                            SELECT 
                                g.tooth_number, array_agg (s.id) AS tooth_surfaces
                            FROM 
                                public.fin_bill_generate              AS g 
                                LEFT JOIN public.md_srv_tooth_surface AS t ON t.srv_rendered_id = g.id
                                LEFT JOIN public.md_tooth_surface     AS s ON s.id = t.tooth_surface_id 
                            WHERE 
                                g.bill_id = f.bill_id AND g.case_id = f.case_id AND nullif (trim (g.tooth_number), '') IS NOT NULL
                            GROUP BY 1
                        ) AS t
                ) AS e ON TRUE
                LEFT JOIN LATERAL 
                (
                    SELECT 
                        array_agg (srv_prototype_id) AS p_ids
                    FROM 
                        public.md_csg_to_srv_prototype
                    WHERE 
                        csg_id = (f.region_data -> 'dsg_id')::INTEGER 
                        AND srv_prototype_id = ANY (ARRAY (SELECT p.id FROM public.sr_srv_prototype AS p, public.sr_service AS s WHERE p.id = s.prototype_id AND s.id = ANY (y.srv_ids)))
                ) AS o ON TRUE
            WHERE
                f.bill_id = p1_bill_id AND NOT f.is_sifted 
        )
        UPDATE public.fin_bill_generate AS f
        SET
            region_data = coalesce (f.region_data, ''::HSTORE) ||
                          hstore ('dsg_code', t.dsg_code::TEXT) || 
                          hstore ('dsg_name', t.dsg_name::TEXT) || 
                          hstore ('idcase', t.case_id::TEXT) || 
                          hstore ('factor_of_level_of_hospital_care', CASE WHEN f.org_id IN (5583224, 5584220) THEN '1.02' ELSE '1' END::TEXT) || 
                          hstore ('factor_of_relative_capacity_costs', CASE WHEN t.pos_code = 'DG' THEN coalesce (t.factor_of_relative_capacity_costs, '1') ELSE '1' END::TEXT) || 
                          hstore ('ishod', t.step_result_code::TEXT) || 
                          hstore ('ishod_z', t.step_care_result_code::TEXT) || 
                          hstore ('kod_oper', t.kod_oper::TEXT) || 
                          hstore ('kol_usl', CASE WHEN t.pos_code = 'DG' THEN 1 ELSE t.rdd_quantity END::TEXT) || 
                          hstore ('kol_ye', CASE WHEN t.pos_code = 'DG' THEN CASE WHEN t.patient_age < 18 THEN t.child_cul ELSE t.adult_cul END ELSE t.srv_cul END::TEXT) || 
                          hstore ('tooths_surfaces', t.tooths_surfaces) || 
                          CASE WHEN t.is_home_visit THEN hstore ('idotd', 'СТГД') ELSE hstore ('') END 
        FROM t
        WHERE
            f.id = t.id AND f.bill_id = t.bill_id 
        ;
        FOR _r IN
            SELECT
                f.bill_id,
                f.id,
                f.closing_step_id AS step_id,
                f.step_cnt::TEXT AS step_cnt,
                f.case_close_date,
                f.price_position_code AS pos_code,
                p.price AS base_tariff,
                (f.region_data -> 'dsg_id')::INTEGER AS dsg_id,
                f.region_data -> 'dsg_code' AS dsg_code,
                f.region_data -> 'ishod' AS ishod,
                (f.region_data -> 'kol_ye')::DECIMAL AS kol_ye,
                (f.region_data -> 'factor_of_level_of_hospital_care')::DECIMAL AS factor_of_level_of_hospital_care,  --коэффициент уровня оказания стационарной медпомощи
                (f.region_data -> 'factor_of_relative_capacity_costs')::DECIMAL AS factor_of_relative_capacity_costs --коэффициент относительной затратоёмкости
            FROM
                public.fin_bill_generate AS f
                LEFT JOIN LATERAL 
                (
                    SELECT price FROM fin_pl_position 
                    WHERE 
                        price_list_id = f.price_list_id AND daterange (from_dt::DATE, to_dt::DATE, '[]') @> f.case_close_date AND code = (_bill_info -> 'pos_code') 
                    ORDER BY to_dt DESC 
                    LIMIT 1
                ) AS p ON TRUE
            WHERE
                f.bill_id = p1_bill_id AND NOT f.is_sifted
        LOOP
            --управленческий коэффициент
            _bill_info := _bill_info || hstore ('factor_of_management', '1');
            --коэффициент сложности курации пациента
            _bill_info := _bill_info || hstore ('factor_of_difficulty_of_cure', '1') || hstore ('codes_of_difficulty_of_cure_arr', NULL::TEXT);
            
            FOR _s IN 
                SELECT 
                    c.value, c.code
                FROM
                    public.mc_step_cur_coef_criteria AS s, public.mc_cur_coef_criteria AS c
                WHERE
                    c.id = s.criteria_id AND s.step_id = _r.step_id
            LOOP
                _bill_info := _bill_info || hstore ('codes_of_difficulty_of_cure_arr', concat (rtrim ((_bill_info -> 'codes_of_difficulty_of_cure_arr'), ',') || ',', _s.code));
                
                _bill_info := _bill_info || hstore ('factor_of_difficulty_of_cure', ((_bill_info -> 'factor_of_difficulty_of_cure')::DECIMAL * _s.value)::TEXT);
            END LOOP;
            
            IF (_bill_info -> 'factor_of_difficulty_of_cure')::DECIMAL > 1.8 THEN _bill_info := _bill_info || hstore ('factor_of_difficulty_of_cure', '1.8'); END IF;
            
            IF _r.pos_code IS DISTINCT FROM 'DG' THEN _bill_info := _bill_info || hstore ('factor_of_difficulty_of_cure', '1'); END IF;
            --уменьшающий коэффициент для незаконченных случаев
            _bill_info := _bill_info || 
                hstore 
                (
                    'factor_of_reduction', 
                    coalesce
                    (
                        (
                            SELECT condition -> _r.step_cnt FROM public.md_csg_reduction_factor 
                            WHERE 
                                csg_id = _r.dsg_id AND _r.case_close_date <@ daterange (from_dt, to_dt, '[]') 
                            ORDER BY to_dt DESC, from_dt DESC NULLS LAST
                            LIMIT 1
                        ),
                        CASE WHEN _r.ishod IN ('3', '4', '5', '9', '10') AND _r.dsg_code NOT IN ('61', '62') THEN '0.75' ELSE NULL END,
                        '1'
                    )
                )
            ;
            _bill_info := _bill_info || 
                hstore 
                (
                    'idotd', 
                    concat 
                    (
                        'СТГ', 
                            CASE 
                                WHEN 
                                    (_r.ishod IN ('3', '4', '5', '9', '10') AND _r.dsg_code NOT IN ('61', '62')) 
                                    OR 
                                    nullif ((_bill_info -> 'factor_of_reduction'), '1') IS NOT NULL 
                                THEN 
                                    'Н' 
                                ELSE 
                                    'З' 
                            END
                    )
                )
            ;
            UPDATE fin_bill_generate AS f 
            SET 
                tariff = _r.base_tariff,
                price = CASE 
                            WHEN 
                                _r.pos_code = 'DG' 
                            THEN 
                                round 
                                (
                                    _r.base_tariff * _r.factor_of_relative_capacity_costs * _r.factor_of_level_of_hospital_care 
                                    *
                                    (_bill_info -> 'factor_of_management')::DECIMAL 
                                    *
                                    (_bill_info -> 'factor_of_difficulty_of_cure')::DECIMAL,
                                    2
                                )
                                *
                                (_bill_info -> 'factor_of_reduction')::DECIMAL 
                            ELSE
                                _r.base_tariff
                            END,
                region_data = coalesce (region_data, ''::HSTORE) || 
                              slice (_bill_info, ARRAY['factor_of_difficulty_of_cure', 'factor_of_management', 'factor_of_reduction']) || 
                              hstore ('kol_ye', round (_r.kol_ye * (_bill_info -> 'factor_of_reduction')::DECIMAL, 2)::TEXT) || 
                              hstore ('osn_kskp', CASE WHEN _r.pos_code = 'DG' THEN (_bill_info -> 'codes_of_difficulty_of_cure_arr') ELSE NULL END) || 
                              hstore ('gs', CASE WHEN (_mo_info.extra_info -> 'org_terr_type') = 'village' THEN 'S' ELSE 'G' END) || 
                              hstore ('kod_mo', _mo_info.code) || 
                              CASE WHEN NOT defined (f.region_data, 'idotd') THEN slice (_bill_info, ARRAY ['idotd']) ELSE hstore ('') END
            WHERE
                f.bill_id = _r.bill_id AND f.id = _r.id
            ;
        END LOOP;
    END IF;
    -----------------------------------------------------------номер записи в выгрузке---------------------------------------------------------------
    WITH t AS 
    (
        SELECT bill_id, id, dense_rank () OVER (ORDER BY case_id) AS n_zap FROM fin_bill_generate WHERE bill_id = p1_bill_id AND NOT is_sifted
    )
    UPDATE fin_bill_generate AS f
    SET
        n_zap = t.n_zap
    FROM t
    WHERE
        t.bill_id = f.bill_id AND t.id = f.id
    ;
EXCEPTION
    WHEN NO_DATA_FOUND THEN RAISE EXCEPTION 'Отсутствуют данные по счёту';
END;
$$;

