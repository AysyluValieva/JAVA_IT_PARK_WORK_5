CREATE FUNCTION fin_price__get_price_by_cost_item(r_id integer, plid integer, ci_id integer)
  RETURNS numeric
LANGUAGE plpgsql
AS $$
declare rec record;
        p numeric;
        q numeric;
        b numeric;
        a numeric;
        f integer;
        c numeric;
        cc numeric;
        ff boolean;
        posId integer;
        tariff numeric;
begin
if r_id is null then return null; end if;
if ci_id is null then return null; end if;

SELECT plp.id, CASE WHEN plp.cost_item_type_id = 2 THEN (pci.price*plp.price)/100 ELSE pci.price END into posId, tariff FROM fin_pl_pos_to_clinic_srv s
                  LEFT JOIN fin_pl_position plp ON plp.id = s.pl_position_id
									LEFT JOIN fin_cost_item_to_pl_pos pci ON pci.pl_position_id = plp.id
									LEFT JOIN sr_srv_rendered sr ON sr.id = r_id
									LEFT JOIN md_srv_rendered mr ON mr.id = sr.id
									LEFT JOIN mc_case c ON mr.case_id = c.id
									LEFT JOIN mc_step st ON st.id = c.closing_step_id
                                    WHERE s.clinic_service_id = sr.service_id AND plp.price_list_id = plid AND pci.cost_item_id = ci_id
                                    AND CASE WHEN (SELECT count(pl_position_id)
                                                        FROM fin_pl_pos_to_clinic_srv s
                                                        LEFT JOIN fin_pl_position plp ON plp.id = s.pl_position_id
                                                        WHERE s.clinic_service_id = sr.service_id
                                                        AND plp.price_list_id = plid) > 1
                                            THEN
                                            st.outcome_date >= COALESCE(plp.from_dt,st.outcome_date) AND st.outcome_date <= COALESCE(plp.to_dt,CURRENT_DATE)
                                            ELSE TRUE END
 and
     exists (select 1 from sr_srv_rendered sr left join fin_pl_pos_to_clinic_srv pptc on pptc.clinic_service_id = sr.service_id where sr.id = r_id and pptc.pl_position_id = plp.id);

for rec in
select CASE WHEN pm.cost_item_type_id = 2 THEN (mci.value::numeric*pm.value::numeric)/100 ELSE mci.value::numeric END as value, pm.condition, pm.type from fin_price_modifier pm
    LEFT JOIN fin_cost_item_to_modifier mci ON mci.modifier_id = pm.id
    where ((scope_id = 1 and price_list_id = plId)
    or (scope_id = 2 and exists (select 1 from fin_modifier_to_pl_pos where pl_position_id = posId and pm.id = price_modifier_id))) and mci.cost_item_id = ci_id
loop

if fin_price_modifier__need_apply(r_id, rec.condition) then

    if rec.type=2 then tariff := tariff + cast(rec.value as numeric); end if;

    if rec.type=3 then tariff := cast(rec.value as numeric); end if;

end if;


end loop;

return round(tariff,2);

end;
$$;

