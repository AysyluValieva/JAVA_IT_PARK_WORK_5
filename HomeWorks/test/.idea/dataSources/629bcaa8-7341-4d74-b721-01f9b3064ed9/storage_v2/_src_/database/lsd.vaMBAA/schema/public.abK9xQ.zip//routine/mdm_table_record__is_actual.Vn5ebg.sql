CREATE FUNCTION mdm_table_record__is_actual(xversion_id integer, xid character varying)
  RETURNS boolean
LANGUAGE plpgsql
AS $$
begin
  return mdm_table_record__is_actual(xversion_id,xid,current_date);
end;
$$;

