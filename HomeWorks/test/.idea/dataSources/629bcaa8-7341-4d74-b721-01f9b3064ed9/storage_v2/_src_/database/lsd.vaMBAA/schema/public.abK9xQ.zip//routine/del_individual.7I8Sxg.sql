CREATE FUNCTION del_individual(_id integer, _flag integer)
  RETURNS text
LANGUAGE plpgsql
AS $$
declare
        _srv_arr integer[];
begin
if (_flag is null) then return 'Необходимо указать тип: 1-физ.лицо, 2-пациент, 3-сотрудник'; end if;
if (_id is null)   then return 'Необходимо указать ID'; end if;
_srv_arr = ARRAY(select fbsi.service_id  from mc_case c
join mc_step s on s.case_id=c.id
join md_srv_rendered msr on msr.step_id=s.id
join fin_bill_spec_item fbsi on fbsi.service_id=msr.id
where c.patient_id=_id) ;
IF ARRAY_LENGTH(_srv_arr, 1) IS NOT NULL THEN return 'У данного физ.лица имеются услуги, которые попали в счет';
else
    if _flag=1 then
    delete from md_ambulance_call where registrator_id=_id;
                delete from pci_patient_reg where patient_id=_id;
                delete from pim_party_addr_to_addr_type where party_address_id in (select id from pim_party_address where party_id=_id);
        delete from pim_party_address where party_id=_id;
        delete from pim_party_role_to_party where party_id=_id;
                update sec.demo set patient_id=null where patient_id=_id;
                update mc_attendant set individual_id=null where individual_id=_id;
                update disp.md_dispr set indiv_id=null where indiv_id=_id;
                update disp.md_dispr_research set indiv_id=null where indiv_id=_id;
                update disp.md_dispr_risk_factor set indiv_id=null where indiv_id=_id;
                update disp.md_event_service_patient set indiv_id=null where indiv_id=_id;
                update migr.md_migr_card set indiv_id=null where indiv_id=_id;
                delete from migr.md_migr_patient where id=_id;
               -- update pci_benefit_request set patient_id=null where patient_id=_id;
                        delete from fin_contract_to_patient where patient_id=_id;
                        update fin_patient_contract set patient_id=null where patient_id=_id;
                        delete from hospital.prescription where patient_id=_id;
                        update inventory.store_opr_jur set patient_id=null where patient_id=_id;
                delete from pci_patient where id=_id;
                delete from pim_citizenship where individual_id=_id;
                        update fin_contractor set employee_id=null where employee_id in (select id from pim_employee where individual_id=_id);
                                update inv_opr set authorization_id=null where authorization_id in (select id from inv_authorization where employee_id in (select id from pim_employee where individual_id=_id));
                        delete from inv_authorization where employee_id in (select id from pim_employee where individual_id=_id);
                                update inv_opr set base_opr_id=null where base_opr_id in (select id from inv_opr where init_employee_id in (select id from pim_employee where individual_id=_id));
                                        update inv_remains_h set prev_id=null where prev_id in (select id from inv_remains_h where opr_id in (select id from inv_opr where init_employee_id in (select id from pim_employee where individual_id=_id)));
                                delete from inv_remains_h where opr_id in (select id from inv_opr where init_employee_id in (select id from pim_employee where individual_id=_id));
                                        delete from mc_inv_spec_consumable where inv_opr_srv_id in (select id from mc_inv_opr_srv where opr_id in (select id from inv_opr where init_employee_id in (select id from pim_employee where individual_id=_id)));
                                delete from mc_inv_opr_srv where opr_id in (select id from inv_opr where init_employee_id in (select id from pim_employee where individual_id=_id));
                                delete from md_sicklist_opr where opr_id in (select id from inv_opr where init_employee_id in (select id from pim_employee where individual_id=_id));
                        delete from inv_opr where init_employee_id in (select id from pim_employee where individual_id=_id);
                        delete from md_employee_resource where employee_id  in (select id from pim_employee where individual_id=_id);
                        delete from md_quotum_refer_employee where employee_id in (select id from pim_employee where individual_id=_id);
                        update pci_patient set empl_state_death_id=null where empl_state_death_id in (select id from pim_employee where individual_id=_id);
                        update pci_patient_job set employee_id=null where employee_id in (select id from pim_employee where individual_id=_id);
                        update pim_employee_position_resource set employee_position_id=null where employee_position_id in (select id from pim_employee_position where employee_id in (select id from pim_employee where individual_id=_id));
                delete from pim_employee where individual_id=_id;
                delete from pim_indiv_agreement where indiv_id=_id;
                                    update qos_examination_case set document_id=null  where document_id in (select id from pim_individual_doc where code_id in (select id from pim_indiv_code where indiv_id=_id));
                        delete from pim_individual_doc where code_id in (select id from pim_indiv_code where indiv_id=_id);
                delete from pim_indiv_code where indiv_id=_id;
                delete from pim_indiv_contact where indiv_id=_id;
                        update qos_examination_case set document_id=null  where document_id in (select id from pim_individual_doc where indiv_id=_id);
                delete from pim_individual_doc where indiv_id=_id;
                delete from pim_indiv_marital_status where individual_id=_id;
                delete from pim_pseudonym where individual_id=_id;
                delete from pim_workplace where indiv_id=_id;
        delete from pim_individual where id=_id;
                update aud_log set app_user_id=null where app_user_id in (select id from sec_user_party where party_id=_id);
                delete from cmn_filter where user_id in (select id from sec_user_party where party_id=_id);
                delete from cmn_msg_log where user_id in (select id from sec_user_party where party_id=_id);
                delete from cmn_msg_to_user where user_id in (select id from sec_user_party where party_id=_id);
                update ehr_phrase set user_id=null where user_id in (select id from sec_user_party where party_id=_id);
                update ehr_template set user_id=null where user_id in (select id from sec_user_party where party_id=_id);
                delete from fin_bill_status_log where user_id in (select id from sec_user_party where party_id=_id);
                delete from fin_bill_validation_user where user_id in (select id from sec_user_party where party_id=_id);
                update fin_payment_share set user_id=null where user_id in (select id from sec_user_party where party_id=_id);
                update md_appointment set registrator_id=null where registrator_id in (select id from sec_user_party where party_id=_id);
                update md_cda_signed set sign_user_id=null where sign_user_id in (select id from sec_user_party where party_id=_id);
                update md_cda_signed set unsign_user_id=null where unsign_user_id in (select id from sec_user_party where party_id=_id);
                update md_referral_history set user_id=null where user_id in (select id from sec_user_party where party_id=_id);
                update md_region_benefit_download set user_id=null where user_id in (select id from sec_user_party where party_id=_id);
                update md_sec_diagnosis_group_to_user set user_id=null where user_id in (select id from sec_user_party where party_id=_id);
                update md_srv_denial set user_id=null where user_id in (select id from sec_user_party where party_id=_id);
                update ntf_template set user_id=null where user_id in (select id from sec_user_party where party_id=_id);
                delete from sec_user_group where user_id in (select id from sec_user_party where party_id=_id);
                delete from sec_user_org where user_id in (select id from sec_user_party where party_id=_id);
                delete from inventory.store_closing_period where user_id in (select id from sec_user_party where party_id=_id);
                update sec_audit_entry set user_id=null where user_id in (select id from sec_user_party where party_id=_id);
        delete from sec_user where id in (select id from sec_user_party where party_id=_id);       
    delete from pim_party where id=_id;
    RETURN 'Физ.лицо удален';
    else
            if _flag=2 then
                        delete from fin_contract_to_patient where patient_id=_id;
                        update fin_patient_contract set patient_id=null where patient_id=_id;
                        delete from hospital.prescription where patient_id=_id;
                        update inventory.store_opr_jur set patient_id=null where patient_id=_id;
            delete from pci_patient where id=_id;
            RETURN 'Пациент удален';
            else
                    if _flag=3 then
                            update fin_contractor set employee_id=null where employee_id=_id;
                                    update inv_opr set authorization_id=null where authorization_id in (select id from inv_authorization where employee_id=_id);
                            delete from inv_authorization where employee_id=_id;
                                    update inv_opr set base_opr_id=null where base_opr_id in (select id from inv_opr where init_employee_id=_id);
                                            update inv_remains_h set prev_id=null where prev_id in (select id from inv_remains_h where opr_id in (select id from inv_opr where init_employee_id=_id));
                                    delete from inv_remains_h where opr_id in (select id from inv_opr where init_employee_id=_id);
                                            delete from mc_inv_spec_consumable where inv_opr_srv_id in (select id from mc_inv_opr_srv where opr_id in (select id from inv_opr where init_employee_id=_id));
                                    delete from mc_inv_opr_srv where opr_id in (select id from inv_opr where init_employee_id=_id);
                                    delete from md_sicklist_opr where opr_id in (select id from inv_opr where init_employee_id=_id);
                            delete from inv_opr where init_employee_id=_id;
                            delete from md_employee_resource where employee_id=_id;
                            delete from md_quotum_refer_employee where employee_id=_id;
                            update pci_patient set empl_state_death_id=null where empl_state_death_id=_id;
                            update pci_patient_job set employee_id=null where employee_id=_id;
                            update pim_employee_position_resource set employee_position_id=null where employee_position_id in (select id from pim_employee_position where employee_id=_id);
                    delete from pim_employee where id=_id;
                    RETURN 'Сотрудник удален';
                    end if;
            end if;
    end if;
end if ;
exception when OTHERS then raise notice '!!!!'; 
return null;
end;
$$;

