CREATE FUNCTION update_responsible(res_group_id integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
begin
            UPDATE sr_res_group
            SET responsible_id =
            (SELECT epr.employee_position_id
            FROM pim_employee_position_resource epr
            WHERE epr.id IN
            (SELECT MAX (rgr.resource_id)
            FROM sr_res_group_relationship rgr
            WHERE rgr.group_id = $1 AND (rgr._is_system=true or (rgr.edatetime is null or rgr.edatetime >= current_date))
            AND EXISTS
            (SELECT rr.id
            FROM sr_res_role rr
            WHERE rr.id = rgr.role_id
            AND rr.kind_id = 1 and (is_disabled is false or is_disabled is null))))
            WHERE id = $1;

            end;
$$;

