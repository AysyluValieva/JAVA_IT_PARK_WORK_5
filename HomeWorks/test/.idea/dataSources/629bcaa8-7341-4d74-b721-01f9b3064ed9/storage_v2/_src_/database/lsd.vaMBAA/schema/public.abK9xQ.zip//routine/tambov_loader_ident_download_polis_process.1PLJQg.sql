CREATE FUNCTION tambov_loader_ident_download_polis_process()
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
	_row tambov_loader_ident_download_polis%rowtype;
	spliter constant text := '--------------------------------------------------------------------------------------------------------------------------------';
	_msg text[];
begin
	
	for _row in select * from tambov_loader_ident_download_polis where indiv_exists order by id
	loop

		_msg := _msg || 'Начинаю процесс обработки записи'::text;
	
		if _row.status <> '0' and _row.source = 'R' then 
			_msg := _msg || 'Обработка записи пропускается'::text || 'Данные переданы в центральный сегмент'::text;
			continue;
		end if;

				_msg := _msg || spliter || 'Полис начало'::text;
		if _row.vpolis is null or _row.npolis is null then
			_msg := _msg || 'Тип, номер полиса и Страх.орган. не указана в XML документе'::text || 'Пропускаю обновление'::text;
		else
			if _row.smo_org_id is null then 
				_msg := _msg || 'Не удалось определить ID страховой организации'::text || 'Обработка записи будет пропущена'::text;
			else
										if _row.vpolis = 3 then 
						_msg := _msg || '-----     Полис типа ENP     -----'::text || update_enp_polis(_row)::text[];
					elsif _row.vpolis = 2 then 
						_msg := _msg || '-----     Полис типа TEMP     -----'::text || update_temp_polis(_row)::text[];
					elsif _row.vpolis = 1 then
						_msg := _msg || '-----     Полис типа OLD     -----'::text || update_old_polis(_row)::text[];
					else
						_msg := _msg || 'Неверный тип полиса'::text || 'Допускаются значение в поле vpolis 1, 2, 3'::text;
					end if;
									end if;
		end if;
		_msg := _msg || 'Обработка записи завершена.'::text || spliter::text;
		update tambov_loader_ident_download_polis set msg = msg || _msg where id = _row.id;
		raise notice '%', _row.id;
		_msg := null;
	end loop;
		end;
$$;

