CREATE FUNCTION adr__is_any_parent(childid text[], parentid integer)
  RETURNS boolean
STABLE
LANGUAGE plpgsql
AS $$
declare result boolean;
                arr integer[];
                begin
                arr := $1::integer[];
                select count(*) > 0 into result
                  from address_element_data e1, address_element_data e2
                  where e1.id = ANY (arr) and e2.id = $2
                  and e1."path" <@ e2."path";
                return result;

                end;
$$;

