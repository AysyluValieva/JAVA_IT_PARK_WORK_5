CREATE FUNCTION update_responsible_on_save_employee_position_resource()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN

    PERFORM update_responsible(relationships.group_id) from (select * from sr_res_group_relationship where resource_id = NEW.id and group_id is not null) as relationships ;
    RETURN NEW;
END;
$$;

