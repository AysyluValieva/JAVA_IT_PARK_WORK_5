CREATE FUNCTION update_medcase_open_date_time()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE
                        caseId integer;
                        admissionDtTm timestamp;
                        result mc_step%ROWTYPE;
                BEGIN
                    IF TG_OP = 'INSERT' OR TG_OP = 'UPDATE' THEN
                        caseId = NEW.case_id;
                    ELSIF TG_OP = 'DELETE' THEN
                        caseId = OLD.case_id;
                    ELSE
                        RETURN NULL;
                    END IF;

                    admissionDtTm = (select min(admission_date + coalesce(admission_time, time '00:00')) from mc_step where mc_step.case_id=caseId);
                    update mc_case set open_date = admissionDtTm, open_time = admissionDtTm where id = caseId;

                    IF TG_OP = 'UPDATE' and OLD.case_id <> NEW.case_id THEN
                        admissionDtTm = (select min(admission_date + coalesce(admission_time, time '00:00')) from mc_step where mc_step.case_id=OLD.case_id);
                        update mc_case set open_date = admissionDtTm, open_time = admissionDtTm where id = OLD.case_id;
                    END IF;
                    RETURN result;
                END;
$$;

