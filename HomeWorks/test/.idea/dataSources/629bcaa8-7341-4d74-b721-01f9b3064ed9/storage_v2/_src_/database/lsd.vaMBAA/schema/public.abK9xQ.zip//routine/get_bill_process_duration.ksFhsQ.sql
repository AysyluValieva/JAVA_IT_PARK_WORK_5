CREATE FUNCTION get_bill_process_duration(OUT cnt bigint, OUT avg_time integer)
  RETURNS record
STABLE
LANGUAGE plpgsql
AS $$
BEGIN
    SELECT
        count (b.id), coalesce (extract (epoch from avg (age (e.date, b.date)))::INTEGER, 0) INTO cnt, avg_time
    FROM
        fin_bill_status_log AS b, 
        LATERAL 
        (
            SELECT 
                date
            FROM 
                fin_bill_status_log 
            WHERE 
                status_id = 1 AND bill_id = b.bill_id AND user_id = b.user_id AND date > b.date
            ORDER BY age (date, b.date)
            LIMIT 1
        ) AS e
    WHERE
        b.status_id = 7 AND b.date <@ tsrange (LOCALTIMESTAMP - '1 hour'::INTERVAL, LOCALTIMESTAMP, '[]')
    ;
END;
$$;

