CREATE FUNCTION upd_fk_indiv(p_tab name, p_old_id integer, p_new_id integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
                c_n constant text := 'upd_fk';
                ifk record;
                q text;
                arr name[] := array['pim_organization'];
            begin
                set constraints all deferred;
                -- perform log_a(c_n||':t='||p_tab, 'INFO');
                -- raise notice 't=%',p_tab;
                for ifk in
                    select c.relname, ca.attname fk_attname, n.nspname,
                        -- check - if PK==FK
                        (select count(1)
                        from pg_constraint cs4, pg_constraint cs5
                        where cs4.conrelid = c.oid
                        and cs4.contype = 'p'
                        and cs4.conkey[1] = cs.conkey[1]
                        and cs5.confkey[1] = cs4.conkey[1]
                        and cs5.contype = 'f'
                        and cs5.confrelid = c.oid) as cnt
                        from pg_class c, pg_constraint cs, pg_class p, pg_attribute ca, pg_catalog.pg_namespace n
                        where ca.attrelid = c.oid
                        and ca.attnum = cs.conkey[1]
                        and cs.contype = 'f'
                        and cs.conrelid = c.oid
                        and cs.confrelid = p.oid
                        and p.relname = lower(p_tab)
                        and n.oid = c.relnamespace
                    loop
                    --   perform log_a(c_n||':'||ifk.relname||'.'||ifk.fk_attname||' -> '||p_tab, 'INFO');
                    --   raise notice '   %.%.% -> %',ifk.relname, ifk.fk_attname,ifk.cnt, p_tab;
                    begin
                        q := 'update '||ifk.nspname||'.'||ifk.relname||' set '||ifk.fk_attname||'='||p_new_id||' where '||ifk.fk_attname||'='||p_old_id; execute q;
                        exception when sqlstate '23505' then -- ignore duplicates for now
                        -- perform log_a(c_n||':'||'dup key:'||ifk.relname||':'||p_new_id, 'WARN');
                    end;
                    if ifk.cnt > 0 and ifk.relname <> all(arr) then
                        perform upd_fk(ifk.relname, p_old_id, p_new_id);
                    end if;
                end loop;
            end;
$$;

