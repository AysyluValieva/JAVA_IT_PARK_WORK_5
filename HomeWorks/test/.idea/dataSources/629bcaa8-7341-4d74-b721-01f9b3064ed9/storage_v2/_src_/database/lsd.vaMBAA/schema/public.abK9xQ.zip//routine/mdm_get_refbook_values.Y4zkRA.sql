CREATE FUNCTION mdm_get_refbook_values(oid text, version text, source_code text)
  RETURNS TABLE(id integer, code text, name text)
LANGUAGE plpgsql
AS $$
declare  version_id int;
  begin
     select mdm_refbook_version.id from mdm_refbook into version_id
     inner join mdm_refbook_source on mdm_refbook.source_id = mdm_refbook_source.id
     inner join mdm_refbook_version on mdm_refbook.id = mdm_refbook_version.refbook_id
     where mdm_refbook_source.code = $3 and mdm_refbook_source.object_id ||'.'||mdm_refbook.object_id  = $1 and mdm_refbook_version.version = $2;
     if(version_id is null) then
        return ;
     end if;


     return query select codes.record_id  as id,  codes.value as code , names.value as name from (select mdm_record.id as record_id,  mdm_record_column.value as value from mdm_record
     inner join mdm_record_column on mdm_record.id = mdm_record_column.record_id
     inner join mdm_refbook_column on mdm_record_column.column_id = mdm_refbook_column.id
     where mdm_record.refbook_version_id = version_id and  mdm_refbook_column.is_unique_key = true ) codes
     inner join (select mdm_record.id as record_id,  mdm_record_column.value as value from mdm_record
     inner join mdm_record_column on mdm_record.id = mdm_record_column.record_id
     inner join mdm_refbook_column on mdm_record_column.column_id = mdm_refbook_column.id
     where mdm_record.refbook_version_id = version_id and  mdm_refbook_column.is_display_name = true ) names
     on codes.record_id=names.record_id ;
  end;
$$;

