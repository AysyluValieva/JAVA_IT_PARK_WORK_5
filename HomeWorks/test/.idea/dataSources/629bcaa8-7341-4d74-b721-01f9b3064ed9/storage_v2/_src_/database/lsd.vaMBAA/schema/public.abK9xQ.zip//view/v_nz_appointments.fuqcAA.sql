CREATE VIEW v_nz_appointments AS
  SELECT mv_nz_appointments.org_id,
    mv_nz_appointments.gender_id,
    mv_nz_appointments.state_id,
    mv_nz_appointments.source_id,
    mv_nz_appointments.department_id,
    mv_nz_appointments.speciality_id,
    mv_nz_appointments.executor_id,
    mv_nz_appointments.democube_days_id,
    mv_nz_appointments.age_category_2_id,
    mv_nz_appointments.age_category_3_id,
    mv_nz_appointments.ma_cnt
   FROM mv_nz_appointments;

