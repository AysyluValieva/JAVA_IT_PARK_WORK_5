CREATE FUNCTION inv_store_sync()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
begin
            case TG_RELNAME
            when 'inv_store' then
            if new.department_id is not null then
            select org_id into new.org_id from pim_department where id = new.department_id;
            end if;
            when 'inv_store_post' then
            update inv_store set
            org_id = (select d.org_id
            from pim_department d, md_post p where p.department_id = d.id and p.id = new.post_id),
            department_id = (select department_id from md_post p where p.id = new.post_id)
            where id = new.id;
            end case;
            return new;
            end;
$$;

