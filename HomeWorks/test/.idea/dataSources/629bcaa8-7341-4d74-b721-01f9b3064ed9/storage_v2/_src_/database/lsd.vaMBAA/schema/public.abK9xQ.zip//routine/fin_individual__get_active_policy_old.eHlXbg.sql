CREATE FUNCTION fin_individual__get_active_policy_old(p1_individual_id integer, p2_date date)
  RETURNS integer
STRICT
LANGUAGE plpgsql
AS $$
DECLARE
    _types_other INTEGER[];
    _ids INTEGER[];
    _ap INTEGER;
    _type_enp INTEGER;
BEGIN
    _type_enp := (SELECT id FROM pim_code_type WHERE code = 'ENP');
    
    _types_other := ARRAY (SELECT id FROM pim_doc_type WHERE code IN ('MHI_UNIFORM', 'MHI_OLDER', 'MHI_TEMP'));
    
    _ids := ARRAY 
    (
        SELECT id FROM pim_indiv_doc 
        WHERE 
            indiv_id = p1_individual_id 
            AND 
            p2_date BETWEEN coalesce (issue_dt, DATE '1900-01-01') AND coalesce (expire_dt, DATE '4000-01-01')
    );
    
    WITH 
    d AS 
    (
        SELECT id, doc_id, code_id, issue_dt, expire_dt FROM pim_indiv_doc WHERE id = ANY (_ids)
    ),
    t AS 
    (
        (
            SELECT 
                d.id,
                coalesce (d.issue_dt, DATE '1900-01-01') AS issue_dt,
                coalesce (d.expire_dt, DATE '4000-01-01') AS expire_dt,
                1 AS type_id
            FROM 
                d JOIN pim_indiv_code AS c ON c.id = d.code_id AND c.type_id = _type_enp
            ORDER BY 
                issue_dt DESC, expire_dt DESC, id DESC
            LIMIT 1
        )
        UNION
        (
            SELECT 
                d.id,
                coalesce (d.issue_dt, DATE '1899-01-01') AS issue_dt,
                coalesce (d.expire_dt, DATE '4000-01-01') AS expire_dt,
                2 AS type_id
            FROM 
                d JOIN pim_doc AS c ON c.id = d.doc_id AND c.type_id = ANY (_types_other)
        )
    )
    SELECT id INTO STRICT _ap FROM t ORDER BY type_id, issue_dt DESC, expire_dt DESC, id DESC LIMIT 1;
    
    IF (_ap IS NOT NULL) THEN RETURN _ap; ELSE RETURN NULL; END IF;
    
EXCEPTION
    WHEN NO_DATA_FOUND THEN RETURN NULL;
END;
$$;

