CREATE FUNCTION get_first_job_org_name(individual_id integer)
  RETURNS text
LANGUAGE plpgsql
AS $$
declare
            begin
            return(select o.short_name from pim_organization o
            join pci_patient_job pj on (o.id = pj.organization_id and pj.patient_id = individual_id) limit 1);
            end;
$$;

