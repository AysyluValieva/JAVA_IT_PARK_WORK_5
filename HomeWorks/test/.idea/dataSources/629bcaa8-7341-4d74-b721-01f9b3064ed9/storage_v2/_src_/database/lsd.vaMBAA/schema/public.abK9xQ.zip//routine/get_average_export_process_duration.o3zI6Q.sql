CREATE FUNCTION get_average_export_process_duration(OUT time10k integer, OUT region text)
  RETURNS record
STABLE
LANGUAGE plpgsql
AS $$
BEGIN
    time10k := 
    round 
    (
        10000 / nullif 
        (
            (
                SELECT
                    avg (service_count / extract (epoch from age (to_ts, from_ts))::DECIMAL)
                FROM 
                    fin_bill_export_log
                WHERE
                    from_ts <@ tsrange (LOCALTIMESTAMP - '14 days'::INTERVAL, LOCALTIMESTAMP, '[]')
            ), 0
        )
    );
    region := (SELECT value FROM cmn_setting_value WHERE setting_id = 'cz.atria.common.settings.impl.ProductOwnerInfoSettings.regionCode')
    ;
END;
$$;

