CREATE FUNCTION find_document(integer, integer, text, text)
  RETURNS pim_individual_doc
LANGUAGE SQL
AS $$
select * from pim_individual_doc where 
		(type_id, (COALESCE(issuer_id, 0)), upper(((COALESCE(series, ''::character varying))::text || (number)::text)))=
				($1, (coalesce($2, 0)), upper(((coalesce($3, ''::character varying))::text || ($4)::text)));
$$;

