CREATE FUNCTION step_plc_visit_update_goal_tf()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
              IF ((not exists (select value from cmn_setting_value  where setting_id = 'cz.atria.medcase.ui.MedicalCaseUISettings.useVisitGoal')) or
                 (select value from cmn_setting_value  where setting_id = 'cz.atria.medcase.ui.MedicalCaseUISettings.useVisitGoal') != 'true') THEN
                     UPDATE mc_step SET plc_goal_id = NEW.init_goal_id where case_id=NEW.id and _case_mode_id=1;
              END IF;
             RETURN NEW;
            END;
$$;

