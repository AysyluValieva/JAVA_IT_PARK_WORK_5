CREATE FUNCTION get_hsp_record_caption(integer)
  RETURNS character varying
LANGUAGE plpgsql
AS $$
declare
                caption RECORD;

            begin

              select to_char(mc_step.admission_date, 'dd.mm.yyyy') as bdate,  pim_department.name as department,
                   coalesce((select md_diagnosis.code from mc_diagnosis  inner join md_diagnosis on md_diagnosis.id = mc_diagnosis.diagnos_id
                where mc_diagnosis.is_main is not null and mc_diagnosis.is_main = true and mc_diagnosis.step_id = mc_step.id), 'Основной диагноз не указан') as diagnosis
              from mc_step into caption
              inner join pim_department on pim_department.id = mc_step.hsp_department_id
              where mc_step.id =$1;
              if (caption is not null) then
                  return  caption.bdate || ' '||caption.department || ' ' ||caption.diagnosis;
              end if;
              return '';

            end;
$$;

