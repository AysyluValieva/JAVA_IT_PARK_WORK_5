CREATE VIEW cas_user_tgt_counter AS
  SELECT t.username,
    t.tgt_count AS count
   FROM dblink('dbname=cas host=192.168.2.118 port=5432 user=cas password=AppMaster2'::text, 'SELECT username, tgt_count FROM user_tgt_counter'::text) t(username character varying(255), tgt_count integer);

COMMENT ON VIEW cas_user_tgt_counter IS 'Счетчик авторизованных в cas пользователей';

COMMENT ON COLUMN cas_user_tgt_counter.username IS 'Логин пользователя';

COMMENT ON COLUMN cas_user_tgt_counter.count IS 'Число пользователей, авторизованных в cas под логином в настоощее время';

