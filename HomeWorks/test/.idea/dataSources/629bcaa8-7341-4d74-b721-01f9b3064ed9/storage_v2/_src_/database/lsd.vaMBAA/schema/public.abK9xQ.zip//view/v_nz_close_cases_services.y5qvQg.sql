CREATE VIEW v_nz_close_cases_services AS
  SELECT mv_nz_close_cases_services.clinic_id,
    mv_nz_close_cases_services.gender_id,
    mv_nz_close_cases_services.soc_group_id,
    mv_nz_close_cases_services.care_regimen_id,
    mv_nz_close_cases_services.result_id,
    mv_nz_close_cases_services.care_result_id,
    mv_nz_close_cases_services.department_id,
    mv_nz_close_cases_services.diagnos_id,
    mv_nz_close_cases_services.profile_id,
    mv_nz_close_cases_services.type_id,
    mv_nz_close_cases_services.prototype_id,
    mv_nz_close_cases_services.democube_days_id,
    mv_nz_close_cases_services.age_category_2_id,
    mv_nz_close_cases_services.age_category_3_id,
    mv_nz_close_cases_services.sr_cnt
   FROM mv_nz_close_cases_services;

