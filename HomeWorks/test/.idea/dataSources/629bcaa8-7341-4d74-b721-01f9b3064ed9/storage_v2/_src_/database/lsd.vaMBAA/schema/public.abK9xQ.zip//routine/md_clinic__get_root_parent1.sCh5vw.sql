CREATE FUNCTION md_clinic__get_root_parent1(xid integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
  _id integer;
begin
  select id into _id from (with recursive temp1(id, parent_id, path, cycle, rownum) as (
    select o1.id,o1.parent_id,array[o1.id],false,1 from pim_organization o1, md_clinic c1 where o1.id = xid and o1.id = c1.id
  union all
    select o2.id, o2.parent_id,path||o2.id,o2.id=any(path),rownum+1
    from pim_organization o2
    inner join md_clinic c2 on o2.id = c2.id
    inner join temp1 on (temp1.parent_id = o2.id) and not cycle
  )
  select id, parent_id, rownum
    from  temp1 order by rownum desc limit 1) t1;
  return _id;
end;
$$;

