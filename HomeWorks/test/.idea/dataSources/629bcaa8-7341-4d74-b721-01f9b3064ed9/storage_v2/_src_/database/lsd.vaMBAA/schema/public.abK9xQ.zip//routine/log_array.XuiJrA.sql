CREATE FUNCTION log_array(message text[], _id integer)
  RETURNS void
LANGUAGE SQL
AS $$
update tambov_loader_ident_download set
		msg = msg || $1 
	where id = $2;
$$;

