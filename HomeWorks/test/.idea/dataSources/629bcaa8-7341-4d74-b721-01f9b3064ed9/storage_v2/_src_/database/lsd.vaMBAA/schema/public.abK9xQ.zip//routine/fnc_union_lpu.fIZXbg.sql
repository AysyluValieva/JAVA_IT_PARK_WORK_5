CREATE FUNCTION fnc_union_lpu()
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE _r TEXT [];
_c TEXT [];
_arr INTEGER [];
_arr_dist INTEGER [];
_min INTEGER;
_max INTEGER;
_clause INTEGER;
_rate INTEGER;
_period TEXT;
rc record;
BEGIN
    /*------------------------------------------
            Механизм объединения МО. 
    ------------------------------------------*/
    ------- Проверка на наличие данных для объединения ( tmp_union_org )
    IF NOT EXISTS (
            SELECT true
            FROM tmp_union_org
            ) THEN RAISE EXCEPTION 'Нет данных для объединения!!! Заполните таблицу: tmp_union_org';END
        IF ;
            --------DROP TEMP TABLE----------
            DROP TABLE
    IF EXISTS tmp_new_services;
        DROP TABLE
    IF EXISTS tmp_old_sevice;
     
            --статистика
        INSERT into  tmp_union_stat (
            WITH param AS (
                SELECT unnest((array_agg(old_org_id) || array_agg(new_org_id))::INTEGER []) AS org_id
                FROM tmp_union_org
                ) SELECT 'ДО'::TEXT AS "Шаг"
            ,p.org_id AS "ЛПУ"
            ,dep.cnt AS "Kол-во подразделений"
            ,pos.cnt AS "Kол-во штаток"
            ,emp.cnt AS "Kол-во сотрудников"
            ,res.cnt AS "Kол-во сост.ресурсов"
            ,ser.cnt AS "Kол-во услуг"
            ,cs.cnt AS "Kол-во случаев"
            ,srv.cnt AS "Kол-во оказанных услуг"
            ,reg.cnt AS "Kол-во пациентов" FROM param p LEFT JOIN (
            SELECT count(1) AS cnt
                ,d.org_id AS org_id
            FROM pim_department d
            WHERE d.org_id IN (
                    SELECT org_id
                    FROM param
                    )
            GROUP BY 2
            ) dep ON dep.org_id = p.org_id LEFT JOIN (
            SELECT count(1) AS cnt
                ,d.organization_id AS org_id
            FROM pim_position d
            WHERE d.organization_id IN (
                    SELECT org_id
                    FROM param
                    )
            GROUP BY 2
            ) pos ON pos.org_id = p.org_id LEFT JOIN (
            SELECT count(1) AS cnt
                ,d.organization_id AS org_id
            FROM pim_employee d
            WHERE d.organization_id IN (
                    SELECT org_id
                    FROM param
                    )
            GROUP BY 2
            ) emp ON emp.org_id = p.org_id LEFT JOIN (
            SELECT count(1) AS cnt
                ,d.org_id AS org_id
            FROM sr_res_group d
            WHERE d.org_id IN (
                    SELECT org_id
                    FROM param
                    )
            GROUP BY 2
            ) res ON res.org_id = p.org_id LEFT JOIN (
            SELECT count(1) AS cnt
                ,d.org_id AS org_id
            FROM sr_service d
            WHERE d.org_id IN (
                    SELECT org_id
                    FROM param
                    )
            GROUP BY 2
            ) ser ON ser.org_id = p.org_id LEFT JOIN (
            SELECT count(1) AS cnt
                ,d.clinic_id AS org_id
            FROM mc_case d
            WHERE d.clinic_id IN (
                    SELECT org_id
                    FROM param
                    )
            GROUP BY 2
            ) cs ON cs.org_id = p.org_id LEFT JOIN (
            SELECT count(1) AS cnt
                ,d.org_id AS org_id
            FROM sr_srv_rendered d
            WHERE d.org_id IN (
                    SELECT org_id
                    FROM param
                    )
            GROUP BY 2
            ) srv ON srv.org_id = p.org_id LEFT JOIN (
            SELECT count(1) AS cnt
                ,d.clinic_id AS org_id
            FROM pci_patient_reg d
            WHERE d.clinic_id IN (
                    SELECT org_id
                    FROM param
                    )
            GROUP BY 2
            ) reg ON reg.org_id = p.org_id ORDER BY 2 ASC
            );
 
    /*-----------START DEPARTMENT----------  если необходимо самим создать подразделение
    SELECT setval('dc_departament_seq', (
                SELECT max(id)
                FROM pim_department
                ))
    INTO _min + 1;
    CREATE TEMP TABLE temp_dep_id AS (
        WITH ins_dep AS (
            INSERT INTO pim_department (
                id
                ,code
                ,NAME
                ,type_id
                ,org_id
                ) (
                SELECT nextval('dc_departament_seq') AS id
                ,o.id AS old_org_id
                ,replace(substring(o.short_name, position('"' IN o.short_name)), '"', '') || ' (Ф)' AS NAME
                ,10 AS type_id
                ,t.new_org_id FROM pim_organization o JOIN (
                SELECT old_org_id
                    ,new_org_id
                FROM tmp_union_org
                ) t ON o.id = t.old_org_id
                ) RETURNING code::INTEGER AS old_org_id
                ,id::INTEGER AS new_dep_id
            ) SELECT * FROM ins_dep
        );
    SELECT currval('dc_departament_seq')
    INTO _max;
    INSERT INTO tmp_union_lpu_log (
        num
        ,step
        ,query
        )
    VALUES (
        1
        ,'DEPARTMENT'
        ,'DELETE FROM pim_department WHERE id between ' || _min || ' AND ' || _max || ';'
        );
    _min = NULL;
    _max = NULL;
    UPDATE tmp_union_org u
    SET new_dep_id = t.new_dep_id
    FROM temp_dep_id t
    WHERE t.old_org_id = u.old_org_id;
    UPDATE pim_department d
    SET parent_id = NULL
    WHERE d.parent_id = d.id;*/
---переносим подразделение старых мо
    INSERT INTO tmp_union_lpu_log (
        num
        ,step
        ,query
        ) (
        WITH param AS (
            SELECT d.id
                ,d.org_id
                ,d.parent_id
            FROM pim_department d
            WHERE d.org_id IN (
                    SELECT old_org_id
                    FROM tmp_union_org
                    )
            ) SELECT 2
        ,'DEPARTMENT'
        ,CONCAT (
            'UPDATE pim_department u SET parent_id = '
            ,f.parent_id
            ,', org_id = '
            ,f.org_id
            ,' WHERE u.id = '
            ,f.id
            ,';'
            ) FROM param f
        );
    UPDATE pim_department d
    SET parent_id = f.new_dep_id
        ,org_id = f.new_org_id
    FROM tmp_union_org f
    WHERE d.org_id = f.old_org_id
        AND d.parent_id IS NULL;
    INSERT INTO tmp_union_lpu_log (
        num
        ,step
        ,query
        ) (
        WITH param AS (
            SELECT o.unit_id AS old_unit
                ,o2.unit_id AS new_unit
            FROM tmp_union_org t
            JOIN pim_organization o ON o.id = t.old_org_id
            JOIN pim_organization o2 ON o2.id = t.new_org_id
            ) SELECT 2
        ,'CONTEXT'
        ,CONCAT (
            'UPDATE sec_user_context_default u SET org_unit_id = '
            ,f.new_unit
            ,' WHERE u.org_unit_id = '
            ,f.old_unit
            ,' and id ?;'
            ) FROM param f
        );
    UPDATE sec_user_context_default u
    SET org_unit_id = f.new_unit
    FROM (
        SELECT o.unit_id AS old_unit
            ,o2.unit_id AS new_unit
        FROM tmp_union_org t
        JOIN pim_organization o ON o.id = t.old_org_id
        JOIN pim_organization o2 ON o2.id = t.new_org_id
        ) f
    WHERE u.org_unit_id = f.old_unit;
INSERT INTO tmp_union_lpu_log (
        num
        ,step
        ,query
        ) (
        WITH param AS (
            SELECT old_org_id,new_org_id            
            FROM tmp_union_org t     
                        ) SELECT 2
        ,'SEC_USER'
        ,CONCAT (
            'UPDATE sec_user_org u SET org_id = '
            ,f.new_org_id
            ,' WHERE u.org_id = '
            ,f.old_org_id
            ,';'
            ) FROM param f
        );
    UPDATE sec_user_org u
    SET org_id = t.new_org_id
    FROM
         tmp_union_org t
    WHERE u.org_id = t.old_org_id;
-----PCI_PATIENT_REG
INSERT INTO tmp_union_lpu_log (
        num
        ,step
        ,query
        ) (
        WITH param AS (
            SELECT old_org_id,new_org_id            
            FROM tmp_union_org t
                        ) SELECT 2
        ,'PATIENT'
        ,CONCAT (
            'UPDATE pci_patient_reg p SET clinic_id = '
            ,f.new_org_id
            ,' WHERE p.clinic_id = '
            ,f.old_org_id
            ,';'
            ) FROM param f
        );
    UPDATE pci_patient_reg p
    SET clinic_id = t.new_org_id
    FROM
         tmp_union_org t
    WHERE p.clinic_id = t.old_org_id
 and not exists(select 1 from pci_patient_reg where clinic_id=t.new_org_id and patient_id=p.patient_id and type_id=p.type_id);
INSERT INTO tmp_union_lpu_log (
        num
        ,step
        ,query
        ) (
        WITH param AS (
            SELECT old_org_id,new_org_id            
            FROM tmp_union_org t
                        ) SELECT 2
        ,'TICKET'
        ,CONCAT (
            'UPDATE md_ticket_number_org SET org_id = '
            ,f.new_org_id
            ,' WHERE org_id = '
            ,f.old_org_id
            ,';'
            ) FROM param f
        );
  UPDATE md_ticket_number_org n
    SET org_id = t.new_org_id
    FROM
         tmp_union_org t
    WHERE n.org_id = t.old_org_id; 
 
    -------- SR_RES_GROUP
    INSERT INTO tmp_union_lpu_log (
        num
        ,step
        ,query
        ) (
        WITH param AS (
            SELECT g.id
                ,g.org_id
                ,g.department_id
            FROM sr_res_group g
            JOIN tmp_union_org t ON g.org_id = t.old_org_id
            JOIN sr_res_group_source s ON g.id = s.res_group_id
                AND s.source_id = 0
            ) SELECT 3
        ,'SR_RES_GROUP'
        ,CONCAT (
            'UPDATE sr_res_group u SET department_id = '
            ,f.department_id
            ,', org_id = '
            ,f.org_id
            ,' WHERE u.id = '
            ,f.id
            ,';'
            ) FROM param f
        );
    UPDATE sr_res_group u
    SET department_id = f.new_dep_id
    FROM (
        SELECT sg.id
            ,t.new_dep_id
        FROM sr_res_group sg
        JOIN tmp_union_org t ON sg.org_id = t.old_org_id
        WHERE sg.department_id IS NULL
        ) f
    WHERE f.id = u.id;
    UPDATE sr_res_group AS g
    SET org_id = t.new_org_id
    FROM tmp_union_org AS t
        ,sr_res_group_source AS s
    WHERE g.org_id = t.old_org_id
        AND g.id = s.res_group_id
        AND s.source_id = 0 --portal
        ;
    -----------START SERVICES---------- 
    PERFORM(SELECT setval('sr_service_id_seq', (
                    SELECT max(id)
                    FROM sr_service
                    )));
             
/* END */
CREATE TABLE tmp_new_services AS (
    SELECT * FROM sr_service WHERE org_id IN (
        SELECT t.new_org_id
        FROM tmp_union_org t
        )
    );
INSERT INTO tmp_new_services (
    id
    ,code
    ,cul
    ,is_death
    ,duration
    ,is_fictitious
    ,is_independent
    ,is_multuplicity
    ,NAME
    ,category_id
    ,duration_unit_id
    ,prototype_id
    ,type_id
    ,from_dt
    ,to_dt
    ,is_repeated
    ,is_inherit_protocol
    ,is_expendable_materials
    ,is_actual_cul
    ,is_paraclinical
    ,is_complex
    ,accounting_id
    ,org_id
    ,terms
    ) (
    SELECT s.id
    ,s.code
    ,s.cul
    ,s.is_death
    ,s.duration
    ,s.is_fictitious
    ,s.is_independent
    ,s.is_multuplicity
    ,s.NAME
    ,s.category_id
    ,s.duration_unit_id
    ,s.prototype_id
    ,s.type_id
    ,s.from_dt
    ,s.to_dt
    ,s.is_repeated
    ,s.is_inherit_protocol
    ,s.is_expendable_materials
    ,s.is_actual_cul
    ,s.is_paraclinical
    ,s.is_complex
    ,s.accounting_id
    ,s.org_id
    ,t.old_org_id || ' to ' || t.new_org_id 
FROM sr_service s JOIN tmp_union_org t ON t.old_org_id = s.org_id LEFT JOIN tmp_new_services n ON trim(lower(s.NAME)) = trim(lower(n.NAME))
    AND s.code = n.code
    AND n.type_id = s.type_id
    AND n.org_id = t.new_org_id WHERE n.id IS NULL
    );----old_org service
INSERT INTO tmp_union_lpu_log (
    num
    ,step
    ,query
    ) (
    WITH param AS (
        SELECT g.id
            ,g.org_id
        FROM sr_service g
        JOIN tmp_union_org t ON g.org_id = t.old_org_id
        ) SELECT 4
    ,'SR_SERVICE'
    ,CONCAT (
        'UPDATE sr_service u SET org_id = '
        ,f.org_id
        ,' WHERE u.id = '
        ,f.id
        ,';'
        ) FROM param f
    );
UPDATE sr_service s
SET org_id = f.new_org_id
FROM (
    SELECT t.new_org_id
        ,f.id
    FROM tmp_new_services f
    JOIN tmp_union_org t ON f.terms LIKE '%to%'
        AND t.old_org_id = f.org_id
    ) f
WHERE s.id = f.id;
CREATE TABLE tmp_old_sevice AS (
    SELECT s.id AS id0
    ,n.id AS id1,t.is_delete FROM (
    SELECT id
        ,type_id
        ,prototype_id
        ,NAME
        ,code
        ,org_id
    FROM sr_service
    WHERE org_id IN (
            SELECT t.old_org_id
            FROM tmp_union_org t
            )
    ) s JOIN tmp_union_org t ON t.old_org_id = s.org_id JOIN tmp_new_services n ON trim(lower(s.NAME)) = trim(lower(n.NAME))
    AND s.code = n.code
    AND n.type_id = s.type_id
    AND n.org_id = t.new_org_id
    );
/*
update fin_pl_pos_to_clinic_srv c
set clinic_service_id=o.id1
from tmp_old_sevice o
where clinic_service_id=o.id0
and not exists (select 1 from fin_pl_pos_to_clinic_srv where pl_position_id=c.pl_position_id and clinic_service_id=rc.new_service_id);

update fin_bill_generate
set service_id=o.id1
from tmp_old_sevice o
where service_id=o.id0;

update fin_bill_steps set service_id=o.id1
from tmp_old_sevice o
where service_id=o.id0;


-----------END SERVICES---------- 
INSERT INTO tmp_union_lpu_log (
    num
    ,step
    ,query
    ) (
    WITH param AS (
        SELECT g.id
            ,g.clinic_id
        FROM fin_price_list g
        JOIN tmp_union_org t ON g.clinic_id = t.old_org_id
        ) SELECT 5
    ,'FIN_PRICE_LIST'
    ,CONCAT (
        'UPDATE fin_price_list u SET clinic_id = '
        ,f.clinic_id
        ,' WHERE u.id = '
        ,f.id
        ,';'
        ) FROM param f
    );
UPDATE fin_price_list u
SET clinic_id = f.new_org_id
    ,commentary = f.old_org_id || 'to' || f.new_org_id
FROM tmp_union_org f
WHERE u.clinic_id = f.old_org_id;
_min = NULL;
_max = NULL;*/

delete from fin_price_list where clinic_id in (select old_org_id from tmp_union_org);
-----------START PORTAL-----------
INSERT INTO tmp_union_lpu_log (
    num
    ,step
    ,query
    ) (
    WITH param AS (
        SELECT g.id
            ,g.clinic_id
        FROM pc_clinic_to_group g
        JOIN tmp_union_org t ON g.clinic_id = t.old_org_id
        ) SELECT 8
    ,'PORTAL'
    ,CONCAT (
        'UPDATE pc_clinic_to_group u SET clinic_id = '
        ,f.clinic_id
        ,' WHERE u.id = '
        ,f.id
        ,' AND NOT EXISTS ( select true from pc_clinic_to_group where clinic_id = '
        ,f.clinic_id
        ,' and group_id = u.group_id )'
        ,';'
        ) FROM param f
    );
UPDATE pc_clinic_to_group g
SET clinic_id = t.new_org_id
FROM tmp_union_org t
WHERE g.clinic_id = t.old_org_id
    AND NOT EXISTS (
        SELECT true
        FROM pc_clinic_to_group
        WHERE clinic_id = t.new_org_id
            AND group_id = g.group_id
        );
/*INSERT INTO pc_department (
    NAME
    ,id
    ,is_visible
    ,ordern
    ) (
    SELECT d.NAME
    ,d.id
    ,TRUE
    ,1 FROM pim_department d JOIN tmp_union_org t ON d.id = t.new_dep_id
    );*/
INSERT INTO tmp_union_lpu_log (
    num
    ,step
    ,query
    ) (
    WITH param AS (
        SELECT new_dep_id
        FROM tmp_union_org
        ) SELECT 9
    ,'PORTAL'
    ,'DELETE FROM pc_department WHERE id = ' || new_dep_id || ';' FROM param
    );
/*
INSERT INTO pc_department_to_group (id, group_id, department_id)
( select nextval('pc_department_to_group_seq'),
         c.group_id,
         u.new_dep_id
    from tmp_union_org u join pc_clinic_to_group c ON c.clinic_id = u.new_org_id
);*/
INSERT INTO tmp_union_lpu_log (
    num
    ,step
    ,query
    ) (
    WITH param AS (
        SELECT p.*
        FROM pc_clinic_to_group p
        WHERE p.clinic_id IN (
                SELECT old_org_id
                FROM tmp_union_org
                )
        ) SELECT 10
    ,'PORTAL'
    ,'INSERT INTO pc_clinic_to_group ' || p.* || ';' FROM param p
    );
INSERT INTO tmp_union_lpu_log (
    num
    ,step
    ,query
    ) (
    WITH param AS (
        SELECT p.*
        FROM pc_clinic p
        WHERE p.id IN (
                SELECT old_org_id
                FROM tmp_union_org
                )
        ) SELECT 11
    ,'PORTAL'
    ,'INSERT INTO pc_clinic ' || p.* || ';' FROM param p
    );
DELETE
FROM pc_clinic_to_group p
WHERE p.clinic_id IN (
        SELECT old_org_id
        FROM tmp_union_org
        );
DELETE
FROM pc_clinic p
WHERE p.id IN (
        SELECT old_org_id
        FROM tmp_union_org
        );
-----------END PORTAL---------- 
-----------КВОТЫ---------------
FOR
rc in
(select o.id as clause_id,qc.quotum_id,r.id as rate_id,r.edate,rp.code as period_code,qr.value,o.org_id,u.new_org_id from tmp_union_org u
join md_quotum_refer_org o on o.org_id=u.old_org_id
join sr_quotum_clause qc on qc.id=o.id
join sr_quotum_rate r on r.clause_id=qc.id
join sr_quotum_quantity_rate qr on qr.id=r.id
join sr_quotum_rate_period rp on rp.id=r.period_id
)
 loop
select o.id as clause_id,r.id as rate_id,rp.code
into _clause,_rate,_period
from md_quotum_refer_org o 
join sr_quotum_clause qc on qc.id=o.id and qc.quotum_id=rc.quotum_id
join sr_quotum_rate r on r.clause_id=qc.id
join sr_quotum_quantity_rate qr on qr.id=r.id and (edate>CURRENT_DATE or edate is null)
join sr_quotum_rate_period rp on rp.id=r.period_id
where o.org_id=rc.new_org_id;
if rc.edate<=CURRENT_DATE THEN
delete from sr_srv_rendered_q_rate where clause_id=rc.clause_id;
delete from md_quotum_dispensary where id=rc.clause_id;
delete from md_quotum_referral where id=rc.clause_id;
delete from md_quotum_executor where id=rc.clause_id;
delete from md_quotum_service where id=rc.clause_id;
delete from md_quotum_srv_proto where id=rc.clause_id;
delete from sr_q_template_clause where id=rc.clause_id;
delete from sr_quotum_clause where id=rc.clause_id;
end if;
if (rc.edate>CURRENT_DATE or rc.edate is null) and _rate is null
then
update md_quotum_refer_org set org_id=rc.new_org_id where org_id=rc.org_id;
end if;
if (rc.edate>CURRENT_DATE or rc.edate is null) and _rate is not null THEN
  if _period=rc.period_code THEN
update sr_srv_rendered_q_rate set rate_id=_rate,clause_id=_clause
where clause_id=rc.clause_id;
update  sr_quotum_quantity_rate set value=value+rc.value
where id=_rate;
delete from sr_srv_rendered_q_rate where clause_id=rc.clause_id;
delete from md_quotum_dispensary where id=rc.clause_id;
delete from md_quotum_referral where id=rc.clause_id;
delete from md_quotum_executor where id=rc.clause_id;
delete from md_quotum_service where id=rc.clause_id;
delete from md_quotum_srv_proto where id=rc.clause_id;
delete from sr_q_template_clause where id=rc.clause_id;
delete from sr_quotum_clause where id=rc.clause_id;
else RAISE EXCEPTION 'Периоды квот разные!';
 end if;
end if; 
end loop;
-----------------
-----------SCOPE --------------
FOR
_r IN
WITH param AS (
        SELECT c.scope_id AS old_scope_id
            ,cl.scope_id AS new_scope_id
            ,t.old_org_id
            ,t.new_org_id,t.is_delete
        FROM tmp_union_org t
        JOIN md_clinic c ON t.old_org_id = c.id
        JOIN md_clinic cl ON t.new_org_id = cl.id
        WHERE cl.scope_id <> c.scope_id
        )
    ,cte AS (
        SELECT CASE
                WHEN k.column_name <> 'id'
                    AND k.table_name NOT IN ('cmn_setting_value')
                    THEN CONCAT (
                            'UPDATE '
                            ,t.constraint_schema
                            ,'.' 
                            ,k.table_name
                            ,' AS u SET '
                            ,k.column_name
                            ,' = '
                            ,f.new_scope_id
                            ,' WHERE u.'
                            ,k.column_name
                            ,' = '
                            ,f.old_scope_id
                            ,';'
                            )
                when k.column_name = 'id' and f.is_delete then 'DELETE FROM ' || k.table_name || ' WHERE ' || k.column_name || ' = ' || f.old_scope_id || ';'
                END AS query
        FROM param f
            ,information_schema.constraint_table_usage t
        JOIN information_schema.constraint_column_usage l ON t.constraint_name = l.constraint_name
        JOIN information_schema.key_column_usage k ON t.constraint_name = k.constraint_name
        JOIN information_schema.table_constraints c ON t.constraint_name = c.constraint_name
        JOIN pg_constraint ON pg_constraint.conname = t.constraint_name
        WHERE c.constraint_type = 'FOREIGN KEY'
            AND t.table_name = 'cmn_scope'
            AND k.table_name NOT LIKE '%aud%'
            AND l.column_name = 'id'
        )
SELECT DISTINCT string_to_array((CAST(c.query AS TEXT)), ';') AS query
FROM cte c
ORDER BY 1 DESC LOOP if _r[1] is not null then
INSERT INTO tmp_union_lpu_log (
    num
    ,step
    ,query
    )
VALUES (
    200
    ,'SCOPE'
    ,_r [1]
    );
EXECUTE (_r [1]); end if;
END
LOOP;
-----------SERVICE--------------
FOR
_r IN
WITH param AS (
        SELECT DISTINCT t.id0 AS old_service_id
            ,t.id1 AS new_service_id,t.is_delete
        FROM tmp_old_sevice t
        )
    ,cte AS (
        SELECT DISTINCT CASE
                WHEN k.column_name <> 'id'
       AND k.table_name NOT IN (
            'fin_pl_pos_to_clinic_srv'
          )
                    THEN CONCAT (
                            'UPDATE '
                            ,t.constraint_schema
                            ,'.' 
                            ,k.table_name
                            ,' AS u SET '
                            ,k.column_name
                            ,' = '
                            ,f.new_service_id
                            ,' WHERE u.'
                            ,k.column_name
                            ,' = '
                            ,f.old_service_id
                            ,';'
                            )
                when k.column_name = 'id' and f.is_delete then 'DELETE FROM ' || k.table_name || ' WHERE '|| k.column_name || ' = ' || f.old_service_id || ';'
                END AS query
        FROM param f
            ,information_schema.constraint_table_usage t
        JOIN information_schema.constraint_column_usage l ON t.constraint_name = l.constraint_name
        JOIN information_schema.key_column_usage k ON t.constraint_name = k.constraint_name
        JOIN information_schema.table_constraints c ON t.constraint_name = c.constraint_name
        JOIN pg_constraint ON pg_constraint.conname = t.constraint_name
        WHERE c.constraint_type = 'FOREIGN KEY'
            AND t.table_name = 'sr_service'
            AND k.table_name NOT LIKE '%aud%'
            AND l.column_name = 'id'
        )
SELECT DISTINCT string_to_array((CAST(c.query AS TEXT)), ',') AS query
FROM cte c
ORDER BY 1 DESC LOOP if _r[1] is not null then
INSERT INTO tmp_union_lpu_log (
    num
    ,step
    ,query
    )
VALUES (
    300
    ,'SERVICE'
    ,_r [1]
    );
EXECUTE (_r [1]); end if;
END
LOOP;
DELETE
FROM sr_service
WHERE id IN (
        SELECT id0
        FROM tmp_old_sevice
        );
-----------CLINIC --------------
FOR
_r IN
WITH param AS (
        SELECT t.old_org_id
            ,t.new_org_id,t.is_delete
        FROM tmp_union_org t
        )
    ,cte AS (
        SELECT CASE
                WHEN k.column_name <> 'id'
                    AND k.table_name NOT IN (
                        'md_nosol_registr_clinic'
                        ,'fin_bill_main_child_clinic'
             ,'fin_bill_main_template_child_clinic'
             ,'pc_clinic_to_group'
                        )
                    THEN CONCAT (
                            'UPDATE '
                            ,t.constraint_schema
                            ,'.' 
                            ,k.table_name
                            ,' AS u SET '
                            ,k.column_name
                            ,' = '
                            ,f.new_org_id
                            ,' WHERE u.'
                            ,k.column_name
                            ,' = '
                            ,f.old_org_id
                            ,';'
                            )
                when k.column_name = 'id' and f.is_delete then 'DELETE FROM ' || k.table_name || ' WHERE ' || k.column_name || ' = ' || f.old_org_id || ';'
                END AS query
        FROM param f
            ,information_schema.constraint_table_usage t
        JOIN information_schema.constraint_column_usage l ON t.constraint_name = l.constraint_name
        JOIN information_schema.key_column_usage k ON t.constraint_name = k.constraint_name
        JOIN information_schema.table_constraints c ON t.constraint_name = c.constraint_name
        JOIN pg_constraint ON pg_constraint.conname = t.constraint_name
        WHERE c.constraint_type = 'FOREIGN KEY'
            AND t.table_name = 'md_clinic'
            AND k.table_name NOT LIKE '%aud%'
      AND k.table_name <>'pci_patient_reg'
            AND l.column_name = 'id'
        )
SELECT DISTINCT string_to_array((CAST(c.query AS TEXT)), ';') AS query
FROM cte c
ORDER BY 1 DESC LOOP if _r[1] is not null then
INSERT INTO tmp_union_lpu_log (
    num
    ,step
    ,query
    )
VALUES (
    400
    ,'CLINIC'
    ,_r [1]
    );
EXECUTE (_r [1]); end if;
END
LOOP;
-----------ORGANIZATION--------------
FOR
_r IN
WITH param AS (
        SELECT t.old_org_id
            ,t.new_org_id,t.is_delete
        FROM tmp_union_org t
        )
    ,cte AS (
        SELECT CASE
                WHEN k.column_name <> 'id'
                    AND k.table_name NOT IN (
                        'pim_org_funding_type'
                        ,'sr_schedule_org'
                        ,'ntf_event_value'
                        ,'trust_doc'
                        )
                    THEN CONCAT (
                            'UPDATE '
                            ,t.constraint_schema
                            ,'.' 
                            ,k.table_name
                            ,' AS u SET '
                            ,k.column_name
                            ,' = '
                            ,f.new_org_id
                            ,' WHERE u.'
                            ,k.column_name
                            ,' = '
                            ,f.old_org_id
                            ,';'
                            )
                when k.column_name = 'id' and f.is_delete then 'DELETE FROM ' || k.table_name || ' WHERE ' || k.column_name || ' = ' || f.old_org_id || ';'
                END AS query
        FROM param f
            ,information_schema.constraint_table_usage t
        JOIN information_schema.constraint_column_usage l ON t.constraint_name = l.constraint_name
        JOIN information_schema.key_column_usage k ON t.constraint_name = k.constraint_name
        JOIN information_schema.table_constraints c ON t.constraint_name = c.constraint_name
        JOIN pg_constraint ON pg_constraint.conname = t.constraint_name
        WHERE c.constraint_type = 'FOREIGN KEY'
            AND t.table_name = 'pim_organization'
            AND k.table_name NOT LIKE '%aud%'
     -- AND k.table_name <>'pim_employee'
            AND l.column_name = 'id'
        )
SELECT DISTINCT string_to_array((CAST(c.query AS TEXT)), ';') AS query
FROM cte c
ORDER BY 1 DESC LOOP if _r[1] is not null then
INSERT INTO tmp_union_lpu_log (
    num
    ,step
    ,query
    )
VALUES (
    500
    ,'ORGANIZATION'
    ,_r [1]
    );
EXECUTE (_r [1]); end if;
END
LOOP;
-----------PARTY--------------
UPDATE sec_user_role_party u
SET party_id = f.new_org_id
FROM tmp_union_org f
WHERE f.old_org_id = u.party_id
    AND NOT EXISTS (
        SELECT TRUE
        FROM sec_user_role_party s
        WHERE s.party_id = f.new_org_id
            AND s.user_role_id = u.user_role_id
        );
UPDATE pim_party_role_to_party u
SET party_id = f.new_org_id
FROM tmp_union_org f
WHERE f.old_org_id = u.party_id
    AND NOT EXISTS (
        SELECT TRUE
        FROM pim_party_role_to_party s
        WHERE s.party_id = f.new_org_id
            AND s.role_id = u.role_id
        );
FOR
_r IN
WITH param AS (
        SELECT t.old_org_id
            ,t.new_org_id,t.is_delete
        FROM tmp_union_org t
        )
    ,cte AS (
        SELECT CASE
                WHEN k.column_name <> 'id'
                    AND k.table_name NOT IN (
                        'sec_user_role_party'
                        ,'pim_party_role_to_party'
                        )
                    THEN CONCAT (
                            'UPDATE '
                            ,t.constraint_schema
                            ,'.' 
                            ,k.table_name
                            ,' AS u SET '
                            ,k.column_name
                            ,' = '
                            ,f.new_org_id
                            ,' WHERE u.'
                            ,k.column_name
                            ,' = '
                            ,f.old_org_id
                            ,';'
                            )
                when k.column_name = 'id' and f.is_delete then 'DELETE FROM ' || k.table_name || ' WHERE ' || k.column_name || ' = ' || f.old_org_id || ';'
                END AS query
        FROM param f
            ,information_schema.constraint_table_usage t
        JOIN information_schema.constraint_column_usage l ON t.constraint_name = l.constraint_name
        JOIN information_schema.key_column_usage k ON t.constraint_name = k.constraint_name
        JOIN information_schema.table_constraints c ON t.constraint_name = c.constraint_name
        JOIN pg_constraint ON pg_constraint.conname = t.constraint_name
        WHERE c.constraint_type = 'FOREIGN KEY'
            AND t.table_name = 'pim_party'
            AND k.table_name NOT LIKE '%aud%'
            AND l.column_name = 'id'
        )
SELECT DISTINCT string_to_array((CAST(c.query AS TEXT)), ';') AS query
FROM cte c
ORDER BY 1 DESC LOOP if _r[1] is not null then
INSERT INTO tmp_union_lpu_log (
    num
    ,step
    ,query
    )
VALUES (
    600
    ,'PARTY'
    ,_r [1]
    );
EXECUTE (_r [1]); end if;
END 
LOOP;
INSERT INTO tmp_union_stat (
    WITH param AS (
        SELECT unnest((array_agg(old_org_id) || array_agg(new_org_id))::INTEGER []) AS org_id
        FROM tmp_union_org
        ) SELECT 'ПОСЛЕ'::TEXT AS "Шаг"
    ,p.org_id AS "ЛПУ"
    ,dep.cnt AS "Kол-во подразделений"
    ,pos.cnt AS "Kол-во штаток"
    ,emp.cnt AS "Kол-во сотрудников"
    ,res.cnt AS "Kол-во сост.ресурсов"
    ,ser.cnt AS "Kол-во услуг"
    ,cs.cnt AS "Kол-во случаев"
    ,srv.cnt AS "Kол-во оказанных услуг"
    ,reg.cnt AS "Kол-во пациентов" FROM param p LEFT JOIN (
    SELECT count(1) AS cnt
        ,d.org_id AS org_id
    FROM pim_department d
    WHERE d.org_id IN (
            SELECT org_id
            FROM param
            )
    GROUP BY 2
    ) dep ON dep.org_id = p.org_id LEFT JOIN (
    SELECT count(1) AS cnt
        ,d.organization_id AS org_id
    FROM pim_position d
    WHERE d.organization_id IN (
            SELECT org_id
            FROM param
            )
    GROUP BY 2
    ) pos ON pos.org_id = p.org_id LEFT JOIN (
    SELECT count(1) AS cnt
        ,d.organization_id AS org_id
    FROM pim_employee d
    WHERE d.organization_id IN (
            SELECT org_id
            FROM param
            )
    GROUP BY 2
    ) emp ON emp.org_id = p.org_id LEFT JOIN (
    SELECT count(1) AS cnt
        ,d.org_id AS org_id
    FROM sr_res_group d
    WHERE d.org_id IN (
            SELECT org_id
            FROM param
            )
    GROUP BY 2
    ) res ON res.org_id = p.org_id LEFT JOIN (
    SELECT count(1) AS cnt
        ,d.org_id AS org_id
    FROM sr_service d
    WHERE d.org_id IN (
            SELECT org_id
            FROM param
            )
    GROUP BY 2
    ) ser ON ser.org_id = p.org_id LEFT JOIN (
    SELECT count(1) AS cnt
        ,d.clinic_id AS org_id
    FROM mc_case d
    WHERE d.clinic_id IN (
            SELECT org_id
            FROM param
            )
    GROUP BY 2
    ) cs ON cs.org_id = p.org_id LEFT JOIN (
    SELECT count(1) AS cnt
        ,d.org_id AS org_id
    FROM sr_srv_rendered d
    WHERE d.org_id IN (
            SELECT org_id
            FROM param
            )
    GROUP BY 2
    ) srv ON srv.org_id = p.org_id LEFT JOIN (
    SELECT count(1) AS cnt
        ,d.clinic_id AS org_id
    FROM pci_patient_reg d
    WHERE d.clinic_id IN (
            SELECT org_id
            FROM param
            )
    GROUP BY 2
    ) reg ON reg.org_id = p.org_id ORDER BY 2 ASC
    );
DELETE
FROM sec_user_role_party
WHERE party_id IN (
        SELECT t.old_org_id
        FROM tmp_union_org t where is_delete
        );
DELETE
FROM pim_party_role_to_party
WHERE party_id IN (
        SELECT t.old_org_id
        FROM tmp_union_org t where is_delete
        );
DELETE
FROM pim_party
WHERE id IN (
        SELECT t.old_org_id
        FROM tmp_union_org t where is_delete
        );
 
UPDATE pim_organization o
SET close_dt = CURRENT_DATE
FROM tmp_union_org f
WHERE f.old_org_id = o.id
AND not is_delete 
;
 
DELETE
FROM tmp_union_org;
EXCEPTION WHEN unique_violation THEN RAISE NOTICE 'Следует обработку таблицы добавить в исключение.'
    ,SQLERRM
    ,SQLSTATE;END;




$$;

