CREATE VIEW fin_dispensary_srv_extra_price AS
  SELECT dispensary_srv_extra_price.item_type,
    dispensary_srv_extra_price.commentary,
    dispensary_srv_extra_price.code,
    dispensary_srv_extra_price.name,
    dispensary_srv_extra_price.tariff,
    dispensary_srv_extra_price.valid_period
   FROM billing.dispensary_srv_extra_price;

