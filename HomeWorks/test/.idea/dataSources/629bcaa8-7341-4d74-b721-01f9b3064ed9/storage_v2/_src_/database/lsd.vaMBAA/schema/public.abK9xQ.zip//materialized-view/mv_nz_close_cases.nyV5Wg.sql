CREATE MATERIALIZED VIEW mv_nz_close_cases AS WITH dset AS (
         SELECT mc.id,
            mc.clinic_id,
            mc.care_regimen_id,
            mc.soc_group_id,
            md.diagnos_id,
            ms.result_id,
            ms.profile_id,
            cres.care_result_id,
            x.id AS democube_days_id,
            i.gender_id,
            COALESCE(hr.department_id, COALESCE(srg.department_id, pp.department_id)) AS department_id,
            date_part('year'::text, age((COALESCE(ms.outcome_date, ms.admission_date))::timestamp with time zone, (i.birth_dt)::timestamp with time zone)) AS age
           FROM ((((((((((mc_case mc
             JOIN mc_step ms ON ((ms.id = mc.closing_step_id)))
             JOIN cube_days x ON ((x.calendar_date = COALESCE(ms.outcome_date, ms.admission_date))))
             JOIN pim_individual i ON (((i.id = mc.patient_id) AND (i.gender_id = ANY (ARRAY[1, 2])) AND (i.birth_dt IS NOT NULL))))
             JOIN mc_diagnosis md ON ((md.id = mc.main_diagnos_id)))
             JOIN sr_res_group srg ON ((srg.id = ms.res_group_id)))
             LEFT JOIN hsp_record hr ON ((hr.id = ms.id)))
             JOIN pim_employee_position pep ON ((pep.id = srg.responsible_id)))
             JOIN pim_position pp ON ((pp.id = pep.position_id)))
             JOIN mc_step_result res ON ((res.id = ms.result_id)))
             LEFT JOIN mc_step_result_care_result cres ON ((cres.result_id = res.id)))
        )
 SELECT dset.clinic_id,
    dset.gender_id,
    dset.soc_group_id,
    dset.care_regimen_id,
    dset.result_id,
    dset.care_result_id,
    dset.department_id,
    dset.diagnos_id,
    dset.profile_id,
    dset.democube_days_id,
        CASE
            WHEN ((dset.gender_id = 1) AND (dset.age >= (16)::double precision) AND (dset.age <= (59)::double precision)) THEN 1
            WHEN ((dset.gender_id = 1) AND (dset.age >= (60)::double precision)) THEN 2
            WHEN ((dset.gender_id = 1) AND (dset.age < (16)::double precision)) THEN 5
            WHEN ((dset.gender_id = 2) AND (dset.age >= (16)::double precision) AND (dset.age <= (54)::double precision)) THEN 3
            WHEN ((dset.gender_id = 2) AND (dset.age >= (55)::double precision)) THEN 4
            WHEN ((dset.gender_id = 2) AND (dset.age < (16)::double precision)) THEN 7
            ELSE NULL::integer
        END AS age_category_2_id,
        CASE
            WHEN (dset.age = (0)::double precision) THEN 1
            WHEN (dset.age <= (3)::double precision) THEN 2
            WHEN (dset.age <= (5)::double precision) THEN 3
            WHEN (dset.age <= (7)::double precision) THEN 4
            WHEN (dset.age <= (14)::double precision) THEN 5
            WHEN (dset.age <= (15)::double precision) THEN 6
            WHEN (dset.age <= (17)::double precision) THEN 7
            ELSE 8
        END AS age_category_3_id,
    count(DISTINCT dset.id) AS mc_cnt
   FROM dset
  GROUP BY dset.clinic_id, dset.gender_id, dset.soc_group_id, dset.care_regimen_id, dset.result_id, dset.care_result_id, dset.department_id, dset.diagnos_id, dset.profile_id, dset.democube_days_id,
        CASE
            WHEN ((dset.gender_id = 1) AND (dset.age >= (16)::double precision) AND (dset.age <= (59)::double precision)) THEN 1
            WHEN ((dset.gender_id = 1) AND (dset.age >= (60)::double precision)) THEN 2
            WHEN ((dset.gender_id = 1) AND (dset.age < (16)::double precision)) THEN 5
            WHEN ((dset.gender_id = 2) AND (dset.age >= (16)::double precision) AND (dset.age <= (54)::double precision)) THEN 3
            WHEN ((dset.gender_id = 2) AND (dset.age >= (55)::double precision)) THEN 4
            WHEN ((dset.gender_id = 2) AND (dset.age < (16)::double precision)) THEN 7
            ELSE NULL::integer
        END,
        CASE
            WHEN (dset.age = (0)::double precision) THEN 1
            WHEN (dset.age <= (3)::double precision) THEN 2
            WHEN (dset.age <= (5)::double precision) THEN 3
            WHEN (dset.age <= (7)::double precision) THEN 4
            WHEN (dset.age <= (14)::double precision) THEN 5
            WHEN (dset.age <= (15)::double precision) THEN 6
            WHEN (dset.age <= (17)::double precision) THEN 7
            ELSE 8
        END;

CREATE INDEX mv_nz_close_cases_clinic_id_inx
  ON mv_nz_close_cases (clinic_id);

CREATE INDEX mv_nz_close_cases_gender_id_inx
  ON mv_nz_close_cases (gender_id);

CREATE INDEX mv_nz_close_cases_soc_group_id_inx
  ON mv_nz_close_cases (soc_group_id);

CREATE INDEX mv_nz_close_cases_care_regimen_id_inx
  ON mv_nz_close_cases (care_regimen_id);

CREATE INDEX mv_nz_close_cases_result_id_inx
  ON mv_nz_close_cases (result_id);

CREATE INDEX mv_nz_close_cases_care_result_id_inx
  ON mv_nz_close_cases (care_result_id);

CREATE INDEX mv_nz_close_cases_department_id_inx
  ON mv_nz_close_cases (department_id);

CREATE INDEX mv_nz_close_cases_diagnos_id_inx
  ON mv_nz_close_cases (diagnos_id);

CREATE INDEX mv_nz_close_cases_profile_id_inx
  ON mv_nz_close_cases (profile_id);

CREATE INDEX mv_nz_close_cases_democube_days_id_inx
  ON mv_nz_close_cases (democube_days_id);

CREATE INDEX mv_nz_close_cases_age_category_2_id_inx
  ON mv_nz_close_cases (age_category_2_id);

CREATE INDEX mv_nz_close_cases_age_category_3_id_inx
  ON mv_nz_close_cases (age_category_3_id);

