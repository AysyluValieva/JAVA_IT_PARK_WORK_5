CREATE FUNCTION get_sr_res_role_params(orgid character varying, depid character varying, formcodeid character varying, OUT id integer, OUT code character varying, OUT name character varying, OUT min integer, OUT max integer, OUT required integer)
  RETURNS SETOF record
LANGUAGE plpgsql
AS $$
begin
  return query
     select sr_res_role.id,cmn_finder.code,sr_res_role.name,coalesce(params.minimum,0), coalesce(params.maximum,1), coalesce(params.required,0) from sr_res_role
     left join
     (
      select distinct on (p.role_id) * from sr_res_role_params as p
      where
           (p.form_code_id = formCodeId::int or p.form_code_id is null)
           and (p.org_id = orgId::int or p.org_id is null)
           and (p.dep_id = depId::int or p.dep_id is null)
           order by p.role_id, p.form_code_id, p.org_id, p.dep_id
      ) as params on params.role_id = sr_res_role.id
      inner join
             cmn_finder on sr_res_role.finder_id=cmn_finder.id
  order by sr_res_role.id;
 end;
$$;

