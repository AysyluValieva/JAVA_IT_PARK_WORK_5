CREATE FUNCTION typing_insert_json_into_case(json, json)
  RETURNS json
LANGUAGE plpgsql
AS $$
declare uniq text;
        rec record; 
        ret json;
        rb boolean;
        rec1 record;
        rc3 record;
        hsp_id_variable INTEGER;
begin

begin --trans
uniq = '';
execute'

---updated 01.06.2015  

-- 1. читаю структуру
----------------------------------------------------

create temp table "typing_diagnos" ON COMMIT DROP AS  
with t as (
 select
  json_array_elements(value) d
 from json_each(
$1 -- эта строка - параметр
 ) where key=''diagnosis''
)

select
 d ->> ''id'' _id,
 d ->> ''mkb_id'' _mkb_id,
 d ->> ''disease_type_id'' _disease_type_id,
 d ->> ''type_id'' _type_id,
 d ->> ''is_main'' _is_main,
 d ->> ''stage_id'' _stage_id,
 d ->> ''step_id'' _step_id,
 d ->> ''step_num'' step_num,
 d ->> ''disp_id'' _disp_id,
 d ->> ''disp_in_out'' disp_in_out,
 d ->> ''nosol_registr_id'' _nosol_registr_id,
 d ->> ''dispensary_group_id'' _dispensary_group_id,
 d ->> ''reg_in_dt'' _reg_in_dt,
 d ->> ''reg_out_dt'' _reg_out_dt,
 d ->> ''reg_in_doctor_id'' _reg_in_doctor_id,
 d ->> ''reg_out_doctor_id'' _reg_out_doctor_id,
 d ->> ''reg_stage_id'' _reg_stage_id,
 d ->> ''reg_out_reason_id'' _reg_out_reason_id

from t
;


create temp table "typing_services"  ON COMMIT DROP AS 
with t as (
 select
  json_array_elements(value) d
 from json_each(
$1 -- эта строка - параметр
 ) where key=''services''
)

select
 d ->> ''id'' _id,
 d ->> ''step_num'' step_num,
 d ->> ''step_id'' _step_id,
 d ->> ''service_num'' service_num,
 d ->> ''service_id'' _service_id,
 d ->> ''bdate'' _bdate,
 d ->> ''funding_id'' _funding_id,
 d ->> ''quantity'' _quantity,
 d ->> ''res_group_id'' _res_group_id,
 d ->> ''mkb_id'' _mkb_id,
 d ->> ''doctor_id'' _doctor_id,
 d ->> ''cul'' _cul,
 d ->> ''note'' _note,
 d ->> ''diag_disease_type_id'' _diag_disease_type_id,
 d ->> ''diag_stage_id'' _diag_stage_id,
 d ->> ''diag_type_id'' _diag_type_id,
 d ->> ''tooth_number'' tooth_number,
 d ->> ''is_refused'' _is_refused,
 d->> ''org_id'' _org_id


from t
;

create temp table  "typing_visits"  ON COMMIT DROP AS  
with t as (
 select
  json_array_elements(value) d
 from json_each(
$1 -- эта строка - параметр
 ) where key=''visits''
)

select
 d ->> ''id'' _id,
 d ->> ''step_num'' step_num,
 d ->> ''type_id'' _type_id,
 d ->> ''admission_date'' _admission_date,
  d ->> ''outcome_date'' _outcome_date,
 d ->> ''place_id'' _place_id,
 d ->> ''initiator_id'' _initiator_id,
 d ->> ''goal_id'' _goal_id,
 d ->> ''profile_id'' _profile_id,
 d ->> ''standard_id'' _standard_id,
 d ->> ''mes_id'' _mes_id,
 d ->> ''res_group_id'' _res_group_id,
 d ->> ''doctor_id'' _doctor_id,
 d ->> ''result_id'' _result_id,
 d ->> ''stepResultReason_id'' _stepResultReason_id,
 d ->> ''outcome_id'' _outcome_id,
 d ->> ''is_viewed'' _is_viewed,
 d ->> ''is_needed'' _is_needed,
 d ->> ''is_sanitized'' _is_sanitized,
 d ->> ''department_id'' _department_id,
 d ->> ''bed_profile_id'' _bed_profile_id,
 d ->> ''csg_id'' _csg_id,
 d ->> ''deviation_reason_id'' _deviation_reason_id,
 d ->> ''complexity_level_id'' _complexity_level_id,
 d ->> ''hosp_department_id'' _hosp_department_id,
 d ->> ''vmp_type_id'' _vmp_type_id,
 d ->> ''vmp_method_id'' _vmp_method_id
 
from t
;


create temp table  "typing_case"   ON COMMIT DROP AS  

with t as (
select
$1::json d
)


select
 d ->> ''id'' _id,
 d ->> ''case_type_id'' _case_type_id,
 d ->> ''patient_id'' _patient_id,
 d ->> ''clinic_id'' _clinic_id,
 d ->> ''uid'' uid,
 d ->> ''care_regimen_id'' _care_regimen_id,
 d ->> ''funding_id'' _funding_id,
 d ->> ''init_goal_id'' _init_goal_id,
 d ->> ''care_level_id'' _care_level_id,
 d ->> ''payment_method_id'' _payment_method_id,
 d ->> ''admission_reason_id'' _admission_reason_id,
 d ->> ''repeat_count_id'' _repeat_count_id,
 d ->> ''referral_id'' _referral_id,
 d ->> ''ref_organization_id'' _ref_organization_id,
 d ->> ''ref_doctor_id'' _ref_doctor_id,
 d ->> ''referral_date'' _referral_date,
 d ->> ''recv_organization_id'' _recv_organization_id,
 d ->> ''ref_mkb_id'' _ref_mkb_id,
 d ->> ''order_number'' order_number,
 d ->> ''referral_type_id'' _referral_type_id,
 d ->> ''sicklist_id'' _sicklist_id,
 d ->> ''sl_code'' sl_code,
 d ->> ''disability_reason_id'' _disability_reason_id,
 d ->> ''disability_from_dt'' _disability_from_dt,
 d ->> ''disability_to_dt'' _disability_to_dt,
 coalesce(d ->> ''care_providing_from_id'',d ->> ''care_providing_form_id'') _care_providing_form_id,
 d ->> ''admission_state'' _admission_state_id,
 d ->> ''drunkenness_type_id'' _drunkenness_type_id,
 d->> ''time_gone_id'' _time_gone_id,
 d->> ''provision_condition_id'' _provision_condition_id,
 d->> ''note'' _note,
 d->> ''workplace_print'' workplace_print,
 d->> ''ready_to_work_dt'' _ready_to_work_dt,
 d->> ''md_sicklist_state'' _md_sicklist_state,
 d->> ''sl_name'' sl_name,
 d->> ''sl_surname'' sl_surname,
 d->> ''sl_patr_name'' sl_patr_name,
 d->> ''employee_position_id'' _employee_position_id

from t
;



create temp table "typing_resources" ON COMMIT DROP AS 
with t as (
 select
  json_array_elements(value) d
 from json_each(
$1 -- эта строка - параметр
 ) where key=''res''
)

select
 d ->> ''role_id'' _role_id,
 d ->> ''step_num'' step_num,
 d ->> ''resourse_id'' _resource_id,
 d ->> ''bdatetime'' _bdatetime,
 d ->> ''edatetime'' _edatetime,
 d ->> ''service_num'' _serv_num
from t
;

create temp table "typing_cur"  ON COMMIT DROP AS 
with t as (
 select
  json_array_elements(value) d
 from json_each(
$1 -- эта строка - параметр
 ) where key=''cur''
)

select
 d ->> ''criteria_id'' _criteria_id,
 d ->> ''step_num'' step_num,
 d ->> ''value'' _value,
 d ->> ''id'' _id
from t
;

create temp table "typing_standarts"  ON COMMIT DROP AS 
with t as (
 select
  json_array_elements(value) d
 from json_each(
$1 -- эта строка - параметр
 ) where key=''standarts''
 )

select
 to_int(d ->> ''csg_id'') csg_id,
 d->> ''step_num''  step_num,
 to_int(d ->> ''vmp_type_id'')vmp_type_id,
 to_int(d ->> ''vmp_method_id'')vmp_method_id

from t
;





-- 2. Случай--------------------------------------------------------------------------

-- 2.1 Добавляю реальные колонки
alter table "typing_case"
 add column id integer,
 add column case_type_id integer,
 add column patient_id integer,
 add column clinic_id integer,
 add column care_regimen_id integer,
 add column funding_id integer,
 add column init_goal_id integer,
 add column care_level_id integer,
 add column payment_method_id integer,
 add column admission_reason_id integer,
 add column repeat_count_id integer,
 add column referral_id integer,
 add column ref_organization_id integer,
 add column ref_doctor_id integer,
 add column ref_mkb_id integer,
 add column referral_date date,
 add column recv_organization_id integer,
 add column referral_type_id integer,
 add column sicklist_id integer,
 add column disability_reason_id integer,
 add column disability_from_dt date,
 add column disability_to_dt date,
 add column care_providing_form_id integer,
 add column admission_state_id integer,
 add column drunkenness_type_id integer,
add COLUMN time_gone_id integer,
add COLUMN provision_condition_id INTEGER,
add column ready_to_work_dt date,
add column  md_sicklist_state integer,
add column employee_position_id integer,

 add column errors text default ''''
;
-- 2.2 Заполняю реальные колонки
update "typing_case" set
 id = to_int(_id),
 case_type_id = coalesce(to_int(_case_type_id), 1),
 patient_id = to_int(_patient_id),
 clinic_id = to_int(_clinic_id),
 care_regimen_id = to_int(_care_regimen_id),
 funding_id = to_int(_funding_id),
 init_goal_id = to_int(_init_goal_id),
 care_level_id = to_int(_care_level_id),
 payment_method_id = to_int(_payment_method_id),
 admission_reason_id = to_int(_admission_reason_id),
 repeat_count_id = to_int(_repeat_count_id),
 referral_id = to_int(_referral_id),
 ref_organization_id = to_int(_ref_organization_id),
 ref_mkb_id = to_int(_ref_mkb_id),
 ref_doctor_id = to_int(_ref_doctor_id),
 referral_date = to_dt(_referral_date),
 recv_organization_id = to_int(_recv_organization_id),
 referral_type_id = to_int(_referral_type_id),
 sicklist_id = to_int(_sicklist_id),
 disability_reason_id = to_int(_disability_reason_id),
 disability_from_dt = to_dt(_disability_from_dt),
 disability_to_dt = to_dt(_disability_to_dt),
care_providing_form_id  = to_int(_care_providing_form_id),
admission_state_id = to_int(_admission_state_id),
drunkenness_type_id = to_int(_drunkenness_type_id),
time_gone_id = to_int(_time_gone_id),
provision_condition_id = to_int(_provision_condition_id),
ready_to_work_dt = to_dt(_ready_to_work_dt),
md_sicklist_state = to_int(_md_sicklist_state),
employee_position_id = to_int(_employee_position_id)




;


-- 2.3. обновляю данные в случае, если есть id при этом проверяю все ограничения
update mc_case c set
 clinic_id = t.clinic_id, care_regimen_id = t.care_regimen_id, funding_id = t.funding_id, init_goal_id = t.init_goal_id, care_level_id = t.care_level_id, payment_method_id = t.payment_method_id,
 admission_reason_id = t.admission_reason_id, repeat_count_id = t.repeat_count_id, referral_id = t.referral_id, patient_id = t.patient_id, uid = t.uid,
    care_providing_form_id = t.care_providing_form_id,admission_state_id = t.admission_state_id,drunkenness_type_id = t.drunkenness_type_id,time_gone_id = t.time_gone_id,provision_condition_id = t.provision_condition_id

from "typing_case" t
where
 c.id = t.id and
 exists (select 1 from pci_patient p where p.id = t.patient_id) and
 exists (select 1 from md_clinic cln where cln.id = t.clinic_id) and
 (exists (select 1 from mc_care_regimen r where r.id = t.care_regimen_id) or t.care_regimen_id is null) and
 (exists (select 1 from fin_funding_source_type f where f.id = t.funding_id) or t.funding_id is null) and
 (exists (select 1 from mc_case_init_goal f where f.id = t.init_goal_id)) and
 (exists (select 1 from mc_care_level cl where cl.id = t.care_level_id) or t.care_level_id is null) and
 (exists (select 1 from mc_payment_method pm where pm.id = t.payment_method_id) or t.payment_method_id is null) and
 (exists (select 1 from mc_admission_reason ar where ar.id = t.admission_reason_id) or t.admission_reason_id is null) and
 (exists (select 1 from mc_repeat_count cl where cl.id = t.repeat_count_id) or t.repeat_count_id is null) and
 (exists (select 1 from md_referral rf where rf.id = t.referral_id) or t.referral_id is null) and t.uid is not null
;

-- 2.4. Запись ошибок (не найден id обновляемого случая) при обновлении случая
update "typing_case" t set errors = ''{"level":"case", "message":"не найден случай по id", "column_name":"id"}''
where id is not null and not exists (select 1 from mc_case c where c.id = t.id);

-- 2.5. Добавляю случай, если нет id, при этом проверяю все ограничения
alter table "typing_case" add column new_id integer;
update "typing_case" t
set new_id = nextval(''mc_case_seq'')
where t.id is null and
 exists (select 1 from pci_patient p where p.id = t.patient_id) and
 exists (select 1 from md_clinic cln where cln.id = t.clinic_id) and
 exists (select 1 from mc_case_type ct where ct.id = t.case_type_id) and
 (exists (select 1 from mc_care_regimen r where r.id = t.care_regimen_id) or t.care_regimen_id is null) and
 (exists (select 1 from fin_funding_source_type f where f.id = t.funding_id) or t.funding_id is null) and
 (exists (select 1 from mc_case_init_goal f where f.id = t.init_goal_id)) and
 (exists (select 1 from mc_care_level cl where cl.id = t.care_level_id) or t.care_level_id is null) and
 (exists (select 1 from mc_payment_method pm where pm.id = t.payment_method_id) or t.payment_method_id is null) and
 (exists (select 1 from mc_admission_reason ar where ar.id = t.admission_reason_id) or t.admission_reason_id is null) and
 (exists (select 1 from mc_repeat_count cl where cl.id = t.repeat_count_id) or t.repeat_count_id is null) and
 (exists (select 1 from md_referral rf where rf.id = t.referral_id) or t.referral_id is null) and t.uid is not null

;



insert into mc_case(id, case_type_id, create_date, clinic_id, patient_id, care_regimen_id, funding_id, init_goal_id, care_level_id, payment_method_id, admission_reason_id, repeat_count_id, referral_id, uid, care_providing_form_id ,
admission_state_id,
drunkenness_type_id ,
time_gone_id,
provision_condition_id,note)
select new_id, case_type_id, current_date, clinic_id, patient_id, care_regimen_id, funding_id, init_goal_id, care_level_id, payment_method_id, admission_reason_id, repeat_count_id, referral_id, uid, care_providing_form_id ,
admission_state_id,
drunkenness_type_id ,
time_gone_id,
provision_condition_id,
_note

 from 
 "typing_case" where new_id
 is not null;


update "typing_case" set id = new_id where new_id is not null;

-- 2.6 Добавление оставшихся ошибок (при обновлении, либо добавлении случая)
update "typing_case" t set errors = concat(errors, ''{"level":"case", "message":"не найден тип случая по case_type_id = '', case_type_id, ''", "column_name":"case_type_id"}'')
 where not exists (select 1 from mc_case_type ct where ct.id = t.case_type_id);
update "typing_case" t set errors = concat(errors, ''{"level":"case", "message":"не найден пациент по patient_id = '', patient_id, ''", "column_name":"id"}'')
 where not exists (select 1 from pci_patient p where p.id = t.patient_id);
update "typing_case" t set errors = concat(errors, ''{"level":"case", "message":"не найдена МО по clinic_id = '', clinic_id, ''", "column_name":"clinic_id"}'')
 where not exists (select 1 from md_clinic cln where cln.id = t.clinic_id);
update "typing_case" t set errors = concat(errors, ''{"level":"case", "message":"не найден care_regimen_id = '', care_regimen_id, ''", "column_name":"care_regimen_id"}'')
 where care_regimen_id is not null and not exists (select 1 from mc_care_regimen cr where cr.id = t.care_regimen_id);
update "typing_case" t set errors = concat(errors, ''{"level":"case", "message":"не найден funding_id = '', funding_id, ''", "column_name":"funding_id"}'')
 where funding_id is not null and not exists (select 1 from fin_funding_source_type x where x.id = t.funding_id);
update "typing_case" t set errors = concat(errors, ''{"level":"case", "message":"не найден init_goal_id = '', init_goal_id, ''", "column_name":"init_goal_id"}'')
 where not exists (select 1 from mc_case_init_goal x where x.id = t.init_goal_id);
update "typing_case" t set errors = concat(errors, ''{"level":"case", "message":"не найден care_level_id = '', care_level_id, ''", "column_name":"care_level_id"}'')
 where care_level_id is not null and not exists (select 1 from mc_care_level x where x.id = t.care_level_id);
update "typing_case" t set errors = concat(errors, ''{"level":"case", "message":"не найден payment_method_id = '', payment_method_id, ''", "column_name":"payment_method_id"}'')
 where payment_method_id is not null and not exists (select 1 from mc_payment_method x where x.id = t.payment_method_id);
update "typing_case" t set errors = concat(errors, ''{"level":"case", "message":"не найден admission_reason_id = '', admission_reason_id, ''", "column_name":"admission_reason_id"}'')
 where admission_reason_id is not null and not exists (select 1 from mc_admission_reason x where x.id = t.admission_reason_id);
update "typing_case" t set errors = concat(errors, ''{"level":"case", "message":"не найден repeat_count_id = '', repeat_count_id, ''", "column_name":"repeat_count_id"}'')
 where repeat_count_id is not null and not exists (select 1 from mc_repeat_count x where x.id = t.repeat_count_id);
update "typing_case" t set errors = concat(errors, ''{"level":"case", "message":"не найден referral_id = '', referral_id, ''", "column_name":"referral_id"}'')
 where referral_id is not null and not exists (select 1 from md_referral x where x.id = t.referral_id);
update "typing_case" t set errors = concat(errors, ''{"level":"case", "message":"не найден uid = '', uid, ''", "column_name":"uid"}'')
 where referral_id is not null and not exists (select 1 from md_referral x where x.id = t.referral_id);
update "typing_case" t set errors = concat(errors, ''{"level":"case", "message":"Данный случай включен в реестр, изменение невозможно", 
"column_name":"id"}'')
 where exists(select 1 FROM fin_bill_spec_item f JOIN md_srv_rendered m ON m.id = f.service_id WHERE m.case_id =t.id);
  





-- 2.5 Ресурс-------------------------------------------------------------------------
-- 2.5.1 добавляю реальные колонки----------------------------------------------------

alter table "typing_resources"
 add column role_id integer,
 add column serv_num    integer,
 add column resource_id integer,
 add column bdatetime   date,
 add column edatetime   date,
 add column group_id    integer,
 add column org_id      integer,
 add column responsible_id integer,
 add column errors      text default ''''
;

--- 2.5.2 Заполняю реальные колонки
update "typing_resources" set
 role_id    = to_int(_role_id),
 serv_num    = to_int(_serv_num ),
 resource_id = to_int(_resource_id),
 bdatetime  = to_dt(_bdatetime),
 edatetime  = to_dt(_edatetime)
 ;


---Добавляю группу и организацию
update "typing_resources" set
group_id= nextval(''sr_res_group_seq'')
WHERE resource_id in(SELECT max(resource_id) FROM "typing_resources" group by serv_num, step_num);

update "typing_resources" set
org_id =  (SELECT clinic_id FROM  "typing_case" limit 1);


update "typing_resources" r set
responsible_id = employee_position_id
FROM pim_employee_position_resource epr WHERE epr.id = r.resource_id and  group_id is not null
and exists(SELECT 1 FROM sr_resource sr WHERE sr.id = r.resource_id)
and exists(SELECT 1 FROM sr_res_role x WHERE id = r.role_id and x.kind_id =1)
;


insert into sr_res_group(id, org_id,edate, bdate, responsible_id, is_system, department_id)
SELECT group_id, org_id, edatetime, bdatetime, responsible_id, true, null FROM  "typing_resources" r WHERE  group_id is not null
and exists(SELECT 1 FROM pim_organization o WHERE o.id = r.org_id);



--Заполняю группу
update "typing_resources" r set
group_id= t.group_id
FROM "typing_resources" t WHERE t.group_id is not null and ((t.serv_num = r.serv_num) or (t.serv_num is null and r.serv_num is null ))  and t.step_num = r.step_num and r.group_id is null;

insert into sr_res_group_relationship(id, resource_id,bdatetime, edatetime,group_id, role_id,is_disabled)
  SELECT nextval(''sr_res_group_relationship_seq''), resource_id,bdatetime,edatetime, group_id, role_id, CASE when edatetime is not null then true end
  FROM  "typing_resources" t
WHERE exists(SELECT 1 FROM sr_resource r WHERE  r.id = t.resource_id)
and exists(SELECT 1 FROM sr_res_role r WHERE r.id= t.role_id ) 
;




update "typing_resources" t set errors = concat(errors, ''{"level":"resource", "message":"не найден ресурс по resource_id = '', resource_id, ''", "column_name":"resource_id"}'')
 where not exists (select 1 from sr_resource ct where ct.id = t.resource_id);
update "typing_resources" t set errors = concat(errors, ''{"level":"resource", "message": "не найдена роль по role_id = '', role_id, ''", "column_name":"role_id"}'')
 where not exists (select 1 from sr_res_role ct where ct.id = t.role_id);
update "typing_resources" t set errors = concat(errors, ''{"level":"resource", "message": "МО сотрудника и МО случая не совпадают", "column_name":"id"}'')
 where not exists (select 1 
	 from pim_employee_position_resource epr
     join pim_employee_position ep on epr.employee_position_id = ep.id
     join pim_employee e on ep.employee_id = e.id
	 WHERE epr.id = t.resource_id
	 and e.organization_id = t.org_id
	 ) and  t.resource_id is not null
    ;
 




-- 3. Шаги--------------------------------------------------------------------------
-- 3.1 добавление реальных колонок
alter table "typing_visits"
 add column case_id integer,
 add column id integer,
 add column type_id integer,
 add column admission_date date,
 add column outcome_date date,
 add column place_id integer,
 add column initiator_id integer,
 add column goal_id integer,
 add column profile_id integer,
 add column standard_id integer,
 add column mes_id integer,
 add column res_group_id integer,
 add column result_id integer,
 add column stepResultReason_id integer,
 add column outcome_id integer,
 add column patient_id integer,
 add column clinic_id integer,
 add column doctor_id integer,
 add column is_viewed boolean,
 add column is_needed boolean,
 add column is_sanitized boolean,
add COLUMN department_id INTEGER,
add COLUMN hosp_department_id integer,
add COLUMN bed_profile_id INTEGER,
    add column csg_id INTEGER,
add column complexity_level_id INTEGER,
add column deviation_reason_id INTEGER,
add column vmp_type_id INTEGER,
add column vmp_method_id INTEGER,
 add column errors text default ''''
 
;

-- 3.2 Заполнение реальных колонок
update "typing_visits" set
 case_id = (select id from "typing_case"),
 patient_id = (select patient_id from "typing_case"),
 clinic_id = (select clinic_id from "typing_case"),
 id = to_int(_id),
 type_id = to_int(_type_id),
 admission_date = to_dt(_admission_date),
 outcome_date = to_dt(_outcome_date),
 place_id = to_int(_place_id),
 initiator_id = to_int(_initiator_id),
 goal_id = to_int(_goal_id),
 profile_id = to_int(_profile_id),
 standard_id = to_int(_standard_id),
 mes_id = to_int(_mes_id),
 res_group_id = to_int(_res_group_id),
 stepResultReason_id = to_int(_stepResultReason_id),
 result_id = to_int(_result_id),
 outcome_id = to_int(_outcome_id),
 doctor_id = to_int(_doctor_id),
department_id = to_int(_department_id),
bed_profile_id = to_int(_bed_profile_id),
csg_id = to_int(_csg_id),
hosp_department_id = to_int(_hosp_department_id),
complexity_level_id= to_int(_complexity_level_id),
deviation_reason_id = to_int(_deviation_reason_id),
vmp_type_id  = to_int(_vmp_type_id),
vmp_method_id = to_int(_vmp_method_id),
 is_viewed =  case when _is_viewed = ''true'' or _is_viewed = ''1'' then true else false end,
 is_needed =  case when _is_needed = ''true'' or _is_needed = ''1'' then true else false end,
 is_sanitized =  case when _is_sanitized = ''true'' or _is_sanitized = ''1'' then true else false end
;

update "typing_visits" v
set res_group_id = group_id
FROM "typing_resources" r
WHERE (v.step_num = r.step_num
or (r.step_num is null)) --- если для всего случая - r.step_id должен быть пустой 
and v.res_group_id is null
;




-- 3.2.1 Удаляю информацию по закрытию случая.
update mc_step s 
set result_id =null
FROM  "typing_case" c WHERE c.id is not null and c.id =s.case_id
and exists(SELECT 1 FROM mc_step_result r WHERE  r.id = s.result_id and is_closed = true);

update "typing_visits" t
  set res_group_id =  typing_gen_res_group(t.doctor_id, null)
  WHERE exists(SELECT 1 FROM "typing_visits" t JOIN mc_step s ON s.id = t.id)
and exists(SELECT 1 FROM sr_res_group s WHERE s.id = t.res_group_id and is_system =false)
and t.doctor_id is not null;

update "typing_visits" t
  set res_group_id = typing_gen_res_group(null, t.res_group_id)
  WHERE exists(SELECT 1 FROM "typing_visits" t JOIN mc_step s ON s.id = t.id)
and exists(SELECT 1 FROM sr_res_group s WHERE s.id = t.res_group_id and is_system =false)
and t.res_group_id is not null
--and id is null
;

update "typing_visits" t
  set res_group_id = typing_gen_res_group(null, t.res_group_id )
from mc_step step
 WHERE exists(SELECT 1 FROM "typing_visits" t JOIN mc_step s ON s.id = t.id)
and exists(SELECT 1 FROM sr_res_group s WHERE s.id = t.res_group_id and is_system =false)
--and t.doctor_id is not null
and t.id is not null
and t.id = step.id
;




-- 3.3 Oбновляю шаги
update mc_step st set
 admission_date = t.admission_date,
 outcome_date = coalesce(t.outcome_date,t.admission_date),
 profile_id = t.profile_id,
 mes_id = t.mes_id,
 standard_id = t.standard_id,
 res_group_id =   typing_gen_res_group(null,t.res_group_id),
 result_id = t.result_id,
 reason_id = t.stepResultReason_id,
 outcome_id = t.outcome_id,
 vmp_method_id =t.vmp_method_id,
 vmp_type_id = t.vmp_type_id,
 csg_id = coalesce(t.csg_id, standarts.csg_id)
from "typing_visits" t left join(select * from typing_standarts limit 1) standarts on true
 where st.id = t.id and
 exists (select 1 from mc_case c where c.id = t.case_id) and exists (select 1 from mc_step st where st.id = t.id) and t.admission_date is not null and
 --exists (select 1 from plc_visit_place x where x.id = t.place_id) and
 (exists (select 1 from md_profile x where x.id = t.profile_id) or t.profile_id is null) and
 (exists (select 1 from md_mes x where x.id = t.mes_id) or t.mes_id is null) and
 (exists (select 1 from md_standard x where x.id = t.standard_id) or t.standard_id is null) and
 --(exists (select 1 from sr_res_group x where x.id = t.res_group_id) or t.res_group_id is null) and
 (exists (select 1 from mc_case_init_goal x where x.id = t.goal_id)) and
 (exists (select 1 from plc_initiator x where x.id = t.initiator_id) or t.initiator_id is null) and
 (exists (select 1 from plc_visit_type x where x.id = t.type_id) or t.type_id is null) and
 (exists (select 1 from sr_resource x where x.id = t.doctor_id) or t.doctor_id is null) and
 (exists (select 1 from mc_step_result x where x.id = t.result_id) or t.result_id is null) and
 (exists (select 1 from mc_step_result_reason x where x.id = t.stepResultReason_id) or t.stepResultReason_id is null) and
 (exists (select 1 from mc_step_care_result x where x.id = t.outcome_id) or t.outcome_id is null)
and (exists(SELECT 1 FROM mc_vmp_method x WHERE x.id = t.vmp_method_id) or  t.vmp_method_id is null)
and (exists(SELECT 1 FROM mc_vmp_type x WHERE x.id = t.vmp_type_id) or t.vmp_type_id is null)
;








update plc_visit v set
 goal_id = t.goal_id,
 initiator_id = t.initiator_id,
 place_id = t.place_id,
 type_id = t.type_id,
 is_viewed = t.is_viewed,
 is_needed = t.is_needed,
 is_sanitized = t.is_sanitized
from "typing_visits" t  CROSS JOIN "typing_case" c   where v.id = t.id and c.case_type_id <> 2 and
 exists (select 1 from mc_case c where c.id = t.case_id) and exists (select 1 from mc_step st where st.id = t.id) and t.admission_date is not null and
 exists (select 1 from plc_visit_place x where x.id = t.place_id) and
 (exists (select 1 from md_profile x where x.id = t.profile_id) or t.profile_id is null) and
 (exists (select 1 from md_mes x where x.id = t.mes_id) or t.mes_id is null) and
 (exists (select 1 from md_standard x where x.id = t.standard_id) or t.standard_id is null) and
 (exists (select 1 from sr_res_group x where x.id = t.res_group_id) or t.res_group_id is null) and
 (exists (select 1 from mc_case_init_goal x where x.id = t.goal_id)) and
 (exists (select 1 from plc_initiator x where x.id = t.initiator_id) or t.initiator_id is null) and
 (exists (select 1 from plc_visit_type x where x.id = t.type_id) or t.type_id is null) and
 (exists (select 1 from mc_step_result x where x.id = t.result_id) or t.result_id is null) and
 (exists (select 1 from mc_step_care_result x where x.id = t.outcome_id) or t.outcome_id is null) and
 (exists (select 1 from sr_resource x where x.id = t.doctor_id) or t.doctor_id is null) and
 (exists (select 1 from mc_step_result x where x.id = t.result_id) or t.result_id is null) and
 (exists (select 1 from mc_step_care_result x where x.id = t.outcome_id) or t.outcome_id is null)

 ;

update sr_res_group_relationship rgr set resource_id = t.doctor_id
from "typing_visits" t, sr_res_role r where t.res_group_id = rgr.group_id and r.id = rgr.role_id and r.code = ''DOCTOR'' and t.doctor_id is not null 
and exists(SELECT 1 FROM "typing_visits" t JOIN mc_step s ON s.id = t.id)
and exists(SELECT 1 FROM sr_res_group s WHERE s.id = t.res_group_id and is_system = true);
 


 update hsp_record h set
 mes_id = t.mes_id,
 issue_planned_date = CASE when exists(SELECT 1 FROM mc_step_result x WHERE is_closed = true and id in(SELECT result_id FROM "typing_visits")) then (select max(outcome_date) from "typing_visits" ) end
 from "typing_visits" t CROSS JOIN "typing_case" c   where h.id = t.id and c.case_type_id = 2 and h.id = t.id  and exists (select 1 from mc_case c where c.id = t.case_id) and exists (select 1 from mc_step st where st.id = t.id) and t.admission_date is not null ;



-- 3.4 Добавляю ошибку, если обновляемый шаг не существует
update "typing_visits" t set errors = concat(errors, ''{"level":"step", "message":"не найден шаг по id = '', id, ''", "column_name":"id"}'')
 where id is not null and not exists (select 1 from mc_step x where x.id = t.id);



-- 3.5 Добавляю шаги, если нет id
alter table "typing_visits" add column new_id integer;
update "typing_visits" t
set new_id = nextval(''mc_step_seq'')
where id is null and
 exists (select 1 from mc_case c where c.id = t.case_id) and t.admission_date is not null and
 exists (select 1 from plc_visit_place x where x.id = t.place_id) and
 (exists (select 1 from md_profile x where x.id = t.profile_id) or t.profile_id is null) and
 (exists (select 1 from md_mes x where x.id = t.mes_id) or t.mes_id is null) and
 (exists (select 1 from md_standard x where x.id = t.standard_id) or t.standard_id is null) and
 (exists (select 1 from sr_res_group x where x.id = t.res_group_id) or t.res_group_id is null) and
 (exists (select 1 from mc_case_init_goal x where x.id = t.goal_id)) and
 (exists (select 1 from plc_initiator x where x.id = t.initiator_id) or t.initiator_id is null) and
 (exists (select 1 from plc_visit_type x where x.id = t.type_id) or t.type_id is null) and
 (exists (select 1 from mc_step_result x where x.id = t.result_id) or t.result_id is null) and
 (exists (select 1 from mc_step_care_result x where x.id = t.outcome_id) or t.outcome_id is null) and
 (exists (select 1 from sr_resource x where x.id = t.doctor_id) or t.doctor_id is null)
;

update "typing_visits" t
set new_id = nextval(''mc_step_seq'')
where  id is null and exists (select 1 from mc_case c where c.id = t.case_id) and t.admission_date is not null
and(exists(SELECT 1 FROM mc_deviation_reason x WHERE x.id = t.deviation_reason_id) or t.deviation_reason_id is null)
and(exists(select 1 FROM mc_complexity_level x WHERE x.id = t.complexity_level_id) or t.complexity_level_id is null)
and (exists(SELECT 1 FROM md_profile p WHERE p.id = t.profile_id) or t.profile_id is null) 
and (exists(select 1 FROM mc_step_result x WHERE t.result_id = x.id)
or  t.result_id is null)
and (exists(SELECT 1 FROM mc_step_care_result x WHERE x.id = t.outcome_id ) or t.outcome_id is null)
and (exists(SELECT 1 FROM mc_vmp_method x WHERE x.id = t.vmp_method_id) or  t.vmp_method_id is null)
and (exists(SELECT 1 FROM mc_vmp_type x WHERE x.id = t.vmp_type_id) or t.vmp_type_id is null)

;

update "typing_visits" t
set res_group_id = case when coalesce(res_group_id, doctor_id) is not null then typing_gen_res_group(doctor_id, res_group_id) end;

insert into mc_step(id, admission_date,admission_time, outcome_date, case_id, outcome_id, result_id, reason_id, profile_id, mes_id,csg_id, res_group_id,regimen_id,outcome_regimen_id,deviation_reason_id, vmp_method_id, vmp_type_id)
select t.new_id, t.admission_date,''0:0:0''::time,  CASE when t.outcome_date is null then t.admission_date else t.outcome_date end, t.case_id, t.outcome_id, t.result_id, t.stepResultReason_id, t.profile_id, t.mes_id,coalesce(t.csg_id,standarts.csg_id),t.res_group_id, c.care_regimen_id, c.care_regimen_id,deviation_reason_id,coalesce(t.vmp_method_id,standarts.vmp_method_id),coalesce(t.vmp_type_id,standarts.vmp_type_id) from "typing_visits" t
  cross join   "typing_case" c left join (select * from typing_standarts standarts limit 1)  standarts on true
 where
 t.new_id is not null --and case_id is not null and admission_date is not null and place_id is not null
;


insert into plc_visit(id, goal_id, initiator_id, place_id, type_id, is_viewed, is_needed, is_sanitized)
select t.new_id, goal_id, initiator_id, place_id, type_id, is_viewed, is_needed, is_sanitized from "typing_visits" t  cross join   "typing_case" where case_type_id <> 2
and t.new_id is not null and place_id is not null
and exists(SELECT 1 FROM mc_step x WHERE x.id =t.new_id)
and exists(SELECT 1 FROM plc_visit_place x WHERE x.id =t.place_id)
and t.new_id is not null
 --and case_id is not null and admission_date is not null and place_id is not null

;


insert into hsp_record(id,mes_id,funding_id,department_id, bed_profile_id,issue_planned_date,complexity_level_id)
select t.new_id, mes_id ,funding_id, CASE WHEN step_num =''1'' then COALESCE(hosp_department_id, department_id) else coalesce(department_id, hosp_department_id) end,bed_profile_id, CASE when exists(SELECT 1 FROM mc_step_result x WHERE is_closed = true and id in(SELECT result_id FROM "typing_visits")) then (select max(outcome_date) from "typing_visits" ) end,complexity_level_id from "typing_visits" t cross join   "typing_case" where case_type_id = 2
and t.new_id is not null 
and exists(SELECT 1 FROM mc_step s WHERE s.id = t.new_id)
and exists(select 1 FROM pim_department x WHERE x.id =COALESCE(hosp_department_id, department_id))
;



update hsp_record h
set previous_id = (SELECT max(t.new_id) FROM "typing_visits" t WHERE t.new_id<h.id)
FROM "typing_visits" t WHERE h.id in (SELECT new_id FROM "typing_visits")
and exists( select 1 from hsp_record  where id = (SELECT max(t.new_id) FROM "typing_visits" t WHERE t.new_id<h.id))
;

update "typing_visits" set id = new_id where new_id is not null;

-- 3.6 Добавляю все ошибки при добавлении либо обновлении шага
update "typing_visits" t set errors = concat(errors, ''{"level":"step", "message":"не заполнен admission_date", "column_name":"admission_date"}'')
 where t.admission_date is null;
update "typing_visits" t set errors = concat(t.errors, ''{"level":"step", "message":"не заполнен place_id", "column_name":"place_id"}'')
from  "typing_case" c
 where t.place_id is null
 and not exists (SELECT 1 FROM  "typing_case" where case_type_id = 2);
update "typing_visits" t set errors = concat(t.errors, ''{"level":"step", "message":"неверный place_id = ", "column_name":"place_id"}'')
from  "typing_case" c
 where not exists(SELECT 1 FROM plc_visit_place x WHERE x.id =t.place_id) and t.place_id is not null;
update "typing_visits" t set errors = concat(errors, ''{"level":"step", "message":"не найден profile_id = '', profile_id, ''", "column_name":"profile_id"}'')
 where profile_id is not null and not exists (select 1 from md_profile x where x.id = t.profile_id)
;
update "typing_visits" t set errors = concat(errors, ''{"level":"step", "message":"не найден mes_id = '', mes_id, ''", "column_name":"mes_id"}'')
 where mes_id is not null and not exists (select 1 from md_mes x where x.id = t.mes_id);
update "typing_visits" t set errors = concat(errors, ''{"level":"step", "message":"не найден standard_id = '', standard_id, ''", "column_name":"standard_id"}'')
 where standard_id is not null and not exists (select 1 from md_standard x where x.id = t.standard_id);
update "typing_visits" t set errors = concat(errors, ''{"level":"step", "message":"не найден res_group_id = '', res_group_id, ''", "column_name":"res_group_id"}'')
 where res_group_id is not null and not exists (select 1 from sr_res_group x where x.id = t.res_group_id);
update "typing_visits" t set errors = concat(errors, ''{"level":"step", "message":"не найден goal_id = '', goal_id, ''", "column_name":"goal_id"}'')
 where not exists (select 1 from mc_case_init_goal x where x.id = t.goal_id);
update "typing_visits" t set errors = concat(errors, ''{"level":"step", "message":"не найден initiator_id = '', initiator_id, ''", "column_name":"initiator_id"}'')
 where initiator_id is not null and not exists (select 1 from plc_initiator x where x.id = t.initiator_id);
update "typing_visits" t set errors = concat(errors, ''{"level":"step", "message":"не найден type_id = '', type_id, ''", "column_name":"type_id"}'')
 where type_id is not null and not exists (select 1 from plc_visit_type x where x.id = t.type_id);
update "typing_visits" t set errors = concat(errors, ''{"level":"step", "message":"не найден result_id = '', result_id, ''", "column_name":"result_id"}'')
 where result_id is not null and not exists (select 1 from mc_step_result x where x.id = t.result_id);
update "typing_visits" t set errors = concat(errors, ''{"level":"step", "message":"не найден outcome_id = '', outcome_id, ''", "column_name":"outcome_id"}'')
 where outcome_id is not null and not exists (select 1 from mc_step_care_result x where x.id = t.outcome_id);

update "typing_visits" t set errors = concat(errors, ''{"level":"step", "message":"не найден result_id '', result_id, ''", "column_name":"result_id"}'')
 where not exists(SELECT 1 FROM "typing_visits" WHERE result_id is not null);
update "typing_visits" t set  errors = concat(t.errors, ''{"level":"step", "message": "Не найден department_id =  '', department_id, ''", "column_name":"outcome_id"}'')
FROM "typing_case" tc where not exists(select 1 FROM pim_department x WHERE x.id =t.department_id) and tc.case_type_id = 2 and t.department_id is not null;
update "typing_visits" t set  errors = concat(t.errors, ''{"level":"step", "message": "Не найден hosp_department_id =  '', hosp_department_id, ''", "column_name":"outcome_id"}'')
FROM "typing_case" tc where not exists(select 1 FROM pim_department x WHERE x.id =t.hosp_department_id) and tc.case_type_id = 2 and t.hosp_department_id is not null;

update "typing_visits" t set  errors = concat(t.errors, ''{"level":"step", "message": "МО сотрудника и МО случая не совпадают  '', doctor_id, ''", "column_name":"doctor_id"}'')
where not exists (select 1 
	 from pim_employee_position_resource epr
     join pim_employee_position ep on epr.employee_position_id = ep.id
     join pim_employee e on ep.employee_id = e.id
	 WHERE epr.id = t.doctor_id
	 and e.organization_id = t.clinic_id)
and t.doctor_id is not null;

-- 3.5 Коэффициент курации
alter table "typing_cur"
 add column id integer,
 add column criteria_id integer,
 add column new_id integer,
 add column value numeric,
 add column errors text default ''''
;


update typing_cur set
id = to_int(_id),
criteria_id=to_int(_criteria_id),
value = to_numeric(_value)
;

--- Обновляю, если есть id
update mc_step_cur_coef_criteria c
set value = t.value,
criteria_id = t.criteria_id
FROM typing_cur t WHERE c.id = t.id
;



update typing_cur c
set new_id = nextval(''mc_step_cur_seq'')
WHERE exists(SELECT 1 FROM mc_cur_coef_criteria x WHERE x.id = c.criteria_id)
and value is not null
;

insert into mc_step_cur_coef_criteria(id, criteria_id,step_id,value)
SELECT c.new_id, c.criteria_id,v.new_id, c.value FROM typing_cur c JOIN typing_visits v ON c.step_num = v.step_num
WHERE c.new_id is not null and v.new_id is not null;


-- Добавляю ошибки

update "typing_cur" t set  errors = concat(t.errors, ''{"level":"cur", "message":" Не указан criteria_id '', criteria_id, ''", "column_name":"criteria_id"}'')
 where criteria_id is null;
update "typing_cur" t set  errors = concat(t.errors, ''{"level":"cur", "message":" Не указан step_num'', step_num, ''", "column_name":"step_num"}'')
where step_num is null;
update "typing_cur" t set  errors = concat(t.errors, ''{"level":"cur", "message":" Не указан value'', value, ''", "column_name":"value"}'')
 where value is null;
update "typing_cur" t set  errors = concat(t.errors, ''{"level":"cur", "message":" Не найден criteria_id ='', criteria_id, ''", "column_name":"criteria_id"}'')
 where criteria_id is not null and not exists(SELECT 1 FROM mc_cur_coef_criteria x WHERE x.id = t.criteria_id);


-- 4. Услуги-----------------------------------------------------------------------------------------------------------------------------
-- 4.1 Добавление реальных колонок
alter table "typing_services"
 add column id integer,
 add column step_id integer,
 add column case_id integer,
 add column service_id integer,
 add column bdate date,
 add column funding_id integer,
 add column quantity integer,
 add column res_group_id integer,
 add column mkb_id integer,
 add column clinic_id integer,
 add column patient_id integer,
 add column new_id integer,
 add column doctor_id integer,
 add column cul numeric,
 add column is_refused boolean,
 add column diag_type_id int,
 add column diag_disease_type_id int,
 add column diag_stage_id int,
 add column org_id int,
 add column errors text default ''''
;

-- 4.2 Заполнение реальных колонок
update "typing_services" set
 case_id = (select id from "typing_case"),
 id = to_int(_id),
 step_id = to_int(_step_id),
 service_id = to_int(_service_id),
 bdate =  to_dt(_bdate),
 funding_id = to_int(_funding_id),
 quantity = to_int(_quantity),
 res_group_id = to_int(_res_group_id),
 mkb_id = to_int(_mkb_id),
 is_refused = CASE when _is_refused is null then false else _is_refused = ''1'' end,
 doctor_id = to_int(_doctor_id),
 clinic_id = (select clinic_id from "typing_case" where clinic_id is not null),
 patient_id = (select patient_id from "typing_case"),
 diag_stage_id = to_int(_diag_stage_id),
 diag_type_id = to_int(_diag_type_id) ,
 diag_disease_type_id= to_int(_diag_disease_type_id),
 cul = to_numeric(_cul),
 org_id = to_int(_org_id)
;


update "typing_services" s
set res_group_id = group_id
FROM "typing_resources" r
WHERE (s.step_num = r.step_num
or (r.step_num is null)) --- если для всего случая - r.step_id должен быть пустой 
and s.res_group_id is null
;

-- 4.3 Обновляю услуги
update sr_srv_rendered r set
       bdate = t.bdate, funding_id = t.funding_id, res_group_id = t.res_group_id, service_id = t.service_id, customer_id = t.patient_id, org_id = t.clinic_id, cul = t.cul
  from "typing_services" t
 where t.id = r.id and exists (select 1 from mc_case c where c.id = t.case_id)
   and (exists (select 1 from fin_funding_source_type x where x.id = t.funding_id) or t.funding_id is null)
   --and (exists (select 1 from sr_res_group x where x.id = t.res_group_id) or t.res_group_id is null)
   and (exists (select 1 from sr_resource x where x.id = t.doctor_id) or t.doctor_id is null)
   and exists (select 1 from sr_service x where x.id = t.service_id)
   and exists (select 1 from pci_patient x where x.id = t.patient_id)
   and exists (select 1 from md_clinic x where x.id = t.clinic_id)
   and (exists (select 1 from mc_step x where x.id = t.step_id) or t.step_id is null)
   and (exists (select 1 from md_diagnosis x where x.id = t.mkb_id) or t.mkb_id is null)
;

update md_srv_rendered r set
 step_id = t.step_id, diagnosis_id = t.mkb_id, case_id = t.case_id
from "typing_services" t
where t.id = r.id and exists (select 1 from mc_case c where c.id = t.case_id) and
 (exists (select 1 from fin_funding_source_type x where x.id = t.funding_id) or t.funding_id is null) and
 --(exists (select 1 from sr_res_group x where x.id = t.res_group_id) or t.res_group_id is null) and
 (exists (select 1 from sr_resource x where x.id = t.doctor_id) or t.doctor_id is null) and
 (exists (select 1 from sr_service x where x.id = t.service_id)) and
 exists (select 1 from pci_patient x where x.id = t.patient_id) and
 exists (select 1 from md_clinic x where x.id = t.clinic_id) and
 (exists (select 1 from mc_step x where x.id = t.step_id) or t.step_id is null) and
 (exists (select 1 from md_diagnosis x where x.id = t.mkb_id) or t.mkb_id is null)
;


-- 4.4 Добавляю ошибку (отсутствует id услуги)
update "typing_services" t set errors = concat(errors, ''{"level":"srv", "message":"не найдена услуга по id = '', id, ''", "column_name":"id"}'')
 where id is not null and not exists (select 1 from sr_srv_rendered x where x.id = t.id);

-- 4.5 Добавляю услуги, если нет id
update "typing_services" t set new_id = nextval(''sr_srv_rendered_seq'')
where id is null and exists (select 1 from mc_case c where c.id = t.case_id) and
 (exists (select 1 from fin_funding_source_type x where x.id = t.funding_id) or t.funding_id is null) and
 --(exists (select 1 from sr_res_group x where x.id = t.res_group_id) or t.res_group_id is null) and
 (exists (select 1 from sr_resource x where x.id = t.doctor_id) or t.doctor_id is null) and
 (exists (select 1 from sr_service x where x.id = t.service_id)) and
 exists (select 1 from pci_patient x where x.id = t.patient_id) and
 exists (select 1 from md_clinic x where x.id = t.clinic_id) and
 (exists (select 1 from mc_step x where x.id = t.step_id) or t.step_id is null) and
 (exists (select 1 from md_diagnosis x where x.id = t.mkb_id) or t.mkb_id is null);

insert into sr_srv_rendered(id, bdate, service_id, customer_id, quantity, org_id, is_rendered, res_group_id, cul, funding_id,comment, is_refused, tooth_number)
select s.new_id,
CASE when s.bdate is null then v.admission_date else s.bdate end,
 s.service_id, s.patient_id, s.quantity, 
COALESCE(s.org_id,s.clinic_id),
 true,
       case when  coalesce(s.res_group_id, s.doctor_id) is not null then typing_gen_res_group(s.doctor_id, s.res_group_id)
else v.res_group_id end,
     s.cul, s.funding_id, s._note, 
CASE when (s.is_refused is null) then false else s.is_refused end,
    s.tooth_number
  from "typing_services" s left JOIN "typing_visits"  v ON v.step_num =s.step_num  where s.new_id is not null and s.service_id is not null
  and (exists (select 1 from sr_service x where x.id = s.service_id and x.org_id = s.org_id)
   or exists (select 1 from sr_service x where x.id = s.service_id and x.org_id = s.clinic_id))

;


insert into md_srv_rendered(id, step_id, case_id, diagnosis_id)
select s.new_id, 
CASE when (s.org_id is null or s.org_id = s.clinic_id) then s.step_id end,
CASE when (s.org_id is null or s.org_id = s.clinic_id) then s.case_id end,
CASE when (s.org_id is null or s.org_id = s.clinic_id) then s.mkb_id end
from "typing_services" s where s.new_id is not null
and exists(SELECT 1 FROM mc_case x WHERE  x.id = s.case_id)
  and (exists (select 1 from sr_service x where x.id = s.service_id and x.org_id = s.org_id)
   or exists (select 1 from sr_service x where x.id = s.service_id and x.org_id = s.clinic_id))

;

SELECT typing_insert_into_disp();

update "typing_services" s set id = new_id where new_id is not null and s.service_id is not null;

-- 4.6 Добавляю все ошибки услуг
update "typing_services" t set errors = concat(errors, ''{"level":"srv", "message":"не найден funding_id = '', funding_id, ''", "column_name":"funding_id"}'')
 where t.funding_id is not null and not exists (select 1 from fin_funding_source_type x where x.id = t.funding_id);
update "typing_services" t set errors = concat(errors, ''{"level":"srv", "message":"не найден res_group_id = '', res_group_id, ''", "column_name":"res_group_id"}'')
 where t.res_group_id is not null and not exists (select 1 from sr_res_group x where x.id = t.res_group_id);
--update "typing_services" t set errors = concat(errors, ''{"level":"srv", "message":"не найден service_id = '', service_id, ''", "column_name":"service_id"}'')
-- where not exists (select 1 from sr_service x where x.id = t.service_id);
update "typing_services" t set errors = concat(errors, ''{"level":"srv", "message":"не найден step_id = '', step_id, ''", "column_name":"step_id"}'')
 where t.step_id is not null and not exists (select 1 from mc_step x where x.id = t.step_id);
--update "typing_services" t set errors = concat(errors, ''{"level":"srv", "message":"не найден mkb_id = '', mkb_id, ''", "column_name":"mkb_id"}'')
-- where t.mkb_id is not null and not exists (select 1 from md_diagnosis x where x.id = t.mkb_id);
update "typing_services" t set errors = concat(errors, ''{"level":"srv", "message":"Услуга «'', (select name from sr_service s where s.id = t.service_id limit 1) ,''»  с id='', service_id, '' не оказывается в данной МО", "column_name":"service_id"}'')
 where not exists (select 1 from sr_service x where x.id = t.service_id and x.org_id =t.org_id)
and not exists (select 1 from sr_service x where x.id = t.service_id and x.org_id =t.clinic_id)
and t.service_id is not null;
update "typing_services" t set  errors = concat(t.errors, ''{"level":"srv", "message": МО сотрудника и МО случая не совпадают"  '', doctor_id, ''", "column_name":"doctor_id"}'')
where not exists (select 1 
	 from pim_employee_position_resource epr
     join pim_employee_position ep on epr.employee_position_id = ep.id
     join pim_employee e on ep.employee_id = e.id
	 WHERE epr.id = t.doctor_id
	 and e.organization_id = t.clinic_id)
and t.doctor_id is not null;


 ;



-- 5. Диагнозы-----------------------------------------------------------------------------------------------------------------------------
-- 5.1 Добавляю реальные колонки
alter table "typing_diagnos"
 add column id integer,
 add column mkb_id integer,
 add column disease_type_id integer,
 add column is_main boolean,
 add column stage_id integer,
 add column step_id integer,
 add column disp_id integer,
 add column nosol_registr_id integer,
 add column dispensary_group_id integer,
 add column reg_in_dt date,
 add column reg_out_dt date,
 add column reg_in_doctor_id integer,
 add column reg_out_doctor_id integer,
 add column reg_stage_id integer,
 add column reg_out_reason_id integer,
 add column case_id integer,
 add column patient_id integer,
 add column clinic_id integer,
 add column type_id integer,
 add column new_id integer,
 add column errors text default ''''
;

-- 5.2 Заполняю реальные колонки
update "typing_diagnos" set
 id = to_int(_id),
 mkb_id = to_int(_mkb_id),
 disease_type_id = to_int(_disease_type_id),
 is_main = case when _is_main = ''true'' or _is_main = ''1'' then true else false end,
 stage_id = to_int(_stage_id),
 disp_id = to_int(_disp_id),
 nosol_registr_id = to_int(_nosol_registr_id),
 dispensary_group_id = to_int(_dispensary_group_id),
 reg_in_dt = to_dt(_reg_in_dt),
 reg_out_dt = to_dt(_reg_out_dt),
 reg_in_doctor_id = to_int(_reg_in_doctor_id),
 reg_out_doctor_id = to_int(_reg_out_doctor_id),
 reg_stage_id = to_int(_reg_stage_id),
 reg_out_reason_id = to_int(_reg_out_reason_id),
 type_id = to_int(_type_id)
;


update "typing_diagnos" d set
 case_id = coalesce(v.id, v.new_id),
 patient_id = v.patient_id, 
 clinic_id = v.clinic_id
from "typing_case" v
;

update "typing_diagnos" d set
 step_id = v.id
from "typing_visits" v where v.step_num = d.step_num
;


-- 5.3 Обновляю диагнозы, если есть id
update mc_diagnosis d set
 diagnos_id = t.mkb_id,
 disease_type_id = t.disease_type_id,
 is_main = t.is_main,
 case_id = t.case_id,
 step_id = t.step_id,
 patient_id = t.patient_id,
 stage_id = t.stage_id,
 type_id = t.type_id

from "typing_diagnos" t
 where d.id = t.id and
  exists (select 1 from pci_patient x where x.id = t.patient_id) and
  exists (select 1 from md_clinic x where x.id = t.clinic_id) and
  exists (select 1 from mc_case c where c.id = t.case_id) and
  exists (select 1 from md_diagnosis x where x.id = t.mkb_id) and
  (exists (select 1 from mc_disease_type x where x.id = t.disease_type_id) or t.disease_type_id is null) and
  (exists (select 1 from mc_stage x where x.id = t.stage_id) or t.stage_id is null) and
  (exists (select 1 from mc_diagnosis_type x where x.id = t.type_id) or t.type_id is null)
;

-- 5.4 Добавляю ошибку (отсутствует id диагноза)
update "typing_diagnos" t set errors = concat(errors, ''{"level":"dgn", "message":"не найден диагноз по id = '', id, ''", "column_name":"id"}'')
 where id is not null and not exists (select 1 from mc_diagnosis x where x.id = t.id);

-- 5.5 добавляю диагнозы, если нет id

update "typing_diagnos" t set new_id = nextval(''mc_diagnosis_seq'')
 where id is null and
  exists (select 1 from pci_patient x where x.id = t.patient_id) and
  exists (select 1 from md_clinic x where x.id = t.clinic_id) and
  exists (select 1 from mc_case c where c.id = t.case_id) and
  exists (select 1 from md_diagnosis x where x.id = t.mkb_id) and
  (exists (select 1 from mc_disease_type x where x.id = t.disease_type_id) or t.disease_type_id is null) and
  (exists (select 1 from mc_stage x where x.id = t.stage_id) or t.stage_id is null) and
  (exists (select 1 from mc_diagnosis_type x where x.id = t.type_id) or t.type_id is null);

update  "typing_diagnos" t
set stage_id =4
WHERE step_id =(select max(step_id) FROM "typing_diagnos" t)
and not exists(select 1 FROM "typing_diagnos"  WHERE stage_id =4);

insert into mc_diagnosis(id, diagnos_id, disease_type_id, case_id, patient_id, stage_id, step_id, type_id, is_main,establishment_date)
 select d.new_id, d.mkb_id, d.disease_type_id, d.case_id, d.patient_id, d.stage_id, d.step_id, d.type_id, CASE when(select count(new_id)>1 FROM "typing_diagnos" WHERE is_main = true) then false else d.is_main end, admission_date from "typing_diagnos" d LEFT JOIN "typing_visits" v ON d.step_id=v.id  where d.new_id is not null
and (exists(SELECT 1 FROM mc_step x WHERE x.id =d.step_id))
;

update mc_diagnosis d
set is_main = true
FROM (SELECT max(new_id) as id FROM typing_diagnos WHERE (select count(new_id)>1 FROM "typing_diagnos" WHERE is_main = true) 
group by step_num) x
WHERE x.id = d.id
;

update "typing_diagnos" set id = new_id where new_id is not null;


update md_srv_rendered msr
set diagnosis_id = CASE when msr.diagnosis_id is null then d.mkb_id else msr.diagnosis_id end,
step_id = v.id
from "typing_services" s JOIN "typing_visits" v ON v.step_num=s.step_num  JOIN "typing_diagnos" d ON d.step_id = v.id  where s.new_id is not null and msr.id =s.new_id
and (s.org_id is null or s.org_id = s.clinic_id)
and d.mkb_id <> -1
;




-- 5.6 добавляю все ошибки диагнозов
update "typing_diagnos" t set errors = concat(errors, ''{"level":"dgn", "message":"не найден mkb_id = '', _mkb_id, ''", "column_name":"mkb_id"}'')
WHERE mkb_id =-1;
update "typing_diagnos" t set errors = concat(errors, ''{"level":"dgn", "message":"не найден disease_type_id = '', disease_type_id, ''", "column_name":"disease_type_id"}'')
 where t.disease_type_id is not null and not exists (select 1 from mc_disease_type x where x.id = t.disease_type_id);
update "typing_diagnos" t set errors = concat(errors, ''{"level":"dgn", "message":"не найден stage_id = '', stage_id, ''", "column_name":"stage_id"}'')
 where t.stage_id is not null and not exists (select 1 from mc_stage x where x.id = t.stage_id);
update "typing_diagnos" t set errors = concat(errors, ''{"level":"dgn", "message":"не найден type_id = '', type_id, ''", "column_name":"type_id"}'')
 where t.type_id is not null and not exists (select 1 from mc_diagnosis_type x where x.id = t.type_id);

-- 6. Больничный----------------------------------------------------------------------------
-- 6.1 Обновление больничного
update md_sicklist sl set disability_reason_id = c.disability_reason_id, disability_from_dt = c.disability_from_dt, disability_to_dt = c.disability_to_dt, code = c.sl_code, clinic_id = c.clinic_id, patient_id = c.patient_id
 from "typing_case" c
  where c.sicklist_id = sl.id and (c.disability_reason_id is null or exists(select 1 from md_sl_disability_reason x where x.id = c.disability_reason_id));

-- 6.2 Добавляю ошибку (не найден id больничного)
update "typing_case" t set errors = concat(errors, ''{"level":"sl", "message":"не найден sicklist_id = '', sicklist_id, ''", "column_name":"sicklist_id"}'')
 where t.sicklist_id is not null and not exists (select 1 from md_sicklist x where x.id = t.sicklist_id);

-- 6.3 Добавляю больничный
alter table "typing_case" add column new_sl_id integer;

update "typing_case" c set new_sl_id = nextval(''md_sicklist_seq'')
 where sl_code is not null and sl_code != '''' and (c.disability_reason_id is null or exists(select 1 from md_sl_disability_reason x where x.id = c.disability_reason_id));

update "typing_case" c
set sl_surname= i.surname,
sl_name = i.name,
sl_patr_name = i.patr_name
FROM pim_individual i WHERE i.id =c.patient_id
and (sl_surname is null
or sl_name is null
or sl_patr_name is null or
sl_surname = ''''
or sl_name =''''
or sl_patr_name =''''
)
; 

insert into md_sicklist(id, disability_from_dt, disability_to_dt, code, disability_reason_id, clinic_id, patient_id, type_id,workplace_type_id,issue_dt,workplace_print,ready_to_work_dt,final_diagnosis_id,state_id,name,surname,patr_name,case_id)

select new_sl_id,
disability_from_dt,
disability_to_dt,
sl_code,
disability_reason_id,
clinic_id,
patient_id,
1,
1,
disability_from_dt,
workplace_print,
ready_to_work_dt,
x.id,
CASE when md_sicklist_state is null then 3 else md_sicklist_state end,
sl_name,
sl_surname,
sl_patr_name,
new_id
from "typing_case" c  cross join(select md.id from "typing_diagnos" x
Join mc_diagnosis mc on mc.id = x.id  
join md_diagnosis md on md.id = mc.diagnos_id  
join mc_stage s on s.id = mc.stage_id and mc.is_main
order by stage_order desc, id
limit 1) x
where new_sl_id is not null;



insert into md_sicklist_period
SELECT nextval(''md_sicklist_period__seq''),
disability_from_dt,
disability_to_dt,
employee_position_id,
new_sl_id,
null
from "typing_case" c
where new_sl_id is not null
and exists(select 1 FROM pim_employee_position p WHERE p.id =c.employee_position_id)
and employee_position_id is not null
;




update "typing_case" set sicklist_id = new_sl_id where new_sl_id is not null;

-- 6.4 Добавляю ошибки больничного
update "typing_case" t set errors = concat(errors, ''{"level":"sl", "message":"не найден disability_reason_id = '', disability_reason_id, ''", "column_name":"disability_reason_id"}'')
 where t.disability_reason_id is not null and not exists (select 1 from md_sl_disability_reason x where x.id = t.disability_reason_id);
update "typing_case" t set errors = concat(errors, ''{"level":"sl", "message":"не указан номер больничного", "column_name":"sl_code"}'')
 where (sl_code is null or sl_code = '''') and t.disability_reason_id is not null; --disability_reason_id - это признак того, что больничный заполнен
  update "typing_case" t set errors = concat(errors, ''{"level":"sl", "message":"не найден employee_position_id = '', employee_position_id, ''", "column_name":"employee_position_id"}'')
 where t.employee_position_id is not null and not exists (select 1 from pim_employee_position x where x.id = t.employee_position_id );
 update "typing_case" t set errors = concat(errors, ''{"level":"sl", "message":"не указан employee_position_id", "column_name":"employee_position_id"}'')
 where (employee_position_id is null) and t.disability_reason_id is not null;

 


-- 7. Направления----------------------------------------------------------------------------
-- 7.1 Обновляю направления
update md_referral r set ref_organization_id = c.ref_organization_id, ref_doctor_id = c.ref_doctor_id, diagnosis_id = c.ref_mkb_id, referral_date = c.referral_date,
 recv_organization_id = c.recv_organization_id, referral_type_id = c.referral_type_id
from "typing_case" c where c.referral_id = r.id and c.referral_date is not null and
 (exists(select 1 from pim_organization o where o.id = c.ref_organization_id)) and
 (c.recv_organization_id is null or exists(select 1 from pim_organization o where o.id = c.recv_organization_id)) and
 (c.ref_doctor_id is null or exists(select 1 from md_employee_position x where x.id = c.ref_doctor_id)) and
 (c.ref_mkb_id is null or exists(select 1 from md_diagnosis x where x.id = c.ref_mkb_id)) and
 (c.referral_type_id is null or exists(select 1 from md_referral_type x where x.id = c.referral_type_id)) and
  exists (select 1 from pci_patient x where x.id = c.patient_id) and
  exists (select 1 from md_clinic x where x.id = c.clinic_id)
 -- exists (select 1 from mc_case x where x.id = c.id)
;
-- 7.2 Добавляю ошибку (не найден id направления в бд)
update "typing_case" t set errors = concat(errors, ''{"level":"rfl", "message":"не найден referral_id = '', referral_id, ''", "column_name":"referral_id"}'')
 where t.referral_id is not null and not exists (select 1 from md_referral x where x.id = t.referral_id);

-- 7.3 Добавляю направление
alter table "typing_case" add column new_ref_id integer;

update "typing_case" c set new_ref_id = nextval(''md_referral_seq'')
where c.referral_id is null and
 c.referral_date is not null and
 (exists(select 1 from pim_organization o where o.id = c.ref_organization_id)) and
 (c.recv_organization_id is null or exists(select 1 from pim_organization o where o.id = c.recv_organization_id)) and
 (c.ref_doctor_id is null or exists(select 1 from md_employee_position x where x.id = c.ref_doctor_id)) and
 (c.ref_mkb_id is null or exists(select 1 from md_diagnosis x where x.id = c.ref_mkb_id)) and
 (c.referral_type_id is null or exists(select 1 from md_referral_type x where x.id = c.referral_type_id)) and
  exists (select 1 from pci_patient x where x.id = c.patient_id) and
  exists (select 1 from md_clinic x where x.id = c.clinic_id) and
  exists (select 1 from mc_case x where x.id = c.id)
;
insert into md_referral(id, ref_organization_id, ref_doctor_id, diagnosis_id, referral_date, recv_organization_id, referral_type_id,patient_id,step_id)
select new_ref_id, ref_organization_id, ref_doctor_id, ref_mkb_id, referral_date, recv_organization_id, referral_type_id,c.patient_id, v.new_id from "typing_case" c cross join typing_visits v
 where new_ref_id is not null
 and v.step_num = ''1'' ;

--update "typing_case" set id = new_ref_id where new_ref_id is not null;

-- 7.4 Добавляю ошибки направления
update "typing_case" t set errors = concat(errors, ''{"level":"rfl", "message":"не найден ref_organization_id = '', ref_organization_id, ''", "column_name":"ref_organization_id"}'')
 where t.referral_date is not null and (t.ref_organization_id is not null and not exists(select 1 from pim_organization o where o.id = t.ref_organization_id));
update "typing_case" t set errors = concat(errors, ''{"level":"rfl", "message":"не найден recv_organization_id = '', recv_organization_id, ''", "column_name":"recv_organization_id"}'')
 where t.referral_date is not null and (t.recv_organization_id is not null and not exists(select 1 from pim_organization o where o.id = t.recv_organization_id));
update "typing_case" t set errors = concat(errors, ''{"level":"rfl", "message":"не найден ref_doctor_id = '', ref_doctor_id, ''", "column_name":"ref_doctor_id"}'')
 where t.referral_date is not null and (t.ref_doctor_id is not null and not exists(select 1 from md_employee_position o where o.id = t.ref_doctor_id));
update "typing_case" t set errors = concat(errors, ''{"level":"rfl", "message":"не найден ref_mkb_id = '', ref_mkb_id, ''", "column_name":"ref_mkb_id"}'')
 where t.referral_date is not null and (t.ref_mkb_id is not null and not exists(select 1 from md_diagnosis o where o.id = t.ref_mkb_id));
update "typing_case" t set errors = concat(errors, ''{"level":"rfl", "message":"не найден referral_type_id = '', referral_type_id, ''", "column_name":"referral_type_id"}'')
 where t.referral_date is not null and (t.referral_type_id is not null and not exists(select 1 from md_referral_type o where o.id = t.referral_type_id));
update "typing_case" t set errors = concat(errors, ''{"level":"rfl", "message":"не заполнено referral_date", "column_name":"referral_date"}'')
 where t.referral_date is null and coalesce(ref_organization_id, referral_id, recv_organization_id, ref_doctor_id, ref_mkb_id, referral_type_id) is not null;


-- 8. Д-учет----------------------------------------------------------------------------------------------
-- 8.1 Обновляю Д-учет
update pci_dispensary disp set
 med_case_in_id = case when d.disp_in_out = ''in'' then case_id end,
 med_case_out_id = case when d.disp_in_out = ''out'' then case_id end,
 reg_in_dt = d.reg_in_dt,
 reg_out_dt = d.reg_out_dt,
 reg_in_doctor_id = d.reg_in_doctor_id,
 reg_out_doctor_id = d.reg_out_doctor_id,
 patient_id = d.patient_id,
 reg_out_reason_id = d.reg_out_reason_id,
 reg_stage_id = d.reg_stage_id,
 clinic_id = d.clinic_id,
 diagnosis_id = d.mkb_id,
 dispensary_group_id = d.dispensary_group_id,
 nosol_registr_id = d.nosol_registr_id
from "typing_diagnos" d
where d.disp_id = disp.id and d.reg_in_dt is not null and
 exists(select 1 from md_diagnosis x where d.mkb_id = x.id) and
 exists(select 1 from md_employee_position x where d.reg_in_doctor_id = x.id) and
 exists(select 1 from md_nosol_registr x where d.nosol_registr_id = x.id) and
 exists(select 1 from md_reg_stage x where d.reg_stage_id = x.id) and
 exists(select 1 from mc_case x where d.case_id = x.id) and
 exists(select 1 from pci_patient x where d.patient_id = x.id) and
 exists(select 1 from md_clinic x where d.clinic_id = x.id) and
 exists(select 1 from md_reg_stage x where d.reg_stage_id = x.id) and
 (d.reg_out_doctor_id is null or exists(select 1 from md_employee_position x where x.id = d.reg_out_doctor_id)) and
 (d.reg_out_reason_id is null or exists(select 1 from pci_unreg_reason x where x.id = d.reg_out_reason_id)) and
 (d.dispensary_group_id is null or exists(select 1 from md_dispensary_group x where x.id = d.dispensary_group_id)) and
 d.disp_in_out in (''in'', ''out'')
;

-- 8.2 Добавляю ошибку (не найден id д-учета)
update "typing_diagnos" t set errors = concat(errors, ''{"level":"disp", "message":"не найден disp_id = '', disp_id, ''", "column_name":"disp_id"}'')
 where t.disp_id is not null and not exists (select 1 from pci_dispensary x where x.id = t.disp_id);


-- 8.3 Добавляю Д-учет
alter table "typing_diagnos" add column new_disp_id integer;
update "typing_diagnos" d set new_disp_id = nextval(''pci_dispensary_seq'')
where d.disp_id is null and d.reg_in_dt is not null and
 exists(select 1 from md_diagnosis x where d.mkb_id = x.id) and
 exists(select 1 from md_employee_position x where d.reg_in_doctor_id = x.id) and
 exists(select 1 from md_nosol_registr x where d.nosol_registr_id = x.id) and
 exists(select 1 from md_reg_stage x where d.reg_stage_id = x.id) and
 exists(select 1 from mc_case x where d.case_id = x.id) and
 exists(select 1 from pci_patient x where d.patient_id = x.id) and
 exists(select 1 from md_clinic x where d.clinic_id = x.id) and
 exists(select 1 from md_reg_stage x where d.reg_stage_id = x.id) and
 (d.reg_out_doctor_id is null or exists(select 1 from md_employee_position x where x.id = d.reg_out_doctor_id)) and
 (d.reg_out_reason_id is null or exists(select 1 from pci_unreg_reason x where x.id = d.reg_out_reason_id)) and
 (d.dispensary_group_id is null or exists(select 1 from md_dispensary_group x where x.id = d.dispensary_group_id)) and
 d.disp_in_out in (''in'', ''out'')
;

insert into pci_dispensary(id, med_case_in_id, med_case_out_id, reg_in_dt, reg_out_dt, reg_in_doctor_id, reg_out_doctor_id, patient_id, reg_out_reason_id, reg_stage_id, clinic_id, diagnosis_id,
 dispensary_group_id, nosol_registr_id)
select
 new_disp_id,
 case when disp_in_out = ''in'' then case_id end,
 case when disp_in_out = ''out'' then case_id end,
 reg_in_dt,
 reg_out_dt,
 reg_in_doctor_id,
 reg_out_doctor_id,
 patient_id,
 reg_out_reason_id,
 reg_stage_id,
 clinic_id,
 mkb_id,
 dispensary_group_id,
 nosol_registr_id
from "typing_diagnos"
where new_disp_id is not null
;

update "typing_diagnos" set disp_id = new_disp_id where new_disp_id is not null;

-- 8.4 добавляю все ошибки д-учета
update "typing_diagnos" t set errors = concat(errors, ''{"level":"disp", "message":"не заполнен reg_in_dt", "column_name":"reg_in_dt"}'')
 where t.reg_in_dt is null and coalesce(reg_in_doctor_id, disp_id, reg_in_doctor_id, nosol_registr_id) is not null;
update "typing_diagnos" t set errors = concat(errors, ''{"level":"disp", "message":"не найден reg_in_doctor_id = '', reg_in_doctor_id, ''", "column_name":"reg_in_doctor_id"}'')
 where not exists(select 1 from md_employee_position x where t.reg_in_doctor_id = x.id) and coalesce(reg_in_doctor_id, disp_id, reg_in_doctor_id, nosol_registr_id) is not null;
update "typing_diagnos" t set errors = concat(errors, ''{"level":"disp", "message":"не найден nosol_registr_id = '', nosol_registr_id, ''", "column_name":"nosol_registr_id"}'')
 where not exists(select 1 from md_nosol_registr x where t.nosol_registr_id = x.id) and coalesce(reg_in_doctor_id, disp_id, reg_in_doctor_id, nosol_registr_id) is not null;
update "typing_diagnos" t set errors = concat(errors, ''{"level":"disp", "message":"не найден reg_out_doctor_id = '', reg_out_doctor_id, ''", "column_name":"reg_out_doctor_id"}'')
 where t.reg_out_doctor_id is not null and not exists(select 1 from md_employee_position x where t.reg_out_doctor_id = x.id);
update "typing_diagnos" t set errors = concat(errors, ''{"level":"disp", "message":"не найден reg_out_reason_id = '', reg_out_reason_id, ''", "column_name":"reg_out_reason_id"}'')
 where t.reg_out_reason_id is not null and not exists(select 1 from pci_unreg_reason x where t.reg_out_reason_id = x.id);
update "typing_diagnos" t set errors = concat(errors, ''{"level":"disp", "message":"не найден dispensary_group_id = '', dispensary_group_id, ''", "column_name":"dispensary_group_id"}'')
 where t.dispensary_group_id is not null and not exists(select 1 from md_dispensary_group x where t.dispensary_group_id = x.id);


-- 9. Устанавливаю основной диагноз

with t as (
 select md.case_id, md.id from "typing_diagnos" x
 join mc_diagnosis md on md.id = x.id
 join mc_stage s on s.id = md.stage_id and md.is_main
 order by stage_order desc
limit 1
)
update mc_case c 
 set main_diagnos_id = t.id
from t where t.case_id = c.id;

create temp table "typing_tmp"  ON COMMIT DROP AS  
with t as (
 select md.* from "typing_diagnos" x
 join mc_diagnosis md on md.id = x.id
 join mc_stage s on s.id = md.stage_id and md.is_main
 order by stage_order desc
limit 1
)
select nextval(''mc_diagnosis_seq'') new_id, * from t where stage_id < 4;

insert into mc_diagnosis(id, diagnos_id, disease_type_id, case_id, patient_id, stage_id, step_id, type_id, establishment_date, is_main)
 select nextval(''mc_diagnosis_seq''), s.mkb_id, s.diag_disease_type_id, s.case_id, s.patient_id, s.diag_stage_id, v.new_id, s.diag_type_id, s.bdate,false from "typing_services" s JOIN "typing_visits" v ON s.step_num=v.step_num  where s.new_id is  not  null and s.mkb_id not in(SELECT d.mkb_id FROM   "typing_diagnos" d  JOIN "typing_visits" v ON d.step_num =v.step_num) and (SELECT count(new_id) FROM "typing_tmp") = 0
and exists (SELECT 1 FROM mc_step x WHERE x.id = v.new_id)
 ;


insert into mc_diagnosis(id, establishment_date, note, diagnos_id, disease_type_id, doctor_id, injury_type_id, case_id, patient_id, stage_id, step_id, type_id, is_main, is_suspicion)
select new_id, establishment_date, note, diagnos_id, disease_type_id, doctor_id, injury_type_id, case_id, patient_id, 4, null, type_id, 
is_main, is_suspicion from "typing_tmp" t
WHERE exists(SELECT 1 FROM mc_step x WHERE x.id = t.step_id);





update mc_case c set main_diagnos_id = coalesce(t.new_id, t.id)
from "typing_tmp" t where t.case_id = c.id;


-- 10. Cобираю JSON
update "typing_case" set errors = concat(''"errors":['', replace(errors, ''}{'', ''},{''), '']'');
update "typing_visits" set errors = concat(''"errors":['', replace(errors, ''}{'', ''},{''), '']'');
update "typing_services" set errors = concat(''"errors":['', replace(errors, ''}{'', ''},{''), '']'');
update "typing_diagnos" set errors = concat(''"errors":['', replace(errors, ''}{'', ''},{''), '']'');
update "typing_resources" set errors = concat(''"errors":['', replace(errors, ''}{'', ''},{''), '']'');
update "typing_cur" set errors = concat(''"errors":['', replace(errors, ''}{'', ''},{''), '']'');

-- 11. Закрытие случая, если есть шаг с результатом, устанавливаю state_id = 1

with t as (
 select case_id from "typing_visits" where result_id is not null limit 1
)
update mc_case c set state_id = 1 from t where t.case_id = c.id;

-- 12. Проставляю каждому шагу основной диагноз
with t as (
 select step_id, id from "typing_diagnos"
)
update mc_step st set main_diagnosis_id = t.id from t where t.step_id = st.id;

' using $1;

-- Запуск валидаций, копирую таблицу с валидациями
execute'
 create temp table "typing_validate" ON COMMIT DROP AS  select *
 from typing_validate( (select id from "typing_case"), $1 ) as tabl1(rb boolean, vld text, msg text, clmn_name text )
' using $2;


 for rec in execute('
 select bool_or(rb) rb
 from "typing_validate"
')
loop
 rb = rec.rb;
end loop;





for rec in execute('
with t as
(
select 
 concat(''{"id":"'',coalesce(new_id::text, _id),
  ''","patient_id":"'',_patient_id,''","clinic_id":"'',_clinic_id,''","uid":"'',uid,''","care_regimen_id":"'',_care_regimen_id,''","funding_id":"'',_funding_id,
  ''","init_goal_id":"'',_init_goal_id,''","care_level_id":"'',_care_level_id,''","payment_method_id":"'',_payment_method_id,''","admission_reason_id":"'',_admission_reason_id,
  ''","repeat_count_id":"'',_repeat_count_id,''","referral_id":"'',coalesce(referral_id::text, new_ref_id::text,_referral_id),
  ''","ref_organization_id":"'',_ref_organization_id,''","ref_doctor_id":"'',_ref_doctor_id,
  ''","referral_date":"'',_referral_date,''","recv_organization_id":"'',_recv_organization_id,''","ref_mkb_id":"'',_ref_mkb_id,''","order_number":"'',order_number,
  ''","referral_type_id":"'',_referral_type_id,''","sicklist_id":"'',coalesce(new_sl_id::text, sicklist_id::text, _sicklist_id),
  ''","sl_code":"'',sl_code,''","disability_reason_id":"'',_disability_reason_id,
  ''","disability_from_dt":"'',_disability_from_dt,''","disability_to_dt":"'',_disability_to_dt,''",'',errors,
  
  '',"visits":['',
    (
    select
     array_to_string(array_agg(
     concat(''{"id":"'',coalesce(id::text, new_id::text, _id),
     ''","step_num":"'',step_num,''","type_id":"'',_type_id,''","admission_date":"'',_admission_date,''","place_id":"'',_place_id,''","initiator_id":"'',_initiator_id,
     ''","goal_id":"'',_goal_id,''","profile_id":"'',_profile_id,''","standard_id":"'',_standard_id,''","mes_id":"'',_mes_id,''","res_group_id":"'', (select res_group_id from mc_step st where st.id = coalesce(t.id, t.new_id)), ''","result_id":"'',_result_id, ''","stepResultReason_id":"'',_stepResultReason_id, ''","doctor_id":"'',_doctor_id, ''","vmp_method_id":"'',_vmp_method_id,''","vmp_type_id":"'',_vmp_type_id,
     ''","outcome_id":"'',_outcome_id,''","is_viewed":"'',_is_viewed,''","is_needed":"'',_is_needed,''","is_sanitized":"'',_is_sanitized,''",'',errors,''}'')
     ), '','')
    from "typing_visits" t
    ), '']'',

  '',"services":['',
    (
    select
     array_to_string(array_agg(
     concat(''{"id":"'',coalesce(id::text, new_id::text, _id),
     ''","step_num":"'',step_num,''","step_id":"'',_step_id,''","service_id":"'',_service_id,''","bdate":"'',_bdate,''","funding_id":"'',_funding_id,''","doctor_id":"'',_doctor_id,
     ''","quantity":"'',_quantity,''","res_group_id":"'',(select res_group_id from sr_srv_rendered r where r.id = coalesce(t.id, t.new_id)),''","mkb_id":"'',_mkb_id,''",'',errors,''}'')
     ), '','')
    from "typing_services" t
    ), '']'',


  '',"diagnosis":['',
    (
    select
       array_to_string(array_agg(
       concat(''{"id":"'',coalesce(id::text, new_id::text, _id),
       ''","step_num":"'',step_num,''","mkb_id":"'',_mkb_id,''","disease_type_id":"'',_disease_type_id,''","type_id":"'',_type_id,''","is_main":"'',_is_main,
       ''","stage_id":"'',_stage_id,''","step_id":"'',_step_id,
       ''","disp_id":"'',coalesce(disp_id::text, new_disp_id::text, _disp_id),''","disp_in_out":"'',disp_in_out,''","nosol_registr_id":"'',_nosol_registr_id,
       ''","dispensary_group_id":"'',_dispensary_group_id,''","reg_in_dt":"'',_reg_out_dt,''","reg_in_doctor_id":"'',_reg_in_doctor_id,''","reg_out_doctor_id":"'',_reg_out_doctor_id,
       ''","reg_stage_id":"'',_reg_stage_id,''","reg_out_reason_id":"'',_reg_out_reason_id,''",'',errors,''}'')
       ), '','')
    from "typing_diagnos"
    ), '']'',

  '',"validate":['',
    (
    select
       array_to_string(array_agg(
       concat(''{"rb":"'', rb::text, ''" ,"vld":"'', vld, ''","msg":"'', msg, ''","clmn_name":"'', clmn_name, ''" }'')
       ), '','')
    from "typing_validate"
    ), '']'',

  '',"resources":['',
    (
    select
       array_to_string(array_agg(
       concat(''{"role_id":"'', role_id::text, ''" ,"step_num":"'', step_num::text, ''","resource_id":"'', resource_id::text, ''","group_id":"'', group_id::text,''","org_id":"'', org_id::text,''", '' ,errors,''}'') 
       ), '','')
    from "typing_resources"
    ), '']'',

'',"cur":['',
    (
    select
       array_to_string(array_agg(
       concat(''{"id":"'', coalesce(id::text, new_id::text, _id), ''" ,"criteria_id":"'', criteria_id ::text, ''","value":"'', value::text,''", '' ,errors,''}'')
       ), '','')
    from "typing_cur"
    ), '']'',
  ''}'') x
from "typing_case"
)

select x::json x from t


')
 loop
  ret = rec.x;
 end loop;

-- Просталяю соц. положение в случай
 execute('
  update mc_case c set soc_group_id = p.social_group_id
  from "typing_case" cc, pci_patient p where cc.id = c.id and c.patient_id = p.id
 ');


if rb then raise exception ''; end if;



if exists (SELECT 1 from typing_services WHERE errors <> '"errors":[]' ) or
exists (SELECT 1 from typing_case WHERE errors <> '"errors":[]' ) or
exists (SELECT 1 from typing_diagnos WHERE errors <> '"errors":[]' ) or
exists (SELECT 1 from typing_resources WHERE errors <> '"errors":[]' ) or
exists (SELECT 1 from typing_visits WHERE errors <> '"errors":[]' ) or
exists (SELECT 1 from typing_cur WHERE errors <> '"errors":[]' ) 
then raise exception ''; end if;



exception when RAISE_EXCEPTION then raise notice '123';
 end; -- trans


 return ret;
end;

$$;

