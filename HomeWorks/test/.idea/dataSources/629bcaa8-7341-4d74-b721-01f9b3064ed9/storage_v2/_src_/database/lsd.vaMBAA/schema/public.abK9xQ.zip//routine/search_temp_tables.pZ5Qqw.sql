CREATE FUNCTION search_temp_tables(kl character varying)
  RETURNS SETOF text
STRICT
LANGUAGE plpgsql
AS $$
declare
        r text;
        _key text[];
        tab record;
    begin
                if trim($1)='' then raise exception 'Введите хотя бы одно ключевое слово'; end if;
                select string_to_array($1, ',') into _key;
        for i in 1..array_length(_key,1) loop
                        for tab in select * from pg_tables where tablename ilike '%'||replace(trim(_key[i]),'_','\_')||'%' and schemaname='public' loop
                                return next 'ALTER TABLE '||tab.schemaname||'.'||tab.tablename||' SET SCHEMA supp;';
                        end loop;
                end loop;
    end;
$$;

