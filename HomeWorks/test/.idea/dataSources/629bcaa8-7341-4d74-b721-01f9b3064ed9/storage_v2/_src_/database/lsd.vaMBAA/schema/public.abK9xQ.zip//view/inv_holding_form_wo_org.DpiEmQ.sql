CREATE VIEW inv_holding_form_wo_org AS
  SELECT h.id,
    h.name_trade,
    cg.name AS commodity_group_name,
    mh.inn_id,
    i.name_rus AS inn_name,
    h.descr,
    h.commodity_group_id,
    f.id AS form_id,
    f.form_full_name,
    COALESCE(f.full_name, (h.name_trade)::character varying) AS full_name,
    f.form_type_id
   FROM ((((inv_holding h
     JOIN inv_commodity_group cg ON ((cg.id = h.commodity_group_id)))
     LEFT JOIN inv_md_holding mh ON ((mh.id = h.id)))
     LEFT JOIN inv_inn i ON ((i.id = mh.inn_id)))
     LEFT JOIN inv_form f ON ((f.holding_id = h.id)));

