CREATE FUNCTION update_pat_addr_date(pat_id integer, from_dt date, type_addr integer[])
  RETURNS integer
LANGUAGE plpgsql
AS $$
DECLARE
                BEGIN
                    UPDATE pim_party_address
                    SET to_date = cast(from_dt - cast('1 day' as interval) as date)
                    WHERE id IN (SELECT ppa.id
                                    FROM pim_party_address ppa
                                    INNER JOIN pim_party_addr_to_addr_type ppatat ON ppa.id = ppatat.party_address_id
                                    WHERE ppa.to_date is null and ppa.from_date < from_dt
                                    and ppa.party_id = pat_id AND ppatat.address_type_id = ANY(type_addr :: int[]));
                    RETURN 1;
                END
$$;

