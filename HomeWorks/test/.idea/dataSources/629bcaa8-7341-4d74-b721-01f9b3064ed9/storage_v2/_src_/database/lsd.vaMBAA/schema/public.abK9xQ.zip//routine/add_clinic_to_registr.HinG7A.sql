CREATE FUNCTION add_clinic_to_registr(nosol_id integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
begin
insert into md_nosol_registr_clinic (nosol_registr_id, clinic_id) select $1, id from md_clinic where id not in (select clinic_id from md_nosol_registr_clinic where nosol_registr_id = $1);
end;
$$;

