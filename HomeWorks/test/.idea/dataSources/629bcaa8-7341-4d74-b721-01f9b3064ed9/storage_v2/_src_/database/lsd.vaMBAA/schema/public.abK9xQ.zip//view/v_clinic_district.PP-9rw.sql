CREATE VIEW v_clinic_district AS
  SELECT d.id,
    d.name,
    s.clinic_id
   FROM (md_clinic_district d
     JOIN md_clinic_separation s ON ((d.separation_id = s.id)));

