CREATE FUNCTION disable_trigger(value boolean, trigger_name text)
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
    table_name VARCHAR;
    action_var VARCHAR;
  BEGIN
    IF (value)
    THEN
      action_var := 'DISABLE';
    ELSE
      action_var := 'ENABLE';
    END IF;
    FOR table_name IN SELECT event_object_schema || '.' || event_object_table
                      FROM information_schema.triggers
                      WHERE information_schema.triggers.trigger_name = $2
                      GROUP BY 1
    LOOP
      EXECUTE format('ALTER TABLE %s %s TRIGGER %s', table_name, action_var, $2);
    END LOOP;

  END;
$$;

