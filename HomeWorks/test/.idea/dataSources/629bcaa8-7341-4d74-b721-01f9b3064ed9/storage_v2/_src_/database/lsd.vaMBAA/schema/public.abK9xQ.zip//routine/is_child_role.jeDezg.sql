CREATE FUNCTION is_child_role(role_id integer, child_role integer)
  RETURNS boolean
LANGUAGE SQL
AS $$
WITH RECURSIVE temp1 (child_id, parent_id, id) AS (
                SELECT d.child_id, d.parent_id, d.id
                    FROM sec_role_relation d WHERE d.parent_id = $1
                union
                select d2.child_id, d2.parent_id, d2.id
                     FROM sec_role_relation d2 INNER JOIN temp1 ON( temp1.child_id= d2.parent_id)      )
                select CASE WHEN (count(child_id)>0) THEN TRUE ELSE FALSE END from temp1 where child_id = $2
$$;

