CREATE FUNCTION mdm__close_unmapped_records(xtable character varying, xid_col_name character varying, xsource_version_id integer, xclose_dt date)
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
  rec record;
  st varchar;
begin
  st = 'select '||xtable||'.' || xid_col_name || '::varchar from ' || xtable || ' where not exists (
    select 1 from mdm_record_mapping rm
	join mdm_record rec on rm.target_record_id = rec.id
	join mdm_refbook_version v on rec.refbook_version_id = v.id
	join mdm_refbook_version v2 on rm.source_refbook_id = v2.id
	join mdm_internal_refbook irb on v2.refbook_id = irb.id

    where irb.table_name = ''' || xtable || ''' and '|| xtable||'.' || xid_col_name || '::varchar = rm.source_record_id and v.id = ' || xsource_version_id || ')';
--  raise notice '%', st;
  for rec in execute st
  loop
    perform mdm_table_record__close(xtable, rec.id, xclose_dt);
--     raise notice '%', rec;
  end loop;
end;
$$;

