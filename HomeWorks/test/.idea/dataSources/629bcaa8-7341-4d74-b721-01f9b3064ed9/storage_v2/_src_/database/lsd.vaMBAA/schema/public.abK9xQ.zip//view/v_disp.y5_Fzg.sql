CREATE VIEW v_disp AS
  SELECT mv_disp.clinic_id,
    mv_disp.age_category_id,
    mv_disp.gender_id,
    mv_disp.social_group_id,
    mv_disp.dispensary_group_id,
    mv_disp.nosol_registr_id,
    mv_disp.disp_diagnosis_id,
    mv_disp.reg_out_reason_id,
    mv_disp.reg_stage_id,
    mv_disp.calendar_date,
    mv_disp.democube_days_id,
    mv_disp.disp_cnt,
    mv_disp.patient_cnt,
    mv_disp.new_disp_cnt,
    mv_disp.new_patient_cnt,
    mv_disp.undisp_cnt,
    mv_disp.undisp_patient_cnt
   FROM mv_disp;

