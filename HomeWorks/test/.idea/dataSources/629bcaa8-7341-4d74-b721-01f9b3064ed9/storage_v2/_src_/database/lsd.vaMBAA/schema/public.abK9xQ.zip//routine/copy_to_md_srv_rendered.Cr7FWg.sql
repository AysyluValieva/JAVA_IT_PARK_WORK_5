CREATE FUNCTION copy_to_md_srv_rendered()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
Declare
   _app_code TEXT;
begin
  /*
    Данный триггер производит изменения(insert или update) в таблице md_srv_rendered
    при совершении тех же операций в таблице sr_srv_rendered. Это необходимо для того,
    чтобы интегрировать в "Ай-Новусовский" N2O модуль "Стоматология", разработанный,
    "РТЛабс". Позже необходимо избавиться от таблицы md_srv_rendered, как таковой,
    т.к. необходисые её поля присутствуют в таблице sr_srv_rendered.
   */
        SELECT current_setting('app.source') INTO _app_code;
 
                            IF (_app_code = 'typing2') THEN
                                RETURN NEW;
                            END IF;


  if (tg_op = 'INSERT') then
      begin
        insert into md_srv_rendered(id,
                                    is_urgent,
                                    is_use_cryogenic,
                                    is_use_endoscopic,
                                    is_use_laser,
                                    anesthesia_type_id,
                                    step_id,
                                    complication_type_id,
                                    diagnosis_id,
                                    case_id,
                                    referral_id,
                                    result_category_id,
                                    patient_prescription_id,
                                    health_group_id,
                                    vmp_type_id,
									vmp_method_id,
                                    anatomic_zone_id,
                                    prescription_id,
									entity_sync_num)
                             values(NEW.id,
                                    NEW.md_is_urgent,
                                    NEW.md_is_use_cryogenic,
                                    NEW.md_is_use_endoscopic,
                                    NEW.md_is_use_laser,
                                    NEW.md_anesthesia_type_id,
                                    NEW.md_step_id,
                                    NEW.md_complication_type_id,
                                    NEW.md_diagnosis_id,
                                    NEW.md_case_id,
                                    NEW.md_referral_id,
                                    NEW.md_result_category_id,
                                    NEW.md_patient_prescription_id,
                                    NEW.md_health_group_id,
                                    NEW.md_vmp_type_id,
									NEW.md_vmp_method_id,
                                    NEW.md_anatomic_zone_id,
                                    NEW.md_prescription_id,
									NEW.entity_sync_num);
        exception
             when others
             then raise notice 'Record with id = % already exists in table md_srv_rendered!', NEW.id;
      end;
  elseif (tg_op = 'UPDATE') then
	if not exists (select id from md_srv_rendered where id = NEW.id) then
		begin
        insert into md_srv_rendered(id,
                                    is_urgent,
                                    is_use_cryogenic,
                                    is_use_endoscopic,
                                    is_use_laser,
                                    anesthesia_type_id,
                                    step_id,
                                    complication_type_id,
                                    diagnosis_id,
                                    case_id,
                                    referral_id,
                                    result_category_id,
                                    patient_prescription_id,
                                    health_group_id,
                                    vmp_type_id,
									vmp_method_id,
                                    anatomic_zone_id,
                                    prescription_id,
									entity_sync_num)
                             values(NEW.id,
                                    NEW.md_is_urgent,
                                    NEW.md_is_use_cryogenic,
                                    NEW.md_is_use_endoscopic,
                                    NEW.md_is_use_laser,
                                    NEW.md_anesthesia_type_id,
                                    NEW.md_step_id,
                                    NEW.md_complication_type_id,
                                    NEW.md_diagnosis_id,
                                    NEW.md_case_id,
                                    NEW.md_referral_id,
                                    NEW.md_result_category_id,
                                    NEW.md_patient_prescription_id,
                                    NEW.md_health_group_id,
                                    NEW.md_vmp_type_id,
									NEW.md_vmp_method_id,
                                    NEW.md_anatomic_zone_id,
                                    NEW.md_prescription_id,
									NEW.entity_sync_num);
        exception
             when others
             then raise notice 'Record with id = % already exists in table md_srv_rendered!', NEW.id;
      end;
	else
      begin
        update md_srv_rendered
           set is_urgent = NEW.md_is_urgent,
               is_use_cryogenic = NEW.md_is_use_cryogenic,
               is_use_endoscopic = NEW.md_is_use_endoscopic,
               is_use_laser = NEW.md_is_use_laser,
               anesthesia_type_id = NEW.md_anesthesia_type_id,
               step_id = NEW.md_step_id,
               complication_type_id = NEW.md_complication_type_id,
               diagnosis_id = NEW.md_diagnosis_id,
               case_id = NEW.md_case_id,
               referral_id = NEW.md_referral_id,
               result_category_id = NEW.md_result_category_id,
               patient_prescription_id = NEW.md_patient_prescription_id,
               health_group_id = NEW.md_health_group_id,
               vmp_type_id = NEW.md_vmp_type_id,
			   vmp_method_id = NEW.md_vmp_method_id,
               anatomic_zone_id = NEW.md_anatomic_zone_id,
               prescription_id = NEW.md_prescription_id,
			   entity_sync_num = NEW.entity_sync_num
        where id = NEW.id;
      exception
      when others
      then raise notice 'Error on update md_srv_rendered record with id = % !', NEW.id;
      end;
	 end if;
  end if;
  return null;
end;
$$;

