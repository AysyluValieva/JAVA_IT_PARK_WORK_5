CREATE FUNCTION pglogical_assign_repset()
  RETURNS event_trigger
LANGUAGE plpgsql
AS $$
DECLARE obj record;
BEGIN
    IF (
      (SELECT EXISTS(SELECT 1
                     FROM information_schema.schemata
                     WHERE schema_name = 'pglogical'))
    )
    THEN
      IF (SELECT EXISTS(SELECT 1
                        FROM pglogical.replication_set
                        WHERE set_name = 'audit_set'))
      THEN
        FOR obj IN SELECT * FROM pg_event_trigger_ddl_commands()
        LOOP
            IF obj.object_type = 'table' THEN
                IF obj.schema_name = 'audit' THEN
                    PERFORM pglogical.replication_set_add_table('audit_set', obj.objid);
                END IF;
            END IF;
        END LOOP;
      END IF;
    END IF;
END;
$$;

