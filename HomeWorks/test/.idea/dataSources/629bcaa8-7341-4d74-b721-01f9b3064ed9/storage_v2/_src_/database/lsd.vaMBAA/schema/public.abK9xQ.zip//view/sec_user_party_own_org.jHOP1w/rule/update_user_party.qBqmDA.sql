CREATE RULE update_user_party AS
    ON UPDATE TO sec_user_party_own_org DO INSTEAD NOTHING;

