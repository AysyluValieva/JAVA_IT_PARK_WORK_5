CREATE FUNCTION sr_srv_rendered_sync_mdsr_tg_tf()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE
  syncRequired boolean := false;
  noChanges boolean;
BEGIN
if coalesce(NEW.entity_type, -1) not in (0, 1) then
  raise exception 'Illegal state: entity_type must be equal in (0, 1)';
end if;

if TG_OP='INSERT' then
  if NEW.entity_type_aware then
    syncRequired := true;--discriminator is not null: sync md table
  end if;
  --discriminator is null: nothing to do
end if;
if TG_OP='UPDATE' then
  if (NEW.entity_type = 0 and OLD.entity_type = 1) then
    raise exception 'Illegal state: can not change entity_type 1 to 0';
  end if;

  if coalesce(NEW.entity_sync_num, -1) = coalesce(OLD.entity_sync_num, -1) then--is not caused by sync trigger
    noChanges := (OLD.md_is_urgent = NEW.md_is_urgent or OLD.md_is_urgent is null and NEW.md_is_urgent is null)
AND (OLD.md_is_use_cryogenic = NEW.md_is_use_cryogenic or OLD.md_is_use_cryogenic is null and NEW.md_is_use_cryogenic is null)
AND (OLD.md_is_use_endoscopic = NEW.md_is_use_endoscopic or OLD.md_is_use_endoscopic is null and NEW.md_is_use_endoscopic is null)
AND (OLD.md_is_use_laser = NEW.md_is_use_laser or OLD.md_is_use_laser is null and NEW.md_is_use_laser is null)
AND (OLD.md_anesthesia_type_id = NEW.md_anesthesia_type_id or OLD.md_anesthesia_type_id is null and NEW.md_anesthesia_type_id is null)
AND (OLD.md_step_id = NEW.md_step_id or OLD.md_step_id is null and NEW.md_step_id is null)
AND (OLD.md_complication_type_id = NEW.md_complication_type_id or OLD.md_complication_type_id is null and NEW.md_complication_type_id is null)
AND (OLD.md_diagnosis_id = NEW.md_diagnosis_id or OLD.md_diagnosis_id is null and NEW.md_diagnosis_id is null)
AND (OLD.md_case_id = NEW.md_case_id or OLD.md_case_id is null and NEW.md_case_id is null)
AND (OLD.md_referral_id = NEW.md_referral_id or OLD.md_referral_id is null and NEW.md_referral_id is null)
AND (OLD.md_result_category_id = NEW.md_result_category_id or OLD.md_result_category_id is null and NEW.md_result_category_id is null)
AND (OLD.md_patient_prescription_id = NEW.md_patient_prescription_id or OLD.md_patient_prescription_id is null and NEW.md_patient_prescription_id is null)
AND (OLD.md_health_group_id = NEW.md_health_group_id or OLD.md_health_group_id is null and NEW.md_health_group_id is null)
AND (OLD.md_vmp_type_id = NEW.md_vmp_type_id or OLD.md_vmp_type_id is null and NEW.md_vmp_type_id is null)
AND (OLD.md_vmp_method_id = NEW.md_vmp_method_id or OLD.md_vmp_method_id is null and NEW.md_vmp_method_id is null)
AND (OLD.md_anatomic_zone_id = NEW.md_anatomic_zone_id or OLD.md_anatomic_zone_id is null and NEW.md_anatomic_zone_id is null)
AND (OLD.md_prescription_id = NEW.md_prescription_id or OLD.md_prescription_id is null and NEW.md_prescription_id is null);
    noChanges := coalesce(noChanges, false);
    syncRequired := not noChanges;
  end if;
  --caused by sync trigger: interrupt recursion
end if;

if syncRequired then
  if TG_OP='INSERT' then

insert into md_srv_rendered (
entity_sync_num,
id,
is_urgent,
is_use_cryogenic,
is_use_endoscopic,
is_use_laser,
anesthesia_type_id,
step_id,
complication_type_id,
diagnosis_id,
case_id,
referral_id,
result_category_id,
patient_prescription_id,
health_group_id,
vmp_type_id,
vmp_method_id,
anatomic_zone_id,
prescription_id)
values (
1,
NEW.id,
NEW.md_is_urgent,
NEW.md_is_use_cryogenic,
NEW.md_is_use_endoscopic,
NEW.md_is_use_laser,
NEW.md_anesthesia_type_id,
NEW.md_step_id,
NEW.md_complication_type_id,
NEW.md_diagnosis_id,
NEW.md_case_id,
NEW.md_referral_id,
NEW.md_result_category_id,
NEW.md_patient_prescription_id,
NEW.md_health_group_id,
NEW.md_vmp_type_id,
NEW.md_vmp_method_id,
NEW.md_anatomic_zone_id,
NEW.md_prescription_id);

  end if;

  if TG_OP='UPDATE' then

UPDATE md_srv_rendered SET
entity_sync_num = coalesce(entity_sync_num, 0) + 1,--prevent recursion
is_urgent = NEW.md_is_urgent,
is_use_cryogenic = NEW.md_is_use_cryogenic,
is_use_endoscopic = NEW.md_is_use_endoscopic,
is_use_laser = NEW.md_is_use_laser,
anesthesia_type_id = NEW.md_anesthesia_type_id,
step_id = NEW.md_step_id,
complication_type_id = NEW.md_complication_type_id,
diagnosis_id = NEW.md_diagnosis_id,
case_id = NEW.md_case_id,
referral_id = NEW.md_referral_id,
result_category_id = NEW.md_result_category_id,
patient_prescription_id = NEW.md_patient_prescription_id,
health_group_id = NEW.md_health_group_id,
vmp_type_id = NEW.md_vmp_type_id,
vmp_method_id = NEW.md_vmp_method_id,
anatomic_zone_id = NEW.md_anatomic_zone_id,
prescription_id = NEW.md_prescription_id
WHERE id = NEW.id;
  end if;
end if;

RETURN NEW;
END;
$$;

