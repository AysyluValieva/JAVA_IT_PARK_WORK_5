CREATE FUNCTION fin_bill__get_main_bill(bill_id integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
    main_bill_id integer;
begin
    if bill_id is null then return null; end if;
    main_bill_id = (select fin_bill_main.id from fin_bill_main where fin_bill_main.id = bill_id);
    if main_bill_id is not null then return main_bill_id;
    end if;
    main_bill_id = (select fin_bill_additional.base_id from fin_bill_additional where fin_bill_additional.id = bill_id);
    if main_bill_id is not null then return fin_bill__get_main_bill(main_bill_id);
    end if;
    main_bill_id = (select fin_bill_correctional.base_id from fin_bill_correctional where fin_bill_correctional.id = bill_id);
    if main_bill_id is not null then return fin_bill__get_main_bill(main_bill_id);
    end if;
    return null;
end;
$$;

