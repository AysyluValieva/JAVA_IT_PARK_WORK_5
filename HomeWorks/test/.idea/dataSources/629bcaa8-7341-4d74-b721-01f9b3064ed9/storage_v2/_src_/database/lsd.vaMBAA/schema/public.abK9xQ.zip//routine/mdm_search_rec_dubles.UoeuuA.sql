CREATE FUNCTION mdm_search_rec_dubles(tbl_name character varying)
  RETURNS TABLE(id integer, name character varying, cnt integer)
LANGUAGE plpgsql
AS $$
DECLARE
  _result record;
BEGIN
  FOR _result IN EXECUTE '
select tbl.id,tbl.name,count(mrm.source_record_id) from '||$1||' tbl
left join mdm_record_mapping mrm on mrm.source_record_id::integer=tbl.id and mrm.source_refbook_id=mdm_table__get_refbook_version_id('''||$1||''') 
group by tbl.id,tbl.name having count(mrm.source_record_id)<>1 order by 3'
  LOOP
    id:=_result.id;
    name:=_result.name;
    cnt:=_result.count;
    RETURN NEXT;
  END LOOP;
END
$$;

