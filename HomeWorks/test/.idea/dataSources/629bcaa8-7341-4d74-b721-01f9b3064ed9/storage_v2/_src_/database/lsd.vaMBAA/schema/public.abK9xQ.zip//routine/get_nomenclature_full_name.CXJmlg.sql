CREATE FUNCTION get_nomenclature_full_name(inv_store_nomenclature_id integer)
  RETURNS text
LANGUAGE plpgsql
AS $$
declare
   full_name text;
   org_name text;
   param text;
   retval text;
   param_string text;
begin
  select coalesce(inv_h.name_trade,'')||' '||coalesce(inv_ft.short_name,'') into full_name
      from inv_store_nomenclature inv_sn
         left join inv_holding inv_h on inv_sn.holding_id=inv_h.id
         left join inv_form inv_f on inv_sn.form_id=inv_f.id
         left join inv_form_type inv_ft on inv_f.form_type_id=inv_ft.id
  where inv_sn.id=inv_store_nomenclature_id;

  select  coalesce(pim_org.short_name,'')||''||coalesce('('||ae.name||')','') into org_name
      from inv_store_nomenclature inv_sn
         left join pim_organization pim_org on pim_org.id=inv_sn.clinic_id
         left join address_element ae on ae.id=pim_org.country_jurisdiction_id
  where inv_sn.id=inv_store_nomenclature_id ;

  param_string='';
  for param in select fpv.val||cmn.mnemocode
              from inv_form_param_value fpv
                  left join inv_form_param fp on fp.id=fpv.form_param_id
                  left join inv_form inf on inf.id=fpv.form_id
                  left join cmn_measure cmn on cmn.id=fpv.unit_id
              where inf.id=(select inv_sn.form_id from inv_store_nomenclature inv_sn where inv_sn.id=inv_store_nomenclature_id)
              order by fp.degree
              loop
                  param_string=param_string||' '||param;
              end loop;

  retval=coalesce(full_name,'')||' '||coalesce(param_string,'')||' '||coalesce(org_name,'');
  return retval;
end;
$$;

