CREATE FUNCTION exists_org_coefficient_interval(coef_id integer, orgg_id integer, typee_id integer, from_dt date, to_dt date)
  RETURNS boolean
LANGUAGE plpgsql
AS $$
DECLARE
                    result boolean;
                    rec record;
                BEGIN
                    FOR rec IN
                        SELECT
                        oc.id, oc.from_dt, oc.to_dt
                        FROM pim_org_coefficient oc
                        WHERE oc.org_id = orgg_id and oc.type_id = typee_id and oc.id !=coef_id
                    loop
                        select overlaps(coalesce(rec.from_dt, date '01.01.0001'), coalesce(rec.to_dt, date '01.01.3000'), coalesce(from_dt, date '01.01.0001'), coalesce(to_dt, date '01.01.3000'))
                        into result;
                        if (result = 't') then
                            return true;
                        end if;
                    end loop;
                    return false;
                END;
$$;

