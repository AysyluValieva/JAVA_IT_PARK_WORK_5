CREATE VIEW v_nz_diagnosis AS
  WITH d1 AS (
         SELECT d.id AS l1_id,
            concat(d.code, (' '::text || (d.name)::text)) AS l1_diag
           FROM md_diagnosis d
          WHERE ((d.parent_id IS NULL) AND ((d.code)::text ~~ '%-%'::text))
        ), d2 AS (
         SELECT d1.l1_id,
            d1.l1_diag,
            d.id AS l2_id,
            concat(d.code, (' '::text || (d.name)::text)) AS l2_diag
           FROM (d1
             LEFT JOIN md_diagnosis d ON ((d.parent_id = d1.l1_id)))
        ), d3 AS (
         SELECT d2.l1_id,
            d2.l1_diag,
            d2.l2_id,
            d2.l2_diag,
            d.id AS l3_id,
            concat(d.code, (' '::text || (d.name)::text)) AS l3_diag
           FROM (d2
             LEFT JOIN md_diagnosis d ON ((d.parent_id = d2.l2_id)))
        ), d4 AS (
         SELECT d3.l1_id,
            d3.l1_diag,
            d3.l2_id,
            d3.l2_diag,
            d3.l3_id,
            d3.l3_diag,
            COALESCE(d.id, d3.l3_id) AS l4_id,
                CASE
                    WHEN (d.id IS NOT NULL) THEN concat(d.code, (' '::text || (d.name)::text))
                    ELSE d3.l3_diag
                END AS l4_diag
           FROM (d3
             LEFT JOIN md_diagnosis d ON ((d.parent_id = d3.l3_id)))
        ), d5 AS (
         SELECT d4.l1_id,
            d4.l1_diag,
            d4.l2_id,
            d4.l2_diag,
            d4.l3_id,
            d4.l3_diag,
            d4.l4_id,
            d4.l4_diag,
            COALESCE(d.id, d4.l4_id) AS l5_id,
                CASE
                    WHEN (d.id IS NOT NULL) THEN concat(d.code, (' '::text || (d.name)::text))
                    ELSE d4.l4_diag
                END AS l5_diag
           FROM (d4
             LEFT JOIN md_diagnosis d ON ((d.parent_id = d4.l4_id)))
        )
 SELECT d5.l1_id,
    d5.l1_diag,
    d5.l2_id,
    d5.l2_diag,
    d5.l3_id,
    d5.l3_diag,
    d5.l4_id,
    d5.l4_diag,
    d5.l5_id,
    d5.l5_diag
   FROM d5
  ORDER BY d5.l1_diag, d5.l2_diag, d5.l3_diag, d5.l4_diag, d5.l5_diag;

