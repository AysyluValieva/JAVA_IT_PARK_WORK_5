CREATE FUNCTION prescribed_services_execution(integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
    count_service_prescribed integer;
    count_service_rendered integer;
    prescription_data RECORD;

begin

select md_patient_prescription.start_period_date as sdate,
LEAST(md_patient_prescription.end_period_date, md_patient_prescription.cancel_date) as edate ,
coalesce((select cmn_time_period.code from cmn_time_event_period inner join cmn_time_period on cmn_time_period.id = cmn_time_event_period.return_period_id where cmn_time_event_period.time_event_id = md_prescription.time_event_id limit 1), 'DAY') as code
from md_prescription into prescription_data
inner join md_patient_prescription on md_patient_prescription.id =  md_prescription.id
inner  join cmn_measure on md_prescription.period_duration_unit_id = cmn_measure.id
inner join cmn_time_event on md_prescription.time_event_id = cmn_time_event.id
where md_patient_prescription.start_period_date is not null and md_patient_prescription.end_period_date is not null and md_prescription.id = $1;

IF (prescription_data.code = 'WEEK') THEN
    select count(1) from generate_series(prescription_data.sdate,  prescription_data.edate, '1 day'::interval) i into count_service_prescribed
    where extract(dow from date (i::date)) in (select case when cmn_time_event_period.value = 7 then 0 else cmn_time_event_period.value  end from cmn_time_event_period inner join cmn_time_period on cmn_time_event_period.return_period_id = cmn_time_period.id where
    exists ( select 1 from md_prescription  where id = $1 and cmn_time_event_period.time_event_id = time_event_id)) ;
ELSEIF (prescription_data.code = 'MONTH') THEN
    select count(1) from generate_series(prescription_data.sdate,  prescription_data.edate, '1 month'::interval) i into count_service_prescribed
    where extract(month from date (i::date)) in (select cmn_time_event_period.value  from cmn_time_event_period inner join cmn_time_period on cmn_time_event_period.return_period_id = cmn_time_period.id where
    exists ( select 1 from md_prescription  where id = $1 and cmn_time_event_period.time_event_id = time_event_id)) ;
ELSEIF (prescription_data.code = 'QUARTER') THEN
    select count(1) from generate_series(prescription_data.sdate,  prescription_data.edate, '3 month'::interval) i into count_service_prescribed
    where extract(quarter from date (i::date)) in (select cmn_time_event_period.value from cmn_time_event_period inner join cmn_time_period on cmn_time_event_period.return_period_id = cmn_time_period.id where
    exists ( select 1 from md_prescription  where id = $1 and cmn_time_event_period.time_event_id = time_event_id)) ;
ELSEIF (prescription_data.code = 'DAY') THEN
    select count(1) from generate_series(prescription_data.sdate,  prescription_data.edate, '1 day'::interval) into count_service_prescribed;
END IF;



IF (count_service_prescribed is null) THEN
  return 0;
ELSE
    IF (count_service_prescribed = 0) THEN
      return null ;
    END IF;
    select coalesce(sum(coalesce(sr_srv_rendered.quantity, 1)), 0)
    from sr_srv_rendered into count_service_rendered
    where md_patient_prescription_id = $1;
    return  round (100 * count_service_rendered/count_service_prescribed);
END IF;
end;
$$;

