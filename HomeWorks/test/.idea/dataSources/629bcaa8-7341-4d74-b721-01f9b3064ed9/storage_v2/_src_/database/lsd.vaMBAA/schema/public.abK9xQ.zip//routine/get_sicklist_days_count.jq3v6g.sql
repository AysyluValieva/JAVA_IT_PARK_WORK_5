CREATE FUNCTION get_sicklist_days_count(i integer)
  RETURNS integer
LANGUAGE SQL
AS $$
with recursive r as (
				select  s.id as current_id,
					    parent_id as current_parent_id,
					    s.id,
					    case ready_to_work_other_id -- для ready_to_work_other_id = 4 и 6 всегда находим первоначальную запись
							when 4 then parent_id
							when 6 then parent_id
							else 
					            case mst.e_code --
						            when  '2' then parent_id -- только в случае sicklist.type_id = 2 находим parent_id
								    when '3' then null :: int  -- для e_code = '3' не проваливаемся до первоначальной записи
								    else null :: int
								end
						end as parent_id, -- если на первом шаге расчетный parent_id = NULL то рекурсивный запрос не провалится дальше
					    count_day, count_day_work, ready_to_work_other_id, ready_to_work_other_dt
				from md_sicklist s
						join lateral (
								SELECT
										max(to_dt) - min(from_dt) + 1 as count_day,
										s.ready_to_work_other_dt - min(from_dt) + 1 as count_day_work
								from md_sicklist_period p
								where p.sicklist_id = s.id
								)p on true
					    left join md_sicklist_type mst on mst.id = s.type_id
				where s.id = $1
					
				union all
				select r.current_id, r.current_parent_id, s.id, s.parent_id, coalesce(r.count_day, 0) + coalesce(p.count_day, 0), p.count_day_work, r.ready_to_work_other_id, r.ready_to_work_other_dt
				from md_sicklist s
						join r on r.parent_id = s.id
						join lateral (
								SELECT
										max(to_dt) - min(from_dt) + 1 as count_day,
										r.ready_to_work_other_dt - min(from_dt) + 1 as count_day_work
								from md_sicklist_period p
								where p.sicklist_id = s.id
								)p on true
		)
		select coalesce(
							case ready_to_work_other_id
									when 4 then count_day_work
									when 6 then count_day_work
									else count_day
							end, 0) as count_day
		from r
		where parent_id is null
$$;

