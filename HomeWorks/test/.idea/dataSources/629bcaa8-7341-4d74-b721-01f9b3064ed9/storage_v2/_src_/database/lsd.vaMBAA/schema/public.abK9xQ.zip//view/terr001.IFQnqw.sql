CREATE VIEW terr001 AS
  SELECT terr001.cod,
    terr001.name,
    terr001.type_schet,
    terr001.date_ins,
    terr001.date_del,
    terr001.dt
   FROM billing.terr001;

