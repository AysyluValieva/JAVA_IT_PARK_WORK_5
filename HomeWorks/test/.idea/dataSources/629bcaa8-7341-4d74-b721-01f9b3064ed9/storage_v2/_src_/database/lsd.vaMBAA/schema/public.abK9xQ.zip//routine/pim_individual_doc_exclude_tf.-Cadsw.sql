CREATE FUNCTION pim_individual_doc_exclude_tf()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE
                r RECORD;
                not_uq BOOLEAN;
            BEGIN
                SELECT is_not_unique FROM pim_doc_type WHERE id = NEW.type_id INTO not_uq;
                IF not_uq THEN
                    RETURN NEW;
                END IF;
                FOR r IN SELECT * FROM pim_individual_doc WHERE
                type_id = NEW.type_id
                AND COALESCE(issuer_id,0) = COALESCE(NEW.issuer_id,0)
                AND UPPER(COALESCE(series,'')||number) = UPPER(COALESCE(NEW.series,'')||NEW.number)
                LOOP
                IF (daterange(r.issue_dt,r.expire_dt) && daterange(NEW.issue_dt,NEW.expire_dt) AND (NEW.id IS NULL OR NEW.id <> r.id)) THEN
                RAISE EXCEPTION 'Уже существует такой документ с серией/номером% % и пересекющимся интервалом дат.', ' '||COALESCE(NEW.series,''), NEW.number;
                END IF;
                END LOOP;
                RETURN NEW;
            END
$$;

