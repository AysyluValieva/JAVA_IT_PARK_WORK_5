CREATE FUNCTION apda_get_houses_diapason(pattern character varying)
  RETURNS apda_houses_diapason
LANGUAGE plpgsql
AS $$
DECLARE
  diapason_type   VARCHAR;
  diapason_houses VARCHAR;
  diapason_flats  VARCHAR;
  single_number   VARCHAR;
BEGIN
  IF $1 LIKE 'Н(%'
  THEN diapason_type = 'Н';
    diapason_houses = substring($1, 3, length($1) - 3);
  ELSEIF $1 LIKE 'Ч(%'
    THEN diapason_type = 'Ч';
      diapason_houses = substring($1, 3, length($1) - 3);
  ELSEIF $1 LIKE '%(%'
    THEN
      single_number = (regexp_split_to_array($1, E'\\(')) [1];
      diapason_flats = replace((regexp_split_to_array($1, E'\\(')) [2], ')', '');
      RETURN ('О',
              single_number,
              NULL,
              NULL,
              (((regexp_split_to_array(diapason_flats, E'-'))) [1] :: INTEGER,
               ((regexp_split_to_array(diapason_flats, E'-'))) [2] :: INTEGER
              ) :: apda_flats_diapason
      ) :: apda_houses_diapason;
  ELSEIF $1 LIKE '%-%'
    THEN diapason_type = 'И';
      diapason_houses = $1;
  ELSE RETURN ('О', $1, NULL, NULL, NULL) :: apda_houses_diapason; END IF;

  IF diapason_houses NOTNULL
  THEN
    RETURN (diapason_type,
            NULL,
            ((regexp_split_to_array(diapason_houses, E'-'))) [1] :: INTEGER,
            ((regexp_split_to_array(diapason_houses, E'-'))) [2] :: INTEGER,
            NULL
    ) :: apda_houses_diapason;
  END IF;

  RETURN NULL;
END;
$$;

