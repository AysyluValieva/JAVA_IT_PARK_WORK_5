CREATE FUNCTION no_doubling_on_create_new_service_rendered()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE
                  r RECORD;
                BEGIN
                  IF EXISTS(SELECT 1
                            FROM public.sr_srv_rendered pmc
                            WHERE ((pmc.planned_date IS NULL AND NEW.planned_date IS NULL) OR pmc.planned_date = NEW.planned_date)
                               --   AND ((pmc.planned_time IS NULL AND NEW.planned_time IS NULL) OR pmc.planned_time = NEW.planned_time)
                                    AND ((pmc.bdate IS NULL AND NEW.bdate IS NULL) OR pmc.bdate = NEW.bdate)
                                                                        AND ((pmc.edate IS NULL AND NEW.edate IS NULL) OR pmc.edate = NEW.edate)
                                    AND ((pmc.customer_id IS NULL AND NEW.customer_id IS NULL) OR pmc.customer_id = NEW.customer_id)
                                --  AND ((pmc.res_group_id IS NULL AND NEW.res_group_id IS NULL) OR pmc.res_group_id = NEW.res_group_id)
																		AND ((pmc.md_step_id IS NULL AND NEW.md_step_id IS NULL) OR pmc.md_step_id = NEW.md_step_id)
                                  AND ((pmc.service_id IS NULL AND NEW.service_id IS NULL) OR pmc.service_id = NEW.service_id)
                                  AND ((pmc.prototype_id IS NULL AND NEW.prototype_id IS NULL) OR pmc.prototype_id = NEW.prototype_id)
                                  AND ((pmc.org_id IS NULL AND NEW.org_id IS NULL) OR pmc.org_id = NEW.org_id)
                                  AND ((pmc.md_case_id IS NULL AND NEW.md_case_id IS NULL) OR pmc.md_case_id = NEW.md_case_id)
																	AND NEW.tooth_number is NULL
                                  AND ((current_timestamp - pmc.aud_when_create) < '3s' :: INTERVAL)
                                order by id desc limit 1000
                  )
                  THEN
                    RAISE EXCEPTION 'Произошло автоматическое дублирование строк, дубль не сохранен';
                  END IF;
                  RETURN NEW;
                END;
$$;

