CREATE FUNCTION create_notif_rule(table_name character varying, event character varying)
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
    _event_code VARCHAR;
    _rule_name  VARCHAR;
    _table_name VARCHAR;
  BEGIN
    IF table_name IS NULL OR event IS NULL
    THEN
      RETURN;
    END IF;
    _event_code := UPPER(table_name)||'|'||event;
    _rule_name := 'event_on_' || lower(event);

    IF(select position('"' in table_name) = 0)
      THEN
        _table_name :='"'||(regexp_split_to_array(table_name, '[.]{1}'))[1]||'".'||(regexp_split_to_array(table_name, '[.]{1}'))[2];
      ELSE
        _table_name := table_name;
    END IF;

    IF upper(event) IN ('UPDATE', 'INSERT')
    THEN
      EXECUTE format('CREATE RULE %s AS ON %s  TO %s DO ALSO
                        (INSERT INTO event_handler.db_event_log(id, event_code, create_event_time, params)
                           SELECT nextval(''event_handler.db_event_log_seq''), ''%s'', now(), row_to_json(NEW) where current_setting(''app.source'') <> ''DB'';
                        SELECT pg_notify( ''db_event'', ''%s^''||currval(''event_handler.db_event_log_seq'')) where current_setting(''app.source'') <> ''DB'');',
                     _rule_name, event, _table_name,_event_code, _event_code, _event_code);
    ELSIF upper(event) = 'DELETE'
      THEN
        EXECUTE format('CREATE RULE %s AS ON DELETE TO %s DO ALSO
                          (INSERT INTO event_handler.db_event_log(id, event_code, create_event_time, params)
                            SELECT nextval(''event_handler.db_event_log_seq''), ''%s'', now(), row_to_json(OLD) where current_setting(''app.source'') <> ''DB'';
                          SELECT pg_notify( ''db_event'', ''%s^''||currval(''event_handler.db_event_log_seq'')) where current_setting(''app.source'') <> ''DB''); ',
                       _rule_name, _table_name, _event_code, _event_code, _event_code);
    END IF;

  END;
$$;

