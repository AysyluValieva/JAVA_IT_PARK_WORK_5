CREATE VIEW v_age_category_2 AS
  SELECT 1 AS id,
    '16-59 лет (М)'::text AS name,
    1 AS gender_id,
    'Мужской'::text AS gender_name
UNION
 SELECT 2 AS id,
    '60 и более (М)'::text AS name,
    1 AS gender_id,
    'Мужской'::text AS gender_name
UNION
 SELECT 3 AS id,
    '16-54 лет (Ж)'::text AS name,
    2 AS gender_id,
    'Женский'::text AS gender_name
UNION
 SELECT 4 AS id,
    '55 и более (Ж)'::text AS name,
    2 AS gender_id,
    'Женский'::text AS gender_name;

