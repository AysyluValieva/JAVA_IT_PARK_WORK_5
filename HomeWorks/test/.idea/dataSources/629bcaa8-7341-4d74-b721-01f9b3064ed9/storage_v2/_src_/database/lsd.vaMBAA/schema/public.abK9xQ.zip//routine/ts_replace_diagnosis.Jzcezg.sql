CREATE FUNCTION ts_replace_diagnosis(clinic_id integer, month_no integer, old_diagnosis character varying, new_diagnosis character varying)
  RETURNS void
LANGUAGE plpgsql
AS $$
BEGIN
UPDATE mc_diagnosis d
SET diagnos_id = (SELECT id FROM md_diagnosis WHERE code = $4)
WHERE d.id in  (SELECT cd.id FROM mc_case c JOIN mc_step s ON c.id = s.case_id JOIN mc_diagnosis cd ON c.id = cd.case_id JOIN md_diagnosis mdi ON mdi.id = cd.diagnos_id  WHERE c.clinic_id = $1 
and date_part('month',outcome_date) =$2 
and mdi.code= $3 
);
UPDATE mc_case c
SET main_diagnos_id = (SELECT id FROM md_diagnosis WHERE code = $4)
WHERE c.id in  (SELECT c.id FROM mc_case c join md_diagnosis mdi ON mdi.id = c.main_diagnos_id JOIN mc_step s ON c.closing_step_id = s.id  WHERE c.clinic_id = $1 
and date_part('month',outcome_date) =$2 
and mdi.code= $3 
);
RAISE NOTICE 'done';
END
$$;

