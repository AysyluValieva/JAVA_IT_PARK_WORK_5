CREATE VIEW inv_reg_cert_v AS
  SELECT rc.id AS reg_cert_id,
    rc.md_holding_id AS holding_id,
    NULL::integer AS form_id
   FROM inv_reg_cert rc
UNION
 SELECT rcf.reg_cert_id,
    rc.md_holding_id AS holding_id,
    rcf.form_id
   FROM inv_reg_cert_form rcf,
    inv_reg_cert rc
  WHERE (rc.id = rcf.reg_cert_id);

