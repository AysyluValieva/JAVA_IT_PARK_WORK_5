CREATE FUNCTION setting_group__delete(xcode character varying)
  RETURNS void
LANGUAGE plpgsql
AS $$
begin

delete from cmn_setting_value where
  (select cmn_setting_group.code from cmn_setting, cmn_setting_group where cmn_setting.group_id = cmn_setting_group.id
  and cmn_setting_value.setting_id = cmn_setting.id) = xcode;

delete from cmn_setting where (select cmn_setting_group.code from cmn_setting_group where cmn_setting_group.id = cmn_setting.group_id) = xcode;

delete from cmn_domain where code like xcode||'%';

delete from cmn_setting_group where code = xcode;

end;
$$;

