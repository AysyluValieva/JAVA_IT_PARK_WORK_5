CREATE MATERIALIZED VIEW cube_days AS SELECT (row_number() OVER ())::integer AS id,
    (gday.gday)::date AS calendar_date,
    (date_part('year'::text, (gday.gday)::date))::integer AS year_,
    (date_part('quarter'::text, (gday.gday)::date))::integer AS quarter_of_year,
    (date_part('month'::text, (gday.gday)::date))::integer AS month_of_year,
    (to_char(((gday.gday)::date)::timestamp with time zone, 'WW'::text))::integer AS week_of_year,
    (date_part('day'::text, (gday.gday)::date))::integer AS day_of_month,
    (to_char(((gday.gday)::date)::timestamp with time zone, 'ID'::text))::integer AS day_of_week,
    (to_char(((gday.gday)::date)::timestamp with time zone, 'DDD'::text))::integer AS day_of_year,
        CASE
            WHEN (date_part('quarter'::text, (gday.gday)::date) = (1)::double precision) THEN '1-ый квартал'::text
            WHEN (date_part('quarter'::text, (gday.gday)::date) = (2)::double precision) THEN '2-ой квартал'::text
            WHEN (date_part('quarter'::text, (gday.gday)::date) = (3)::double precision) THEN '3-ий квартал'::text
            WHEN (date_part('quarter'::text, (gday.gday)::date) = (4)::double precision) THEN '4-ый квартал'::text
            ELSE NULL::text
        END AS name_quarter_of_year,
        CASE
            WHEN (date_part('month'::text, (gday.gday)::date) = (1)::double precision) THEN 'Январь'::text
            WHEN (date_part('month'::text, (gday.gday)::date) = (2)::double precision) THEN 'Февраль'::text
            WHEN (date_part('month'::text, (gday.gday)::date) = (3)::double precision) THEN 'Март'::text
            WHEN (date_part('month'::text, (gday.gday)::date) = (4)::double precision) THEN 'Апрель'::text
            WHEN (date_part('month'::text, (gday.gday)::date) = (5)::double precision) THEN 'Май'::text
            WHEN (date_part('month'::text, (gday.gday)::date) = (6)::double precision) THEN 'Июнь'::text
            WHEN (date_part('month'::text, (gday.gday)::date) = (7)::double precision) THEN 'Июль'::text
            WHEN (date_part('month'::text, (gday.gday)::date) = (8)::double precision) THEN 'Август'::text
            WHEN (date_part('month'::text, (gday.gday)::date) = (9)::double precision) THEN 'Сентябрь'::text
            WHEN (date_part('month'::text, (gday.gday)::date) = (10)::double precision) THEN 'Октябрь'::text
            WHEN (date_part('month'::text, (gday.gday)::date) = (11)::double precision) THEN 'Ноябрь'::text
            WHEN (date_part('month'::text, (gday.gday)::date) = (12)::double precision) THEN 'Декабрь'::text
            ELSE NULL::text
        END AS name_month_of_year,
        CASE
            WHEN ((to_char(((gday.gday)::date)::timestamp with time zone, 'ID'::text))::integer = 1) THEN 'Понедельник'::text
            WHEN ((to_char(((gday.gday)::date)::timestamp with time zone, 'ID'::text))::integer = 2) THEN 'Вторник'::text
            WHEN ((to_char(((gday.gday)::date)::timestamp with time zone, 'ID'::text))::integer = 3) THEN 'Среда'::text
            WHEN ((to_char(((gday.gday)::date)::timestamp with time zone, 'ID'::text))::integer = 4) THEN 'Четверг'::text
            WHEN ((to_char(((gday.gday)::date)::timestamp with time zone, 'ID'::text))::integer = 5) THEN 'Пятница'::text
            WHEN ((to_char(((gday.gday)::date)::timestamp with time zone, 'ID'::text))::integer = 6) THEN 'Суббота'::text
            WHEN ((to_char(((gday.gday)::date)::timestamp with time zone, 'ID'::text))::integer = 7) THEN 'Восресенье'::text
            ELSE NULL::text
        END AS name_day_of_week
   FROM generate_series((to_date('2013-01-01'::text, 'YYYY-MM-DD'::text))::timestamp with time zone, (to_date((to_char((('now'::text)::date)::timestamp with time zone, 'yyyy'::text) || '-12-31'::text), 'YYYY-MM-DD'::text))::timestamp with time zone, '1 day'::interval) gday(gday);

CREATE INDEX id_inx
  ON cube_days (id);

CREATE INDEX date_inx
  ON cube_days (calendar_date);

CREATE INDEX year_inx
  ON cube_days (year_);

CREATE INDEX quarter_inx
  ON cube_days (quarter_of_year);

CREATE INDEX month_inx
  ON cube_days (month_of_year);

CREATE INDEX day_inx
  ON cube_days (day_of_month);

