CREATE FUNCTION mdm_table_record__save(xtable character varying, xid character varying, xcreate_dt date, xclose_dt date)
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
  rec record;
begin

  rec := mdm_table_record__get(xtable, xid);

  if rec is null then
    insert into mdm_table_record(refbook_id, record_id, close_dt)
      values(mdm_table__get_refbook_version_id(xtable), xid, null);
    select * into rec from mdm_table_record
      where record_id = xid and mdm_table__get_refbook_version_id(xtable) = refbook_id;
  end if;

  update mdm_table_record set create_dt = xcreate_dt, close_dt = xclose_dt
    where refbook_id = rec.refbook_id and record_id = rec.record_id;

end;
$$;

