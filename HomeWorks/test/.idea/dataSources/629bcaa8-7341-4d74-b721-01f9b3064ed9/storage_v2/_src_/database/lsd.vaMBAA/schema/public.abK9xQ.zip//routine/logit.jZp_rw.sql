CREATE FUNCTION logit(message text, _id integer)
  RETURNS void
LANGUAGE SQL
AS $$
update tambov_loader_ident_download set msg = array_append(msg, $1) where id = $2;
$$;

