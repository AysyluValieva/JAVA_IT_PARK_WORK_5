CREATE FUNCTION add_count_prescription_execution()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE
    count_execution_var varchar;
BEGIN
    IF    TG_OP = 'INSERT' THEN
        IF (NEW.md_patient_prescription_id is not null) THEN
            count_execution_var = count_of_execution_prescription(NEW.md_patient_prescription_id);
            UPDATE md_patient_prescription SET count_execution = count_execution_var WHERE id = NEW.md_patient_prescription_id;
        END IF;
        RETURN NEW;
    ELSIF TG_OP = 'UPDATE' THEN
       IF (OLD.md_patient_prescription_id is not null) THEN
            count_execution_var := count_of_execution_prescription(OLD.md_patient_prescription_id);
            UPDATE md_patient_prescription SET count_execution = count_execution_var WHERE id = OLD.md_patient_prescription_id;
       END IF;
       IF (NEW.md_patient_prescription_id is not null) THEN
            count_execution_var := count_of_execution_prescription(NEW.md_patient_prescription_id);
            UPDATE md_patient_prescription SET count_execution = count_execution_var WHERE id = NEW.md_patient_prescription_id;
        END IF;
        RETURN NEW;
    ELSIF TG_OP = 'DELETE' THEN
        IF (OLD.md_patient_prescription_id is not null) THEN
            count_execution_var := count_of_execution_prescription(OLD.md_patient_prescription_id);
            UPDATE md_patient_prescription SET count_execution = count_execution_var WHERE id = OLD.md_patient_prescription_id;
        END IF;
        RETURN OLD;
    END IF;
END;
$$;

