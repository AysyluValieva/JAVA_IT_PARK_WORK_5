CREATE FUNCTION update_plc_visit_or_hsp_record()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE
                        _case_id integer;
						_case_mode_id integer;
						_step_id integer;
                        -- visit
                        _plc_goal_id integer;
                        _plc_initiator_id integer;
                        _plc_place_id integer;
                        _plc_type_id integer;
                        _plc_is_viewed boolean;
                        _plc_is_needed boolean;
                        _plc_is_sanitized boolean;
                        _plc_appointment_id integer;
                        _plc_planned_date date;
                        -- hsp
                        _hsp_department_id integer;
                        _hsp_funding_id integer;
                        _hsp_mes_id integer;
                        _hsp_previous_id integer;
                        _hsp_is_set_diagnosis boolean;
                        _hsp_is_diag_not_eq boolean;
                        _hsp_days_comp_algo_id integer;
                        _hsp_is_admission_day_counts boolean;
                        _hsp_missed_days_amount  integer;
                        _hsp_bed_days_amount integer;
                        _hsp_issue_planned_date date;
                        _hsp_complexity_level_id integer;
                        _hsp_bed_profile_id  integer;
                        _hsp_refusal_employee_id integer;
                        _hsp_plan_department_id integer;
                BEGIN
                    IF TG_OP = 'INSERT' OR TG_OP = 'UPDATE' THEN
                        _step_id = NEW.id;
                        _plc_goal_id = NEW.plc_goal_id;
                        _plc_initiator_id = NEW.plc_initiator_id;
                        _plc_place_id = NEW.plc_place_id;
                        _plc_type_id = NEW.plc_type_id;
                        _plc_is_viewed = NEW.plc_is_viewed;
                        _plc_is_needed = NEW.plc_is_needed;
                        _plc_is_sanitized = NEW.plc_is_sanitized;
                        _plc_appointment_id = NEW.plc_appointment_id;
                        _plc_planned_date = NEW.plc_planned_date;
                        _hsp_department_id = NEW.hsp_department_id;
                        _hsp_funding_id = NEW.hsp_funding_id;
                        _hsp_mes_id = NEW.hsp_mes_id;
                        _hsp_previous_id = NEW.hsp_previous_id;
                        _hsp_is_set_diagnosis = NEW.hsp_is_set_diagnosis;
                        _hsp_is_diag_not_eq = NEW.hsp_is_diag_not_eq;
                        _hsp_days_comp_algo_id = NEW.hsp_days_comp_algo_id;
                        _hsp_is_admission_day_counts = NEW.hsp_is_admission_day_counts;
                        _hsp_missed_days_amount = NEW.hsp_missed_days_amount;
                        _hsp_bed_days_amount = NEW.hsp_bed_days_amount;
                        _hsp_issue_planned_date = NEW.hsp_issue_planned_date;
                        _hsp_complexity_level_id = NEW.hsp_complexity_level_id;
                        _hsp_bed_profile_id  = NEW.hsp_bed_profile_id;
                        _hsp_refusal_employee_id = NEW.hsp_refusal_employee_id;
                        _hsp_plan_department_id = NEW.hsp_plan_department_id;
						_case_mode_id = (select mct.case_mode_id 
											from mc_step ms
											join mc_case mc on mc.id = ms.case_id
											join mc_case_type mct on mc.case_type_id = mct.id
--where not exists (select 1 from mc_step s join mc_case c on c.id = s.case_id join hsp_record hs on hs.id = ms.id where s.id = ms.id)
--and mct.case_mode_id = 2
--and ms.hsp_department_id IS not NULL /*and ms.plc_place_id is null*/
											where ms.id = NEW.id);
                    ELSIF TG_OP = 'DELETE' THEN
                        _step_id = OLD.id;
                    ELSE
                        RETURN NULL;
                    END IF;
                     
                    IF TG_OP = 'INSERT' OR TG_OP = 'UPDATE' THEN
                        IF _case_mode_id = 1 THEN
							IF EXISTS (SELECT 1 FROM hsp_record WHERE id = _step_id) THEN 
								DELETE FROM hsp_record WHERE id = _step_id;
							END IF;
                            IF EXISTS (SELECT 1 FROM plc_visit WHERE id = _step_id) THEN
                                UPDATE plc_visit SET goal_id = _plc_goal_id, initiator_id = _plc_initiator_id, place_id = _plc_place_id, type_id = _plc_type_id, is_viewed = _plc_is_viewed,
                                                is_needed = _plc_is_needed, is_sanitized = _plc_is_sanitized, appointment_id = _plc_appointment_id, planned_date = _plc_planned_date  WHERE id = _step_id;
                            ELSE
                                INSERT INTO plc_visit (id, goal_id, initiator_id, place_id, type_id, is_viewed, is_needed, is_sanitized, appointment_id, planned_date)
                                VALUES (_step_id, _plc_goal_id, _plc_initiator_id, _plc_place_id, _plc_type_id, _plc_is_viewed, _plc_is_needed, _plc_is_sanitized, _plc_appointment_id, _plc_planned_date);
                            END IF;
                        ELSIF _case_mode_id = 2 THEN
							IF EXISTS (SELECT 1 FROM plc_visit WHERE id = _step_id) THEN 
								DELETE FROM plc_visit WHERE id = _step_id;
							END IF;
                            IF EXISTS (SELECT 1 FROM hsp_record WHERE id = _step_id) THEN
                                UPDATE hsp_record SET department_id = _hsp_department_id, funding_id = _hsp_funding_id, mes_id = _hsp_mes_id, previous_id = _hsp_previous_id,
                                                is_set_diagnosis = _hsp_is_set_diagnosis, is_diag_not_eq = _hsp_is_diag_not_eq, days_comp_algo_id = _hsp_days_comp_algo_id,
                                                is_admission_day_counts = _hsp_is_admission_day_counts,  missed_days_amount = _hsp_missed_days_amount, bed_days_amount = _hsp_bed_days_amount,
                                                issue_planned_date = _hsp_issue_planned_date, complexity_level_id = _hsp_complexity_level_id, bed_profile_id = _hsp_bed_profile_id,
                                                refusal_employee_id = _hsp_refusal_employee_id, plan_department_id = _hsp_plan_department_id  WHERE id = _step_id;
                            ELSE
                                INSERT INTO hsp_record (id, department_id, funding_id, mes_id, previous_id, is_set_diagnosis, is_diag_not_eq, days_comp_algo_id, is_admission_day_counts,
                                                    missed_days_amount, bed_days_amount, issue_planned_date, complexity_level_id, bed_profile_id, refusal_employee_id, plan_department_id)
                                VALUES (_step_id, _hsp_department_id, _hsp_funding_id, _hsp_mes_id, _hsp_previous_id, _hsp_is_set_diagnosis, _hsp_is_diag_not_eq, _hsp_days_comp_algo_id,
                                _hsp_is_admission_day_counts, _hsp_missed_days_amount, _hsp_bed_days_amount, _hsp_issue_planned_date, _hsp_complexity_level_id, _hsp_bed_profile_id, _hsp_refusal_employee_id, _hsp_plan_department_id);
                            END IF;
                        END IF;
                    END IF;
                     
                    IF TG_OP = 'DELETE' THEN
                        DELETE FROM plc_visit WHERE id = _step_id;
                        DELETE FROM hsp_record WHERE id = _step_id;
					END IF;
                     
                    RETURN NULL;
                END;

$$;

