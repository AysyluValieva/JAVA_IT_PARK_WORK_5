CREATE FUNCTION insert_snils(ss text, snils text, id_pac integer)
  RETURNS pim_individual_doc
LANGUAGE SQL
AS $$
with cte as (
		insert into pim_indiv_code (id, indiv_id, code, type_id)
		select 
			nextval('pim_indiv_code_id_seq') as id,
			$3 as indiv_id, 
			$2 as code,
			(select id from pim_code_type where code='SNILS') as type_id
		returning *
	)
	insert into pim_individual_doc(id, type_id, indiv_id, "number", code_id, is_active)
	select 
			nextval('pim_individual_doc_id_seq') as id,
			(select id from pim_doc_type where code='SNILS') as type_id,
			$3 as indiv_id, 
			$1 as "number",
			cte.id as code_id,
			true as is_active
	from cte
	returning *
$$;

