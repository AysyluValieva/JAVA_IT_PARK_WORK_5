CREATE FUNCTION calc_patient_job()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
declare
            begin
                if (TG_OP = 'DELETE')
                then
                    update pim_individual set list_job_org =(
                        select o.short_name from pim_organization o
                        join pci_patient_job pj on (o.id = pj.organization_id and pj.patient_id = OLD.patient_id) limit 1
                    )
                    where id = OLD.patient_id;

                    return OLD;
                else
                    update pim_individual set list_job_org =(
                        select o.short_name from pim_organization o
                        join pci_patient_job pj on (o.id = pj.organization_id and pj.patient_id = NEW.patient_id) limit 1
                    )
                    where id = NEW.patient_id;
                    --нужно обновлять и "старого" пациента, если измениля patient_id
                    if (TG_OP = 'UPDATE' AND NEW.patient_id <> OLD.patient_id) then
                        update pim_individual set list_job_org =(
                            select o.short_name from pim_organization o
                            join pci_patient_job pj on (o.id = pj.organization_id and pj.patient_id = NEW.patient_id) limit 1
                        )
                        where id = OLD.patient_id;
                    end if;

                    return NEW;
                end if;
            end;
$$;

