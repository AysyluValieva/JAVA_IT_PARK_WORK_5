CREATE FUNCTION get_protocol_sign_info(srv_rendered_id integer)
  RETURNS text
LANGUAGE plpgsql
AS $$
declare
                    res text := '';
                    protocol_signed record;
                begin
                    select * into protocol_signed from md_ehr_protocol_signed  where health_record_id =(select sp.protocol_id from md_srv_protocol sp inner join md_ehr_protocol p on p.id=sp.protocol_id where sp.srv_rendered_id = $1 and p.is_signed = true limit 1) and unsign_dt is null order by sign_dt desc limit 1;
                    res := res || 'Подписано ' || to_char(protocol_signed.sign_dt::timestamp, 'dd.MM.YYYY HH24:MI') || ',';
                    res := res || (select ' ФИО подписавшего: '|| coalesce(protocol_signed.signatory, ''));
                    return res;
                end;
$$;

