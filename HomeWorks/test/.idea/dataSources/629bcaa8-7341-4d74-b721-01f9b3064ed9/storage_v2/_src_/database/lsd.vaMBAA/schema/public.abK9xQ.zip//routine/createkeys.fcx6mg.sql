CREATE FUNCTION createkeys(orgid integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
BEGIN

/* 1. создание ролей "Минимальная" в МО */
insert into sec.role (name) values ('Минимальная');
insert into sec.role_org (id, org_id) values (currval('sec.role_id_seq'), orgId);

/* 2. создание ключей доступа по должности в МО */
insert into sec.access_key (type_id, org_id, empl_pos_id, user_id, name)
select distinct 2 as type_id, o.id as org_id, ep.id as empl_pos_id, u.id as user_id, coalesce(NULLIF(pname.name,''), NULLIF(p.name, '')) as name
from sec_user u
                join sec_user_party up on up.id = u.id
                join pim_individual i on i.id = up.party_id
                join pim_employee e on e.individual_id = i.id and (e.dismissal_dt is null or e.dismissal_dt > now())
                join pim_organization o on o.id = e.organization_id
                join pim_employee_position ep on ep.employee_id = e.id and (ep.end_date is null or ep.end_date > now())
                left join pim_position p on p.id = ep.position_id
                left join pim_position_name pname on p.id = pname.position_id
                where o.id = orgId
                order by u.id;


/* 3. назначение роли "Минимальная" сотрудникам МО */
insert into sec.access_key_role (role_id, user_access_id)
select r.id as role_id, ak.id as user_access_id
from sec.access_key ak
join sec.role_org ro on ro.org_id = ak.org_id
join sec.role r on r.id = ro.id and r.name = 'Минимальная'
where ak.type_id = 2
  and not exists (select id from sec.access_key_role where user_access_id = ak.id)
  and ak.org_id = orgId
order by ak.id;

END;
$$;

