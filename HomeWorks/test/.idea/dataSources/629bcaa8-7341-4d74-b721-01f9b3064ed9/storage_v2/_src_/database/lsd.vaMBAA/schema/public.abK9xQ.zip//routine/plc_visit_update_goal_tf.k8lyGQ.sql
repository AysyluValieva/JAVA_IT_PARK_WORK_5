CREATE FUNCTION plc_visit_update_goal_tf()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
            IF ((not exists (select value from cmn_setting_value  where setting_id = 'cz.atria.medcase.ui.MedicalCaseUISettings.useVisitGoal')) or
            (select value from cmn_setting_value  where setting_id = 'cz.atria.medcase.ui.MedicalCaseUISettings.useVisitGoal') != 'true') THEN
              UPDATE plc_visit SET goal_id =(SELECT init_goal_id FROM MC_CASE where id=
                (select case_id from mc_step where id= NEW.id)) where id=NEW.id;
            END IF;
            RETURN NEW;
            END;
$$;

