CREATE FUNCTION find_smo_org()
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
	_row record;
	_ids int[];
	_o pim_organization%rowtype;
	_msg text[];
begin
	for _row in select distinct on (smo_ogrn, smo_ok) * from tambov_loader_ident_download_polis
	loop
		_msg := array_append(_msg, 'Ищу ID СМО по коду ОГРН и ОКАТО указанным в XML')::text;
		_msg := _msg || 'Поиск списка ID СМО с ОГРН указанным в поле smo_ogrn и ОКАТО указанным в поле smo_ok'::text;
		

		select array_agg(poc.org_id) into _ids 
		from pim_org_code poc 
		join pim_code_type pct on poc.type_id = pct."id"
		join pim_organization o on o.id = poc.org_id
		join address_element ae on o.work_territory_id = ae.id
		join address_code ac on ae.id = ac.element_id
		join address_code_book acb on acb.id = ac.book_id
		where poc.code = _row.smo_ogrn and pct.code='OGRN' 
			and acb."name" = 'ОКАТО' 
			and _row.smo_ok = left(ac."value", length(_row.smo_ok));

		_msg := _msg || 'Найдено подходящих записей '::text || coalesce(_ids::text, '[]')::text;


		if _ids is null then 
			_msg := _msg || 'Не удалось найти организацию страхованию по коду ОГРН и ОКАТО'::text;
		elsif array_length(_ids, 1) = 1 then 
			_msg := _msg || 'Найдено одно соотвествие по коду ОГРН и  ОКАТО'::text;
		elsif array_length(_ids, 1) > 1 then 
			_msg := _msg || 'Найдено несколько соотвествий коду ОГРН и ОКАТО.'::text || 'Выбираю из них с наименьшей длиной имени'::text;

			with cte as (
				select length(short_name) ln, id from pim_organization where id = any(_ids) order by 1 limit 1
			)
			select o.* into _o from pim_organization o join cte on cte.id = o.id;

			_msg := _msg || 'Походящая запись выбрана'::text;


			update tambov_loader_ident_download_polis set 
				msg = _msg || coalesce(row_to_json(_o)::text, 'null')::text || 'Найдена организация для страховой.'::text,
				smo_org_id = _o.id
			where smo_ogrn = _row.smo_ogrn and smo_ok = _row.smo_ok;
			_msg := null;
		end if;
	end loop;
end;
$$;

