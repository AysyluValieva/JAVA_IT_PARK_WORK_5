CREATE FUNCTION mdm_finder__setup(finder_id integer, table_name character varying)
  RETURNS void
LANGUAGE plpgsql
AS $$
begin

update cmn_finder 
set query = mdm_finder__get_query(query, table_name), query_backup_new = mdm_finder__get_query(query, table_name)
where id = finder_id 
;

end;
$$;

