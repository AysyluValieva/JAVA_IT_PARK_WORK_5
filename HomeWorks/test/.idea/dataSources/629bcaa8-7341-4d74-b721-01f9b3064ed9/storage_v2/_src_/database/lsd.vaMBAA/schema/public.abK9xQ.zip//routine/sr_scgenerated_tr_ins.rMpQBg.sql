CREATE FUNCTION sr_scgenerated_tr_ins()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE _inherted_name varchar;
            _schema varchar := 'schedule.';
            _master_name varchar := 'sr_scgenerated';

            _year varchar;
            _month varchar;

            _range_begin_date varchar;
            _range_end_date varchar;
            BEGIN

            IF TG_OP = 'INSERT' THEN

            IF NEW.date IS NULL THEN
            RAISE EXCEPTION 'Значение в колонке date нарушает ограничение NOT NULL';
            END IF;

            _year := date_part('year', NEW.date)::text;

            _month := lpad(date_part('month', NEW.date)::text,2,'0')::text;


            --вычисляем название унаследованной таблицы
            _inherted_name := 'sr_scgenerated_y' || _year || '_m'|| _month || '_r' || NEW.region_code;

            --проверяем существование унаследованной таблицы
            IF NOT EXISTS(SELECT 0 FROM information_schema.tables WHERE table_name = _inherted_name) THEN

            --если отсутствует, то создаем её
            EXECUTE 'CREATE TABLE '|| _schema || _inherted_name ||'() INHERITS ('|| _master_name ||')';

            EXECUTE 'ALTER TABLE '|| _schema || _inherted_name ||' ADD CONSTRAINT '|| _inherted_name ||'_pkey PRIMARY KEY(id)';

            --задаем условия, при которых записи проставляются в таблицу

            _range_begin_date :=  _year || '-'|| _month || '-01';

            _range_end_date :=  to_char(to_date(_range_begin_date, 'yyyy-MM-dd') + interval '1 month'  - interval '1 day', 'yyyy-MM-dd');


            EXECUTE 'ALTER TABLE '|| _schema || _inherted_name ||' ADD CONSTRAINT date__min_max_date_check CHECK (date BETWEEN '''|| _range_begin_date ||'''::date AND '''|| _range_end_date ||'''::date)';

            EXECUTE 'ALTER TABLE '|| _schema || _inherted_name ||' ADD CONSTRAINT region_check CHECK (region_code='|| NEW.region_code ||')';

            -- создаем индексы
            EXECUTE 'CREATE INDEX ON '|| _schema || _inherted_name ||' USING btree (date)';

            EXECUTE 'CREATE INDEX '|| _inherted_name ||'_all_2_idx ON '|| _schema || _inherted_name ||' USING btree (res_group_id, service_id, source_id, date)';

            EXECUTE 'CREATE INDEX '|| _inherted_name || '_org_source ON '|| _schema || _inherted_name || ' USING btree (source_id, org_id)';

            END IF;

            IF NOT EXISTS (SELECT 0 FROM pg_proc p, pg_namespace s WHERE pronamespace = s.oid AND p.proname = 'partition_insert_' || _inherted_name AND s.nspname = 'schedule') THEN
                EXECUTE 'CREATE OR REPLACE FUNCTION schedule.partition_insert_' || _inherted_name || '(r ' || TG_TABLE_NAME || ') RETURNS int AS $FUNC$' ||
                    'BEGIN ' ||
                    'INSERT INTO ' || _schema || _inherted_name || ' SELECT r.*; ' ||
                    'RETURN 1;'||
                    'END $FUNC$ LANGUAGE plpgsql VOLATILE';
            END IF;

            --вставляем записи в унаследованную таблицу
            EXECUTE 'SELECT schedule.partition_insert_' || _inherted_name || '($1)' USING NEW;

            END IF;

            --отменяем вставку в мастер таблицу
            RETURN NULL;

            END;
$$;

