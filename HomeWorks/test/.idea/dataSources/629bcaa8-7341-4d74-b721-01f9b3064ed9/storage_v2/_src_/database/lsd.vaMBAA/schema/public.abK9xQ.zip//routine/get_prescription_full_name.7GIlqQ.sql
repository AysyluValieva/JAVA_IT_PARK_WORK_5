CREATE FUNCTION get_prescription_full_name(integer)
  RETURNS character varying
LANGUAGE plpgsql
AS $$
declare
    fullName varchar;
begin
    select
        coalesce(s.name, sp.name)||
        coalesce(nullif(', '||
            array_to_string(array(
                select h.name_trade||' '||c.count||' '||m.mnemocode
                from md_prescription_consumable pc
                  inner join mc_inv_consumable c on c.id = pc.id
                  left join cmn_measure m on c.measure_id = m.id
                  left join inv_holding h on c.holding_id = h.id
                where prescription_id = p.id
                ), ', '), ', '), '')||
        coalesce(nullif(', '||get_text_representation_period(p.period_unit_id, p.period_count), ', '), '')
    from
        md_prescription p into fullName
        left join sr_srv_prototype sp on sp.id = p.prototype_id
        left join sr_service s on s.id = p.service_type_id
        
    where p.id = $1;

    return fullName;
end;
$$;

