CREATE VIEW v_age_category AS
  SELECT 1 AS id,
    '0-17 лет'::text AS name,
    1 AS gender_id,
    'Мужской'::text AS gender_name
UNION
 SELECT 2 AS id,
    '18-59 лет'::text AS name,
    1 AS gender_id,
    'Мужской'::text AS gender_name
UNION
 SELECT 3 AS id,
    '60 лет и более'::text AS name,
    1 AS gender_id,
    'Мужской'::text AS gender_name
UNION
 SELECT 4 AS id,
    '0-17 лет'::text AS name,
    2 AS gender_id,
    'Женский'::text AS gender_name
UNION
 SELECT 5 AS id,
    '18-54 лет'::text AS name,
    2 AS gender_id,
    'Женский'::text AS gender_name
UNION
 SELECT 6 AS id,
    '55 лет и более'::text AS name,
    2 AS gender_id,
    'Женский'::text AS gender_name;

