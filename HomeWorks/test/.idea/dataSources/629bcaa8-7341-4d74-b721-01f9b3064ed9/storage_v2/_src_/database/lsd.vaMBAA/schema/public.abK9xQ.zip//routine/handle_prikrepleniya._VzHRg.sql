CREATE FUNCTION handle_prikrepleniya()
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
	br tambov_loader_prik_src%rowtype;
begin

end;
$$;

