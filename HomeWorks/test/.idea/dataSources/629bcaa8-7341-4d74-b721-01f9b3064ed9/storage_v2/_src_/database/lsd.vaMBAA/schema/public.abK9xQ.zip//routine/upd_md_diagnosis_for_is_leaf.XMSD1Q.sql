CREATE FUNCTION upd_md_diagnosis_for_is_leaf()
  RETURNS void
LANGUAGE plpgsql
AS $$
begin
update md_diagnosis m1 set is_leaf = true
where not exists(select 1 from md_diagnosis where parent_id=m1.id and mdm_table_record__is_actual('md_diagnosis', id::varchar)=true)
and m1.parent_id is not null
and mdm_table_record__is_actual('md_diagnosis', m1.id::varchar)=true;
end;
$$;

