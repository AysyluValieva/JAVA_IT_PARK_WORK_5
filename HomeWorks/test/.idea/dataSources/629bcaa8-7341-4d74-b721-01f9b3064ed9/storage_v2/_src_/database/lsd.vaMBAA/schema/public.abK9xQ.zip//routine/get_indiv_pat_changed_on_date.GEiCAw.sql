CREATE FUNCTION get_indiv_pat_changed_on_date(date)
  RETURNS TABLE(id integer)
STABLE
STRICT
LANGUAGE SQL
AS $$
SELECT id FROM public.pim_individual WHERE aud_when > $1 UNION SELECT id FROM public.pci_patient WHERE aud_when > $1;
$$;

