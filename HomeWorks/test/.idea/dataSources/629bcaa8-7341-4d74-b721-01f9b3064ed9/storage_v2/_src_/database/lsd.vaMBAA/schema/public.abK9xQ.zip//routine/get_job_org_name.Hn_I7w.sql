CREATE FUNCTION get_job_org_name(individual_id integer)
  RETURNS text
LANGUAGE plpgsql
AS $$
declare
            begin
                return(select coalesce(o.short_name, ' ') || ',' || coalesce(pj.job_name,' ') from pim_organization o
                join pci_patient_job pj on (o.id = pj.organization_id and pj.patient_id = individual_id)
                where pj.is_main_job = true AND (pj.to_dt IS NULL OR pj.to_dt > CURRENT_DATE)
                limit 1);
            end;
$$;

