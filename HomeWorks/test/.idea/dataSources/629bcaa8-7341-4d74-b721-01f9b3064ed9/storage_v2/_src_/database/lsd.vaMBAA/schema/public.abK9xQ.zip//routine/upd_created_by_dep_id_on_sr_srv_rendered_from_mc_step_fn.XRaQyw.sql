CREATE FUNCTION upd_created_by_dep_id_on_sr_srv_rendered_from_mc_step_fn()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
                        IF  TG_OP = 'UPDATE'
                        THEN
                            UPDATE sr_srv_rendered ssr
                            SET _created_by_dep_id = NEW._department_id WHERE new.id = ssr.md_step_id;
                        END IF;
                        RETURN NULL;
                    END;
$$;

