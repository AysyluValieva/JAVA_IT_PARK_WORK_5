CREATE FUNCTION typing_validate(integer, json)
  RETURNS SETOF record
LANGUAGE plpgsql
AS $$
DECLARE
            v text;
            validations_codes text[];
            BEGIN
            validations_codes := ARRAY
            [
            'v1'
            ];
            END;
$$;

