CREATE FUNCTION email_log_hidepass_tg_tf()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
            IF NEW.text ~* 'пароль' THEN NEW.text := 'СОДЕРЖАНИЕ ПИСЬМА СКРЫТО.'; END IF;
            RETURN NEW;
        END;
$$;

