CREATE VIEW v_nz_services_categories AS
  SELECT sp.id,
    concat(sp.code, (' '::text || (sp.name)::text)) AS prototype_name
   FROM sr_srv_prototype sp
  ORDER BY (concat(sp.code, (' '::text || (sp.name)::text)));

