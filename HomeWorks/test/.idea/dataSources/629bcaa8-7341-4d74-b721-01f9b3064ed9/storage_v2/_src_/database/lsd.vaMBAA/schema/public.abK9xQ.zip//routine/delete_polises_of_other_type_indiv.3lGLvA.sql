CREATE FUNCTION delete_polises_of_other_type_indiv(_polis pim_individual_doc, _id integer)
  RETURNS text[]
LANGUAGE plpgsql
AS $$
declare
	_r pim_individual_doc%rowtype;
	cnt int;
	_code text;
	_del text;
	_msg text[];
begin
	_msg := _msg || 'Удаляю полисы других типов у физ лица'::text;
	select count(*) into cnt from tambov_loader_ident_download_polis where id_pac = _polis.indiv_id;

	if cnt = 1
	then 
		_msg := _msg || 'В XML документе указан только один полис у этого физ лица'::text;
		
		select "name" into _code from pim_doc_type where id = _polis.type_id;
		select string_agg("name", ' ,') into _del from pim_doc_type where id <> _polis.type_id and code in ('MHI_UNIFORM', 'MHI_OLDER', 'MHI_TEMP');
		
		_msg := _msg || concat('Тип полиса ' , _code)::text || concat('Ищу полисы с типами ', _del)::text;
						
		if exists (
				select 1 from pim_individual_doc pid join pim_doc_type pdt on pid.type_id = pdt.id 
				where pdt.code in ('MHI_TEMP', 'MHI_OLDER', 'MHI_UNIFORM') 
					and pid.indiv_id = _polis.indiv_id
					and pid.type_id <> _polis.type_id
					and pid.id <> _polis.id)
		then 
			for _r in 
					select * from pim_individual_doc pid join pim_doc_type pdt on pid.type_id = pdt.id 
					where pdt.code in ('MHI_TEMP', 'MHI_OLDER', 'MHI_UNIFORM') 
						and pid.indiv_id = _polis.id 
						and pid.id <> _polis.id
						and pid.type_id <> _polis.type_id
			loop
				_msg := _msg || 'Удаляю полис'::text || row_to_json(_r)::text;
				perform delete_document_by_id(_r.id);
			end loop;
				_msg := _msg || 'Удаление полисов других типов завершено'::text;
		else
			_msg := _msg || concat('Полисов c типами ', _del, ' у физ лица не найдено')::text;
		end if;
	else		
		_msg := _msg || 'В XML документе указано более одного полиса у этого физ лица'::text || 'Пропускаю удаление полисов других типов у этого физ лица'::text;
	end if;
	return _msg;
end;
$$;

