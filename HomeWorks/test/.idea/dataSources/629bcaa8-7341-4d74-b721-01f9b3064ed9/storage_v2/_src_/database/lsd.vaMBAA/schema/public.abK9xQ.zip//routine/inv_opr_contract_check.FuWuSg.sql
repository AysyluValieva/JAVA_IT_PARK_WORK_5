CREATE FUNCTION inv_opr_contract_check()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
declare
            v_id int;
            v_is_contract_unique inv_opr_type.is_contract_unique%type;
            v_cnt int;
            begin
            case TG_RELNAME
            when 'inv_opr' then
            select is_contract_unique into v_is_contract_unique from inv_opr_type where id = new.opr_type_id;
            if v_is_contract_unique is not null and v_is_contract_unique and new.contract_id is not null then
            select id into v_id from inv_opr o where contract_id = new.contract_id limit 1;
            if found and v_id is not null then
            raise sqlstate 'ZR002' using message='opr.id='||v_id;
            end if;
            end if;
            when 'inv_opr_type' then
            if new.is_contract_required is not null and new.is_contract_required then
            select count(1) into v_cnt from inv_opr where opr_type_id = new.id and contract_id is null;
            if v_cnt != 0 then
            raise sqlstate 'ZR001'; -- contract required, but operations without contracts exists
            end if;
            end if;
            if new.is_contract_unique is not null and new.is_contract_unique and (old.is_contract_unique is null or not
            old.is_contract_unique) then
            select contract_id into v_id from inv_opr where opr_type_id = new.id and contract_id is not null group by
            contract_id having count(1) > 1 limit 1;
            if found and v_id is not null then
            raise sqlstate 'ZR002' using message = 'contract.id='||v_id; -- contract uniqueness failed
            end if;
            end if;
            end case;
            return new;
            end;
$$;

