CREATE FUNCTION get_mes_days(mes_id integer)
  RETURNS character varying
LANGUAGE plpgsql
AS $$
declare
    mesDuration character varying := '';
    duration record;
begin
    for duration in
          (
            select mcr.name, md.duration, md.delta from mc_mes_duration md 
            left outer join mc_care_regimen mcr on mcr.id = md.care_regimen_id      
            where md.md_mes = mes_id
          )

    loop
       if mesDuration <> '' then
          mesDuration := mesDuration || '; ';
       end if;

       if duration.delta is not null then 
       mesDuration := mesDuration || duration.name || ':' || duration.duration || '-' || (duration.delta + duration.duration);
       else mesDuration := mesDuration || duration.name || ':' || duration.duration;
       end if;
      
    end loop;
    return mesDuration;

end;
$$;

