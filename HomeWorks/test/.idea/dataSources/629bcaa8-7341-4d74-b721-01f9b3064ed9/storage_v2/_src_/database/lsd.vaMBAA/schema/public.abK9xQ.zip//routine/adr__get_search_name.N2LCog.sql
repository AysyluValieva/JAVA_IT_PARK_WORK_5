CREATE FUNCTION adr__get_search_name(param_id integer)
  RETURNS character varying
STRICT
LANGUAGE plpgsql
AS $$
BEGIN
     RETURN (select adr__get_element_as_text(param_id, '(1,f,0)(2,f,0)(3,f,0)(4,f,0)(5,f,0)(6,f,0)(7,f,0)(8,f,0)(9,f,0)'));
  END;
$$;

