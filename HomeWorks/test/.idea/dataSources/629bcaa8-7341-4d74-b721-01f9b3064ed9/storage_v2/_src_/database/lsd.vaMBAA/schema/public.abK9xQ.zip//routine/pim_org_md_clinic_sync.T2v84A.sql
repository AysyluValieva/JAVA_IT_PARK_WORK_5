CREATE FUNCTION pim_org_md_clinic_sync()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
            update md_clinic mc set full_name=po.full_name,short_name=po.short_name,reg_dt=po.reg_dt ,parent_id=po.parent_id,close_dt=po.close_dt
            from (select id,full_name,short_name,reg_dt,parent_id,close_dt from pim_organization where id=NEW.id) po where mc.id=NEW.id;
            RETURN new;
            END;
$$;

