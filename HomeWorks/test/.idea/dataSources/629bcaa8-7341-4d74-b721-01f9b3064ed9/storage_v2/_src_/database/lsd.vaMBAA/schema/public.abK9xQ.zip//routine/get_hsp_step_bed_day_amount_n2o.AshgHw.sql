CREATE FUNCTION get_hsp_step_bed_day_amount_n2o(stepid integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
                    r record;
                    excluded_days integer = 0;
                    duration integer = 0;
                    outcome_date date = current_date;
                    days_off_count integer = 0;
                    algorithm_id integer = 0;
                begin

                    select
                        s.id, s.hsp_department_id, s.hsp_previous_id, s.hsp_bed_days_amount, s.hsp_days_comp_algo_id, s.hsp_missed_days_amount, s.admission_date, s.outcome_date, s._clinic_id as clinic_id, cra.days_comp_algo_id as algo
                        into r
                    from mc_step s
                        inner join mc_case c on c.id = s.case_id
                        left join mc_care_regimen_algo cra on cra.regimen_id = s.regimen_id
                        where s._case_mode_id = 2 and s.id = stepId;


                        if (r.outcome_date is not null) then outcome_date = r.outcome_date; else outcome_date = current_date; end if;

                        if (outcome_date < r.admission_date or r.hsp_previous_id is null) then
                            return 0;
                        end if;

                        if (r.hsp_missed_days_amount is not null) then excluded_days = r.hsp_missed_days_amount; end if;
                        if (r.hsp_days_comp_algo_id is not null) then
                            algorithm_id = r.hsp_days_comp_algo_id;
                        else
                            if(r.algo is not null) then algorithm_id = r.algo;
                            else algorithm_id = 1;
                            end if;
                        end if;

                        if (algorithm_id = 4) then
                           select count(osh) into days_off_count from sr_org_shift osh
                           join sr_schedule_org so on so.id = osh.schedule_org_id
                           where
                                (so.department_id = r.hsp_department_id
                                or (so.org_id = r.clinic_id and so.department_id is null and not (exists (select 1 from sr_org_shift osh join sr_schedule_org so on so.id = osh.schedule_org_id where so.department_id = r.hsp_department_id and (osh.date >= r.admission_date and osh.date <= outcome_date)))))
                                and (osh.date >= r.admission_date and osh.date <= outcome_date) and osh.time_type_id = 2;
                           excluded_days = excluded_days + days_off_count;
                        end if;

                        duration = outcome_date - r.admission_date - excluded_days;
                        if (algorithm_id = 2 or algorithm_id = 4 or (algorithm_id = 3 and r.admission_date = outcome_date)) then
                          duration = duration + 1;
                        end if;
                    
                    return duration;
                end;
$$;

