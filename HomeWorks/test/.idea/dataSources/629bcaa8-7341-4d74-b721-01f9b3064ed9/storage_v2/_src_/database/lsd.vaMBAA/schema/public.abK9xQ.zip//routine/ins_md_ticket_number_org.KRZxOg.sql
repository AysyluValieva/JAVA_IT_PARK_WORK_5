CREATE FUNCTION ins_md_ticket_number_org()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
declare
            var_org_id integer;
            begin
            if tg_op = 'INSERT' and new.ticket_number is not null then
            select org_id into var_org_id from sr_res_group where id = new.executor_id;
            if var_org_id is not null then
            insert into md_ticket_number_org (id, org_id, bdate, ticket_number)
            values (new.id, var_org_id, new.bdatetime::date, new.ticket_number);
            end if;
            end if;
            return new;
            end;
$$;

