CREATE VIEW inv_reg_cert_status_data_v AS
  SELECT rc.id,
    rc.md_holding_id,
    rc.code,
    rc.num,
    rc.reg_dt,
    rc.reg_org_id,
    rc.composition,
    rc.pharm_action,
    rc.type_id,
    rc.issue_org_id,
    rcsd5.dt,
    rcsd5.status_id
   FROM (inv_reg_cert rc
     LEFT JOIN ( SELECT rcsd.reg_cert_id,
            rcsd.dt,
            rcsd.status_id
           FROM inv_reg_cert_status_data rcsd
          WHERE (rcsd.id = ( SELECT max(rcsd2.id) AS max
                   FROM inv_reg_cert_status_data rcsd2
                  WHERE ((rcsd2.reg_cert_id = rcsd.reg_cert_id) AND (rcsd2.dt = ( SELECT max(rcsd3.dt) AS max
                           FROM inv_reg_cert_status_data rcsd3
                          WHERE (rcsd3.reg_cert_id = rcsd2.reg_cert_id))))))) rcsd5 ON ((rc.id = rcsd5.reg_cert_id)));

