CREATE FUNCTION log_a(p_msg character varying, p_lvl character varying)
  RETURNS void
LANGUAGE plpgsql
AS $$
begin
                insert into log_trace(id, logging_datetime, logging_level, message)
                values(nextval('log_trace_seq'), clock_timestamp(), p_lvl, p_msg);
            end;
$$;

