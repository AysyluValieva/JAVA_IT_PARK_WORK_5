CREATE FUNCTION upd_visit_department_id_at_mc_step_fn()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE
  departmentId INTEGER;
BEGIN
  SELECT p.department_id INTO departmentId FROM pim_employee_position ep
  INNER JOIN pim_position p ON p.id = ep.position_id
  WHERE ep.id = NEW._responsible_id;

  UPDATE mc_step
  SET _department_id = departmentId WHERE id = new.id;

  RETURN NULL;
END;
$$;

