CREATE FUNCTION get_referral_services_names(referral_id integer)
  RETURNS text
LANGUAGE plpgsql
AS $$
declare
  names text := '';
  referral_service_name text := '';
begin
  for referral_service_name in
          (
		        select coalesce(
		                          (select name from sr_service where id  = md_referral_service.service_id),
		                          (select name from sr_srv_prototype  where id = md_referral_service.service_prototype_id)
            ) from md_referral_service where md_referral_service.referral_id =  $1
          )

    loop
       if names = '' then
          names := referral_service_name;
        elseif (referral_service_name is not null) then
          names := names || ', ' ||referral_service_name;
       end if;
    end loop;
  return names;
end;
$$;

