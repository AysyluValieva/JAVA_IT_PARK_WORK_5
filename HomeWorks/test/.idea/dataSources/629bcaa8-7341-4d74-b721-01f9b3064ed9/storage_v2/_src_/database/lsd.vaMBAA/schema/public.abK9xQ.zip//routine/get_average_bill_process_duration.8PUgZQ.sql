CREATE FUNCTION get_average_bill_process_duration(OUT time10k integer, OUT region text)
  RETURNS record
STABLE
LANGUAGE plpgsql
AS $$
DECLARE
    _r RECORD;
    _n BIGINT := 0;
    _srv_cnt BIGINT := 0;
    _process_time INTEGER := 0;
    _all_speed DECIMAL := 0;
BEGIN
    FOR _r IN
        SELECT
            bill_id, max (date) AS date, (array_agg (user_id ORDER BY date DESC))[1] AS user_id
        FROM 
            fin_bill_status_log
        WHERE
            status_id = 1 AND date <@ tsrange (LOCALTIMESTAMP - '14 days'::INTERVAL, LOCALTIMESTAMP, '[]')
        GROUP BY 1
    LOOP
        IF
            (SELECT status_id IN (1, 2, 3, 4, 5) FROM fin_bill WHERE id = _r.bill_id)
        THEN
            _n := _n + 1;
            _srv_cnt := (SELECT service_count FROM fin_bill_spec WHERE NOT is_correct AND bill_id = _r.bill_id);
            _process_time := 
            coalesce 
            (
                extract 
                (
                    epoch from 
                    (
                        SELECT 
                            age (_r.date, date)
                        FROM 
                            fin_bill_status_log 
                        WHERE 
                            status_id = 7 AND bill_id = _r.bill_id AND user_id = _r.user_id AND date < _r.date
                        ORDER BY age (_r.date, date)
                        LIMIT 1
                    )
                )::BIGINT, 1
            );
            _all_speed := _all_speed + _srv_cnt / _process_time::DECIMAL;
        END IF;
    END LOOP;
    IF
        nullif (_all_speed / _n::DECIMAL, 0) IS NOT NULL
    THEN
        time10k := round (10000 / (_all_speed / _n::DECIMAL));
    END IF;
		--raise notice '% %',_all_speed, _n;
    region := (SELECT value FROM cmn_setting_value WHERE setting_id = 'cz.atria.common.settings.impl.ProductOwnerInfoSettings.regionCode')
    ;
END;
$$;

