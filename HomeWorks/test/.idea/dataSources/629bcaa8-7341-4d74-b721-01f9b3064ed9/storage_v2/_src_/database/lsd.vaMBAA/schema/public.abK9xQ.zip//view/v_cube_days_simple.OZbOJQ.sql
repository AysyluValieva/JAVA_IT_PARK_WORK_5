CREATE VIEW v_cube_days_simple AS
  SELECT cube_days_simple.id,
    cube_days_simple.calendar_date,
    cube_days_simple.year_,
    cube_days_simple.month_of_year,
    cube_days_simple.name_month_of_year
   FROM cube_days_simple;

