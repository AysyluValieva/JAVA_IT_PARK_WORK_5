CREATE FUNCTION mdm_table__get_refbook_version_id(tbl_name character varying)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
  retval integer;
begin

select v.id into retval from mdm_internal_refbook irb join mdm_refbook_version v on irb.id = v.refbook_id
  where v.version is null and irb.table_name = tbl_name;

return retval;

end;
$$;

