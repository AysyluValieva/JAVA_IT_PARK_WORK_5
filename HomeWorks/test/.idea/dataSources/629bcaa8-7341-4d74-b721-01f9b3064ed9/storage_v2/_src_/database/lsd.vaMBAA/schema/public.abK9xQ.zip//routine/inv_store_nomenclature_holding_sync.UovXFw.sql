CREATE FUNCTION inv_store_nomenclature_holding_sync()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
declare
            v_holding_id inv_holding.id%type;
            begin
            case TG_RELNAME
            when 'inv_store_nomenclature' then
            	if new.form_id is not null then
            		if TG_OP = 'UPDATE' and old.form_id is not null and old.form_id != new.form_id then
            			select holding_id into new.holding_id from inv_form where id = new.form_id;
            		else
            			if new.holding_id is not null then
            				-- check - if holding is the same
            				select holding_id into v_holding_id from inv_form where id = new.form_id;
            				if new.holding_id != v_holding_id then
            					raise 'holding defined not correspond. inv_form.holding_id=% inv_store_nomenclature.holding_id=%', v_holding_id, new.holding_id using errcode = 'integrity_constraint_violation';
            				end if;
            			else -- automatically set holding_id by form
            				select holding_id into new.holding_id from inv_form where id = new.form_id;
            			end if;
            		end if;
            	end if;
            when 'inv_form' then
            	if TG_OP = 'UPDATE' and old.holding_id != new.holding_id then
            	update inv_store_nomenclature set holding_id = new.holding_id where form_id = new.id;
            	end if;
            else null;
            end case;
            return new;
            end;
$$;

