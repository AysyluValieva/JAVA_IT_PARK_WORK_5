CREATE FUNCTION insert_temp_polis(npolis text, id_pac integer, stdate date, enddate date, smo_org_id integer, note text)
  RETURNS pim_individual_doc
LANGUAGE SQL
AS $$
insert into pim_individual_doc(id, type_id, issuer_id, issue_dt, expire_dt, indiv_id, "number", note, is_active)
	select 
		nextval('pim_individual_doc_id_seq') as id,
		(select id from pim_doc_type where code='MHI_TEMP') as type_id, 
		$5 as issuer_id, 
		$3 as issue_dt, 
		$4 as expire_dt, 
		$2 as indiv_id, 
		$1 as "number", 	
		$6 as note, 
		case when $4 is null or $4 > current_date then true else false end as is_active
	returning *;
$$;

