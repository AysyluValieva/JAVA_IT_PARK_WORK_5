CREATE FUNCTION sr_scgenerated_from_sr_service_after_update()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
            update sr_scgenerated ss set org_id=s.org_id
            from (
            select aps.id,s.org_id FROM sr_scgenerated aps JOIN sr_service s ON aps.service_id = s.id where s.id=NEW.id)
            s where ss.id=s.id;
            RETURN new;
            END;
$$;

