CREATE FUNCTION copy_visit_data_to_step_tg_tf()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE
                            _app_code TEXT;

                        BEGIN
                            SELECT current_setting('app.source') INTO _app_code;

                            IF ('typing2' <> _app_code AND 'n2o'<>_app_code) THEN
                                _app_code := 'lsd';
                            END IF;

                            IF(SELECT EXISTS(SELECT 1 FROM cmn_app_using_mc_step_only WHERE cmn_app_using_mc_step_only.app_code = _app_code) ) THEN
                                RETURN NEW;
                            END IF;
                            UPDATE mc_step SET
                                plc_goal_id = v.goal_id,
                                plc_initiator_id = v.initiator_id,
                                plc_is_needed = v.is_needed,
                                plc_is_sanitized = v.is_sanitized,
                                plc_is_viewed = v.is_viewed,
                                plc_place_id = v.place_id,
                                plc_type_id = v.type_id,
                                plc_appointment_id = v.appointment_id,
                                plc_planned_date = v.planned_date
                            FROM (SELECT goal_id, initiator_id, is_needed, is_sanitized, is_viewed, place_id, type_id, appointment_id, planned_date  FROM plc_visit WHERE id = NEW.id) v
                        WHERE id = NEW.id;
                        RETURN NEW;
                        END;
$$;

