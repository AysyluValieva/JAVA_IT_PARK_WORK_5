CREATE FUNCTION get_service_tree(in_service_id integer, OUT top_node_id integer, OUT parent_node_id integer, OUT id integer, OUT name character varying, OUT is_required boolean, OUT is_default boolean)
  RETURNS SETOF record
LANGUAGE plpgsql
AS $$
DECLARE
    result record;
begin
    return query
    	with recursive service_node(top_node_id, parent_node_id, id, name, is_required, is_default) as (
		select s.id, null::integer, s.id, s.name, true, true from sr_service s where s.id = in_service_id
		union
		select n.top_node_id, c.complex_id, c.service_id, s.name, coalesce(c.is_required, false), coalesce(c.is_default, false) from sr_srv_composition c, sr_service s, service_node n where  c.service_id = s.id and c.complex_id = n.id
	)
	select * from service_node;
end;
$$;

