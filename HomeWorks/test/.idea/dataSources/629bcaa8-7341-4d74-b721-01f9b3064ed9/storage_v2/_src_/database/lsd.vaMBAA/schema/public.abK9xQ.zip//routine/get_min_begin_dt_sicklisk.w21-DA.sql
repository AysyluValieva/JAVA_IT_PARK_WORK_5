CREATE FUNCTION get_min_begin_dt_sicklisk(ssicklist_id integer)
  RETURNS date
LANGUAGE plpgsql
AS $$
DECLARE
                pparent_id integer;
                min_id integer;
            BEGIN
                pparent_id = null;
                min_id = ssicklist_id;
                select parent_id from md_sicklist where id = ssicklist_id into pparent_id;
                while (pparent_id is not null)
                loop
                    min_id = pparent_id;
                    select parent_id from md_sicklist where id = pparent_id into pparent_id;
                end loop;
                return (select min(from_dt) from md_sicklist_period where sicklist_id = min_id);
            END;
$$;

