CREATE FUNCTION tambov_loader_ident_download_fiodrw()
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
	_row tambov_loader_ident_download_person%rowtype;
	_i pim_individual%rowtype;
	spliter constant text := '---------------------------------------------------------------------------------------------------------------------------------------------------------------------';
	_msg text[];
begin
	for _row in select * from tambov_loader_ident_download_person where fam is not null or im is not null or ot is not null or w is not null or dr is not null and indiv_exists
	loop
		if _row.status <> '0' and _row.source = 'R' then 
			_msg := _msg || 'Обработка записи пропускается'::text || 'Данные переданы в центральный сегмент'::text;
			continue;
		end if;

		select * into _i from pim_individual where id = _row.id_pac;

				_msg := _msg || spliter || 'ФИО начало'::text;
		if _row.fam is null and _row.im is null and _row.ot is null then 
			_msg := _msg || 'ФИО не указано в XML документе'::text || 'Пропускаю обновление ФИО'::text;
		else 
			_msg := _msg || 'Обновляю ФИО'::text || update_fio(_row);
		end if;
		_msg := _msg || 'ФИО завершено'::text;

										_msg := _msg || spliter || 'ДР начало.'::text;
		if _row.dr is null then 
			_msg := _msg || 'ДР не указан в XML документе.'::text || 'Пропускаю обновление ДР'::text;
		else
			_msg := _msg || 'Обновляю ДР'::text;
			if _row.dr <> _i.birth_dt or _i.birth_dt is null then 
				_msg := _msg || 'ДР не совпадает'::text || row_to_json(_i)::text || 'Обновляю ДР'::text;
				update pim_individual set birth_dt = _row.dr where id = _i.id;
			else
				_msg := _msg || 'ДР в БД и XML совпадает'::text || 'Пропускаю обновление'::text;
			end if;
		end if;

		_msg := _msg || 'ДР завершено.'::text;

						_msg := _msg || spliter || 'ПОЛ начало.'::text;
		if _row.w is null then 
			_msg := _msg || 'Пол не указан в XML документе.'::text || 'Пропускаю обновление Пола'::text;
		else
			if  _row.w <> 1 and _row.w <> 2 then 
				_msg := _msg || 'Код пола имеет неверное значение'::text || 'Допустимые значениея 1 и 2'::text;
			else 
				if _row.gender_id is null then
					_msg := _msg || 'Не удалось определить соотвествующий коду в поле W, id пола в БД'::text;
				elsif  _row.gender_id <> _i.gender_id then 
					_msg := _msg || 'Пол не совпадает в XML и БД'::text || row_to_json(_i)::text || 'Обновляю Пол'::text;
					update pim_individual set gender_id = _row.gender_id where id = _i.id;
				else 
					_msg := _msg || 'Пол в XML и БД совпадает'::text || 'Необходимости в обновлении данных нет'::text;
				end if;
			end if;
		end if;
		_msg := _msg || 'Пол завершено.'::text;

		update tambov_loader_ident_download_person set msg = msg || _msg where id = _row.id;
		_msg := null;
	end loop;
end;
$$;

