CREATE FUNCTION get_bed_day_amount_n2o(caseid integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
                    stepId integer;
                    bed_days integer = 0;
                begin

                    for stepId in (select s.id from mc_step s where s.case_id = caseId and s._case_mode_id = 2)
                    loop
                        bed_days = bed_days + get_hsp_step_bed_day_amount_n2o(stepId);
            	    end loop;
            	    return bed_days;

                end;
$$;

