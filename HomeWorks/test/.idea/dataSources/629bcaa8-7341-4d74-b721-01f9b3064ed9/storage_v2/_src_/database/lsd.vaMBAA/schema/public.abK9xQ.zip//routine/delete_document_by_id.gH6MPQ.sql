CREATE FUNCTION delete_document_by_id(id integer)
  RETURNS pim_individual_doc
LANGUAGE SQL
AS $$
with cte as (
		update pim_individual_doc set code_id = null where id = $1 returning code_id
	), ts as (
		delete from pim_indiv_code d using cte where d.id = cte.code_id
	)
	delete from pim_individual_doc where id = $1 returning *
$$;

