CREATE FUNCTION upd_md_diagnosis_for_interval(diag_id integer, level_k integer, par integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
r record;
next_level_k integer;
diag_code text;
begin
select code into diag_code from md_diagnosis where id=$1;
if ($1 is not null and $2 is not null) THEN
update md_diagnosis set parent_id=$3,level=$2 where id = $1 and coalesce(level,-1)<$2;
next_level_k:=$2+1;
for r in select * from md_diagnosis 
where code like '%-%' and substring(code,1,3)>=substring(diag_code,1,3) and substring(code,5,3)<=substring(diag_code,5,3) and id<>$1 
loop
perform upd_md_diagnosis_for_interval(r.id,next_level_k,$1);
end loop;
end if;
end;
$$;

