CREATE FUNCTION count_service_prescribed(integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
            count_service_prescribed integer;
            prescription_data RECORD;
            begin

            count_service_prescribed =1;

            select md_patient_prescription.start_period_date as sdate,
            LEAST(md_patient_prescription.end_period_date, md_patient_prescription.cancel_date) as edate ,
            coalesce(cmn_time_period.code, 'DAY') as code
            from md_prescription into prescription_data
            inner join md_patient_prescription on md_patient_prescription.id = md_prescription.id
            left outer join cmn_time_event on md_prescription.time_event_id = cmn_time_event.id
            left outer join cmn_time_event_period period on period.time_event_id = cmn_time_event.id
            left outer join cmn_time_period on cmn_time_period.id = period.return_period_id
            where md_patient_prescription.start_period_date is not null and md_patient_prescription.end_period_date is
            not null and md_prescription.id = $1;

            IF (prescription_data.code = 'WEEK') THEN
            select count(1) from generate_series(prescription_data.sdate, prescription_data.edate, '1 week'::interval)
            into count_service_prescribed;
            ELSEIF (prescription_data.code = 'MONTH') THEN
            select count(1) from generate_series(prescription_data.sdate, prescription_data.edate, '1 month'::interval)
            into count_service_prescribed;
            ELSEIF (prescription_data.code = 'QUARTER') THEN
            select count(1) from generate_series(prescription_data.sdate, prescription_data.edate, '3 month'::interval)
            into count_service_prescribed;
            ELSEIF (prescription_data.code = 'DAY') THEN
            select count(1) from generate_series(prescription_data.sdate, prescription_data.edate, '1 day'::interval)
            into count_service_prescribed;
            ELSEIF (prescription_data.code = 'YEAR') THEN
            select count(1) from generate_series(prescription_data.sdate, prescription_data.edate, '1 year'::interval)
            into count_service_prescribed;
            ELSEIF (prescription_data.code = 'HALF_YEAR') THEN
            select count(1) from generate_series(prescription_data.sdate, prescription_data.edate, '6 month'::interval)
            into count_service_prescribed;
            END IF;

            return count_service_prescribed;
            end;
$$;

