CREATE FUNCTION get_pim_cert_speciality_name_tree(xid integer)
  RETURNS text
LANGUAGE plpgsql
AS $$
declare
            _id integer;
            _name text;
            begin
            select id, name into _id, _name from (with recursive temp1(id, parent_id, path, cycle, rownum, name) as (
            select o1.id,o1.parent_id,array[o1.id],false,1, text(o1.name) from pim_cert_speciality o1 where o1.id = xid
            union all
            select o2.id, o2.parent_id,path||o2.id,o2.id=any(path),rownum+1, text(o2.name||'/'||temp1.name)
            from pim_cert_speciality o2
            inner join temp1 on (temp1.parent_id = o2.id) and not cycle
            )
            select id, parent_id, rownum, name
            from  temp1 order by rownum desc limit 1) t1;
            return _name;
            end;
$$;

