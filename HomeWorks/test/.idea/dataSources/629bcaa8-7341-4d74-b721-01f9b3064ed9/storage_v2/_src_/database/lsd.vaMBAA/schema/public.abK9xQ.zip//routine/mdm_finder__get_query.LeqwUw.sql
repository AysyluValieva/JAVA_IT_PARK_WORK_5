CREATE FUNCTION mdm_finder__get_query(query character varying, table_name character varying)
  RETURNS character varying
IMMUTABLE
LANGUAGE plpgsql
AS $$
begin
  if query ~ ('(?i)'||table_name||' (on|join|inner|left|where)')
  then
    return regexp_replace(query, table_name||' ', '(select * from '||table_name||' :mdm) '||table_name||' ');
  end if;
  if query ~ (table_name||' \w')
  then
    return regexp_replace(query, table_name||' (\w)', '(select * from '||table_name||' :mdm) \1');
  end if;
  return regexp_replace(query, table_name||'($| |,|\n)', '(select * from '||table_name||' :mdm) '||table_name||'\1');
end;
$$;

