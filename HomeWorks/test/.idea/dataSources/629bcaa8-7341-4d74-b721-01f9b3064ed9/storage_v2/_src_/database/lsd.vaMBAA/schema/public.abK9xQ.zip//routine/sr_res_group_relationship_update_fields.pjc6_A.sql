CREATE FUNCTION sr_res_group_relationship_update_fields()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE
                is_system boolean;
            BEGIN
                select g.is_system into is_system from sr_res_group g where g.id = NEW.group_id;
                NEW._is_system := is_system;

                RETURN NEW;
            END;
$$;

