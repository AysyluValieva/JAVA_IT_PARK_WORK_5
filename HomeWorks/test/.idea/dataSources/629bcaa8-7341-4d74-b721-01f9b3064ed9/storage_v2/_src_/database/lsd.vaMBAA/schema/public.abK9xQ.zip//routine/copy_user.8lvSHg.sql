CREATE FUNCTION copy_user(_user_1 character varying, _user_2 character varying, OUT _user_cur character varying, OUT _pass character varying)
  RETURNS record
LANGUAGE plpgsql
AS $$
declare
_user_cur_id integer;
_user_1_id integer;
_pass_md5 text;
r record; 
begin 
if not exists(select 1 from sec_user where upper(login::text)=upper(_user_1)) then raise exception 'Пользователь % не существует!',_user_1; end if;
_user_cur='novus-'||_user_2;
_user_1_id=(select id from sec_user where upper(login::text)=upper(_user_1));  --поиск юзера по логину
if exists(select 1 from sec_user where upper(login::text)=upper(_user_cur)) then 
_user_cur_id=(select id from sec_user where upper(login::text)=upper(_user_cur));
delete from sec_user_role where user_id=_user_cur_id;--удаляем роли
delete from sec_user_org where user_id=_user_cur_id;--удаляем доступные организации
_pass='Без изменений';--пароль не меняем
else
_pass=random_string(8);--создаем пароль
_pass_md5=md5(_pass);--хешируем
insert into sec_user(id,cr_dt,comment,login,password) select nextval('sec_user_seq'),localtimestamp,'copy_user',_user_cur,_pass_md5;--создаем пользователя
_user_cur_id=currval('sec_user_seq');
insert into sec_passhash_history(id,user_id,hash,issue_date) select nextval('sec_passhash_history_seq'),_user_cur_id,_pass_md5, current_date;--запись о пароле
insert into pim_party(id,type_id) select nextval('pim_party_id_seq'),id from pim_party_type where name='физическое лицо';--создаем контрагента ФЛ
insert into pim_individual(id) select currval('pim_party_id_seq');--заготовка для ФЛ
insert into sec_user_party(id,party_id) select _user_cur_id,currval('pim_party_id_seq');--связываем контрагента и юзера
insert into sec_user_party_org select _user_cur_id;
end if;  
insert into sec_user_org (id, user_id, org_id) select nextval ('sec_user_org_seq'), _user_cur_id, org_id from sec_user_org where user_id=_user_1_id;--добавление ЛПУ созданному юзеру
for r in select * from sec_user_role where user_id=_user_1_id order by id loop--добавление ролей юзеру
insert into sec_user_role (id,role_id,user_id) select nextval ('sec_user_role_seq'),r.role_id,_user_cur_id;
insert into sec_user_role_ext(id) select currval('sec_user_role_seq');
insert into sec_user_role_party (id,user_role_id,party_id) 
select nextval('sec_user_role_party_seq'),currval ('sec_user_role_seq'),party_id 
from sec_user_role_party where user_role_id=r.id;--проставляем доступ пользователю, в доступных ему ЛПУ
end loop;
return;
end
$$;

