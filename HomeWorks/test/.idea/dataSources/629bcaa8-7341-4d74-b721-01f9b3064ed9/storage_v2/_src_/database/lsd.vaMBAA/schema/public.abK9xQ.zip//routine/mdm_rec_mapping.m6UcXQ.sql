CREATE FUNCTION mdm_rec_mapping(ref_map integer, name_flag boolean, code_flag boolean)
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
r record;
int_ref integer;
targ_ref integer;
tab text;
rec_id integer;
BEGIN
if ($2='f' and $3='f') then raise exception 'Необходимо выбрать хотя бы один признак сопоставления'; end if;
if (select id from mdm_refbook_mapping where id=$1) is NULL then raise exception 'В таблице mdm_refbook_mapping не существует записи с id = %!',$1; end if;

select ir.table_name,rm.target_refbook_id into tab,targ_ref 
from mdm_internal_refbook ir join
mdm_refbook_version rv on rv.refbook_id=ir.id join
mdm_refbook_mapping rm on rv.id=rm.target_refbook_id
where rm.id=$1;

for r in EXECUTE 'select * from '|| tab ||' where id not in(select source_record_id::integer from mdm_record_mapping where source_refbook_id= '|| targ_ref ||') order by id' loop
raise notice 'Запись из внутреннего справочника - %, - %',r.id,r.name;
if ($2='t' and $3='f') then
rec_id:=(select record_id from mdm_record_column mrc left JOIN
mdm_refbook_column mrco on mrc.column_id=mrco.id
where mrco.refbook_version_id=(select source_refbook_id from mdm_refbook_mapping where id=$1) 
and regexp_replace(lower(mrc.value), '\W', '', 'g')=regexp_replace(lower(r.name), '\W', '', 'g') limit 1);
end if;
if ($2='f' and $3='t') then
rec_id:=(select record_id from mdm_record_column mrc left JOIN
mdm_refbook_column mrco on mrc.column_id=mrco.id
where mrco.refbook_version_id=(select source_refbook_id from mdm_refbook_mapping where id=$1) 
and regexp_replace(lower(mrc.value), '\W', '', 'g')=regexp_replace(lower(r.code::text), '\W', '', 'g') limit 1);
end if;
if ($2='t' and $3='t') then
rec_id:=(select record_id_1 from (
select record_id as record_id_1 from mdm_record_column mrc left JOIN
mdm_refbook_column mrco on mrc.column_id=mrco.id
where mrco.refbook_version_id=(select source_refbook_id from mdm_refbook_mapping where id=$1) 
and regexp_replace(lower(mrc.value), '\W', '', 'g')=regexp_replace(lower(r.name), '\W', '', 'g')
) as t join (select record_id as record_id_2 from mdm_record_column mrc left JOIN
mdm_refbook_column mrco on mrc.column_id=mrco.id
where mrco.refbook_version_id=(select source_refbook_id from mdm_refbook_mapping where id=$1) 
and regexp_replace(lower(mrc.value), '\W', '', 'g')=regexp_replace(lower(r.code::text), '\W', '', 'g')
) as tt on t.record_id_1=tt.record_id_2 limit 1);
end if;
if (rec_id is not null) THEN
raise notice 'Запись добавлена: target_record_id - %, source_record_id - %, source_refbook_id - %',rec_id,r.id,targ_ref;
insert into mdm_record_mapping (target_record_id,source_record_id,source_refbook_id) values(rec_id,r.id,targ_ref);
else raise notice 'Соответсвие не найдено';
end if;
end loop;
END;
$$;

