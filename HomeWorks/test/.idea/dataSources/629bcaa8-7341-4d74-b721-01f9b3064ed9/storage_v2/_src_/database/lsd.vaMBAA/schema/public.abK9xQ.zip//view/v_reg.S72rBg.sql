CREATE VIEW v_reg AS
  SELECT mv_reg.clinic_id,
    mv_reg.district_id,
    mv_reg.age_category_id,
    mv_reg.gender_id,
    mv_reg.type_id,
    mv_reg.social_group_id,
    mv_reg.calendar_date,
    mv_reg.democube_days_id,
    mv_reg.registration_cnt,
    mv_reg.patient_cnt,
    mv_reg.new_registration_cnt,
    mv_reg.new_patient_cnt,
    mv_reg.unregistration_cnt,
    mv_reg.unreg_patient_cnt
   FROM mv_reg;

