CREATE FUNCTION gen_kaluga_reg_district_address_linear(_type_code text, _profile_code text)
  RETURNS boolean
LANGUAGE plpgsql
AS $$
declare 
	i integer;
    r record;
begin
	drop table if exists kaluga_reg_district_address_linear1;

	
	-- отбираем все участки где не указан конкретный список домов
	create unlogged table kaluga_reg_district_address_linear1 with (autovacuum_enabled=false) as
	select 
		ma.id, ma.district_id, ma.address_id, ma.building_pattern, null::int as house_id, null::text as house_num, null::text[] nums
	from md_district_address ma 
	join md_clinic_district md on ma.district_id = md.id
	join md_clinic_separation ms on ms.id = md.separation_id
	join md_reg_type mt on mt.id = ms.reg_type_id
	join md_profile mp on mp.id = ms.profile_id
	where (building_pattern is null or trim(building_pattern) = '' or upper(building_pattern) = 'ВСЕ') and mp.code = _profile_code and mt.code = _type_code;

	--удаляем дубли
	--случаются ошибочно продублированы адресные элементы участков 
	--особенно там где много адресных элементов
	with cte as (
		select (array_agg(id order by id))[1] as id from kaluga_reg_district_address_linear1 
		group by district_id, address_id having count(*) > 1 
	)
	delete from kaluga_reg_district_address_linear1 where id in (select id from cte);

	--создаю список всех возможных адресов домов 
	--у которых в иерархии есть адресные элементы найденные на пред.этапе
	drop table if exists kaluga_reg_district_address_linear2;
	create unlogged table kaluga_reg_district_address_linear2 with (autovacuum_enabled=false) as 
	select lin.id, lin.district_id, lin.address_id, lin.building_pattern, q.h_id as house_id, q.h_num as house_num from kaluga_reg_district_address_linear1 lin, lateral (
		with recursive cte as (
			select * from address_element where parent_id = lin.address_id
			union 
			select ae.* from address_element ae join cte on cte.id = ae.parent_id
		)
		select cte.id as h_id, cte."name" as h_num from cte Join address_element_type aet on cte.type_id = aet.id where upper(aet."name") = upper('ДОМ')
	) q;

	-- отбираю участки у которых указаны списки домов, и/или интервалы домов
	drop table if exists kaluga_reg_district_address_linear3;
	
	create unlogged table kaluga_reg_district_address_linear3 with (autovacuum_enabled=false) as 
	select 
		ma.id, address_id, district_id, regexp_split_to_table(building_pattern,',') building_pattern, null::int house_id, null::text house_num, null::text[] nums
	from md_district_address ma
	join md_clinic_district md on ma.district_id = md."id"
	join md_clinic_separation ms on ms.id = md.separation_id
	join md_reg_type mt on mt.id = ms.reg_type_id
	join md_profile mp on mp.id = ms.profile_id
	where not(building_pattern is null or trim(building_pattern) = '' or upper(building_pattern) = 'ВСЕ') and mp.code = _profile_code and mt.code = _type_code;

	--добавляем уникальное поле т.к. после вызова regexp_split_to_table появляется множество записей с одинаковым id полем
	alter table kaluga_reg_district_address_linear3 add column _id serial;
	--pdate kaluga_reg_district_address_linear2 set nums = array_agg(array[building_pattern]);


	--список домов как массив входящих в адресные элементы для указанных через тире
	with cte as (
		select _id, building_pattern, (regexp_split_to_array(building_pattern, '-'))[1]::int s, (regexp_split_to_array(building_pattern, '-'))[2]::int e
		from kaluga_reg_district_address_linear3 where building_pattern ~ '^\d+-\d+$'
	), mte as (
		select cte._id, q from cte, lateral (select array_agg(m::text) q from generate_series(s, e) m) q
	)
	update kaluga_reg_district_address_linear3 lin set nums = q from mte where mte._id = lin._id;

	--для четных номеров домов
	with cte as (
		select _id, replace(replace(replace(building_pattern,'Ч',''),'(',''),')','') building_pattern
		from kaluga_reg_district_address_linear3
		where position('-' in building_pattern) != 0 and building_pattern ~ '^Ч\(\d*-\d*\)$'
	), mte as (
		select *, (regexp_split_to_array(building_pattern, '-'))[1]::int s, (regexp_split_to_array(building_pattern, '-'))[2]::int e from cte 
	), vze as (
		select mte._id, q from mte, lateral (select array_agg(g::text) q from generate_series(s, e, 2) g) v
	)
	update kaluga_reg_district_address_linear3 lin set nums = q from vze where vze._id = lin._id;

	--для нечетных чисел 
	with cte as (	
		select _id, address_id, district_id, replace(replace(replace(building_pattern,'Н',''),'(',''),')','') building_pattern
		from kaluga_reg_district_address_linear3
		where position('-' in building_pattern) != 0 and building_pattern ~ '^Н\(\d*-\d*\)$'
	), mte as (
		select _id, building_pattern, (regexp_split_to_array(building_pattern, '-'))[1]::int s, (regexp_split_to_array(building_pattern, '-'))[2]::int e from cte
	), gte as (
		select mte._id, mte.building_pattern, v from mte, lateral (select array_agg(m::text) as v from generate_series(s, e, 2) m) q
	)
	update kaluga_reg_district_address_linear3 lin set nums = v from gte where gte._id = lin._id;

	--проставляю там где шаблон разбивки указывает на номер дома 
	update kaluga_reg_district_address_linear3 lin set nums = array[building_pattern] where nums is  null;

	drop table if exists kaluga_reg_district_address_linear4;
	create unlogged table kaluga_reg_district_address_linear4 (
		id int, district_id int, address_id int, building_pattern text, house_id int, house_num text, nums text [], _id int) 
	with (autovacuum_enabled=false);
	
	insert into kaluga_reg_district_address_linear4 (id, district_id, address_id, building_pattern, house_id, house_num, nums, _id) 
	select lin.id, lin.district_id, lin.address_id, lin.building_pattern, q.h_id, q.h_num, lin.nums, lin._id 
	from kaluga_reg_district_address_linear3 lin, lateral (
		with recursive cte as (
			select * from address_element where parent_id = lin.address_id
			union 
			select ae.* from address_element ae join cte on cte.id = ae.parent_id
		)
		select cte.id as h_id, cte."name" as h_num from cte Join address_element_type aet on cte.type_id = aet.id where upper(aet."name") = upper('ДОМ')
	) q;
	
	--сверяю вхождение номера дома на в массив возможных домов адресного элемента
	--удаляю те адреса номера возможных адресов домов не попали в карту разбивки
	delete from kaluga_reg_district_address_linear4 where not (house_num = any(nums));
	
	drop table if exists kaluga_reg_district_address_linear;
	alter table kaluga_reg_district_address_linear2 rename to kaluga_reg_district_address_linear;
	insert into kaluga_reg_district_address_linear(id, district_id, address_id, building_pattern, house_id, house_num)
	select 
		id, 
		district_id, 
		address_id, 
		building_pattern, 
		house_id, 
		house_num
	from kaluga_reg_district_address_linear4;

	alter table kaluga_reg_district_address_linear add column _id serial primary key;
	create index on kaluga_reg_district_address_linear using btree(house_id);
	create index on kaluga_reg_district_address_linear using btree(district_id);

	analyze kaluga_reg_district_address_linear;
	
	drop table if exists kaluga_reg_district_address_linear1;
 	drop table if exists kaluga_reg_district_address_linear3;
 	drop table if exists kaluga_reg_district_address_linear4;
	return true;
end
$$;

