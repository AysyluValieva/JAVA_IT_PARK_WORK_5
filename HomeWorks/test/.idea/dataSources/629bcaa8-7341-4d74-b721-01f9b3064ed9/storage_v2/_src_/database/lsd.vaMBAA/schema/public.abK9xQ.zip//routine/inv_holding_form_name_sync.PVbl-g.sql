CREATE FUNCTION inv_holding_form_name_sync()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
declare
v_is_form_full_name_changed boolean := false;
v_form_id inv_form.id%type;
begin
case TG_RELNAME
when 'inv_holding' then
   if TG_OP = 'UPDATE' and new.name_trade != old.name_trade then
      update inv_form
      set full_name = new.name_trade || coalesce(' '||get_form_full_name(id), '')
      where holding_id = new.id;
   end if;
when 'inv_form' then
   case TG_OP
   when 'UPDATE' then
      if new.form_type_id != old.form_type_id or coalesce(new.rem, '?') <> coalesce(old.rem, '?') then
         new.form_full_name := (select short_name from inv_form_type where id = new.form_type_id)||coalesce(new.rem||' ','')||' '||get_form_param_full_name(new.id);
         v_is_form_full_name_changed := true;
      end if;
   when 'INSERT' then
      new.form_full_name := (select short_name from inv_form_type where id = new.form_type_id)||coalesce(new.rem||' ','');
      v_is_form_full_name_changed := true;
   else null;
   end case;
   if v_is_form_full_name_changed then
      new.full_name = (select name_trade from inv_holding where id = new.holding_id)||' '||new.form_full_name;
   end if;
when 'inv_form_param_value' then
   if TG_OP in ('INSERT', 'UPDATE') then v_form_id := new.form_id;
   elsif TG_OP = 'DELETE' then v_form_id := old.form_id;
   end if;
   update inv_form set form_full_name = get_form_full_name(v_form_id) where id = v_form_id;
   update inv_form set full_name = (select name_trade from inv_holding where id = (select holding_id from inv_form where id = v_form_id))||' '||form_full_name where id = v_form_id;
else null;
end case;
return new;
exception when others then raise notice '%:%', sqlstate, sqlerrm;
return new;
end;
$$;

