CREATE MATERIALIZED VIEW mv_mo_activity AS WITH dual AS (
         SELECT 1 AS id
        ), f AS (
         SELECT x.id AS democube_days_id,
            x.calendar_date,
            i.gender_id,
            i.birth_dt,
            c.patient_id,
            c.clinic_id,
            c.care_regimen_id,
            c.funding_id,
            s.case_id,
            s.id AS step_id,
            s.profile_id,
            s.res_group_id,
            s.result_id,
            s.admission_date,
            s.outcome_date,
            date_part('year'::text, age((s.admission_date)::timestamp with time zone, (i.birth_dt)::timestamp with time zone)) AS age_admission_date,
            date_part('year'::text, age((s.outcome_date)::timestamp with time zone, (i.birth_dt)::timestamp with time zone)) AS age_outcome_date,
            date_part('year'::text, age(i.death_dt, (i.birth_dt)::timestamp without time zone)) AS age_death_date,
            date_part('year'::text, age((x.calendar_date)::timestamp with time zone, (i.birth_dt)::timestamp with time zone)) AS age_calendar_date,
            (s.admission_date = x.calendar_date) AS by_admission_date,
            (s.outcome_date = x.calendar_date) AS by_outcome_date,
            (c.closing_step_id = s.id) AS closing_step,
            row_number() OVER (PARTITION BY s.case_id ORDER BY s.admission_date, s.admission_time, s.id) AS rn
           FROM (((cube_days x
             JOIN mc_step s ON ((((s.admission_date = x.calendar_date) OR (s.outcome_date = x.calendar_date)) AND (x.year_ >= 2013))))
             JOIN mc_case c ON ((s.case_id = c.id)))
             JOIN pim_individual i ON (((c.patient_id = i.id) AND (i.gender_id = ANY (ARRAY[1, 2])) AND (i.birth_dt IS NOT NULL))))
        ), ff AS (
         SELECT f.democube_days_id,
            f.calendar_date,
            f.gender_id,
            f.birth_dt,
            f.patient_id,
            f.clinic_id,
            f.care_regimen_id,
            f.funding_id,
            f.case_id,
            f.step_id,
            f.profile_id,
            f.res_group_id,
            f.result_id,
            f.admission_date,
            f.outcome_date,
            f.age_admission_date,
            f.age_outcome_date,
            f.age_death_date,
            f.age_calendar_date,
            f.by_admission_date,
            f.by_outcome_date,
            f.closing_step,
            f.rn,
            g.department_id,
            vp.e_code AS vpe_code,
            vt.e_code AS vte_code
           FROM (((((f
             JOIN plc_visit v ON (((v.id = f.step_id) AND f.by_admission_date)))
             LEFT JOIN plc_visit_place vp ON ((v.place_id = vp.id)))
             LEFT JOIN mc_case_init_goal gl ON ((v.goal_id = gl.id)))
             LEFT JOIN plc_visit_type vt ON ((gl.visit_type_id = vt.id)))
             LEFT JOIN sr_res_group g ON ((f.res_group_id = g.id)))
        ), t1 AS (
         SELECT
                CASE
                    WHEN ((ff.gender_id = 1) AND ((ff.age_admission_date >= (16)::double precision) AND (ff.age_admission_date <= (59)::double precision))) THEN 1
                    WHEN ((ff.gender_id = 1) AND (ff.age_admission_date >= (60)::double precision)) THEN 2
                    WHEN ((ff.gender_id = 1) AND (ff.age_admission_date < (16)::double precision)) THEN 5
                    WHEN ((ff.gender_id = 2) AND ((ff.age_admission_date >= (16)::double precision) AND (ff.age_admission_date <= (54)::double precision))) THEN 3
                    WHEN ((ff.gender_id = 2) AND (ff.age_admission_date >= (55)::double precision)) THEN 4
                    WHEN ((ff.gender_id = 2) AND (ff.age_admission_date < (16)::double precision)) THEN 7
                    ELSE NULL::integer
                END AS age_category_2_id,
                CASE
                    WHEN (ff.age_admission_date = (0)::double precision) THEN 1
                    WHEN (ff.age_admission_date <= (3)::double precision) THEN 2
                    WHEN (ff.age_admission_date <= (5)::double precision) THEN 3
                    WHEN (ff.age_admission_date <= (7)::double precision) THEN 4
                    WHEN (ff.age_admission_date <= (14)::double precision) THEN 5
                    WHEN (ff.age_admission_date <= (15)::double precision) THEN 6
                    WHEN (ff.age_admission_date <= (17)::double precision) THEN 7
                    ELSE 8
                END AS age_category_3_id,
            ff.gender_id,
            ff.democube_days_id,
            ff.clinic_id,
            ff.department_id,
            ff.profile_id,
            ff.care_regimen_id,
            ff.funding_id,
            count(DISTINCT
                CASE
                    WHEN ((ff.vpe_code)::text = '1'::text) THEN ff.step_id
                    ELSE NULL::integer
                END) AS m1,
            count(DISTINCT
                CASE
                    WHEN ((ff.vpe_code)::text = '1'::text) THEN ff.patient_id
                    ELSE NULL::integer
                END) AS m2,
            count(DISTINCT
                CASE
                    WHEN ((ff.vpe_code)::text = '2'::text) THEN ff.step_id
                    ELSE NULL::integer
                END) AS m3,
            count(DISTINCT
                CASE
                    WHEN ((ff.vpe_code)::text = '2'::text) THEN ff.patient_id
                    ELSE NULL::integer
                END) AS m4,
            count(DISTINCT
                CASE
                    WHEN ((ff.vte_code)::text = '1'::text) THEN ff.step_id
                    ELSE NULL::integer
                END) AS m5,
            count(DISTINCT
                CASE
                    WHEN ((ff.vte_code)::text = '1'::text) THEN ff.patient_id
                    ELSE NULL::integer
                END) AS m6
           FROM ff
          GROUP BY
                CASE
                    WHEN ((ff.gender_id = 1) AND ((ff.age_admission_date >= (16)::double precision) AND (ff.age_admission_date <= (59)::double precision))) THEN 1
                    WHEN ((ff.gender_id = 1) AND (ff.age_admission_date >= (60)::double precision)) THEN 2
                    WHEN ((ff.gender_id = 1) AND (ff.age_admission_date < (16)::double precision)) THEN 5
                    WHEN ((ff.gender_id = 2) AND ((ff.age_admission_date >= (16)::double precision) AND (ff.age_admission_date <= (54)::double precision))) THEN 3
                    WHEN ((ff.gender_id = 2) AND (ff.age_admission_date >= (55)::double precision)) THEN 4
                    WHEN ((ff.gender_id = 2) AND (ff.age_admission_date < (16)::double precision)) THEN 7
                    ELSE NULL::integer
                END,
                CASE
                    WHEN (ff.age_admission_date = (0)::double precision) THEN 1
                    WHEN (ff.age_admission_date <= (3)::double precision) THEN 2
                    WHEN (ff.age_admission_date <= (5)::double precision) THEN 3
                    WHEN (ff.age_admission_date <= (7)::double precision) THEN 4
                    WHEN (ff.age_admission_date <= (14)::double precision) THEN 5
                    WHEN (ff.age_admission_date <= (15)::double precision) THEN 6
                    WHEN (ff.age_admission_date <= (17)::double precision) THEN 7
                    ELSE 8
                END, ff.gender_id, ff.democube_days_id, ff.clinic_id, ff.department_id, ff.profile_id, ff.care_regimen_id, ff.funding_id
        ), t2 AS (
         SELECT
                CASE
                    WHEN ((ff.gender_id = 1) AND ((ff.age_admission_date >= (16)::double precision) AND (ff.age_admission_date <= (59)::double precision))) THEN 1
                    WHEN ((ff.gender_id = 1) AND (ff.age_admission_date >= (60)::double precision)) THEN 2
                    WHEN ((ff.gender_id = 1) AND (ff.age_admission_date < (16)::double precision)) THEN 5
                    WHEN ((ff.gender_id = 2) AND ((ff.age_admission_date >= (16)::double precision) AND (ff.age_admission_date <= (54)::double precision))) THEN 3
                    WHEN ((ff.gender_id = 2) AND (ff.age_admission_date >= (55)::double precision)) THEN 4
                    WHEN ((ff.gender_id = 2) AND (ff.age_admission_date < (16)::double precision)) THEN 7
                    ELSE NULL::integer
                END AS age_category_2_id,
                CASE
                    WHEN (ff.age_admission_date = (0)::double precision) THEN 1
                    WHEN (ff.age_admission_date <= (3)::double precision) THEN 2
                    WHEN (ff.age_admission_date <= (5)::double precision) THEN 3
                    WHEN (ff.age_admission_date <= (7)::double precision) THEN 4
                    WHEN (ff.age_admission_date <= (14)::double precision) THEN 5
                    WHEN (ff.age_admission_date <= (15)::double precision) THEN 6
                    WHEN (ff.age_admission_date <= (17)::double precision) THEN 7
                    ELSE 8
                END AS age_category_3_id,
            ff.gender_id,
            ff.democube_days_id,
            ff.clinic_id,
            ff.department_id,
            ff.profile_id,
            ff.care_regimen_id,
            ff.funding_id,
            count(DISTINCT ff.step_id) AS m7,
            count(DISTINCT ff.patient_id) AS m8
           FROM ((((ff
             JOIN md_srv_rendered m ON ((m.case_id = ff.case_id)))
             JOIN sr_srv_rendered srv ON ((m.id = srv.id)))
             JOIN sr_service ser ON ((srv.service_id = ser.id)))
             JOIN sr_srv_category cat ON (((ser.category_id = cat.id) AND ((cat.code)::text = 'STOMATOLOGY'::text))))
          GROUP BY
                CASE
                    WHEN ((ff.gender_id = 1) AND ((ff.age_admission_date >= (16)::double precision) AND (ff.age_admission_date <= (59)::double precision))) THEN 1
                    WHEN ((ff.gender_id = 1) AND (ff.age_admission_date >= (60)::double precision)) THEN 2
                    WHEN ((ff.gender_id = 1) AND (ff.age_admission_date < (16)::double precision)) THEN 5
                    WHEN ((ff.gender_id = 2) AND ((ff.age_admission_date >= (16)::double precision) AND (ff.age_admission_date <= (54)::double precision))) THEN 3
                    WHEN ((ff.gender_id = 2) AND (ff.age_admission_date >= (55)::double precision)) THEN 4
                    WHEN ((ff.gender_id = 2) AND (ff.age_admission_date < (16)::double precision)) THEN 7
                    ELSE NULL::integer
                END,
                CASE
                    WHEN (ff.age_admission_date = (0)::double precision) THEN 1
                    WHEN (ff.age_admission_date <= (3)::double precision) THEN 2
                    WHEN (ff.age_admission_date <= (5)::double precision) THEN 3
                    WHEN (ff.age_admission_date <= (7)::double precision) THEN 4
                    WHEN (ff.age_admission_date <= (14)::double precision) THEN 5
                    WHEN (ff.age_admission_date <= (15)::double precision) THEN 6
                    WHEN (ff.age_admission_date <= (17)::double precision) THEN 7
                    ELSE 8
                END, ff.gender_id, ff.democube_days_id, ff.clinic_id, ff.department_id, ff.profile_id, ff.care_regimen_id, ff.funding_id
        ), p AS (
         SELECT
                CASE
                    WHEN ((i.gender_id = 1) AND (date_part('year'::text, age(((a.bdatetime)::date)::timestamp with time zone, (i.birth_dt)::timestamp with time zone)) >= (16)::double precision) AND (date_part('year'::text, age(((a.bdatetime)::date)::timestamp with time zone, (i.birth_dt)::timestamp with time zone)) <= (59)::double precision)) THEN 1
                    WHEN ((i.gender_id = 1) AND (date_part('year'::text, age(((a.bdatetime)::date)::timestamp with time zone, (i.birth_dt)::timestamp with time zone)) >= (60)::double precision)) THEN 2
                    WHEN ((i.gender_id = 1) AND (date_part('year'::text, age(((a.bdatetime)::date)::timestamp with time zone, (i.birth_dt)::timestamp with time zone)) < (16)::double precision)) THEN 5
                    WHEN ((i.gender_id = 2) AND (date_part('year'::text, age(((a.bdatetime)::date)::timestamp with time zone, (i.birth_dt)::timestamp with time zone)) >= (16)::double precision) AND (date_part('year'::text, age(((a.bdatetime)::date)::timestamp with time zone, (i.birth_dt)::timestamp with time zone)) <= (54)::double precision)) THEN 3
                    WHEN ((i.gender_id = 2) AND (date_part('year'::text, age(((a.bdatetime)::date)::timestamp with time zone, (i.birth_dt)::timestamp with time zone)) >= (55)::double precision)) THEN 4
                    WHEN ((i.gender_id = 2) AND (date_part('year'::text, age(((a.bdatetime)::date)::timestamp with time zone, (i.birth_dt)::timestamp with time zone)) < (16)::double precision)) THEN 7
                    ELSE NULL::integer
                END AS age_category_2_id,
                CASE
                    WHEN (date_part('year'::text, age(((a.bdatetime)::date)::timestamp with time zone, (i.birth_dt)::timestamp with time zone)) = (0)::double precision) THEN 1
                    WHEN (date_part('year'::text, age(((a.bdatetime)::date)::timestamp with time zone, (i.birth_dt)::timestamp with time zone)) <= (3)::double precision) THEN 2
                    WHEN (date_part('year'::text, age(((a.bdatetime)::date)::timestamp with time zone, (i.birth_dt)::timestamp with time zone)) <= (5)::double precision) THEN 3
                    WHEN (date_part('year'::text, age(((a.bdatetime)::date)::timestamp with time zone, (i.birth_dt)::timestamp with time zone)) <= (7)::double precision) THEN 4
                    WHEN (date_part('year'::text, age(((a.bdatetime)::date)::timestamp with time zone, (i.birth_dt)::timestamp with time zone)) <= (14)::double precision) THEN 5
                    WHEN (date_part('year'::text, age(((a.bdatetime)::date)::timestamp with time zone, (i.birth_dt)::timestamp with time zone)) <= (15)::double precision) THEN 6
                    WHEN (date_part('year'::text, age(((a.bdatetime)::date)::timestamp with time zone, (i.birth_dt)::timestamp with time zone)) <= (17)::double precision) THEN 7
                    ELSE 8
                END AS age_category_3_id,
            a.id AS appointment_id,
            a.customer_id,
            a.is_house_call,
            a.care_regimen_id,
            a.funding_id,
            i.gender_id,
            x.id AS democube_days_id,
            g.org_id AS clinic_id,
            g.department_id
           FROM (((cube_days x
             JOIN md_appointment a ON ((((a.bdatetime)::date = x.calendar_date) AND (x.year_ >= 2013))))
             JOIN sr_res_group g ON ((a.executor_id = g.id)))
             JOIN pim_individual i ON (((a.customer_id = i.id) AND (i.gender_id = ANY (ARRAY[1, 2])) AND (i.birth_dt IS NOT NULL))))
        ), t3 AS (
         SELECT p.age_category_2_id,
            p.age_category_3_id,
            p.gender_id,
            p.democube_days_id,
            p.clinic_id,
            p.department_id,
            p.care_regimen_id,
            p.funding_id,
            count(DISTINCT p.appointment_id) AS m9,
            count(DISTINCT p.customer_id) AS m10
           FROM p
          WHERE p.is_house_call
          GROUP BY p.age_category_2_id, p.age_category_3_id, p.gender_id, p.democube_days_id, p.clinic_id, p.department_id, p.care_regimen_id, p.funding_id
        ), t4 AS (
         SELECT p.age_category_2_id,
            p.age_category_3_id,
            p.gender_id,
            p.democube_days_id,
            p.clinic_id,
            p.department_id,
            p.care_regimen_id,
            p.funding_id,
            count(DISTINCT p.appointment_id) AS m11,
            count(DISTINCT p.customer_id) AS m12
           FROM (md_ambulance_call c
             JOIN p ON ((c.appointment_id = p.appointment_id)))
          GROUP BY p.age_category_2_id, p.age_category_3_id, p.gender_id, p.democube_days_id, p.clinic_id, p.department_id, p.care_regimen_id, p.funding_id
        ), q AS (
         SELECT f.democube_days_id,
            f.calendar_date,
            f.gender_id,
            f.birth_dt,
            f.patient_id,
            f.clinic_id,
            f.care_regimen_id,
            f.funding_id,
            f.case_id,
            f.step_id,
            f.profile_id,
            f.res_group_id,
            f.result_id,
            f.admission_date,
            f.outcome_date,
            f.age_admission_date,
            f.age_outcome_date,
            f.age_death_date,
            f.age_calendar_date,
            f.by_admission_date,
            f.by_outcome_date,
            f.closing_step,
            f.rn,
            h.id AS record_id,
            h.department_id,
            h.bed_profile_id AS record_bed_profile_id,
            g.department_id AS res_group_department_id,
            dt.e_code AS dte_code
           FROM ((((f
             LEFT JOIN hsp_record h ON ((h.id = f.step_id)))
             LEFT JOIN pim_department d ON ((h.department_id = d.id)))
             LEFT JOIN pim_department_type dt ON ((d.type_id = dt.id)))
             LEFT JOIN sr_res_group g ON ((f.res_group_id = g.id)))
        ), t5 AS (
         SELECT
                CASE
                    WHEN ((q.gender_id = 1) AND ((q.age_admission_date >= (16)::double precision) AND (q.age_admission_date <= (59)::double precision))) THEN 1
                    WHEN ((q.gender_id = 1) AND (q.age_admission_date >= (60)::double precision)) THEN 2
                    WHEN ((q.gender_id = 1) AND (q.age_admission_date < (16)::double precision)) THEN 5
                    WHEN ((q.gender_id = 2) AND ((q.age_admission_date >= (16)::double precision) AND (q.age_admission_date <= (54)::double precision))) THEN 3
                    WHEN ((q.gender_id = 2) AND (q.age_admission_date >= (55)::double precision)) THEN 4
                    WHEN ((q.gender_id = 2) AND (q.age_admission_date < (16)::double precision)) THEN 7
                    ELSE NULL::integer
                END AS age_category_2_id,
                CASE
                    WHEN (q.age_admission_date = (0)::double precision) THEN 1
                    WHEN (q.age_admission_date <= (3)::double precision) THEN 2
                    WHEN (q.age_admission_date <= (5)::double precision) THEN 3
                    WHEN (q.age_admission_date <= (7)::double precision) THEN 4
                    WHEN (q.age_admission_date <= (14)::double precision) THEN 5
                    WHEN (q.age_admission_date <= (15)::double precision) THEN 6
                    WHEN (q.age_admission_date <= (17)::double precision) THEN 7
                    ELSE 8
                END AS age_category_3_id,
            q.gender_id,
            q.democube_days_id,
            q.clinic_id,
                CASE
                    WHEN (q.record_id IS NOT NULL) THEN
                    CASE
                        WHEN ((q.dte_code)::text = '4'::text) THEN h2.department_id
                        ELSE q.department_id
                    END
                    ELSE q.res_group_department_id
                END AS department_id,
                CASE
                    WHEN (q.record_id IS NOT NULL) THEN
                    CASE
                        WHEN ((q.dte_code)::text = '4'::text) THEN s2.profile_id
                        ELSE q.profile_id
                    END
                    ELSE q.profile_id
                END AS profile_id,
            k.room_id,
            k.bed_id,
            COALESCE(q.record_bed_profile_id, k.bed_profile_id) AS bed_profile_id,
            q.care_regimen_id,
            q.funding_id,
            count(DISTINCT q.case_id) AS m13
           FROM ((((q
             JOIN dual ON ((q.by_admission_date AND (q.rn = 1))))
             LEFT JOIN hsp_record h2 ON ((h2.previous_id = q.record_id)))
             LEFT JOIN mc_step s2 ON ((s2.id = h2.id)))
             LEFT JOIN mv_koiki k ON ((k.step_id =
                CASE
                    WHEN (q.record_id IS NOT NULL) THEN
                    CASE
                        WHEN ((q.dte_code)::text = '4'::text) THEN s2.id
                        ELSE q.step_id
                    END
                    ELSE q.step_id
                END)))
          GROUP BY
                CASE
                    WHEN ((q.gender_id = 1) AND ((q.age_admission_date >= (16)::double precision) AND (q.age_admission_date <= (59)::double precision))) THEN 1
                    WHEN ((q.gender_id = 1) AND (q.age_admission_date >= (60)::double precision)) THEN 2
                    WHEN ((q.gender_id = 1) AND (q.age_admission_date < (16)::double precision)) THEN 5
                    WHEN ((q.gender_id = 2) AND ((q.age_admission_date >= (16)::double precision) AND (q.age_admission_date <= (54)::double precision))) THEN 3
                    WHEN ((q.gender_id = 2) AND (q.age_admission_date >= (55)::double precision)) THEN 4
                    WHEN ((q.gender_id = 2) AND (q.age_admission_date < (16)::double precision)) THEN 7
                    ELSE NULL::integer
                END,
                CASE
                    WHEN (q.age_admission_date = (0)::double precision) THEN 1
                    WHEN (q.age_admission_date <= (3)::double precision) THEN 2
                    WHEN (q.age_admission_date <= (5)::double precision) THEN 3
                    WHEN (q.age_admission_date <= (7)::double precision) THEN 4
                    WHEN (q.age_admission_date <= (14)::double precision) THEN 5
                    WHEN (q.age_admission_date <= (15)::double precision) THEN 6
                    WHEN (q.age_admission_date <= (17)::double precision) THEN 7
                    ELSE 8
                END, q.gender_id, q.democube_days_id, q.clinic_id,
                CASE
                    WHEN (q.record_id IS NOT NULL) THEN
                    CASE
                        WHEN ((q.dte_code)::text = '4'::text) THEN h2.department_id
                        ELSE q.department_id
                    END
                    ELSE q.res_group_department_id
                END,
                CASE
                    WHEN (q.record_id IS NOT NULL) THEN
                    CASE
                        WHEN ((q.dte_code)::text = '4'::text) THEN s2.profile_id
                        ELSE q.profile_id
                    END
                    ELSE q.profile_id
                END, k.room_id, k.bed_id, COALESCE(q.record_bed_profile_id, k.bed_profile_id), q.care_regimen_id, q.funding_id
        ), t6 AS (
         SELECT
                CASE
                    WHEN res.is_death THEN
                    CASE
                        WHEN ((q.gender_id = 1) AND ((q.age_death_date >= (16)::double precision) AND (q.age_death_date <= (59)::double precision))) THEN 1
                        WHEN ((q.gender_id = 1) AND (q.age_death_date >= (60)::double precision)) THEN 2
                        WHEN ((q.gender_id = 1) AND (q.age_death_date < (16)::double precision)) THEN 5
                        WHEN ((q.gender_id = 2) AND ((q.age_death_date >= (16)::double precision) AND (q.age_death_date <= (54)::double precision))) THEN 3
                        WHEN ((q.gender_id = 2) AND (q.age_death_date >= (55)::double precision)) THEN 4
                        WHEN ((q.gender_id = 2) AND (q.age_death_date < (16)::double precision)) THEN 7
                        ELSE NULL::integer
                    END
                    ELSE
                    CASE
                        WHEN ((q.gender_id = 1) AND ((q.age_outcome_date >= (16)::double precision) AND (q.age_outcome_date <= (59)::double precision))) THEN 1
                        WHEN ((q.gender_id = 1) AND (q.age_outcome_date >= (60)::double precision)) THEN 2
                        WHEN ((q.gender_id = 1) AND (q.age_outcome_date < (16)::double precision)) THEN 5
                        WHEN ((q.gender_id = 2) AND ((q.age_outcome_date >= (16)::double precision) AND (q.age_outcome_date <= (54)::double precision))) THEN 3
                        WHEN ((q.gender_id = 2) AND (q.age_outcome_date >= (55)::double precision)) THEN 4
                        WHEN ((q.gender_id = 2) AND (q.age_outcome_date < (16)::double precision)) THEN 7
                        ELSE NULL::integer
                    END
                END AS age_category_2_id,
                CASE
                    WHEN res.is_death THEN
                    CASE
                        WHEN (q.age_death_date = (0)::double precision) THEN 1
                        WHEN (q.age_death_date <= (3)::double precision) THEN 2
                        WHEN (q.age_death_date <= (5)::double precision) THEN 3
                        WHEN (q.age_death_date <= (7)::double precision) THEN 4
                        WHEN (q.age_death_date <= (14)::double precision) THEN 5
                        WHEN (q.age_death_date <= (15)::double precision) THEN 6
                        WHEN (q.age_death_date <= (17)::double precision) THEN 7
                        ELSE 8
                    END
                    ELSE
                    CASE
                        WHEN (q.age_outcome_date = (0)::double precision) THEN 1
                        WHEN (q.age_outcome_date <= (3)::double precision) THEN 2
                        WHEN (q.age_outcome_date <= (5)::double precision) THEN 3
                        WHEN (q.age_outcome_date <= (7)::double precision) THEN 4
                        WHEN (q.age_outcome_date <= (14)::double precision) THEN 5
                        WHEN (q.age_outcome_date <= (15)::double precision) THEN 6
                        WHEN (q.age_outcome_date <= (17)::double precision) THEN 7
                        ELSE 8
                    END
                END AS age_category_3_id,
            q.gender_id,
            q.democube_days_id,
            q.clinic_id,
                CASE
                    WHEN (q.record_id IS NULL) THEN q.res_group_department_id
                    ELSE q.department_id
                END AS department_id,
            q.profile_id,
            k.room_id,
            k.bed_id,
            COALESCE(q.record_bed_profile_id, k.bed_profile_id) AS bed_profile_id,
            q.care_regimen_id,
            q.funding_id,
            count(DISTINCT q.case_id) AS m14,
            count(DISTINCT
                CASE
                    WHEN res.is_death THEN q.case_id
                    ELSE NULL::integer
                END) AS m15
           FROM (((q
             JOIN dual ON ((q.by_outcome_date AND q.closing_step)))
             LEFT JOIN mc_step_result res ON ((q.result_id = res.id)))
             LEFT JOIN mv_koiki k ON ((k.step_id = q.step_id)))
          GROUP BY
                CASE
                    WHEN res.is_death THEN
                    CASE
                        WHEN ((q.gender_id = 1) AND ((q.age_death_date >= (16)::double precision) AND (q.age_death_date <= (59)::double precision))) THEN 1
                        WHEN ((q.gender_id = 1) AND (q.age_death_date >= (60)::double precision)) THEN 2
                        WHEN ((q.gender_id = 1) AND (q.age_death_date < (16)::double precision)) THEN 5
                        WHEN ((q.gender_id = 2) AND ((q.age_death_date >= (16)::double precision) AND (q.age_death_date <= (54)::double precision))) THEN 3
                        WHEN ((q.gender_id = 2) AND (q.age_death_date >= (55)::double precision)) THEN 4
                        WHEN ((q.gender_id = 2) AND (q.age_death_date < (16)::double precision)) THEN 7
                        ELSE NULL::integer
                    END
                    ELSE
                    CASE
                        WHEN ((q.gender_id = 1) AND ((q.age_outcome_date >= (16)::double precision) AND (q.age_outcome_date <= (59)::double precision))) THEN 1
                        WHEN ((q.gender_id = 1) AND (q.age_outcome_date >= (60)::double precision)) THEN 2
                        WHEN ((q.gender_id = 1) AND (q.age_outcome_date < (16)::double precision)) THEN 5
                        WHEN ((q.gender_id = 2) AND ((q.age_outcome_date >= (16)::double precision) AND (q.age_outcome_date <= (54)::double precision))) THEN 3
                        WHEN ((q.gender_id = 2) AND (q.age_outcome_date >= (55)::double precision)) THEN 4
                        WHEN ((q.gender_id = 2) AND (q.age_outcome_date < (16)::double precision)) THEN 7
                        ELSE NULL::integer
                    END
                END,
                CASE
                    WHEN res.is_death THEN
                    CASE
                        WHEN (q.age_death_date = (0)::double precision) THEN 1
                        WHEN (q.age_death_date <= (3)::double precision) THEN 2
                        WHEN (q.age_death_date <= (5)::double precision) THEN 3
                        WHEN (q.age_death_date <= (7)::double precision) THEN 4
                        WHEN (q.age_death_date <= (14)::double precision) THEN 5
                        WHEN (q.age_death_date <= (15)::double precision) THEN 6
                        WHEN (q.age_death_date <= (17)::double precision) THEN 7
                        ELSE 8
                    END
                    ELSE
                    CASE
                        WHEN (q.age_outcome_date = (0)::double precision) THEN 1
                        WHEN (q.age_outcome_date <= (3)::double precision) THEN 2
                        WHEN (q.age_outcome_date <= (5)::double precision) THEN 3
                        WHEN (q.age_outcome_date <= (7)::double precision) THEN 4
                        WHEN (q.age_outcome_date <= (14)::double precision) THEN 5
                        WHEN (q.age_outcome_date <= (15)::double precision) THEN 6
                        WHEN (q.age_outcome_date <= (17)::double precision) THEN 7
                        ELSE 8
                    END
                END, q.gender_id, q.democube_days_id, q.clinic_id,
                CASE
                    WHEN (q.record_id IS NULL) THEN q.res_group_department_id
                    ELSE q.department_id
                END, q.profile_id, k.room_id, k.bed_id, COALESCE(q.record_bed_profile_id, k.bed_profile_id), q.care_regimen_id, q.funding_id
        ), t7 AS (
         SELECT
                CASE
                    WHEN ((q.gender_id = 1) AND ((q.age_calendar_date >= (16)::double precision) AND (q.age_calendar_date <= (59)::double precision))) THEN 1
                    WHEN ((q.gender_id = 1) AND (q.age_calendar_date >= (60)::double precision)) THEN 2
                    WHEN ((q.gender_id = 1) AND (q.age_calendar_date < (16)::double precision)) THEN 5
                    WHEN ((q.gender_id = 2) AND ((q.age_calendar_date >= (16)::double precision) AND (q.age_calendar_date <= (54)::double precision))) THEN 3
                    WHEN ((q.gender_id = 2) AND (q.age_calendar_date >= (55)::double precision)) THEN 4
                    WHEN ((q.gender_id = 2) AND (q.age_calendar_date < (16)::double precision)) THEN 7
                    ELSE NULL::integer
                END AS age_category_2_id,
                CASE
                    WHEN (q.age_calendar_date = (0)::double precision) THEN 1
                    WHEN (q.age_calendar_date <= (3)::double precision) THEN 2
                    WHEN (q.age_calendar_date <= (5)::double precision) THEN 3
                    WHEN (q.age_calendar_date <= (7)::double precision) THEN 4
                    WHEN (q.age_calendar_date <= (14)::double precision) THEN 5
                    WHEN (q.age_calendar_date <= (15)::double precision) THEN 6
                    WHEN (q.age_calendar_date <= (17)::double precision) THEN 7
                    ELSE 8
                END AS age_category_3_id,
            q.gender_id,
            q.democube_days_id,
            q.clinic_id,
                CASE
                    WHEN (q.record_id IS NULL) THEN q.res_group_department_id
                    ELSE q.department_id
                END AS department_id,
            q.profile_id,
            k.room_id,
            k.bed_id,
            COALESCE(q.record_bed_profile_id, k.bed_profile_id) AS bed_profile_id,
            q.care_regimen_id,
            q.funding_id,
            sum(GREATEST(((q.outcome_date - q.admission_date) +
                CASE
                    WHEN (q.care_regimen_id <> 2) THEN 1
                    ELSE 0
                END), 1)) AS m16
           FROM ((q
             JOIN dual ON (q.by_outcome_date))
             LEFT JOIN mv_koiki k ON ((k.step_id = q.step_id)))
          GROUP BY
                CASE
                    WHEN ((q.gender_id = 1) AND ((q.age_calendar_date >= (16)::double precision) AND (q.age_calendar_date <= (59)::double precision))) THEN 1
                    WHEN ((q.gender_id = 1) AND (q.age_calendar_date >= (60)::double precision)) THEN 2
                    WHEN ((q.gender_id = 1) AND (q.age_calendar_date < (16)::double precision)) THEN 5
                    WHEN ((q.gender_id = 2) AND ((q.age_calendar_date >= (16)::double precision) AND (q.age_calendar_date <= (54)::double precision))) THEN 3
                    WHEN ((q.gender_id = 2) AND (q.age_calendar_date >= (55)::double precision)) THEN 4
                    WHEN ((q.gender_id = 2) AND (q.age_calendar_date < (16)::double precision)) THEN 7
                    ELSE NULL::integer
                END,
                CASE
                    WHEN (q.age_calendar_date = (0)::double precision) THEN 1
                    WHEN (q.age_calendar_date <= (3)::double precision) THEN 2
                    WHEN (q.age_calendar_date <= (5)::double precision) THEN 3
                    WHEN (q.age_calendar_date <= (7)::double precision) THEN 4
                    WHEN (q.age_calendar_date <= (14)::double precision) THEN 5
                    WHEN (q.age_calendar_date <= (15)::double precision) THEN 6
                    WHEN (q.age_calendar_date <= (17)::double precision) THEN 7
                    ELSE 8
                END, q.gender_id, q.democube_days_id, q.clinic_id,
                CASE
                    WHEN (q.record_id IS NULL) THEN q.res_group_department_id
                    ELSE q.department_id
                END, q.profile_id, k.room_id, k.bed_id, COALESCE(q.record_bed_profile_id, k.bed_profile_id), q.care_regimen_id, q.funding_id
        ), tt AS (
         SELECT t1.age_category_2_id,
            t1.age_category_3_id,
            t1.gender_id,
            t1.democube_days_id,
            t1.clinic_id,
            t1.department_id,
            t1.profile_id,
            NULL::integer AS room_id,
            NULL::integer AS bed_id,
            NULL::integer AS bed_profile_id,
            t1.care_regimen_id,
            t1.funding_id,
            t1.m1,
            t1.m2,
            t1.m3,
            t1.m4,
            t1.m5,
            t1.m6,
            NULL::integer AS m7,
            NULL::integer AS m8,
            NULL::integer AS m9,
            NULL::integer AS m10,
            NULL::integer AS m11,
            NULL::integer AS m12,
            NULL::integer AS m13,
            NULL::integer AS m14,
            NULL::integer AS m15,
            NULL::integer AS m16
           FROM t1
        UNION
         SELECT t2.age_category_2_id,
            t2.age_category_3_id,
            t2.gender_id,
            t2.democube_days_id,
            t2.clinic_id,
            t2.department_id,
            t2.profile_id,
            NULL::integer AS int4,
            NULL::integer AS int4,
            NULL::integer AS int4,
            t2.care_regimen_id,
            t2.funding_id,
            NULL::bigint AS int8,
            NULL::bigint AS int8,
            NULL::bigint AS int8,
            NULL::bigint AS int8,
            NULL::bigint AS int8,
            NULL::bigint AS int8,
            t2.m7,
            t2.m8,
            NULL::integer AS int4,
            NULL::integer AS int4,
            NULL::integer AS int4,
            NULL::integer AS int4,
            NULL::integer AS int4,
            NULL::integer AS int4,
            NULL::integer AS int4,
            NULL::integer AS int4
           FROM t2
        UNION
         SELECT t3.age_category_2_id,
            t3.age_category_3_id,
            t3.gender_id,
            t3.democube_days_id,
            t3.clinic_id,
            t3.department_id,
            NULL::integer AS int4,
            NULL::integer AS int4,
            NULL::integer AS int4,
            NULL::integer AS int4,
            t3.care_regimen_id,
            t3.funding_id,
            NULL::bigint AS int8,
            NULL::bigint AS int8,
            NULL::bigint AS int8,
            NULL::bigint AS int8,
            NULL::bigint AS int8,
            NULL::bigint AS int8,
            NULL::bigint AS int8,
            NULL::bigint AS int8,
            t3.m9,
            t3.m10,
            NULL::integer AS int4,
            NULL::integer AS int4,
            NULL::integer AS int4,
            NULL::integer AS int4,
            NULL::integer AS int4,
            NULL::integer AS int4
           FROM t3
        UNION
         SELECT t4.age_category_2_id,
            t4.age_category_3_id,
            t4.gender_id,
            t4.democube_days_id,
            t4.clinic_id,
            t4.department_id,
            NULL::integer AS int4,
            NULL::integer AS int4,
            NULL::integer AS int4,
            NULL::integer AS int4,
            t4.care_regimen_id,
            t4.funding_id,
            NULL::bigint AS int8,
            NULL::bigint AS int8,
            NULL::bigint AS int8,
            NULL::bigint AS int8,
            NULL::bigint AS int8,
            NULL::bigint AS int8,
            NULL::bigint AS int8,
            NULL::bigint AS int8,
            NULL::bigint AS int8,
            NULL::bigint AS int8,
            t4.m11,
            t4.m12,
            NULL::integer AS int4,
            NULL::integer AS int4,
            NULL::integer AS int4,
            NULL::integer AS int4
           FROM t4
        UNION
         SELECT t5.age_category_2_id,
            t5.age_category_3_id,
            t5.gender_id,
            t5.democube_days_id,
            t5.clinic_id,
            t5.department_id,
            t5.profile_id,
            t5.room_id,
            t5.bed_id,
            t5.bed_profile_id,
            t5.care_regimen_id,
            t5.funding_id,
            NULL::bigint AS int8,
            NULL::bigint AS int8,
            NULL::bigint AS int8,
            NULL::bigint AS int8,
            NULL::bigint AS int8,
            NULL::bigint AS int8,
            NULL::bigint AS int8,
            NULL::bigint AS int8,
            NULL::bigint AS int8,
            NULL::bigint AS int8,
            NULL::bigint AS int8,
            NULL::bigint AS int8,
            t5.m13,
            NULL::integer AS int4,
            NULL::integer AS int4,
            NULL::integer AS int4
           FROM t5
        UNION
         SELECT t6.age_category_2_id,
            t6.age_category_3_id,
            t6.gender_id,
            t6.democube_days_id,
            t6.clinic_id,
            t6.department_id,
            t6.profile_id,
            t6.room_id,
            t6.bed_id,
            t6.bed_profile_id,
            t6.care_regimen_id,
            t6.funding_id,
            NULL::bigint AS int8,
            NULL::bigint AS int8,
            NULL::bigint AS int8,
            NULL::bigint AS int8,
            NULL::bigint AS int8,
            NULL::bigint AS int8,
            NULL::bigint AS int8,
            NULL::bigint AS int8,
            NULL::bigint AS int8,
            NULL::bigint AS int8,
            NULL::bigint AS int8,
            NULL::bigint AS int8,
            NULL::bigint AS int8,
            t6.m14,
            t6.m15,
            NULL::integer AS int4
           FROM t6
        UNION
         SELECT t7.age_category_2_id,
            t7.age_category_3_id,
            t7.gender_id,
            t7.democube_days_id,
            t7.clinic_id,
            t7.department_id,
            t7.profile_id,
            t7.room_id,
            t7.bed_id,
            t7.bed_profile_id,
            t7.care_regimen_id,
            t7.funding_id,
            NULL::bigint AS int8,
            NULL::bigint AS int8,
            NULL::bigint AS int8,
            NULL::bigint AS int8,
            NULL::bigint AS int8,
            NULL::bigint AS int8,
            NULL::bigint AS int8,
            NULL::bigint AS int8,
            NULL::bigint AS int8,
            NULL::bigint AS int8,
            NULL::bigint AS int8,
            NULL::bigint AS int8,
            NULL::bigint AS int8,
            NULL::bigint AS int8,
            NULL::bigint AS int8,
            t7.m16
           FROM t7
        )
 SELECT t.age_category_2_id,
    t.age_category_3_id,
    t.gender_id,
    t.democube_days_id,
    t.clinic_id,
    t.department_id,
    t.profile_id,
    t.room_id,
    t.bed_id,
    t.bed_profile_id,
    t.care_regimen_id,
    t.funding_id,
    sum(COALESCE(t.m1, (0)::bigint)) AS m1,
    sum(COALESCE(t.m2, (0)::bigint)) AS m2,
    sum(COALESCE(t.m3, (0)::bigint)) AS m3,
    sum(COALESCE(t.m4, (0)::bigint)) AS m4,
    sum(COALESCE(t.m5, (0)::bigint)) AS m5,
    sum(COALESCE(t.m6, (0)::bigint)) AS m6,
    sum(COALESCE(t.m7, (0)::bigint)) AS m7,
    sum(COALESCE(t.m8, (0)::bigint)) AS m8,
    sum(COALESCE(t.m9, (0)::bigint)) AS m9,
    sum(COALESCE(t.m10, (0)::bigint)) AS m10,
    sum(COALESCE(t.m11, (0)::bigint)) AS m11,
    sum(COALESCE(t.m12, (0)::bigint)) AS m12,
    sum(COALESCE(t.m13, (0)::bigint)) AS m13,
    sum(COALESCE(t.m14, (0)::bigint)) AS m14,
    sum(COALESCE(t.m15, (0)::bigint)) AS m15,
    sum(COALESCE(t.m16, (0)::bigint)) AS m16
   FROM tt t
  GROUP BY t.age_category_2_id, t.age_category_3_id, t.gender_id, t.democube_days_id, t.clinic_id, t.department_id, t.profile_id, t.room_id, t.bed_id, t.bed_profile_id, t.care_regimen_id, t.funding_id;

CREATE INDEX mv_mo_activity_age_category_2_id_inx
  ON mv_mo_activity (age_category_2_id);

CREATE INDEX mv_mo_activity_age_category_3_id_inx
  ON mv_mo_activity (age_category_3_id);

CREATE INDEX mv_mo_activity_gender_id_inx
  ON mv_mo_activity (gender_id);

CREATE INDEX mv_mo_activity_democube_days_id_inx
  ON mv_mo_activity (democube_days_id);

CREATE INDEX mv_mo_activity_clinic_id_inx
  ON mv_mo_activity (clinic_id);

CREATE INDEX mv_mo_activity_department_id_inx
  ON mv_mo_activity (department_id);

CREATE INDEX mv_mo_activity_profile_id_inx
  ON mv_mo_activity (profile_id);

CREATE INDEX mv_mo_activity_room_id_inx
  ON mv_mo_activity (room_id);

CREATE INDEX mv_mo_activity_bed_id_inx
  ON mv_mo_activity (bed_id);

CREATE INDEX mv_mo_activity_bed_profile_id_inx
  ON mv_mo_activity (bed_profile_id);

CREATE INDEX mv_mo_activity_care_regimen_id_inx
  ON mv_mo_activity (care_regimen_id);

CREATE INDEX mv_mo_activity_funding_id_inx
  ON mv_mo_activity (funding_id);

