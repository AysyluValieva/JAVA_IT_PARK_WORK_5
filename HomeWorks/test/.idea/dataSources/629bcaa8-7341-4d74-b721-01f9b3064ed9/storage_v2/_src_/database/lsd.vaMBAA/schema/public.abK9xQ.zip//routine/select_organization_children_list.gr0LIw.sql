CREATE FUNCTION select_organization_children_list(integer)
  RETURNS SETOF integer
LANGUAGE SQL
AS $$
WITH RECURSIVE included_organizations(id) AS (
                SELECT id FROM pim_organization WHERE parent_id = $1
            UNION
                SELECT po.id
                    FROM included_organizations io, pim_organization po
                WHERE po.parent_id = io.id
            )
            SELECT id FROM included_organizations;
$$;

