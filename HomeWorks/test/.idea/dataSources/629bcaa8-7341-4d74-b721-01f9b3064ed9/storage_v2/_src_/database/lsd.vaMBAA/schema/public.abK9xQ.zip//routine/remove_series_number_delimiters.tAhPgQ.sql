CREATE FUNCTION remove_series_number_delimiters()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
declare
            begin
                if (NEW.series is not null) then
                NEW.series = regexp_replace(NEW.series, '-|\s|\/|\\', '', 'g');
                end if;
                if (NEW.number is not null) then
                NEW.number = regexp_replace(NEW.number, '-|\s|\/|\\', '', 'g');
                end if;
                return NEW;
            end;
$$;

