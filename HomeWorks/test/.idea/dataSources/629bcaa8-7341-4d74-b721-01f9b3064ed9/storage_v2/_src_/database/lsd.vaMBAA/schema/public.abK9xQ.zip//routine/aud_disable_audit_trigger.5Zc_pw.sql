CREATE FUNCTION aud_disable_audit_trigger(value boolean)
  RETURNS void
LANGUAGE plpgsql
AS $$
BEGIN
    PERFORM disable_trigger($1, 'audit_trigger');
  END;
$$;

