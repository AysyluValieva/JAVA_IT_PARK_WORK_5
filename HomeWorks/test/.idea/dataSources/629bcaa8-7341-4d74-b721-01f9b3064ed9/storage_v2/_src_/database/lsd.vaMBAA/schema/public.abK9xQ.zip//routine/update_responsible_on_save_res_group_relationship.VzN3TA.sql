CREATE FUNCTION update_responsible_on_save_res_group_relationship()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN

    IF TG_OP = 'INSERT' THEN
        IF (NEW.group_id is not null) THEN
	        PERFORM update_responsible(NEW.group_id);
        END IF;
        RETURN NEW;

    ELSIF TG_OP = 'UPDATE' THEN
        IF (NEW.group_id is not null) THEN
	        PERFORM update_responsible(NEW.group_id);
        END IF;
        RETURN NEW;

    ELSIF TG_OP = 'DELETE' THEN
        IF (OLD.group_id is not null) THEN
            PERFORM update_responsible(OLD.group_id);
        END IF;
        RETURN OLD;

    END IF;
END;
$$;

