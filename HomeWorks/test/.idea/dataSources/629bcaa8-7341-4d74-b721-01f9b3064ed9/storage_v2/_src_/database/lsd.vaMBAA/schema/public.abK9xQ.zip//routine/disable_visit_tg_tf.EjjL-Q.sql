CREATE FUNCTION disable_visit_tg_tf()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
                     RAISE EXCEPTION 'plc_visit is deprecated, use mc_step table';
                  END;
$$;

