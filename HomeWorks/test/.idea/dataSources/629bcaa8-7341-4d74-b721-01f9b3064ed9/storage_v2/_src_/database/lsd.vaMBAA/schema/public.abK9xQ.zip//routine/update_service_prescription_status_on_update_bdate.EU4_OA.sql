CREATE FUNCTION update_service_prescription_status_on_update_bdate()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE
  prescriptionId integer;
  srSrvRenderedId integer;
BEGIN
  IF TG_OP = 'UPDATE' THEN
     srSrvRenderedId = NEW.id;
     prescriptionId = (select prescription_id from md_srv_rendered where id = srSrvRenderedId);
     perform update_prescription_status(prescriptionId);
  END IF;
  RETURN NULL;
END;
$$;

