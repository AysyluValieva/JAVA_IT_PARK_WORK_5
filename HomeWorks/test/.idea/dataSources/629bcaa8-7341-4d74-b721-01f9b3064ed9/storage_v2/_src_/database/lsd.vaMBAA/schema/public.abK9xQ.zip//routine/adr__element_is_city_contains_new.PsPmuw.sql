CREATE FUNCTION adr__element_is_city_contains_new(income_id integer)
  RETURNS boolean
LANGUAGE plpgsql
AS $$
begin

			if exists(
				select null
				from address_element_data D
				join address_element_data D2 on D.id = income_id and D2.path @> D.path
				join address_element E on E.id = D2.id
				join address_element_type T on E.type_id = T.id and T.short_name in ('г','городок')
				limit 1)
			then return true;
			end if;

		
            return false;
		

            end;
$$;

