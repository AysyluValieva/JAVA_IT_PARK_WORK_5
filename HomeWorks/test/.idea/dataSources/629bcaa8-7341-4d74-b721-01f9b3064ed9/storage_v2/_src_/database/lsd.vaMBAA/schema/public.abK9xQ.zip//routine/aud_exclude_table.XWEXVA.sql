CREATE FUNCTION aud_exclude_table(target_table regclass)
  RETURNS void
LANGUAGE plpgsql
AS $$
BEGIN
    EXECUTE 'DROP TRIGGER IF EXISTS audit_trigger_row ON ' || quote_ident(target_table::text);
    EXECUTE 'DROP TRIGGER IF EXISTS audit_trigger_stm ON ' || quote_ident(target_table::text);
exception when others then null;
END;
$$;

