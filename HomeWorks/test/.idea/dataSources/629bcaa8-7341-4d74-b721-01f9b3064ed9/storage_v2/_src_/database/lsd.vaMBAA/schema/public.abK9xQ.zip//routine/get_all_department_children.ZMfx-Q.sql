CREATE FUNCTION get_all_department_children(department_id integer, org_id integer)
  RETURNS SETOF integer
LANGUAGE SQL
AS $$
WITH RECURSIVE temp1 (id, parent_id) AS (
                  SELECT d.id, d.parent_id
                      FROM pim_department d WHERE d.parent_id = $1 and d.org_id=$2
                  union
                  select d2.id, d2.parent_id
                       FROM pim_department d2 INNER JOIN temp1 ON( temp1.id= d2.parent_id) where d2.org_id=$2)
                  select id from temp1
$$;

