CREATE FUNCTION validate_case_type_regimen_payment_acc(i1_method_id integer, i2_regimen_id integer, i3_type_id integer)
  RETURNS record
STABLE
STRICT
LANGUAGE plpgsql
AS $$
DECLARE 
    _r RECORD;
    _result BOOLEAN := TRUE;
    _regimen TEXT := '';
    _method TEXT := '';
BEGIN
    IF
        i3_type_id = 3 AND i2_regimen_id = 1 AND i1_method_id <> 23 
    THEN
        _result := FALSE;
        SELECT 
            r.name, m.name INTO STRICT _regimen, _method
        FROM 
            mc_payment_method_to_care_regimen AS t, mc_care_regimen AS r, mc_payment_method AS m
        WHERE 
            t.payment_method_id = m.id AND t.care_regimen_id = r.id AND m.id = 23
        ;
    ELSIF
        i3_type_id = 1 AND i2_regimen_id = 1 AND i1_method_id <> 22
    THEN
        _result := FALSE;
        SELECT 
            r.name, m.name INTO STRICT _regimen, _method
        FROM 
            mc_payment_method_to_care_regimen AS t, mc_care_regimen AS r, mc_payment_method AS m
        WHERE 
            t.payment_method_id = m.id AND t.care_regimen_id = r.id AND m.id = 22
        ;
    END IF;
    
    RETURN (_result, _regimen, _method)
    ;
END;
$$;

