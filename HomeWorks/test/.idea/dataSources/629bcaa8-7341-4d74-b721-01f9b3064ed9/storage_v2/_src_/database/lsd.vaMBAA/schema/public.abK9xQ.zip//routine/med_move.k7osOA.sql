CREATE FUNCTION med_move(bg date, ed date, storeid integer[])
  RETURNS TABLE(ssid integer, modifid integer, modifname text, code_tfoms text, hid integer, mneiid integer, countinsecpack integer, storeid integer, orgid integer, fundid integer, fundcode text, fundname text, contractor_id integer, batchseries text, batchexpire_dt date, ssprice numeric, cgid integer, cgname text, measure text, beginquantity numeric, incomequantity numeric, outcomequantity numeric)
STABLE
LANGUAGE SQL
AS $$
SELECT	* FROM (
		SELECT
			ss.ID ssid,
			modif.ID modifid,
			modif.NAME modifname,
			modif.code_tfoms, 
			h.ID hid,
			modif.mnei_id mneiId,
			COALESCE (modif.mnei_count_in_sec_pk,1) countInSecPack,
			store.ID storeid,
			--store.name storename, 
			store.org_id orgId,
			fund.ID fundid,
			fund.code as fundCode, 
			fund.NAME fundname,
			batch.contractor_id as contractor_id, 
			batch.series batchseries,
			batch.expire_dt batchexpire_dt,
			ss.price ssprice,
			cg.ID cgid,
			cg.NAME cgname,
			(SELECT inventory.get_unit_name_by_flag_of_modif(modif.price_unit_flag, modif.ID)) measure,
			inventory.get_store_supply_quantity_at_date(ss.ID, $1,	NULL) beginQuantity,
			inventory.get_income_quantity_for_store_supply_for_period (ss.ID,	$1, $2,	NULL) incomeQuantity,
			inventory.get_outcome_quantity_for_store_supply_for_period (ss.ID, $1,	$2, NULL) outcomeQuantity
		FROM
			inventory.store_supply ss
		LEFT OUTER JOIN inventory.batch batch ON batch. ID = ss.batch_id
		LEFT OUTER JOIN inventory.hold_modif modif ON modif. ID = batch.hold_modif_id
		LEFT OUTER JOIN inventory.holding h ON h. ID = modif.holding_id
		LEFT OUTER JOIN inventory.commodity_group cg ON cg. ID = h.commodity_group_id
		LEFT OUTER JOIN inventory.store store ON store. ID = ss.store_id
		LEFT OUTER JOIN inventory.funding_source fund ON fund. ID = batch.funding_source_id
	) AS turnoverSheet 
	WHERE (beginQuantity = 0 AND incomeQuantity = 0	AND outcomeQuantity = 0) IS FALSE
		AND storeid = any($3)
	ORDER BY 11
$$;

