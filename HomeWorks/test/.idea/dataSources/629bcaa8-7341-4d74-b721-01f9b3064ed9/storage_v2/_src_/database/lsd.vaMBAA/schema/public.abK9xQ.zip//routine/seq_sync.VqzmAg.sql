CREATE FUNCTION seq_sync(p_tab name, p_seq name)
  RETURNS bigint
LANGUAGE plpgsql
AS $$
declare
v_pk_name pg_attribute.attname%type;
v_next	bigint;
begin
select attname into v_pk_name from pg_attribute, pg_class, pg_constraint where attrelid = pg_class.oid and relname = lower(p_tab) and conrelid = attrelid and contype = 'p' and conkey[1] = attnum;
execute 'select max('||v_pk_name||') + 1 from '||p_tab into v_next;
if v_next is not null then
execute 'alter sequence '||p_seq||' restart with '||v_next;
end if;
return v_next;
end;
$$;

