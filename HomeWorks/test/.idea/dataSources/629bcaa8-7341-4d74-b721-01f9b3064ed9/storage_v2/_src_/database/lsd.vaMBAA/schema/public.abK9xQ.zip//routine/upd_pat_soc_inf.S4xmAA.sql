CREATE FUNCTION upd_pat_soc_inf(xpat_id integer, xbirth_place character varying, xcitizenship integer, xethnic_group integer, xeducation_type integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
                --xaddr integer;
                --res record;
              begin
                  update public.pim_individual set birth_place = xbirth_place where id = xpat_id;
                  if not exists (select * from public.pim_citizenship where individual_id = xpat_id)
                    then insert into public.pim_citizenship (individual_id ,country_id)
                            values (xpat_id,xcitizenship);
                    else update  public.pim_citizenship set country_id = xcitizenship where individual_id = xpat_id;
                  end if;
                  if not exists (select * from public.pci_patient where id = xpat_id)
                    then insert into public.pci_patient (id,created_dt,ethnic_group_id, education_type_id)
                            values (xpat_id,now(),xethnic_group,xeducation_type);
                    else update public.pci_patient set ethnic_group_id = xethnic_group, education_type_id = xeducation_type where id = xpat_id;
                  end if;
                  return xpat_id;
              end;
$$;

