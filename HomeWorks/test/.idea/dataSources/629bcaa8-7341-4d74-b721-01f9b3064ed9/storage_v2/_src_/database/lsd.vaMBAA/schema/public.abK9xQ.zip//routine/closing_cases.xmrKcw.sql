CREATE FUNCTION closing_cases(case_id_in integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
declare 

op_date date;
close_step_id integer;

begin	
	
	select open_date into op_date from mc_case where id = case_id_in;
	select id into close_step_id from mc_step where case_id = case_id_in and outcome_date is null;
	update mc_step set outcome_date = op_date + interval '13 day', result_id = 14, outcome_id = 3 where case_id = case_id_in and outcome_date is null;
	update mc_case set close_date = open_date + interval '13 day', closing_step_id = close_step_id where id = case_id_in;
	raise NOTICE 'Закрыт случай mc_case.id = %, шагом mc_step.id = %', case_id_in, close_step_id;
end;

$$;

