CREATE FUNCTION fin_get_ksg(_case_id integer, _step_id integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare _main_diagnos_id   integer;
        _main_diagnos_code varchar;        
        _gender_code       varchar;
        _age_code          integer;
        _bed_days_code     integer;
        _diagnos_id        integer[];
        _srv_prototype_arr integer[];        
        _skip_step_2       boolean;
        _politrauma        boolean;
        _ksg_id            integer;
        _ksg_t_id          integer;
        _ksg_t_arr         integer[];
        _ksg_t_arr1        integer[];
        _ksg_h_id          integer;
        _ksg_h_arr         integer[];
        _ksg_h_arr1        integer[];
        _ksg_t_coefficient numeric;
        _ksg_h_coefficient numeric;
        _by_step           boolean;
begin

if _case_id is null then return null; end if;

SELECT CASE WHEN (ARRAY_LENGTH(ARRAY_AGG(DISTINCT p.code), 1) > 1
                  AND
                  ARRAY_AGG(p.code)::TEXT[] && ARRAY['162', '379', '107', '462', '192', '79', '492', '131', '407']::TEXT[])
            THEN TRUE
            ELSE FALSE
       END
  INTO _by_step
  FROM mc_step AS s
  JOIN LATERAL (SELECT bed_profile_id FROM hsp_record WHERE id = s.id) AS h ON TRUE
  JOIN LATERAL (SELECT code FROM md_bed_profile WHERE id = h.bed_profile_id) AS p ON TRUE
 WHERE s.case_id = _case_id;

IF NOT _by_step THEN
   --Основной диагноз случая
       select md.id, translate(md.code, '*+', '')
         into _main_diagnos_id, _main_diagnos_code
         from mc_case mc
         join mc_diagnosis mcd on mcd.id = mc.main_diagnos_id
         join md_diagnosis md on md.id = mcd.diagnos_id
        where mc.id = _case_id;

   --Услуги случая
   _srv_prototype_arr =
       ARRAY(select coalesce(srv.prototype_id, sr.prototype_id) from mc_case mc
        join mc_step step on step.case_id = mc.id
        join md_srv_rendered msr on msr.step_id = step.id
        join sr_srv_rendered srv on srv.id = msr.id
        join sr_service sr on sr.id = srv.service_id
       where mc.id = _case_id);

   --Сопутствующие диагнозы случая 
   _diagnos_id = 
       ARRAY(select distinct md.id from mc_case mc
        join mc_diagnosis mcd on mcd.case_id = mc.id and not mcd.is_main
        join md_diagnosis md on md.id = mcd.diagnos_id
       where mc.id = _case_id); 
ELSE
   --Основной диагноз шага
       select md.id, translate(md.code, '*+', '')
         into _main_diagnos_id, _main_diagnos_code
         from mc_step ms
         join mc_diagnosis mcd on mcd.id = ms.main_diagnosis_id
         join md_diagnosis md on md.id = mcd.diagnos_id
        where ms.case_id = _case_id
          and ms.id = _step_id;

   --Услуги шага
   _srv_prototype_arr =
       ARRAY(select coalesce(srv.prototype_id, sr.prototype_id) from mc_case mc
        join mc_step step on step.case_id = mc.id
        join md_srv_rendered msr on msr.step_id = step.id
        join sr_srv_rendered srv on srv.id = msr.id
        join sr_service sr on sr.id = srv.service_id
       where mc.id = _case_id
         and step.id = _step_id);

   --Сопутствующие диагнозы шага 
   _diagnos_id = 
       ARRAY(select distinct md.id from mc_step ms
        join mc_diagnosis mcd on mcd.case_id = ms.case_id and not mcd.is_main
        join md_diagnosis md on md.id = mcd.diagnos_id
       where ms.case_id = _case_id
         and ms.id = _step_id); 
END IF;
    
--Пол, возраст, дни в стационаре
   select case coalesce(i.gender_id, 3)
          when 1 then 'М'
          when 2 then 'Ж'
          else '' end as gender_code,
          case  
          when extract(year from age(s.admission_date,i.birth_dt))>=18 then 0
          when (s.admission_date-i.birth_dt) > 90 then 3
          when (s.admission_date-i.birth_dt) > 28 then 2
          else 1 end as age_code,
          case 
          when r.bed_days_amount >= 3 then 1
          else 0 END as bed_days_code
   into _gender_code, _age_code, _bed_days_code
   from mc_step s
   join mc_case c on c.id = s.case_id
   join pim_individual i on i.id = c.patient_id
   left join hsp_record r on r.id = s.id
   where s.id = _step_id;
   
IF 
--Проверка на политравму
   ((select count(*) > 0  from md_ksg_diagnosis_politrauma where diagnos_id = _main_diagnos_id and anatom_area = 'Т7')
   AND
   (select count(*) > 0  from md_ksg_diagnosis_politrauma where diagnos_id = ANY(_diagnos_id) 
    and (diagnos_code in ('J95.1', 'J95.2', 'J96.0', 'T79.4', 'R57.1', 'R57.8') or diagnos_code like 'N17%')))
   OR
   ((select not array_agg(anatom_area) &&  
                array(select anatom_area from md_ksg_diagnosis_politrauma where diagnos_id = ANY(_diagnos_id))
    from md_ksg_diagnosis_politrauma where diagnos_id = _main_diagnos_id)
   AND
   (select count(*) > 0  from md_diagnosis where id = ANY(_diagnos_id)
    and (code in ('J95.1', 'J95.2', 'J96.0', 'T79.4', 'R57.1', 'R57.8') or code like 'N17%')))    
THEN		
   _politrauma = true;
END IF;


IF 
   _politrauma = true  
THEN
   _ksg_id = (select id from md_clinical_statistical_group where code = '192' and to_dt is null); RETURN _ksg_id; 
ELSE

   -- ШАГ 1: Определение терапевтической КСГ
   IF ARRAY_LENGTH(_srv_prototype_arr, 1) IS NOT NULL THEN
      _ksg_t_arr = ARRAY(SELECT DISTINCT cd.csg_id
                           FROM md_csg_to_diagnosis cd
                          WHERE _main_diagnos_id BETWEEN cd.from_diagnosis_id AND cd.to_diagnosis_id);
   ELSE
      _ksg_t_arr = ARRAY(SELECT DISTINCT tt.csg_id
                           FROM tt_csg_group_detail tt
                          WHERE tt.diagnosis_code = _main_diagnos_code
                            AND NULLIF(tt.service_code, '') IS NULL);
      _skip_step_2 = TRUE;
   END IF;

   IF ARRAY_LENGTH(_ksg_t_arr, 1) = 1 THEN
      _ksg_t_id = UNNEST(_ksg_t_arr);
   ELSE
      -- проверяем услуги
      IF (SELECT COUNT(1) > 0 FROM md_csg_to_srv_prototype spr WHERE spr.csg_id = ANY(_ksg_t_arr) 
                                                                 AND spr.srv_prototype_id = ANY(_srv_prototype_arr))
      THEN
         _ksg_t_arr = ARRAY(SELECT DISTINCT spr.csg_id 
                              FROM md_csg_to_srv_prototype spr
                             WHERE spr.csg_id = ANY(_ksg_t_arr) 
                               AND spr.srv_prototype_id = ANY(_srv_prototype_arr));
         _skip_step_2 = TRUE;
      ELSE
         _ksg_t_arr = ARRAY(SELECT DISTINCT tt.csg_id
                              FROM tt_csg_group_detail tt
                             WHERE tt.diagnosis_code = _main_diagnos_code
                               AND NULLIF(tt.service_code, '') IS NULL);
      END IF;
      IF ARRAY_LENGTH(_ksg_t_arr, 1) = 1 THEN
         _ksg_t_id = UNNEST(_ksg_t_arr);
      ELSE
         -- проверяем возраст
         IF (SELECT COUNT(tt.age) > 0 FROM tt_csg_group_detail tt WHERE tt.csg_id = ANY(_ksg_t_arr)
                                                                    AND tt.diagnosis_code = _main_diagnos_code)
         THEN
            CASE _age_code
            WHEN 1 THEN
               _ksg_t_arr1 = ARRAY(SELECT DISTINCT tt.csg_id 
                                     FROM tt_csg_group_detail tt
                                    WHERE tt.csg_id = ANY(_ksg_t_arr) 
                                      AND tt.diagnosis_code = _main_diagnos_code
                                      AND tt.age IN (1, 2, 3));
            WHEN 2 THEN
               _ksg_t_arr1 = ARRAY(SELECT DISTINCT tt.csg_id 
                                     FROM tt_csg_group_detail tt
                                    WHERE tt.csg_id = ANY(_ksg_t_arr) 
                                      AND tt.diagnosis_code = _main_diagnos_code
                                      AND tt.age IN (2, 3));
            WHEN 3 THEN
               _ksg_t_arr1 = ARRAY(SELECT DISTINCT tt.csg_id 
                                     FROM tt_csg_group_detail tt
                                    WHERE tt.csg_id = ANY(_ksg_t_arr) 
                                      AND tt.diagnosis_code = _main_diagnos_code
                                      AND tt.age = _age_code);
            ELSE
               _ksg_t_arr1 = ARRAY(SELECT DISTINCT tt.csg_id 
                                     FROM tt_csg_group_detail tt
                                    WHERE tt.csg_id = ANY(_ksg_t_arr) 
                                      AND tt.diagnosis_code = _main_diagnos_code
                                      AND tt.age IS NULL);
            END CASE;
            IF ARRAY_LENGTH(_ksg_t_arr1, 1) IS NULL THEN
               _ksg_t_arr = ARRAY(SELECT DISTINCT tt.csg_id 
                                    FROM tt_csg_group_detail tt
                                   WHERE tt.csg_id = ANY(_ksg_t_arr) 
                                     AND tt.diagnosis_code = _main_diagnos_code
                                     AND tt.age IS NULL);
            ELSE
               _ksg_t_arr = _ksg_t_arr1;
            END IF;
         END IF;
         IF ARRAY_LENGTH(_ksg_t_arr, 1) = 1 THEN
            _ksg_t_id = UNNEST(_ksg_t_arr);
         ELSE
            -- проверяем пол
            IF (SELECT COUNT(NULLIF(tt.sex, '')) > 0 FROM tt_csg_group_detail tt WHERE tt.csg_id = ANY(_ksg_t_arr)
                                                                                   AND tt.diagnosis_code = _main_diagnos_code)
            THEN
               _ksg_t_arr = ARRAY(SELECT DISTINCT tt.csg_id 
                                    FROM tt_csg_group_detail tt
                                   WHERE tt.csg_id = ANY(_ksg_t_arr) 
                                     AND tt.diagnosis_code = _main_diagnos_code
                                     AND tt.sex = _gender_code);
            END IF;
            IF ARRAY_LENGTH(_ksg_t_arr, 1) = 1 THEN
               _ksg_t_id = UNNEST(_ksg_t_arr);
            ELSE
               -- проверяем количество дней в стационаре
               IF (SELECT COUNT(tt.los) > 0 FROM tt_csg_group_detail tt WHERE tt.csg_id = ANY(_ksg_t_arr)
                                                                          AND tt.diagnosis_code = _main_diagnos_code)
               THEN
                  _ksg_t_arr = ARRAY(SELECT DISTINCT tt.csg_id 
                                       FROM tt_csg_group_detail tt
                                      WHERE tt.csg_id = ANY(_ksg_t_arr) 
                                        AND tt.diagnosis_code = _main_diagnos_code
                                        AND COALESCE(tt.los, 0) = _bed_days_code);
               END IF;
            END IF;
         END IF;
      END IF;
   END IF;
   IF ARRAY_LENGTH(_ksg_t_arr, 1) = 1 THEN
      _ksg_t_id = UNNEST(_ksg_t_arr);
   ELSIF ARRAY_LENGTH(_ksg_t_arr, 1) > 1 THEN
      SELECT g1.id
        INTO _ksg_t_id
        FROM md_clinical_statistical_group g1
       WHERE g1.id = ANY(_ksg_t_arr)
         AND g1.coefficient = (SELECT MAX(g.coefficient)
                                 FROM md_clinical_statistical_group g
                                WHERE g.id = ANY(_ksg_t_arr))
       LIMIT 1;
   END IF;
   
   IF _skip_step_2 THEN RETURN _ksg_t_id; END IF;

   -- ШАГ 2: Определение хирургической КСГ
   _ksg_h_arr = ARRAY(SELECT DISTINCT spr.csg_id
                        FROM md_csg_to_srv_prototype spr
                       WHERE spr.srv_prototype_id = ANY(_srv_prototype_arr));

   IF ARRAY_LENGTH(_ksg_h_arr, 1) = 1 THEN
      _ksg_h_id = UNNEST(_ksg_h_arr);
   ELSE
      -- проверяем диагноз
      IF (SELECT COUNT(1) > 0 FROM md_csg_to_diagnosis cd WHERE cd.csg_id = ANY(_ksg_h_arr) 
                                                            AND _main_diagnos_id BETWEEN cd.from_diagnosis_id AND cd.to_diagnosis_id)
      THEN
         _ksg_h_arr = ARRAY(SELECT DISTINCT cd.csg_id 
                              FROM md_csg_to_diagnosis cd
                             WHERE cd.csg_id = ANY(_ksg_h_arr)
                               AND _main_diagnos_id BETWEEN cd.from_diagnosis_id AND cd.to_diagnosis_id);
      ELSE
         _ksg_h_arr = ARRAY(SELECT DISTINCT spr.csg_id
                              FROM md_csg_to_srv_prototype spr
                             WHERE spr.srv_prototype_id = ANY(_srv_prototype_arr)
                               AND NOT EXISTS (SELECT 1 FROM md_csg_to_diagnosis WHERE csg_id = spr.csg_id));
      END IF;
      IF ARRAY_LENGTH(_ksg_h_arr, 1) = 1 THEN
         _ksg_h_id = UNNEST(_ksg_h_arr);
      ELSE
         -- проверяем возраст
         IF (SELECT COUNT(tt.age) > 0 
               FROM tt_csg_group_detail tt
               JOIN sr_srv_prototype s ON TRIM(s.code) = TRIM(tt.service_code)
              WHERE tt.csg_id = ANY(_ksg_h_arr)
                AND s.id = ANY(_srv_prototype_arr))
         THEN
            CASE _age_code
            WHEN 1 THEN
               _ksg_h_arr1 = ARRAY(SELECT DISTINCT tt.csg_id 
                                     FROM tt_csg_group_detail tt
                                     JOIN sr_srv_prototype s ON TRIM(s.code) = TRIM(tt.service_code)
                                    WHERE tt.csg_id = ANY(_ksg_h_arr) 
                                      AND s.id = ANY(_srv_prototype_arr)
                                      AND tt.age IN (1, 2, 3));
            WHEN 2 THEN
               _ksg_h_arr1 = ARRAY(SELECT DISTINCT tt.csg_id 
                                     FROM tt_csg_group_detail tt
                                     JOIN sr_srv_prototype s ON TRIM(s.code) = TRIM(tt.service_code)
                                    WHERE tt.csg_id = ANY(_ksg_h_arr) 
                                      AND s.id = ANY(_srv_prototype_arr)
                                      AND tt.age IN (2, 3));
            WHEN 3 THEN
               _ksg_h_arr1 = ARRAY(SELECT DISTINCT tt.csg_id 
                                     FROM tt_csg_group_detail tt
                                     JOIN sr_srv_prototype s ON TRIM(s.code) = TRIM(tt.service_code)
                                    WHERE tt.csg_id = ANY(_ksg_h_arr) 
                                      AND s.id = ANY(_srv_prototype_arr)
                                      AND tt.age = _age_code);
            ELSE
               _ksg_h_arr1 = ARRAY(SELECT DISTINCT tt.csg_id 
                                     FROM tt_csg_group_detail tt
                                     JOIN sr_srv_prototype s ON TRIM(s.code) = TRIM(tt.service_code)
                                    WHERE tt.csg_id = ANY(_ksg_h_arr) 
                                      AND s.id = ANY(_srv_prototype_arr)
                                      AND tt.age IS NULL);
            END CASE;
            IF ARRAY_LENGTH(_ksg_h_arr1, 1) IS NULL THEN
               _ksg_h_arr = ARRAY(SELECT DISTINCT tt.csg_id 
                                    FROM tt_csg_group_detail tt
                                    JOIN sr_srv_prototype s ON TRIM(s.code) = TRIM(tt.service_code)
                                   WHERE tt.csg_id = ANY(_ksg_h_arr) 
                                     AND s.id = ANY(_srv_prototype_arr)
                                     AND tt.age IS NULL);
            ELSE
               _ksg_h_arr = _ksg_h_arr1;
            END IF;
         END IF;
         IF ARRAY_LENGTH(_ksg_h_arr, 1) = 1 THEN
            _ksg_h_id = UNNEST(_ksg_h_arr);
         ELSE
            -- проверяем пол
            IF (SELECT COUNT(NULLIF(tt.sex, '')) > 0
                  FROM tt_csg_group_detail tt
                  JOIN sr_srv_prototype s ON TRIM(s.code) = TRIM(tt.service_code)
                 WHERE tt.csg_id = ANY(_ksg_h_arr)
                   AND s.id = ANY(_srv_prototype_arr))
            THEN
               _ksg_h_arr = ARRAY(SELECT DISTINCT tt.csg_id 
                                    FROM tt_csg_group_detail tt
                                    JOIN sr_srv_prototype s ON TRIM(s.code) = TRIM(tt.service_code)
                                   WHERE tt.csg_id = ANY(_ksg_h_arr) 
                                     AND s.id = ANY(_srv_prototype_arr)
                                     AND tt.sex = _gender_code);
            END IF;
            IF ARRAY_LENGTH(_ksg_h_arr, 1) = 1 THEN
               _ksg_h_id = UNNEST(_ksg_h_arr);
            ELSE
               -- проверяем количество дней в стационаре
               IF (SELECT COUNT(tt.los) > 0
                     FROM tt_csg_group_detail tt
                     JOIN sr_srv_prototype s ON TRIM(s.code) = TRIM(tt.service_code)
                    WHERE tt.csg_id = ANY(_ksg_h_arr)
                      AND s.id = ANY(_srv_prototype_arr))
               THEN
                  _ksg_h_arr = ARRAY(SELECT DISTINCT tt.csg_id 
                                       FROM tt_csg_group_detail tt
                                       JOIN sr_srv_prototype s ON TRIM(s.code) = TRIM(tt.service_code)
                                      WHERE tt.csg_id = ANY(_ksg_h_arr) 
                                        AND s.id = ANY(_srv_prototype_arr)
                                        AND COALESCE(tt.los, 0) = _bed_days_code);
               END IF;
            END IF;
         END IF;
      END IF;
   END IF;
   IF ARRAY_LENGTH(_ksg_h_arr, 1) = 1 THEN
      _ksg_h_id = UNNEST(_ksg_h_arr);
   ELSIF ARRAY_LENGTH(_ksg_h_arr, 1) > 1 THEN
      SELECT g1.id
        INTO _ksg_h_id
        FROM md_clinical_statistical_group g1
       WHERE g1.id = ANY(_ksg_h_arr)
         AND g1.coefficient = (SELECT MAX(g.coefficient)
                                 FROM md_clinical_statistical_group g
                                WHERE g.id = ANY(_ksg_h_arr))
       LIMIT 1;
   END IF;

END IF;

-- ШАГ 3: Окончательное отнесения случая к КСГ

IF _ksg_t_id is not null
THEN select coefficient into _ksg_t_coefficient from md_clinical_statistical_group where id = _ksg_t_id;
END IF;
IF _ksg_h_id is not null
THEN select coefficient into _ksg_h_coefficient from md_clinical_statistical_group where id = _ksg_h_id;
END IF;


IF (SELECT COUNT(1) > 0
      FROM md_ksg_exclusion
     WHERE ksg_by_service = _ksg_h_id
       AND ksg_by_diagnosis = _ksg_t_id)
THEN
   _ksg_id = _ksg_h_id; return _ksg_id;
END IF;  

IF COALESCE(_ksg_t_coefficient, 0) >= COALESCE(_ksg_h_coefficient, 0) THEN _ksg_id = _ksg_t_id; return _ksg_id; ELSE _ksg_id = _ksg_h_id; return _ksg_id;
END IF; 
  

return _ksg_id;

end;
$$;

