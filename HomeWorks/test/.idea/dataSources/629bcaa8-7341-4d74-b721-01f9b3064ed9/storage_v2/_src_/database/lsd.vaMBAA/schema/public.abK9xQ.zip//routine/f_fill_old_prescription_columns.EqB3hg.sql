CREATE FUNCTION f_fill_old_prescription_columns()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE
      holdingRow hospital.prescription_holding%ROWTYPE;
      prescriptionId integer;
  BEGIN
      IF  TG_OP = 'INSERT' OR TG_OP = 'UPDATE' THEN
          prescriptionId = NEW.prescription_id;
          select * into holdingRow from hospital.prescription_holding where prescription_id = NEW.prescription_id order by id limit 1;
      ELSIF  TG_OP = 'DELETE' THEN
          prescriptionId = OLD.prescription_id;
          select * into holdingRow from hospital.prescription_holding where prescription_id = OLD.prescription_id order by id limit 1;
      END IF;

      IF prescriptionId is null THEN
          RETURN NULL;
      END IF;

      IF holdingRow is NULL THEN
          UPDATE hospital.prescription SET
              holding_id = null,
              hold_form_type_id = null,
              hold_mnei_id = null,
              hold_dose_value = null,
              hold_dose_measure_id = null,
              hold_con_value = null,
              hold_con_measure_id = null,
              count = null,
              is_patient_medicament = null
          WHERE id = prescriptionId;
      ELSE
          UPDATE hospital.prescription SET
              holding_id = holdingRow.holding_id,
              hold_form_type_id = holdingRow.hold_form_type_id,
              hold_mnei_id = holdingRow.hold_mnei_id,
              hold_dose_value = holdingRow.hold_dose_value,
              hold_dose_measure_id = holdingRow.hold_dose_measure_id,
              hold_con_value = holdingRow.hold_con_value,
              hold_con_measure_id = holdingRow.hold_con_measure_id,
              count = holdingRow.count,
              is_patient_medicament = holdingRow.is_patient_medicament
          WHERE id = prescriptionId;
      END IF;
      RETURN NULL;
  END;
$$;

