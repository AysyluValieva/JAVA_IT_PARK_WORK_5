CREATE FUNCTION delete_step_hsp_previous_tg_tf()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
    DELETE FROM public.mc_step WHERE _case_mode_id = 2 AND hsp_previous_id = OLD.id;
    RETURN NULL;
END;
$$;

