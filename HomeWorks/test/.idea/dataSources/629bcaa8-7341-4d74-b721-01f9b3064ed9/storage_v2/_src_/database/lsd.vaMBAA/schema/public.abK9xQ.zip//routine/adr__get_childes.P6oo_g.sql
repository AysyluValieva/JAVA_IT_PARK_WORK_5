CREATE FUNCTION adr__get_childes(id integer)
  RETURNS character varying
LANGUAGE plpgsql
AS $$
declare
  element_id integer := id;
  element record;
  result text := '';
begin

  for element in
    select aed.id
      from address_element_data aed
      where aed.path <@ (select path from address_element_data aed2 where aed2.id = element_id) and aed.id <> element_id
  loop

    if result <> '' then
      result := result || ' ';
    end if;
    result := result || element.id;

  end loop;

  return result;
end;
$$;

