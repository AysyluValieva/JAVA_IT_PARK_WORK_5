CREATE FUNCTION get_diagnosis_full_name(_diagnosis_id integer, _attrs integer[])
  RETURNS text
LANGUAGE plpgsql
AS $$
DECLARE
                full_name text;
                subcode text;
                subname text;
              BEGIN
                SELECT array_to_string(array_agg(av.value ORDER BY ap.pos), '.'),
                   array_to_string(array_agg(av.name ORDER BY ap.pos), '; ') into subcode, subname
                FROM md_attr_value av
                 JOIN md_diag_attr mda on mda.id = av.diag_attr_id
                 JOIN md_attr_pos ap on av.diag_attr_id = ap.diag_attr_id AND ap.diagnosis_id = _diagnosis_id
                WHERE av.id = ANY(_attrs);

                SELECT concat_ws(' ', code, subcode, concat_ws(', ', name, subname)) INTO full_name
                FROM public.md_diagnosis md_d
                WHERE md_d.id=_diagnosis_id;

                RETURN full_name;
              END;
$$;

