CREATE FUNCTION mc_case_update_trigger_fields()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
        update mc_step set _clinic_id = NEW.clinic_id, _patient_id = NEW.patient_id WHERE case_id = NEW.id and (_clinic_id != NEW.clinic_id or _patient_id != NEW.patient_id);

        RETURN NULL;
END;
$$;

