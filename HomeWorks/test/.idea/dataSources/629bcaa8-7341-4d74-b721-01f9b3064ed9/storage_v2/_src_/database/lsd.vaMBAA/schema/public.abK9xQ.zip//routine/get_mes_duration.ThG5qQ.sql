CREATE FUNCTION get_mes_duration(stepid integer)
  RETURNS numeric
LANGUAGE plpgsql
AS $$
begin
                        return (select max(duration) as duration
                            from mc_mes_duration
                            where md_mes = (select mes_id from mc_step where id = stepId)
                            and care_regimen_id = (select regimen_id from mc_step where id = stepId)
                            group by md_mes, care_regimen_id);
                    end;
$$;

