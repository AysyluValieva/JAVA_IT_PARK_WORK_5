CREATE FUNCTION get_case_open_date(case_id integer)
  RETURNS date
IMMUTABLE
STRICT
LANGUAGE SQL
AS $$
select min(cs.admission_date) from mc_step cs where cs.case_id = $1;
$$;

