CREATE FUNCTION merg_dubl_patients(pid_upd integer, pid_del integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
_r record;
_code integer[];
_tab text[]:=array['mc_case','mc_diagnosis','md_patient_prescription','md_referral','md_sicklist','md_receipt','fin_contract_to_patient','sr_srv_rendered','md_appointment','pim_party_address', 'pim_indiv_marital_status','pim_indiv_agreement'];
begin
--Проверка на сотрудников
if exists(select 1 from pim_individual where id = $2)then
if exists(select 1 from pim_employee where individual_id in ($1,$2)) then 
RAISE EXCEPTION 'ERROR: Пациенты не должны являться сотрудниками';   
--return;
end if;
if (select count(*)<2 from pci_patient where id in ($1,$2)) then 
RAISE EXCEPTION 'ERROR: Выбранные сущности - не пациенты';   
--return;
end if;


--перенос случаев,диагнозов,назначений,направлений,больничных листов,рецептов,контрактов,услуг,талонов
for _r in
select tc.constraint_schema, tc.table_name, kcu.column_name
from information_schema.table_constraints as tc
join information_schema.key_column_usage as kcu on tc.constraint_name = kcu.constraint_name
join information_schema.constraint_column_usage as ccu on ccu.constraint_name = tc.constraint_name
where 1=1
and constraint_type = 'FOREIGN KEY'
and ccu.table_name in('pim_individual','pci_patient','pim_party')
and tc.table_name in (select unnest(_tab))
loop
--raise notice 'update %',_r.table_name;
execute 'update '||_r.table_name||' set '||_r.column_name||'='||$1||' where '||_r.column_name||'='||$2||';';
end loop;
--Перенос кодов и связанных с ними информации в доках со второго на первого пациента
--если код у второго присутствует у первого, то не переносим
for _r in select distinct type_id from pim_indiv_code where indiv_id=$2 order by 1 loop 
if 
	not exists(select 1 from pim_indiv_code where type_id=_r.type_id and indiv_id=$1) 
then
  
	select array_agg(id) into _code from pim_indiv_code where indiv_id=$2 and type_id=_r.type_id;
	update pim_indiv_code set indiv_id=$1 where id in (select unnest(_code));
	update pim_individual_doc set indiv_id=$1 where code_id in (select unnest(_code));
  
end if;
end loop;
--апдейт отдельно поскольку изменяем два поля
if exists(select 1 from iehr_pix_registry where patient_id=$2) then 
update iehr_pix_registry set patient_id=$1,
pix_uid=substring(pix_uid,1, strpos(pix_uid,'^'))||(select code from pim_indiv_code where indiv_id=$1 and type_id=(select id from pim_code_type where code='UID') limit 1) 
where patient_id=$2;
raise notice 'Пациент присутсвует в iehr_pix_registry';
end if;
--Удаление второго пациента

delete from pim_indiv_agreement where indiv_id =$2;
delete from pim_indiv_marital_status where individual_id =$2;
delete from pim_citizenship where individual_id =$2;
delete from pim_party_role_to_party where party_id = $2;
delete from pim_individual_doc where indiv_id = $2;
delete from pim_indiv_code where indiv_id = $2;
delete from pci_patient where id=$2;
delete from pim_individual where id=$2;
delete from pim_party where id=$2;
raise notice 'done! В пациента с id =  %', $1 || '  перенесены данные из пациента с id='|| $2 || ', Последний был удален.  Это заняло:' ||(clock_timestamp()::TIME-CURRENT_TIMESTAMP::TIME)::TEXT ;
end if;
exception when  others then raise notice 'ERR! В пациента с id =  %', $1 || '  не удалось перенести данные из пациента с id='|| $2 || ' SQLSTATE:' ||SQLSTATE;
end;
$$;

