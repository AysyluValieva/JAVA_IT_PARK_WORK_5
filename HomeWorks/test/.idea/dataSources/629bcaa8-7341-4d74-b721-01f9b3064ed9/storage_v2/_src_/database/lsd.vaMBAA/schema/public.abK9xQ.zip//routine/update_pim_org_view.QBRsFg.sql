CREATE FUNCTION update_pim_org_view()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
                IF   TG_OP = 'INSERT' THEN
                    INSERT INTO pim_organization_view(id, name, ts_name) values (NEW.id, (select short_name from pim_organization where pim_organization.id = NEW.id),
                    (select to_tsvector('russian', coalesce(pim_organization.short_name, '')||' '
                                ||coalesce(pim_organization.full_name, '')||' '
                                || coalesce(pim_legal_form.code, ''))
                    from pim_organization left outer join pim_legal_form on pim_organization.legal_form_id = pim_legal_form.id where pim_organization.id = NEW.id));
                    RETURN NEW;
                ELSIF TG_OP = 'UPDATE' THEN
                    UPDATE pim_organization_view set name = (select short_name from pim_organization where id = NEW.id),
                    ts_name = (select to_tsvector('russian', coalesce(pim_organization.short_name, '')||' '
                                ||coalesce(pim_organization.full_name, '')||' '
                                || coalesce(pim_legal_form.code, ''))
                    from pim_organization left outer join pim_legal_form on pim_organization.legal_form_id = pim_legal_form.id where pim_organization.id = NEW.id )
                    where pim_organization_view.id = NEW.id;
                    RETURN NEW;
                ELSIF TG_OP = 'DELETE' THEN
                    DELETE FROM pim_organization_view where id = OLD.id;
                    RETURN OLD;
                END IF;
                RETURN NULL;
            END;
$$;

