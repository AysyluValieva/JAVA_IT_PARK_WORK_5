CREATE VIEW v_pim_indiv_doc_and_code AS
  SELECT document3_.indiv_id,
    document3_.number
   FROM (pim_indiv_doc individual2_
     CROSS JOIN pim_doc document3_)
  WHERE (individual2_.doc_id = document3_.id)
UNION
 SELECT individual4_.indiv_id,
    individual4_.code AS number
   FROM pim_indiv_code individual4_;

COMMENT ON VIEW v_pim_indiv_doc_and_code IS 'deprecated';

COMMENT ON COLUMN v_pim_indiv_doc_and_code.indiv_id IS 'deprecated';

COMMENT ON COLUMN v_pim_indiv_doc_and_code.number IS 'deprecated';

