CREATE FUNCTION mdm__get_display_name_column(xversion_id integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
  retval integer;
begin
  select id into retval from mdm_refbook_column where refbook_version_id = xversion_id and is_display_name = true;
  return retval;
end;
$$;

