CREATE FUNCTION dbu_primary_key_exists(pkname character varying, tablename character varying, schemaname character varying)
  RETURNS boolean
LANGUAGE plpgsql
AS $$
declare result boolean;
            begin

            select count(*) > 0 into result
            from pg_constraint
            inner join pg_class table_owner on pg_constraint.conrelid = table_owner.oid
            inner join pg_namespace on pg_constraint.connamespace = pg_namespace.oid
            where pg_constraint.contype = 'p'
            and pg_constraint.conname = lower($1)
            and table_owner.relname = lower($2)
            and pg_namespace.nspname = lower($3);

            return result;
            end;
$$;

