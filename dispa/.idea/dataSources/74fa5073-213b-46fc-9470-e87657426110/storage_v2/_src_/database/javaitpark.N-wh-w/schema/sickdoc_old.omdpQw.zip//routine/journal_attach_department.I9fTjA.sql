CREATE FUNCTION journal_attach_department(p_journal_id integer, p_dep_id integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
BEGIN

-- Если журнал является общим для клиники, то ничего не привязываем
  IF (SELECT is_common_for_clinic
      FROM sickdoc.journal
      WHERE id = p_journal_id)
  THEN
    RETURN;
  END IF;

  IF (SELECT sickdoc.journal_is_active(p_journal_id))
  THEN
    DELETE FROM sickdoc.journal_default
    WHERE journal_id = (SELECT journal_id
                        FROM sickdoc.journal_default
                        WHERE dep_id = $2 AND (SELECT sickdoc.journal_is_active(journal_id)))
          AND dep_id = $2;
  END IF;

  INSERT INTO sickdoc.journal_default (journal_id, dep_id) VALUES ($1, $2);

END;
$$;

