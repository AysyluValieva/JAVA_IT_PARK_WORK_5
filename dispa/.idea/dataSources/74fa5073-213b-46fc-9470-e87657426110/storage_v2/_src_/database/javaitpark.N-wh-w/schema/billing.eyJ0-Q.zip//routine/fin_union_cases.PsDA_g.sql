CREATE FUNCTION fin_union_cases(p1_bill_id integer, p3_user_id integer)
  RETURNS void
STRICT
LANGUAGE plpgsql
AS $$
DECLARE 
_bill record;
cs integer[];
fc integer;
ch boolean;
ste record;
BEGIN
--raise exception 'тест';	
PERFORM pg_sleep(10);
INSERT INTO billing.fin_bill_spec_item_button_log (log_at, action_type, bill_id, user_id, user_login)
        VALUES (LOCALTIMESTAMP, 'union_cases', p1_bill_id, p3_user_id, (SELECT login FROM public.sec_user WHERE id = p3_user_id LIMIT 1))
    ;
end
$$;

