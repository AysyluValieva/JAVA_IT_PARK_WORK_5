CREATE FUNCTION to_time(text)
  RETURNS time without time zone
LANGUAGE plpgsql
AS $$
begin
            if ($1 ~ '\d{4}'
                or
                $1 ~ '\d{1}\:\d{2}'
                or $1 ~ '\d{2}\:\d{2}'  
) then return  $1::time;
      
            else return null;
            end if;
            end;
$$;

