CREATE FUNCTION close_brg_to_call(xbrg_id integer, xemp_id integer, xreg integer, xuser integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
  xfdt timestamp without time zone;
  xfromdate  timestamp without time zone;
  xtodate timestamp without time zone;
  xchange integer;
  xstate integer;
  xtrans timestamp without time zone;
  -- пациент
  xcustomer_id integer;
  -- для системного составного ресурса
  xgroup integer;
  resel record;
  xrelationship_id integer;
  xcall_number integer;
  xcall_address varchar(250);
  xclinic integer;
  xrole integer;

  -- случай
  xcase integer;
  -- шаг
  xstep integer;
  xprof integer;
  xcare_regimen integer;
  -- посещение
  --xvisit integer; т.к. = xstep
  xvisit_place integer;
  xvisit_goal integer;
  xvisit_type integer;
  xinitiator integer;
  xcall_kind integer;
  xcaller integer;
  -- для услуги
  xrendered integer;
  xservice integer;
  xduration integer;
  xmeasure integer;
  xfunding integer;

  -- всмпомогательные поля
  xbrg integer;
  xemp integer;
  xdep integer;
  xname varchar(250);
  xres integer;
  xresrole integer;

  brg_list record;

begin
  xtodate := now();
  FOR brg_list IN
  select id from amb.md_ambulance_call where ((brg_id = xbrg_id) or (emp_id = xemp_id)) and to_time is null
  LOOP

    xcase = (select case_id from amb.md_ambulance_call_result where id = brg_list.id);
    select into xcall_number,xcall_kind, xcaller,xfdt,xclinic,xchange,xbrg,xemp,xdep
      call_number,call_kind_id,caller_id,from_time,station_id,call_dt,brg_id,emp_id,substation_id
    from amb.md_ambulance_call where id = brg_list.id;
    xcall_address = (select adr__get_element_as_text((select address_id from amb.md_ambulance_call where id = brg_list.id),'(6,s,0)(7,s,0)(8,s,0)'));
    select into xfromdate date_time from amb.md_ambcall_state_history where call_id = brg_list.id and state_id = 5;
    update amb.md_ambulance_call set to_time = xtodate where id = brg_list.id;
    if (xbrg is not null) --and (xcall_kind = 7)
    then
      execute amb.add_team_job_status_hist (xbrg_id,xtodate + '1 second',1,xreg,'завершен: '||CAST(xcall_number as varchar(10))||'/'||xcall_address,xuser);
    end if;
    xstate :=  amb.add_ambcall_state_hist (brg_list.id,xtodate,10,2,xreg);
    --получаем пациента
    select into xcustomer_id patient_id from amb.md_ambulance_call where id = brg_list.id;

    IF (xbrg is not null)
    THEN
      -- создаём системный составной ресурс
      xgroup = nextval('sr_res_group_seq');
      insert into sr_res_group (id,bdate,edate,is_system,name,org_id,department_id)
        select xgroup,xfromdate,xtodate,true,name,org_id,department_id from sr_res_group
        where id = (select resource_id from amb.sr_res_team rt left join amb.sr_res_team_job rtj on rtj.team_id = rt.id where rtj.id = xbrg_id);
      --insert into md_res_group (id) values (xgroup);
      insert into public.sr_res_group_profile(id,res_group_id,profile_id)
      values(nextval('sr_res_group_profile_seq'),xgroup,(select profile_id from sr_res_group_profile where res_group_id = (select resource_id from amb.sr_res_team rt left join amb.sr_res_team_job rtj on rtj.team_id = rt.id where rtj.id = xbrg)));

      -- пишем состав бригады на момент обслуживания вызова
      xtrans = (select date_time from amb.md_ambcall_state_history where call_id = brg_list.id and state_id = 5 order by date_time desc limit 1);
      -- //изменить так, чтоб транспорта не было
      for resel in
      select srtjr.resource_id as xres, srtte.res_role_id as xroleE,srttt.res_role_id as xroleT,srr.id as xrole,srtjr.is_head as head
      from amb.sr_res_team_job_resourse srtjr
        join sr_resource sr on sr.id = srtjr.resource_id
        join amb.sr_res_team_job srtj on srtjr.team_job_id = srtj.id
        join amb.sr_res_team srt on srtj.team_id = srt.id
        left join amb.sr_res_team_template srtt on srt.team_template_id = srtt.id
        left join amb.sr_res_team_template_employer srtte on srtt.id = srtte.team_template_id and srtte.work_place = srtjr.workplace
        left join amb.sr_res_team_template_transport srttt on srtt.id = srttt.team_template_id and (srttt.work_place = srtjr.workplace or upper(srttt.work_place) = upper('Транспорт')) and sr.res_kind_id = (select id from sr_res_kind where upper(name) = upper('Транспорт'))
        left join sr_res_role srr on srtte.res_role_id = srr.id or srttt.res_role_id = srr.id or srtjr.role_id = srr.id
      where srtjr.team_job_id = xbrg_id and (srtjr.deviation_id is null or srtjr.deviation_id in (2,7))
            and (srtjr.bdate <= xtrans)
            and (srtjr.edate >= xtodate or srtjr.edate is null)
      loop
        xrelationship_id :=nextval('sr_res_group_relationship_seq');
        if (resel.head = true or coalesce(resel.xroleE,resel.xroleT,resel.xrole) = (select id from sr_res_role where upper(code) = upper('TRANSPORT')))
        then xrole := coalesce(resel.xroleE,resel.xroleT,resel.xrole);
        else xrole :=
        case
        when (select upper(code) from sr_res_role where id = coalesce(resel.xroleE,resel.xroleT,resel.xrole)) like upper('DOCTOR%') then (select id from sr_res_role where upper(code) = upper('DOCTOR_ASST'))
        when (select upper(code) from sr_res_role where id = coalesce(resel.xroleE,resel.xroleT,resel.xrole)) like upper('PARAMEDIC%') then (select id from sr_res_role where upper(code) = upper('PARAMEDIC_ASST'))
        when (select upper(code) from sr_res_role where id = coalesce(resel.xroleE,resel.xroleT,resel.xrole)) like upper('DISPATCHER%') then (select id from sr_res_role where upper(code) = upper('DISPATCHER_ASST'))
        when (select upper(code) from sr_res_role where id = coalesce(resel.xroleE,resel.xroleT,resel.xrole)) like upper('DRIVER%') then (select id from sr_res_role where upper(code) = upper('DRIVER_ASST'))
        end;
        end if;
        INSERT INTO public.sr_res_group_relationship (id,bdatetime,edatetime,resource_id,group_id,role_id)
        VALUES (xrelationship_id,xfromdate,xtodate,resel.xres,xgroup,xrole);
      end loop;
      if (select upper(srr.e_code)
          from public.sr_res_group_relationship srgr
            join public.sr_res_role srr on srr.id = srgr.role_id
          where srgr.group_id = xgroup and srr.kind_id = 1) = upper('DOCTOR')
      then
        insert into public.md_resgroup_amb_profile (id,profile_id)
          select xgroup,profile_id from public.md_resgroup_amb_profile where id = (select resource_id from amb.sr_res_team rt left join amb.sr_res_team_job rtj on rtj.team_id = rt.id where rtj.id = xbrg_id);
      else
        insert into public.md_resgroup_amb_profile (id,profile_id)
        values(xgroup, (select id from public.md_ambulance_profile where e_code = '3'));
        update sr_res_group set name = concat('ф',name) where id =xgroup;
      end if;
    ELSE
      xname := (select srtjr.workplace||' '||pi.surname||' '||left(initcap(pi.name),1)||'. '||left(initcap(pi.patr_name),1)||'.'
                from amb.sr_res_team_job_resourse srtjr
                  join sr_resource sr on sr.id = srtjr.resource_id
                  join pim_employee_position_resource pepr on pepr.id = sr.id
                  join pim_employee_position pep on pep.id = pepr.employee_position_id
                  join pim_employee pe on pe.id = pep.employee_id
                  join pim_individual pi on pi.id = pe.individual_id
                  join pim_position ppos on ppos.id = pep.position_id
                where srtjr.id = xbrg_id);

      -- создаём системный составной ресурс
      xgroup = nextval('sr_res_group_seq');
      insert into sr_res_group (id,bdate,edate,is_system,name,org_id,department_id)
      values(xgroup,xfromdate,xtodate,true,xname,xclinic,xdep);
      --insert into md_res_group (id) values (xgroup);
      /*insert into public.sr_res_group_profile(id,res_group_id,profile_id)
          values(nextval('sr_res_group_profile_seq'),xgroup
          ,(select profile_id
              from sr_res_group_profile
              where res_group_id = (select resource_id
                                      from amb.sr_res_team rt
                                      join amb.sr_res_team_job rtj on rtj.team_id = rt.id and rtj.edate is null
                                      where rtj.id = xbrg_id)));*/

      -- пишем в состав системного составного ресурса
      select into xres, xresrole resource_id, role_id
      from  amb.sr_res_team_job_resourse where id = xbrg_id;
      -- //изменить так, чтоб транспорта не было
      xrelationship_id :=nextval('sr_res_group_relationship_seq');
      xrole :=
      case
      when (select upper(code) from sr_res_role where id = xresrole) = upper('DOCTOR') or (select upper(code) from sr_res_role where id = xresrole) = upper('DOCTOR_ASST')
        then (select id from sr_res_role where upper(code) = upper('DOCTOR'))
      when (select upper(code) from sr_res_role where id = xresrole) = upper('PARAMEDIC') or (select upper(code) from sr_res_role where id = xresrole) = upper('PARAMEDIC_ASST')
        then (select id from sr_res_role where upper(code) = upper('PARAMEDIC'))
      when (select upper(code) from sr_res_role where id = xresrole) = upper('DISPATCHER') or (select upper(code) from sr_res_role where id = xresrole) = upper('DISPATCHER_ASST')
        then (select id from sr_res_role where upper(code) = upper('DISPATCHER'))
      end;
      INSERT INTO public.sr_res_group_relationship (id,bdatetime,edatetime,resource_id,group_id,role_id)
      VALUES (xrelationship_id,xfromdate,xtodate,xres,xgroup,xrole);
    END IF;

    -- создаем шаг
    xstep = nextval('mc_step_seq');
    xprof = (select id from md_profile where e_code = '84');
    xcare_regimen = (select id from mc_care_regimen where e_code = '6');
    insert into mc_step(id,case_id, admission_date, admission_time,res_group_id,profile_id,is_continue,is_continue_editable)
    VALUES(xstep,xcase, cast(xfdt as date),cast(xfdt as time),xgroup,xprof,false,false);

    -- закрытие случая уходит в создание КВ
    --xcase_state = (select id from mc_case_state where e_code = '1');
    --update mc_case set closing_step_id = xstep, state_id = xcase_state where id = xcase;
    update mc_case set closing_step_id = xstep where id = xcase;

    -- создаем посещение
    xvisit_place = (select id from plc_visit_place where e_code = '3');
    xvisit_goal = (select init_goal_id from mc_case where id = xcase);
    xvisit_type =(select id from plc_visit_type where e_code ='1');
    xinitiator =(select id from plc_initiator where e_code =
                                                    case when xcall_kind in (4,6) or xcaller in (6)			-- условие очень спорно, нужно будет переписать для однозначности
                                                      then '2' else '1' end);
    insert into plc_visit (id,place_id,goal_id,type_id,initiator_id)
    values (xstep,xvisit_place,xvisit_goal,xvisit_type,xinitiator);

    --записываем "Оказанную услугу"
    xrendered = nextval('sr_srv_rendered_seq');
    xservice = (select id from sr_service where org_id = xclinic and code = 'SNMP');
    xduration = (select cast(EXTRACT(EPOCH FROM AGE(to_time, from_time))/60 as integer) from amb.md_ambulance_call where id = brg_list.id);
    xmeasure = (select id from sr_srv_duration_unit where measure_id = (select id from cmn_measure where e_code = '1'));
    xfunding = (select funding_id from mc_case where id = xcase);
    insert into public.sr_srv_rendered(id,is_rendered,customer_id,res_group_id,org_id,service_id,bdate,begin_time,edate
      ,duration,duration_measure_unit_id,quantity,funding_id, for_upload)
    values (xrendered,true,xcustomer_id,xgroup,xclinic,xservice
      ,cast(xfdt as date), cast(xfdt as time),CAST(xtodate as date),xduration,xmeasure,1,xfunding, true);

    -- md_srv_rendered
    insert into md_srv_rendered (id,case_id,step_id,is_urgent)
    values(xrendered,xcase,xstep,true);

    -- service_place_id = 1(на месте вызова), так как добавляем услугу вызова скорой помощи
    insert into amb.md_ambulance_call_services (call_id, service_id, service_place_id) values (brg_list.id, xrendered, 1);

    -- в посещение фиксируем длительность
    update plc_visit set duration = xduration where id = xstep;

    -- записываем данные об спц бригаде в результат вызова
    update amb.md_ambulance_call_result set srv_rendered_id = xrendered where id = brg_list.id;

    -- в случае если отметка о госпитализации была проставлена заранее, Результат по текущему mc_step должен быть "Доставлен в больницу (403)"
    if exists(select id from amb.md_ambulance_call_note where call_id = brg_list.id and note_id = 21 and note_active = true and note_type = true)
    then update public.mc_step set result_id = (select id from public.mc_step_result where e_code = '403')
    where case_id = (select case_id from amb.md_ambulance_call_result where id = brg_list.id);
    end if;

    -- отметка о доезде бригаде, которая поехала на спц вызов по текущему
    if exists(select child.id from amb.md_ambulance_call_on_base cob
      join amb.md_ambulance_call child on child.id = cob.id
    where cob.call_on_base_id = brg_list.id and child.call_kind_id = 5)
    then
      xstate := amb.add_ambcall_state_hist ((select child.id from amb.md_ambulance_call_on_base cob
        join amb.md_ambulance_call child on child.id = cob.id
      where cob.call_on_base_id = brg_list.id and child.call_kind_id = 5),xtodate,7,2,xreg);
    end if;

  END LOOP;
end;
$$;

