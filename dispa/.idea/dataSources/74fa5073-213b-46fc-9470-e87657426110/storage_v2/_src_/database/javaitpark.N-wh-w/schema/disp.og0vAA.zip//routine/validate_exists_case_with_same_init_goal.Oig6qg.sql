CREATE FUNCTION validate_exists_case_with_same_init_goal(xepid integer)
  RETURNS text
LANGUAGE plpgsql
AS $$
declare
                      event_type integer;
                      event_type_code character varying(10);
                      xinit_goal_id integer;
                      init_goal_name character varying(255);
                      individual_id integer;
                      xevent_age text;
                      model_ages text[];
                      model_age text;
                      ageyearmonth text;
			                ageyear text;
			                age text;
			                equal_ages text[];
			                equal_age text;
			                case_info text[];
			                case_info_orphans text[];
                    begin
                      select me.event_type into event_type from disp.md_event_patient mep
	                      left join disp.md_event me on me.id = mep.event_id
	                      where mep.id = xepid;
	                    select code into event_type_code from disp.md_event_type where id = event_type;
	                    select ett.case_init_goal_id into xinit_goal_id
                        from disp.md_event_type_target ett
                        where ett.event_type_id = event_type
	                      and ett.stage = 1
	                      and (begin_date is null or begin_date <= current_date)
	                      and (end_date is null or end_date >= current_date);
	                    select name into init_goal_name from mc_case_init_goal where id = xinit_goal_id;
	                    select indiv_id into individual_id from disp.md_event_patient where id = xepid;
	                    select event_age into xevent_age from disp.md_event_patient where id = xepid;

	                    model_ages=(select array_agg(row_to_json(row(mmpb.age)))
                        from disp.md_event_service mes
                        left join disp.md_event_service_model mesm on mesm.event_service_id = mes.id
                        left join disp.md_model_patient mmp on mmp.id = mesm.model_id
                        inner join disp.md_model_patient_base mmpb on mmpb.model_id = mmp.id
                        left join pim_individual i on i.id = individual_id
                        where mmpb.gender_id = i.gender_id 
                        and mes.event_id = (select event_id from disp.md_event_patient where id = xepid) 
                        and mmp.base is true);

                      ageyearmonth = xevent_age;
                      ageyear = xevent_age;
                      if (position('.' in xevent_age) > 0) then
			                  ageyear = left(xevent_age, position('.' in xevent_age)-1);
			                end if;

                      if model_ages is not null then
			                  foreach model_age in array model_ages
			                  loop
			                    model_age:=cast((model_age::json->'f1') as character varying);
			                    model_age:=substring(model_age from 2 for length(model_age)-2);
			                    foreach age in array regexp_split_to_array(replace(model_age,' ',''), ',')
			                    loop
			                      continue when age = any(equal_ages);
                            if(age like '%.%') then
                              if(age = ageyearmonth) then
                                equal_ages:=array_append(equal_ages,age);                                    
                              end if;
                            else
                              if(age = ageyear) then
                                equal_ages:=array_append(equal_ages,age);                                    
                              end if;
                            end if;
                          end loop;
                        end loop;
                      end if; 

	                    if (event_type_code like 'ДВ%') then
                        select array_agg(info) into case_info from (select concat('Номер случая: "', mc.uid, '", дата начала случая: ', to_char(mc.open_date, 'dd.mm.yyyy'), '.') info 
                          from mc_case mc
                          where mc.patient_id = individual_id
                          and mc.init_goal_id = xinit_goal_id
                          and mc.open_date is not null
	                        and (equal_ages @> ARRAY[(select concat(date_part('year',age(to_date(concat(extract(year from mc.open_date),'.12.31'), 'yyyy.mm.dd'),birth_dt)), '.', date_part('month',age(to_date(concat(extract(year from mc.open_date),'.12.31'), 'yyyy.mm.dd'),birth_dt))) from pim_individual where id = individual_id)]::text[]
	                        or equal_ages @> ARRAY[(select date_part('year',age(to_date(concat(extract(year from mc.open_date),'.12.31'), 'yyyy.mm.dd'),birth_dt)) from pim_individual where id = individual_id)]::text[])
	                        order by mc.open_date desc) as cases;
			                elsif (event_type_code like 'ДС%' or event_type_code like 'ОН%') then
			                  foreach equal_age in array equal_ages
			                  loop
                          select array_agg(info) into case_info_orphans from (select concat('Номер случая: "', mc.uid, '", дата начала случая: ', to_char(mc.open_date, 'dd.mm.yyyy'), ', дата окончания: ' || to_char(ms.outcome_date, 'dd.mm.yyyy'), '.') info 
                            from mc_case mc
                            left join mc_step ms on ms.id = mc.closing_step_id
                            where mc.patient_id = individual_id
                            and mc.init_goal_id = xinit_goal_id
                            and mc.open_date is not null
	                          and ((ms.outcome_date is null and (equal_age = (select concat(date_part('year',age(mc.open_date,birth_dt)), '.', date_part('month',age(mc.open_date,birth_dt))) from pim_individual where id = individual_id) or equal_age = (select concat(date_part('year',age(mc.open_date,birth_dt))) from pim_individual where id = individual_id)))
	                          or (ms.outcome_date is not null and equal_age::real >= (select concat(date_part('year',age(mc.open_date,birth_dt)))::real from pim_individual where id = individual_id) and equal_age::real <= (select concat(date_part('year',age(ms.outcome_date,birth_dt)), '.', date_part('month',age(ms.outcome_date,birth_dt)))::real from pim_individual where id = individual_id)))
	                          order by mc.open_date desc) as cases;
	                        case_info:=array_cat(case_info, case_info_orphans);
                        end loop;
			                end if;
			  
			                if (case_info is not null) then
	                      return concat('В ЭМК пациента есть уже случай с целью обращения "', init_goal_name, '". ', array_to_string(case_info, ' '));
	                    else
	                      return null;
	                    end if;
                    end;
$$;

