CREATE FUNCTION add_mse_main_org(org_name character varying, org_code character varying)
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
new_id INTEGER;
mse_role INTEGER;
mse_code INTEGER;
current_code character varying;
BEGIN
select poc.code INTO current_code from pim_organization po join pim_org_code poc on po.id = poc.org_id 
where poc.type_id = (SELECT id FROM pim_code_type WHERE code = 'MSE_CODE') and po.parent_id is null;
if current_code IS NOT NULL THEN RAISE EXCEPTION 'main org already present'; END IF; 
INSERT into pim_party (id, version, type_id) VALUES (nextval('pim_party_id_seq'), CURRENT_TIMESTAMP, 2) RETURNING id INTO new_id;
INSERT INTO pim_organization (full_name, short_name, id) VALUES ('Бюро МСЭ тест', 'Бюро МСЭ тест', new_id);

SELECT id INTO mse_role FROM pim_party_role WHERE code = 'BUREAU_OF_MED_SOC_EXPERTISE';
INSERT INTO pim_party_role_to_party (role_id, party_id) VALUES (mse_role, new_id);

SELECT id INTO mse_code FROM pim_code_type WHERE code = 'MSE_CODE';
INSERT INTO pim_org_code (id, code, type_id, org_id) VALUES (nextval('pim_org_code_seq'), org_code, mse_code, new_id);

END;
$$;

