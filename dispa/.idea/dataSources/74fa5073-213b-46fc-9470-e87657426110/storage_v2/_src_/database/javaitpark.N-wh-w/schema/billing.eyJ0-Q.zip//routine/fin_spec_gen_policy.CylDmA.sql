CREATE FUNCTION fin_spec_gen_policy(p1_bill_id integer, p2_status text)
  RETURNS void
STRICT
LANGUAGE plpgsql
AS $$
DECLARE 
    _main_bill_id INTEGER := public.fin_bill__get_main_bill (p1_bill_id);
    _clinic_id INTEGER;
    _financing_type_id INTEGER;
    _payer_id INTEGER;
    _payer_role TEXT;
    _payer_territory LTREE;
    _regions_arr INTEGER[];
    _is_local BOOLEAN;
    _is_foreign BOOLEAN;
    _is_nopolicy BOOLEAN;
    _all_region BOOLEAN;
BEGIN
    /*
        version: 2015-06-09
    */
    ----------------------------------------------------параметры для страховой принадлежности-------------------------------------------------------
    SELECT clinic_id, financing_type_id, payer_id INTO _clinic_id, _financing_type_id, _payer_id FROM public.fin_bill_main WHERE id = _main_bill_id
    ;
    IF
        (SELECT code FROM public.fin_funding_source_type WHERE id = _financing_type_id LIMIT 1) = 'OMS'
    THEN
        _payer_role := coalesce 
                        (
                            (
                                SELECT 
                                    r.code 
                                FROM 
                                    public.pim_party_role_to_party AS t, public.pim_party_role AS r 
                                WHERE 
                                    r.id = t.role_id AND t.party_id = _payer_id 
                                ORDER BY 
                                    r.code = 'HIF_ORGANIZATION' DESC NULLS LAST, r.code = 'MEDICAL_INSURANCE_ORGANIZATION' DESC NULLS LAST 
                                LIMIT 1
                            ), ''
                        )
        ;
    END IF;
    _regions_arr := ARRAY (SELECT region_id FROM public.fin_bill_main_to_region WHERE main_bill_id = _main_bill_id)
    ;
    IF 
        array_length (_regions_arr, 1) IS NOT NULL
    THEN
        _is_local    := (0 = ANY (_regions_arr));
        _is_foreign  := (1 = ANY (_regions_arr));
        _is_nopolicy := (2 = ANY (_regions_arr));
        _all_region  := _is_local AND _is_foreign AND _is_nopolicy;
    ELSE
        _is_local := TRUE; _is_foreign := TRUE; _is_nopolicy := TRUE; _all_region := TRUE;
    END IF;
    UPDATE billing.fin_bill_generate
    SET
        active_policy_id = public.fin_individual__get_active_policy (customer_id, case_close_date)
    WHERE
        bill_id = p1_bill_id AND NOT is_sifted
    ;
    UPDATE billing.fin_bill_generate AS f
    SET
        active_policy_issuer_id = i.issuer_id
    FROM
        public.pim_individual_doc AS i
    WHERE
        f.bill_id = p1_bill_id AND NOT f.is_sifted AND f.active_policy_id = i.id
    ;
    UPDATE billing.fin_bill_generate AS f
    SET
        smo_work_territory_id = o.work_territory_id
    FROM
        public.pim_organization AS o
    WHERE
        f.bill_id = p1_bill_id AND NOT f.is_sifted AND f.active_policy_issuer_id = o.id
    ;
    -------------------------------------------------------отсеивание по полису----------------------------------------------------------------------
    IF
        (SELECT code FROM public.fin_funding_source_type WHERE id = _financing_type_id) = 'OMS'
    THEN
        UPDATE billing.fin_bill_generate SET belonging_type = 'nopolicy' WHERE bill_id = p1_bill_id AND NOT is_sifted AND active_policy_id IS NULL
        ;
        UPDATE billing.fin_bill_generate SET belonging_type = 'nopolicy_issuer' WHERE bill_id = p1_bill_id AND NOT is_sifted AND belonging_type IS NULL AND active_policy_issuer_id IS NULL
        ;
        IF 
            _payer_role = 'MEDICAL_INSURANCE_ORGANIZATION' 
        THEN
            UPDATE billing.fin_bill_generate
            SET 
                belonging_type = CASE WHEN active_policy_issuer_id = _payer_id THEN 'local' ELSE 'foreign' END
            WHERE
                bill_id = p1_bill_id AND NOT is_sifted AND belonging_type IS NULL
            ;
            IF
                p2_status = 'GENERATE'
            THEN
                UPDATE billing.fin_bill_generate
                SET
                    is_sifted = TRUE, sifting_cause = 'Страховая принадлежность не подходит под выбранного плательщика'
                WHERE
                    bill_id = p1_bill_id AND NOT is_sifted AND belonging_type <> 'local'
                ;
            END IF;
        ELSE
            _payer_territory = 
            CASE 
                WHEN 
                    _payer_role = 'HIF_ORGANIZATION' 
                THEN 
                    (SELECT a.path FROM public.pim_organization AS o, public.address_element_data AS a WHERE o.work_territory_id = a.id AND o.id = _payer_id) 
                ELSE 
                    (SELECT a.path FROM public.pim_organization AS o, public.address_element_data AS a WHERE o.work_territory_id = a.id AND o.id = _clinic_id) 
            END;
            IF 
                p2_status = 'GENERATE' AND _payer_territory IS NULL
            THEN 
                UPDATE billing.fin_bill_generate
                SET 
                    is_sifted = TRUE, sifting_cause = 'Пустая территория обслуживания ' || CASE WHEN _payer_role = 'HIF_ORGANIZATION' THEN 'ТФОМС' ELSE 'ЛПУ' END
                WHERE 
                    bill_id = p1_bill_id AND NOT is_sifted
                ;
            ELSE
                WITH t AS 
                (
                    SELECT
                        f.bill_id, 
                        f.id,
                        CASE WHEN _payer_territory <@ a.path OR _payer_territory @> a.path THEN 'local' ELSE 'foreign' END AS belonging_type
                    FROM
                        billing.fin_bill_generate AS f
                        LEFT JOIN LATERAL (SELECT path FROM public.address_element_data WHERE id = f.smo_work_territory_id LIMIT 1) AS a ON TRUE
                    WHERE
                        f.bill_id = p1_bill_id AND NOT f.is_sifted AND f.belonging_type IS NULL
                )
                UPDATE billing.fin_bill_generate AS f
                SET 
                    belonging_type = t.belonging_type
                FROM t
                WHERE
                    f.bill_id = t.bill_id AND f.id = t.id
                ;
            END IF;
            IF
                p2_status = 'GENERATE' AND NOT _all_region
            THEN
                IF
                    _is_nopolicy AND _is_foreign
                THEN
                    UPDATE billing.fin_bill_generate
                    SET
                        is_sifted = TRUE, sifting_cause = 'Тип региона не подходит под выбранные: без полиса, чужой'
                    WHERE
                        bill_id = p1_bill_id AND NOT is_sifted AND belonging_type = 'local'
                    ;
                ELSIF
                    _is_nopolicy AND _is_local
                THEN
                    UPDATE billing.fin_bill_generate
                    SET
                        is_sifted = TRUE, sifting_cause = 'Тип региона не подходит под выбранные: без полиса, свой'
                    WHERE
                        bill_id = p1_bill_id AND NOT is_sifted AND belonging_type = 'foreign'
                    ;
                ELSIF
                     _is_foreign AND _is_local
                THEN
                    UPDATE billing.fin_bill_generate
                    SET
                        is_sifted = TRUE, sifting_cause = 'Тип региона не подходит под выбранные: чужой, свой'
                    WHERE
                        bill_id = p1_bill_id AND NOT is_sifted AND belonging_type LIKE 'nopolicy%'
                    ;
                ELSIF
                    _is_nopolicy
                THEN
                    UPDATE billing.fin_bill_generate
                    SET
                        is_sifted = TRUE, sifting_cause = 'Тип региона не подходит под выбранные: без полиса'
                    WHERE
                        bill_id = p1_bill_id AND NOT is_sifted AND belonging_type IN ('local', 'foreign')
                    ;
                ELSIF
                    _is_foreign
                THEN
                    UPDATE billing.fin_bill_generate
                    SET
                        is_sifted = TRUE, sifting_cause = 'Тип региона не подходит под выбранные: чужой'
                    WHERE
                        bill_id = p1_bill_id AND NOT is_sifted AND belonging_type IN ('local', 'nopolicy', 'nopolicy_issuer')
                    ;
                ELSIF
                    _is_local
                THEN
                    UPDATE billing.fin_bill_generate
                    SET
                        is_sifted = TRUE, sifting_cause = 'Тип региона не подходит под выбранные: свой'
                    WHERE
                        bill_id = p1_bill_id AND NOT is_sifted AND belonging_type IN ('foreign', 'nopolicy', 'nopolicy_issuer')
                    ;
                END IF;
            END IF;
        END IF;
    END IF;
EXCEPTION
    WHEN NO_DATA_FOUND THEN RAISE EXCEPTION 'Отсутствуют данные по счёту';
END;
$$;

