CREATE FUNCTION func_validate_used_bed(md_bed_resource_id integer, clinic_id integer, begin_dt date, end_dt date, patient_id integer, old_booking_id integer DEFAULT '-1'::integer, new_booking_status integer DEFAULT '-1'::integer)
  RETURNS text
LANGUAGE SQL
AS $$
SELECT 'Койка не может быть использована: ' || nullif(COALESCE (/*kf_not_setting.path, */ kf.path, notkf.path, '(свободна)'),'(свободна)') -- если (свободна) то результат = NULL
                FROM md_bed_resource r
                    INNER JOIN md_bed b ON r.bed_id = b.id
                    JOIN md_room room ON b.room_id = room.id
                    LEFT JOIN sr_resource sr on sr.id = r.id
                    LEFT OUTER JOIN md_bed_profile bp ON bp.id = b.bed_profile_id
                    -- если КФ включен смотрим состояние койки: недоступна, занята, запланирована подтверждена/не подтверждена, экстренная бронь, либо свободна если на все рассматриваемые дни есть свободные смены
                    LEFT JOIN LATERAL ( -- включен ли КФ (логика взята из receptionist_hospitalRecord.query.xml)
                            SELECT CASE
                               WHEN exists(SELECT 1
                                           FROM hospital.detailed_bed_sheduler_settings ds
                                               LEFT JOIN public.cmn_scope_type cst ON ds.level_id = cst.id
                                           WHERE cst.code = 'Clinic' AND ds.org_id = $2
                                                 AND ds.use_detailed_bed_sheduler IS TRUE AND
                                                 (ds.from_date IS NULL OR ds.from_date <= current_date))
                                   THEN true
                               ELSE
                                   CASE WHEN (NOT exists(
                                       SELECT 1
                                       FROM hospital.detailed_bed_sheduler_settings ds
                                           LEFT JOIN public.cmn_scope_type cst ON ds.level_id = cst.id
                                       WHERE cst.code = 'Clinic' AND ds.org_id = $2)
                                              AND exists(
                                                  SELECT 1
                                                  FROM hospital.detailed_bed_sheduler_settings ds
                                                      LEFT JOIN public.cmn_scope_type cst ON ds.level_id = cst.id
                                                  WHERE cst.code = 'Global' AND ds.use_detailed_bed_sheduler IS TRUE AND
                                                        (ds.from_date IS NULL OR ds.from_date <= current_date))
                                   )
                                       THEN true
                                   ELSE false
                                   END
                               END as check_used
                            where $2 <> -1
                            union ALL
                            select true as check_used where $2 = -1
                        ) kf_used on true

                    -- если КФ включен но в КФ не найдена койка то койка считается недоступной (модуль будет включен в разработку после обсуждения с Аналитиками, сейчас такие ресурсы занимать возможно)
                    /*LEFT JOIN LATERAL (
                        WITH param(
                               in_org_id,
                               in_begin_dt,
                               in_end_dt,
                               in_care_regimen_id,
                               in_department_id,
                               in_profile_id,
                               in_bed_profile_id,
                               in_patient_sex_id,
                               in_room_id
                           ) AS (
                           select  -1/*_in_org_id*/ :: INTEGER,
                                   $3:: date + interval '0 hours 0 minute 0 second' ,
                                   $4:: date + interval '23 hours 59 minute 59 second',-- _in_end_dt :: date + interval '23 hours 59 minute 59 second',
                                   -1:: INTEGER,
                                   -1:: INTEGER,
                                   -1:: INTEGER,
                                   -1:: INTEGER,
                                   -1:: INTEGER,
                                   room.id:: INTEGER
                           where check_used = TRUE
                           ),
                        interval_dt as (
                            SELECT  row_number() OVER (ORDER BY dt ) - 1 AS id,
                                    dt::date AS from_dt,
                                    dt + interval '1 day -1 sec' AS to_dt,
                                    to_char(dt, 'DD.MM.YYYY') AS from_dt_str,
                                    case when dt < in_end_dt then true else false end as from_dt_view
                            FROM    param
                                    join generate_series(in_begin_dt, /*in_degin_dt + INTERVAL '13 day'*/ in_end_dt, '1 day') dt on true
                            where   check_used = TRUE
                            ORDER BY dt),
                        bed_tree as (
                            SELECT  distinct
                                    d.id as d_id,
                                    p.id as p_id,
                                    room.id as r_id,
                                    b.id as b_id,
                                    mbr.id as res_id,
                                    d.id :: TEXT :: LTREE || p.id :: TEXT || p.id :: TEXT || room.id :: TEXT || b.id :: TEXT AS bed_tree, -- для использования исключений
                                    sr.power/*b.count_shift*/,
                                    b.number,
                                    d.name as d_name,
                                    p.name as p_name,
                                    room.name as pr_name
                            FROM    param join (select kf_mbr.id from md_bed_resource kf_mbr where kf_mbr.bed_id = b.id limit 1)  mbr on true
                                    JOIN LATERAL (select from pim_room_resource prr where prr.room_id = b.room_id limit 1) prr on true -- палата является ресурсом
                                    JOIN md_room mr ON b.room_id = mr.id
                                    JOIN pim_room room ON b.room_id = room.id and room.department_id = coalesce(nullif(in_department_id, -1), room.department_id)
                                    JOIN pim_department d ON d.id = room.department_id
                                    JOIN md_department_profile dp ON d.id = dp.department_id
                                    JOIN md_profile p ON p.id = dp.profile_id and p.id = coalesce(nullif(in_profile_id, -1), p.id)
                                    JOIN pim_room_type rt ON room.type_id = rt.id
                            WHERE   check_used = TRUE and b.room_id = coalesce(nullif(in_room_id, -1), b.room_id)
                            )
                        select b.id, 'в КФ для этой койки нет соответствующих настроек в окружении'::text as path
                        from param
                        where check_used = TRUE
                              and not exists (select from bed_tree bt where bt.b_id = b.id)
                    ) kf_not_setting on true*/
                    -- состояние коек по КФ логике:
                    LEFT JOIN LATERAL (
                        WITH param(
                               in_org_id,
                               in_begin_dt,
                               in_end_dt,
                               in_care_regimen_id,
                               in_department_id,
                               in_profile_id,
                               in_bed_profile_id,
                               in_patient_sex_id,
                               in_room_id
                           ) AS (
                           select  -1/*_in_org_id*/ :: INTEGER,
                                   $3:: date + interval '0 hours 0 minute 0 second' ,
                                   $4:: date + interval '23 hours 59 minute 59 second',-- _in_end_dt :: date + interval '23 hours 59 minute 59 second',
                                   -1:: INTEGER,
                                   -1:: INTEGER,
                                   -1:: INTEGER,
                                   -1:: INTEGER,
                                   -1:: INTEGER,
                                   room.id:: INTEGER
                           where check_used = TRUE
                           ),
                        interval_dt as (
                            SELECT  row_number() OVER (ORDER BY dt ) - 1 AS id,
                                    dt::date AS from_dt,
                                    dt + interval '1 day -1 sec' AS to_dt,
                                    to_char(dt, 'DD.MM.YYYY') AS from_dt_str,
                                    case when dt < in_end_dt then true else false end as from_dt_view
                            FROM    param
                                    join generate_series(in_begin_dt, /*in_degin_dt + INTERVAL '13 day'*/ in_end_dt, '1 day') dt on true
                            where   check_used = TRUE
                            ORDER BY dt),
                        bed_tree as (
                            SELECT  distinct
                                    d.id as d_id,
                                    p.id as p_id,
                                    room.id as r_id,
                                    b.id as b_id,
                                    --bp.id as bp_id,
                                    --o.id AS org_id,
                                    --cr.id AS care_regimen_id,
                                    --nullif(g.id, 3) AS g_id,
                                    mbr.id as res_id,
                                    d.id :: TEXT :: LTREE || p.id :: TEXT || p.id :: TEXT || room.id :: TEXT || b.id :: TEXT AS bed_tree, -- для использования исключений
                                    -- добавляем из за return out
                                    sr.power/*b.count_shift*/,
                                    --o.full_name AS org_name,
                                    --cr.name AS care_regimen_name,
                                    b.number,
                                    d.name as d_name,
                                    p.name as p_name,
                                    --rt.name as rt_name,
                                    room.name as pr_name
                                    --g.name as g_name,
                                    --bp.name as bp_name
                            FROM    param join (select kf_mbr.id from md_bed_resource kf_mbr where kf_mbr.bed_id = b.id limit 1)  mbr on true
                                    JOIN LATERAL (select from pim_room_resource prr where prr.room_id = b.room_id limit 1) prr on true -- палата является ресурсом
                                    JOIN md_room mr ON b.room_id = mr.id
                                    JOIN pim_room room ON b.room_id = room.id and room.department_id = coalesce(nullif(in_department_id, -1), room.department_id)
                                    --join pim_room r on r.id = b.room_id
                                    JOIN pim_department d ON d.id = room.department_id
                                    JOIN md_department_profile dp ON d.id = dp.department_id
                                    JOIN md_profile p ON p.id = dp.profile_id and p.id = coalesce(nullif(in_profile_id, -1), p.id)
                                    --JOIN pim_organization o on o.id = d.org_id and o.id = coalesce(nullif(in_org_id, -1), o.id )
                                    --JOIN mc_care_regimen cr ON b.regimen_id = cr.id and b.regimen_id = coalesce(nullif(in_care_regimen_id, -1), b.regimen_id)
                                    JOIN pim_room_type rt ON room.type_id = rt.id
                                    --JOIN md_bed_profile bp ON bp.id = b.bed_profile_id and bp.id = coalesce(nullif(in_bed_profile_id, -1), bp.id)
                                    --LEFT OUTER JOIN pim_gender g ON room.gender_id = g.id
                            WHERE   check_used = TRUE and b.room_id = coalesce(nullif(in_room_id, -1), b.room_id)
                                    and not exists(select from hospital.booking_status bst where bst.id = $7 and bst.code = '4')
                            )
                        ,
                        bed_room_profile as (
                            select r.r_id, rp.profile_id from bed_tree r join md_room_profile rp on rp.room_id = r.r_id group by 1, 2
                            ),
                        bed_room_tree as (
                            select distinct r.* from bed_tree r where not exists (select from bed_room_profile rp where rp.r_id = r.r_id)
                            union all
                            select distinct r.* from param join bed_tree r on true join bed_room_profile rp on r.r_id = rp.r_id and r.p_id = rp.profile_id and rp.profile_id = coalesce(nullif(in_profile_id, -1), rp.profile_id)
                            ),
                        bed_uses as (
                            select
                                b.bed_tree, b.b_id, bo.id, bo.step_id, bo.reservation_id, bo.status_id, '(в КФ койка содержит брони за указанный период)' as txt
                            FROM param
                                JOIN bed_room_tree b ON TRUE
                                join hospital.booking bo on bo.bed_id = b.b_id and bo.id <> $6
                                join hospital.booking_status bst on bst.id = bo.status_id and bst.code <> '4'
                            where
                                bo.begin_dt <= bo.end_dt
                                and bo.end_dt > in_begin_dt
                                and coalesce(sr.power, 0) < 1
                                and daterange(bo.begin_dt, bo.end_dt, '()') @> in_begin_dt::date
                                and bo.iscurrent
                            --- смотрим переходящую бронь с датыК - 1 день на датуК, если есть бронь то считаем что койка занята
                            union
                            select
                                b.bed_tree, b.b_id, bo.id, bo.step_id, bo.reservation_id, bo.status_id, '(в КФ койка содержит брони за указанный период)' as c
                            FROM param
                                JOIN bed_room_tree b ON TRUE
                                join hospital.booking bo on bo.bed_id = b.b_id and bo.id <> $6
                                join hospital.booking_status bst on bst.id = bo.status_id and bst.code <> '4'
                            where bo.begin_dt < in_end_dt
                                and bo.begin_dt <= bo.end_dt
                                and coalesce(sr.power, 0) < 1
                                and daterange(bo.begin_dt, bo.end_dt, '()') @> in_end_dt::date
                                and bo.iscurrent
                            union
                            --- смотрим все промежуточные дни за период (исключаем крайние даты из основного периода),если есть хоть одна бронь то койка недоступна
                            select b.bed_tree, b.b_id, bo.id, bo.step_id, bo.reservation_id, bo.status_id, '(в КФ койка содержит брони за указанный период)'
                            FROM param
                                JOIN bed_room_tree b ON TRUE
                                join hospital.booking bo on bo.bed_id = b.b_id and bo.id <> $6
                                join hospital.booking_status bst on bst.id = bo.status_id and bst.code <> '4'
                            where
                                bo.begin_dt <= bo.end_dt
                                and in_begin_dt::date <= in_end_dt ::date
                                and daterange(bo.begin_dt, bo.end_dt, '[]') && daterange(in_begin_dt::date, in_end_dt::date, '()') -- с помощью () исключили из периода начальную и конечную дату
                                and coalesce(sr.power, 0) < 1
                                and bo.iscurrent
                            union
                            --- смотрим все промежуточные дни за период (исключаем крайние даты из основного периода),если есть хоть одна бронь то койка недоступна
                            select b.bed_tree, b.b_id, null, null, null, 0, concat('(в КФ ', coalesce(u.comment, 'койка недоступна'), ')')
                            FROM param
                                JOIN bed_room_tree b ON TRUE
                                JOIN hospital.unused_bed u on u.bed_tree @> b.bed_tree
                            where
                                in_begin_dt::date <= in_end_dt::date
                                and daterange(in_begin_dt::date, in_end_dt::date, '[]') && u.date_range
                            union
                            --- по всем койкам у которых установлена мощность смотрим есть ли свободные койки
                            select bed_tree, b_id, null, null, null, 7, '(в КФ койка не имеет достаточных свободных смен)' from (
                                select b.bed_tree, b.b_id, null, null, null, dt.from_dt, sr.power - sum(bs.count_shift) as free_count--, bo.*
                                FROM
                                param
                                JOIN bed_room_tree b ON TRUE
                                join hospital.booking bo on bo.bed_id = b.b_id and bo.id <> $6
                                join hospital.booking_status bst on bst.id = bo.status_id and bst.code <> '4'
                                join interval_dt dt on true
                                --join hospital.booking bo on bo.bed_id = b.b_id
                                join hospital.booking_shift bs on bs.booking_id = bo.id and bs.dt = dt.from_dt
                                where
                                    bo.begin_dt <= bo.end_dt
                                    and in_begin_dt <= in_end_dt
                                    and sr.power > 0
                                    and daterange(bo.begin_dt, bo.end_dt, '[]') && daterange(in_begin_dt::date, in_end_dt::date, '[]')
                                    and bo.iscurrent
                                group by b.bed_tree, b.b_id, dt.from_dt, sr.power
                                having sr.power - sum(bs.count_shift) < 1)t
                            union
                            --- только в случае если coalesce(sr.power, 0) < 1 и уже есть хоть одна бронь считаем что занимать больше нельзя
                            select b.bed_tree, b.b_id, null, null, null, 0, concat('(добавить экстренную бронь нельзя, так как уже есть другая бронь на этот день)')
                            FROM param
                                JOIN bed_room_tree b ON TRUE
                                join hospital.booking bo on bo.bed_id = b.b_id and bo.id <> $6
                                join hospital.booking_status bos on bos.id = bo.status_id and bos.code <> '4'
                            where
                                coalesce(sr.power, 0) < 1
                                and exists(select from hospital.booking_status bst where bst.id = $7 and bst.code = '1')
                                and in_begin_dt::date <= in_end_dt::date
                                and daterange(bo.begin_dt, bo.end_dt, '[]') && daterange(in_begin_dt::date, in_end_dt::date, '[]')
                                and bo.iscurrent
                            union
                            -- исключаем возможность положить частично на день когда есть экстренная бронь
                            select
                                b.bed_tree, b.b_id, bo.id, bo.step_id, bo.reservation_id, bo.status_id, '(в КФ койка содержит экстренную бронь за указанный период)' as txt
                            FROM param
                                JOIN bed_room_tree b ON TRUE
                                join hospital.booking bo on bo.bed_id = b.b_id and bo.id <> $6
                                join hospital.booking_status bst on bst.id = bo.status_id and bst.code = '1'
                            where
                                bo.begin_dt <= bo.end_dt
                                and in_begin_dt::date <= in_end_dt ::date
                                and daterange(bo.begin_dt, bo.end_dt, '[]') && daterange(in_begin_dt::date, in_end_dt::date, '[]')
                                and coalesce(sr.power, 0) < 1
                                and bo.iscurrent
                        ),
                        -- по всем найденным мешающим койкам определим ФИО + исключим из списка записи с текущим пациентом
                        bed_uses_kf as (
                            select * from
                                (select -- смотрим все записи где есть step_id
                                    b.*,
                                    nullif(concat(initcap(i.surname), ' ' || upper(left(i.name, 1)) || '.', ' ' || upper(left(i.patr_name, 1)) || '.'), '') AS patient_name
                                from bed_uses b
                                    join mc_step s on s.id = b.step_id
                                    join mc_case c on c.id = s.case_id
                                    JOIN pim_individual i ON i.id = c.patient_id
                                where c.patient_id <> coalesce($5, -1)
                                union all-- смотрим все записи где нет step_id, но есть reservation_id
                                select b.*,
                                    nullif(concat(initcap(i.surname), ' ' || upper(left(i.name, 1)) || '.', ' ' || upper(left(i.patr_name, 1)) || '.'), '') AS patient_name
                                from bed_uses b
                                    join hsp_reservation hsr ON hsr.id = nullif(b.reservation_id, 0) --and hsr.bed_profile_id = bp.id
                                    JOIN md_referral mref ON mref.id = hsr.referral_id
                                    JOIN pim_individual i on i.id = mref.patient_id
                                where mref.patient_id <> coalesce($5, -1) and b.step_id is null
                                union ALL -- все остальные записи (экстренная бронь, койка неиспользуется)
                                select b.*, null
                                from bed_uses b
                                where b.step_id is null and b.reservation_id is null
                                )T
                            )
                        select distinct b_id, path
                        from (
                            select  b_id, t.status_id, first_value(txt) over(partition by t.b_id order by t.status_id) as path
                            from bed_uses_kf t
                        )t
                        union all  -- для определения что койка участвует в КФ добавим свободные смены
                        select distinct b.b_id, '(свободна)'
                        from bed_room_tree b where not exists (select from bed_uses_kf t where t.b_id = b.b_id)
                    ) kf on true
                    LEFT JOIN LATERAL (select case when kf.b_id = b.id then TRUE else FALSE end as check_kf_reest) kf_reest ON TRUE -- признак что койка участвует в КФ (свободна, есть брони или исключения)
                    LEFT JOIN LATERAL ( -- определяем что койка свободна или нет из ресурсов (когда КФ отключен)
                        SELECT
                            CASE
                            WHEN NOT EXISTS(
                                SELECT 1
                                FROM sr_res_group_relationship rgrel
                                    JOIN mc_step ON mc_step.res_group_id = rgrel.group_id
                                WHERE rgrel.resource_id = r.id AND
                                      (NOT ($3 :: TIMESTAMP > rgrel.edatetime OR
                                            $4 :: TIMESTAMP IS NOT NULL AND
                                            $4 :: TIMESTAMP < rgrel.bdatetime)
                                       OR
                                       ($4 :: TIMESTAMP IS NULL OR $4 :: TIMESTAMP > rgrel.bdatetime) AND
                                       rgrel.edatetime IS NULL
                                      ) AND
                                      (mc_step.outcome_date IS NULL OR
                                       (mc_step.outcome_date + COALESCE(mc_step.outcome_time, '00:00:00' :: TIME)) >=
                                       $3 :: TIMESTAMP))
                            THEN '(свободна)'
                            ELSE (
                                  SELECT '(' || COALESCE(i.surname, '') || ' '
                                         || CASE COALESCE(SUBSTRING(i.name FOR 1), '')
                                            WHEN ''
                                                THEN ''
                                            ELSE SUBSTRING(i.name FOR 1) || '.' END || ' ' ||
                                         CASE COALESCE(SUBSTRING(i.patr_name FOR 1), '')
                                         WHEN ''
                                             THEN ''
                                         ELSE SUBSTRING(i.patr_name FOR 1) || '.' END
                                         || ', номер случая ' || mc_case.uid || ')'
                                  FROM sr_res_group_relationship rgrel
                                      JOIN mc_step ON mc_step.res_group_id = rgrel.group_id
                                      JOIN mc_case ON mc_case.id = mc_step.case_id
                                      JOIN pci_patient ON pci_patient.id = mc_case.patient_id
                                      JOIN pim_individual i ON i.id = pci_patient.id
                                  WHERE  rgrel.resource_id = r.id AND
                                         mc_case.patient_id <> coalesce($5, -1) AND
                                         mc_case.clinic_id = coalesce(nullif($2, -1), mc_case.clinic_id) AND
                                        (NOT ($3 :: TIMESTAMP > rgrel.edatetime OR
                                              $4 :: TIMESTAMP IS NOT NULL AND
                                              $4 :: TIMESTAMP < rgrel.bdatetime)
                                         OR
                                         ($4 :: TIMESTAMP IS NULL OR $4 :: TIMESTAMP > rgrel.bdatetime) AND
                                         rgrel.edatetime IS NULL)
                                  ORDER BY rgrel.bdatetime DESC
                                  LIMIT 1)
                            END AS path
                        WHERE NOT kf_reest.check_kf_reest -- стандартную проверку делаем когда койка не участвует в КФ
			        ) notkf on true
                where r.id = $1;
$$;

