CREATE FUNCTION add_prescription_count_execution_on_sr_srv_rendered_update()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE
    count_execution_var varchar;
    patient_prescription_id_var integer;
BEGIN
	select patient_prescription_id from md_srv_rendered into patient_prescription_id_var where id = NEW.id;
	IF (patient_prescription_id_var is not null) THEN
	    count_execution_var := count_of_execution_prescription(patient_prescription_id_var);
	    UPDATE md_patient_prescription SET count_execution = count_execution_var WHERE id = patient_prescription_id_var;
	END IF;
	RETURN NEW;
END;
$$;

