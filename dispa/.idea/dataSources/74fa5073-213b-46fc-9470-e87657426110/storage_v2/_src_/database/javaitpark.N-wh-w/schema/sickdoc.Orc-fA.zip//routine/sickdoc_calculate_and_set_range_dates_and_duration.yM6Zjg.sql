CREATE FUNCTION sickdoc_calculate_and_set_range_dates_and_duration(p_sickdoc_id integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
                  l_begin_dt DATE;
                  l_days INTEGER;
                  l_end_dt DATE;
                BEGIN
                  l_begin_dt = (SELECT from_dt
                                FROM sickdoc.period
                                WHERE sickdoc_id = p_sickdoc_id
                                ORDER BY from_dt ASC
                                LIMIT 1);

                  l_end_dt = (SELECT to_dt
                              FROM sickdoc.period
                              WHERE sickdoc_id = p_sickdoc_id
                              ORDER BY to_dt DESC
                              LIMIT 1);

                  l_days = cast((l_end_dt - l_begin_dt) as integer) + 1;
                  UPDATE sickdoc.sickdoc
                  SET
                    begin_dt = l_begin_dt,
                    end_dt   = l_end_dt,
                    days     = l_days
                  WHERE id = p_sickdoc_id;
                END;
$$;

