CREATE FUNCTION fin_price_modifier_need_apply(p1_id integer, p2_condition text, OUT r boolean)
  RETURNS boolean
STABLE
STRICT
LANGUAGE plpgsql
AS $$
BEGIN
    /*
        current version date 2014-12-15
    */
    IF 
        nullif (trim (p2_condition), '') IS NULL 
    THEN 
        r := TRUE;
    ELSIF 
        p2_condition ILIKE 'SELECT%' 
    THEN 
        EXECUTE replace (p2_condition, '?', p1_id::TEXT) INTO r; r := coalesce (r, FALSE);
    ELSE 
        r := FALSE;
    END IF;
END;
$$;

