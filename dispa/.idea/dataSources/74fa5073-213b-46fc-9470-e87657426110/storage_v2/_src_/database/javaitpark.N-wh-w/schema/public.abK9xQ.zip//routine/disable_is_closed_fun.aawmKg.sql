CREATE FUNCTION disable_is_closed_fun()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
    IF coalesce(NEW.is_closed, false) <> coalesce(OLD.is_closed, false) THEN
      RAISE EXCEPTION 'column "is_closed" is not editable';
      RETURN NULL;
    END IF;
    RETURN NULL;
  END;
$$;

