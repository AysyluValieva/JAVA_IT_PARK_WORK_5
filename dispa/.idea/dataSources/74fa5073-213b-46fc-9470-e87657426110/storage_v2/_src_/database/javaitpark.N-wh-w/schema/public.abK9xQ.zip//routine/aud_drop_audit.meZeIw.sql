CREATE FUNCTION aud_drop_audit()
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
	table_name varchar;
    BEGIN
	FOR table_name IN select event_object_schema ||'.'|| event_object_table from information_schema.triggers where trigger_name = 'audit_trigger' group by 1
	LOOP
            EXECUTE format('select aud_drop_audit(''%s'');', table_name);
	END LOOP;
    END;
$$;

