CREATE FUNCTION fun_test_2()
  RETURNS TABLE(id numeric, number numeric, name text, znach numeric)
LANGUAGE plpgsql
AS $$
DECLARE
 rec RECORD;
BEGIN
FOR rec IN EXECUTE 'select * from work.test where znach = 10'
	LOOP
		id = rec.id;
		number =rec.number;
		name = rec.name;
		znach = rec.znach;
		RETURN next;
	END LOOP;
END;
$$;

