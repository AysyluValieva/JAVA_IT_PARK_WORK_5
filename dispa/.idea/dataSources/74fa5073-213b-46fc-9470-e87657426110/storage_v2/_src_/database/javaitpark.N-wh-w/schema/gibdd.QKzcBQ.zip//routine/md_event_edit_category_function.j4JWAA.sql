CREATE FUNCTION md_event_edit_category_function(xreferenceid integer, xcategories character varying)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
                categoryid json;
            begin
                delete from gibdd.md_gibdd_reference_category where reference_id = xreferenceid;
                foreach categoryid in array array(select value from json_array_elements(cast(xcategories as json)))
                LOOP
                    insert into gibdd.md_gibdd_reference_category(reference_id, category_id) values (xreferenceid, categoryid::text::int);
                END LOOP;
                return xreferenceid;
            end;
$$;

