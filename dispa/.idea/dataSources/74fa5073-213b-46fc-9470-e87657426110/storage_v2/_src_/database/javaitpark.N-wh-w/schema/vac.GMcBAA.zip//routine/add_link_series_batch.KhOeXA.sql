CREATE FUNCTION add_link_series_batch(xbatch_id integer, xseries_id integer, xstore_supply_id integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
DECLARE
    existsLink BOOLEAN;
    nullName BOOLEAN;
  BEGIN
    IF ($1 IS NOT NULL AND $2 IS NOT NULL ) THEN
      existsLink = (SELECT exists(SELECT 1 from vac.batch_vac_series WHERE batch_id = $1));
      nullName = (SELECT trim(series) = '' from inventory.batch WHERE id = $1 LIMIT 1);
      IF (NOT existsLink AND (nullName or $3 ISNULL )) THEN
        INSERT INTO vac.batch_vac_series (batch_id, series_id)  VALUES ($1,$2);
      END IF;
    END IF;
    RETURN $3;
  END;
$$;

