CREATE FUNCTION apda_check_district_by_age_criterion(age integer, district_id integer)
  RETURNS boolean
LANGUAGE plpgsql
AS $$
BEGIN
  RETURN (SELECT exists(SELECT 1
                        FROM md_district_age a
                        WHERE a.district_id = $2 AND $1 BETWEEN a.from_age AND a.to_age
                        LIMIT 1));
END;
$$;

