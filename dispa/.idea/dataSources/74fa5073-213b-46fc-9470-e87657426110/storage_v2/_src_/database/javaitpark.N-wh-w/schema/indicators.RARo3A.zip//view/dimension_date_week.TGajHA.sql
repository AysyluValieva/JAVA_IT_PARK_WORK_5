CREATE VIEW dimension_date_week AS
  SELECT dimension_date.id,
    dimension_date.year_,
    dimension_date.quarter_of_year,
    dimension_date.month_of_year,
    dimension_date.week_of_year,
    dimension_date.half_of_year,
    dimension_date.aud_who,
    dimension_date.aud_when,
    dimension_date.aud_source,
    dimension_date.aud_who_create,
    dimension_date.aud_when_create,
    dimension_date.aud_source_create
   FROM indicators.dimension_date
  WHERE (dimension_date.dimension_date_def_id = 5);

COMMENT ON VIEW dimension_date_week IS 'Временной срез. Год, квартал, месяц, неделя';

COMMENT ON COLUMN dimension_date_week.id IS 'Идентификатор';

COMMENT ON COLUMN dimension_date_week.year_ IS 'Год';

COMMENT ON COLUMN dimension_date_week.quarter_of_year IS 'Квартал года';

COMMENT ON COLUMN dimension_date_week.month_of_year IS 'Месяц года';

COMMENT ON COLUMN dimension_date_week.week_of_year IS 'Неделя года';

COMMENT ON COLUMN dimension_date_week.half_of_year IS 'Полугодие года';

