CREATE FUNCTION delete_org_unit()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
            IF TG_OP = 'DELETE' THEN
            IF (OLD.unit_id is not null) THEN
            delete from pim_org_unit where id = OLD.unit_id;
            END IF;
            RETURN OLD;
            END IF;
            END;
$$;

