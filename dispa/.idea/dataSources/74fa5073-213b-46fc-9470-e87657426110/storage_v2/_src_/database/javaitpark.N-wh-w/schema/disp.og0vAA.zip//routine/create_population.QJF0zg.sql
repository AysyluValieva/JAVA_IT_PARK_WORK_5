CREATE FUNCTION create_population(xid integer, xorg_id integer, xyear character varying, xm21_36_begin integer, xf21_36_begin integer, xm39_60_begin integer, xf39_60_begin integer, xm60_begin integer, xf60_begin integer, xm21_36_disp integer, xf21_36_disp integer, xm39_60_disp integer, xf39_60_disp integer, xm60_disp integer, xf60_disp integer, xch0_4_disp integer, xch5_9_disp integer, xch10_14_disp integer, xch15_17_disp integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
declare

        begin
        if (xid is null) then
          INSERT INTO disp.md_population(
                    id, org_id, year, m21_36_begin, f21_36_begin, m39_60_begin, f39_60_begin,
                    m60_begin, f60_begin, m21_36_disp, f21_36_disp, m39_60_disp,
                    f39_60_disp, m60_disp, f60_disp, ch0_4_disp, ch5_9_disp, ch10_14_disp,
                    ch15_17_disp)
                    VALUES (nextval('disp.md_population_id_seq'), xorg_id, substr(xyear,1,4), xm21_36_begin, xf21_36_begin, xm39_60_begin, xf39_60_begin,
                    xm60_begin, xf60_begin, xm21_36_disp, xf21_36_disp, xm39_60_disp,
                    xf39_60_disp, xm60_disp, xf60_disp, xch0_4_disp, xch5_9_disp, xch10_14_disp,
                    xch15_17_disp);
        else
	  UPDATE disp.md_population
          SET year=substr(xyear,1,4), m21_36_begin=xm21_36_begin, f21_36_begin=xf21_36_begin, m39_60_begin=xm39_60_begin,
          f39_60_begin=xf39_60_begin, m60_begin=xm60_begin, f60_begin=xf60_begin, m21_36_disp=xm21_36_disp, f21_36_disp=xf21_36_disp,
          m39_60_disp=xm39_60_disp, f39_60_disp=xf39_60_disp, m60_disp=xm60_disp, f60_disp=xf60_disp, ch0_4_disp=xch0_4_disp,
          ch5_9_disp=xch5_9_disp, ch10_14_disp=xch10_14_disp, ch15_17_disp=xch15_17_disp
          WHERE id = xid;
        end if;
        end;
$$;

