CREATE FUNCTION family_member_update(p_sikdoc_extended_id integer, p_disability_reason_code character varying, p_care_for_patient_id1 integer, p_care_for_patient_id2 integer, p_family_relation_id1 integer, p_family_relation_id2 integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
  c_care_for_family_member_code CONSTANT VARCHAR = '09';
  l_family_member_id1 INTEGER;
  l_family_member_id2 INTEGER;
BEGIN
  SELECT
    family_member_1_id,
    family_member_2_id
  FROM sickdoc.sickdoc_extended
  WHERE id = p_sikdoc_extended_id
  INTO l_family_member_id1, l_family_member_id2;

  IF p_disability_reason_code = c_care_for_family_member_code
  THEN

    IF l_family_member_id1 NOTNULL
    THEN
      UPDATE sickdoc.family_member
      SET patient_id = p_care_for_patient_id1, relation_id = p_family_relation_id1
      WHERE
        id = l_family_member_id1;
    ELSE
      INSERT INTO sickdoc.family_member (id, patient_id, relation_id)
      VALUES (DEFAULT, p_care_for_patient_id1, p_family_relation_id1)
      RETURNING id
        INTO l_family_member_id1;
      UPDATE sickdoc.sickdoc_extended
      SET family_member_1_id = l_family_member_id1;
    END IF;

    IF p_care_for_patient_id2 NOTNULL
    THEN
      IF l_family_member_id2 ISNULL
      THEN
        INSERT INTO sickdoc.family_member (id, patient_id, relation_id)
        VALUES (DEFAULT, p_care_for_patient_id2, p_family_relation_id2)
        RETURNING id
          INTO l_family_member_id2;
        UPDATE sickdoc.sickdoc_extended
        SET family_member_2_id = l_family_member_id2;
      ELSE
        UPDATE sickdoc.family_member
        SET patient_id = p_care_for_patient_id2, relation_id = p_family_relation_id2
        WHERE
          id = l_family_member_id2;
      END IF;
    END IF;

  ELSE
    DELETE FROM sickdoc.family_member
    WHERE id = l_family_member_id1;
    DELETE FROM sickdoc.family_member
    WHERE id = l_family_member_id2;
  END IF;
END;
$$;

