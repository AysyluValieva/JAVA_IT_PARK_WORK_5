CREATE FUNCTION get_available_profiles(from_dt date, to_dt date)
  RETURNS TABLE(id integer, name text)
LANGUAGE plpgsql
AS $$
BEGIN
                  IF (from_dt IS NULL AND to_dt IS NULL)
                  THEN
                    from_dt := current_date - INTERVAL '14 day';
                    to_dt := current_date + INTERVAL '14 day';
                  ELSEIF from_dt IS NULL
                    THEN from_dt := to_dt - INTERVAL '1 month';
                  ELSEIF to_dt IS NULL
                    THEN to_dt := from_dt + INTERVAL '1 month';
                  END IF;
                  RETURN QUERY WITH profiles AS (
                      SELECT DISTINCT
                        d.id                                                  AS d_id,
                        p.id                                                  AS id,
                        p.name                                                AS name,
                        d.id :: TEXT :: LTREE || p.id :: TEXT || p.id :: TEXT AS bed_tree
                      FROM public.pim_department d
                        JOIN public.md_department_profile dp ON d.id = dp.department_id
                        JOIN public.pim_department_type t ON d.type_id = t.id AND trim(lower(t.code)) IN ('3', lower('SURGERY'))
                        JOIN public.md_profile p ON p.id = dp.profile_id
                      GROUP BY d.id, p.id
                  )
                  SELECT
                    p.id,
                    p.name
                  FROM profiles p
                    JOIN generate_series(from_dt :: DATE, to_dt :: DATE,
                         '1 day') dd(dt) ON TRUE
                    LEFT JOIN LATERAL (SELECT TRUE AS is_unused
                                       FROM hospital.unused_bed u
                                       WHERE nlevel(u.bed_tree) = 3 AND u.bed_tree @> p.bed_tree AND u.date_range @> dd.dt :: DATE
                                       LIMIT 1) u ON TRUE
                  WHERE is_unused IS NULL
                  GROUP BY p.id, p.name;
                END;
$$;

