CREATE FUNCTION createevent(xid integer, xname character varying, xorg integer, xfund integer, xsdate character varying, xedate character varying, xstandard integer, xetype integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
          i integer;
        begin
          i = xid;
          if (select count(*) from disp.md_event where id = xid) > 0 then
            update disp.md_event set name = xname, org_id = xorg, event_type=xeType, pay_type = xfund, start_date = to_date(xsdate, 'DD.MM.YYYY'), end_date = to_date(xedate, 'DD.MM.YYYY'), standard_id = xstandard
              where disp.md_event.id = xid;
            delete from disp.md_event_service where event_id = xid;
            insert into disp.md_event_service
              select nextval('disp.md_event_service_id_seq')::int as id, i event_id, COALESCE(ss.org_id, (select org_id from sr_service where id = sssd.service_id))::int org_id,
                     mspe.res_group_id, COALESCE(ss.id, sssd.service_id)::int service_id,
                     CASE WHEN CAST(mspe.priority as integer) = 1 THEN TRUE ELSE FALSE END, CASE WHEN CAST(mspe.priority as integer) = 2 THEN TRUE ELSE FALSE END, mspe.district_check, msp.id, mspe.order_idx, mspe.ignore_service
              from md_standard_prescription msp
                left join md_standard ms on ms.id = xstandard
                left join md_prescription mp on mp.id = msp.id
                left join sr_service ss on ss.id = mp.service_type_id
                left join disp.md_standard_prescription_extended mspe on mspe.id = msp.id
                left join md_norm_document_service mnds on mnds.id = mspe.norm_doc_service_id
                left join disp.sr_srv_service_document sssd on sssd.document_service_id = mnds.id and sssd.owner_org_id = xorg -- Документ "Взрослая дисп. 1 этап"
              where msp.standard_id = xstandard;

            insert into disp.md_event_service_model
              select nextval('disp.md_event_service_model_id_seq')::int as id, mes.id event_service_id, mspe.model_patient_id model_id, TRUE is_based
              from disp.md_event_service mes
                left join disp.md_standard_prescription_extended mspe on mspe.id = mes.standard_prescription_id
              where mes.event_id = i and mspe.model_patient_id IS NOT NULL;
          else
            insert into disp.md_event(id, org_id, event_type, name, standard_id, start_date, pay_type, end_date)
              values(i,xorg,xeType,xname,xstandard,to_date(xsdate, 'DD.MM.YYYY'),xfund,to_date(xedate, 'DD.MM.YYYY'));
            insert into disp.md_event_service
              select nextval('disp.md_event_service_id_seq')::int as id, i event_id, COALESCE(ss.org_id, (select org_id from sr_service where id = sssd.service_id))::int org_id,
                     mspe.res_group_id, COALESCE(ss.id, sssd.service_id)::int service_id,
                     CASE WHEN CAST(mspe.priority as integer) = 1 THEN TRUE ELSE FALSE END, CASE WHEN CAST(mspe.priority as integer) = 2 THEN TRUE ELSE FALSE END, mspe.district_check, msp.id, mspe.order_idx, mspe.ignore_service
              from md_standard_prescription msp
                left join md_standard ms on ms.id = xstandard
                left join md_prescription mp on mp.id = msp.id
                left join sr_service ss on ss.id = mp.service_type_id
                left join disp.md_standard_prescription_extended mspe on mspe.id = msp.id
                left join md_norm_document_service mnds on mnds.id = mspe.norm_doc_service_id
                left join disp.sr_srv_service_document sssd on sssd.document_service_id = mnds.id and sssd.owner_org_id = xorg -- Документ "Взрослая дисп. 1 этап"
              where msp.standard_id = xstandard;
            insert into disp.md_event_service_model
              select nextval('disp.md_event_service_model_id_seq')::int as id, mes.id event_service_id, mspe.model_patient_id model_id, TRUE is_based
              from disp.md_event_service mes
                left join disp.md_standard_prescription_extended mspe on mspe.id = mes.standard_prescription_id
              where mes.event_id = i and mspe.model_patient_id IS NOT NULL;
          end if;
          return i;
        end;
$$;

