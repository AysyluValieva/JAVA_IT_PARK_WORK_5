CREATE FUNCTION saveorphansinspec(xepid integer, xssrid integer, xcaseid integer, xbdate character varying, xresource integer, xmd integer, xdis integer, xcounsel character varying, xreference character varying, xservice integer, xsuspicion boolean)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
          serviceid integer;
          srrid integer;
          stepid integer;
          sysresid integer;
          result_id integer;
        begin
          serviceid = xservice;
          if (select count(meec.id) from disp.md_event_eq_case meec
                left join MD_SRV_RENDERED msr on msr.case_id = meec.case_id
                inner join SR_SRV_RENDERED ssr on ssr.id = msr.id and ssr.service_id = serviceid
                where meec.event_patient_id = xepid) > 0 then
              if xssrid IS NULL then
                xssrid = (select ssr.id from disp.md_event_eq_case meec
                left join MD_SRV_RENDERED msr on msr.case_id = meec.case_id
                inner join SR_SRV_RENDERED ssr on ssr.id = msr.id and ssr.service_id = serviceid
                where meec.event_patient_id = xepid);
              end if;
              srrid = xssrid;
              update mc_step set admission_date = COALESCE(to_date(xbdate, 'DD.MM.YYYY'), current_date), outcome_date = COALESCE(to_date(xbdate, 'DD.MM.YYYY'), current_date)
                where id = (select step_id from disp.md_disp_orphans_inspec where service_id = xssrid);
--               Обновляем случай
--               update MC_CASE set open_date = (
--                 select ssr.bdate from disp.md_event_patient mep
--                         left join disp.md_event_service_patient mesp on mesp.event_patient_id = mep.id
--                         left join disp.md_event_service mes on mes.id = mesp.service_id
--                         left join disp.sr_srv_service_document sssd on sssd.service_id = mes.service_id -- Документ "Взрослая дисп. 1 этап"
--                         left join md_norm_document_service mnds on mnds.id = sssd.document_service_id
--                         left join disp.md_event_eq_case meec on meec.event_patient_id = mep.id
--                         left join (select ssr.id, msr.case_id, ssr.service_id, ssr.res_group_id, ssr.bdate from MD_SRV_RENDERED msr
--                         left join SR_SRV_RENDERED ssr on ssr.id = msr.id) as ssr on ssr.case_id = meec.case_id and ssr.service_id = sssd.service_id
--                         where mnds.code = 'Д1.02' and mep.id = xepid
--                 )
--               where id = xcaseId;
              if xresource != (select res_group_id from SR_SRV_RENDERED where id = xssrid) then
                sysresid = nextval('sr_res_group_seq');
                insert into SR_RES_GROUP(id, bdate, edate, is_system, name, department_id, org_id, responsible_id, is_available_in_electronic_queue, label_id)
                  select sysresid as id, bdate, edate, TRUE as is_system, name, department_id, org_id, responsible_id, is_available_in_electronic_queue, label_id
                  from SR_RES_GROUP
                  where id = xresource;
                update mc_step set res_group_id = sysresid
                  where id = (select step_id from disp.md_disp_orphans_inspec where service_id = xssrid);
              end if;
              update mc_diagnosis set diagnos_id =  xmd, disease_type_id = xdis, establishment_date = COALESCE(to_date(xbdate, 'DD.MM.YYYY'), current_date)
                where id = (select diagnos_id from disp.md_disp_orphans_inspec where service_id = xssrid);
              update disp.md_dispr_diagnosis_service set resource_id = xresource, service_id = serviceid
                where diagnosis_id = (select diagnos_id from disp.md_disp_orphans_inspec where service_id = xssrid);
              update SR_SRV_RENDERED set bdate=COALESCE(to_date(xbdate, 'DD.MM.YYYY'), current_date), edate=COALESCE(to_date(xbdate, 'DD.MM.YYYY'), current_date), res_group_id=xresource
               where id = xssrid;
              if (select count(id) from disp.md_disp_orphans_inspec where service_id = xssrid) > 0 then
                update disp.md_disp_orphans_inspec set main_diagnos=xmd, disease=xdis, counsel=xcounsel, reference=xreference
                  where service_id = xssrid;
              else
                insert into disp.md_disp_orphans_inspec (id, event_patient_id, service_id, main_diagnos, other_diagnos_1, other_diagnos_2, disease, counsel, reference)
                  values (nextval('disp.md_disp_orphans_inspec_id_seq'), xepid, srrid, xmd, xdis, xcounsel, xreference);
              end if;
          else
            srrid = nextval('sr_srv_rendered_seq');
            stepid =  nextval('mc_step_seq');
            sysresid = nextval('sr_res_group_seq');
            -- insert newsysres, step, visit, diag
            insert into SR_RES_GROUP(id, bdate, edate, is_system, name, department_id, org_id, responsible_id, is_available_in_electronic_queue, label_id)
              select sysresid as id, bdate, edate, TRUE as is_system, name, department_id, org_id, responsible_id, is_available_in_electronic_queue, label_id
              from SR_RES_GROUP
              where id = xresource;
            insert into mc_step (id, admission_date, outcome_date, case_id, regimen_id, res_group_id, outcome_id, profile_id)
              values (stepid, COALESCE(to_date(xbdate, 'DD.MM.YYYY'), current_date), COALESCE(to_date(xbdate, 'DD.MM.YYYY'), current_date), xcaseId, (select id from mc_care_regimen where code = 1), sysresid, (select id from mc_step_care_result where code = '306'),
                      (select mp.id from SR_RES_GROUP srg
                       left join SR_RES_GROUP_RELATIONSHIP srgr on srgr.group_id = srg.id
                       inner join pim_employee_position_resource pepr on pepr.id = srgr.resource_id
                       left join PIM_EMPLOYEE_POSITION pep on pep.id = pepr.employee_position_id
                       left join PIM_POSITION pp on pp.id = pep.POSITION_ID
                       left join PIM_SPECIALITY ps on ps.id = pp.speciality_id
                       left join disp.md_profile_specialty mps on mps.spec_code = ps.code
                       left join md_profile mp on mp.code = mps.profile_code
                       where srg.id = xresource limit 1));
            insert into plc_visit (id, goal_id, place_id) values (stepid, (select mett.case_init_goal_id from disp.md_event_patient mep left join disp.md_event me on me.id = mep.event_id left join disp.md_event_type_target mett on mett.event_type_id = me.event_type where mep.id = xepid and (mett.begin_date is null or mett.begin_date <= current_date) and (mett.end_date is null or mett.end_date >= current_date)),
            (select id from plc_visit_place where code = '1'));
--             update MC_CASE set open_date = (
--                 select ssr.bdate from disp.md_event_patient mep
--                         left join disp.md_event_service_patient mesp on mesp.event_patient_id = mep.id
--                         left join disp.md_event_service mes on mes.id = mesp.service_id
--                         left join disp.sr_srv_service_document sssd on sssd.service_id = mes.service_id -- Документ "Взрослая дисп. 1 этап"
--                         left join md_norm_document_service mnds on mnds.id = sssd.document_service_id
--                         left join disp.md_event_eq_case meec on meec.event_patient_id = mep.id
--                         left join (select ssr.id, msr.case_id, ssr.service_id, ssr.res_group_id, ssr.bdate from MD_SRV_RENDERED msr
--                         left join SR_SRV_RENDERED ssr on ssr.id = msr.id) as ssr on ssr.case_id = meec.case_id and ssr.service_id = sssd.service_id
--                         where mnds.code = 'Д1.02' and mep.id = xepid
--                 )
--               where id = xcaseId;
            insert into MC_DIAGNOSIS (id, case_id, patient_id, establishment_date, diagnos_id, disease_type_id, type_id, is_suspicion, is_main, stage_id)
              values (nextval('mc_diagnosis_seq'), xcaseId, (select indiv_id from disp.md_event_patient where id = xepid), COALESCE(to_date(xbdate, 'DD.MM.YYYY'), current_date), xmd,
                      xdis, (select id from mc_diagnosis_type where code = '1'), xsuspicion, TRUE, (select id from mc_stage where code = '3'));
            insert into disp.md_dispr_diagnosis_service (id, resource_id, service_id, diagnosis_id)
              values (nextval('disp.md_dispr_diagnosis_service_id_seq'), xresource, serviceid, currval('mc_diagnosis_seq'));
            -- end insert
            insert into SR_SRV_RENDERED (id, service_id, bdate, res_group_id, customer_id, is_rendered, edate, quantity, funding_id, org_id, payment_status_id)
              values (srrid, serviceid, COALESCE(to_date(xbdate, 'DD.MM.YYYY'), current_date), xresource, (select indiv_id from disp.md_event_patient where id = xepid), TRUE, COALESCE(to_date(xbdate, 'DD.MM.YYYY'), current_date), 1,
              (select etf.funding_source_type_id from disp.md_event_type_fund etf join disp.md_event me on me.event_type = etf.event_type_id join disp.md_event_patient mep on mep.event_id = me.id where mep.id = xepid), (select me.org_id from disp.md_event_patient mep left join disp.md_event me on me.id = mep.event_id where mep.id = xepid), 1);
            insert into MD_SRV_RENDERED (id, case_id, step_id, diagnosis_id) values (srrid, xcaseId, stepid,
              (select md.diagnos_id from disp.md_dispr_diagnosis_service mdds left join mc_diagnosis md on md.id = mdds.diagnosis_id where mdds.id = currval('disp.md_dispr_diagnosis_service_id_seq') and md.is_main = true)
            );
            update mc_step set main_diagnosis_id = (select mdds.diagnosis_id from disp.md_dispr_diagnosis_service mdds left join mc_diagnosis md on md.id = mdds.diagnosis_id where mdds.id = currval('disp.md_dispr_diagnosis_service_id_seq') and md.is_main = true) where id = stepid;
            insert into disp.md_disp_orphans_inspec (id, event_patient_id, service_id, main_diagnos, disease, counsel, reference, diagnos_id, step_id)
              values (nextval('disp.md_disp_orphans_inspec_id_seq'), xepid, srrid, xmd, xdis, xcounsel, xreference, currval('mc_diagnosis_seq'), stepid);

            select id into result_id from disp.md_disp_orphans_result where event_patient_id = xepid and is_before = false;
            if (result_id is not null) then
	      insert into disp.md_disp_orphans_diagnosis_extended (id, result_id, not_edit, service_id)
              values (currval('mc_diagnosis_seq'), result_id, true, srrid);
	    end if;

          end if;

          if (select open_date from MC_CASE where id = xcaseId) IS NULL then
            update MC_CASE set open_date = COALESCE(to_date(xbdate, 'DD.MM.YYYY'), current_date)
              where id = xcaseId;
          end if;

          -- change STATUS
          update disp.md_event_service_patient_status set status = 4
              where service_id = (select mesp.id from disp.md_event_patient mep
                left join disp.md_event_service_patient mesp on mesp.event_patient_id =  mep.id
                inner join disp.md_event_service mes on mes.id = mesp.service_id and mes.service_id = serviceid
                where mep.id = xepid);
          return srrid;
        end;
$$;

