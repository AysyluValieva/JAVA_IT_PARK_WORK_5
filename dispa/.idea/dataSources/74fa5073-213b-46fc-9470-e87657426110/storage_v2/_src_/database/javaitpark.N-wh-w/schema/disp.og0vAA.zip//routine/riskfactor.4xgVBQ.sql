CREATE FUNCTION riskfactor(xid integer, xhas_high_pressure boolean, xhas_over_mass boolean, xhas_hypercholesterinemia boolean, xhas_over_glucose boolean, xhas_smoking boolean, xhas_lower_physical_activity boolean, xhas_poor_nutrition boolean, xhas_alcohol_dependence boolean, xhas_risk_alcohol boolean, xhas_high_level_stress boolean, xhas_dyslipidemia boolean, xindividual_counseling_id integer, xgroup_counseling_id integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
          count integer;
        begin
        count=(select count(id) from disp.md_dispr_risk_factor where id =xid);
        if (count>0) then
           update disp.md_dispr_risk_factor set has_high_pressure=xhas_high_pressure,
                    has_over_mass=xhas_over_mass,
                    has_hypercholesterinemia=xhas_hypercholesterinemia,
                    has_over_glucose=xhas_over_glucose,
                    has_smoking=xhas_smoking,
                    has_lower_physical_activity=xhas_lower_physical_activity,
                    has_poor_nutrition=xhas_poor_nutrition,
                    has_alcohol_dependence=xhas_alcohol_dependence,
                    has_risk_alcohol=xhas_risk_alcohol,
                    has_high_level_stress=xhas_high_level_stress,
                    has_dyslipidemia=xhas_dyslipidemia,
                    individual_counseling_id=xindividual_counseling_id,
                    group_counseling_id=xgroup_counseling_id
                    where id=xid;
        else
            insert into disp.md_dispr_risk_factor (id,indiv_id, event_id,has_high_pressure,has_over_mass,has_hypercholesterinemia,
                has_over_glucose, has_smoking,has_lower_physical_activity,has_poor_nutrition,has_alcohol_dependence,
                     has_risk_alcohol,has_high_level_stress,has_dyslipidemia,individual_counseling_id,group_counseling_id)
                values(xid,(select indiv_id from disp.md_event_patient where id=xid),(select event_id from disp.md_event_patient where id=xid),xhas_high_pressure,xhas_over_mass,xhas_hypercholesterinemia,
                xhas_over_glucose, xhas_smoking,xhas_lower_physical_activity,xhas_poor_nutrition,xhas_alcohol_dependence,
                     xhas_risk_alcohol,xhas_high_level_stress,xhas_dyslipidemia,xindividual_counseling_id,xgroup_counseling_id);
        end if;

          return 1;
        end;
$$;

