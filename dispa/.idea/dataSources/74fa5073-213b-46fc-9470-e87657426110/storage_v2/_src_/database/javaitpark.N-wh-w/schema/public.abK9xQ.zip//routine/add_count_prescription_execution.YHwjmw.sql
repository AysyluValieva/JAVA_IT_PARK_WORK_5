CREATE FUNCTION add_count_prescription_execution()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE
    count_execution_var varchar;
BEGIN
    IF    TG_OP = 'INSERT' THEN
        IF (NEW.patient_prescription_id is not null) THEN
            count_execution_var = count_of_execution_prescription(NEW.patient_prescription_id);
            UPDATE md_patient_prescription SET count_execution = count_execution_var WHERE id = NEW.patient_prescription_id;
        END IF;
        RETURN NEW;
    ELSIF TG_OP = 'UPDATE' THEN
       IF (OLD.patient_prescription_id is not null) THEN
            count_execution_var := count_of_execution_prescription(OLD.patient_prescription_id);
            UPDATE md_patient_prescription SET count_execution = count_execution_var WHERE id = OLD.patient_prescription_id;
       END IF;
       IF (NEW.patient_prescription_id is not null) THEN
            count_execution_var := count_of_execution_prescription(NEW.patient_prescription_id);
            UPDATE md_patient_prescription SET count_execution = count_execution_var WHERE id = NEW.patient_prescription_id;
        END IF;
        RETURN NEW;
    ELSIF TG_OP = 'DELETE' THEN
        IF (OLD.patient_prescription_id is not null) THEN
            count_execution_var := count_of_execution_prescription(OLD.patient_prescription_id);
            UPDATE md_patient_prescription SET count_execution = count_execution_var WHERE id = OLD.patient_prescription_id;
        END IF;
        RETURN OLD;
    END IF;
END;
$$;

