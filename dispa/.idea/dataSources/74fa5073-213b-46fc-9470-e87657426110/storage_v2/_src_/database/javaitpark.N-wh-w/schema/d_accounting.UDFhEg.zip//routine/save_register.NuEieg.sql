CREATE FUNCTION save_register(xid integer, xcode text, xname text, xtype_id integer, xbegin_date date, xend_date date, xclinicid integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
DECLARE
  _id INTEGER;
BEGIN
  _id = xid;

  IF (_id IS NULL)
  THEN
    INSERT INTO d_accounting.register (id, code, name, type_id, begin_date, end_date)
    VALUES (nextval('d_accounting.register_id_seq'), xcode, xname, xtype_id, xbegin_date, xend_date)
    RETURNING id
      INTO _id;
    IF (xtype_id = 2 AND xclinicId IS NOT NULL)
    THEN
      INSERT INTO d_accounting.register_clinic (register_id, clinic_id) VALUES (_id, xclinicId);
    END IF;
  ELSE
    UPDATE d_accounting.register
    SET code = xcode, name = xname, type_id = xtype_id, begin_date = xbegin_date, end_date = xend_date
    WHERE id = _id;
    IF (xtype_id = 2 AND xclinicId IS NOT NULL AND NOT EXISTS(SELECT 1
                                                              FROM d_accounting.register_clinic rc
                                                              WHERE rc.clinic_id = xclinicId AND rc.register_id = _id))
    THEN
      INSERT INTO d_accounting.register_clinic (register_id, clinic_id) VALUES (_id, xclinicId);
    END IF;
  END IF;

  RETURN _id;
END;
$$;

