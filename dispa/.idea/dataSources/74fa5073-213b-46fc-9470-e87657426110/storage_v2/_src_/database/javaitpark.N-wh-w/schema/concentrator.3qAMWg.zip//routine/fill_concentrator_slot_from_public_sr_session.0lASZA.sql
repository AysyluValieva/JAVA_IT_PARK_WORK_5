CREATE FUNCTION fill_concentrator_slot_from_public_sr_session()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
                  IF TG_OP = 'INSERT'
                  THEN
                    INSERT INTO concentrator.slot (id, uuid) VALUES (NEW.id, uuid_generate_v4());
                  END IF;

                  RETURN NEW;
                END;
$$;

