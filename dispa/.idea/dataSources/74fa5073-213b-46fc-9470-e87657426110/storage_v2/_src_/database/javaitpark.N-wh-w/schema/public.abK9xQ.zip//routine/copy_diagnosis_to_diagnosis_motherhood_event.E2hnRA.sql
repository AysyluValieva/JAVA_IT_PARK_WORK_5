CREATE FUNCTION copy_diagnosis_to_diagnosis_motherhood_event()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE
  _is_motherhood BOOLEAN;
  _is_new        BOOLEAN;
BEGIN
  IF TG_OP = 'INSERT' OR TG_OP = 'UPDATE'
  THEN
    IF NEW.diagnos_id NOTNULL AND NEW.patient_id NOTNULL
    THEN
      SELECT EXISTS
      (SELECT 1
       FROM services_template st
         LEFT JOIN services_template_diagnosis std ON std.template_id = st.id
         LEFT JOIN md_diagnosis mdd ON mdd.id = std.diagnosis_id
         LEFT JOIN motherhood.mh_pregnant_map mhp ON mhp.patient_id = NEW.patient_id
       WHERE st.is_motherhood = TRUE
             AND CURRENT_DATE BETWEEN COALESCE(st.begin_date, '-infinity') AND COALESCE(st.end_date, 'infinity')
             AND std.diagnosis_id = NEW.diagnos_id
             AND NEW.establishment_date :: DATE BETWEEN mhp.reg_dt AND COALESCE(mhp.unreg_dt, 'infinity'))
      INTO _is_motherhood;

      IF _is_motherhood
      THEN
        IF TG_OP = 'INSERT'
        THEN
          _is_new = TRUE;
        ELSE
          IF (SELECT exists(SELECT 1
                            FROM motherhood.mc_diagnosis_motherhood_event
                            WHERE id = NEW.id)) = TRUE
          THEN
            _is_new = FALSE;
          ELSE
            _is_new = TRUE;
          END IF;
        END IF;

        IF _is_new
        THEN
          INSERT INTO motherhood.mc_diagnosis_motherhood_event (
            id,
            establishment_date,
            note,
            diagnos_id,
            disease_type_id,
            doctor_id,
            injury_type_id,
            case_id,
            patient_id,
            stage_id,
            step_id,
            type_id,
            is_main,
            is_suspicion,
            mes_id,
            clinical_form_id,
            localization_id,
            complication_id,
            standard_id,
            csg_id)
          VALUES (
            NEW.id,
            NEW.establishment_date,
            NEW.note,
            NEW.diagnos_id,
            NEW.disease_type_id,
            NEW.doctor_id,
            NEW.injury_type_id,
            NEW.case_id,
            NEW.patient_id,
            NEW.stage_id,
            NEW.step_id,
            NEW.type_id,
            NEW.is_main,
            NEW.is_suspicion,
            NEW.mes_id,
            NEW.clinical_form_id,
            NEW.localization_id,
            NEW.complication_id,
            NEW.standard_id,
            NEW.csg_id
          );
        ELSE
          UPDATE motherhood.mc_diagnosis_motherhood_event
          SET
            establishment_date = NEW.establishment_date,
            note               = NEW.note,
            diagnos_id         = NEW.diagnos_id,
            disease_type_id    = NEW.disease_type_id,
            doctor_id          = NEW.doctor_id,
            injury_type_id     = NEW.injury_type_id,
            case_id            = NEW.case_id,
            patient_id         = NEW.patient_id,
            stage_id           = NEW.stage_id,
            step_id            = NEW.step_id,
            type_id            = NEW.type_id,
            is_main            = NEW.is_main,
            is_suspicion       = NEW.is_suspicion,
            mes_id             = NEW.mes_id,
            clinical_form_id   = NEW.clinical_form_id,
            localization_id    = NEW.localization_id,
            complication_id    = NEW.complication_id,
            standard_id        = NEW.standard_id,
            csg_id             = NEW.csg_id
          WHERE id = NEW.id;
        END IF;
      END IF;
    END IF;

    RETURN NEW;
  ELSE
    DELETE FROM motherhood.mc_diagnosis_motherhood_event
    WHERE id = OLD.id;

    RETURN OLD;
  END IF;
END;
$$;

