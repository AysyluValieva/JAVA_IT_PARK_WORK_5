CREATE FUNCTION adr__get_element_as_text_new(id integer DEFAULT 1086644, format text DEFAULT '(2,f,0)(3,f,0)(4,f,0)(5,f,0)(6,s,0)(7,s,0)'::text)
  RETURNS character varying
LANGUAGE plpgsql
AS $$
declare
  substr record;
  type_code char;
  arr text[];
  b boolean;
  i integer := 0;
  level_id integer;
  format_id integer;
  element_id integer := id;
  element record;
  result text := '';
begin

  for substr in
    select cast(regexp_matches(format, E'([(][1-9][,][nfs][,][0-9]+[)])', 'g') as text) as el
  loop
    i := i + 1;
    arr[i] := substr.el;
  end loop;

  for element in
    select e.id, e.name, e.display_format_id as el_fmt,
    t.name as type, t.short_name as short_type, t.display_format_id as type_fmt, l.id as level
      from ((address_element_inclusion i
      join address_element e on e.id = i.parent_id)
      join address_element_type t on e.type_id = t.id)
      join address_element_level l on l.id = e.level_id
      where i.child_id = element_id
      order by l.id
  loop

    b := false;
    for j in coalesce(array_lower(arr,1),0) .. coalesce(array_upper(arr,1),-1) loop
      level_id := cast(substring(arr[j],4,1) as integer);
      if level_id = element.level then
        b := true;
        i := j;
        exit;
      end if;
    end loop;

    if b = true then
      if element.id <> cast(substring(arr[i],8,arr[i].length-10) as integer) then
        if result <> '' then
          result := result || ', ';
        end if;
        type_code := cast(substring(arr[i],6,1) as char);
        if element.el_fmt <> 0 then
          format_id := element.el_fmt;
        else
          format_id := element.type_fmt;
        end if;
        case type_code
          when 'f' then
            if format_id = 2 then
              result := result || element.name || ' ' || element.type;
            else
              result := result || element.type || ' ' || element.name;
            end if;
          when 's' then
            if format_id = 2 then
              result := result || element.name || ' ' || element.short_type;
            else
              result := result || element.short_type || ' ' || element.name;
            end if;
          else
            result := result || element.name;
        end case;
      end if;
    end if;

  end loop;

  if result = '' then
    return null;
  end if;

  return result;

end;
$$;

