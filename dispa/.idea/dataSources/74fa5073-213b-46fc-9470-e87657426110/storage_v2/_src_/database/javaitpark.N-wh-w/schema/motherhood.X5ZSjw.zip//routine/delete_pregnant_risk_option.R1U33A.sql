CREATE FUNCTION delete_pregnant_risk_option(mapid integer, groupid integer, optionids character varying)
  RETURNS void
LANGUAGE plpgsql
AS $$
BEGIN
  DELETE FROM motherhood.mh_pregnant_map_risk_option WHERE pregnant_map_id = mapid AND
                                                           risk_option_id IN (
                                                           SELECT rfo.id
                FROM motherhood.risk_factory_group rfg
                LEFT JOIN motherhood.risk_factory_value rfv ON rfv.group_id = rfg.id
                LEFT JOIN motherhood.risk_factory_options rfo ON rfo.value_id = rfv.id
                where rfg.id = groupid and (optionids is null or rfo.id != ANY(string_to_array(optionids, ',')::int[]))
                );
END;
$$;

