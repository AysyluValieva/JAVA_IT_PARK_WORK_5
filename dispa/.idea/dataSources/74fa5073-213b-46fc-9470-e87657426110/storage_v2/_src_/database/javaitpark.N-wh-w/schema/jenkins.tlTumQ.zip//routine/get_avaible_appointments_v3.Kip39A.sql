CREATE FUNCTION get_avaible_appointments_v3(_employee_id integer, _department_id text, _individual_id integer, _bdate date, _edate date)
  RETURNS TABLE(ss integer, bdatetime character varying, edatetime character varying)
LANGUAGE plpgsql
AS $$
declare
_query text;
            begin

            _query= concat ('

with  _shedul as (
--С‚СѓС‚ СЃРѕР±РёСЂР°СЋС‚СЃСЏ РІСЃРµ РІРѕР·РјРѕР¶РЅС‹Рµ  РїСЂРёР·РЅР°РєРё РґРЅРµР№ РґР»СЏ СЂР°РїРёСЃР°РЅРёСЏ СЂРµСЃСѓСЂСЃР°
select id, min(btime), max(etime), return_period_id, agg, bdate,edate,srg_id from (
select  distinct _rule.id, _srv.btime, _srv.etime, _period.return_period_id, "array_agg"(_period.value ) agg, _rule.bdate, _rule.edate,_srg.id srg_id
								from sr_res_group _srg
								join sr_schedule_service _service on "_srg".id=_service.res_group_id
								join sr_schedule_rule _rule on "_rule".schedule_id="_service".id
								join cmn_time_event_period _period on _period.time_event_id=_rule.time_event_id
								join sr_schedule_rule_srv _srv on _srv.schedule_rule_id = _rule.id
								--left join sr_schedule_rule_call _call on _call.schedule_rule_id="_rule".id
								where _srg.id=',_employee_id,' 
								--and "_rule".id=60676
								and _rule.time_type_id=1 
								and (_rule.edate is null	or _rule.edate  > current_date )	
								and  exists(select 1 from sr_schedule_rule_call where schedule_rule_id="_rule".id and btime=_srv.btime and etime=_srv.etime)
								--and _call.id is null
								GROUP BY _rule.id, _srv.btime, _srv.etime, _period.return_period_id , _rule.bdate, _rule.edate,_srg.id
								order by _rule.id, _srv.btime

)_t group by id,return_period_id, agg , bdate,edate ,srg_id
),
_days as (
--РіРµРЅРµСЂР°С†РёСЏ РґРЅРµР№
select day, yyyy,mm,dd,number_week,week
from ( select day,  Extract(YEAR from day::date ) AS yyyy
								, Extract(MONTH from day::date ) AS mm
								, Extract(day from day::date ) AS dd
								,Extract(week from day::date ) AS number_week
								,to_char(day-''1 day''::interval,''d'') as week
								 from (
								select  (CURRENT_DATE + i ) as day
								from generate_series(date ''',_bdate,'''::date  - CURRENT_DATE, 
										 date  ''',_edate,'''::date - CURRENT_DATE ) i
								 ) a) _t 
)
,_sort as (
select distinct concat (day, '' '', min)::TIMESTAMP _bdt, concat (day, '' '', max)::TIMESTAMP _edt, *  from _shedul CROSS join _days
where case when  return_period_id=4  then week::integer in (select unnest(agg::int[]))
 when  return_period_id=3  then true 
	when return_period_id=5  then mm::integer in (select unnest(agg::int[]))
	when return_period_id=7  then number_week::integer in (select unnest(agg::int[]))
  end
and day BETWEEN  bdate and edate 
)
,all_sessions as (select ss.bdatetime, ss.edatetime, rg.id rg , ep.employee_id emp, ss.id ss
                        from pim_employee_position ep
                        inner join sr_res_group rg on rg.responsible_id=ep.id
						join sr_res_group_source srgs on srgs.res_group_id = rg.id and srgs.source_id = 0
                        inner join sr_timetable_res_group trg on trg.res_group_id=rg.id
                        inner join sr_timetable t on t.id=trg.id
                        inner join sr_shift s on s.timetable_id=t.id
                        inner join sr_session ss on ss.shift_id=s.id
												left join  sr_session_quotum ssq on ss.id=ssq.session_id
												left join sr_session_source_na sssn on sssn.session_id= ss.id and sssn.source_id = 0
                     where rg.id =', _employee_id,' and cast(ss.bdatetime as date)>=''',_bdate,'''
and ss.bdatetime::timestamp> now()::timestamp
and cast(ss.edatetime as date)<=''',_edate,''' and ssq.session_id is null and s.time_type_id!=2 and ss.time_type_id!=2
					and  sssn.session_id is null --РЅРµ СѓС‡РёС‚С‹РІР°С‚СЊ РЅРµРґРѕСЃС‚СѓРїРЅС‹Рµ Р·Р°РїРёСЃРё
					 ),   
--С‚Р°Р»РѕРЅС‹ РїР°С†РёРµРЅС‚Р° РІ Р·Р°РґР°РЅРЅС‹Р№ РёРЅС‚РµСЂРІР°Р» РІСЂРµРјРµРЅРё                                     
individual_appointment as (
select app.bdatetime, app.edatetime 
								  from md_appointment app  
								  inner join pim_individual pi on app.customer_id=pi.id
							where pi.id=nullif(''',_individual_id,''','''')::integer   and app.bdatetime BETWEEN ''',_bdate,''' and ''', _edate,''' and  app.cancel_reason_id is NULL),   
--РґР°С‚С‹, РЅР° РєРѕС‚РѕСЂС‹Рµ СѓР¶Рµ РёРјРµРµС‚СЃСЏ Р·Р°РїРёСЃСЊ Рє СѓРєР°Р·Р°РЅРЅРѕРјСѓ СЃ РїРµС†РёР°Р»РёСЃС‚Сѓ РІ СѓРєР°Р·Р°РЅРЅС‹Р№ РёРЅС‚РµСЂРІР°Р» РІСЂРµРјРµРЅРё
have_employee_appointment_today as (select cast(all_sessions.bdatetime as date) d
   										from all_sessions
  										inner join md_appointment app on app.executor_id=all_sessions.rg and all_sessions.bdatetime=app.bdatetime and cancel_reason_id is NULL
   										inner join pim_individual pi on pi.id=app.customer_id
								 where  all_sessions.bdatetime>CURRENT_DATE and pi.id=nullif(''',_individual_id,''','''')::integer and app.state_id not in(1,4)
								 order by d
)

select distinct all_sessions.ss,   all_sessions.bdatetime::character varying, all_sessions.edatetime::character varying
   from all_sessions
   left join md_appointment app on app.executor_id=all_sessions.rg and all_sessions.bdatetime=app.bdatetime and cancel_reason_id is NULL and app.state_id <>4
   left join individual_appointment on all_sessions.bdatetime between individual_appointment.bdatetime and individual_appointment.edatetime
where individual_appointment.bdatetime is NULL
and app.id is NULL  and cast(all_sessions.bdatetime as date) not in( select d from have_employee_appointment_today) 
and all_sessions.bdatetime>CURRENT_DATE
and  not exists (select 1 from _sort where all_sessions.bdatetime  BETWEEN _sort._bdt and _sort._edt)

');
raise notice 'Р—Р°РїСЂРѕСЃ !!!  %   !!!!',_query;

return QUERY	EXECUTE(_query);

           end;
$$;

