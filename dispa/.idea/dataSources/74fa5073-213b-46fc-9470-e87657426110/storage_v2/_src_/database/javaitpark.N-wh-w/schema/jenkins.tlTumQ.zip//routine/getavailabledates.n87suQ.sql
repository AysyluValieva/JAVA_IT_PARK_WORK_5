CREATE FUNCTION getavailabledates(_employee_id integer, _department_id text, idpat text, _bdate date, _edate date)
  RETURNS text
LANGUAGE plpgsql
AS $$
DECLARE
  _result text;
BEGIN
 select * into _result from "jenkins"."getavailabledates_v1"("_employee_id" , "_department_id", "idpat" , "_bdate" , "_edate" );
RETURN _result;
END;
$$;

