CREATE FUNCTION apdam_attachment_patients(in_md_clinic_id integer, in_check_district boolean, in_department_id integer, in_type_id integer, in_reg_date date, in_update_type integer, in_detachment_type integer, in_specific_criteria character varying, in_active_address_code character varying)
  RETURNS void
LANGUAGE plpgsql
AS $$
BEGIN
  IF in_reg_date ISNULL
  THEN in_reg_date = current_date; END IF;

  RAISE NOTICE 'Валидация входных параметров ...';
  EXECUTE apdam_validate_input_params(in_md_clinic_id, in_check_district, in_type_id, in_update_type,
                                      in_detachment_type);

  RAISE NOTICE 'Обновление прикреплений ...';
  EXECUTE apdam_update_reg(in_md_clinic_id, in_check_district, in_department_id, in_type_id, in_reg_date,
                           in_update_type, in_detachment_type, in_specific_criteria, in_active_address_code);

  RAISE NOTICE 'Прикрепление новых пациентов ...';
  EXECUTE apdam_attachment_new_patients(in_md_clinic_id, in_check_district, in_department_id, in_type_id, in_reg_date,
                                        in_active_address_code);

  EXECUTE apdam_cleanup();
END;
$$;

