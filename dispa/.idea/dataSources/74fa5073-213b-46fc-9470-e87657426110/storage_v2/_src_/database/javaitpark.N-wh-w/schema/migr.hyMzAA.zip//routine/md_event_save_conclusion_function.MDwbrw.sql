CREATE FUNCTION md_event_save_conclusion_function(xid integer, xcertificate_number character varying, xcert_date_begin date, xcert_date_end date, xconclusion_number character varying, xconclusion_date date, xmedcommission integer, xcertificate_series character varying DEFAULT NULL::character varying, xconclusion_series character varying DEFAULT NULL::character varying)
  RETURNS integer
LANGUAGE plpgsql
AS $$
begin

                update migr.md_migr_card set
                    certificate_number = xcertificate_number,
                    cert_date_begin = xcert_date_begin,
                    cert_date_end=xcert_date_end,
                    conclusion_number=xconclusion_number,
                    conclusion_date=xconclusion_date,
                    med_commission_id=xmedCommission,
                    certificate_series=xcertificate_series,
                    conclusion_series=xconclusion_series
                    where id = xid;

                PERFORM migr.save_contraindications(xid);

                update mc_case set closing_step_id = (select id from mc_step where case_id = (select case_id from disp.md_event_patient where id = xid) order by outcome_date desc limit 1)
		        where id = (select case_id from disp.md_event_patient where id = xid) and closing_step_id is null;

            return xid;
            end;
$$;

