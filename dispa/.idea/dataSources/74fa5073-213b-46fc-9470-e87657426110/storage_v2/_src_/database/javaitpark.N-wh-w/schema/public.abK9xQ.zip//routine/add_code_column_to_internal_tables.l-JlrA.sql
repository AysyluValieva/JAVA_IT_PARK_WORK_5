CREATE FUNCTION add_code_column_to_internal_tables()
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
    item RECORD;
BEGIN
    FOR item IN
        SELECT r.table_name
        FROM   mdm_internal_refbook r
        WHERE  r.table_name IS NOT NULL AND EXISTS
          (SELECT * FROM information_schema.tables WHERE table_schema = 'public' and table_name = r.table_name and table_type = 'BASE TABLE')

    LOOP
    IF NOT EXISTS
    (
    SELECT attname FROM pg_attribute WHERE attrelid =
    (SELECT oid FROM pg_class WHERE relname =  item.table_name )
     AND attname = 'code'
     )
     THEN
        EXECUTE('ALTER TABLE ' || item.table_name || ' ADD COLUMN code character varying(100);');
     END IF;
    IF NOT EXISTS
    (
    SELECT attname FROM pg_attribute WHERE attrelid =
    (SELECT oid FROM pg_class WHERE relname =  item.table_name )
     AND attname = 'e_code'
     )
     THEN
        EXECUTE('ALTER TABLE ' || item.table_name || ' ADD COLUMN e_code character varying(100);');
     END IF;
    END LOOP;
END
$$;

