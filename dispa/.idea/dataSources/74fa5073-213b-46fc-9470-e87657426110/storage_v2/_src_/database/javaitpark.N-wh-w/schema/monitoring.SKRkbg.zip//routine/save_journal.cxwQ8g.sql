CREATE FUNCTION save_journal(xid integer, xname text, xtype_id integer, xkind_id integer, xis_active boolean, xorg_id integer, xclinic_id integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
  _id integer;
begin
  _id = xid;

  if (xid is null) then
      insert into monitoring.mn_journal (name, type_id, kind_id, is_active)
        values (xname, xtype_id, xkind_id, xis_active) returning id into _id;
      insert into monitoring.mn_journal_access (clinic_id, journal_id) values (coalesce(xorg_id, xclinic_id), _id);
  ELSE
      update monitoring.mn_journal
      set name = xname, type_id = xtype_id, kind_id = xkind_id, is_active = xis_active
      where id = _id;
  END IF;

  if (xtype_id = 2)
  then
    DELETE FROM monitoring.mn_journal_org where journal_id = _id;
    DELETE FROM monitoring.mn_journal_access where journal_id = _id;
    insert into monitoring.mn_journal_access (clinic_id, journal_id) values (coalesce(xorg_id, xclinic_id), _id);
    insert into monitoring.mn_journal_org (clinic_id, journal_id) values (coalesce(xorg_id, xclinic_id), _id);

  END IF;

  return _id;
END;
$$;

