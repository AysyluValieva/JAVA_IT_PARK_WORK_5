CREATE FUNCTION fin_spec_gen_head(p1_bill_id integer)
  RETURNS void
STRICT
LANGUAGE plpgsql
AS $$
DECLARE 
    _main_bill_id INTEGER;
    _clinic_id INTEGER;
    _from_date DATE;
    _to_date DATE;
    _financing_type_id INTEGER;
    _price_list_id INTEGER;
    _item_type TEXT;
    _care_regimen_arr INTEGER[];
    _payment_method_arr INTEGER[];
    _case_init_goal_arr INTEGER[];
    _format_id_arr INTEGER[];
BEGIN
    /*
        current version date 2014-12-12
    */
    ------------------------------------------------------------------параметры----------------------------------------------------------------------
    _main_bill_id := fin_bill__get_main_bill (p1_bill_id)
    ;
    SELECT 
        coalesce (a.from_date, m.from_date), coalesce (a.to_date, m.to_date), m.clinic_id, m.financing_type_id, m.price_list_id, nullif (trim (p.commentary), '')
        INTO 
        _from_date, _to_date, _clinic_id, _financing_type_id, _price_list_id, _item_type
    FROM
        fin_bill_main                 AS m 
        JOIN fin_price_list           AS p ON p.id = m.price_list_id
        LEFT JOIN fin_bill_additional AS a ON m.id = a.base_id AND a.id = p1_bill_id
    WHERE
        m.id = _main_bill_id
    ;
    ---------------------------------------------------проверка на заполнение обязательных полей-----------------------------------------------------
    IF
        _price_list_id IS NULL OR _financing_type_id IS NULL OR _clinic_id IS NULL OR _to_date IS NULL OR _from_date IS NULL
    THEN
        RAISE EXCEPTION 'Не заполнены обязательные поля счёта: прейскурант, тип финансирования, МО, период формирования';
    END IF;
    -------------------------------------------выбор параметров в зависимости от заранее заданных условий--------------------------------------------
    --
    ---------------------------------------------------------добавление в нужные таблицы-------------------------------------------------------------
    IF
        array_length (_care_regimen_arr, 1) IS NOT NULL
    THEN
        DELETE FROM fin_bill_main_to_care_regimen WHERE main_bill_id = _main_bill_id
        ;
        INSERT INTO fin_bill_main_to_care_regimen (main_bill_id, care_regimen_id) 
            SELECT _main_bill_id, unnest (_care_regimen_arr)
        ;
    END IF;
    
    IF
        array_length (_payment_method_arr, 1) IS NOT NULL
    THEN
        DELETE FROM fin_bill_main_to_payment_method WHERE main_bill_id = _main_bill_id
        ;
        INSERT INTO fin_bill_main_to_payment_method (main_bill_id, payment_method_id) 
            SELECT _main_bill_id, unnest (_payment_method_arr)
        ;
    END IF;
    
    IF
        array_length (_case_init_goal_arr, 1) IS NOT NULL
    THEN
        DELETE FROM fin_bill_main_to_case_init_goal WHERE main_bill_id = _main_bill_id
        ;
        INSERT INTO fin_bill_main_to_case_init_goal (main_bill_id, case_init_goal_id) 
            SELECT _main_bill_id, unnest (_case_init_goal_arr)
        ;
    END IF;
EXCEPTION
    WHEN NO_DATA_FOUND THEN RAISE EXCEPTION 'Не заполнены необходимые параметры, либо неправильные данные счёта';
END;
$$;

