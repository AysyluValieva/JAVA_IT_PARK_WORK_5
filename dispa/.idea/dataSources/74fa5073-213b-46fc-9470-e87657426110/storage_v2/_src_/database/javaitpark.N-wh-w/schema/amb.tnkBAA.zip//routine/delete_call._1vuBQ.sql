CREATE FUNCTION delete_call(xcall_id integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
                   xcase_id integer;
                begin
                    delete from amb.md_ambulance_call_in_cityservice where call_note_id in
                    (select id from amb.md_ambulance_call_note where call_id = xcall_id);
                    delete from amb.md_ambulance_call_double where call_note_id in
                    (select id from amb.md_ambulance_call_note where call_id = xcall_id);
                    delete from amb.md_ambulance_call_note where call_id = xcall_id;
                    delete from amb.md_ambcall_state_history where call_id = xcall_id;
                    delete from amb.md_ambcall_route_history where call_id = xcall_id;
                    delete from amb.md_ambcall_priority_history where call_id = xcall_id;
                    delete from md_resgroup_amb_profile where id in (select s.res_group_id
                    from mc_step s,
                    amb.md_ambulance_call_result amr
                    where amr.id = xcall_id
                    and s.case_id=amr.case_id);
                    delete from sr_res_group_profile where res_group_id in (select s.res_group_id
                    from mc_step s,
                    amb.md_ambulance_call_result amr
                    where amr.id = xcall_id
                    and s.case_id=amr.case_id);
                    delete from amb.md_ambulance_call_services where call_id = xcall_id;

                    xcase_id = (select case_id from amb.md_ambulance_call_result where id = xcall_id);

                    delete from amb.md_ambulance_call_result where id = xcall_id;
                    delete from mc_case where id = xcase_id;
                    delete from amb.md_ambulance_call where id = xcall_id;
                end;
$$;

