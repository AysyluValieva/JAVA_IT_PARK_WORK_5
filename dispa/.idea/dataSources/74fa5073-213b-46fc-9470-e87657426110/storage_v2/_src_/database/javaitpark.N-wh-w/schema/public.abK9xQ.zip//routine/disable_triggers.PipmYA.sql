CREATE FUNCTION disable_triggers(trigger_name_pattern text)
  RETURNS void
LANGUAGE plpgsql
AS $$
declare       
 trigger_name_record RECORD;      
 trigger_table_record RECORD;  
begin      
	FOR trigger_name_record IN select distinct trigger_name, event_object_table from information_schema.triggers where trigger_name like '%' || trigger_name_pattern || '%' 
	LOOP   
		begin 
			execute 'alter table ' || trigger_name_record.event_object_table || ' disable trigger ' || trigger_name_record.trigger_name;
		end;
	END LOOP;  
end;
$$;

