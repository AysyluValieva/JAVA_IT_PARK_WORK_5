CREATE FUNCTION getavaibleappointments(_employee_id integer, _department_id text, _individual_id integer, _bdate date, _edate date)
  RETURNS TABLE(ss integer, bdatetime character varying, edatetime character varying)
LANGUAGE plpgsql
AS $$
BEGIN
 

return query ( select * from "jenkins"."getavaibleappointments_v3"( "_employee_id" ,  "_department_id" ,  "_individual_id" ,  "_bdate" ,  "_edate" ) );

 
 
END;
$$;

