CREATE FUNCTION priority_calculation(xcall integer, xreg integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
                xkind integer;
                xbdate TIMESTAMP WITHOUT TIME ZONE;
                xreason INTEGER;
                xplace integer;
                xage integer;

                xprior integer;
                xnum integer;
                xselectsum integer;
                xsum integer := 0;
                xhist integer;
                xpriority integer;
                xnumber integer;
                res record;
              begin
                xselectsum = (select max(sr.priority)
                from
                amb.md_ambulance_call mac
                join pim_individual pi on pi.id = mac.patient_id
                join amb.md_amb_selecting_to_reason sr on sr.clinic_id = mac.station_id and
                sr.department_id = mac.substation_id and mac.caller_reason_id = sr.caller_reason_id

                left join amb.md_ambulance_caller_reason cr on cr.id = mac.caller_reason_id
                left join public.md_profile reaprof on reaprof.id = cr.profile_id
                left join public.md_diagnosis dia on dia.id = mac.reason_diag
                left join public.md_diagnosis_profile mdp on mdp.diagnosis_id = dia.id
                left join public.md_profile diaprof on diaprof.id = mdp.profile_id

                where mac.id = xcall and sr.is_active

                and ((select count(*) from amb.md_amb_selecting_team st where sr.id = st.selecting_reason_id) = 0
                or
                exists(select 1 from amb.md_amb_selecting_team st
                left join amb.sr_res_team_template_profile ttp on ttp.team_template_id = st.team_template_id
                left join md_profile mp on ttp.profile_id = mp.id where sr.id = st.selecting_reason_id
                  and (sr.is_use_profile is null or not sr.is_use_profile or sr.is_use_profile and (mp.id = (case when pi.birth_dt is not null and cast(amb.get_age_full(pi.birth_dt,cast(now() as date)) as varchar(9)) like '%day%' or mac.age_days is not null
                    then
                        (select id from md_profile where code = '55')
                    else
                        case when pi.birth_dt is not null and amb.get_age_full(pi.birth_dt,cast(now() as date))< '18 year'  or mac.age_months is not null or mac.age_years < 18
                            then
                                (select id from md_profile where code = '68')
                            else
                                coalesce(reaprof.id,diaprof.id)
                        end
                end) or mp.id is null))
                and (not st.is_exclude or st.is_exclude is null)))

                and
                ((select count(*) from amb.md_amb_selecting_call_place scp
                where sr.id = scp.selecting_reason_id) = 0
                or
                exists(select 1 from amb.md_amb_selecting_call_place scp
                where sr.id = scp.selecting_reason_id and mac.call_place_id = scp.call_place_id))

                and ((select count(*) from amb.md_amb_patient_model pm
                where sr.id = pm.selecting_reason_id) = 0
                or
                exists(select 1 from amb.md_amb_patient_model pm where sr.id = pm.selecting_reason_id  and (
                (pm.gender_id is not null and pm.gender_id = pi.gender_id or pm.gender_id is null)
                and
                (pm.from_year is null and pm.from_month is null and pm.from_day is null and pm.to_year is null and pm.to_month is null and pm.to_day is null or
                (pm.from_year is not null or pm.from_month is not null or pm.from_day is not null or pm.to_year is not null or pm.to_month is not null or pm.to_day is not null)
                and
                (pm.from_year is null and pm.from_month is null and pm.from_day is null or (pm.from_year is not null or pm.from_month is not null or pm.from_day is not null) and
                CAST(coalesce(pm.from_year||' years ', '')||coalesce(pm.from_month||' mons ', '')||coalesce(pm.from_day||' days ', '') AS Interval)
                < age(current_date, pi.birth_dt))
                and
                (pm.to_year is null and pm.to_month is null and pm.to_day is null or (pm.to_year is not null or pm.to_month is not null or pm.to_day is not null)
                and CAST(coalesce(pm.to_year||' years ', '')||coalesce(pm.to_month||' mons ', '')||coalesce(pm.to_day||' days ', '') AS Interval)
                > age(current_date, pi.birth_dt)))))
                ));
                If (xselectsum is null)
                then

                    select into xkind,xbdate,xreason,xplace,xage call_kind_id,from_time,caller_reason_id,call_place_id,
                        case when age_years is not null then age_years else case when age_months is not null then age_months else age_days end end
                        from amb.md_ambulance_call where id = xcall;
                    If (xreason is null) and xkind in (3,4,5)
                        then
                            if xkind in (3,5)
                                then xpriority = 4;
                                else xpriority = 3;
                            end if;
                        else
                            xpriority := (select priority_id from amb.md_ambulance_caller_reason where id = xreason);
                    end If;
                    xnumber := (select number from amb.md_ambulance_priority where id = xpriority);
                    xsum:= xsum + xnumber;
                    --xhist := amb.add_ambcall_priority_hist (xcall,xbdate,xpriority,xreg);
                    xprior := null;
                    xnum := 0;
                    if (select priority_id from amb.md_ambulance_call_place where id = xplace) is not null
                        then
                            xprior := (select priority_id from amb.md_ambulance_call_place where id = xplace);
                            xnum := (select number from amb.md_ambulance_priority where id = xprior);
                            if xpriority <> xprior and xnumber < xnum
                                then
                                    --xhist := amb.add_ambcall_priority_hist (xcall,xbdate,xprior,xreg);
                                    xpriority := xprior;
                                    xnumber := xnum;
                            end if;
                    end if;
                    xsum:= xsum + xnum;
                    if xpriority <> xprior and xnumber < xnum
                        then
                            --xhist := amb.add_ambcall_priority_hist (xcall,xbdate,xprior,xreg);
                            xpriority := xprior;
                            xnumber := xnum;
                    end if;
                    xprior := null;
                    xnum := 0;
                    for res in select * from amb.md_ambulance_priority_to_age
                        loop
                            if xage between coalesce(res.from_age_year,res.from_age_month,res.from_age_day) and coalesce(res.to_age_year,res.to_age_month,res.to_age_day)
                                then xprior := res.priority_id;
                            end if;
                    end loop;
                    if xprior is not null
                        then
                            xnum := (select number from amb.md_ambulance_priority where id = xprior);
                            if xpriority <> xprior and xnumber < xnum
                                then
                                    --xhist := amb.add_ambcall_priority_hist (xcall,xbdate,xprior,xreg);
                                    xpriority := xprior;
                                    xnumber := xnum;
                            end if;
                    end if;
                    xsum:= xsum + xnum;
                    update amb.md_ambulance_call set priority_id = xpriority, priority = xsum where id = xcall;
                    xhist := amb.add_ambcall_priority_hist (xcall,xbdate,xpriority,xreg);
                else
                    xsum := xselectsum;
                    update amb.md_ambulance_call set priority = xsum where id = xcall;
                end if;
                return xsum;
              end;
$$;

