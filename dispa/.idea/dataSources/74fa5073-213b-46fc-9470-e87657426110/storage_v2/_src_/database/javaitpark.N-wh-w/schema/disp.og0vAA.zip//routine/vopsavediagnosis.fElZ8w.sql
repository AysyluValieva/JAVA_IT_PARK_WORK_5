CREATE FUNCTION vopsavediagnosis(xgroupid integer, xpreliminary date, xfirst date, xestablishment date, xdiagnosisid integer, xmep integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare

        begin

          if (select count(mepd.id) from disp.md_event_patient_diagnosis mepd

                where mepd.group_id=xgroupid and event_patient_id=xmep ) > 0 then
              update disp.md_event_patient_diagnosis set preliminary_date=xpreliminary, first_date=xfirst, establishment_date=xestablishment, diagnosis_id=xdiagnosisid where event_patient_id=xmep and group_id=xgroupid;
else
  insert into disp.md_event_patient_diagnosis (id,group_id,preliminary_date,first_date,establishment_date, diagnosis_id, event_patient_id)
  values (nextval('disp.md_event_patient_diagnosis_seq'),xgroupid, xpreliminary, xfirst, xestablishment, xdiagnosisid ,xmep );
end if;
          return xdiagnosisid;
        end;
$$;

