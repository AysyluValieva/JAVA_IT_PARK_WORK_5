CREATE FUNCTION create_lacking_beds(p_room_id integer, p_profile_id integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
  l_cell_count INTEGER; --Число основных коек по плану
  l_cell_count_fact INTEGER; --Фактическое число основных коек
  l_cell_count_lack INTEGER; --Кол-во нехватающих основных коек
  l_cell_count_extra INTEGER; --Количество дополнительных коек по плану
  l_cell_count_extra_fact INTEGER; --Фактическое число дополнительных коек
  l_cell_count_extra_lack INTEGER; --Кол-во нехватающих дополнительных коек
  l_bed_profile_id INTEGER;
  l_department_id INTEGER;
  l_department_profile_id INTEGER;
  l_regimen_id INTEGER;
  l_bed_id INTEGER;
  l_FOLD_BED_ID INTEGER; --Идентификатор статуса "Койка свернута"
  l_DEPLOYED_BED_ID INTEGER; --Идентификатор статуса "Койка развернута"
  l_BEDSPASE_RESOURSE_KIND_ID INTEGER = 4; --Иденитификатор вида ресуса "Койка"
  l_resource_id INTEGER;

  index INTEGER;
  l_number INTEGER;
BEGIN

  l_FOLD_BED_ID = (select id from pim_stock_unit_state where code = '4' limit 1); --Логику позаимствовал с LSD
  l_DEPLOYED_BED_ID = (select id from pim_stock_unit_state where code = '3' limit 1);

  l_cell_count = (
    select coalesce(cell_count,0) from md_room where id = p_room_id
  );

  IF l_cell_count ISNULL or l_cell_count < 0
    THEN RAISE EXCEPTION 'Не удалось определить планируемое количество основных коек';
  END IF;

  l_cell_count_fact = (
    select count(mb.room_id)
      from md_bed mb where mb.room_id = p_room_id and
      (mb.from_dt is null or CURRENT_DATE >= mb.from_dt) and
      (mb.to_dt is null or mb.to_dt >= CURRENT_DATE) and
      not COALESCE(mb.additional_bed, false)
  );

  l_cell_count_extra = (
    select coalesce(cell_count_extra,0) from md_room where id = p_room_id
  );

  IF l_cell_count_extra ISNULL or l_cell_count_extra < 0
    THEN RAISE EXCEPTION 'Не удалось определить планируемое количество дополнительных коек';
  END IF;

  l_cell_count_extra_fact = (
    select count(mb.room_id)
      from md_bed mb where mb.room_id = p_room_id and
      (mb.from_dt is null or CURRENT_DATE >= mb.from_dt) and
      (mb.to_dt is null or mb.to_dt >= CURRENT_DATE) and
      COALESCE(mb.additional_bed, false)
  );

  /*Определяем профиль койки*/
  l_bed_profile_id = (
    select bed_profile_id from md_profile_to_bed_profile where profile_id = p_profile_id limit 1
  );
  IF l_bed_profile_id ISNULL
  THEN RAISE EXCEPTION 'Профиль койки не определен'; END IF;

  l_department_id = (select department_id from pim_room where id = p_room_id);
  l_department_profile_id = (
    select id from md_department_profile
    where profile_id notnull and profile_id = p_profile_id and
    department_id notnull and department_id = l_department_id limit 1
  );

  l_regimen_id = (select regimen_id from md_room where id = p_room_id);
  IF l_regimen_id ISNULL
  THEN RAISE EXCEPTION 'Не задан режим лечения'; END IF;

  l_number = (select coalesce(max(number::integer),0)+1 from md_bed where number ~ '^[0-9]{1,6}$' and room_id = p_room_id);
  /* Пробуем добавить нехватающие основные койки  */
  IF l_cell_count_fact < l_cell_count THEN
    l_cell_count_lack = l_cell_count - l_cell_count_fact;
    index = 0;

    WHILE index < l_cell_count_lack LOOP
      INSERT into md_bed (
        id,
        room_id,
        bed_profile_id,
        profile_id,
        regimen_id,
        from_dt,
        number,
        additional_bed
      ) values (
        nextval('md_bed_seq'),
        p_room_id,
        l_bed_profile_id,
        l_department_profile_id,
        l_regimen_id,
        CURRENT_DATE,
        l_number::varchar,
        false
      ) RETURNING id
      INTO l_bed_id;

      INSERT INTO md_bed_state( id, bed_id, from_dt, state_id)
      VALUES (nextval('md_bed_state_seq'), l_bed_id, CURRENT_DATE, l_DEPLOYED_BED_ID);

      INSERT INTO sr_resource( id, res_kind_id)
      VALUES (nextval('sr_resource_seq'), l_BEDSPASE_RESOURSE_KIND_ID) RETURNING id
      INTO l_resource_id;

      INSERT INTO md_bed_resource (id, bed_id)
      VALUES (l_resource_id, l_bed_id);

      l_number = l_number + 1;
      index = index + 1;
    END LOOP;
  END IF;

  /* Пробуем добавить нехватающие дополнительные койки  */
  IF l_cell_count_extra_fact < l_cell_count_extra THEN
    l_cell_count_extra_lack = l_cell_count_extra - l_cell_count_extra_fact;
    index = 0;

    WHILE index < l_cell_count_extra_lack LOOP
      INSERT into md_bed (
        id,
        room_id,
        bed_profile_id,
        profile_id,
        regimen_id,
        from_dt,
        number,
        additional_bed
      ) values (
        nextval('md_bed_seq'),
        p_room_id,
        l_bed_profile_id,
        l_department_profile_id,
        l_regimen_id,
        CURRENT_DATE,
        l_number::varchar,
        true
      ) RETURNING id
      INTO l_bed_id;

      INSERT INTO md_bed_state( id, bed_id, from_dt, state_id)
      VALUES (nextval('md_bed_state_seq'), l_bed_id, null, l_FOLD_BED_ID);

      INSERT INTO sr_resource( id, res_kind_id)
      VALUES (nextval('sr_resource_seq'), l_BEDSPASE_RESOURSE_KIND_ID) RETURNING id
      INTO l_resource_id;

      INSERT INTO md_bed_resource (id, bed_id)
      VALUES (l_resource_id, l_bed_id);

      l_number = l_number + 1;
      index = index + 1;
    END LOOP;
  END IF;

END;
$$;

