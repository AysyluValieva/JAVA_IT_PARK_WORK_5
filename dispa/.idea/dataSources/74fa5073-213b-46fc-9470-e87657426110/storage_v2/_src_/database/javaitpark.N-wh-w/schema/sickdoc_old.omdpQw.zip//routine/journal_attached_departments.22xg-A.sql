CREATE FUNCTION journal_attached_departments(p_id integer)
  RETURNS TABLE(id integer, code character varying, clinic_id integer, journal_id integer, name character varying)
IMMUTABLE
LANGUAGE plpgsql
AS $$
DECLARE
  l_clinic_id INTEGER;
BEGIN

  IF (SELECT j.is_common_for_clinic
      FROM sickdoc.journal j
      WHERE j.id = p_id)
  THEN

    l_clinic_id = (SELECT j.clinic_id
                   FROM sickdoc.journal j
                   WHERE j.id = p_id);
    RETURN QUERY
    SELECT
      d.id,
      d.code,
      l_clinic_id,
      p_id,
      d.name
    FROM pim_department d
    WHERE d.org_id = l_clinic_id;
  ELSE

    RETURN QUERY
    SELECT
      d.id as id,
      d.code as code,
      l_clinic_id as clinic_id,
      p_id as journal_id,
      d.name as name
    FROM sickdoc.journal_default j
      JOIN pim_department d ON d.id = j.dep_id
    WHERE j.journal_id = p_id;

  END IF;

END;
$$;

