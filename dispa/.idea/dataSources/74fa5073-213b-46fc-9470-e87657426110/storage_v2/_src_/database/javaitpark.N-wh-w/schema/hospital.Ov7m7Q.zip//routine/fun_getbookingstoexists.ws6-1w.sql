CREATE FUNCTION fun_getbookingstoexists(patiend_id integer, department_id integer, admission_date date, end_date date, is_current_dep boolean DEFAULT true)
  RETURNS boolean
LANGUAGE SQL
AS $$
with bo as (
                SELECT bo.bed_id, bo.reservation_id
                FROM hospital.booking bo
                    JOIN hospital.booking_status bs ON bo.status_id = bs.id
                WHERE bs.code IN ('2', '3')
                    and daterange(bo.begin_dt, bo.end_dt, '[]') && daterange($3::date, $4::date, '[]')
                    and bo.iscurrent = TRUE
                )
            SELECT exists(
                SELECT 1
                FROM bo
                    JOIN md_bed mb ON bo.bed_id = mb.id
                    JOIN hsp_reservation hr ON bo.reservation_id = hr.id
                    JOIN md_referral mr ON hr.referral_id = mr.id
                WHERE
                    $5 = TRUE
                    AND hr.department_id = coalesce(nullif($2, -1), hr.department_id)
                    AND mr.patient_id = coalesce(nullif($1, -1), mr.patient_id)
                union all
                SELECT 1
                FROM bo
                    JOIN md_bed mb ON bo.bed_id = mb.id
                    JOIN hsp_reservation hr ON bo.reservation_id = hr.id
                    JOIN md_referral mr ON hr.referral_id = mr.id
                WHERE
                    $5 = FALSE
                    AND hr.department_id <> coalesce($2, -1)
                    AND mr.patient_id = coalesce(nullif($1, -1), mr.patient_id)
                )
$$;

