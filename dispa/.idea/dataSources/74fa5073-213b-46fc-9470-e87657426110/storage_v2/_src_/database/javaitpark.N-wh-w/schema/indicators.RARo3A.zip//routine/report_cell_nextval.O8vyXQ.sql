CREATE FUNCTION report_cell_nextval(report_id integer, year_ integer)
  RETURNS bigint
LANGUAGE plpgsql
AS $$
--Состав первичного ключа:
                        --	RRRRYYYNNNNNNNNNNNN
                        -- 	где RRRR - код отчетной формы;
                        --  YYY  - последние 3 символа года, извлекается из временного среза;
                        --  NNNNNNNNNNNN - уникальный код строки (формируется функцией nextval('indicators_inh.report_cell_yYYYY_rRRRR_seq'))

                BEGIN

                    IF report_id IS NULL THEN
                        RAISE EXCEPTION 'Не задан параметр report_id';
                    END IF;

                    IF year_ IS NULL THEN
                        RAISE EXCEPTION 'Не задан параметр year_';
                    END IF;

                    RETURN  (report_id::text|| substring(year_::text, 2) || lpad(nextval(('indicators_inh.report_cell_y'||
                        CAST(year_ as varchar) || '_r' || CAST(report_id as varchar) || '_seq')::regclass)::text, 12,'0'))::bigint;

                END;
$$;

