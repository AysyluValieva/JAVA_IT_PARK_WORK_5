CREATE VIEW getworkingtime_ AS
  SELECT DISTINCT ss.bdatetime AS bdt,
    ss.edatetime AS edt,
    rg.id,
    (ss.bdatetime)::date AS _bdatetime,
    (ss.edatetime)::date AS _edatetime
   FROM (((((((((pim_employee_position ep
     JOIN sr_res_group rg ON ((rg.responsible_id = ep.id)))
     JOIN sr_res_group_source srgr ON ((srgr.res_group_id = rg.id)))
     JOIN md_appointment_source mas ON ((mas.id = srgr.source_id)))
     JOIN sr_timetable_res_group trg ON ((trg.res_group_id = rg.id)))
     JOIN sr_timetable t ON ((t.id = trg.id)))
     JOIN sr_shift s ON ((s.timetable_id = t.id)))
     JOIN sr_session ss ON ((ss.shift_id = s.id)))
     LEFT JOIN sr_session_ticket sst ON ((sst.session_id = ss.id)))
     LEFT JOIN sr_session_quotum ssq ON ((ss.id = ssq.session_id)))
  WHERE ((ssq.session_id IS NULL) AND (sst.session_id IS NULL) AND (s.time_type_id <> 2) AND (ss.bdatetime > now()) AND (ss.time_type_id <> 2));

