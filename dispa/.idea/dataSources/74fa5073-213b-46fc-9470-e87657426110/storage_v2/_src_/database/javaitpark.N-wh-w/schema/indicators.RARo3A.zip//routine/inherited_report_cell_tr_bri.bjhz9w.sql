CREATE FUNCTION inherited_report_cell_tr_bri()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN

                    NEW.min_id := CAST((CAST(NEW.report_id as text) || substring(CAST(NEW.year_ as text),2) || '000000000000') as bigint);

                    NEW.max_id := NEW.min_id + 999999999999;

                    RETURN NEW;

                END;
$$;

