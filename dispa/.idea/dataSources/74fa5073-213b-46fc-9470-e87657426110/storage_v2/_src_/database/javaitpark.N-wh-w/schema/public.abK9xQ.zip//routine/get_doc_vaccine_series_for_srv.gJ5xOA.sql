CREATE FUNCTION get_doc_vaccine_series_for_srv(srv_id integer)
  RETURNS text
LANGUAGE plpgsql
AS $$
declare
  i integer;
begin
  RETURN 

(select s.num as series 
from mc_inv_opr_srv opr_r 
join inv_opr opr on opr.id=opr_r.opr_id and opr_r.service_id=srv_id
join inv_spec spec on spec.opr_id=opr.id
join inv_remains rem on rem.id=spec.contractor_remains_id
join inv_series s on s.id = rem.series_id
limit 1)
;
end;
$$;

