CREATE VIEW cas_user_tgt_counter AS
  SELECT t.username,
    t.tgt_count AS count
   FROM dblink('host=127.0.0.1 dbname=cas user=cas password=cas'::text, '
      SELECT username, tgt_count
      FROM user_tgt_counter'::text) t(username character varying(255), tgt_count integer);

