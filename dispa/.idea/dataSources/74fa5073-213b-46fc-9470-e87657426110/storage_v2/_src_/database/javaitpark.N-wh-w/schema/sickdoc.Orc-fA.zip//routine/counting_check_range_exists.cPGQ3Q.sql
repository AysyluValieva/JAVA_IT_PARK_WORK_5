CREATE FUNCTION counting_check_range_exists(p_requisites character varying, p_table_name character varying, p_id integer)
  RETURNS bigint
LANGUAGE plpgsql
AS $$
DECLARE
  l_result bigint;
  l_record RECORD;
  l_arr_input varchar[];
  l_str_iterator varchar;
  l_arr bigint[] DEFAULT '{}';
  l_arr_total bigint[] DEFAULT '{}';

  l_begin bigint;
  l_end bigint;

  l_id_case varchar DEFAULT ';';

BEGIN
  IF p_id IS NOT NULL THEN
     IF p_table_name = 'bso_record_range' THEN  l_id_case:=' WHERE r.rec_record_id <> ' || p_id;
     ELSE l_id_case:=' WHERE r.distr_record_id <> ' || p_id;
     END IF;
  END IF;

  l_arr_input := string_to_array(p_requisites,';');

  FOR l_record IN EXECUTE 'SELECT * FROM sickdoc.' || p_table_name || ' r ' || l_id_case LOOP
	FOREACH l_str_iterator IN ARRAY l_arr_input LOOP
	          l_arr := regexp_split_to_array(l_str_iterator, '-');
		  l_begin := l_arr[1];
		  IF array_length(l_arr, 1) = 2 THEN l_end := l_arr[2]; ELSE l_end := l_arr[1]; END IF;
		  IF NOT (l_begin > COALESCE (l_record.end_num,l_record.start_num)::bigint  OR l_end < l_record.start_num::bigint) THEN RETURN 1; END IF;
	END LOOP;
  END LOOP;
  RETURN 0;
END;

$$;

