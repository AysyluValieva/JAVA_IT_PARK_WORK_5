CREATE FUNCTION fin_get_price_type(p1_bill_id integer, OUT value text)
  RETURNS text
STABLE
STRICT
LANGUAGE plpgsql
AS $$
DECLARE
    _main_bill_id INTEGER := public.fin_bill__get_main_bill (p1_bill_id);
BEGIN
    value := (SELECT t.code FROM public.fin_pl_type AS t, public.fin_price_list AS l, public.fin_bill_main AS m WHERE t.id = l.type_id AND l.id = m.price_list_id AND m.id = _main_bill_id LIMIT 1);
END;
$$;

