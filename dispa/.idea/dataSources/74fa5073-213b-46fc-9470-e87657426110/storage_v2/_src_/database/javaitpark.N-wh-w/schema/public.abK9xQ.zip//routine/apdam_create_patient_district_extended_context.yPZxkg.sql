CREATE FUNCTION apdam_create_patient_district_extended_context(in_reg_date date)
  RETURNS void
LANGUAGE plpgsql
AS $$
BEGIN
  DROP TABLE IF EXISTS apdam_patient_district;
  CREATE UNLOGGED TABLE apdam_patient_district WITH (AUTOVACUUM_ENABLED = FALSE
  ) AS
    SELECT
      d.patient_id,
      d.district_id,
      d.pim_party_address_id,
      d.org_terminal_id,
      d.orgs,
      coalesce(job.orgs, ARRAY [] :: INT [])         AS p_orgs,
      d.diagnosis_terminal_id,
      d.diagnos_code_from,
      d.diagnos_code_to,
      dispensary.codes                               AS p_diagnos_codes,
      d.age_terminal_id,
      d.age_from                                     AS age_from,
      d.age_to                                       AS age_to,
      d.p_age,
      d.gender_terminal_id,
      d.gender_id,
      d.p_gender_id,
      d.benefit_terminal_id,
      d.benefits,
      coalesce(benefit.benefits, ARRAY [] :: INT []) AS p_benefits,
      TRUE :: BOOLEAN                                AS check_terminal
    FROM apdam_patient_district_limited d,
      LATERAL (SELECT array_agg(j.organization_id) orgs
               FROM pci_patient_job j
               WHERE j.patient_id = d.patient_id
                     AND ($1 >= j.from_dt OR j.from_dt ISNULL)
                     AND ($1 <= j.to_dt OR j.to_dt ISNULL)
      ) job,
      LATERAL (SELECT array_agg(j.benefit_def_id) benefits
               FROM pci_benefit j
               WHERE j.patient_id = d.patient_id
                     AND ($1 >= j.from_dt OR j.from_dt ISNULL)
                     AND ($1 <= j.to_dt OR j.to_dt ISNULL)
      ) benefit,
      LATERAL (SELECT array_agg(md.code) codes
               FROM pci_dispensary pd
                 JOIN md_diagnosis md ON pd.diagnosis_id = md.id
               WHERE pd.patient_id = d.patient_id
                     AND ($1 >= pd.reg_in_dt OR pd.reg_in_dt ISNULL)
                     AND ($1 <= pd.reg_out_dt OR pd.reg_out_dt ISNULL)
      ) dispensary;

  CREATE INDEX ON apdam_patient_district USING BTREE (district_id);
END;
$$;

