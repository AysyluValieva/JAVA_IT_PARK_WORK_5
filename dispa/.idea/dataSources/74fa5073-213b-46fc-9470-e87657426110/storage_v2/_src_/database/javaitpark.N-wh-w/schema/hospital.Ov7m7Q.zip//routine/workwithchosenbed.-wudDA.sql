CREATE FUNCTION workwithchosenbed(p_dep_id integer, p_profile_id integer, p_bed_profile_id integer, p_room_id integer, p_bed_id integer, p_bed_count_shift_max integer, p_begin_date date, p_end_date date, p_step_old integer, p_step_new integer, p_rezervation_old integer, p_rezervation_new integer, p_count_shift integer, p_type_old character varying, p_type_new character varying)
  RETURNS numeric
LANGUAGE plpgsql
AS $$
DECLARE
    _status_old_id INTEGER;
    _status_new_id INTEGER;
    rez            INTEGER;
BEGIN
    -- функция для изменения состояния коечного фонда для типов брони Экстренная бронь и Бронь плановая подтвержденная и неподтвержденная

    -- изменение КФ для типов брони ЗАНЯТО происходит на срабатывании триггеров на сохранениие/изменение/удаление СОСТАВНОГО РЕСУРСА типа КОЙКА при привязке к посещению госпитального случая
    -- или изменение посещений госпиталного случая (когда выбирают/отменяют созданный ранее существующий СОСТАВНОЙ РЕСУРС, такая возможность есть в ЛСД или интеграционных сервисах)
    -- использовать текущую функцию для изменения типа брони ЗАНЯТО нельзя.

    -- 1й шаг
    -- чистим состояние до (если FREE) то шаг пропускаем
    -- находим старое состояние с TRUE -- FALSE

    -- оптимизированный вариант поиска _status_old_id и _status_new_id за один проход таблицы
    SELECT
        coalesce((array_agg(status_old
        ORDER BY status_old) :: INT []) [1], 4) AS _status_old_id,
        coalesce((array_agg(status_new
        ORDER BY status_new) :: INT []) [1], 4) AS _status_new_id
    INTO _status_old_id, _status_new_id
    FROM (
             SELECT
                 CASE WHEN st.type = lower(p_type_old)
                     THEN bs.id
                 ELSE NULL END AS status_old,
                 CASE WHEN st.type = lower(p_type_new)
                     THEN bs.id
                 ELSE NULL END AS status_new
             FROM (VALUES
                 ('busy', '5'),
                 ('extra', '1'),
                 ('conf', '3'),
                 ('unconf', '2'),
                 ('free', '4')
                  ) st(type, codde)
                 JOIN hospital.booking_status bs ON bs.code = st.codde
             WHERE st.type IN (lower(p_type_old), lower(p_type_new))
         ) t;
    -- 1й шаг списываем. учитывается возможность существования остатка после списания, записи о бронях могут существовать как в ширь (несколько дней) так и в глубь (занимает несколько смен в день), это все учтено в новой версии)
    WITH dt_interval as ( -- определим расширение диапазона
        select daterange(b.begin_dt, b.end_dt, '[]') as dt_range,
               b.begin_dt,
               b.end_dt
        from   hospital.booking b
        WHERE _status_old_id <> 4
              AND b.iscurrent
              AND daterange(b.begin_dt, b.end_dt, '[]') && daterange(p_begin_date, p_end_date, '[]')
              AND coalesce(b.step_id, -1) = coalesce(p_step_old, -1)
              AND coalesce(b.reservation_id, -1) = coalesce(p_rezervation_old, -1)
              AND b.bed_id = p_bed_id
              AND b.status_id = _status_old_id
        ),
    upd_old AS ( -- все записи попавшие в диапазон считаем недействительными, если после списания есть остаток то прибавим на следующем шаге
        UPDATE hospital.booking b
        SET iscurrent = FALSE
        FROM  dt_interval
        WHERE _status_old_id <> 4
              AND b.iscurrent
              AND daterange(b.begin_dt, b.end_dt, '[]') && dt_interval.dt_range
              AND coalesce(b.step_id, -1) = coalesce(p_step_old, -1)
              AND coalesce(b.reservation_id, -1) = coalesce(p_rezervation_old, -1)
              AND b.bed_id = p_bed_id
        RETURNING *
        ),
    book_saldo AS ( -- если остается остаток после списания то мы добавляем в booking остаток с признаком T (для OLD = free так делать не будем)

        SELECT  bb.step_id, bb.bed_id, bb.reservation_id, bb.status_id, d.dt, bb.saldo
        FROM dt_interval
            join lateral (select dt from generate_series(dt_interval.begin_dt, dt_interval.end_dt, '1 day')dt) d(dt) on true
            join lateral (
                 select b_old.step_id, b_old.bed_id, b_old.reservation_id, b_old.status_id, sum(bs_old.count_shift) - coalesce(p_count_shift, 0) as saldo
                 from upd_old b_old
                      join hospital.booking_shift bs_old on b_old.id = bs_old.booking_id and bs_old.dt = d.dt
                 GROUP BY b_old.step_id, b_old.bed_id, b_old.reservation_id, b_old.status_id
                 HAVING sum(bs_old.count_shift) - coalesce(p_count_shift, 0) > 0
                 )bb on TRUE
            WHERE _status_old_id = 1
        ),
    --ins_log as (insert into hospital.booking_dev_log (log) select t from (select * from book_saldo)t returning 1),
    ins_book_saldo as (--добавляем остаток в booking
        INSERT INTO hospital.booking (step_id, bed_id, reservation_id, status_id, status_date, begin_dt, end_dt, iscurrent)
        select step_id, bed_id, reservation_id, status_id, now(), dt, dt, TRUE from book_saldo
        RETURNING *
        ),
    --ins_log as (insert into hospital.booking_dev_log (log) select t from (select * from ins_book_saldo)t returning 1),
    ins_book_shift_saldo AS (
            INSERT INTO hospital.booking_shift (booking_id, count_shift, dt)
                SELECT
                    bi.id,
                    ss.saldo,
                    bi.begin_dt
                FROM ins_book_saldo bi
                    JOIN LATERAL (-- если на этот день уже была ранее экстра, но после списания остается остаток то мы прошлую сделали неактуальной, и вставляем записи на разницу
                    SELECT sum(ss.saldo) as saldo FROM book_saldo ss
                    WHERE coalesce(bi.step_id, -1) = coalesce(ss.step_id, -1)
                         and coalesce(bi.reservation_id, -1) = coalesce(ss.reservation_id, -1)
                         and bi.status_id = ss.status_id
                         AND bi.begin_dt = ss.dt
                    ) ss ON TRUE
                --left join lateral (select 1 from new_ins_old limit 1) n on true
                WHERE _status_old_id = 1
            RETURNING 1)
    select 1 INTO rez;
    -- 2 шаг -- если NEW = FREE то шаг пропускаем
    -- проверяем есть ли на новое состояние записи с TRUE
    -- если есть то запоминаем их количество и делаем FALSE
    WITH new_ins_old AS (
        UPDATE hospital.booking b
        SET iscurrent = FALSE
        WHERE --p_type_new <> 'free'
            b.iscurrent = TRUE
            AND daterange(b.begin_dt, b.end_dt, '[]') && daterange(p_begin_date, p_end_date, '[]')
            AND coalesce(b.step_id, -1) = coalesce(p_step_new, -1)
            AND coalesce(b.reservation_id, -1) = coalesce(p_rezervation_new, -1)
            AND b.bed_id = p_bed_id
            AND b.status_id = _status_new_id
        RETURNING *),
        -- 3 шаг, добавляем новые записи.
        -- если новое состояние равно extra (на каждый день отдельно сохраняем booking)
            ins_book_extra AS (
            INSERT INTO hospital.booking (step_id, bed_id, reservation_id, status_id, status_date, begin_dt, end_dt, iscurrent)
                SELECT
                    NULLif(p_step_new, -1),
                    p_bed_id,
                    NULLif(p_rezervation_new, -1),
                    _status_new_id,
                    now(),
                    d.dt,
                    d.dt,
                    TRUE
                FROM generate_series(p_begin_date :: DATE, p_end_date :: DATE, '1 day') d(dt)
                    LEFT JOIN LATERAL (SELECT 1
                                       FROM new_ins_old
                                       LIMIT 1) n ON TRUE
                WHERE p_type_new = 'extra'
            RETURNING *),
            ins_book_shift_extra AS (
            INSERT INTO hospital.booking_shift (booking_id, count_shift, dt)
                SELECT
                    bb.id,
                    p_count_shift + coalesce(previos.count_shift_prev, 0),
                    bb.begin_dt
                FROM ins_book_extra bb
                    LEFT JOIN
                    LATERAL (-- если на этот день уже была ранее экстра то мы прошлую сделали неактуальной, а ее значение прибавляем к текущему p_count_shift
                    SELECT sum(bs2.count_shift) AS count_shift_prev
                    FROM new_ins_old b2
                        JOIN hospital.booking_shift bs2 ON bs2.booking_id = b2.id AND bs2.dt = b2.begin_dt
                    WHERE bb.bed_id = b2.bed_id
                          AND b2.begin_dt = bb.begin_dt
                    ) previos ON TRUE
                --left join lateral (select 1 from new_ins_old limit 1) n on true
                WHERE p_type_new = 'extra'
            RETURNING 1),
        -- если новое состояние не extra (добавляем указанный интервал)
            ins_book AS (
            INSERT INTO hospital.booking (step_id, bed_id, reservation_id, status_id, status_date, begin_dt, end_dt, iscurrent)
                SELECT
                    nullif(p_step_new, -1),
                    p_bed_id,
                    nullif(p_rezervation_new, -1),
                    _status_new_id,
                    now(),
                    p_begin_date,
                    p_end_date,
                    TRUE
                WHERE p_type_new <> 'extra'
            RETURNING *),
            ins_book_shift AS (
            INSERT INTO hospital.booking_shift (booking_id, count_shift, dt)
                SELECT
                    bb.id,
                    p_count_shift + coalesce(previos.count_shift_prev, 0),
                    d.dt
                FROM ins_book bb
                    JOIN generate_series(p_begin_date :: DATE, p_end_date :: DATE, '1 day') d(dt) ON TRUE
                    LEFT JOIN
                    LATERAL (-- если на этот день уже была ранее экстра то мы прошлую сделали неактуальной, а ее значение прибавляем к текущему p_count_shift
                    SELECT sum(bs2.count_shift) AS count_shift_prev
                    FROM new_ins_old b2
                        JOIN hospital.booking_shift bs2 ON bs2.booking_id = b2.id AND bs2.dt = b2.begin_dt
                    ) previos ON TRUE
            RETURNING 1)
    SELECT 1
    INTO rez;
    RETURN 1;
END;
$$;

