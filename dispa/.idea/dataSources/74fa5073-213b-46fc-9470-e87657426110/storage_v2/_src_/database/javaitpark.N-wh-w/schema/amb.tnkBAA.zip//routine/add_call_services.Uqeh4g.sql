CREATE FUNCTION add_call_services(xcall integer, xservice_id integer, xservice_place integer, xorg_id integer, xquantity integer, for_upload boolean)
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
                    xrendered integer;
                    dt TIMESTAMP  WITHOUT TIME ZONE;
                    patient integer;
                    xcase integer;

                  begin
                        xrendered = nextval('sr_srv_rendered_seq');
                        select into dt,patient cast(from_time as date),patient_id from amb.md_ambulance_call where id = xcall;
                        select into xcase case_id from amb.md_ambulance_call_result where id = xcall;
                        insert into public.sr_srv_rendered(id,is_rendered,customer_id,org_id,service_id,bdate,edate,quantity,funding_id, for_upload)
                            values (xrendered,true,patient,xorg_id,xservice_id,dt,dt,xquantity,(select id from fin_funding_source_type where e_code = 'FREE'), for_upload);

                        insert into md_srv_rendered (id,case_id,is_urgent)
                            values(xrendered,xcase,true);

                        insert into amb.md_ambulance_call_services (call_id,service_id,service_place_id)
                                    values(xcall,xrendered,xservice_place);
                  end;
$$;

