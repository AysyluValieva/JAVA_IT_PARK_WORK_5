CREATE FUNCTION fin_fill_pivot_fin_bill_patients_from_temp_table_dev(p1_bill_id integer)
  RETURNS void
STRICT
LANGUAGE plpgsql
AS $$
DECLARE
	v_cnt bigint;
BEGIN
/*fin_bill_patients*/

    INSERT INTO billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fill_fin_bill_patients. Начало');

    IF EXISTS (SELECT relname FROM pg_class WHERE relname='tmp_fin_bill_patients') THEN
    DELETE
      FROM billing.fin_bill_patients AS fbp
     WHERE fbp.bill_id = p1_bill_id
           AND NOT EXISTS (SELECT NULL
                             FROM tmp_fin_bill_patients AS tfbp
                            WHERE fbp.bill_id = tfbp.bill_id
                                  AND fbp.id_pac = tfbp.id_pac);


	GET DIAGNOSTICS v_cnt = ROW_COUNT;
	INSERT INTO billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fill_fin_bill_patients. Deleted: ' || v_cnt || ' rows.');


    UPDATE billing.fin_bill_patients AS fbp
       SET 	from_date = tfbp.from_date,
		to_date = tfbp.to_date,
		item_id_arr = tfbp.item_id_arr,
		patient_id = tfbp.patient_id,
		new_born = tfbp.new_born,
		new_born_part = tfbp.new_born_part,
		pat_surname = tfbp.pat_surname,
		pat_name = tfbp.pat_name,
		pat_patr_name = tfbp.pat_patr_name,
		pat_gender_code = tfbp.pat_gender_code,
		pat_birth_dt = tfbp.pat_birth_dt,
		pat_birthweight = tfbp.pat_birthweight,
		pat_os_sluch = tfbp.pat_os_sluch,
		pat_snils = tfbp.pat_snils,
		pat_social_status = tfbp.pat_social_status,
		pat_reg_addr_id = tfbp.pat_reg_addr_id,
		pat_reg_addr_okato = tfbp.pat_reg_addr_okato,
		pat_fact_addr_id = tfbp.pat_fact_addr_id,
		pat_fact_addr_okato = tfbp.pat_fact_addr_okato,
		pat_birth_addr_id = tfbp.pat_birth_addr_id,
		pat_birth_addr_okato = tfbp.pat_birth_addr_okato,
		pat_birth_addr_text = tfbp.pat_birth_addr_text,
		pat_identity_type = tfbp.pat_identity_type,
		pat_identity_series = tfbp.pat_identity_series,
		pat_identity_number = tfbp.pat_identity_number,
		representative_id = tfbp.representative_id,
		rep_surname = tfbp.rep_surname,
		rep_name = tfbp.rep_name,
		rep_patr_name = tfbp.rep_patr_name,
		rep_no_patr_name = tfbp.rep_no_patr_name,
		rep_gender_code = tfbp.rep_gender_code,
		rep_birth_dt = tfbp.rep_birth_dt,
		rep_os_sluch = tfbp.rep_os_sluch,
		rep_snils = tfbp.rep_snils,
		rep_reg_addr_id = tfbp.rep_reg_addr_id,
		rep_reg_addr_okato = tfbp.rep_reg_addr_okato,
		rep_fact_addr_id = tfbp.rep_fact_addr_id,
		rep_fact_addr_okato = tfbp.rep_fact_addr_okato,
		rep_birth_addr_id = tfbp.rep_birth_addr_id,
		rep_birth_addr_text = tfbp.rep_birth_addr_text,
		rep_identity_type = tfbp.rep_identity_type,
		rep_identity_series = tfbp.rep_identity_series,
		rep_identity_number = tfbp.rep_identity_number,
		region_data = tfbp.region_data/*,
		aud_who = tfbp.aud_who,
		aud_when = tfbp.aud_when,
		aud_source = tfbp.aud_source,
		aud_who_create = tfbp.aud_who_create,
		aud_when_create = tfbp.aud_when_create,
		aud_source_create = tfbp.aud_source_create*/
      FROM tmp_fin_bill_patients AS tfbp
     WHERE fbp.bill_id = tfbp.bill_id
           AND fbp.id_pac = tfbp.id_pac
    AND (COALESCE(fbp.from_date, date '19000101') != COALESCE(tfbp.from_date, date '19000101')
		OR COALESCE(fbp.to_date, date '19000101') != COALESCE(tfbp.to_date, date '19000101')
		OR COALESCE(fbp.item_id_arr, ARRAY[0]) != COALESCE(tfbp.item_id_arr, ARRAY[0])
		OR COALESCE(fbp.patient_id, 0) != COALESCE(tfbp.patient_id, 0)
		OR COALESCE(fbp.new_born, FALSE) != COALESCE(tfbp.new_born, FALSE)
		OR COALESCE(fbp.new_born_part, '') != COALESCE(tfbp.new_born_part, '')
		OR COALESCE(fbp.pat_surname, '') != COALESCE(tfbp.pat_surname, '')
		OR COALESCE(fbp.pat_name, '') != COALESCE(tfbp.pat_name, '')
		OR COALESCE(fbp.pat_patr_name, '') != COALESCE(tfbp.pat_patr_name, '')
		OR COALESCE(fbp.pat_gender_code, '') != COALESCE(tfbp.pat_gender_code, '')
		OR COALESCE(fbp.pat_birth_dt, date '19000101') != COALESCE(tfbp.pat_birth_dt, date '19000101')
		OR COALESCE(fbp.pat_birthweight, 0) != COALESCE(tfbp.pat_birthweight, 0)
		OR COALESCE(fbp.pat_os_sluch, ARRAY['']) != COALESCE(tfbp.pat_os_sluch, ARRAY[''])
		OR COALESCE(fbp.pat_snils, '') != COALESCE(tfbp.pat_snils, '')
		OR COALESCE(fbp.pat_social_status, '') != COALESCE(tfbp.pat_social_status, '')
		OR COALESCE(fbp.pat_reg_addr_id, 0) != COALESCE(tfbp.pat_reg_addr_id, 0)
		OR COALESCE(fbp.pat_reg_addr_okato, '') != COALESCE(tfbp.pat_reg_addr_okato, '')
		OR COALESCE(fbp.pat_fact_addr_id, 0) != COALESCE(tfbp.pat_fact_addr_id, 0)
		OR COALESCE(fbp.pat_fact_addr_okato, '') != COALESCE(tfbp.pat_fact_addr_okato, '')
		OR COALESCE(fbp.pat_birth_addr_id, 0) != COALESCE(tfbp.pat_birth_addr_id, 0)
		OR COALESCE(fbp.pat_birth_addr_okato, '') != COALESCE(tfbp.pat_birth_addr_okato, '')
		OR COALESCE(fbp.pat_birth_addr_text, '') != COALESCE(tfbp.pat_birth_addr_text, '')
		OR COALESCE(fbp.pat_identity_type, 0) != COALESCE(tfbp.pat_identity_type, 0)
		OR COALESCE(fbp.pat_identity_series, '') != COALESCE(tfbp.pat_identity_series, '')
		OR COALESCE(fbp.pat_identity_number, '') != COALESCE(tfbp.pat_identity_number, '')
		OR COALESCE(fbp.representative_id, 0) != COALESCE(tfbp.representative_id, 0)
		OR COALESCE(fbp.rep_surname, '') != COALESCE(tfbp.rep_surname, '')
		OR COALESCE(fbp.rep_name, '') != COALESCE(tfbp.rep_name, '')
		OR COALESCE(fbp.rep_patr_name, '') != COALESCE(tfbp.rep_patr_name, '')
		OR COALESCE(fbp.rep_no_patr_name, FALSE) != COALESCE(tfbp.rep_no_patr_name, FALSE)
		OR COALESCE(fbp.rep_gender_code, '') != COALESCE(tfbp.rep_gender_code, '')
		OR COALESCE(fbp.rep_birth_dt, date '19000101') != COALESCE(tfbp.rep_birth_dt, date '19000101')
		OR COALESCE(fbp.rep_os_sluch, ARRAY['']) != COALESCE(tfbp.rep_os_sluch, ARRAY[''])
		OR COALESCE(fbp.rep_snils, '') != COALESCE(tfbp.rep_snils, '')
		OR COALESCE(fbp.rep_reg_addr_id, 0) != COALESCE(tfbp.rep_reg_addr_id, 0)
		OR COALESCE(fbp.rep_reg_addr_okato, '') != COALESCE(tfbp.rep_reg_addr_okato, '')
		OR COALESCE(fbp.rep_fact_addr_id, 0) != COALESCE(tfbp.rep_fact_addr_id, 0)
		OR COALESCE(fbp.rep_fact_addr_okato, '') != COALESCE(tfbp.rep_fact_addr_okato, '')
		OR COALESCE(fbp.rep_birth_addr_id, 0) != COALESCE(tfbp.rep_birth_addr_id, 0)
		OR COALESCE(fbp.rep_birth_addr_text, '') != COALESCE(tfbp.rep_birth_addr_text, '')
		OR COALESCE(fbp.rep_identity_type, 0) != COALESCE(tfbp.rep_identity_type, 0)
		OR COALESCE(fbp.rep_identity_series, '') != COALESCE(tfbp.rep_identity_series, '')
		OR COALESCE(fbp.rep_identity_number, '') != COALESCE(tfbp.rep_identity_number, '')
		OR COALESCE(fbp.region_data, ''::hstore) != COALESCE(tfbp.region_data, ''::hstore)
		/*OR COALESCE(fbp.aud_who, '') != COALESCE(tfbp.aud_who, '')
		OR COALESCE(fbp.aud_when, timestamp '19000101') != COALESCE(tfbp.aud_when, timestamp '19000101')
		OR COALESCE(fbp.aud_source, '') != COALESCE(tfbp.aud_source, '')
		OR COALESCE(fbp.aud_who_create, '') != COALESCE(tfbp.aud_who_create, '')
		OR COALESCE(fbp.aud_when_create, timestamp '19000101') != COALESCE(tfbp.aud_when_create, timestamp '19000101')
		OR COALESCE(fbp.aud_source_create, '') != COALESCE(tfbp.aud_source_create, '')*/);

	GET DIAGNOSTICS v_cnt = ROW_COUNT;
	INSERT INTO billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fill_fin_bill_patients. Changed: ' || v_cnt || ' rows.');
	
    INSERT
      INTO billing.fin_bill_patients(
						 bill_id, from_date, to_date, id_pac, item_id_arr, patient_id, new_born, new_born_part, pat_surname, pat_name, pat_patr_name, pat_gender_code, pat_birth_dt,
				     pat_birthweight, pat_os_sluch, pat_snils, pat_social_status, pat_reg_addr_id, pat_reg_addr_okato, pat_fact_addr_id, pat_fact_addr_okato, pat_birth_addr_id,
				     pat_birth_addr_okato, pat_birth_addr_text, pat_identity_type, pat_identity_series, pat_identity_number, representative_id, rep_surname, rep_name, rep_patr_name,
				     rep_no_patr_name, rep_gender_code, rep_birth_dt, rep_os_sluch, rep_snils, rep_reg_addr_id, rep_reg_addr_okato, rep_fact_addr_id, rep_fact_addr_okato, rep_birth_addr_id,
				     rep_birth_addr_text, rep_identity_type, rep_identity_series, rep_identity_number, region_data, aud_who, aud_when, aud_source, aud_who_create, aud_when_create, aud_source_create)
    SELECT bill_id, from_date, to_date, id_pac, item_id_arr, patient_id, new_born, new_born_part, pat_surname, pat_name, pat_patr_name, pat_gender_code, pat_birth_dt,
				     pat_birthweight, pat_os_sluch, pat_snils, pat_social_status, pat_reg_addr_id, pat_reg_addr_okato, pat_fact_addr_id, pat_fact_addr_okato, pat_birth_addr_id,
				     pat_birth_addr_okato, pat_birth_addr_text, pat_identity_type, pat_identity_series, pat_identity_number, representative_id, rep_surname, rep_name, rep_patr_name,
				     rep_no_patr_name, rep_gender_code, rep_birth_dt, rep_os_sluch, rep_snils, rep_reg_addr_id, rep_reg_addr_okato, rep_fact_addr_id, rep_fact_addr_okato, rep_birth_addr_id,
				     rep_birth_addr_text, rep_identity_type, rep_identity_series, rep_identity_number, region_data, aud_who, aud_when, aud_source, aud_who_create, aud_when_create, aud_source_create
      FROM tmp_fin_bill_patients tfbp
     WHERE NOT EXISTS (SELECT NULL
                         FROM billing.fin_bill_patients fbp
                        WHERE fbp.bill_id = p1_bill_id
                              AND tfbp.id_pac = fbp.id_pac);

	GET DIAGNOSTICS v_cnt = ROW_COUNT;
	INSERT INTO billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fill_fin_bill_patients. Inserted: ' || v_cnt || ' rows.');

    DROP TABLE tmp_fin_bill_patients;
    END IF;

    INSERT INTO billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fill_fin_bill_patients. Конец');
END;
$$;

