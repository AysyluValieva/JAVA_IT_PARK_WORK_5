CREATE FUNCTION apdam_attachment_new_patients(in_md_clinic_id integer, in_check_district boolean, in_department_id integer, in_type_id integer, in_reg_date date, in_active_address_code character varying)
  RETURNS void
LANGUAGE plpgsql
AS $$
BEGIN
  RAISE NOTICE '--Создание контекста участков ...';
  EXECUTE apdam_create_district_context(in_md_clinic_id, in_check_district, in_department_id, in_type_id, in_reg_date);

  RAISE NOTICE '--Создание контекста пациентов ...';
  EXECUTE apdam_create_patient_context(in_type_id, in_reg_date, in_active_address_code);

  RAISE NOTICE '--Создание контекста пациент - участок ...';
  EXECUTE apdam_create_patient_district_context(in_reg_date);

  RAISE NOTICE '--Прикрепление новых пациентов ...';
  EXECUTE apdam_attachment_new_patients_by_context(in_md_clinic_id, in_department_id, in_type_id, in_reg_date);
END;
$$;

