CREATE FUNCTION family_member_update(p_sikdoc_extended_id integer, p_disability_reason_code character varying, p_care_for_patient_id1 integer, p_care_for_patient_id2 integer, p_family_relation_id1 integer, p_family_relation_id2 integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
  c_family_member_codes CONSTANT VARCHAR ARRAY := ARRAY['03', '09', '12', '13', '14', '15'];

  l_family_member_id1 INTEGER;
  l_family_member_id2 INTEGER;
BEGIN
  SELECT
    family_member_1_id,
    family_member_2_id
  FROM sickdoc.sickdoc_extended
  WHERE id = p_sikdoc_extended_id
  INTO l_family_member_id1, l_family_member_id2;

  DELETE FROM sickdoc.family_member
  WHERE id = l_family_member_id1;

  DELETE FROM sickdoc.family_member
  WHERE id = l_family_member_id2;

  IF (select array_position(c_family_member_codes, p_disability_reason_code) is not null)
  THEN

    IF p_care_for_patient_id1 NOTNULL
    THEN
      INSERT INTO sickdoc.family_member (id, patient_id, relation_id)
      VALUES (DEFAULT, p_care_for_patient_id1, p_family_relation_id1)
      RETURNING id
        INTO l_family_member_id1;
      UPDATE sickdoc.sickdoc_extended
      SET family_member_1_id = l_family_member_id1
      WHERE id = p_sikdoc_extended_id;
    END IF;

    IF p_care_for_patient_id2 NOTNULL
    THEN
      INSERT INTO sickdoc.family_member (id, patient_id, relation_id)
      VALUES (DEFAULT, p_care_for_patient_id2, p_family_relation_id2)
      RETURNING id
        INTO l_family_member_id2;
      UPDATE sickdoc.sickdoc_extended
      SET family_member_2_id = l_family_member_id2
      WHERE id = p_sikdoc_extended_id;
    END IF;

  END IF;
END;
$$;

