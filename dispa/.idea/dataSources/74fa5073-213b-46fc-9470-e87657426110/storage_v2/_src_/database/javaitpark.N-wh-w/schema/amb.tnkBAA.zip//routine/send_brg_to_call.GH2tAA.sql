CREATE FUNCTION send_brg_to_call(xcall integer, xtransmit_state integer, xbrg_id integer, xreg integer, xuser integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
                xcaller_reason_id integer;
                xpatient_id integer;
                xstation_id integer;
                xcall_reason_id integer;
                xreason_accident_id integer;

                xdate timestamp without time zone;
                xstate integer;
                xcall_number integer;
                xcall_address varchar(500);
                xcall_kind integer;
                xcall_prior integer;
                xcall_dt timestamp without time zone;

                -- для случая
                xcase integer;
                xfunding integer;
                xcase_type integer;
                xcare_regimen integer;
                xcare_level integer;
                xcare_providing_form integer;
                xinit_goal integer;
                xinit_type integer;
                xadmission_type integer;
                xpayment_method integer;

              begin
                xdate := now();
                -- повод, пациент, станция
                select into xcall_kind, xcall_number,xcaller_reason_id,xcall_address,xpatient_id,xstation_id,xcall_prior,xcall_dt
                    call_kind_id,call_number,caller_reason_id,coalesce(adr__get_element_as_text(address_id,'(6,s,0)(7,s,0)(8,s,0)'),description),patient_id,station_id,priority_id,from_time
                from amb.md_ambulance_call where id = xcall;
                --причина вызова, причина несчастного случая
                if xcall_kind not in (3,4)
                    then
                        select into xcall_reason_id,xreason_accident_id call_reason_id,reason_accident_id
                            from amb.md_ambulance_caller_reason where id = xcaller_reason_id;
                    else
                        xcall_reason_id = case when xcall_kind = 3 then 7 else 6 end;
                end if;
                -- Случай
                xcare_providing_form = (select id from md_care_providing_form  where e_code =
                        case when xcall_kind in (4,6) then '3' else case when xcall_prior in (1,2) then '1' else '2' end end);
                xinit_type = (select id from mc_case_init_type where e_code =
                        case when xcall_kind in (3,4,6) then '2' else '1' end);
                xfunding = (select id from fin_funding_source_type where e_code = 'OMS');
                if not exists (select id from amb.md_ambulance_call_result where id = xcall)
                then
                    -- создаем "Случай"
                    xcase_type = (select id from mc_case_type where e_code = '7');
                    xcare_regimen = (select id from mc_care_regimen where e_code = '6');
                    xcare_level = (select id from mc_care_level where e_code = '21');
                    xinit_goal = (select id from mc_case_init_goal where e_code = '03');
                    xadmission_type = (select id from mc_admission_type where e_code = '2');
                    xpayment_method = (select id from mc_payment_method where code='15');  -- системный справочник, в эталоне не заполнено e_code

                    xcase = nextval('mc_case_seq');
                    insert into mc_case(id,case_type_id,care_regimen_id,uid,care_level_id,care_providing_form_id,init_goal_id,init_type_id,admission_type_id,funding_id
                        ,open_date,create_date,clinic_id, patient_id,payment_method_id)
                    values(xcase,xcase_type,xcare_regimen,xcall_number,xcare_level,xcare_providing_form,xinit_goal,xinit_type,xadmission_type,xfunding
                        ,cast(xcall_dt as date),cast(xdate as date),xstation_id,xpatient_id,xpayment_method);

                    -- записываем данные в "Результат вызова"
                    insert into amb.md_ambulance_call_result (id,case_id,transmit_state_id,call_reason_id,reason_accident_id,registrator_id)
                        values (xcall,xcase,xtransmit_state,xcall_reason_id,xreason_accident_id,xreg);
                else
                    -- на случай если был отменен посыл и т.п.
                    update mc_case set care_providing_form_id =xcare_providing_form,init_type_id = xinit_type
                        ,create_date = xdate,clinic_id = xstation_id, patient_id = xpatient_id
                        where id = (select case_id from amb.md_ambulance_call_result where id = xcall);
                    update amb.md_ambulance_call_result set transmit_state_id = xtransmit_state,call_reason_id = xcall_reason_id,reason_accident_id = xreason_accident_id,registrator_id = xreg
                        where id = xcall;
                end if;

                -- запись информации по спец бригаде в результат
                if (xcall_kind = 5)
                        then
                            update amb.md_ambulance_call_result set receive_brg = xbrg_id where id = (select call_on_base_id from amb.md_ambulance_call_on_base where id =xcall);
                    end if;

                update amb.md_ambulance_call set brg_id = xbrg_id where id = xcall;

                -- при записи в историю состояний возможно использовать прямую вставку
                /*
                insert into amb.md_ambcall_state_history (id,call_id,date_time,state_id,transmit_id,registrator_id)
                    VALUES(nextval('amb.md_ambcall_state_history_id_seq'),xcall,xdate,4,1,xreg);
                insert into amb.md_ambcall_state_history (id,call_id,date_time,state_id,transmit_id,registrator_id)
                    VALUES(nextval('amb.md_ambcall_state_history_id_seq'),xcall,xdate,15,xtransmit_state,xreg);
                insert into amb.md_ambcall_state_history (id,call_id,date_time,state_id,transmit_id,registrator_id)
                    VALUES(nextval('amb.md_ambcall_state_history_id_seq'),xcall,xdate,5,xtransmit_state,xreg);
                */

                -- состояние вызова - "Назначена бригада"
                xstate :=  amb.add_ambcall_state_hist (xcall,xdate,4,1,xreg);
                -- состояние вызова - "Вызов передан бригаде"
                xstate :=  amb.add_ambcall_state_hist (xcall,xdate + '1 second',15,xtransmit_state,xreg);
                -- состояние вызова - "Вызов принят бригадой"
                xstate :=  amb.add_ambcall_state_hist (xcall,xdate + '2 second',5,xtransmit_state,xreg);
                -- состояние бригады - "На вызове"

                execute amb.add_team_job_status_hist (xbrg_id,xdate + '3 second',2,xreg,CAST(xcall_number as varchar(10))||'/'||xcall_address,xuser);
                /*insert into amb.sr_res_team_job_status_history (team_job_id,date_time,job_status_id,registrator_id,note)
                    VALUES(xbrg_id,xdate,2,xreg,CAST(xcall_number as varchar(10))||'/'||xcall_address);
                  */
                -- запись в историю диспетчерезации - "бригада"
                xstate := amb.add_ambcall_route_hist (xcall,xdate + '4 second',null,null,null,xbrg_id,xreg);
               /* insert into amb.md_ambcall_route_history (id,call_id,date_time,station_id,route_id,substation_id,brg_id,registrator_id)
                    VALUES(nextval('amb.md_ambcall_route_history_id_seq'),xcall,xdate,null,null,null,xbrg_id,xreg);*/
              end;
$$;

