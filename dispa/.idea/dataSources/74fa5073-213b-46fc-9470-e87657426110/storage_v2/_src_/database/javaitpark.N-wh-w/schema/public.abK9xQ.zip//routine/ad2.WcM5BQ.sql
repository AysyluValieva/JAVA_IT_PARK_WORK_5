CREATE FUNCTION ad2(p_tab name)
  RETURNS text
LANGUAGE plpgsql
AS $$
declare
-- <rules>
c_r_last	constant int := 1;
c_r_rand	constant int := 2;
c_r_new		constant int := 3;
-- </rules>
c_len 		constant int := 10;	-- default string value length
v_id text := null;
col record;
con record;
coldef pg_attrdef.adbin%type;
v_val text;	-- todo: rename to expr
v_pk_name pg_attribute.attname%type;
v_is_first boolean := true;
v_cols 	text := '';
v_vals 	text := '';
v_frel	pg_class.relname%type;
v_fatt	pg_attribute.attname%type;
v_r		constant int := c_r_rand;
v_q 	text := '';
v_len	int;	-- actual length
v_fk 	record;
v_is_pk boolean;
v_is_fk boolean;
loid oid = -1;
v_foo int;
-- todo: determine result for PKs with default values
begin
for col in 
	select a.attname, a.atttypid, t.typname, a.attnotnull, a.atthasdef, attrelid, attnum, t.typtype, t.typcategory, a.attlen
	from pg_attribute a, pg_class c, pg_namespace n, pg_type t
	where attnum > 0 and c.relnamespace = n.oid and n.nspname = current_schema and c.oid = a.attrelid and c.relname = lower(p_tab) and t.oid = a.atttypid loop
	v_val := null; v_fk := null; v_is_pk := false; v_is_fk := false;
   if col.attlen = -1 and col.typname = 'bpchar' then -- todo: precise
      v_len := 1; 
   else
      v_len := case (col.attlen > c_len or col.attlen = -1) when true then c_len else col.attlen end;
   end if;
	-- raise notice '% % %', col.attnum, col.attname, col.typname;
	-- default value
	for con in select confrelid, conkey, confkey, contype from pg_constraint where conrelid = col.attrelid and col.attnum = conkey[1] loop
		case con.contype	
			when 'f' then v_fk := con; v_is_fk := true;
			when 'p' then v_is_pk := true;
			when 'u' then v_val := null;	-- todo
         else v_val := null;
		end case;
	end loop;
	if v_is_pk then
		v_pk_name := col.attname; 
	end if;
	select adbin into coldef from pg_attrdef where adrelid = col.attrelid and adnum = col.attnum;
	if found and not v_is_fk then
		v_val := pg_get_expr(coldef, col.attrelid);
	else
		con := null;
		-- raise notice '% %', v_is_pk, v_is_fk;
		if v_is_fk then
			if v_fk.confrelid = col.attrelid then continue;	-- exclude self-references
			else
				select relname into v_frel from pg_class where oid = v_fk.confrelid;
				select attname into v_fatt from pg_attribute where attrelid = v_fk.confrelid and attnum = v_fk.confkey[1];
				-- raise notice '%.%', v_frel, v_fatt;
				if not v_is_pk then
					case v_r
						when c_r_new then if lower(p_tab) <> lower(v_frel) then v_val := ad2(v_frel); end if;
						when c_r_last then execute 'select max('||v_fatt||') from '||v_frel into v_val;
						when c_r_rand then execute 'select '||v_fatt||' from '||v_frel||'  order by random() limit 1' into v_val;
					end case;
				end if;
				if v_val is null and lower(p_tab) <> lower(v_frel) then v_val := ad2(v_frel); end if;
			end if;
		elsif v_is_pk then
			if v_val is null then
				-- try to find sequence
				select 'select nextval('''||relname||''')' into v_val from pg_class where relkind = 'S' and relname = lower(p_tab||'_seq');
				if found then
					execute v_val into v_id;
				else
					if col.typcategory = 'N' then
						execute 'select coalesce((select max('||col.attname||') from '||p_tab||'), 0) + 1' into v_id;
					else
						execute 'select max('||col.attname||') from '||p_tab into v_id;
					end if;
				end if;
				v_val := v_id;
			end if;
		end if;
		if v_val is null then
			case col.typname
				when 'character varying', 'text', 'bpchar' then v_val := gen_rnd(v_len, true);
				when 'date' then v_val := 'current_date - gen_rnd(3, false)::int';
				when 'time', 'time without time zone' then v_val := 'current_time';
				when 'timestamp without time zone', 'timestamp', 'timestamptz' then v_val := 'clock_timestamp() - gen_rnd(9, false)::interval';
				when 'boolean', 'bool' then v_val := 'gen_rnd(1, false)::int % 2 = 0';
				when 'integer' then v_val := gen_rnd(3, false)::int;
				when 'numeric' then v_val := gen_rnd(3, false)||'.'||gen_rnd(1, false);
            when 'bytea' then v_val := gen_rnd(10, true);
            when 'oid' then 
               loid := lo_create(gen_rnd(9, false)::oid);
               select lowrite(lo_open(loid, x'00020000'::int), gen_rnd(10, true)::bytea) into v_foo;
               v_val := loid;
				else 
				case col.typcategory
					when 'S' then v_val := gen_rnd(v_len, true);
					when 'B' then v_val := 'true';
					when 'N' then v_val := '1';
					else v_val := null;
				end case;
			end case;
		end if;
		if v_val is null then
			raise notice 'ty=%', col.typname;
		elsif col.typcategory = 'S' or col.typname in ('bytea') then
			v_val := ''''||v_val||'''';
		end if;
	end if;
	-- raise notice '%=%', col.attname, v_val;
	v_vals := v_vals||(case v_is_first when true then '' else ',' end)||coalesce(v_val, 'null');
	v_cols := v_cols||(case v_is_first when true then '' else ',' end)||(case col.attname = upper(col.attname) when true then '"'||col.attname||'"' else col.attname end);
	if v_is_first then v_is_first := false; end if;
end loop;
v_q := 'insert into '||p_tab||'('||v_cols||') values ('||v_vals||')';
execute v_q;
-- raise notice 'q=%', v_q;
-- raise notice 'id=% pk=%', v_id, v_pk_name;
if v_id is null and v_pk_name is not null then
	execute 'select max('||v_pk_name||') from '||p_tab into v_id;
end if;
return v_id;
exception when others then 
	raise notice 'tab=%; %:%', p_tab,sqlstate, sqlerrm;
	raise notice 'q=%', v_q;
	return -1;
end;
$$;

