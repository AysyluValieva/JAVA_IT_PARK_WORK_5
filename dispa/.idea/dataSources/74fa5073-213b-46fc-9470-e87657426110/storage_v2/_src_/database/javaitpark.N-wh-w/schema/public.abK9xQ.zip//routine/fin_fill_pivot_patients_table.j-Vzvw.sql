CREATE FUNCTION fin_fill_pivot_patients_table(p1_bill_id integer)
  RETURNS void
STRICT
LANGUAGE plpgsql
AS $$
DECLARE
    _code_snils_ind_id INTEGER;
BEGIN
    /*
        current version date 2014-12-11
    */
    IF EXISTS (SELECT 1 FROM fin_bill_patients WHERE bill_id = p1_bill_id) THEN DELETE FROM fin_bill_patients WHERE bill_id = p1_bill_id; END IF;
    
    _code_snils_ind_id := (SELECT id FROM pim_code_type WHERE code = 'SNILS');
    
    INSERT INTO fin_bill_patients 
    (
        bill_id, from_date, to_date, id_pac, patient_id, representative_id, new_born, item_id_arr
    )
        SELECT
            bill_id, from_date, to_date, id_pac, patient_id, representative_id, new_born, array_agg (fin_bill_spec_item_id)
        FROM 
            fin_bill_generate
        WHERE 
            bill_id = p1_bill_id AND NOT is_sifted
        GROUP BY 1, 2, 3, 4, 5, 6, 7
    ;
    --основная информация о пациенте
    WITH patient AS 
    (
        SELECT 
            f.bill_id,
            f.patient_id,
            initcap (coalesce (trim (i.name), '')) AS name,
            initcap (coalesce (trim (i.surname), '')) AS surname,
            initcap (coalesce (trim (i.patr_name), '')) AS patr_name,
            i.birth_dt, 
            coalesce (trim (g.code), '') AS gender_code,
            concat (i.gender_id, to_char (i.birth_dt, 'DDMMYY'), coalesce (a.newborn_number, 1)::VARCHAR(2)) AS new_born_part,
            a.birthweight,
            s.code AS social_status,
            array_agg (coalesce (trim (p.ui_code), '')) AS os_sluch
        FROM
            fin_bill_patients               AS f
            JOIN pim_individual             AS i ON i.id = f.patient_id
            LEFT JOIN pim_gender            AS g ON g.id = i.gender_id
            LEFT JOIN pci_patient           AS a ON a.id = i.id
            LEFT JOIN md_soc_group          AS s ON s.id = a.social_group_id
            LEFT JOIN pci_patient_part_case AS c ON c.patient_id = a.id AND (f.from_date, f.to_date) OVERLAPS (coalesce (c.from_dt, '1900-01-01'), coalesce (c.to_dt, '4000-01-01'))
            LEFT JOIN pci_part_case         AS p ON p.id = c.part_case_id 
        WHERE
            f.bill_id = p1_bill_id 
        GROUP BY 1, 2, 3, 4, 5, 6, 7, 8, 9, 10
    )
    UPDATE fin_bill_patients AS f
    SET
        new_born_part     = t.new_born_part,
        pat_name          = t.name         ,
        pat_surname       = t.surname      ,
        pat_patr_name     = t.patr_name    ,
        pat_birth_dt      = t.birth_dt     ,
        pat_gender_code   = t.gender_code  ,
        pat_birthweight   = t.birthweight  ,
        pat_social_status = t.social_status,
        pat_os_sluch      = t.os_sluch
    FROM 
        patient AS t
    WHERE
        f.bill_id = t.bill_id AND f.patient_id = t.patient_id
    ;
    --обновление информации о фамилии, имени и отчестве пациента из паспорта, если такая есть
    WITH 
    passports AS 
    (
        SELECT 
            f.bill_id,
            f.patient_id,
            (array_agg (i.id ORDER BY i.is_active DESC, i.issue_dt DESC NULLS LAST, i.expire_dt DESC, i.verific_dt DESC NULLS LAST, i.check_dt DESC NULLS LAST))[1] AS id
        FROM
            fin_bill_patients       AS f
            JOIN pim_individual_doc AS i ON i.indiv_id = f.patient_id
            JOIN pim_doc_type       AS t ON t.id = i.type_id AND t.code = 'PASSPORT_RUSSIAN_FEDERATION'
        WHERE
            f.bill_id = p1_bill_id AND f.to_date BETWEEN coalesce (i.issue_dt, '1900-01-01') AND coalesce (i.expire_dt, '4000-01-01')
        GROUP BY 1, 2
    ),
    t AS 
    (
        SELECT
            p.bill_id,
            p.patient_id,
            initcap (trim (i.name)) AS name,
            initcap (trim (i.surname)) AS surname,
            initcap (trim (i.patr_name)) AS patr_name
        FROM
            passports               AS p
            JOIN pim_individual_doc AS i ON i.id = p.id
        WHERE
            (nullif (trim (i.name), '') || nullif (trim (i.surname), '') || nullif (trim (i.patr_name), '')) IS NOT NULL
    )
    UPDATE fin_bill_patients AS f
    SET
        pat_name      = t.name     ,
        pat_surname   = t.surname  ,
        pat_patr_name = t.patr_name 
    FROM t
    WHERE
        f.bill_id = t.bill_id AND f.patient_id = t.patient_id
    ;
    --документ пациента, удостоверяющий личность; адрес места рождения (текст)
    WITH 
    docs AS 
    (
        SELECT
            f.bill_id,
            f.patient_id,
            (
                array_agg 
                (
                    i.id 
                    ORDER BY t.priority, i.is_active DESC, i.issue_dt DESC NULLS LAST, i.expire_dt DESC, i.verific_dt DESC NULLS LAST, i.check_dt DESC NULLS LAST
                )
            )[1] AS id
        FROM
            fin_bill_patients          AS f
            JOIN pim_individual_doc    AS i ON i.indiv_id = f.patient_id
            JOIN pim_doc_type          AS t ON t.id = i.type_id
            JOIN pim_doc_type_category AS c ON c.type_id = t.id 
        WHERE
            f.bill_id = p1_bill_id AND c.category_id = 1 AND f.to_date BETWEEN coalesce (i.issue_dt, '1900-01-01') AND coalesce (i.expire_dt, '4000-01-01')
        GROUP BY 1, 2
    ),
    t AS 
    (
        SELECT
            d.bill_id,
            d.patient_id,
            i.type_id AS identity_doc_type,
            coalesce (trim (upper (i.series)), '') AS identity_doc_series,
            coalesce (trim (upper (i.number)), '') AS identity_doc_number,
            left (coalesce (trim (i.birth_place), ''), 100) AS birth_place
        FROM
            docs                    AS d
            JOIN pim_individual_doc AS i ON i.id = d.id
    )
    UPDATE fin_bill_patients AS f
    SET
        pat_identity_type   = t.identity_doc_type  ,
        pat_identity_series = t.identity_doc_series,
        pat_identity_number = t.identity_doc_number,
        pat_birth_addr_text = t.birth_place
    FROM t
    WHERE
        f.bill_id = t.bill_id AND f.patient_id = t.patient_id
    ;
    --снилс пациента
    WITH t AS 
    (
        SELECT 
            f.bill_id,
            f.patient_id,
            coalesce 
            (
                regexp_replace 
                (
                    replace (replace ((array_agg (coalesce (trim (i.code), '') ORDER BY i.issue_dt DESC NULLS LAST))[1], '-', ''), ' ', ''), 
                    '(...)(...)(...)(..)', 
                    '\1-\2-\3 \4'
                ), ''
            ) AS code
        FROM 
            fin_bill_patients        AS f
            LEFT JOIN pim_indiv_code AS i ON i.indiv_id = f.patient_id AND i.type_id = _code_snils_ind_id
        WHERE
            f.bill_id = p1_bill_id
        GROUP BY 1, 2
    )
    UPDATE fin_bill_patients AS f
    SET
        pat_snils = t.code
    FROM t
    WHERE
        f.bill_id = t.bill_id AND f.patient_id = t.patient_id
    ;
    ----адреса пациента
    --адрес места жительства
    WITH t AS 
    (
        SELECT 
            f.bill_id, 
            f.patient_id, 
            (array_agg (a.addr_id ORDER BY a.register_type_id = 1 DESC NULLS LAST, /*a.from_date DESC NULLS LAST, a.to_date DESC,*/ a.is_valid DESC NULLS LAST, a.id DESC))[1] AS id
        FROM
            fin_bill_patients                AS f
            JOIN pim_party_address           AS a ON a.party_id = f.patient_id 
            JOIN pim_party_addr_to_addr_type AS s ON s.party_address_id = a.id
            JOIN pim_address_type            AS t ON t.id = s.address_type_id 
        WHERE
            f.bill_id = p1_bill_id AND t.code = 'REGISTER' --AND (f.from_date, f.to_date) OVERLAPS (coalesce (a.from_date, '1900-01-01'), coalesce (a.to_date, '4000-01-01'))
        GROUP BY 1, 2
    )
    UPDATE fin_bill_patients AS f
    SET
        pat_reg_addr_id = t.id
    FROM t
    WHERE
        f.bill_id = t.bill_id AND f.patient_id = t.patient_id
    ;
    --адрес места пребывания
    WITH t AS 
    (
        SELECT 
            f.bill_id, 
            f.patient_id, 
            (array_agg (a.addr_id ORDER BY a.register_type_id = 1 DESC NULLS LAST, /*a.from_date DESC NULLS LAST, a.to_date DESC,*/ a.is_valid DESC NULLS LAST, a.id DESC))[1] AS id
        FROM
            fin_bill_patients                AS f
            JOIN pim_party_address           AS a ON a.party_id = f.patient_id 
            JOIN pim_party_addr_to_addr_type AS s ON s.party_address_id = a.id
            JOIN pim_address_type            AS t ON t.id = s.address_type_id 
        WHERE
            f.bill_id = p1_bill_id AND t.code = 'ACTUAL' --AND (f.from_date, f.to_date) OVERLAPS (coalesce (a.from_date, '1900-01-01'), coalesce (a.to_date, '4000-01-01'))
        GROUP BY 1, 2
    )
    UPDATE fin_bill_patients AS f
    SET
        pat_fact_addr_id = t.id
    FROM t
    WHERE
        f.bill_id = t.bill_id AND f.patient_id = t.patient_id
    ;
    --адрес места рождения
    WITH t AS 
    (
        SELECT 
            f.bill_id, 
            f.patient_id, 
            (array_agg (a.addr_id ORDER BY a.register_type_id = 1 DESC NULLS LAST, /*a.from_date DESC NULLS LAST, a.to_date DESC,*/ a.is_valid DESC NULLS LAST, a.id DESC))[1] AS id
        FROM
            fin_bill_patients                AS f
            JOIN pim_party_address           AS a ON a.party_id = f.patient_id 
            JOIN pim_party_addr_to_addr_type AS s ON s.party_address_id = a.id
            JOIN pim_address_type            AS t ON t.id = s.address_type_id 
        WHERE
            f.bill_id = p1_bill_id AND t.code = 'BIRTH' --AND (f.from_date, f.to_date) OVERLAPS (coalesce (a.from_date, '1900-01-01'), coalesce (a.to_date, '4000-01-01'))
        GROUP BY 1, 2
    )
    UPDATE fin_bill_patients AS f
    SET
        pat_birth_addr_id = t.id
    FROM t
    WHERE
        f.bill_id = t.bill_id AND f.patient_id = t.patient_id
    ;
    --основная информация о представителе
    WITH representative AS 
    (
        SELECT 
            f.bill_id,
            f.id_pac,
            initcap (coalesce (trim (i.name), '')) AS name,
            initcap (coalesce (trim (i.surname), '')) AS surname,
            initcap (coalesce (trim (i.patr_name), '')) AS patr_name,
            i.birth_dt, 
            coalesce (trim (g.code), '') AS gender_code,
            'В документе, удостоверяющем личность, отсутствует отчество' = ANY (array_agg (p.name)) AS no_patr_name,
            array_agg (coalesce (trim (p.ui_code), '')) AS os_sluch
        FROM
            fin_bill_patients               AS f
            JOIN pim_individual             AS i ON i.id = f.representative_id
            LEFT JOIN pim_gender            AS g ON g.id = i.gender_id
            LEFT JOIN pci_patient           AS a ON a.id = i.id
            LEFT JOIN pci_patient_part_case AS c ON c.patient_id = a.id AND (f.from_date, f.to_date) OVERLAPS (coalesce (c.from_dt, '1900-01-01'), coalesce (c.to_dt, '4000-01-01'))
            LEFT JOIN pci_part_case         AS p ON p.id = c.part_case_id 
        WHERE
            f.bill_id = p1_bill_id 
        GROUP BY 1, 2, 3, 4, 5, 6, 7
    )
    UPDATE fin_bill_patients AS f
    SET
        rep_name         = t.name        ,
        rep_surname      = t.surname     ,
        rep_patr_name    = t.patr_name   ,
        rep_birth_dt     = t.birth_dt    ,
        rep_gender_code  = t.gender_code ,
        rep_no_patr_name = t.no_patr_name,
        rep_os_sluch     = t.os_sluch
    FROM 
        representative AS t
    WHERE
        f.bill_id = t.bill_id AND f.id_pac = t.id_pac
    ;
    --обновление информации о фамилии, имени и отчестве представителя из паспорта, если такая есть
    WITH 
    passports AS 
    (
        SELECT 
            f.bill_id,
            f.id_pac,
            (array_agg (i.id ORDER BY i.is_active DESC, i.issue_dt DESC NULLS LAST, i.expire_dt DESC, i.verific_dt DESC NULLS LAST, i.check_dt DESC NULLS LAST))[1] AS id
        FROM
            fin_bill_patients       AS f
            JOIN pim_individual_doc AS i ON i.indiv_id = f.representative_id
            JOIN pim_doc_type       AS t ON t.id = i.type_id AND t.code = 'PASSPORT_RUSSIAN_FEDERATION'
        WHERE
            f.bill_id = p1_bill_id AND f.to_date BETWEEN coalesce (i.issue_dt, '1900-01-01') AND coalesce (i.expire_dt, '4000-01-01')
        GROUP BY 1, 2
    ),
    t AS 
    (
        SELECT
            p.bill_id,
            p.id_pac,
            initcap (trim (i.name)) AS name,
            initcap (trim (i.surname)) AS surname,
            initcap (trim (i.patr_name)) AS patr_name
        FROM
            passports               AS p
            JOIN pim_individual_doc AS i ON i.id = p.id
        WHERE
            (nullif (trim (i.name), '') || nullif (trim (i.surname), '') || nullif (trim (i.patr_name), '')) IS NOT NULL
    )
    UPDATE fin_bill_patients AS f
    SET
        rep_name      = t.name     ,
        rep_surname   = t.surname  ,
        rep_patr_name = t.patr_name 
    FROM t
    WHERE
        f.bill_id = t.bill_id AND f.id_pac = t.id_pac
    ;
    --документ представителя, удостоверяющий личность; адрес места рождения (текст)
    WITH 
    docs AS 
    (
        SELECT
            f.bill_id,
            f.id_pac,
            (
                array_agg 
                (
                    i.id 
                    ORDER BY t.priority, i.is_active DESC, i.issue_dt DESC NULLS LAST, i.expire_dt DESC, i.verific_dt DESC NULLS LAST, i.check_dt DESC NULLS LAST
                )
            )[1] AS id
        FROM
            fin_bill_patients          AS f
            JOIN pim_individual_doc    AS i ON i.indiv_id = f.representative_id
            JOIN pim_doc_type          AS t ON t.id = i.type_id
            JOIN pim_doc_type_category AS c ON c.type_id = t.id 
        WHERE
            f.bill_id = p1_bill_id AND c.category_id = 1 AND f.to_date BETWEEN coalesce (i.issue_dt, '1900-01-01') AND coalesce (i.expire_dt, '4000-01-01')
        GROUP BY 1, 2
    ),
    t AS 
    (
        SELECT
            d.bill_id,
            d.id_pac,
            i.type_id AS identity_doc_type,
            coalesce (trim (upper (i.series)), '') AS identity_doc_series,
            coalesce (trim (upper (i.number)), '') AS identity_doc_number,
            left (coalesce (trim (i.birth_place), ''), 100) AS birth_place
        FROM
            docs                    AS d
            JOIN pim_individual_doc AS i ON i.id = d.id
    )
    UPDATE fin_bill_patients AS f
    SET
        rep_identity_type   = t.identity_doc_type  ,
        rep_identity_series = t.identity_doc_series,
        rep_identity_number = t.identity_doc_number,
        rep_birth_addr_text = t.birth_place
    FROM t
    WHERE
        f.bill_id = t.bill_id AND f.id_pac = t.id_pac
    ;
    --снилс представителя
    WITH t AS 
    (
        SELECT 
            f.bill_id,
            f.id_pac,
            coalesce 
            (
                regexp_replace 
                (
                    replace (replace ((array_agg (coalesce (trim (i.code), '') ORDER BY i.issue_dt DESC NULLS LAST))[1], '-', ''), ' ', ''), 
                    '(...)(...)(...)(..)', 
                    '\1-\2-\3 \4'
                ), ''
            ) AS code
        FROM 
            fin_bill_patients        AS f
            LEFT JOIN pim_indiv_code AS i ON i.indiv_id = f.representative_id AND i.type_id = _code_snils_ind_id 
        WHERE
           f.bill_id = p1_bill_id
        GROUP BY 1, 2
    )
    UPDATE fin_bill_patients AS f
    SET
        rep_snils = t.code
    FROM t
    WHERE
        f.bill_id = t.bill_id AND f.id_pac = t.id_pac
    ;
    ----адреса представителя
    --адрес места жительства
    WITH t AS 
    (
        SELECT 
            f.bill_id, 
            f.id_pac, 
            (array_agg (a.addr_id ORDER BY a.register_type_id = 1 DESC NULLS LAST, /*a.from_date DESC NULLS LAST, a.to_date DESC,*/ a.is_valid DESC NULLS LAST, a.id DESC))[1] AS id
        FROM
            fin_bill_patients                AS f
            JOIN pim_party_address           AS a ON a.party_id = f.representative_id 
            JOIN pim_party_addr_to_addr_type AS s ON s.party_address_id = a.id
            JOIN pim_address_type            AS t ON t.id = s.address_type_id 
        WHERE
            f.bill_id = p1_bill_id AND t.code = 'REGISTER' --AND (f.from_date, f.to_date) OVERLAPS (coalesce (a.from_date, '1900-01-01'), coalesce (a.to_date, '4000-01-01'))
        GROUP BY 1, 2
    )
    UPDATE fin_bill_patients AS f
    SET
        rep_reg_addr_id = t.id
    FROM t
    WHERE
        f.bill_id = t.bill_id AND f.id_pac = t.id_pac
    ;
    --адрес места пребывания
    WITH t AS 
    (
        SELECT 
            f.bill_id, 
            f.id_pac, 
            (array_agg (a.addr_id ORDER BY a.register_type_id = 1 DESC NULLS LAST, /*a.from_date DESC NULLS LAST, a.to_date DESC,*/ a.is_valid DESC NULLS LAST, a.id DESC))[1] AS id
        FROM
            fin_bill_patients                AS f
            JOIN pim_party_address           AS a ON a.party_id = f.representative_id 
            JOIN pim_party_addr_to_addr_type AS s ON s.party_address_id = a.id
            JOIN pim_address_type            AS t ON t.id = s.address_type_id 
        WHERE
            f.bill_id = p1_bill_id AND t.code = 'ACTUAL' --AND (f.from_date, f.to_date) OVERLAPS (coalesce (a.from_date, '1900-01-01'), coalesce (a.to_date, '4000-01-01'))
        GROUP BY 1, 2
    )
    UPDATE fin_bill_patients AS f
    SET
        rep_fact_addr_id = t.id
    FROM t
    WHERE
        f.bill_id = t.bill_id AND f.id_pac = t.id_pac
    ;
    --адрес места рождения
    WITH t AS 
    (
        SELECT 
            f.bill_id, 
            f.id_pac, 
            (array_agg (a.addr_id ORDER BY a.register_type_id = 1 DESC NULLS LAST, /*a.from_date DESC NULLS LAST, a.to_date DESC,*/ a.is_valid DESC NULLS LAST, a.id DESC))[1] AS id
        FROM
            fin_bill_patients                AS f
            JOIN pim_party_address           AS a ON a.party_id = f.representative_id 
            JOIN pim_party_addr_to_addr_type AS s ON s.party_address_id = a.id
            JOIN pim_address_type            AS t ON t.id = s.address_type_id 
        WHERE
            f.bill_id = p1_bill_id AND t.code = 'BIRTH' --AND (f.from_date, f.to_date) OVERLAPS (coalesce (a.from_date, '1900-01-01'), coalesce (a.to_date, '4000-01-01'))
        GROUP BY 1, 2
    )
    UPDATE fin_bill_patients AS f
    SET
        rep_birth_addr_id = t.id
    FROM t
    WHERE
        f.bill_id = t.bill_id AND f.id_pac = t.id_pac
    ;
    ----окато для адресов
    UPDATE fin_bill_patients
    SET
        pat_reg_addr_okato   = address__get_nearest_okato (pat_reg_addr_id)  ,
        pat_fact_addr_okato  = address__get_nearest_okato (pat_fact_addr_id) ,
        pat_birth_addr_okato = address__get_nearest_okato (pat_birth_addr_id),
        rep_reg_addr_okato   = address__get_nearest_okato (rep_reg_addr_id)  ,
        rep_fact_addr_okato  = address__get_nearest_okato (rep_fact_addr_id)
    WHERE
        bill_id = p1_bill_id
    ;
END;
$$;

