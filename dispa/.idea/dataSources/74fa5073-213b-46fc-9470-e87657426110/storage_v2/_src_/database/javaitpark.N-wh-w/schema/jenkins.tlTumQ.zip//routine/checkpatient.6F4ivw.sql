CREATE FUNCTION checkpatient(p_arianumber text DEFAULT NULL::integer, p_birthday date DEFAULT NULL::date, p_cellphone text DEFAULT NULL::text, p_document_n text DEFAULT NULL::text, p_document_s text DEFAULT NULL::text, p_homephone text DEFAULT NULL::text, p_idpat text DEFAULT NULL::text, p_name text DEFAULT NULL::text, p_polis_n text DEFAULT NULL::text, p_polis_s text DEFAULT NULL::text, p_secondname text DEFAULT NULL::text, p_surname text DEFAULT NULL::text, _department_id text DEFAULT NULL::text)
  RETURNS TABLE(idpat integer)
LANGUAGE plpgsql
AS $$
BEGIN
 

return query ( select * from "jenkins"."checkpatient_v3"( "p_arianumber" ,  "p_birthday",  "p_cellphone",  "p_document_n",  "p_document_s",  "p_homephone",  "p_idpat" ,  "p_name",  "p_polis_n" ,  "p_polis_s" ,  "p_secondname" ,  "p_surname",  "_department_id") );

 
 
END;
$$;

