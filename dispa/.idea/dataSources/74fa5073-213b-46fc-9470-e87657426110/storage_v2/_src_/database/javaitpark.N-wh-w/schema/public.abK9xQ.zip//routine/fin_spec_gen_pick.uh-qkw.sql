CREATE FUNCTION fin_spec_gen_pick(p1_bill_id integer, p2_status text)
  RETURNS void
STRICT
LANGUAGE plpgsql
AS $$
DECLARE 
    _main_bill_id INTEGER := fin_bill__get_main_bill (p1_bill_id);
    _clinic_id INTEGER;
    _from_dt DATE;
    _to_dt DATE;
    _price_list_id INTEGER;
    _case_type_id INTEGER;
    _payment_method_arr INTEGER[];
    _care_regimen_arr INTEGER[];
    _case_init_goal_arr INTEGER[];
    _type_id INTEGER;
    _status TEXT;
    _case_type_arr INTEGER[];
    _care_level_arr INTEGER[];
BEGIN
    /*
        version: 2015-02-16
    */
    ---------------------------------------------изменение статуса для исправительных счетов---------------------------------------------------------
    _status := CASE WHEN p2_status = 'VALIDATE' AND EXISTS (SELECT 1 FROM fin_bill_correctional WHERE id = p1_bill_id) THEN 'VALIDATE_CORRECT' ELSE p2_status END
    ;
    --------------------------------------------------очистка от предыдущего формирования------------------------------------------------------------
    IF 
        _status IN ('VALIDATE', 'VALIDATE_CORRECT', 'RECALCULATE')
    THEN
        WITH t AS 
        (
            SELECT 
                s.bill_id, s.spec_item_id AS id 
            FROM 
                fin_bill_steps AS s LEFT JOIN fin_bill_spec_item AS i ON s.spec_item_id = i.id AND s.bill_id = i.bill_id 
            WHERE 
                s.bill_id = p1_bill_id AND i.id IS NULL
        )
        DELETE FROM fin_bill_steps AS s USING t WHERE s.bill_id = t.bill_id AND s.spec_item_id = t.id
        ;
    END IF;
    DELETE FROM fin_bill_generate WHERE bill_id = p1_bill_id
    ;
    DELETE FROM fin_bill_spec_item WHERE bill_id = p1_bill_id
    ;
    ------------------------------------------------------------------параметры----------------------------------------------------------------------
    IF
        _status IN ('CORRECT', 'RECALCULATE', 'VALIDATE_CORRECT')
    THEN
        SELECT 
            from_date, to_date, clinic_id, price_list_id, case_type_id, type_id
            INTO 
            _from_dt, _to_dt, _clinic_id, _price_list_id, _case_type_id, _type_id
        FROM
            fin_bill_main
        WHERE
            id = _main_bill_id
        ;
    ELSIF
        _status IN ('GENERATE', 'VALIDATE')
    THEN
        SELECT 
            coalesce (a.from_date, m.from_date), coalesce (a.to_date, m.to_date), m.clinic_id, m.price_list_id, m.case_type_id, m.type_id
            INTO 
            _from_dt, _to_dt, _clinic_id, _price_list_id, _case_type_id, _type_id
        FROM
            fin_bill_main                 AS m 
            LEFT JOIN fin_bill_additional AS a ON m.id = a.base_id AND a.id = p1_bill_id
        WHERE
            m.id = _main_bill_id
        ;
    END IF;
    -------------------------------------------------режим лечения, способ оплаты, цель посещения----------------------------------------------------
    IF
        _type_id IS NOT NULL
    THEN
        _care_regimen_arr   := nullif (ARRAY (SELECT care_regimen_id   FROM fin_bill_main_type_to_care_regimen   WHERE main_bill_type_id = _type_id), '{}'::INTEGER[]);
        _payment_method_arr := nullif (ARRAY (SELECT payment_method_id FROM fin_bill_main_type_to_payment_method WHERE main_bill_type_id = _type_id), '{}'::INTEGER[]);
        _case_init_goal_arr := nullif (ARRAY (SELECT case_init_goal_id FROM fin_bill_main_type_to_case_init_goal WHERE main_bill_type_id = _type_id), '{}'::INTEGER[]);
        _case_type_arr      := nullif (ARRAY (SELECT case_type_id      FROM fin_bill_main_type_to_case_type      WHERE main_bill_type_id = _type_id), '{}'::INTEGER[]);
        _care_level_arr     := nullif (ARRAY (SELECT care_level_id     FROM fin_bill_main_type_to_care_level     WHERE main_bill_type_id = _type_id), '{}'::INTEGER[]);
    ELSE
        _care_regimen_arr   := nullif (ARRAY (SELECT care_regimen_id   FROM fin_bill_main_to_care_regimen   WHERE main_bill_id = _main_bill_id), '{}'::INTEGER[]);
        _payment_method_arr := nullif (ARRAY (SELECT payment_method_id FROM fin_bill_main_to_payment_method WHERE main_bill_id = _main_bill_id), '{}'::INTEGER[]);
        _case_init_goal_arr := nullif (ARRAY (SELECT case_init_goal_id FROM fin_bill_main_to_case_init_goal WHERE main_bill_id = _main_bill_id), '{}'::INTEGER[]);
    END IF;
    -----------------------------------------------------------первичное добавление------------------------------------------------------------------
    IF
        _status = 'CORRECT'
    THEN
        UPDATE fin_bill_spec_item
        SET 
            correctional_bill_id = p1_bill_id
        WHERE
            bill_id = _main_bill_id AND correctional_bill_id IS NULL AND status_id IN (3, 4)
        ;
        INSERT INTO fin_bill_generate 
        (
            id, bdate, edate, service_id, comment, tooth_number, funding_id, step_id, res_group_id, rdd_diagnosis_id,
            case_id, case_type_id, care_level_id, care_regimen_id, provision_condition_id, init_goal_id, payment_method_id,
            patient_id, closing_step_id, case_open_date, case_close_date,
            org_id, bill_id, price_list_id, from_date, to_date, contract_id
        )
            SELECT
                s.id, s.bdate, s.edate, s.service_id, s.comment, s.tooth_number, coalesce (s.funding_id, c.funding_id, 0), m.step_id, s.res_group_id, m.diagnosis_id,
                c.id, c.case_type_id, c.care_level_id, c.care_regimen_id, c.provision_condition_id, c.init_goal_id, c.payment_method_id,
                c.patient_id, c.closing_step_id, c.open_date, t.outcome_date, 
                coalesce (s.org_id, c.clinic_id), p1_bill_id, _price_list_id, _from_dt, _to_dt, coalesce (s.contract_id, 0)
            FROM
                fin_bill_spec_item   AS i
                JOIN md_srv_rendered AS m ON m.id = i.service_id
                JOIN sr_srv_rendered AS s ON s.id = m.id 
                JOIN mc_case         AS c ON c.id = m.case_id
                JOIN mc_step         AS t ON t.id = c.closing_step_id 
            WHERE
                i.bill_id = _main_bill_id AND i.correctional_bill_id = p1_bill_id
        ;
    ELSIF
        _status IN ('VALIDATE', 'VALIDATE_CORRECT', 'RECALCULATE')
    THEN
        INSERT INTO fin_bill_generate 
        (
            id, bdate, edate, service_id, comment, tooth_number, funding_id, step_id, res_group_id, rdd_diagnosis_id,
            case_id, case_type_id, care_level_id, care_regimen_id, provision_condition_id, init_goal_id, payment_method_id,
            patient_id, closing_step_id, case_open_date, case_close_date,
            org_id, bill_id, price_list_id, from_date, to_date, contract_id
        )
            SELECT
                s.id, s.bdate, s.edate, s.service_id, s.comment, s.tooth_number, coalesce (s.funding_id, c.funding_id, 0), m.step_id, s.res_group_id, m.diagnosis_id,
                c.id, c.case_type_id, c.care_level_id, c.care_regimen_id, c.provision_condition_id, c.init_goal_id, c.payment_method_id,
                c.patient_id, c.closing_step_id, c.open_date, t.outcome_date, 
                coalesce (s.org_id, c.clinic_id), p1_bill_id, _price_list_id, _from_dt, _to_dt, coalesce (s.contract_id, 0)
            FROM
                fin_bill_steps       AS f 
                JOIN md_srv_rendered AS m ON m.id = f.srv_rendered_id 
                JOIN sr_srv_rendered AS s ON s.id = m.id 
                JOIN mc_case         AS c ON c.id = m.case_id 
                JOIN mc_step         AS t ON t.id = c.closing_step_id 
            WHERE
                f.bill_id = p1_bill_id
        ;
    ELSIF
        _status = 'GENERATE'
    THEN
        INSERT INTO fin_bill_generate 
        (
            id, bdate, edate, service_id, comment, tooth_number, funding_id, step_id, res_group_id, rdd_diagnosis_id,
            case_id, case_type_id, care_level_id, care_regimen_id, provision_condition_id, init_goal_id, payment_method_id,
            patient_id, closing_step_id, case_open_date, case_close_date,
            org_id, bill_id, price_list_id, from_date, to_date, contract_id
        )
            SELECT
                s.id, s.bdate, s.edate, s.service_id, s.comment, s.tooth_number, coalesce (s.funding_id, c.funding_id, 0), m.step_id, s.res_group_id, m.diagnosis_id,
                c.id, c.case_type_id, c.care_level_id, c.care_regimen_id, c.provision_condition_id, c.init_goal_id, c.payment_method_id,
                c.patient_id, c.closing_step_id, c.open_date, t.outcome_date, 
                coalesce (s.org_id, c.clinic_id), p1_bill_id, _price_list_id, _from_dt, _to_dt, coalesce (s.contract_id, 0)
            FROM
                mc_case              AS c 
                JOIN mc_step         AS t ON t.id = c.closing_step_id 
                JOIN md_srv_rendered AS m ON m.case_id = c.id 
                JOIN sr_srv_rendered AS s ON m.id = s.id 
            WHERE
                t.outcome_date BETWEEN _from_dt AND _to_dt
                AND c.clinic_id = _clinic_id
                AND NOT EXISTS (SELECT 1 FROM fin_bill_spec_item WHERE service_id = m.id AND bill_id <> p1_bill_id)
                AND CASE WHEN _type_id IS NOT NULL THEN coalesce (c.case_type_id = ANY (_case_type_arr), TRUE) ELSE coalesce (_case_type_id, c.case_type_id) = c.case_type_id END
                AND CASE WHEN _type_id IS NOT NULL THEN coalesce (c.care_level_id = ANY (_care_level_arr), TRUE) ELSE TRUE END
                AND coalesce (c.care_regimen_id = ANY (_care_regimen_arr), TRUE)
                AND coalesce (c.payment_method_id = ANY (_payment_method_arr), TRUE)
                AND coalesce (c.init_goal_id = ANY (_case_init_goal_arr), TRUE)
        ;
    END IF;
EXCEPTION
    WHEN NO_DATA_FOUND THEN RAISE EXCEPTION 'Не заполнены необходимые параметры, либо неправильные данные счёта';
END;
$$;

