CREATE FUNCTION denialsetrequiredserviceforpatient(xtype integer, xcheckservices character varying, xdeniservice character varying, xdeniservice2 character varying, xepid integer)
  RETURNS text
LANGUAGE plpgsql
AS $$
declare
                        serviceRequired integer [];
                        servicePatient integer [];
                        denial integer [];
                        results text [];
                        service integer;
                        checkserviceId json;
                        result  text ;
                        begin

                if (xtype=1)then
                    --обязательные услуги в мероприятие
                    serviceRequired:=(array (select service_id  from disp.md_event_service where event_id=(select event_id from disp.md_event_patient where id=xepid limit 1) and required=true));
                    --услуги на которые уже согласился пациент
                    servicePatient:=(array(select mes.service_id from disp.md_event_service mes left join disp.md_event_service_patient mesp on mesp.service_id=mes.id left join disp.md_event_service_patient_agreement mespa on mespa.service_id=mesp.id  where mespa.agree is true and mesp.event_patient_id=xepid));
                    --если согласие не было,делаем проверку по подходящим по моделям услуги
                    if(servicePatient is null) then
                        foreach checkserviceId in array array(select value from json_array_elements(cast(xcheckservices as json)))
	                        LOOP
		                        if (checkserviceId::text!='null') then
			                        servicePatient:=array_append(servicePatient,checkserviceId::text::int);
		                        end if;

	                        END LOOP;
                    end if;
                    --услуги на отказ
                    if (xdeniservice is not null) then
                        foreach checkserviceId in array array(select value from json_array_elements(cast(xdeniservice as json)))
	                        LOOP
		                        if (checkserviceId::text!='null') then
			                        denial:=array_append(denial,(select service_id from disp.md_event_service where id= checkserviceId::text::int));
		                        end if;
	                        END LOOP;
	                else
                        foreach checkserviceId in array array(select value from json_array_elements(cast(xdeniservice2 as json)))
	                        LOOP
		                        if (checkserviceId::text!='null') then
			                        denial:=array_append(denial,(select mes.service_id from disp.md_event_patient mep
                                                                                        left join disp.md_event_service_patient mesp on mesp.event_patient_id=mep.id
                                                                                        left join disp.md_event_service mes on mes.id=mesp.service_id where mep.id=xepid and  mesp.id= checkserviceId::text::int));
		                        end if;
	                        END LOOP;
                    end if ;
                    if (xtype=1)then
                        if (serviceRequired is not null) then
	                        foreach service in array serviceRequired
		                        loop
                        			if ((SELECT service = ANY(denial)) =true) then
				                        results:=array_append(results, cast((select ss.name from sr_service ss where id=service limit 1)as text));
			                        end if;
		                        end loop;
                        end if;

                    end if;
                result=array_to_string(results,', ');
                if (result is null) then return 'true'; return result; end if;


  else return 'true';
end if; 
        return result;
        end;
$$;

