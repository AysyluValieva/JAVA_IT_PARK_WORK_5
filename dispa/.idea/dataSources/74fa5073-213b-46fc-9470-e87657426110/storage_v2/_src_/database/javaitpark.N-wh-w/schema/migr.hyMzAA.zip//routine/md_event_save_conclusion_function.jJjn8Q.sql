CREATE FUNCTION md_event_save_conclusion_function(xid integer, xcertificate_number integer, xcert_date_begin date, xcert_date_end date, xconclusion_number integer, xconclusion_date date, xmedcommission integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
                indicationsListid json;
                unhealthy_diagnosis boolean;
                unhealthy_result boolean;
            begin

                update migr.md_migr_card set
                    certificate_number = xcertificate_number,
                    cert_date_begin = xcert_date_begin,
                    cert_date_end=xcert_date_end,
                    conclusion_number=xconclusion_number,
                    conclusion_date=xconclusion_date,
                    med_commission_id=xmedCommission
                    where id = xid;

                select exists(select 1 from migr.md_migr_service mgs join md_diagnosis md on mgs.main_diagnosis_id = md.id where mgs.event_patient_id = xid and
                (md.code like 'F10%' or md.code like 'F11%' or md.code like 'F12%' or md.code like 'F13%' or
                md.code like 'F14%' or md.code like 'F15%' or md.code like 'F16%' or md.code like 'F17%' or
                md.code like 'F18%' or md.code like 'F19%' or md.code like 'A15%' or md.code like 'A16%' or
                md.code like 'A17%' or md.code like 'A18%' or md.code like 'A19%' or md.code like 'B20%' or
                md.code like 'B21%' or md.code like 'B22%' or md.code like 'B23%' or md.code like 'B24%' or
                md.code like 'A30%' or md.code like 'A50%' or md.code like 'A51%' or md.code like 'A52%' or
                md.code like 'A53%' or md.code like 'A55%' or md.code like 'A57%')
                and (mgs.is_second is null or mgs.is_second = false)) into unhealthy_diagnosis;

                select exists(select 1 from migr.md_migr_service mgs where mgs.event_patient_id = xid and mgs.result = true and (mgs.is_second is null or mgs.is_second = false)) into unhealthy_result;

		        if ((unhealthy_diagnosis = true) or (unhealthy_result = true)) then
		            update migr.md_migr_card set status_id = 3 where id = xid;
		        else
		            update migr.md_migr_card set status_id = 2 where id = xid;
		        end if;

                update mc_case set closing_step_id = (select id from mc_step where case_id = (select case_id from disp.md_event_eq_case where event_patient_id = xid) order by outcome_date desc limit 1)
		        where id = (select case_id from disp.md_event_eq_case where event_patient_id = xid) and closing_step_id is null;

            return xid;
            end;
$$;

