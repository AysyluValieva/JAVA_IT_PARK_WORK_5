CREATE FUNCTION md_event_add_migrant_function_validation(xpid integer)
  RETURNS character varying
LANGUAGE plpgsql
AS $$
declare
                gender integer;
                birthday date;
                reg_address character varying;
                doc1 character varying;
                result character varying;
            begin
                select gender_id into gender from pim_individual where id = xpid;
                select birth_dt into birthday from pim_individual where id = xpid;

                select adr__get_search_name(
                (select ae.id from pim_party_address ppa
                left join pim_party_addr_to_addr_type ppatat on ppatat.party_address_id = ppa.id
                left join pim_address_type pat on pat.id = ppatat.address_type_id
                left join address_element ae on ae.id = ppa.addr_id
                where pat.code = 'REGISTER' and ppa.party_id = xpid limit 1)) into reg_address;

                select case exists(select 1
                from pim_individual_doc id
                join pim_doc_type dt on dt.id = id.type_id
                where dt.code = '9' and id.indiv_id = xpid and is_active = true limit 1)
                when true then (select concat_ws('/', dt.name, concat_ws('_', id.series, id.number), concat_ws('_', to_char(id.issue_dt, 'DD.MM.YYYY'), to_char(id.expire_dt, 'DD.MM.YYYY')), coalesce((select o.short_name from pim_organization o where o.id = id.issuer_id), id.issuer_text))
                from pim_individual_doc id
                join pim_doc_type dt on dt.id = id.type_id
                where dt.code = '9' and id.indiv_id = xpid and is_active = true limit 1)
                else (select concat_ws('/', dt.name, concat_ws('_', id.series, id.number), concat_ws('_', to_char(id.issue_dt, 'DD.MM.YYYY'), to_char(id.expire_dt, 'DD.MM.YYYY')), coalesce((select o.short_name from pim_organization o where o.id = id.issuer_id), id.issuer_text))
                from pim_individual_doc id
                join pim_doc_type dt on dt.id = id.type_id
                where id.indiv_id = xpid and is_active = true order by priority limit 1)
                end into doc1;

                result = null;
                if (gender is null) then
                  result = concat(result, 'Пол; ');
                end if;
                if (birthday is null) then
                  result = concat(result, 'Дата рождения; ');
                end if;
                if (reg_address is null) then
                  result = concat(result, 'Адрес регистрации; ');
                end if;
                if (doc1 is null) then
                  result = concat(result, 'Документ; ');
                end if;
                return result;
            end;
$$;

