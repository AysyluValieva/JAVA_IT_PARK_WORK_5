CREATE FUNCTION create_card_paper(xcall_num integer, xcall_dt integer, xcall_kind_id integer, xcall_type_id integer, xis_group_sufferer boolean, xsum_sufferer integer, xcaller_reason_id integer, xreason_diag integer, xreason_note character varying, xcall_place_id integer, xcall_place_note character varying, xplace_org_id integer, xplace_department_id integer, xaddress_id integer, xhouse character varying, xhousing character varying, xapartment character varying, xporch character varying, xfloor character varying, xdoor_code character varying, xdescription character varying, xto_org_id integer, xto_department_id integer, xto_address_id integer, xto_house character varying, xto_housing character varying, xto_apartment character varying, xto_porch character varying, xto_description character varying, xpatient_id integer, xsurname character varying, xname character varying, xpatrname character varying, xbirthdt date, xgender integer, xis_chronic boolean, xyears integer, xmonths integer, xdays integer, xphone_caller character varying, xcaller_id integer, xemployee_id integer, xcaller_note character varying, xpriority_id integer, xpriority integer, xcontrol integer, xnote character varying, xregistrator_id integer, xstation_id integer, xroute_id integer, xsubstation_id integer, xbrg_id integer, xemp_id integer, xparcal integer, xtransregistrator_id integer, xreceipt_time time without time zone, xtransmit_time time without time zone, xtransmit_state integer, xto_time time without time zone, xresdoc integer, xres1 integer, xres2 integer, xcardreg integer, xexit_time time without time zone, xcoming_time time without time zone, xtransportation_time time without time zone, xtoclinic_time time without time zone, xtosubstation_time time without time zone, xdeath_time time without time zone, xout_delay_reason_id integer, xcall_reason_id integer, xreason_accident_id integer, xcondition_ns character varying, xcitizenship_type_id integer, xnsdatatime timestamp without time zone, xmilage numeric, xneed_exit_through integer, xactiv_visit_clinic_id integer, xother_recommendations character varying, xtime_gone_id integer, xtransporting_type_id integer, xcasenote character varying, xdeathres character varying, xdeathdiag integer, xmasterdiag integer, xresult_id integer, xdeath_date date, xdeathemp integer, xoutdate date, xouttime time without time zone, xout integer, xaccompdiag integer, xmdisease_type integer, xaccompdisease_type integer, xtake_birth_id integer, xuser integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
                        --КТ
                            i integer;
                            -- время приёма вызова
                            xfrom_dt date;
                            xfrom_time timestamp without time zone;
                            xreceipt_time_id integer;
                            -- время передачи бригаде
                            xtrans_time timestamp without time zone;
                            xtransmit_time_id integer;

                            xstatehist integer;
                            priorsum integer;
                            xduble integer;

                            resroute record;
                            xroute_id integer;
                            xroutehist integer;

                        -- из посыла
                            xbrg integer;	-- вот это уже наряд!
                            xemp integer; 	-- это наряд на сотрудника!
                            xbol boolean;
                            --xcall_reason_id integer;
                            --xreason_accident_id integer;
                            --xdate timestamp without time zone;
                            xstate integer;
                            xcall_prior integer;
                            -- для случая
                            xcase integer;
                            xfunding integer;
                            xcase_type integer;
                            xcare_regimen integer;
                            xcare_level integer;
                            xcare_providing_form integer;
                            xinit_goal integer;
                            xinit_type integer;
                            xadmission_type integer;
                            xpayment_method integer;

                        -- из завершения
                            xend_time timestamp without time zone;
                            xend_time_id integer;
                            -- для системного составного ресурса
                            xgroup integer;
                            resel record;
                            xrelationship_id integer;

                            -- шаг
                            xstep integer;
                            xprof integer;
                            --xcare_regimen integer;
                            -- посещение
                            --xvisit integer; т.к. = xstep
                            xvisit_place integer;
                            xvisit_goal integer;
                            xvisit_type integer;
                            xinitiator integer;
                            xcall_kind integer;
                            xcaller integer;
                            -- для услуги
                            xrendered integer;
                            xservice integer;
                            xduration integer;
                            xmeasure integer;
                           -- xfunding integer;

                        -- КВ
                            --dt date;	--xfrom_dt
                            --ft timestamp without time zone;
                            --xcase integer;
                            xcase_state integer;
                            --xstep integer;
                            --xvisit integer;
                            --xrendered integer;
                            --xgroup integer;
                            -- по временным полям
                            xexit_time_id integer;
                            xcoming_time_id integer;
                            xtransportation_time_id integer;
                            xtoclinic_time_id integer;
                            xtosubstation_time_id integer;
                            -- преобразования временных полей
                            xexit_t timestamp without time zone;-- выезд с п/ст
                            xcoming_t timestamp without time zone;-- прибытие на вызов
                            xtransportation_t timestamp without time zone; -- начало транспортировки
                            xtoclinic_t timestamp without time zone; -- прибытие в МО
                            xtosubstation_t timestamp without time zone; -- возвращение на п/ст
                            -- результат вызова
                            --xcall_reason_id integer;
                            --xreason_accident_id integer;
                            xhas_list boolean := false;
                            --диагнозы
                            xmasdiag integer := null;
                            xaccdiag integer := null;
                            xstage integer;
                            xaccompstage integer;
                            xmdiatype integer;
                            xaccompdiatype integer;
                            xdoctor integer;
                            --xstate integer;

                            xcallnote integer;

                          begin
                                --преобразование времени приёма в timestamp
                                xfrom_dt = (select from_data from amb.md_ambulance_change where id = xcall_dt);
                                --xreceipt_time time		-- приём
                                xfrom_time = case when xreceipt_time between cast('00:00' as time) and
                                                (select change_begin from amb.md_ambulance_change_setting where clinic_id = xstation_id and coalesce(department_id, 0) = coalesce(xsubstation_id, 0))
                                            then cast(cast(xfrom_dt + cast('1 day' as interval) as date)||' '|| xreceipt_time  as timestamp without time zone)
                                            else cast(xfrom_dt ||' ' ||xreceipt_time  as timestamp without time zone)
                                            end;

                                if (xpatient_id is null)
                                    then
                                        xpatient_id = amb.create_pat_vrem (xsurname,xname,xpatrname,xbirthdt,xgender);
                                        update pci_patient set
                                        note = note||', '||(select short_name from pim_organization where id = xstation_id)||', вызов №'||cast(xcall_num as varchar(6))||' от '||(select to_char(from_data,'dd.mm.yyyy') from amb.md_ambulance_change where id = xcall_dt)
                                        where id = xpatient_id;
                                /*1*/end if;

                                -- формирование наряда на бригаду на смену вызова
                                -- xbrg_id -- пока регистратором бригады будет диспетчер направления

                                xbrg := amb.add_res_team_job(xbrg_id,xcall_dt,xtransregistrator_id);
                                -- чтобы бригада не попадала в очередь
                                if amb.search_team_job_status (xbrg) is null
                                    then
                                        update amb.sr_res_team_job set bdate = cast((select from_data ||' ' ||from_time from amb.md_ambulance_change where id = xcall_dt) as timestamp without time zone) where id = xbrg;
                                        --cast((select from_data ||' ' ||from_time from amb.md_ambulance_change where id = xcall_dt) as timestamp without time zone)
                                        execute amb.add_team_job_status_hist(xbrg,cast((select from_data ||' ' ||from_time from amb.md_ambulance_change where id = xcall_dt) as timestamp without time zone),1,xtransregistrator_id,'подписка',xuser);

                                        update amb.sr_res_team_job set edate = cast((select to_data ||' ' ||to_time from amb.md_ambulance_change where id = xcall_dt) as timestamp without time zone) where id = xbrg;
                                        execute amb.add_team_job_status_hist (xbrg,cast((select to_data ||' ' ||to_time from amb.md_ambulance_change where id = xcall_dt) as timestamp without time zone),7,xtransregistrator_id,'завершение работы',xuser);
                                /*2*/end if;
                                /*
                                -- формирование наряда на сотрудника, оказавшего помощь амбулаторно на смену вызова
                                -- xemp_id -- пока регистратором бригады будет диспетчер направления

                                -- загвоздка в определении роли
                                select :select
                                        from pim_employee_position_resource pepr on pepr.id = sr.id
                                        join pim_employee_position pep on pep.id = pepr.employee_position_id
                                        join pim_position ppos on ppos.id = pep.position_id
                                where pepr.id = xemp_id;

                                if not exists (select * from amb.sr_res_team_job_resource where resource_id = xemp_id and change_id = xcall_dt)
                                    then
                                        xemp := amb.add_res_team_job_resourse (null,xcall_dt,xemp_id,(select ), (select ),4,false,null,null,xtransregistrator_id);

                          xrole integer,
                          xworkplace varchar,
                                        amb.add_res_team_job(xbrg_id,xcall_dt,xtransregistrator_id);
                                    else
                                        xemp := (select id from amb.sr_res_team_job_resource where resource_id = xemp_id and change_id = xcall_dt);
                                end if;
                                */
                                /*
                                -- чтобы бригада не попадала в очередь
                                if amb.search_team_job_status (xbrg) is null
                                    then
                                        update amb.sr_res_team_job set bdate = cast((select from_data ||' ' ||from_time from amb.md_ambulance_change where id = xcall_dt) as timestamp without time zone) where id = xbrg;
                                        --cast((select from_data ||' ' ||from_time from amb.md_ambulance_change where id = xcall_dt) as timestamp without time zone)
                                        execute amb.add_team_job_status_hist(xbrg,cast((select from_data ||' ' ||from_time from amb.md_ambulance_change where id = xcall_dt) as timestamp without time zone),1,xtransregistrator_id,'подписка',xuser);

                                        update amb.sr_res_team_job set edate = cast((select to_data ||' ' ||to_time from amb.md_ambulance_change where id = xcall_dt) as timestamp without time zone) where id = xbrg;
                                        execute amb.add_team_job_status_hist (xbrg,cast((select to_data ||' ' ||to_time from amb.md_ambulance_change where id = xcall_dt) as timestamp without time zone),7,xtransregistrator_id,'завершение работы',xuser);
                                end if;
                        */
                                i = nextval('amb.md_ambulance_call_seq');
                                insert into amb.md_ambulance_call (id,call_number,call_dt,call_kind_id,call_type_id,is_group_sufferer,sum_sufferer,
                                                                from_time,caller_reason_id,reason_diag,reason_note,
                                                                call_place_id,call_place_note,place_org_id,place_department_id,
                                                                address_id,house,housing,apartment,porch,floor,door_code,description,
                                                                to_org_id,to_department_id,to_address_id,to_house,to_housing,to_apartment,to_porch,to_description,
                                                                patient_id,is_chronic,age_years,age_months,age_days,
                                                                phone_caller,caller_id,employee_id,caller_note,
                                                                priority_id,priority,control,note,registrator_id,
                                                                station_id,route_id,substation_id,brg_id,emp_id)

                                values (i,xcall_num,xcall_dt,xcall_kind_id,xcall_type_id,xis_group_sufferer,xsum_sufferer,
                                        xfrom_time,xcaller_reason_id,xreason_diag,xreason_note,
                                        xcall_place_id,xcall_place_note,xplace_org_id,xplace_department_id,
                                        xaddress_id,xhouse,xhousing,xapartment,xporch,xfloor,xdoor_code,xdescription,
                                        xto_org_id,xto_department_id,xto_address_id,xto_house,xto_housing,xto_apartment,xto_porch,xto_description,
                                        xpatient_id,xis_chronic,xyears,xmonths,xdays,
                                        xphone_caller,xcaller_id,xemployee_id,xcaller_note,
                                        xpriority_id,xpriority,xcontrol,xnote,xregistrator_id,
                                        xstation_id,xroute_id,xsubstation_id,xbrg,xemp_id);

                                -- принят диспетчером
                                --xstatehist = amb.add_ambcall_state_hist (i,dt,1,null,xregistrator_id);
                                IF xreceipt_time is not null
                                THEN
                                    select into xreceipt_time_id mash.id from amb.md_ambcall_state_history mash
                                                left join amb.md_ambulance_call_state macs on macs.id = mash.state_id
                                                    where macs.code = '1' and mash.call_id = i;
                                    if xreceipt_time_id is null
                                    then
                                        --select
                                        xstate := amb.add_ambcall_state_hist (i,xfrom_time,1,null,xregistrator_id);
                                    else
                                        update amb.md_ambcall_state_history set date_time = xfrom_time where id = xreceipt_time_id;
                                    /*3*/end if;
                                /*4*/END IF;
                                -- передан бригаде
                                --преобразование времени передачи в timestamp
                                --xtransmit_time time		-- передача
                                xtrans_time = case when xtransmit_time between cast('00:00' as time) and
                                                (select change_begin from amb.md_ambulance_change_setting where clinic_id = xstation_id and coalesce(department_id, 0) = coalesce(xsubstation_id, 0))
                                                or xfrom_time >= cast(cast(xfrom_dt + cast('1 day' as interval) as date)||' '|| cast('00:00' as time)  as timestamp without time zone)
                                            then cast(cast(xfrom_dt + cast('1 day' as interval) as date)||' '|| xtransmit_time  as timestamp without time zone)
                                            else cast(xfrom_dt ||' ' ||xtransmit_time  as timestamp without time zone)
                                            end;
                                IF xtransmit_time is not null
                                THEN
                                    select into xtransmit_time_id mash.id from amb.md_ambcall_state_history mash
                                                left join amb.md_ambulance_call_state macs on macs.id = mash.state_id
                                                    where macs.code = '5' and mash.call_id = i;
                                    if xtransmit_time_id is null
                                    then
                                        --select
                                        xstate := amb.add_ambcall_state_hist (i,xtrans_time,5,xtransmit_state,xtransregistrator_id);
                                    else
                                        update amb.md_ambcall_state_history set date_time = xtrans_time, transmit_id = xtransmit_state where id = xtransmit_time_id;
                                    /*5*/end if;
                                /*6*/END IF;

                                priorsum = amb.priority_calculation(i,xregistrator_id);
                                if (xcall_type_id = 2) and (xparcal is not null)
                                    then
                                        execute amb.add_amb_call_double(i,9,true,xregistrator_id,xparcal);
                                        update amb.md_ambulance_call set call_mark  = 2 where id = i;
                                /*7*/end if;

                                if amb.check_call_double(i) = false
                                    then update amb.md_ambulance_call set call_mark  = 1 where id = i;
                                /*8*/end if;

                                for resroute in
                                    select ra.id as id, ra.address_id as address_id,ra.building_pattent as building_pattent,ra.route_id as route_id
                                        from amb.md_ambulance_route_area ra
                                        left join amb.md_ambulance_route r on r.id = ra.route_id
                                        where r.org_id = xstation_id and (r.to_time is null or r.to_time >= now()) and (ra.to_time is null or ra.to_time >= now())
                                loop
                                    if amb.check_address_in_district (xaddress_id,resroute.address_id,xhouse,resroute.building_pattent)
                                        then
                                            xroute_id = resroute.route_id;
                                            xroutehist = amb.add_ambcall_route_hist (i,xfrom_time,xstation_id,xroute_id,xsubstation_id,NULL,xregistrator_id);
                                            xstatehist = amb.add_ambcall_state_hist (i,xfrom_time,2,null,xregistrator_id);
                                    /*9*/end if;
                                end loop;

                                --госпитализация, устанавливаем отметку по виду вызова
                                IF (xcall_kind_id in (3,4)) or (xto_org_id is not null)
                                    THEN
                                        xcallnote = amb.add_call_note(i,21,true,null,'а/у госпитализация',xregistrator_id,null);
                                /*10*/END IF;

                        -- из посыла

                            --причина вызова, причина несчастного случая
                            /*
                            select into xcall_reason_id,xreason_accident_id call_reason_id,reason_accident_id
                                from amb.md_ambulance_caller_reason where id = xcaller_reason_id;
                            */
                            -- Случай
                            xcare_providing_form = (select id from md_care_providing_form  where e_code =
                                    case when xcall_kind_id in (4,6) then '3' else case when xpriority_id in (1,2) then '1' else '2' end end);
                            xinit_type = (select id from mc_case_init_type where e_code =
                                    case when xcall_kind_id in (3,4,6) then '2' else '1' end);
                            xfunding = (select id from fin_funding_source_type where e_code = 'OMS');
                            if not exists (select id from amb.md_ambulance_call_result where id = i)
                            then
                                -- создаем "Случай" -- тип случая по виду вызова
                                if xcall_kind_id = 7
                                    then
                                        xcase_type = (select id from mc_case_type where e_code = '8');
                                    else
                                        xcase_type = (select id from mc_case_type where e_code = '7');
                                /*11*/end if;
                                xcare_regimen = (select id from mc_care_regimen where e_code = '6');
                                xcare_level = (select id from mc_care_level where e_code = '21');
                                xinit_goal = (select id from mc_case_init_goal where e_code = '03');
                                xadmission_type = (select id from mc_admission_type where e_code = '2');
                                xpayment_method = (select id from mc_payment_method where code='15');  -- системный справочник, в эталоне не заполнено e_code

                                xcase = nextval('mc_case_seq');
                                insert into mc_case(id,case_type_id,care_regimen_id,uid,care_level_id,care_providing_form_id,init_goal_id,init_type_id,admission_type_id,funding_id
                                    ,open_date,create_date,clinic_id, patient_id,payment_method_id)
                                values(xcase,xcase_type,xcare_regimen,xcall_num,xcare_level,xcare_providing_form,xinit_goal,xinit_type,xadmission_type,xfunding
                                    ,cast(xfrom_time as date),cast(xtrans_time as date),xstation_id,xpatient_id,xpayment_method);

                                -- записываем данные в "Результат вызова"
                                insert into amb.md_ambulance_call_result (id,case_id,transmit_state_id,call_reason_id,reason_accident_id,registrator_id)
                                    values (i,xcase,xtransmit_state,xcall_reason_id,xreason_accident_id,xtransregistrator_id);
                            else
                                -- на случай если был отменен посыл и т.п.
                                update mc_case set care_providing_form_id =xcare_providing_form,init_type_id = xinit_type
                                    ,create_date = cast(xtrans_time as date),clinic_id = xstation_id, patient_id = xpatient_id
                                where id = (select case_id from amb.md_ambulance_call_result where id = i);
                            /*12*/end if;
                            update amb.md_ambulance_call set brg_id = xbrg where id = i;
                            -- состояние вызова - "Назначена бригада"
                            xstate :=  amb.add_ambcall_state_hist (i,xtrans_time,4,1,xtransregistrator_id);
                            -- состояние вызова - "Вызов передан бригаде"
                            xstate :=  amb.add_ambcall_state_hist (i,xtrans_time,15,xtransmit_state,xtransregistrator_id);
                            -- состояние вызова - "Вызов принят бригадой"
                            xstate :=  amb.add_ambcall_state_hist (i,xtrans_time,5,xtransmit_state,xtransregistrator_id);
                            -- состояние бригады - "На вызове"
                            execute amb.add_team_job_status_hist (xbrg,xtrans_time,2,xtransregistrator_id,CAST(xcall_num as varchar(10))||'/'||coalesce(adr__get_element_as_text(xaddress_id,'(6,s,0)(7,s,0)(8,s,0)'),xdescription),xuser);
                            -- запись в историю диспетчерезации - "бригада"
                            xstate := amb.add_ambcall_route_hist (i,xtrans_time,null,null,null,xbrg,xtransregistrator_id);

                        -- из завершения
                            -- время завершения
                            --преобразование времени окончания в timestamp
                                --xto_time time		-- окончание
                                xend_time = case when xto_time between cast('00:00' as time) and
                                                (select change_begin from amb.md_ambulance_change_setting where clinic_id = xstation_id and coalesce(department_id, 0) = coalesce(xsubstation_id, 0))
                                                or xfrom_time >= cast(cast(xfrom_dt + cast('1 day' as interval) as date)||' '|| cast('00:00' as time)  as timestamp without time zone)
                                            then cast(cast(xfrom_dt + cast('1 day' as interval) as date)||' '|| xto_time  as timestamp without time zone)
                                            else cast(xfrom_dt ||' ' ||xto_time  as timestamp without time zone)
                                            end;
                                IF xto_time is not null
                                THEN
                                    select into xend_time_id mash.id from amb.md_ambcall_state_history mash
                                                left join amb.md_ambulance_call_state macs on macs.id = mash.state_id
                                                    where macs.code = '10' and mash.call_id = i;
                                    if xend_time_id is null
                                    then
                                        --xstate :=  amb.add_ambcall_state_hist (xcall,xtodate,10,2,xreg);
                                        xstate := amb.add_ambcall_state_hist (i,xend_time,10,xtransmit_state,xtransregistrator_id);
                                    else
                                        update amb.md_ambcall_state_history set date_time = xend_time where id = xend_time_id;
                                    /*13*/end if;
                                /*14*/END IF;

                            update amb.md_ambulance_call set to_time = xend_time where id = i;
                            execute amb.add_team_job_status_hist (xbrg,xend_time,1,xtransregistrator_id,'завершен: '||CAST(xcall_num as varchar(10))||'/'||(select adr__get_element_as_text(xaddress_id,'(6,s,0)(7,s,0)(8,s,0)')),xuser);
                            if xend_time >= (select date_time from amb.sr_res_team_job_status_history where team_job_id = xbrg and job_status_id = 7)
                                then
                                    update amb.sr_res_team_job_status_history set date_time = xend_time + '1 second' where team_job_id = xbrg and job_status_id = 7;
                            end if;

                            -- создаём системный составной ресурс
                            xgroup = nextval('sr_res_group_seq');
                            insert into sr_res_group (id,bdate,edate,is_system,name,org_id,department_id)
                                select xgroup,xtrans_time,xend_time,true,name,org_id,department_id from sr_res_group
                                    where id = (select resource_id from amb.sr_res_team rt left join amb.sr_res_team_job rtj on rtj.team_id = rt.id where rtj.id = xbrg);
                            --insert into md_res_group (id) values (xgroup);
                            insert into public.sr_res_group_profile(id,res_group_id,profile_id)
                                values(nextval('sr_res_group_profile_seq'),xgroup,(select profile_id from sr_res_group_profile where res_group_id = (select resource_id from amb.sr_res_team rt left join amb.sr_res_team_job rtj on rtj.team_id = rt.id where rtj.id = xbrg)));
                            insert into public.md_resgroup_amb_profile (id,profile_id)
                                select xgroup,profile_id from public.md_resgroup_amb_profile where id = (select resource_id from amb.sr_res_team rt left join amb.sr_res_team_job rtj on rtj.team_id = rt.id where rtj.id = xbrg);

                            -- пишем состав бригады на момент обслуживания вызова
                            /*!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!*/
                            if xresDoc is not null
                              then
                                xrelationship_id :=nextval('sr_res_group_relationship_seq');
                                INSERT INTO public.sr_res_group_relationship (id,bdatetime,edatetime,resource_id,group_id,role_id)
                                    VALUES (xrelationship_id,xtrans_time,xend_time,xresDoc,xgroup,(select id from sr_res_role where upper(code) = upper('DOCTOR')));
                                xrelationship_id :=nextval('sr_res_group_relationship_seq');
                                if xres1 is not null
                                    then
                                      INSERT INTO public.sr_res_group_relationship (id,bdatetime,edatetime,resource_id,group_id,role_id)
                                          VALUES (xrelationship_id,xtrans_time,xend_time,xres1,xgroup,(select id from sr_res_role where upper(code) = upper('PARAMEDIC_ASST')));
                                    end if;
                                if xres2 is not null
                                    then
                                        xrelationship_id :=nextval('sr_res_group_relationship_seq');
                                        INSERT INTO public.sr_res_group_relationship (id,bdatetime,edatetime,resource_id,group_id,role_id)
                                            VALUES (xrelationship_id,xtrans_time,xend_time,xres2,xgroup,(select id from sr_res_role where upper(code) = upper('PARAMEDIC_ASST')));
                                end if;
                              else
                                if xres1 is not null
                                    then
                                      xrelationship_id :=nextval('sr_res_group_relationship_seq');
                                      INSERT INTO public.sr_res_group_relationship (id,bdatetime,edatetime,resource_id,group_id,role_id)
                                          VALUES (xrelationship_id,xtrans_time,xend_time,xres1,xgroup,(select id from sr_res_role where upper(code) = upper('PARAMEDIC')));
                                      if xres2 is not null
                                        then
                                            xrelationship_id :=nextval('sr_res_group_relationship_seq');
                                            INSERT INTO public.sr_res_group_relationship (id,bdatetime,edatetime,resource_id,group_id,role_id)
                                                VALUES (xrelationship_id,xtrans_time,xend_time,xres2,xgroup,(select id from sr_res_role where upper(code) = upper('PARAMEDIC_ASST')));
                                      end if;
                                    else
                                        if xres2 is not null
                                            then
                                              xrelationship_id :=nextval('sr_res_group_relationship_seq');
                                              INSERT INTO public.sr_res_group_relationship (id,bdatetime,edatetime,resource_id,group_id,role_id)
                                                  VALUES (xrelationship_id,xtrans_time,xend_time,xres2,xgroup,(select id from sr_res_role where upper(code) = upper('PARAMEDIC')));
                                        end if;
                                end if;
                            end if;

                            -- создаем шаг
                            xstep = nextval('mc_step_seq');
                            xprof = (select id from md_profile where e_code = '84');
                            --xcare_regimen = (select id from mc_care_regimen where e_code = '6');
                            insert into mc_step(id,case_id, admission_date, admission_time,res_group_id,profile_id,is_continue,is_continue_editable)
                                VALUES(xstep,xcase, cast(xfrom_time as date),cast(xfrom_time as time),xgroup,xprof,false,false);

                            update mc_case set closing_step_id = xstep where id = xcase;

                            -- создаем посещение
                            xvisit_place = (select id from plc_visit_place where e_code = '3');
                            xvisit_goal = (select init_goal_id from mc_case where id = xcase);
                            xvisit_type =(select id from plc_visit_type where e_code ='1');
                            xinitiator =(select id from plc_initiator where e_code =
                                            case when xcall_kind_id in (4,6) or xcaller_id in (6)			-- условие очень спорно, нужно будет переписать для однозначности
                                            then '2' else '1' end);
                            insert into plc_visit (id,place_id,goal_id,type_id,initiator_id)
                                values (xstep,xvisit_place,xvisit_goal,xvisit_type,xinitiator);

                            --записываем "Оказанную услугу"
                            xrendered = nextval('sr_srv_rendered_seq');
                            xservice = (select id from sr_service where org_id = xstation_id and code = 'SNMP');
                            xduration = (select cast(EXTRACT(EPOCH FROM AGE(to_time, from_time))/60 as integer) from amb.md_ambulance_call where id = i);
                            xmeasure = (select id from sr_srv_duration_unit where measure_id = (select id from cmn_measure where e_code = '1'));
                            --xfunding = (select funding_id from mc_case where id = xcase);
                            insert into public.sr_srv_rendered(id,is_rendered,customer_id,res_group_id,org_id,service_id,bdate,begin_time,edate
                            ,duration,duration_measure_unit_id,quantity,funding_id )
                                values (xrendered,true,xpatient_id,xgroup,xstation_id,xservice
                                ,cast(xfrom_time as date), cast(xfrom_time as time),CAST(xend_time as date),xduration,xmeasure,1,xfunding);

                            -- md_srv_rendered
                            insert into md_srv_rendered (id,case_id,step_id,is_urgent)
                                values(xrendered,xcase,xstep,true);

                            -- в посещение фиксируем длительность
                            update plc_visit set duration = xduration where id = xstep;

                            -- записываем данные в результат вызова
                            update amb.md_ambulance_call_result set srv_rendered_id = xrendered where id = i;

                        --КВ

                            --выбираем данные для последующей обработки
                                --select into dt cast(from_time as date) from amb.md_ambulance_call where id = xcall;
                                --select into ft from_time from amb.md_ambulance_call where id = xcall;
                                --select into xcase case_id from amb.md_ambulance_call_result where id = xcall;
                                --select into xstep id from mc_step where case_id = xcase;
                                --select into xrendered srv_rendered_id from amb.md_ambulance_call_result where id = xcall;
                                --select into xgroup res_group_id from sr_srv_rendered where id = xrendered;  -- не надо для случая, т.к. MC_CASE. emergency_team_code varchar(250) - не понятно, зачем вообще нужно

                                -- временные поля
                                --xexit_time  -- выезд с п/ст
                                xexit_t = case when xexit_time between cast('00:00' as time) and
                                                (select change_begin from amb.md_ambulance_change_setting where clinic_id = xstation_id and coalesce(department_id, 0) = coalesce(xsubstation_id, 0))
                                                or xfrom_time >= cast(cast(xfrom_dt + cast('1 day' as interval) as date)||' '|| cast('00:00' as time)  as timestamp without time zone)
                                            then cast(cast(xfrom_dt + cast('1 day' as interval) as date)||' '|| xexit_time  as timestamp without time zone)
                                            else cast(xfrom_dt ||' ' ||xexit_time  as timestamp without time zone)
                                            end;
                                IF xexit_time is not null
                                THEN
                                    select into xexit_time_id mash.id from amb.md_ambcall_state_history mash
                                                left join amb.md_ambulance_call_state macs on macs.id = mash.state_id
                                                    where macs.code = '6' and mash.call_id = i;
                                    if xexit_time_id is null
                                    then
                                        --select
                                        xstate := amb.add_ambcall_state_hist (i,xexit_t,6,xtransmit_state,xcardreg);
                                    else
                                        update amb.md_ambcall_state_history set date_time = xexit_t where id = xexit_time_id;
                                    end if;
                                END IF;
                                --xcoming_time -- прибытие на вызов
                                xcoming_t = case when xcoming_time between cast('00:00' as time) and
                                                (select change_begin from amb.md_ambulance_change_setting where clinic_id = xstation_id and coalesce(department_id, 0) = coalesce(xsubstation_id, 0))
                                                or xfrom_time >= cast(cast(xfrom_dt + cast('1 day' as interval) as date)||' '|| cast('00:00' as time)  as timestamp without time zone)
                                            then cast(cast(xfrom_dt + cast('1 day' as interval) as date)||' '|| xcoming_time  as timestamp without time zone)
                                            else cast(xfrom_dt ||' ' ||xcoming_time  as timestamp without time zone)
                                            end;
                                IF xcoming_time is not null
                                THEN
                                    select into xcoming_time_id mash.id from amb.md_ambcall_state_history mash
                                                left join amb.md_ambulance_call_state macs on macs.id = mash.state_id
                                                    where macs.code = '7' and mash.call_id = i;
                                    if xcoming_time_id is null
                                    then
                                        --select
                                        xstate := amb.add_ambcall_state_hist (i,xcoming_t,7,xtransmit_state,xcardreg);
                                    else
                                        update amb.md_ambcall_state_history set date_time = xcoming_t where id = xcoming_time_id;
                                    end if;
                                END IF;

                                --xtransportation_time  -- начало транспортировки
                                xtransportation_t = case when xtransportation_time between cast('00:00' as time) and
                                                (select change_begin from amb.md_ambulance_change_setting where clinic_id = xstation_id and coalesce(department_id, 0) = coalesce(xsubstation_id, 0))
                                                or xfrom_time >= cast(cast(xfrom_dt + cast('1 day' as interval) as date)||' '|| cast('00:00' as time)  as timestamp without time zone)
                                            then cast(cast(xfrom_dt + cast('1 day' as interval) as date)||' '|| xtransportation_time  as timestamp without time zone)
                                            else cast(xfrom_dt ||' ' ||xtransportation_time  as timestamp without time zone)
                                            end;
                                IF xtransportation_time is not null
                                THEN
                                    select into xtransportation_time_id mash.id from amb.md_ambcall_state_history mash
                                                left join amb.md_ambulance_call_state macs on macs.id = mash.state_id
                                                    where macs.code = '8' and mash.call_id = i;
                                    if xtransportation_time_id is null
                                    then
                                        --select
                                        xstate := amb.add_ambcall_state_hist (i,xtransportation_t,8,xtransmit_state,xcardreg);
                                    else
                                        update amb.md_ambcall_state_history set date_time = xtransportation_t where id = xtransportation_time_id;
                                    end if;
                                END IF;
                                --xtoclinic_time -- прибытие в МО
                                xtoclinic_t = case when xtoclinic_time between cast('00:00' as time) and
                                                (select change_begin from amb.md_ambulance_change_setting where clinic_id = xstation_id and coalesce(department_id, 0) = coalesce(xsubstation_id, 0))
                                                or xfrom_time >= cast(cast(xfrom_dt + cast('1 day' as interval) as date)||' '|| cast('00:00' as time)  as timestamp without time zone)
                                            then cast(cast(xfrom_dt + cast('1 day' as interval) as date)||' '|| xtoclinic_time  as timestamp without time zone)
                                            else cast(xfrom_dt ||' ' ||xtoclinic_time  as timestamp without time zone)
                                            end;
                                IF xtoclinic_time is not null
                                THEN
                                    select into xtoclinic_time_id mash.id from amb.md_ambcall_state_history mash
                                                left join amb.md_ambulance_call_state macs on macs.id = mash.state_id
                                                    where macs.code = '9' and mash.call_id = i;
                                    if xtoclinic_time_id is null
                                    then
                                        --select
                                        xstate := amb.add_ambcall_state_hist (i,xtoclinic_t,9,xtransmit_state,xcardreg);
                                    else
                                        update amb.md_ambcall_state_history set date_time = xtoclinic_t where id = xtoclinic_time_id;
                                    end if;
                                END IF;
                                --xdeath_time time --stamp without time zone -- констатация смерти ???

                                --xtosubstation_time time -- возвращение на п/ст
                                xtosubstation_t = case when xtosubstation_time between cast('00:00' as time) and
                                                (select change_begin from amb.md_ambulance_change_setting where clinic_id = xstation_id and coalesce(department_id, 0) = coalesce(xsubstation_id, 0))
                                                or xfrom_time >= cast(cast(xfrom_dt + cast('1 day' as interval) as date)||' '|| cast('00:00' as time)  as timestamp without time zone)
                                            then cast(cast(xfrom_dt + cast('1 day' as interval) as date)||' '|| xtosubstation_time  as timestamp without time zone)
                                            else cast(xfrom_dt ||' ' ||xtosubstation_time  as timestamp without time zone)
                                            end;
                                IF xtosubstation_time is not null
                                THEN
                                    select into xtosubstation_time_id mash.id from amb.md_ambcall_state_history mash
                                                left join amb.md_ambulance_call_state macs on macs.id = mash.state_id
                                                    where macs.code = '11' and mash.call_id = i;
                                    if xtosubstation_time_id is null
                                    then
                                        --select
                                        xstate := amb.add_ambcall_state_hist (i,xtosubstation_t,11,xtransmit_state,xcardreg);
                                    else
                                        update amb.md_ambcall_state_history set date_time = xtosubstation_t where id = xtosubstation_time_id;
                                    end if;
                                END IF;
                                /*
                                if xcaller_reason <> (select caller_reason_id from amb.md_ambulance_call where id = xcall)
                                    then
                                        select into xcall_reason_id,xreason_accident_id call_reason_id,reason_accident_id
                                            from amb.md_ambulance_caller_reason where id = xcaller_reason;
                                end if;
                                */
                                -- данные о вызове (кроме данных о пациенте)
                                update amb.md_ambulance_call set
                                            caller_reason_id = xcaller_reason_id,
                                            reason_diag = xreason_diag,
                                            reason_note = xreason_note,
                                            call_place_id = xcall_place_id,
                                            call_place_note = xcall_place_note,
                                            place_org_id = xplace_org_id,
                                            place_department_id = xplace_department_id,
                                            address_id  = xaddress_id,
                                            house = xhouse,
                                            housing = xhousing,
                                            apartment = xapartment,
                                            porch = xporch,
                                            floor = xfloor,
                                            door_code = xdoor_code,
                                            description = xdescription,
                                            to_org_id = xto_org_id,
                                            to_department_id = xto_department_id,
                                            to_address_id = xto_address_id,
                                            to_house = xto_house,
                                            to_housing = xto_housing,
                                            to_apartment = xto_apartment,
                                            to_porch = xto_porch,
                                            to_description = xto_description,
                                            --patient_id = xpatient_id,
                                            is_chronic = xis_chronic,
                                            --age_years = xage_years,
                                            --age_months = xage_months,
                                            --age_days = xage_days,
                                            phone_caller = xphone_caller,
                                            caller_id = xcaller_id,
                                            caller_note = xcaller_note,
                                            employee_id = xemployee_id,
                                            note = xnote
                                            where id = i;

                                -- данные о пациенте
                                /*
                                здесь будет либо update по пациенту, либо объединение с уже существующим в системе, после идентификации пациента в системе
                                */

                                -- записи в результат вызова
                                --xhas_list = ();-- по виду вызова и отметкам (д.б. госпитализация)
                                -- дописать
                                --xhas_list = case when

                                update amb.md_ambulance_call_result set
                        --        			transmit_state_id = xtransmit_state_id,   -- если по БУМ будет этаже функция, то будет
                                            out_delay_reason_id = xout_delay_reason_id,
                                            call_reason_id = xcall_reason_id,
                                            reason_accident_id = xreason_accident_id,
                                            citizenship_type_id = xcitizenship_type_id,
                                            condition_ns = xcondition_ns,
                                            nsdatatime = xnsdatatime,
                                            milage = xmilage,
                                            need_exit_through = xneed_exit_through,
                                            activ_visit_clinic_id = xactiv_visit_clinic_id,
                                            other_recommendations = xother_recommendations,
                                            has_list = xhas_list,
                                            registrator_id = xcardreg,
                                            create_dt = now(),
                                            take_birth_id = xtake_birth_id
                                            where id = i;

                                -- записываем диагнозы
                                xstage = (select id from mc_stage where e_code = '4');
                                xaccompstage = (select id from mc_stage where e_code = '3');
                                xmdiatype = (select id from mc_diagnosis_type where e_code = '1');
                                xaccompdiatype = (select id from mc_diagnosis_type where e_code = '2');
                                xdoctor := (select pep.id
                                    from pim_employee_position pep
                                    join pim_employee_position_resource pepr on pepr.employee_position_id = pep.id
                                    join sr_resource sr on sr.id = pepr.id
                                    join sr_res_group_relationship srgrel on srgrel.resource_id = sr.id
                                    join sr_res_group srg on srg.id = srgrel.group_id
                                    where srg.id = xgroup and sr.id = xresDoc);
                                if xmasterdiag is not null
                                    then
                                        xmasdiag = nextval('mc_diagnosis_seq');
                                        insert into public.mc_diagnosis(id,patient_id,case_id,step_id,is_main,stage_id,type_id,diagnos_id,disease_type_id,establishment_date,doctor_id)
                                            values (xmasdiag,xpatient_id,xcase,xstep,true,xstage,xmdiatype,xmasterdiag,xmdisease_type,xfrom_dt,xdoctor);
                                end if;
                                if xaccompdiag is not null
                                    then
                                        xaccdiag = nextval('mc_diagnosis_seq');
                                        insert into public.mc_diagnosis(id,patient_id,case_id,step_id,is_main,stage_id,type_id,diagnos_id,disease_type_id,establishment_date,doctor_id)
                                            values (xaccdiag,xpatient_id,xcase,xstep,false,xaccompstage,xaccompdiatype,xaccompdiag,xaccompdisease_type,xfrom_dt,xdoctor);
                                end if;

                                --записи в случай (mc_case)
                                        --записи в услуга (sr_srv_rendered)
                                        update md_srv_rendered set diagnosis_id = xmasterdiag where id = xrendered;
                                    -- шаг

                                    update mc_step set main_diagnosis_id = xmasdiag
                                        ,result_id = xresult_id
                                        ,death_date = xdeath_date, death_time = xdeath_time, death_employee_id = xdeathemp
                                        ,outcome_date = case when xoutdate is null then cast(xend_time as date) else xoutdate end,outcome_time = xouttime
                                        ,outcome_id = xout, outcome_clinic_id = xto_org_id
                                    where id = xstep;

                                -- дописано, таблица(mc_med_case_result) не нужна для снмп
                                xcase_state = (select id from mc_case_state where e_code = '1');
                                update mc_case set main_diagnos_id = xmasdiag,time_gone_id = xtime_gone_id,transporting_type_id = xtransporting_type_id
                                    ,note = xcasenote,death_reason = xdeathres, death_reason_diagnosis_id = xdeathdiag
                                    ,state_id = xcase_state
                                where id = xcase;

                                xservice := amb.set_service (i);

                            return i;
                          end;
$$;

