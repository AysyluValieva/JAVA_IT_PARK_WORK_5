CREATE FUNCTION saveeventservicefromsearch(xepid integer, xssrid integer, xcaseid integer, xbdate character varying, xresource integer, xservice integer, xcreate boolean, xlink integer, xmes integer, xorgid integer)
  RETURNS character varying
LANGUAGE plpgsql
AS $$
declare
          serviceid integer;
          srrid integer;
          created boolean;
          eventtype integer;
          was_created boolean;
          same_org boolean;
          old_resource integer;
          stepid integer;
          mes_service_id integer;
          is_mes_org boolean;
          is_mes_service boolean;
          is_changed boolean;
        begin

          serviceid = xservice;
          select coalesce(xcreate, false) into created;
          select met.id into eventtype from disp.md_event_type met
            left join disp.md_event me on me.event_type=met.id
            left join disp.md_event_patient mep on mep.event_id=me.id
            where mep.id=xepid;
          select service_id into mes_service_id from disp.md_event_service where id = xmes;
          select (me.org_id = xorgid) into same_org from disp.md_event_patient mep join disp.md_event me on me.id = mep.event_id where mep.id = xepid;
          if (not same_org) then
            select (xorgid = mes.org_id) into is_mes_org from disp.md_event_service mes where id = xmes;
            if (created = false and is_mes_org = true) then
              select (service_id = mes_service_id) into is_mes_service from SR_SRV_RENDERED where id = xssrid;
            end if;
          end if;
          if (created = false and ((same_org = true) or (is_mes_org = true and is_mes_service = false))) then
            created = true;
            serviceid = (select service_id from SR_SRV_RENDERED where id = xssrid);
          end if;

          if xlink IS NULL then

                if created = TRUE then
                    srrid = nextval('sr_srv_rendered_seq');
                    insert into SR_SRV_RENDERED (id, service_id, bdate, res_group_id, customer_id, is_rendered, edate, quantity, funding_id, org_id, payment_status_id)
                      values (srrid, serviceid, COALESCE(to_date(xbdate, 'DD.MM.YYYY'), current_date), xresource, (select indiv_id from disp.md_event_patient where id = xepid), TRUE, COALESCE(to_date(xbdate, 'DD.MM.YYYY'), current_date), 1,
                      (select me.pay_type from disp.md_event me left join disp.md_event_patient mep on mep.event_id=me.id  where mep.id=xepid), xorgid, 1);
                    if (same_org) then
                        stepid = (select disp.find_first_step(xepid));
                        insert into MD_SRV_RENDERED (id, case_id, step_id) values (srrid, xcaseId, stepid);
                    else
                        insert into MD_SRV_RENDERED (id) values (srrid);
                    end if;
                    if (same_org = true or is_mes_org = true) then
                      if (select service_id <> mes_service_id from sr_srv_rendered where id = srrid) then
                        update sr_srv_rendered set service_id = mes_service_id where id = srrid;
                        is_changed = true;
                      end if;
                    end if;
                    insert into disp.md_event_service_link (id, case_id, service_id, event_service_id, is_created)
                      values (nextval('disp.md_event_service_link_id_seq'), xcaseId, srrid, xmes, created);
                else
                    insert into disp.md_event_service_link (id, case_id, service_id, event_service_id, is_created)
                      values (nextval('disp.md_event_service_link_id_seq'), xcaseId, xssrid, xmes, created);
                end if;
          else
                select is_created into was_created from disp.md_event_service_link where id = xlink;
                select res_group_id into old_resource from SR_SRV_RENDERED where id = (select service_id from disp.md_event_service_link where id = xlink);
                if created = TRUE then
                    if (was_created) then
                        srrid = (select service_id from disp.md_event_service_link where id = xlink);
                        update SR_SRV_RENDERED set service_id = serviceid, bdate = COALESCE(to_date(xbdate, 'DD.MM.YYYY'), current_date),
                          res_group_id = xresource, edate = COALESCE(to_date(xbdate, 'DD.MM.YYYY'), current_date), org_id = xorgid
                          where id = srrid;
                        if ((same_org = true) and (old_resource <> xresource)) then
                            stepid = (select disp.find_first_step(xepid));
                            update MD_SRV_RENDERED set case_id = xcaseId, step_id = stepid where id = srrid;
                        else
                            if (same_org = false) then
                                update MD_SRV_RENDERED set case_id = null, step_id = null where id = srrid;
                            end if;
                        end if;
                        if (same_org = true or is_mes_org = true) then
                          if (select service_id <> mes_service_id from sr_srv_rendered where id = srrid) then
                            update sr_srv_rendered set service_id = mes_service_id where id = srrid;
                            is_changed = true;
                          end if;
                        end if;
                    else
                        srrid = nextval('sr_srv_rendered_seq');
                        insert into SR_SRV_RENDERED (id, service_id, bdate, res_group_id, customer_id, is_rendered, edate, quantity, funding_id, org_id, payment_status_id)
                          values (srrid, serviceid, COALESCE(to_date(xbdate, 'DD.MM.YYYY'), current_date), xresource, (select indiv_id from disp.md_event_patient where id = xepid), TRUE, COALESCE(to_date(xbdate, 'DD.MM.YYYY'), current_date), 1,
                          (select me.pay_type from disp.md_event me left join disp.md_event_patient mep on mep.event_id=me.id  where mep.id=xepid), xorgid, 1);
                        if (same_org) then
                            stepid = (select disp.find_first_step(xepid));
                            insert into MD_SRV_RENDERED (id, case_id, step_id) values (srrid, xcaseId, stepid);
                        else
                            insert into MD_SRV_RENDERED (id) values (srrid);
                        end if;
                        if (same_org = true or is_mes_org = true) then
                          if (select service_id <> mes_service_id from sr_srv_rendered where id = srrid) then
                            update sr_srv_rendered set service_id = mes_service_id where id = srrid;
                            is_changed = true;
                          end if;
                        end if;
                    end if;
                    update disp.md_event_service_link set case_id = xcaseId, service_id = srrid, is_created = created
                      where id = xlink;
                else
                    srrid = (select service_id from disp.md_event_service_link where id = xlink);
                    update disp.md_event_service_link set case_id = xcaseId, service_id = xssrid, is_created = created
                      where id = xlink;
                    if (was_created and (srrid <> xssrid)) then                       
                      delete from SR_SRV_RENDERED where id = srrid;
                    end if;
                    
                end if;

          end if;

          -- change STATUS
          update disp.md_event_service_patient set status = 3
              where  id = (select mesp.id from disp.md_event_patient mep
                left join disp.md_event_service_patient mesp on mep.id = mesp.event_patient_id
                inner join disp.md_event_service mes on mes.id = mesp.service_id
                where mep.id = xepid and mes.id = xmes);
          if (is_changed) then
            return 'В ЭМК пациента будет создана услуга с кодом услуги из раздела "Услуги по нормативному документу"';
          else
            return 'Данные сохранены';
          end if;
        end;
$$;

