CREATE FUNCTION typing_validate(integer, json)
  RETURNS SETOF record
LANGUAGE plpgsql
AS $$
DECLARE

i int;
r record;
rb boolean;
vld text;
msg text;
clmn_name text;
v text;
codes text[];
msg_param text;
BEGIN
msg:='';

END;


$$;

