CREATE FUNCTION fsym_on_i_for_pblc_md_rm_mngrp()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
begin                                                                                                                                                                  
                                   
                                  if 1=1 and "public".sym_triggers_disabled() = 0 then                                                                                                 
                                    insert into "public".sym_data                                                                                                                     
                                    (table_name, event_type, trigger_hist_id, row_data, channel_id, transaction_id, source_node_id, external_data, create_time)                                        
                                    values(                                                                                                                                                            
                                      'md_room',                                                                                                                                            
                                      'I',                                                                                                                                                             
                                      467,                                                                                                                                             
                                      
          case when new."id" is null then '' else '"' || cast(cast(new."id" as numeric) as varchar) || '"' end||','||
          case when new."cell_count" is null then '' else '"' || cast(cast(new."cell_count" as numeric) as varchar) || '"' end||','||
          case when new."cell_count_extra" is null then '' else '"' || cast(cast(new."cell_count_extra" as numeric) as varchar) || '"' end||','||
          case when new."comfort_level_id" is null then '' else '"' || cast(cast(new."comfort_level_id" as numeric) as varchar) || '"' end||','||
          case when new."post_id" is null then '' else '"' || cast(cast(new."post_id" as numeric) as varchar) || '"' end||','||
          case when new."regimen_id" is null then '' else '"' || cast(cast(new."regimen_id" as numeric) as varchar) || '"' end||','||
          case when new."kind_id" is null then '' else '"' || cast(cast(new."kind_id" as numeric) as varchar) || '"' end||','||
          case when new."pit" is null then '' when new."pit" then '"1"' else '"0"' end,                                                                                                                                                      
                                      'public_md_room_default',                                                                                                                                                
                                      txid_current(),                                                                                                                                               
                                      "public".sym_node_disabled(),                                                                                                                   
                                      null,                                                                                                                                               
                                      CURRENT_TIMESTAMP                                                                                                                
                                    );                                                                                                                                                                 
                                  end if;                                                                                                                                                              
                                                                                                                                                                               
                                  return null;                                                                                                                                                         
                                end;
$$;

