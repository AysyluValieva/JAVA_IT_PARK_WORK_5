CREATE FUNCTION apda_get_apda_district_address_build_pattern_items(pattern character varying)
  RETURNS apda_district_address_build_pattern_items
LANGUAGE plpgsql
AS $$
DECLARE
  reduced_str          VARCHAR;
  includes             VARCHAR [] := ARRAY [] :: VARCHAR [];
  excludes             VARCHAR [] := ARRAY [] :: VARCHAR [];
  count_brackets       INTEGER := 0;
  start_parse_position INTEGER := 1;
  cur_position         INTEGER := 0;
  it                   CHAR;
  part                 VARCHAR;
BEGIN
  reduced_str = upper(replace($1 || ',', ' ', ''));
  FOR it IN (SELECT regexp_split_to_table(reduced_str, '') ch) LOOP
    cur_position = cur_position + 1;
    IF it = '('
    THEN count_brackets = count_brackets + 1;
    ELSEIF it = ')'
      THEN count_brackets = count_brackets - 1;
    ELSEIF it = ','
      THEN
        IF count_brackets = 0
        THEN
          part = substring(reduced_str, start_parse_position, cur_position - start_parse_position) :: VARCHAR;
          IF part NOTNULL AND part != ''
          THEN
            IF part LIKE 'И%'
            THEN excludes = array_append(excludes, part);
            ELSE includes = array_append(includes, part);
            END IF;
          END IF;
          start_parse_position = cur_position + 1;
        END IF;
    END IF;
  END LOOP;

  RETURN (includes, excludes) :: apda_district_address_build_pattern_items;
END;
$$;

