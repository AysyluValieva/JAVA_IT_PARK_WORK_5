CREATE FUNCTION get_all_diagnosis_children_with_current(diagnosis_id integer)
  RETURNS SETOF md_diagnosis
LANGUAGE SQL
AS $$
WITH RECURSIVE temp1 ( "ID","CODE", "NAME","PARENT", "IS_INJURY", "LEVEL", "IS_LEAF") AS (
      SELECT d.id, d.code, d.name, d.parent_id, d.is_injury, d.level, d.is_leaf
          FROM md_diagnosis d WHERE d.id = $1
      union
      select d2.id, d2.code, d2.name, d2.parent_id, d2.is_injury, d2.level, d2.is_leaf
           FROM md_diagnosis d2 INNER JOIN temp1 ON( temp1."ID"= d2.parent_id)      )
           select * from temp1 order by "LEVEL" desc
$$;

