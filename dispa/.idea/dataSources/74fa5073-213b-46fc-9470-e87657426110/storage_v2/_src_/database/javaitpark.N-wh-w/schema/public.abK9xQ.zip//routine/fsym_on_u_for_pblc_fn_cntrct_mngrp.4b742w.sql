CREATE FUNCTION fsym_on_u_for_pblc_fn_cntrct_mngrp()
  RETURNS trigger
LANGUAGE plpgsql
AS $fun$
declare var_row_data text; 
                                declare var_old_data text; 
                                begin
                                   
                                  if 1=1 and "public".sym_triggers_disabled() = 0 then                                                                                                 
                                    var_row_data := 
          case when new."id" is null then '' else '"' || cast(cast(new."id" as numeric) as varchar) || '"' end||','||
          case when new."comment" is null then '' else '"' || replace(replace(cast(new."comment" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."date" is null then '' else '"' || to_char(new."date", 'YYYY-MM-DD HH24:MI:SS.US') || '"' end||','||
          case when new."number" is null then '' else '"' || replace(replace(cast(new."number" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."period" is null then '' else '"' || to_char(new."period", 'YYYY-MM-DD HH24:MI:SS.US') || '"' end||','||
          case when new."sum" is null then '' else '"' || cast(cast(new."sum" as numeric) as varchar) || '"' end||','||
          case when new."termination_date" is null then '' else '"' || to_char(new."termination_date", 'YYYY-MM-DD HH24:MI:SS.US') || '"' end||','||
          case when new."price_list_id" is null then '' else '"' || cast(cast(new."price_list_id" as numeric) as varchar) || '"' end||','||
          case when new."type_id" is null then '' else '"' || cast(cast(new."type_id" as numeric) as varchar) || '"' end||','||
          case when new."financing_type_id" is null then '' else '"' || cast(cast(new."financing_type_id" as numeric) as varchar) || '"' end||','||
          case when new."beginning_date" is null then '' else '"' || to_char(new."beginning_date", 'YYYY-MM-DD HH24:MI:SS.US') || '"' end||','||
          case when new."is_executed" is null then '' when new."is_executed" then '"1"' else '"0"' end||','||
          case when new."status_id" is null then '' else '"' || cast(cast(new."status_id" as numeric) as varchar) || '"' end||','||
          case when new."status_dt" is null then '' else '"' || to_char(new."status_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when new."name" is null then '' else '"' || replace(replace(cast(new."name" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."inv_fund_source_id" is null then '' else '"' || cast(cast(new."inv_fund_source_id" as numeric) as varchar) || '"' end||','||
          case when new."payment_plan_id" is null then '' else '"' || cast(cast(new."payment_plan_id" as numeric) as varchar) || '"' end; 
                                    var_old_data := 
          case when old."id" is null then '' else '"' || cast(cast(old."id" as numeric) as varchar) || '"' end||','||
          case when old."comment" is null then '' else '"' || replace(replace(cast(old."comment" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when old."date" is null then '' else '"' || to_char(old."date", 'YYYY-MM-DD HH24:MI:SS.US') || '"' end||','||
          case when old."number" is null then '' else '"' || replace(replace(cast(old."number" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when old."period" is null then '' else '"' || to_char(old."period", 'YYYY-MM-DD HH24:MI:SS.US') || '"' end||','||
          case when old."sum" is null then '' else '"' || cast(cast(old."sum" as numeric) as varchar) || '"' end||','||
          case when old."termination_date" is null then '' else '"' || to_char(old."termination_date", 'YYYY-MM-DD HH24:MI:SS.US') || '"' end||','||
          case when old."price_list_id" is null then '' else '"' || cast(cast(old."price_list_id" as numeric) as varchar) || '"' end||','||
          case when old."type_id" is null then '' else '"' || cast(cast(old."type_id" as numeric) as varchar) || '"' end||','||
          case when old."financing_type_id" is null then '' else '"' || cast(cast(old."financing_type_id" as numeric) as varchar) || '"' end||','||
          case when old."beginning_date" is null then '' else '"' || to_char(old."beginning_date", 'YYYY-MM-DD HH24:MI:SS.US') || '"' end||','||
          case when old."is_executed" is null then '' when old."is_executed" then '"1"' else '"0"' end||','||
          case when old."status_id" is null then '' else '"' || cast(cast(old."status_id" as numeric) as varchar) || '"' end||','||
          case when old."status_dt" is null then '' else '"' || to_char(old."status_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when old."name" is null then '' else '"' || replace(replace(cast(old."name" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when old."inv_fund_source_id" is null then '' else '"' || cast(cast(old."inv_fund_source_id" as numeric) as varchar) || '"' end||','||
          case when old."payment_plan_id" is null then '' else '"' || cast(cast(old."payment_plan_id" as numeric) as varchar) || '"' end; 
                                    if 1=1 then 
                                    insert into "public".sym_data                                                                                                                     
                                    (table_name, event_type, trigger_hist_id, pk_data, row_data, old_data, channel_id, transaction_id, source_node_id, external_data, create_time)                     
                                    values(                                                                                                                                                            
                                      'fin_contract',                                                                                                                                            
                                      'U',                                                                                                                                                             
                                      38,                                                                                                                                             
                                      
          case when old."id" is null then '' else '"' || cast(cast(old."id" as numeric) as varchar) || '"' end,                                                                                                                                                      
                                      var_row_data,                                                                                                                                                      
                                      var_old_data,                                                                                                                                                   
                                      'public_fin_contract_default',                                                                                                                                                
                                      txid_current(),                                                                                                                                               
                                      "public".sym_node_disabled(),                                                                                                                   
                                      null,                                                                                                                                               
                                      CURRENT_TIMESTAMP                                                                                                                
                                    );                                                                                                                                                                 
                                  end if;                                                                                                                                                              
                                  end if;                                                                                                                                                              
                                                                                                                                                                               
                                  return null;                                                                                                                                                         
                                end;
$fun$;

