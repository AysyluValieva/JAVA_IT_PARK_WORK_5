CREATE FUNCTION setappointment_v6(_idappointment character varying, _department_id character varying, _idpdat character varying, _doctorreferals character varying)
  RETURNS TABLE(success boolean, type text)
LANGUAGE plpgsql
AS $$
/*
Изменения внесены по 12.10.2017
Предыдущая версия: "jenkins"."setappointment_v4"
Суть изменения: 
Убрать дату для услуг, поскльку мешает работе отчетов.
было:
insert into sr_srv_rendered(id, service_id, bdate, edate, is_rendered, org_id, customer_id, res_group_id)
values(_id_srv, _service_id, _bdatetime::date, _edatetime::date, false, _org_id::integer, _idpdat::integer,_res_group_id);
стало
insert into sr_srv_rendered(id, service_id,  is_rendered, org_id, customer_id, res_group_id)
values(_id_srv, _service_id,  false, _org_id::integer, _idpdat::integer,_res_group_id);

+ добавление в md_appointment_log
*/
 
DECLARE
  _bdatetime TIMESTAMP;
  _edatetime TIMESTAMP;
  _service_id integer;
  _id integer;
  _res_group_id integer;
  _id_srv integer;
  _profile_message varchar;
	_org_id integer;
BEGIN
 
if( upper(_idappointment)='NULL::TEXT' or upper(_idappointment)='NULL' or _idappointment='') then  _idappointment=NULL; end if;
   if( upper(_department_id)='NULL::TEXT'  or upper(_department_id)='NULL' or _department_id='' ) then  _department_id=NULL; end if;
    if( upper(_idpdat)='NULL::TEXT'  or upper(_idpdat)='NULL' or _idpdat='') then  _idpdat=NULL; end if;
     if( upper(_doctorreferals)='NULL::TEXT'  or upper(_doctorreferals)='NULL' or _doctorreferals='') then  _doctorreferals=NULL; end if;
 
--если  _department_id > 10 000 000, то это _department_id,  иначе _id_lpu
if(_department_id is not null and _department_id::INTEGER > 10000000)
then 
	_org_id=null;
	_department_id = substr(_department_id::text, 2, 8)::integer;
	select org_id into _org_id from pim_department where id=_department_id::INTEGER;
else 
	_org_id = _department_id;
	_department_id=null;
end if;



if exists (
select 1 from sr_session ss
join sr_shift s on ss.shift_id=s.id
join  sr_timetable t ON s.timetable_id=t.id
join sr_timetable_res_group trg on t.id=trg.id
join sr_res_group rg on trg.res_group_id=rg.id
join md_appointment ma on ma.executor_id=rg.id and ss.bdatetime=ma.bdatetime
where ss.id=_idappointment::integer and ma.state_id not in (1,4) limit 1) THEN
 RAISE EXCEPTION 'К специалисту на указанное время записан другой пациент'; END IF;
 
 
select into _bdatetime bdatetime from sr_session ss
 where ss.id=_idappointment::integer limit 1;
 
select into _edatetime edatetime from sr_session ss
 where ss.id=_idappointment::integer limit 1;
   
select into _service_id   sr_schedule_rule_srv.service_id
from sr_session ss
join sr_shift shift on shift.id=ss.shift_id
join sr_timetable st on st.id=shift.timetable_id
join sr_timetable_res_group str on str.id=st.id
--join sr_session_service sss on ss.id=sss.service_id
join sr_res_group_service srgs on str.res_group_id = srgs.group_id and srgs.default_service = true
	join sr_schedule_rule on sr_schedule_rule.schedule_id=shift."schedule_id"
	join sr_schedule_rule_srv on sr_schedule_rule_srv.schedule_rule_id =sr_schedule_rule.id
where ss.id=_idappointment::integer
order by srgs.srv_type_id desc
limit 1;
 
 
if( _service_id is null )
then  select into _service_id   srgs.srv_type_id
from sr_session ss
join sr_shift shift on shift.id=ss.shift_id
join sr_timetable st on st.id=shift.timetable_id
join sr_timetable_res_group str on str.id=st.id
--join sr_session_service sss on ss.id=sss.service_id
join sr_res_group_service srgs on str.res_group_id = srgs.group_id -- and srgs.default_service = true
			--join sr_schedule_rule on sr_schedule_rule.schedule_id=shift."schedule_id"
			--join sr_schedule_rule_srv on sr_schedule_rule_srv.schedule_rule_id =sr_schedule_rule.id
where ss.id=_idappointment::integer
order by srgs.srv_type_id desc
limit 1; end if;
 
 
select into _res_group_id  str.res_group_id
from sr_session ss
join sr_shift shift on shift.id=ss.shift_id
join sr_timetable st on st.id=shift.timetable_id
join sr_timetable_res_group str on str.id=st.id
--join sr_session_service sss on ss.id=sss.service_id
 where ss.id=_idappointment::integer
limit 1;
 
select into _profile_message  case
when upper(name) like '%ТЕРАП%' or upper(name) like '%ПЕДИАТР%'
then 'широкого_профиля'
else 'узкий'
end  from sr_res_group where id=_res_group_id::integer;
 
_id=nextval('md_appointment_seq');
_id_srv=nextval('sr_srv_rendered_seq');
 
insert into sr_srv_rendered(id, service_id,  is_rendered, org_id, customer_id, res_group_id)
values(_id_srv, _service_id,  false, _org_id::integer, _idpdat::integer,_res_group_id);
 
 
insert into md_srv_rendered (id, is_urgent)
values (_id_srv, false);
 
if( _doctorreferals is null)
then
          insert into sr_ticket ( id) values (_id);
       
          insert into md_appointment (
          id
          , bdatetime
          , state_id
          , service_id
          , is_urgent
          ,customer_id
          ,organization_id
          ,edatetime
          ,executor_id
          ,source_id
          ,srv_rendered_id
 
, ticket_number
)
          values (_id
          , _bdatetime
          , 2 --запланирована
          , _service_id
          ,false
          ,_idpdat::integer
          ,_org_id::integer
          ,_edatetime
          ,_res_group_id
          ,0
          ,_id_srv
,_id::character varying
);
  INSERT into md_appointment_log (id, appointment_id, dt, source_id, state_id)
                values(nextval('md_appointment_log_seq'), _id, CURRENT_TIMESTAMP,1,2);
          RAISE NOTICE 'Добавлен md_appointment = %', _id;
          return query ( select true::BOOLEAN as "success", _profile_message::text as "type");
 
insert into sr_session_ticket (session_id, ticket_id) select _idappointment::integer, _id;
 
else
           
          insert into sr_ticket ( id) values (_id);
         
          insert into md_appointment (id, bdatetime, state_id, service_id, is_urgent,customer_id,organization_id,edatetime
            , referral_id
            ,funding_id
            ,executor_id
            ,source_id
            ,srv_rendered_id
          )
          select _id  , _bdatetime, 2 , _service_id, false, _idpdat::integer,_org_id::integer,_edatetime --_idpdat
          ,_doctorreferals::integer
          ,funding_id
          ,_res_group_id
          ,0
          ,_id_srv
          from md_referral
          where id=_doctorreferals::integer
          ;
           INSERT into md_appointment_log (id, appointment_id, dt, source_id, state_id)
                values(nextval('md_appointment_log_seq'), _id, CURRENT_TIMESTAMP,1,2);
            insert into sr_session_ticket (session_id, ticket_id) select _idappointment::integer, _id;
 
RAISE NOTICE 'Добавлен md_appointment = %', _id;
return query ( select true::BOOLEAN as "success", _profile_message::text as "type");
end if;
 
 
END;
$$;

