CREATE FUNCTION set_contraindication(xepid integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
begin

	  UPDATE gibdd.md_gibdd_reference
          SET is_contraindications=false where id = xepid and not exists(select 1 from gibdd.md_gibdd_service gs
                left join mc_diagnosis mcd on gs.diagnos_id = mcd.id
                left join md_diagnosis md on mcd.diagnos_id = md.id
                where gs.event_patient_id = xepid
                and (md.code like 'F00%' or md.code like 'F01%' or md.code like 'F02%'
                or md.code like 'F03%' or md.code like 'F04%' or md.code like 'F05%'
                or md.code like 'F06%' or md.code like 'F07%' or md.code like 'F08%'
                or md.code like 'F09%' or md.code like 'F10%' or md.code like 'F11%'
                or md.code like 'F12%' or md.code like 'F13%' or md.code like 'F14%'
                or md.code like 'F15%' or md.code like 'F16%'
                or md.code like 'F18%' or md.code like 'F19%' or md.code like 'F20%'
                or md.code like 'F21%' or md.code like 'F22%' or md.code like 'F23%'
                or md.code like 'F24%' or md.code like 'F25%' or md.code like 'F26%'
                or md.code like 'F27%' or md.code like 'F28%' or md.code like 'F29%'
                or md.code like 'F30%' or md.code like 'F31%' or md.code like 'F32%'
                or md.code like 'F33%' or md.code like 'F34%' or md.code like 'F35%'
                or md.code like 'F36%' or md.code like 'F37%' or md.code like 'F38%'
                or md.code like 'F39%'
                or md.code like 'F70%' or md.code like 'F71%' or md.code like 'F72%'
                or md.code like 'F73%' or md.code like 'F74%' or md.code like 'F75%'
                or md.code like 'F76%' or md.code like 'F77%' or md.code like 'F78%'
                or md.code like 'F79%'
                or md.code='G40'
                or md.code='H54.0'
                or md.code like 'F40%' or md.code like 'F41%' or md.code like 'F42%'
                or md.code like 'F43%' or md.code like 'F44%' or md.code like 'F45%'
                or md.code like 'F46%' or md.code like 'F47%' or md.code like 'F48%'
                or md.code like 'F60%' or md.code like 'F61%' or md.code like 'F62%'
                or md.code like 'F63%' or md.code like 'F64%' or md.code like 'F65%'
                or md.code like 'F66%' or md.code like 'F67%' or md.code like 'F68%'
                or md.code like 'F69%'
                or md.code='H53.1'));

          UPDATE gibdd.md_gibdd_reference
          SET is_contraindications=true where id = xepid and exists(select 1 from gibdd.md_gibdd_service gs
                left join mc_diagnosis mcd on gs.diagnos_id = mcd.id
                left join md_diagnosis md on mcd.diagnos_id = md.id
                where gs.event_patient_id = xepid
                and (md.code like 'F00%' or md.code like 'F01%' or md.code like 'F02%'
                or md.code like 'F03%' or md.code like 'F04%' or md.code like 'F05%'
                or md.code like 'F06%' or md.code like 'F07%' or md.code like 'F08%'
                or md.code like 'F09%' or md.code like 'F10%' or md.code like 'F11%'
                or md.code like 'F12%' or md.code like 'F13%' or md.code like 'F14%'
                or md.code like 'F15%' or md.code like 'F16%'
                or md.code like 'F18%' or md.code like 'F19%' or md.code like 'F20%'
                or md.code like 'F21%' or md.code like 'F22%' or md.code like 'F23%'
                or md.code like 'F24%' or md.code like 'F25%' or md.code like 'F26%'
                or md.code like 'F27%' or md.code like 'F28%' or md.code like 'F29%'
                or md.code like 'F30%' or md.code like 'F31%' or md.code like 'F32%'
                or md.code like 'F33%' or md.code like 'F34%' or md.code like 'F35%'
                or md.code like 'F36%' or md.code like 'F37%' or md.code like 'F38%'
                or md.code like 'F39%'
                or md.code like 'F70%' or md.code like 'F71%' or md.code like 'F72%'
                or md.code like 'F73%' or md.code like 'F74%' or md.code like 'F75%'
                or md.code like 'F76%' or md.code like 'F77%' or md.code like 'F78%'
                or md.code like 'F79%'
                or md.code='G40'
                or md.code='H54.0'
                or md.code like 'F40%' or md.code like 'F41%' or md.code like 'F42%'
                or md.code like 'F43%' or md.code like 'F44%' or md.code like 'F45%'
                or md.code like 'F46%' or md.code like 'F47%' or md.code like 'F48%'
                or md.code like 'F60%' or md.code like 'F61%' or md.code like 'F62%'
                or md.code like 'F63%' or md.code like 'F64%' or md.code like 'F65%'
                or md.code like 'F66%' or md.code like 'F67%' or md.code like 'F68%'
                or md.code like 'F69%'
                or md.code='H53.1'));

        end;
$$;

