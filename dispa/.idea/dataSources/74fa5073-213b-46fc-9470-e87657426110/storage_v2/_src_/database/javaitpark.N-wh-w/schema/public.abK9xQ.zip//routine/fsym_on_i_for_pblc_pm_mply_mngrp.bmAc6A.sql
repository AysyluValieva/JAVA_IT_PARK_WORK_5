CREATE FUNCTION fsym_on_i_for_pblc_pm_mply_mngrp()
  RETURNS trigger
LANGUAGE plpgsql
AS $fun$
begin                                                                                                                                                                  
                                   
                                  if 1=1 and "public".sym_triggers_disabled() = 0 then                                                                                                 
                                    insert into "public".sym_data                                                                                                                     
                                    (table_name, event_type, trigger_hist_id, row_data, channel_id, transaction_id, source_node_id, external_data, create_time)                                        
                                    values(                                                                                                                                                            
                                      'pim_employee',                                                                                                                                            
                                      'I',                                                                                                                                                             
                                      473,                                                                                                                                             
                                      
          case when new."id" is null then '' else '"' || cast(cast(new."id" as numeric) as varchar) || '"' end||','||
          case when new."note" is null then '' else '"' || replace(replace(cast(new."note" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."number" is null then '' else '"' || replace(replace(cast(new."number" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."photo" is null then '' else '"' || replace(replace(cast(new."photo" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."callup_subject_id" is null then '' else '"' || cast(cast(new."callup_subject_id" as numeric) as varchar) || '"' end||','||
          case when new."individual_id" is null then '' else '"' || cast(cast(new."individual_id" as numeric) as varchar) || '"' end||','||
          case when new."organization_id" is null then '' else '"' || cast(cast(new."organization_id" as numeric) as varchar) || '"' end||','||
          case when new."is_dismissed" is null then '' when new."is_dismissed" then '"1"' else '"0"' end||','||
          case when new."employment_dt" is null then '' else '"' || to_char(new."employment_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when new."dismissal_dt" is null then '' else '"' || to_char(new."dismissal_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end,                                                                                                                                                      
                                      'public_pim_employee_default',                                                                                                                                                
                                      txid_current(),                                                                                                                                               
                                      "public".sym_node_disabled(),                                                                                                                   
                                      null,                                                                                                                                               
                                      CURRENT_TIMESTAMP                                                                                                                
                                    );                                                                                                                                                                 
                                  end if;                                                                                                                                                              
                                                                                                                                                                               
                                  return null;                                                                                                                                                         
                                end;
$fun$;

