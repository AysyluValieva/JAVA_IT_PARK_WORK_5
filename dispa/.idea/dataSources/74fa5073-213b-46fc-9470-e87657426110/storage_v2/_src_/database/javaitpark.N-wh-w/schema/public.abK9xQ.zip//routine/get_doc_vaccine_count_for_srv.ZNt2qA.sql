CREATE FUNCTION get_doc_vaccine_count_for_srv(srv_id integer)
  RETURNS text
LANGUAGE plpgsql
AS $$
declare
  i integer;
begin
  RETURN 

(select trim(to_char(spec.val,'999999.99'))||' '|| j.mnemocode from mc_inv_opr_srv opr_r 
join inv_opr opr on opr.id=opr_r.opr_id and opr_r.service_id=srv_id
join inv_spec spec on spec.opr_id=opr.id
join inv_holding d on d.id=spec.holding_id
join inv_md_holding e on e.id=d.id
join inv_holding_pharm_group f on f.holding_id=e.id
join inv_pharm_group g on g.id=f.pharm_group_id and g.name in ('0010 Вакцины, сыворотки, фаги и анатоксины','0010 Вакцины, сыворотки, фаги и анатоксины в комбинациях')
join inv_form h on h.holding_id=d.id
join inv_form_type i on i.id=h.form_type_id 
join cmn_measure j on j.id=spec.unit_id
limit 1)
;
end;
$$;

