CREATE FUNCTION fin_spec_validate_bill_main_extended(p1_bill_id integer, p2_user_id integer)
  RETURNS void
STRICT
LANGUAGE plpgsql
AS $$
DECLARE
    _r RECORD;
    _v VARCHAR;
    _validation_code VARCHAR[];
    _validation_enabled BOOLEAN[];
    _validation_title VARCHAR[];
BEGIN
    /*
        current version date 27.10.2014
        
        changelog 
    */
    _validation_code := ARRAY 
    [
        'CLINIC_CODE',            --1
        'CLINIC_CODE_LENGTH',     --2
        'COMMENT_MAX_LENGTH',     --3
        'BILL_NUMBER_MAX_LENGTH', --4
        'PAYER_CODE_LENGTH'       --5
    ];
    FOREACH _v IN ARRAY _validation_code 
    LOOP 
        SELECT 
            coalesce (u.enabled, v.enabled) AS enabled, title INTO _r 
        FROM 
            fin_bill_validation                AS v 
            LEFT JOIN fin_bill_validation_user AS u ON u.validation_id = v.id AND u.user_id = p2_user_id
        WHERE 
            v.code = _v;
        _validation_enabled := _validation_enabled || _r.enabled;
        _validation_title   := _validation_title   || _r.title  ;
    END LOOP;
    
    DELETE FROM fin_bill_spec_item_error AS e WHERE e.code = ANY (_validation_code) AND EXISTS (SELECT 1 FROM fin_bill_spec_item WHERE bill_id = p1_bill_id AND id = e.item_id)
    ;
    FOR _r IN 
        SELECT 
            e.rcp_id, e.rcp_code_oms, e.bill_comment, e.bill_number, e.payer_code_oms, array_agg (i.id) AS item_id_arr
        FROM 
            fin_bill_spec_item AS i, fin_bill_main_extended AS e
        WHERE
            i.bill_id = p1_bill_id AND e.bill_id = i.bill_id
        GROUP BY 1, 2, 3, 4, 5
    LOOP
        IF 
            _validation_enabled[1] AND _r.rcp_code_oms = '' 
        THEN 
            INSERT INTO fin_bill_spec_item_error (id, error, code, item_id)
                SELECT nextval ('fin_bill_spec_item_error_seq'), _validation_title[1], _validation_code[1], unnest (_r.item_id_arr)
            ;
        ELSIF 
            _validation_enabled[2] AND length (_r.rcp_code_oms) <> 6 
        THEN 
            INSERT INTO fin_bill_spec_item_error (id, error, code, item_id)
                SELECT nextval ('fin_bill_spec_item_error_seq'), _validation_title[2], _validation_code[2], unnest (_r.item_id_arr)
            ;
        END IF;
        IF 
            _validation_enabled[3] AND length (_r.bill_comment) > 250 
        THEN 
            INSERT INTO fin_bill_spec_item_error (id, error, code, item_id)
                SELECT nextval ('fin_bill_spec_item_error_seq'), _validation_title[3], _validation_code[3], unnest (_r.item_id_arr)
            ;
        END IF;
        IF 
            _validation_enabled[4] AND length (_r.bill_number) NOT BETWEEN 1 AND 15 
        THEN 
            INSERT INTO fin_bill_spec_item_error (id, error, code, item_id)
                SELECT nextval ('fin_bill_spec_item_error_seq'), _validation_title[4], _validation_code[4], unnest (_r.item_id_arr)
            ;
        END IF;
        IF 
            _validation_enabled[5] AND length (_r.payer_code_oms) NOT BETWEEN 1 AND 5 
        THEN 
            INSERT INTO fin_bill_spec_item_error (id, error, code, item_id)
                SELECT nextval ('fin_bill_spec_item_error_seq'), _validation_title[5], _validation_code[5], unnest (_r.item_id_arr)
            ;
        END IF;
    END LOOP;
END;
$$;

