CREATE FUNCTION check_for_lice(xcontext integer, xmo_ikb integer, xikb_open_date date)
  RETURNS boolean
LANGUAGE plpgsql
AS $$
DECLARE
                       result BOOLEAN;
                      BEGIN
                    WITH RECURSIVE r AS (
                      SELECT id, parent_id, clinic_id FROM motherhood.mh_institutions
                      WHERE clinic_id = xcontext and xikb_open_date between coalesce(begin_dt, '-infinity') and coalesce(end_dt, 'infinity')

                      UNION
                      SELECT z.id, z.parent_id, z.clinic_id FROM motherhood.mh_institutions z, r
                      WHERE z.id = r.parent_id and xikb_open_date between coalesce(z.begin_dt, '-infinity') and coalesce(z.end_dt, 'infinity')
                    )
                    SELECT case when xcontext = xmo_ikb then true else EXISTS(SELECT 1 FROM r WHERE r.clinic_id = xmo_ikb) end INTO result ;

                        RETURN result;
                        END;
$$;

