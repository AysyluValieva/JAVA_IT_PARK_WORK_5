CREATE FUNCTION check_table_has_default_primary_key(_table character varying)
  RETURNS boolean
LANGUAGE plpgsql
AS $$
BEGIN
                  RETURN (SELECT exists(
                      SELECT 1
                      FROM (SELECT
                              a.attname,
                              format_type(a.atttypid, a.atttypmod) AS data_type
                            FROM pg_index i
                              JOIN pg_attribute a ON a.attrelid = i.indrelid AND a.attnum = ANY (i.indkey)
                            WHERE i.indrelid = $1 :: REGCLASS AND i.indisprimary
                            LIMIT 1) t
                      WHERE (SELECT count(*)
                             FROM pg_index i
                               JOIN pg_attribute a ON a.attrelid = i.indrelid AND a.attnum = ANY (i.indkey)
                             WHERE i.indrelid = $1 :: REGCLASS AND i.indisprimary) = 1 AND
                            t.attname = 'id' AND t.data_type = 'integer'));
                END;
$$;

