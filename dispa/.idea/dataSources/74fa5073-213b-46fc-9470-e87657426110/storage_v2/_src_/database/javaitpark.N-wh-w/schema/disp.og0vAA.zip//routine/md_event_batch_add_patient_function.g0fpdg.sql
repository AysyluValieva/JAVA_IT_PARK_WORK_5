CREATE FUNCTION md_event_batch_add_patient_function(xeid integer, patient_ids integer[])
  RETURNS integer[]
LANGUAGE plpgsql
AS $$
declare
          ids integer[];
          jds integer[];
          i integer;
          end_dt date;
          code character varying;

          size integer;
        begin
        end_dt=(select end_date from disp.md_event where id=xeid);
        code=(select et.code from disp.md_event_type et join disp.md_event e on et.id = e.event_type where e.id = xeid);
          size := array_length(patient_ids, 1);
	  FOR  i in  1..size LOOP
	     ids := array_append(ids, nextval('disp.md_event_patient_id_seq')::integer);
	  END LOOP;
          insert into disp.md_event_patient (id, event_id, indiv_id,not_actual_patient, event_age) select ids[index], xeid, patient_ids[index],false,
                          (SELECT CONCAT(date_part('year',age(
                          ( case when ((position('ДВ' in code) = 1)) then end_dt  else now() end)
                          ,birth_dt)), '.', date_part('month',age(birth_dt))) FROM pim_individual where id = patient_ids[index])
           from generate_series(1, size) as index;
          insert into disp.md_event_questioning (id) select id from unnest(ids) as id;
          insert into disp.md_event_anthro (id) select id from unnest(ids) as id;
          insert into disp.md_dispr (id, event_id, indiv_id) select ids[index1], xeid, patient_ids[index1] from generate_series(1, size) as index1;
          if (((position('ДС' in code) = 1) or (position('ОН' in  code) = 1))) then
              insert into disp.md_disp_orphans_result (id, is_before, event_patient_id) select nextval('disp.md_disp_orphans_result_id_seq'), true, ids[index1] from generate_series(1, size) as index1;
              insert into disp.md_disp_orphans_result (id, is_before, event_patient_id) select nextval('disp.md_disp_orphans_result_id_seq'), false, ids[index1] from generate_series(1, size) as index1;
          end if;
          return ids;
        end;
$$;

