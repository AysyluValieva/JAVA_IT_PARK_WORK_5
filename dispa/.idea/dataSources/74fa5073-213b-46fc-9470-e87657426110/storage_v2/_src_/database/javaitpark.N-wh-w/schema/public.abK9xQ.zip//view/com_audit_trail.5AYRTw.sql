CREATE VIEW com_audit_trail AS
  SELECT com_audit_trail.aud_user,
    com_audit_trail.aud_client_ip,
    com_audit_trail.aud_server_ip,
    com_audit_trail.aud_resource,
    com_audit_trail.aud_action,
    com_audit_trail.applic_cd,
    com_audit_trail.aud_date
   FROM dblink('dbname=cas host=127.0.0.1 port=5432 user=cas password=cas'::text, 'SELECT * FROM com_audit_trail'::text) com_audit_trail(aud_user character varying(100), aud_client_ip character varying(100), aud_server_ip character varying(15), aud_resource character varying(100), aud_action character varying(100), applic_cd character varying(5), aud_date timestamp with time zone);

