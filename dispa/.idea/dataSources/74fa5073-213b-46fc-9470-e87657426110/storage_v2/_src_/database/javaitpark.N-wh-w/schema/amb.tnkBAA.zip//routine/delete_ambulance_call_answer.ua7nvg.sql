CREATE FUNCTION delete_ambulance_call_answer(xcall_id integer, xcaller_reason_id integer, xold_caller_reason_id integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
begin
                    if (xcaller_reason_id is not null and xold_caller_reason_id is not null
                    and xcaller_reason_id <> xold_caller_reason_id)
                    then
                    delete from amb.md_ambulance_call_answer where call_id = xcall_id;
                    end if;
                end;
$$;

