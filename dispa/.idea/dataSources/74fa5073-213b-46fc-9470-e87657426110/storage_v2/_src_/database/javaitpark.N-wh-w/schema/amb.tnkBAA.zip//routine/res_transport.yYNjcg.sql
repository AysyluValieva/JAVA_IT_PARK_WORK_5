CREATE FUNCTION res_transport(xres boolean, xid integer, xfrom_dt date)
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
    xresid integer;
    xstate integer;
  begin
  	If xres is true
    	then
        	if (select state_id from amb.pim_transport_state where transport_id = xid order by from_dt desc limit 1) not in (select id from pim_stock_unit_state where code = '51')
            --not exists (select state_id from amb.pim_transport_state where transport_id = xid and state_id = (select id from pim_stock_unit_state where code = '51'))
            	then
            		if not EXISTS(select id from amb.pim_transport_resource where transport_id = xid)
                    	then
                    		xresid = nextval('sr_resource_seq');
		    				insert into sr_resource (id,power,res_kind_id,code)
  								values(xresid,NULL,5,xresid);
		   					insert into amb.pim_transport_resource (resource_id,transport_id)
    							values (xresid,xid);
                    end if;
		    		xstate = (select id from pim_stock_unit_state where code = '51');
		    		insert into amb.pim_transport_state (transport_id,state_id,from_dt)
						values(xid,xstate,xfrom_dt);
            end if;
        else
        	if (select to_dt from amb.pim_transport where id = xid) is null and
				(select state_id from amb.pim_transport_state where transport_id = xid order by from_dt desc limit 1) not in (select id from pim_stock_unit_state where code = '53') and
                exists (select state_id from amb.pim_transport_state where transport_id = xid and state_id = (select id from pim_stock_unit_state where code = '51'))
                then
            		xstate = (select id from pim_stock_unit_state where code = '53');
        			insert into amb.pim_transport_state (transport_id,state_id,from_dt)
						values(xid,xstate,xfrom_dt);
            end if;
    end if;
  end;
$$;

