CREATE FUNCTION searchtop10patient_v2(_name text DEFAULT NULL::text, _secondname text DEFAULT NULL::text, _surname text DEFAULT NULL::text, _department_id integer DEFAULT NULL::integer)
  RETURNS TABLE(arianumber integer, birthday date, cellphone text, document_n text, document_s text, homephone text, idpat text, name text, polis_n text, polis_s text, secondname text, surname text)
LANGUAGE plpgsql
AS $$
DECLARE
-- v_rec jenkins.typ_searchtop10patient%ROWTYPE;
_id_lpu integer;
BEGIN
if(_department_id > 10000000)
then 
	_id_lpu=null;
	_department_id = substr(_department_id::text, 2, 8)::integer;
else 
	_id_lpu = _department_id;
	_department_id=null;
end if;  
    
  if( upper(_name)='NULL::TEXT' or upper(_name)='NULL' or _name='') then  _name=NULL; end if;
   if( upper(_surname)='NULL::TEXT'  or upper(_surname)='NULL' or _surname='' ) then  _surname=NULL; end if;
    if( upper(_secondname)='NULL::TEXT'  or upper(_secondname)='NULL' or _secondname='') then  _secondname=NULL; end if;
return query (
  with main as (select  distinct
 					ppr.patient_id,
 					ppr.district_id,--AriaNumber
 					pi.name,
                    pi.surname,--Surname
                    pi.patr_name, --SecondName
                    pi.birth_dt,	 --Birthday
										pic.indiv_id 
    ,get_phone(pic.indiv_id, 2) mob
    ,get_phone(pic.indiv_id, 3) dom
 					from pci_patient_reg ppr
                    join pim_individual pi on ppr.patient_id=pi.id    
                    left join pim_individual_doc pid on pi.id=pid.indiv_id  
										    join pim_indiv_contact pic on pic.indiv_id=pi.id
                    where 
										case  when _department_id is null then ppr.clinic_id=_id_lpu  else   ppr.department_id=_department_id::integer end 							
                    and pi.name ilike COALESCE(_name, '%') 
                    and pi.surname ilike COALESCE(_surname, '%') 
                    and pi.patr_name ilike COALESCE(_secondname, '%')   
										limit 10
                   -- and ppr.patient_id=6060824--
 )
 --select * from main

 select 
 distinct
 main.district_id::integer as "arianumber"--AriaNumber
 ,main.birth_dt::date as "birthday"--Birthday
 , mob::text as cellphone
 , jenkins.get_doc(main.patient_id, 13, false)::text as "document_n"--Document_N
 ,jenkins.get_doc(main.patient_id, 13, true)::text as "document_s"--Document_S
 ,dom::text as "homephone"--HomePhone
 ,main.patient_id::text as "idpat"--IdPat
 ,main.name::text --Name
 , COALESCE( jenkins.get_doc(main.patient_id, 24, false), jenkins.get_doc(main.patient_id, 26, false))::text  as "polis_n"--Polis_N
 ,  jenkins.get_doc(main.patient_id, 24, true)::text as "polis_s"--Polis_S
 ,main.patr_name::text as "secondname"--SecondName
 ,main.surname::text as "surname" --Surname
 from main
 limit 10
 );
 

  
END;
$$;

