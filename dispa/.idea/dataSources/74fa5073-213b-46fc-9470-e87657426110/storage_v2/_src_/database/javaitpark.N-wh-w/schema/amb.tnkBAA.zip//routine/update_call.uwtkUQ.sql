CREATE FUNCTION update_call(xcall integer, xis_group_sufferer boolean, xis_psycho boolean, xsum_sufferer integer, xcaller_reason_id integer, xreason_diag integer, xreason_note character varying, xcall_place_id integer, xcall_place_note character varying, xplace_org_id integer, xplace_department_id integer, xaddress_id integer, xhouse character varying, xhousing character varying, xapartment character varying, xporch character varying, xfloor character varying, xdoor_code character varying, xdescription character varying, xto_org_id integer, xto_department_id integer, xto_address_id integer, xto_house character varying, xto_housing character varying, xto_apartment character varying, xto_porch character varying, xto_description character varying, xpatient_id integer, xsurname character varying, xname character varying, xpatrname character varying, xbirthdt date, xgender integer, xis_chronic boolean, xage_years integer, xage_months integer, xage_days integer, xphone_caller character varying, xcaller_id integer, xemployee_id integer, xcaller_note character varying, xpriority_id integer, xpriority integer, xcontrol integer, xnote character varying, xregistrator_id integer, xbrg_id integer, xemp_id integer, xparcal integer, xdesk_id integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
                                                priorsum integer;
                                                xstation_id integer;
                                                xsubstation_id integer;

                                                xcallnote integer;
                                                xnum integer;
                                              begin
                                                    select into xnum call_number from amb.md_ambulance_call where id = xcall;
                                                    if (xpatient_id is null)
                                                        then
                                                            xpatient_id = amb.create_pat_vrem (xsurname,xname,xpatrname,xbirthdt,xgender);
                                                            update public.pci_patient set
                                                                note = note||', '||(select short_name from pim_organization where id = xstation_id)||', вызов №'||cast(xnum as varchar(6))||' от '||(select to_char(from_data,'dd.mm.yyyy') from amb.md_ambulance_change where id = xcall_dt)
                                                                where id = xpatient_id;
                                                        else
                                                            if xpatient_id = (select patient_id from amb.md_ambulance_call where id = xcall)
                                                                then
                                                                    update pim_individual set surname = xsurname, name = xname, patr_name = xpatrname, birth_dt = xbirthdt,gender_id = xgender where id = xpatient_id;
                                                                else
                                                                    update amb.md_ambulance_call set patient_id = xpatient_id,age_years = xage_years,age_months = xage_months,age_days = xage_days where id = xcall;
                                                            end if;
                                                    end if;
                                                    update amb.md_ambulance_call set
                                                                caller_reason_id = xcaller_reason_id,
                                                                reason_diag = xreason_diag,
                                                                reason_note = xreason_note,
                                                                is_group_sufferer = xis_group_sufferer,
                                                                sum_sufferer = xsum_sufferer,
                                                                call_place_id = xcall_place_id,
                                                                call_place_note = xcall_place_note,
                                                                place_org_id = xplace_org_id,
                                                                place_department_id = xplace_department_id,
                                                                address_id  = xaddress_id,
                                                                house = xhouse,
                                                                housing = xhousing,
                                                                apartment = xapartment,
                                                                porch = xporch,
                                                                floor = xfloor,
                                                                door_code = xdoor_code,
                                                                description = xdescription,
                                                                to_org_id = xto_org_id,
                                                                to_department_id = xto_department_id,
                                                                to_address_id = xto_address_id,
                                                                to_house = xto_house,
                                                                to_housing = xto_housing,
                                                                to_apartment = xto_apartment,
                                                                to_porch = xto_porch,
                                                                to_description = xto_description,
                                                                patient_id = xpatient_id,
                                                                is_chronic = xis_chronic,
                                                                age_years = xage_years,
                                                                age_months = xage_months,
                                                                age_days = xage_days,
                                                                phone_caller = xphone_caller,
                                                                caller_id = xcaller_id,
                                                                caller_note = xcaller_note,
                                                                employee_id = xemployee_id,
                                                                note = xnote,
                                                                desk_id = xdesk_id
                                                     where id = xcall;
                                                    priorsum = amb.priority_calculation(xcall,xregistrator_id);

                                                    -- отметка госпитализации
                                                    -- IF ((xcall_kind_id in (3,4)) or (xto_org_id is not null))
                                                    IF (xto_org_id is not null) and not exists (select * from amb.md_ambulance_call_note where call_id = xcall and note_id = 21 and note_type = true and note_active = true)
                                                        THEN
                                                            xcallnote = amb.add_call_note(xcall,21,true,null,'а/у госпитализация',xregistrator_id,null);
                                                        ELSE
                                                            if (xto_org_id is null)	and exists (select * from amb.md_ambulance_call_note where call_id = xcall and note_id = 21 and note_type = true and note_active = true)
                                                                then
                                                                    xcallnote = amb.add_call_note(xcall,21,false,null,'а/у госпитализация',xregistrator_id,null);
                                                                end if;
                                                    END IF;
                                                    /*
                                                    -- автодобавление отметок
                                                    select into xstation_id,xsubstation_id station_id, substation_id from amb.md_ambulance_call where id = xcall;
                                                    execute amb.auto_add_call_note (xcall,xcaller_reason_id,xreason_diag,xis_psycho,xregistrator_id,xstation_id,xsubstation_id);
                                                    */
                                              end;

$$;

