CREATE FUNCTION partition_insert_sr_scgenerated_y2015_m12_r16(r sr_scgenerated)
  RETURNS integer
LANGUAGE plpgsql
AS $$
BEGIN INSERT INTO schedule.sr_scgenerated_y2015_m12_r16 SELECT r.*; RETURN 1;END
$$;

