CREATE FUNCTION upd_team_template(xid integer, xorg integer, xcode character varying, xname character varying, xteam_kind integer, xjob_kind integer, xteam_type integer, xprof integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
  begin
  	update amb.sr_res_team_template set org_id=xorg,code = xcode,name = xname,team_kind_id=xteam_kind,job_kind_id=xjob_kind,team_type_id=xteam_type where id = xid;
    if xprof is not null
    then
    	If EXISTS (select * from amb.sr_res_team_template_profile where team_template_id = xid)
    	then
    		update amb.sr_res_team_template_profile set profile_id = xprof where team_template_id = xid;
    	else
    		insert into amb.sr_res_team_template_profile(team_template_id,profile_id) values (xid,xprof);
    	end if;
    else
    	delete from amb.sr_res_team_template_profile where team_template_id = xid;
    end if;
  end;
$$;

