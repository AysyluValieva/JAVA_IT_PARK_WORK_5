CREATE FUNCTION func_md_room_profile_sync_pim_room_and_md_bed()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
/*
при создании/редактировании/удалении профиля палаты изменим палаты и койки что бы пересобрать все ограничения hospital.unused_bed
*/
BEGIN
    IF (TG_OP = 'DELETE') THEN
        -- при удалении профиля ПАЛАТЫ почистим все исключения
        update pim_room set id = id where id = OLD.room_id;
        update md_bed set room_id = room_id where room_id = OLD.room_id;
        RETURN OLD;
    ELSE
        IF (TG_OP = 'UPDATE' and  OLD.room_id <> NEW.room_id) THEN
            update pim_room set id = id where id = OLD.room_id;
            update md_bed set room_id = room_id where room_id = OLD.room_id;
        END IF;
        update pim_room set id = id where id = NEW.room_id;
        update md_bed set room_id = room_id where room_id = NEW.room_id;
        RETURN NEW;
    END IF;
END;
$$;

