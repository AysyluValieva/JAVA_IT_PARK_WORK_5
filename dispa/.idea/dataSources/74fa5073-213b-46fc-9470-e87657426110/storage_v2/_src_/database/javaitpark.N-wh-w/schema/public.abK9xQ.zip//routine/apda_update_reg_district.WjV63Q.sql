CREATE FUNCTION apda_update_reg_district(pci_patient_reg_id integer, active_address_code character varying)
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
  r               RECORD;
  info            apda_reg_info;
  new_district_id INTEGER;
BEGIN
  SELECT *
  INTO r
  FROM pci_patient_reg
  WHERE id = $1;

  IF r ISNULL
  THEN RAISE EXCEPTION 'Не найдено прикрепления [id = %]', $1; END IF;

  IF r.state_id = 2 OR r.is_assertion
  THEN RETURN; END IF;
  IF r.patient_id ISNULL
  THEN RAISE EXCEPTION 'Для прикрепления [id = %] не указан пациент', r.id; END IF;
  IF r.clinic_id ISNULL
  THEN RAISE EXCEPTION 'Для прикрепления [id = %] не указана МО', r.id; END IF;
  IF r.type_id ISNULL
  THEN RAISE EXCEPTION 'Для прикрепления [id = %] не указан вид прикрепления', r.id; END IF;
  IF r.unreg_dt < current_date
  THEN RAISE EXCEPTION 'Для прикрепления [id = %] указана дата открепления предшествующяя текущей', r.id; END IF;
  IF r.reg_dt ISNULL
  THEN r.reg_dt = current_date; END IF;

  info = apda_get_patient_reg_info(r.id, $2);

  IF (info).patient.death_dt NOTNULL AND r.reg_dt > (info).patient.death_dt
  THEN RAISE EXCEPTION 'Для прикрепления [id = %] дата прикрепления больше даты смерти пациента', r.id;
  END IF;

  new_district_id = apda_get_district_id(info);

  IF new_district_id NOTNULL
  THEN
    UPDATE pci_patient_reg
    SET
      district_id = new_district_id,
      district_by_addr_id = (CASE WHEN district_by_addr_id ISNULL THEN NULL ELSE new_district_id END)
    WHERE id = $1;

    RETURN;
  END IF;

  RAISE EXCEPTION 'Для прикрепления [id = %] не найден участок для прикрепления по входным условиям', r.id;
END;
$$;

