CREATE FUNCTION md_sicklist_migrate_to_n2o(p_id integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
DECLARE
  sl_old public.md_sicklist;
  period_old public.md_sicklist_period;
  sl_new_id INTEGER;
  l_issued_employee_position VARCHAR;
  l_witness_employee_position VARCHAR;
  l_sanatorium_id INTEGER;
  l_parent_id INTEGER;
  l_is_update BOOLEAN;
  l_family_member_1_id INTEGER;
  l_family_member_2_id INTEGER;
  l_begin_dt DATE;
  l_days INTEGER;
  l_end_dt DATE;
  l_registrator_id INTEGER;
BEGIN
  SELECT *
    FROM md_sicklist
    WHERE id = p_id
    INTO sl_old;

  sl_new_id = NULL;
  --Ищем id санатория по ОГРН-коду
  l_sanatorium_id = NULL;
  SELECT o.id
      FROM pim_organization o
      JOIN pim_org_code poc ON poc.org_id = o.id
      JOIN pim_code_type poct ON poct.id=poc.type_id
      WHERE poc.code=sl_old.sanatorium_ogrn_code AND poct.code='OGRN' AND poc.code NOTNULL AND poc.code<>'' AND  sl_old.sanatorium_ogrn_code NOTNULL LIMIT 1
  INTO l_sanatorium_id;

  --Ищем родительский ЛН
  l_parent_id = NULL;
  SELECT id FROM sickdoc.sickdoc
    WHERE md_sicklist_id = sl_old.parent_id
    INTO l_parent_id;

  SELECT EXISTS(
    SELECT 1 FROM sickdoc.sickdoc
      WHERE md_sicklist_id = sl_old.id)
    INTO l_is_update;

  IF l_is_update THEN

  ELSE

    INSERT INTO sickdoc.sickdoc
    (id,case_id,clinic_id,final_diagnosis_id,hospital_from_dt,hospital_to_dt,individual_id,initial_diagnosis_id,issue_dt,
    journal_id,kind_id,number,ready_to_work_dt, ready_to_work_other_dt, ready_to_work_other_id, state_id, transfer_to_o_clinic,
    transfer_from_clinic, workplace_id, workplace_print, workplace_type_id, type_id, md_sicklist_id, parent_id )
    VALUES
    (DEFAULT,sl_old.case_id,sl_old.clinic_id,sl_old.final_diagnosis_id,sl_old.hospital_from_dt,sl_old.hospital_to_dt,sl_old.patient_id,sl_old.initial_diagnosis_id,sl_old.issue_dt,
    null,1,sl_old.code,sl_old.ready_to_work_dt, sl_old.ready_to_work_other_dt, sl_old.ready_to_work_other_id, sl_old.state_id,  COALESCE(sl_old.transfer_to_o_clinic, FALSE),
    COALESCE(sl_old.transfer_from_clinic, FALSE), sl_old.workplace_id, sl_old.workplace_print, sl_old.workplace_type_id, sl_old.type_id, sl_old.id, l_parent_id )
    RETURNING id
        INTO sl_new_id;

    INSERT INTO sickdoc.sickdoc_extended
    (id, disability_from_dt, disability_reason_edited_id, disability_reason_ext_id, disability_reason_id,
    disability_to_dt,is_disability_group_changed, is_early_pregnancy_register, mse_examination_dt, mse_org_id,
    mse_referral_dt, mse_register_dt, on_placement_service, regimen_violation_doctor_id, regimen_violation_dt,
    regimen_violation_id, sanatorium_ogrn_code, voucher_code, sanatorium_id, family_member_1_id, family_member_2_id,
    family_member_1_relation_id_lsd, family_member_1_age_lsd, family_member_1_age_month_lsd, family_member_1_name_lsd,
    family_member_2_relation_id_lsd, family_member_2_age_lsd, family_member_2_age_month_lsd, family_member_2_name_lsd)
    VALUES
    (sl_new_id, sl_old.disability_from_dt, sl_old.disability_reason_edited_id, sl_old.disability_reason_ext_id, sl_old.disability_reason_id,
    sl_old.disability_to_dt, COALESCE(sl_old.is_disability_group_changed,FALSE), COALESCE(sl_old.is_early_pregnancy_register, FALSE), sl_old.mse_examination_dt, sl_old.mse_org_id,
    sl_old.mse_referral_dt, sl_old.mse_register_dt, COALESCE(sl_old.on_placement_service, FALSE), sl_old.regimen_violation_doctor_id, sl_old.regimen_violation_dt,
    sl_old.regimen_violation_id, sl_old.sanatorium_ogrn_code, sl_old.voucher_code, l_sanatorium_id, null, null,
      sl_old.family_member_1_relation_id, sl_old.family_member_1_age, sl_old.family_member_1_age_month, sl_old.family_member_1_name,
    sl_old.family_member_2_relation_id, sl_old.family_member_2_age, sl_old.family_member_2_age_month, sl_old.family_member_2_name);

    FOR period_old IN (SELECT * FROM public.md_sicklist_period WHERE sicklist_id = sl_old.ID )
    LOOP

      l_issued_employee_position = NULL;
      SELECT trim(replace(replace(upper(pp.name),'ВРАЧ',''),'-',' '))
        FROM pim_employee_position pep
      JOIN pim_position pp ON pp.ID = pep.position_id WHERE pep.ID=period_old.employee_position_id limit 1
      INTO l_issued_employee_position;

      l_witness_employee_position = NULL;
      SELECT trim(replace(replace(upper(pp.name),'ВРАЧ',''),'-',' '))
        FROM pim_employee_position pep
      JOIN pim_position pp ON pp.ID = pep.position_id WHERE pep.ID=period_old.witness_employee_position_id limit 1
      INTO l_witness_employee_position;

      INSERT INTO sickdoc.period
        (id,clinic_id,from_dt,to_dt, issued_employee_id, issued_employee_position,
         witness_employee_id, witness_employee_position, sickdoc_id )
      VALUES
        (DEFAULT,sl_old.clinic_id,period_old.from_dt, period_old.to_dt, period_old.employee_position_id, l_issued_employee_position,
        period_old.witness_employee_position_id, l_witness_employee_position, sl_new_id );
    END LOOP;

    --Обновление периода и регистратора
    l_registrator_id = NULL;
      l_begin_dt = NULL;
    SELECT from_dt, issued_employee_id
          FROM sickdoc.period
          WHERE sickdoc_id = sl_new_id
          ORDER BY from_dt ASC
          LIMIT 1
    INTO l_begin_dt, l_registrator_id;

    l_end_dt = NULL;
      l_end_dt = (SELECT to_dt
              FROM sickdoc.period
              WHERE sickdoc_id = sl_new_id
              ORDER BY to_dt DESC
              LIMIT 1);

    l_days = NULL;
      IF l_begin_dt NOTNULL AND l_end_dt NOTNULL AND l_begin_dt<=l_end_dt THEN
        l_days = cast((l_end_dt - l_begin_dt) as integer);
      END IF;

      UPDATE sickdoc.sickdoc
      SET
        begin_dt       = l_begin_dt,
        end_dt         = l_end_dt,
        days           = l_days,
        registrator_id = l_registrator_id
      WHERE id = sl_new_id;
    --Обновление периода

  END IF;

  RETURN sl_new_id;

END;
$$;

