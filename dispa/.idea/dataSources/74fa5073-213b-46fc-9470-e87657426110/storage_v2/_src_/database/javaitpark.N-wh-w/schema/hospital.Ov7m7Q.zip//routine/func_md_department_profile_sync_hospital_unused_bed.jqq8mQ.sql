CREATE FUNCTION func_md_department_profile_sync_hospital_unused_bed()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
/*
при создании/редактировании/удалении профиля подразделения перезазапишем все исключения возможности использования коек в КФ
если профиль подразделения ограничен датами создания и закрытия
если профиль ограничен датами создания и закрытия
*/
DECLARE
    rez             INTEGER;
    _department_id  INTEGER;
    _profile_id     INTEGER;
BEGIN
    IF ((TG_OP = 'DELETE') OR (TG_OP = 'UPDATE' and (OLD.department_id IS DISTINCT FROM NEW.department_id OR OLD.profile_id IS DISTINCT FROM NEW.profile_id))) THEN
        -- если мы удаляем или изменяем в текущей записи значение department_id или profile_id, определим что делать с исключениями по профилю
        WITH w_tree as (
             SELECT  distinct
                     d.id,
                     dp.id,
                     p.id,
                     d.id :: TEXT :: LTREE || p.id :: TEXT || p.id :: TEXT AS bed_tree,
                     dp.from_dt - 1 as from_dt,
                     dp.to_dt,
                     unnest(array[(dp.from_dt - 1), dp.to_dt]) as dt_dt
             FROM    md_department_profile dp
                     JOIN pim_department d ON d.id = dp.department_id
                     JOIN md_profile p ON p.id = dp.profile_id
             WHERE   department_id = OLD.department_id AND profile_id = OLD.profile_id
                     AND dp.id <> OLD.id -- найдем все состояния профиля кроме текущего профиля подразделения который будет удален
             UNION ALL
             SELECT
                     d.id,
                     dp.id,
                     p.id,
                     d.id :: TEXT :: LTREE || p.id :: TEXT AS bed_tree ,
                     p.from_dt - 1 as from_dt,
                     p.to_dt,
                     unnest(array[(p.from_dt - 1), p.to_dt]) as dt_dt
             FROM    md_department_profile dp
                     JOIN pim_department d ON d.id = dp.department_id
                     JOIN md_profile p ON p.id = dp.profile_id
             WHERE   department_id = OLD.department_id AND profile_id = OLD.profile_id
                     AND dp.id <> OLD.id -- найдем все состояния профиля кроме текущего профиля подразделения который будет удален
            ),

        w_tree_sort as (
            select  *, sum(sort) over (partition by bed_tree, dt_dt order by bed_tree, from_dt, sort, dt_dt, sort_name) as dd -- количество открытий и закрытий в один день
            FROM    (
                select  bed_tree, from_dt, sort, dt_dt, sort_name, LAG (sort, 1, 0) over (partition by bed_tree order by bed_tree, from_dt, sort, dt_dt, sort_name) as sort_lag, LEAD (sort, 1, -1) over (partition by bed_tree order by bed_tree, from_dt, sort, dt_dt, sort_name) as sort_lead
                from    (
                    select  bed_tree, from_dt, 2 as sort, dt_dt, 'begin' as sort_name from w_tree where from_dt is not null
                    UNION ALL
                    select  bed_tree, to_dt, 1, dt_dt, 'end' from w_tree where to_dt is not null
                    GROUP BY 1, 2, 3, 4, 5
                    order by 1, 2, 3, 4, 5
                    )t
                )t
            ),

        w_tree_new as  (-- расчетное состояние исключений по подразделению и профилю
            select  bed_tree, daterange(null, from_dt, '[]') as date_range, concat('по ', to_char(from_dt, 'dd.mm.yyyy'), ' этот профиль подразделения недоступен') as comment from w_tree_sort where sort_lag = 0 and sort = 2
            UNION ALL
            select  bed_tree, daterange(from_dt, null, '[]') as date_range, concat('с ', to_char(from_dt, 'dd.mm.yyyy'), ' этот профиль подразделения недоступен') as comment from w_tree_sort where sort_lag = 0 and sort_lead = -1 and sort = 1
            UNION ALL
            select  bed_tree, daterange(from_dt, lead_dt, '[]') as date_range, concat('c ', to_char(from_dt, 'dd.mm.yyyy'), ' по ' || to_char(lead_dt, 'dd.mm.yyyy'), ' этот профиль подразделения недоступен')
            from   (
                select *, lead(from_dt) over (partition by bed_tree order by bed_tree, from_dt) as lead_dt
                from w_tree_sort
                where --sort_lag <> 0
                    sort <> coalesce(sort_lag, 0)
                order by 1, 2, 3
                )t
            WHERE   sort = 1
                --and from_dt IS DISTINCT FROM  lead_dt
                and coalesce(from_dt, lead_dt) <= coalesce(lead_dt, from_dt)
            ),

        w_tree_bd as (
            with param (bed_tree2) as (
                values
                    (OLD.department_id :: TEXT :: LTREE || OLD.profile_id :: TEXT || OLD.profile_id :: TEXT),
                    (OLD.department_id :: TEXT :: LTREE || OLD.profile_id :: TEXT)
            )
            select id, bed_tree, date_range, comment
            from param join hospital.unused_bed on bed_tree = bed_tree2
            ),

        w_tree_delta as (
            select  bed_tree as delta_bed_tree, date_range as delta_date_range, comment as delta_comment,
                sum(delta) as delta -- 1 - есть только в новом состоянии, добавляем в дельта
                                    -- 2 - есть только в бд, удаляем
                                    -- 3 - есть и там и там, ничего не делаем
            from (
                select distinct bed_tree, date_range, comment, 1 as delta from w_tree_new
                union all
                select bed_tree, date_range, comment, 2 as delta from w_tree_bd
                )t
            group by bed_tree, date_range, comment
            ),

        del_w_tree_bd as (
            delete from hospital.unused_bed using w_tree_delta
            WHERE bed_tree = delta_bed_tree and date_range = delta_date_range and comment = delta_comment
                and delta = 2
            RETURNING 1
            ),

        ins_w_tree_bd as (
            insert into hospital.unused_bed (bed_tree, date_range, comment)
            select delta_bed_tree, delta_date_range, delta_comment from w_tree_delta where delta = 1
            RETURNING 1
            )
        select 1 into REZ;

        IF (TG_OP = 'DELETE') THEN
            RETURN OLD;
        END IF;
    END IF;
    IF (TG_OP <> 'DELETE') THEN
        -- если было изменение подразделения или профиля в текущем профиле подразделения то мы старые значения уже пересчитали, остается заполнить новое состояние
        WITH w_tree as (
                    SELECT  distinct
                            d.id,
                            dp.id,
                            p.id,
                            d.id :: TEXT :: LTREE || p.id :: TEXT || p.id :: TEXT AS bed_tree,
                            dp.from_dt - 1 as from_dt,
                            dp.to_dt,
                            unnest(array[(dp.from_dt - 1), dp.to_dt]) as dt_dt
                    FROM    md_department_profile dp
                            JOIN pim_department d ON d.id = dp.department_id
                            JOIN md_profile p ON p.id = dp.profile_id
                    WHERE   department_id = NEW.department_id AND profile_id = NEW.profile_id
                    UNION ALL
                    SELECT
                            d.id,
                            dp.id,
                            p.id,
                            d.id :: TEXT :: LTREE || p.id :: TEXT AS bed_tree ,
                            p.from_dt - 1 as from_dt,
                            p.to_dt,
                            unnest(array[(p.from_dt - 1), p.to_dt]) as dt_dt
                    FROM    md_department_profile dp
                            JOIN pim_department d ON d.id = dp.department_id
                            JOIN md_profile p ON p.id = dp.profile_id
                    WHERE   department_id = NEW.department_id AND profile_id = NEW.profile_id
                    ),

        w_tree_sort as (
            select  *, sum(sort) over (partition by bed_tree, dt_dt order by bed_tree, from_dt, sort, dt_dt, sort_name) as dd -- количество открытий и закрытий в один день
            FROM    (
                select  bed_tree, from_dt, sort, dt_dt, sort_name, LAG (sort, 1, 0) over (partition by bed_tree order by bed_tree, from_dt, sort, dt_dt, sort_name) as sort_lag, LEAD (sort, 1, -1) over (partition by bed_tree order by bed_tree, from_dt, sort, dt_dt, sort_name) as sort_lead
                from    (
                    select  bed_tree, from_dt, 2 as sort, dt_dt, 'begin' as sort_name from w_tree where from_dt is not null
                    UNION ALL
                    select  bed_tree, to_dt, 1, dt_dt, 'end' from w_tree where to_dt is not null
                    GROUP BY 1, 2, 3, 4, 5
                    order by 1, 2, 3, 4, 5
                    )t
                )t
            ),

        w_tree_new as  (-- расчетное состояние исключений по подразделению и профилю
            select  bed_tree, daterange(null, from_dt, '[]') as date_range, concat('по ', to_char(from_dt, 'dd.mm.yyyy'), ' этот профиль подразделения недоступен') as comment from w_tree_sort where sort_lag = 0 and sort = 2
            UNION ALL
            select  bed_tree, daterange(from_dt, null, '[]') as date_range, concat('с ', to_char(from_dt, 'dd.mm.yyyy'), ' этот профиль подразделения недоступен') as comment from w_tree_sort where sort_lag = 0 and sort_lead = -1 and sort = 1
            UNION ALL
            select  bed_tree, daterange(from_dt, lead_dt, '[]') as date_range, concat('c ', to_char(from_dt, 'dd.mm.yyyy'), ' по ' || to_char(lead_dt, 'dd.mm.yyyy'), ' этот профиль подразделения недоступен')
            from    (
                select *, lead(from_dt) over (partition by bed_tree order by bed_tree, from_dt) as lead_dt
                from w_tree_sort
                where --sort_lag <> 0
                     sort <> coalesce(sort_lag, 0)
                order by 1, 2, 3
                )t
            WHERE   sort = 1
                --and from_dt IS DISTINCT FROM  lead_dt
                and coalesce(from_dt, lead_dt) <= coalesce(lead_dt, from_dt)
        ),

        w_tree_bd as (
            with param (bed_tree2) as (
                values
                    (NEW.department_id :: TEXT :: LTREE || NEW.profile_id :: TEXT || NEW.profile_id :: TEXT),
                    (NEW.department_id :: TEXT :: LTREE || NEW.profile_id :: TEXT)
            )
            select id, bed_tree, date_range, comment from param
                    join hospital.unused_bed on bed_tree = bed_tree2
            ),

        w_tree_delta as (
            select  bed_tree as delta_bed_tree, date_range as delta_date_range, comment as delta_comment,
                sum(delta) as delta -- 1 - есть только в новом состоянии, добавляем в дельта
                                    -- 2 - есть только в бд, удаляем
                                    -- 3 - есть и там и там, ничего не делаем
            from (
                select distinct bed_tree, date_range, comment, 1 as delta from w_tree_new
                union all
                select bed_tree, date_range, comment, 2 as delta from w_tree_bd
                )t
            group by bed_tree, date_range, comment
            ),

        del_w_tree_bd as (
            delete from hospital.unused_bed using w_tree_delta
            WHERE bed_tree = delta_bed_tree and date_range = delta_date_range and comment = delta_comment
                and delta = 2
            RETURNING 1
            ),

        ins_w_tree_bd as (
            insert into hospital.unused_bed (bed_tree, date_range, comment)
            select delta_bed_tree, delta_date_range, delta_comment from w_tree_delta where delta = 1
            RETURNING 1
            )
        select 1 into REZ;
        RETURN NEW;
    END IF;
END;
$$;

