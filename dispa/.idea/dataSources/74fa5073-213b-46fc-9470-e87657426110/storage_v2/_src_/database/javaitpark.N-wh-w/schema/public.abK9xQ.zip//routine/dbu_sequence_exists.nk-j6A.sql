CREATE FUNCTION dbu_sequence_exists(sequencename character varying)
  RETURNS boolean
LANGUAGE plpgsql
AS $$
declare result boolean;
            begin

            select count(*) > 0 into result
            from pg_class
            inner join pg_namespace on pg_class.relnamespace = pg_namespace.oid
            and pg_namespace.nspname !~ '^(pg_|information_schema)'
            where pg_class.relkind = 'S'
            and pg_class.relname = lower($1);

            return result;
            end;
$$;

