CREATE FUNCTION sickdoc_create_new(p_date_begin date, p_date_end date, p_clinic_id integer, p_patient_id integer, p_case_id integer, p_md_main_diagnosis_id integer, p_emplpos_id integer, p_issued_for_care_of boolean, p_individual_id integer, p_family_relation_id1 integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
DECLARE
  c_sickdoc_kind_code CONSTANT VARCHAR := '1';
  c_care_for_family_member_code CONSTANT VARCHAR = '09';
  c_sickdoc_status_code CONSTANT VARCHAR := '1'; --Новый
  c_sickdoc_type_code CONSTANT VARCHAR := '1'; --Первичный
  c_default_disability_reason_id CONSTANT INTEGER := (SELECT id FROM md_sl_disability_reason WHERE code = '01'); --Заболевание
  l_sickdoc_status_id INTEGER := (SELECT id FROM md_sicklist_state WHERE code = c_sickdoc_status_code);
  l_care_for_family_member_id INTEGER := (SELECT id FROM md_sl_disability_reason WHERE code = c_care_for_family_member_code);
  l_sickdoc_kind_id INTEGER := (SELECT id from sickdoc.rf_kind WHERE code = c_sickdoc_kind_code);
  l_sickdoc_type_id INTEGER := (SELECT id from md_sicklist_type WHERE code = c_sickdoc_type_code);
  l_sickdok_id INTEGER;
BEGIN
--   создаем ЛН
  INSERT INTO sickdoc.sickdoc
  (begin_dt, end_dt, issue_dt, clinic_id, individual_id, case_id, initial_diagnosis_id, final_diagnosis_id, state_id, kind_id, registrator_id,
   transfer_to_o_clinic, type_id, workplace_type_id, transfer_from_clinic)
  VALUES
    (
      p_date_begin,
      p_date_end,
      p_date_begin,
      p_clinic_id,
      (CASE when p_issued_for_care_of NOTNULL and p_issued_for_care_of then p_individual_id ELSE p_patient_id end),
      p_case_id,
      p_md_main_diagnosis_id,
      p_md_main_diagnosis_id,
      l_sickdoc_status_id,
      l_sickdoc_kind_id,
      p_emplPos_id,
      FALSE,
      l_sickdoc_type_id,
      1,
      FALSE
    )
  RETURNING id INTO l_sickdok_id;

--   добавляем запись в екстенд
  INSERT INTO sickdoc.sickdoc_extended
    (id, disability_reason_id, disability_from_dt, disability_to_dt, is_disability_group_changed,
    is_early_pregnancy_register, on_placement_service)
  VALUES
    (
      l_sickdok_id ,
      (CASE
        when p_issued_for_care_of NOTNULL and p_issued_for_care_of
          then l_care_for_family_member_id
          ELSE c_default_disability_reason_id
       end),
      p_date_begin,
      p_date_end,
      FALSE,
      FALSE,
      FALSE
    );

--   добавляем период
  INSERT INTO sickdoc.period
  (sickdoc_id, from_dt, to_dt, clinic_id, issued_employee_id)
  VALUES
    (
      l_sickdok_id,
      p_date_begin,
      p_date_end,
      p_clinic_id,
      p_emplPos_id
    );
  PERFORM sickdoc.sickdoc_calculate_and_set_range_dates_and_duration(l_sickdok_id);

  IF p_issued_for_care_of NOTNULL and p_issued_for_care_of
  THEN
    PERFORM sickdoc.family_member_update(
      l_sickdok_id, c_care_for_family_member_code, p_patient_id, p_family_relation_id1, NULL, NULL);
  END IF;

  RETURN l_sickdok_id;
END;
$$;

