CREATE FUNCTION update_disease(xid integer, xcode character varying, xlabel character varying, xecode character varying, xsimpledisease character varying)
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE

                  xsimplediseaseid json;
                  child_id integer;
                  child_array integer array;

                BEGIN
                  UPDATE vac_disease SET code = xcode, label = xlabel, e_code = xecode WHERE id = xid;

                    if (xsimpledisease is not null) then

                      FOR child_id IN SELECT child FROM vac_disease2disease WHERE self = xid
                        LOOP
                            if child_id not in (select value::text::int from json_array_elements(cast(xsimpledisease as json)))
                            then
                                delete from vac_disease2disease where self = xid and child = child_id;
                            end if;
                        END LOOP;

                      foreach xsimplediseaseid in array array(select value from json_array_elements(cast(xsimpledisease as json)))
                        LOOP
                            if not exists (select * from vac_disease2disease where child = xsimplediseaseid::text::int and self = xid)
                            then
                                insert into vac_disease2disease (self, child) values (xid, xsimplediseaseid::text::int);
                            end if;
                        END LOOP;
                      else
                      	delete from vac_disease2disease where self = xid;
                  end if;
                END;
$$;

