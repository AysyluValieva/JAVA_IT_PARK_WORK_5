CREATE FUNCTION extended_refbook_search(q character varying)
  RETURNS TABLE(id integer, params character varying)
LANGUAGE plpgsql
AS $$
declare
  t record;
  qq text;qqq text;
  t1 record;
begin
  qq = '';
  for t in select irb.*, rbc.name id_column_name from mdm_internal_refbook irb, mdm_refbook_column rbc
  where irb.identifier_column_id = rbc.id and exists (select 1 from pg_tables where tablename = irb.table_name)
  and exists (select 1 from information_schema.columns where table_name = irb.table_name and column_name = rbc.name)
  loop
    for t1 in select rbc.name, rbv.id version_id from mdm_refbook_column rbc, mdm_refbook_version rbv, cmn_domain dmn, cmn_domain_type dmntype
            where rbc.refbook_version_id = rbv.id
            and rbc.domain_id = dmn.id
            and dmn.type_id = dmntype.id
            and dmntype.code = 'java.lang.String'
            and rbv.refbook_id = t.id
            and exists (select 1 from information_schema.columns where table_name = t.table_name and column_name = rbc.name)
    loop
	qqq = ' union
        select irb.id, (''{"type":"record","filterValue":"' || t1.name || '","refbookId":"'' || irb.id || ''","versionId":'' || rbv.id || '',"id":"'' || '||t.table_name || '.' || t.id_column_name ||
            ' || ''","match":'' || ''"'' || '||t.table_name||'.' || t1.name || ' || ''"'' || ''}'')::varchar from mdm_internal_refbook irb, mdm_refbook rb, mdm_refbook_version rbv, '
        || t.table_name
        || ' where rb.id = irb.id and rb.id = rbv.refbook_id and irb.table_name = ''' || t.table_name || ''''
        || ' and lower('||t.table_name||'.' || t1.name || '::varchar) like lower(''%' || q || '%'')'
        || ' and mdm_table_record__is_actual(''' || t1.version_id || ''', ' || t.table_name||'.' || t.id_column_name || '::varchar)';
        if (qqq is not null) then
	      qq = qq || qqq;
        end if;
    end loop;
  end loop;
  --raise notice '%', qq;

  return query execute

    'select rb.id, (''{"type":"table","id":"'' || rb.id || ''","match":'' || ''"'' || rb.short_name || ''"'' || ''}'')::varchar
        from mdm_refbook rb
        left join mdm_internal_refbook irb on rb.id = irb.id
        left join mdm_external_refbook erb on rb.id = erb.id
        where lower(rb.short_name) like lower(''%' || q || '%'')
    union
    select rb.id, (''{"type":"table","id":"'' || rb.id || ''","match":'' || ''"'' || rb.full_name || ''"'' || ''}'')::varchar
        from mdm_refbook rb
        left join mdm_internal_refbook irb on rb.id = irb.id
        left join mdm_external_refbook erb on rb.id = erb.id
        where lower(rb.full_name) like lower(''%' || q || '%'')
    union
    select rb.id, (''{"type":"table","id":"'' || rb.id || ''","match":'' || ''"'' || coalesce(irb.table_name, erb.code, '''') || ''"'' || ''}'')::varchar
        from mdm_refbook rb
        left join mdm_internal_refbook irb on rb.id = irb.id
        left join mdm_external_refbook erb on rb.id = erb.id
        where lower(erb.code) like lower(''%' || q || '%'')' ||
        ' or (lower(irb.table_name) like lower(''%' || q || '%'') and exists (select 1 from pg_tables where tablename = irb.table_name))' || '

    union
    select rb.id, (''{"type":"record","filterValue":"'' || rbc.name || ''","refbookId":"'' || rb.id || ''","versionId":'' || rbv.id || '',"id":'' || rc.id || '',"match":'' || ''"'' || rc.value || ''"'' || ''}'')::varchar
    from mdm_refbook rb
        inner join mdm_refbook_version rbv on rbv.refbook_id = rb.id
        inner join mdm_record r on r.refbook_version_id = rbv.id
        inner join mdm_record_column rc on rc.record_id = r.id
        inner join mdm_refbook_column rbc on rc.column_id = rbc.id
        where rbc.refbook_version_id = rbv.id and lower(rc.value) like lower(''%' || q || '%'')
    union
    select rb.id, (''{"type":"column","refbookId":"'' || rb.id || ''","versionId":'' || rbv.id || '',"id":'' || rbc.id || '',"match":'' || ''"'' || rbc.name || ''"'' ||  ''}'')::varchar
        from mdm_refbook rb
        inner join mdm_refbook_version rbv on rb.id = rbv.refbook_id
        inner join mdm_refbook_column rbc on rbv.id = rbc.refbook_version_id
        where lower(rbc.name) like lower(''%' || q || '%'')
    union
    select rb.id, (''{"type":"column","refbookId":"'' || rb.id || ''","versionId":'' || rbv.id || '',"id":'' || rbc.id || '',"match":'' || ''"'' || rbc.title || ''"'' ||  ''}'')::varchar
        from mdm_refbook rb
        inner join mdm_refbook_version rbv on rb.id = rbv.refbook_id
        inner join mdm_refbook_column rbc on rbv.id = rbc.refbook_version_id
        where lower(rbc.title) like lower(''%' || q || '%'')'
    || qq;
end;
$$;

