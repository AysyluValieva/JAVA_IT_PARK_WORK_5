CREATE FUNCTION validatehealthgrouporphans(xepid integer, xhealthgroup integer, xbefore boolean)
  RETURNS boolean
LANGUAGE plpgsql
AS $$
declare
                            countDiagnosis integer;
                        begin

                            if (xhealthgroup!=1) then  return true; else
                                countDiagnosis = (select  count(mdd.code) from disp.md_disp_orphans_result mdor
                                                     left join disp.md_disp_orphans_diagnosis_extended mdode on mdode.result_id = mdor.id
                                                     inner join MC_DIAGNOSIS mcd on mcd.id = mdode.id
                                                     left join md_diagnosis mdd on mdd.id = mcd.diagnos_id
                                                    where mdor.event_patient_id=xepid and mdd.code not like 'Z%' and mdor.is_before = xbefore);
                                if (countDiagnosis >0) then return false; end if;

                            end if ;
                    return true;
            end;
$$;

