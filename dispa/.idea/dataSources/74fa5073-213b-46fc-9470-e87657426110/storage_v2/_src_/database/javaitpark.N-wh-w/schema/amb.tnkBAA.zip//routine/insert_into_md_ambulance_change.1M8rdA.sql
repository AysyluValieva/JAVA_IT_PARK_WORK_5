CREATE FUNCTION insert_into_md_ambulance_change(xdate timestamp with time zone, xorg integer, xdep integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
                                el record;
                                xchange integer;
                                to_dt timestamp;
                                xset integer;

                                xclin integer;
                                xroute integer;
                                xchbegin TIME WITHOUT TIME ZONE;
                                xchperiod INTERVAL;
                              begin
                                select into xset,xroute,xchbegin,xchperiod id,route_id,change_begin,change_period
                                    from amb.md_ambulance_change_setting where clinic_id = xorg and (department_id = COALESCE(xdep, 0) or department_id is null) order by department_id limit 1;

                                  if not exists (select * from amb.md_ambulance_change where clinic_id = xorg and COALESCE(department_id, 0) = COALESCE(xdep, 0) and from_data = cast(xdate as date))
                                    THEN
                                      to_dt = cast(CAST(xdate as date)||' '||CAST(xchbegin as time without time zone) as timestamp) + xchperiod;
                                      xchange = nextval('amb.md_ambulance_change_id_seq');
                                      insert into amb.md_ambulance_change (id,setting_id,clinic_id,route_id,department_id,from_data,from_time,to_data,to_time,state)
                                         values (xchange,xset, xorg, xroute,xdep,cast(xdate as date),cast(xchbegin as time),cast(to_dt as date),cast(to_dt as time),0);
                                    else
                                        xchange := (select id from amb.md_ambulance_change where clinic_id = xorg and COALESCE(department_id, 0) = COALESCE(xdep, 0) and from_data = cast(xdate as date));
                                  end if;
                                return xchange;
                              end;

$$;

