CREATE FUNCTION del_team_template(xid integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
begin
                            If exists (select * from amb.sr_res_team where team_template_id = xid)
                              then
                                update amb.sr_res_team_template set close_dt = now() where id = xid;
                              else
                                delete from amb.sr_res_team_template_profile where team_template_id = xid;
                                --/*16.06.2015*/ также удаление из настроек состава шаблона (sr_res_team_template_employer,sr_res_team_template_transport)
                                delete from amb.sr_res_team_template_employer where team_template_id = xid;
                                delete from amb.sr_res_team_template_transport where team_template_id = xid;
                                --/*--16.06.2015*/
                                delete from amb.sr_res_team_template where id = xid;
                            end if;
                          end;
$$;

