CREATE FUNCTION age(timestamp without time zone)
  RETURNS interval
STABLE
STRICT
PARALLEL SAFE
COST 1
LANGUAGE SQL
AS $$
select pg_catalog.age(cast(current_date as timestamp without time zone), $1)
$$;

