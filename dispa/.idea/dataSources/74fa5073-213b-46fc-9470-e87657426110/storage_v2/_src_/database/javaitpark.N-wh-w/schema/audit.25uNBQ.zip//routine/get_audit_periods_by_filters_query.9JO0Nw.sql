CREATE FUNCTION get_audit_periods_by_filters_query(_table_setting_id integer, _record_id character varying)
  RETURNS character varying
LANGUAGE plpgsql
AS $$
DECLARE
                  setting_record        RECORD;
                  count_records         INTEGER;
                  base_query            VARCHAR;
                  sub_query             VARCHAR;
                  dates                 DATE [];
                  begin_date            DATE;
                  end_date              DATE;
                  partition_period_code VARCHAR;
                  shift                 VARCHAR;
                BEGIN
                  SELECT *
                  INTO setting_record
                  FROM audit.table_setting t
                  WHERE t.id = _table_setting_id;

                  IF _record_id NOTNULL
                  THEN
                    _record_id = trim(_record_id);
                    IF setting_record.is_has_default_primary_key
                    THEN
                      IF _record_id LIKE 'id:%'
                      THEN _record_id = trim(split_part(_record_id, ':', 2)); END IF;
                      IF _record_id ~ '^[0-9]+$' = FALSE
                      THEN RAISE EXCEPTION 'BAD_REQUEST'; END IF;
                      sub_query = concat('AND t.id = ', _record_id);
                    ELSE
                      sub_query = concat(' AND ', replace(replace(_record_id, '[;]', ''' AND '), '[:]', '::VARCHAR = '''), '''');
                    END IF;

                    BEGIN
                      EXECUTE format('SELECT count(*) FROM %1$s t WHERE 1=1 %2$s',
                                     concat(setting_record.table_schema, '.', setting_record.table_name), sub_query)
                      INTO count_records;

                      EXCEPTION WHEN OTHERS THEN
                      RAISE EXCEPTION 'BAD_REQUEST';
                    END;

                    IF count_records = 1
                      THEN
                        EXECUTE format('SELECT ARRAY[aud_when_create :: DATE, aud_when :: DATE] FROM %1$s t WHERE 1=1 %2$s',
                                       concat(setting_record.table_schema, '.', setting_record.table_name), sub_query)
                        INTO dates;

                        IF dates [1] ISNULL
                        THEN begin_date = '-infinity';
                        ELSE begin_date = dates [1]; END IF;
                        IF dates [2] ISNULL
                        THEN end_date = 'infinity';
                        ELSE end_date = dates [2]; END IF;
                    ELSE
                      begin_date = '-infinity';
                      end_date = 'infinity';
                    END IF;
                  END IF;

                  SELECT lower(t.code)
                  INTO partition_period_code
                  FROM audit.partition_period t
                  WHERE t.id = setting_record.partition_period_id;

                  IF partition_period_code = 'none'
                  THEN
                    RAISE EXCEPTION 'ALL_TIME';
                  ELSE
                    IF partition_period_code = 'quarter'
                    THEN shift = '3 month';
                    ELSE shift = concat('1 ', partition_period_code);
                    END IF;
                  END IF;

                  base_query = format(
                      'SELECT :select
                      FROM (
                             SELECT to_date(replace(table_name, ''%2$s'', ''''), ''YYYY_MM_DD'') AS begin
                             FROM information_schema.tables t
                             WHERE table_type = ''BASE TABLE'' AND table_schema = ''audit'' AND
                                   table_name LIKE ''%3$s''
                             ORDER BY table_name) t',
                      shift,
                      concat(setting_record.table_schema, '$', setting_record.table_name, '$', left(partition_period_code, 1), '_'),
                      concat(setting_record.table_schema, '$', setting_record.table_name, '$', left(partition_period_code, 1), '_%'));

                  IF begin_date NOTNULL
                  THEN base_query =
                  concat(base_query,
                         format(' WHERE t.begin BETWEEN ''%1$s'' AND ''%2$s''
                                      OR (t.begin + INTERVAL ''%3$s'') :: DATE BETWEEN ''%1$s'' AND ''%2$s''
                                      OR ''%1$s'' :: DATE BETWEEN t.begin AND (t.begin + INTERVAL ''%3$s'') :: DATE
                                      OR ''%2$s'' :: DATE BETWEEN t.begin AND (t.begin + INTERVAL ''%3$s'') :: DATE',
                                begin_date, end_date, shift));
                  END IF;

                  RETURN base_query;
                END;
$$;

