CREATE FUNCTION createclaimforrefusal_v3(_department_id character varying, _idpdat character varying, _idappointment character varying)
  RETURNS TABLE(success boolean)
LANGUAGE plpgsql
AS $$
DECLARE
  _id integer;
  _id_ap integer;
	_org_id integer;
BEGIN
/*
Изменения внесены по INC000004063670
Предыдущая версия: "jenkins"."createclaimforrefusal_v2
Суть изменения: добавлено md_appointment.srv_rendered_id=null и удаление из sr_srv_rendered

*/  
if( upper(_idappointment)='NULL::TEXT' or upper(_idappointment)='NULL' or _idappointment='') then  _idappointment=NULL; end if;
   if( upper(_department_id)='NULL::TEXT'  or upper(_department_id)='NULL' or _department_id='' ) then  _department_id=NULL; end if;
    if( upper(_idpdat)='NULL::TEXT'  or upper(_idpdat)='NULL' or _idpdat='') then  _idpdat=NULL; end if;


--если  _department_id > 10 000 000, то это _department_id,  иначе _id_lpu
if(_department_id is not null and _department_id::INTEGER > 10000000)
then 
	_org_id=null;
	_department_id = substr(_department_id::text, 2, 8)::integer;
	select org_id into _org_id from pim_department where id=_department_id::INTEGER;
else 
	_org_id = _department_id;
	_department_id=null;
end if;

  select ticket_id into _id_ap from sr_session_ticket where session_id=_idappointment::integer;

 --меняю статус
delete from sr_srv_rendered where id in (select srv_rendered_id from md_appointment 
																						where id=_id_ap::integer and customer_id=_idpdat::integer and organization_id=_org_id::integer);
update md_appointment set state_id=4, srv_rendered_id=null 
where id=_id_ap::integer and customer_id=_idpdat::integer and organization_id=_org_id::integer;

update md_appointment_log set state_id=4 where appointment_id=_id_ap::integer;

--удаляю запись
delete from sr_session_ticket where ticket_id=_id_ap::integer;

return query(select true); 



END;
$$;

