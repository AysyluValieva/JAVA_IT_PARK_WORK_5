CREATE FUNCTION save_diagnosis(xid integer, xpatientid integer, xcaseid integer, xserviceid integer, xdiagnosiid integer, xdiseasetypeid integer, xtypeid integer, xsuspicion boolean, xmake_d boolean, xregistr_id integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
  mc_diagnosis_seq integer;
  md_dispr_diagnosis_service_id_seq integer;
  pci_dispensary_seq integer;
  dispensaryId integer;
  ssrId integer;
  stepId integer;
  emplPosId integer;
  newDiagnosisId INTEGER;
  _isMain BOOLEAN;
begin
  SELECT is_main into _isMain FROM mc_diagnosis WHERE id = xid;
  select ssr.id,msr.step_id into ssrId,stepId from mc_case mc
    join md_srv_rendered msr on msr.case_id = mc.id
    join sr_srv_rendered ssr on msr.id = ssr.id and ssr.service_id = xserviceId
  where mc.id = xcaseId limit 1;
  emplPosId = (select pes.id from sr_srv_rendered ssr
    join SR_RES_GROUP srg on srg.id = ssr.res_group_id
    join PIM_EMPLOYEE_POSITION pes on pes.id = srg.responsible_id
  where ssr.id = ssrId);
  IF (xtypeid = 1) THEN
    update MC_DIAGNOSIS xmd set type_id = (select id from mc_diagnosis_type xmdt where xmdt.name = 'Сопутствующий' limit 1)
    where case_id = xcaseid  and exists(select 1 from disp.md_dispr_diagnosis_service xmdds where xmdds.diagnosis_id = xmd.id and xmdds.service_id = xserviceid);
  END IF;
  IF (xid is null) THEN
    mc_diagnosis_seq = nextval('mc_diagnosis_seq');
    md_dispr_diagnosis_service_id_seq = nextval('disp.md_dispr_diagnosis_service_id_seq');

    insert into MC_DIAGNOSIS (id, case_id, step_id, patient_id, establishment_date, diagnos_id, disease_type_id, type_id, is_suspicion, is_main, stage_id)
    values (mc_diagnosis_seq, xcaseId, stepId, xpatientId, current_date, xdiagnosIid,
                              xdiseaseTypeId, xtypeId, xsuspicion, FALSE, 3);
    insert into disp.md_dispr_diagnosis_service (id, resource_id, service_id, diagnosis_id)
    values (md_dispr_diagnosis_service_id_seq, null, xserviceId, mc_diagnosis_seq);
    IF xmake_d = TRUE THEN
      pci_dispensary_seq = nextval('pci_dispensary_seq');
      insert into pci_dispensary (id, diagnosis_id, reg_in_dt, clinic_id, reg_in_doctor_id, reg_stage_id, patient_id, nosol_registr_id, srv_rendered_id, med_case_in_id)
      values (pci_dispensary_seq, xdiagnosIid, (select bdate from sr_srv_rendered where id = ssrId),
              (select clinic_id from mc_case where id = xcaseId),
              emplPosId, 1, xpatientId, xregistr_id, ssrId, xcaseId);
      update disp.md_dispr_diagnosis_service set pci_dispensary_id = pci_dispensary_seq where diagnosis_id = mc_diagnosis_seq;
      update disp.md_dispr set is_d = true where id = (select id from disp.md_event_patient where case_id = xcaseId);
    END IF;
    IF (xtypeid = 1 and ssrId is not null)
    THEN
      update md_srv_rendered xmsr set diagnosis_id = xdiagnosiid where xmsr.id = ssrId;
      IF (select not exists(select 1 from mc_step xms JOIN mc_diagnosis xmd ON xmd.id = xms.main_diagnosis_id  WHERE xms.id = stepId and xmd.stage_id = 4))
      THEN
        IF (select (max(msr.id) = ssrId) from md_srv_rendered msr join sr_srv_rendered ssr on msr.id = ssr.id where step_id = stepId and edate = (
          select max(edate) from md_srv_rendered zmsr join sr_srv_rendered zssr on zmsr.id = zssr.id where step_id = stepId))
        THEN
          update mc_step set main_diagnosis_id = mc_diagnosis_seq where id = stepId;
          update mc_diagnosis set is_main = false where step_id = stepId;
          update mc_diagnosis md set is_main = true where md.id = mc_diagnosis_seq;
          IF (select max(id) = stepId from mc_step where case_id = xcaseid and admission_date =
                                                                               (select max(admission_date) FROM mc_step where case_id =xcaseid))
          THEN
            update mc_case set main_diagnos_id = mc_diagnosis_seq where id = xcaseid;
            update mc_diagnosis set is_main = false where case_id = xcaseid;
            update mc_diagnosis set is_main = true where mc_diagnosis.id = mc_diagnosis_seq;
          END IF;
        END IF;
      END IF;
    END IF;
  else
    update MC_DIAGNOSIS set diagnos_id=xdiagnosIid, disease_type_id=xdiseaseTypeId, type_id=xtypeId,
      is_suspicion=xsuspicion
    where id=xid;
    update disp.md_dispr_diagnosis_service set service_id=xserviceId
    where diagnosis_id = xid;
    dispensaryId = (select pci_dispensary_id from disp.md_dispr_diagnosis_service where diagnosis_id = xid);
    IF xmake_d = TRUE THEN
      if (dispensaryId is null) THEN
        pci_dispensary_seq = nextval('pci_dispensary_seq');
        insert into pci_dispensary (id, diagnosis_id, reg_in_dt, clinic_id, reg_in_doctor_id, reg_stage_id, patient_id, nosol_registr_id, srv_rendered_id, med_case_in_id)
        values (pci_dispensary_seq, xdiagnosIid, (select bdate from sr_srv_rendered where id = ssrId),
                (select clinic_id from mc_case where id = xcaseId),
                emplPosId, 1, xpatientId, xregistr_id, ssrId, xcaseId);
        update disp.md_dispr_diagnosis_service set pci_dispensary_id = pci_dispensary_seq where diagnosis_id = xid;
        update disp.md_dispr set is_d = true where id = (select id from disp.md_event_patient where case_id = xcaseId);
      else
        update pci_dispensary set diagnosis_id = xdiagnosIid, nosol_registr_id = xregistr_id where id = dispensaryId;
      end IF;
    ELSE
      update disp.md_dispr_diagnosis_service set pci_dispensary_id = null where diagnosis_id = xid;
      delete from pci_dispensary where id = dispensaryId;
      update disp.md_dispr set is_d = false where id = (select id from disp.md_event_patient where case_id = xcaseId);
    END IF;
    IF (xtypeid = 1 and ssrId is not null)
    THEN
      update md_srv_rendered xmsr set diagnosis_id = xdiagnosiid where xmsr.id = ssrId;
      IF (select not exists(select 1 from mc_step xms JOIN mc_diagnosis xmd ON xmd.id = xms.main_diagnosis_id  WHERE xms.id = stepId and xmd.stage_id = 4))
      THEN
        IF (select (max(msr.id) = ssrId) from md_srv_rendered msr join sr_srv_rendered ssr on msr.id = ssr.id where step_id = stepId and edate = (
          select max(edate) from md_srv_rendered zmsr join sr_srv_rendered zssr on zmsr.id = zssr.id where step_id = stepId))
        THEN
          update mc_step set main_diagnosis_id = xid where id = stepId;
          update mc_diagnosis set is_main = false where step_id = stepId;
          update mc_diagnosis md set is_main = true where md.id = xid;
          IF (select max(id) = stepId from mc_step where case_id = xcaseid and admission_date =
                                                                               (select max(admission_date) FROM mc_step where case_id =xcaseid))
          THEN
            update mc_case set main_diagnos_id = xid where id = xcaseid;
            update mc_diagnosis set is_main = false where case_id = xcaseid;
            update mc_diagnosis md set is_main = true where md.id = xid;
          END IF;
        END IF;
      END IF;
    ELSE
      IF (_isMain)
      THEN
          --Ищем основной диагноз предыдущей услуги в посещении
          WITH maxDate as (
              SELECT max(edate) as dt FROM md_srv_rendered zmsr JOIN sr_srv_rendered zssr ON zmsr.id = zssr.id
              WHERE step_id = stepId AND zmsr.id !=ssrId and
                    exists(SELECT 1 from disp.md_dispr_diagnosis_service mdds JOIN mc_diagnosis md ON mdds.diagnosis_id = md.id
                    where mdds.service_id = zssr.service_id and md.type_id = 1  and md.step_id = stepId)
          ), maxSsrID AS (
              SELECT max(msr.id) as mid FROM maxDate md, md_srv_rendered msr JOIN sr_srv_rendered ssr ON msr.id = ssr.id
              WHERE step_id = stepId AND msr.id != ssrId AND edate = (md.dt) and
                    exists(SELECT 1 from disp.md_dispr_diagnosis_service mdds JOIN mc_diagnosis md ON mdds.diagnosis_id = md.id
                    where mdds.service_id = ssr.service_id and md.type_id = 1  and md.step_id = stepId)
          ), serviceMax AS (
              SELECT service_id FROM maxSsrID msi, sr_srv_rendered ssr2 WHERE ssr2.id = msi.mid
          ), diagnosisList as (
              SELECT mdds2.diagnosis_id FROM serviceMax sm, disp.md_dispr_diagnosis_service mdds2
              WHERE mdds2.service_id = sm.service_id
                    and exists(select 1 from mc_diagnosis mc where mc.id = mdds2.diagnosis_id and mc.step_id = stepId )
          )
          SELECT md.id into newDiagnosisId FROM mc_diagnosis md JOIN diagnosisList dl ON md.id = dl.diagnosis_id
          WHERE md.type_id =1 AND md.step_id = stepId;
          update mc_step set main_diagnosis_id = newDiagnosisId where id = stepId;
          IF (SELECT max(id) = _stepId FROM mc_step WHERE case_id = xcaseid AND admission_date =
                                                                                        (SELECT max(admission_date) FROM mc_step WHERE case_id = xcaseid))
                  THEN
                      update mc_case set main_diagnos_id = newDiagnosisId where id = xcaseid;
                  END IF;
          update mc_diagnosis md set is_main = true where md.id = newDiagnosisId;
      END IF;
      update mc_diagnosis md set is_main = false where md.id = xid;
    END IF;
  end IF;
end;
$$;

