CREATE FUNCTION getworkingtime_v3(_iddoc integer, _department_id integer, _bdate date, _edate date)
  RETURNS TABLE(bdatetime timestamp without time zone, edatetime timestamp without time zone)
LANGUAGE plpgsql
AS $$
/*
TAS000000304944
РЅРµ РІС‹РІРѕРґРёС‚СЊ СЂР°РїРёСЃР°РЅРёРµ СЃ РІС‹РµР·РґРѕРј РЅР° РґРѕРј
РїСЂРµРґС‹РґСѓС‰Р°СЏ "jenkins"."getworkingtime_v2"
*/
            declare
				_attribute_day integer;
				_days int[];
				_query text;
           begin
--РІСЂРµРјРµРЅРЅР°СЏ СЂРµР·СѓР»СЊС‚РёСЂСѓСЋС‰Р°СЏ С‚Р°Р±Р»РёС†Р°
/*
DROP TABLE IF EXISTS  "jenkins"."getworkingtime";
CREATE table "jenkins"."getworkingtime" ("bdate" timestamp, "edate" timestamp);  
--РµСЃС‚СЊ Р»Рё СЂР°РїРёСЃР°РЅРёРµ?       
with all_sessions as (
select ss.bdatetime, ss.edatetime, rg.id rg , ep.employee_id emp
            			from  pim_employee_position ep
                        inner join sr_res_group rg on rg.responsible_id=ep.id
                        join sr_res_group_source srgr on srgr.res_group_id=rg.id
                        join md_appointment_source mas on mas.id=srgr.source_id
                        inner join sr_timetable_res_group trg on trg.res_group_id=rg.id
                        inner join sr_timetable t on t.id=trg.id
                        inner join sr_shift s on s.timetable_id=t.id
                        inner join sr_session ss on ss.shift_id=s.id
												left join sr_session_ticket sst on sst.session_id=ss.id
											left join  sr_session_quotum ssq on ss.id=ssq.session_id
                     where rg.id= _iddoc 
									and ssq.session_id is null 
											and sst.session_id is null
											and s.time_type_id!=2 
											and ss.bdatetime::TIMESTAMP > CURRENT_TIMESTAMP 
											and ss.time_type_id!=2
                     and cast(ss.bdatetime as date)>= _bdate
                     and cast(ss.edatetime as date)<=_edate
                   )
 insert into "jenkins"."getworkingtime" ("bdate" , "edate" )
select distinct all_sessions.bdatetime::TIMESTAMP, all_sessions.edatetime::TIMESTAMP
   from all_sessions
--where all_sessions.bdatetime>=CURRENT_DATE
;
*/
--РµСЃР»Рё СЂР°РїРёСЃР°РЅРёРµ РЅРµС‚, С‚Рѕ СЃРјРѕС‚СЂРёРј РІ Schedule

IF( not EXISTS(select * from getworkingtime_ where id=_iddoc and _bdatetime>= _bdate and _edatetime<=_edate
))
	THEN 
						_query= concat ('									
with _shedul as (
--С‚СѓС‚ СЃРѕР±РёСЂР°СЋС‚СЃСЏ РІСЃРµ РІРѕР·РјРѕР¶РЅС‹Рµ  РїСЂРёР·РЅР°РєРё РґРЅРµР№ РґР»СЏ СЂР°РїРёСЃР°РЅРёСЏ СЂРµСЃСѓСЂСЃР°
select id, min(btime), max(etime), return_period_id, agg ,bdate,edate from (
select  distinct _rule.id, _srv.btime, _srv.etime, _period.return_period_id, "array_agg"(_period.value ) agg , _rule.bdate, _rule.edate
								from sr_res_group _srg
								join sr_schedule_service _service on "_srg".id=_service.res_group_id
								join sr_schedule_rule _rule on "_rule".schedule_id="_service".id
								join cmn_time_event_period _period on _period.time_event_id=_rule.time_event_id
								join sr_schedule_rule_srv _srv on _srv.schedule_rule_id = _rule.id
								--left join sr_schedule_rule_call _call on _call.schedule_rule_id="_rule".id
								where _srg.id=', _iddoc, ' 
								--and "_rule".id=60676
								and _rule.time_type_id=1 	
								and (_rule.edate is null	or _rule.edate  > current_date )	
								and not exists(select 1 from sr_schedule_rule_call where schedule_rule_id="_rule".id and btime=_srv.btime and etime=_srv.etime)
								--and _call.id is null
								GROUP BY _rule.id, _srv.btime, _srv.etime, _period.return_period_id , _rule.bdate, _rule.edate
								order by _rule.id, _srv.btime

)_t group by id,return_period_id, agg , bdate,edate
),
_days as (
--РіРµРЅРµСЂР°С†РёСЏ РґРЅРµР№
select  day, yyyy,mm,dd,number_week,week
from ( select day,  Extract(YEAR from day::date ) AS yyyy
								, Extract(MONTH from day::date ) AS mm
								, Extract(day from day::date ) AS dd
								,Extract(week from day::date ) AS number_week
								,to_char(day-''1 day''::interval,''d'') as week
								 from (
								select  (CURRENT_DATE + i ) as day
								from generate_series(date ''', _bdate ,'''::date  - CURRENT_DATE, 
										 date  ''',_edate,'''::date - CURRENT_DATE ) i
								 ) a) _t 
)
select distinct concat (day, '' '', min)::TIMESTAMP, concat (day, '' '', max)::TIMESTAMP from _shedul CROSS join _days
where case when  return_period_id=4  then week::integer in (select unnest(agg::int[]))
 when  return_period_id=3  then true 
	when return_period_id=5  then mm::integer in (select unnest(agg::int[]))
	when return_period_id=7  then number_week::integer in (select unnest(agg::int[]))
  end
and day BETWEEN  bdate and edate 
') ;
raise notice 'Р—Р°РїСЂРѕСЃ РёР· С€РµРґСѓР»Рё!!! %   !!!!',_query;
return QUERY	EXECUTE(_query);

else 
_query=concat('
with _r as (
select * from "public"."getworkingtime_"  where id=',_iddoc ,'and _bdatetime>= ''',_bdate,'''::date and _edatetime<=''',_edate,''' 
)
, _shedul as (
--С‚СѓС‚ СЃРѕР±РёСЂР°СЋС‚СЃСЏ РІСЃРµ РІРѕР·РјРѕР¶РЅС‹Рµ  РїСЂРёР·РЅР°РєРё РґРЅРµР№ РґР»СЏ СЂР°РїРёСЃР°РЅРёСЏ СЂРµСЃСѓСЂСЃР°
select id, min(btime), max(etime), return_period_id, agg, bdate,edate,srg_id from (
select  distinct _rule.id, _srv.btime, _srv.etime, _period.return_period_id, "array_agg"(_period.value ) agg, _rule.bdate, _rule.edate,_srg.id srg_id
								from sr_res_group _srg
								join sr_schedule_service _service on "_srg".id=_service.res_group_id
								join sr_schedule_rule _rule on "_rule".schedule_id="_service".id
								join cmn_time_event_period _period on _period.time_event_id=_rule.time_event_id
								join sr_schedule_rule_srv _srv on _srv.schedule_rule_id = _rule.id
								--left join sr_schedule_rule_call _call on _call.schedule_rule_id="_rule".id
								where _srg.id=',_iddoc,' 
								--and "_rule".id=60676
								and _rule.time_type_id=1 
								and (_rule.edate is null	or _rule.edate  > current_date )	
								and  exists(select 1 from sr_schedule_rule_call where schedule_rule_id="_rule".id and btime=_srv.btime and etime=_srv.etime)
								--and _call.id is null
								GROUP BY _rule.id, _srv.btime, _srv.etime, _period.return_period_id , _rule.bdate, _rule.edate,_srg.id
								order by _rule.id, _srv.btime

)_t group by id,return_period_id, agg , bdate,edate ,srg_id
),
_days as (
--РіРµРЅРµСЂР°С†РёСЏ РґРЅРµР№
select day, yyyy,mm,dd,number_week,week
from ( select day,  Extract(YEAR from day::date ) AS yyyy
								, Extract(MONTH from day::date ) AS mm
								, Extract(day from day::date ) AS dd
								,Extract(week from day::date ) AS number_week
								,to_char(day-''1 day''::interval,''d'') as week
								 from (
								select  (CURRENT_DATE + i ) as day
								from generate_series(date ''',_bdate,'''::date  - CURRENT_DATE, 
										 date  ''',_edate,'''::date - CURRENT_DATE ) i
								 ) a) _t 
)
,_sort as (
select distinct concat (day, '' '', min)::TIMESTAMP _bdt, concat (day, '' '', max)::TIMESTAMP _edt, *  from _shedul CROSS join _days
where case when  return_period_id=4  then week::integer in (select unnest(agg::int[]))
 when  return_period_id=3  then true 
	when return_period_id=5  then mm::integer in (select unnest(agg::int[]))
	when return_period_id=7  then number_week::integer in (select unnest(agg::int[]))
  end
and day BETWEEN  bdate and edate 
)
--select * from  _sort  
  select bdt, edt from _r
where not exists (select 1 from _sort where _r.id = _sort.srg_id and "_r".bdt  BETWEEN _sort._bdt and _sort._edt)
order by bdt'
);
raise notice 'Р—Р°РїСЂРѕСЃ СЃРіРµРЅРµСЂРёСЂРѕРІР°РЅРЅРѕРµ!!! %   !!!!',_query;
return QUERY	EXECUTE(_query);

END IF;
            end;
$$;

