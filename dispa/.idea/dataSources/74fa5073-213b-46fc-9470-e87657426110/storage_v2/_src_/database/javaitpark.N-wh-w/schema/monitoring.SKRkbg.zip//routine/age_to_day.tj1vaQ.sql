CREATE FUNCTION age_to_day(age_value integer, typecode character varying)
  RETURNS integer
LANGUAGE plpgsql
AS $$
BEGIN
    return (SELECT EXTRACT(epoch FROM (SELECT ((concat($1, ' ', $2))::INTERVAL)))/86400)::INTEGER;
  END;
$$;

