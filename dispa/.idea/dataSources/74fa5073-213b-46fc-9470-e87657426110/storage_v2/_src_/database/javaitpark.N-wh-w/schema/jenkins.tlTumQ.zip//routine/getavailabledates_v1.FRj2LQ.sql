CREATE FUNCTION getavailabledates_v1(_employee_id integer, _department_id text, idpat text, _bdate date, _edate date)
  RETURNS SETOF text
LANGUAGE plpgsql
AS $$
declare
            begin

            return QUERY (with all_sessions as (select ss.bdatetime, ss.edatetime, rg.id rg , ep.employee_id emp
                        from pim_employee_position ep
                        inner join sr_res_group rg on rg.responsible_id=ep.id
                        inner join sr_timetable_res_group trg on trg.res_group_id=rg.id
                        inner join sr_timetable t on t.id=trg.id
                        inner join sr_shift s on s.timetable_id=t.id
                        inner join sr_session ss on ss.shift_id=s.id
												left join  sr_session_quotum ssq on ss.id=ssq.session_id
                     where rg.id= _employee_id and cast(ss.bdatetime as date)>= _bdate and cast(ss.edatetime as date)<=_edate and ssq.session_id is null and s.time_type_id!=2 and ss.time_type_id!=2)

select substring (getavailabledates::text, 1, 10)||'T00:00:00.000' getavailabledates from (
select CAST(all_sessions.bdatetime as date) getavailabledates 
   from all_sessions
   left join md_appointment app on app.executor_id=all_sessions.rg and all_sessions.bdatetime=app.bdatetime and cancel_reason_id is NULL
where app.id is NULL and all_sessions.bdatetime>=CURRENT_DATE
GROUP BY getavailabledates)t);

            end;
$$;

