CREATE FUNCTION calculate_age(birthdate date, deathdate date, ageyear integer, agemonth integer, ageday integer)
  RETURNS character varying
LANGUAGE plpgsql
AS $$
DECLARE
  result VARCHAR;
BEGIN

  IF (birthDate IS NOT NULL)
    THEN
    IF (deathDate IS NOT NULL)
      THEN
        result = public.get_patient_full_age(birthDate, deathDate);
      ELSE result = public.get_patient_full_age(birthDate, CURRENT_DATE);
    END IF;
  ELSIF (ageYear IS NOT NULL OR ageMonth IS NOT NULL OR ageDay IS NOT NULL)
      THEN
        IF(ageYear IS NOT NULL)
          THEN
          IF ageYear in (11,12,13,14) or cast(right(cast(ageYear as varchar(3)), 1) AS INT) in (0,5,6,7,8,9)
            THEN
              result = cast(cast(ageYear as varchar(3))||' л. ' as VARCHAR);
            ELSE result = cast(cast(ageYear as varchar(3))||' г. ' as VARCHAR);
          END IF;
        END IF;
        IF(ageMonth IS NOT NULL)
          THEN
            result = concat(COALESCE(result, ''), cast(cast(ageMonth as varchar(2))||' мес.' as VARCHAR));
        END IF;
        IF(ageDay IS NOT NULL)
          THEN
            result = concat(COALESCE(result, ''), cast(cast(ageDay as varchar(2))||' дн.' as VARCHAR));
        END IF;
  ELSE result = 0;
  END IF;

  RETURN result;
END;
$$;

