CREATE VIEW pim_indiv_doc AS
  SELECT pim_indiv_doc_detail.id,
    pim_indiv_doc_detail.is_active,
    pim_indiv_doc_detail.expire_dt,
    pim_indiv_doc_detail.issue_dt,
    pim_indiv_doc_detail.issuer_text,
    pim_indiv_doc_detail.note,
    pim_indiv_doc_detail.birth_dt,
    pim_indiv_doc_detail.contract_number,
    pim_indiv_doc_detail.name,
    pim_indiv_doc_detail.patr_name,
    pim_indiv_doc_detail.surname,
    pim_indiv_doc_detail.issuer_id,
    pim_indiv_doc_detail.doc_id,
    pim_indiv_doc_detail.verific_dt,
    pim_indiv_doc_detail.birth_place,
    pim_individual_doc.code_id,
    pim_individual_doc.indiv_id
   FROM (pim_indiv_doc_detail
     LEFT JOIN pim_individual_doc ON ((pim_individual_doc.id = pim_indiv_doc_detail.doc_id)));

