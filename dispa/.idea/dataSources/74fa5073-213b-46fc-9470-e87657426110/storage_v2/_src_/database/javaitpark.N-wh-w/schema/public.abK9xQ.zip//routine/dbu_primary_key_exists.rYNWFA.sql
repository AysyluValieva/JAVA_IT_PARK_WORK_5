CREATE FUNCTION dbu_primary_key_exists(pkname character varying)
  RETURNS boolean
LANGUAGE plpgsql
AS $$
declare result boolean;
            begin

            select count(*) > 0 into result
            from pg_constraint
            inner join pg_namespace on pg_constraint.connamespace = pg_namespace.oid
            and pg_namespace.nspname !~ '^(pg_|information_schema)'
            where pg_constraint.contype = 'p'
            and pg_constraint.conname = lower($1);

            return result;
            end;
$$;

