CREATE FUNCTION drop_partition_sr_session_block()
  RETURNS text
LANGUAGE plpgsql
AS $$
DECLARE
				_result record;
				_return_message text;
				in_tablename_prefix text;
			BEGIN
				in_tablename_prefix = 'sr_session_block';
				_return_message = '';

				FOR _result IN SELECT * FROM pg_tables WHERE schemaname='public'
				LOOP
					IF POSITION(in_tablename_prefix in _result.tablename) > 0
						AND char_length(substring(_result.tablename from '[0-9-]*$')) <> 0
						AND (now() - interval '2 days') > to_timestamp(substring(_result.tablename from '[0-9-]*$'),'ddmmyyyy') THEN
					BEGIN
						EXECUTE 'DROP TABLE public.' || quote_ident(_result.tablename);
						EXCEPTION WHEN OTHERS THEN
						_return_message := _return_message || 'ERROR drop table: ' || _result.tablename::text ;
					END;
					END IF;
				END LOOP;

				RETURN _return_message || ' Done'::text;
			END;

$$;

