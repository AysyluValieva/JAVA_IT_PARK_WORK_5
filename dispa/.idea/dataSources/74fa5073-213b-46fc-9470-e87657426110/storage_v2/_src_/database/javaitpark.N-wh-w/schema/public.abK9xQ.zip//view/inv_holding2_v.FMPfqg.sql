CREATE VIEW inv_holding2_v AS
  SELECT q.form_id,
    q.holding_id,
    (q.holding_id || COALESCE(('_'::text || q.form_id), ''::text)) AS id
   FROM ( SELECT f.id AS form_id,
            COALESCE(f.holding_id, h.id) AS holding_id
           FROM (inv_form f
             RIGHT JOIN inv_holding h ON ((f.holding_id = h.id)))) q;

