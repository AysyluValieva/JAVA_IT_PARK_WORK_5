CREATE FUNCTION add_data(p_tab information_schema.sql_identifier, p_is_inc_null boolean, p_is_add_parent boolean)
  RETURNS bigint
LANGUAGE plpgsql
AS $$
declare
   v_id bigint := null;
   v_cols text := '';
   v_vals text := '';
   v_q text := '';
   c_fk  constant information_schema.table_constraints.constraint_type%type := 'FOREIGN KEY';
   c_pk  constant information_schema.table_constraints.constraint_type%type := 'PRIMARY KEY';
   col record;
   cns record;
   v_cns_ty information_schema.table_constraints.constraint_type%type;
   v_is_first boolean := true;
   v_val text;
   v_len int;
   c_len_max   constant int := 1000;
   v_tab_ref   information_schema.tables.table_name%type;
   v_col_ref   information_schema.columns.column_name%type;
   v_seq       information_schema.sequences.sequence_name%type;
   v_foo       int;
   v_is_def_exs boolean;
   v_pk_name   information_schema.columns.column_name%type;
-- todo: add current_schema condition for all queries
begin
   -- is_nullable in ('YES','NO')
   for col in 
      select column_name, is_nullable, data_type, character_maximum_length 
      from information_schema.columns 
      where table_name = p_tab and table_schema = current_schema() and (p_is_inc_null or (not p_is_inc_null and is_nullable = 'NO')) loop
      v_cns_ty := null;
      v_val := null;
      v_len := c_len_max;
      v_is_def_exs := false;
      select true into v_is_def_exs
      from information_schema.columns 
      where lower(table_name) = lower(p_tab) 
        and table_schema = current_schema() 
        and column_name = col.column_name 
        and lower(column_default) is not null;
      -- todo: multiple constraints on given column
      -- todo: multiple columns on given constraint
      -- todo: given column is PK and FK
      select constraint_type into v_cns_ty 
      from information_schema.table_constraints tc, information_schema.key_column_usage kcu
      where lower(tc.table_name) = lower(p_tab)
        and tc.table_name = kcu.table_name
        and tc.table_schema = kcu.table_schema
        and kcu.column_name = col.column_name
        and kcu.constraint_name = tc.constraint_name
        and (constraint_type in (c_pk)
          or (constraint_type = c_fk
             and not exists (
               select 1 from information_schema.key_column_usage kcu2, information_schema.table_constraints tc2
               where tc2.table_name = tc.table_name
                 and tc2.table_schema = tc.table_schema
                 and kcu2.table_name = kcu.table_name
                 and kcu2.table_schema = kcu.table_schema
                 and kcu2.column_name = col.column_name
                 and kcu2.constraint_name = tc2.constraint_name
                 and tc2.constraint_type = c_pk)));
      raise notice '%:%:%', col.column_name, v_cns_ty, col.character_maximum_length;
      if col.character_maximum_length is not null and col.character_maximum_length < c_len_max then v_len := col.character_maximum_length; end if;
      if v_cns_ty = c_pk then
         v_pk_name := col.column_name;
         if v_is_def_exs then continue; end if;
         -- check - if given column FK also
         v_tab_ref := null;
         execute 'select table_name, column_name
                  from information_schema.key_column_usage
                  where constraint_schema = current_schema()
                    and constraint_name in (select unique_constraint_name from information_schema.referential_constraints
                  where constraint_name in (select constraint_name from information_schema.key_column_usage
                  where lower(table_name) = '''||lower(p_tab)||''' and column_name = '''||col.column_name||'''))' into v_tab_ref, v_col_ref;
         if v_tab_ref is not null then
            v_id = add_data(v_tab_ref, p_is_inc_null);
         else
            v_seq := p_tab||'_seq';
            select 1 into v_foo from information_schema.sequences where lower(sequence_name) = lower(v_seq);
            if not found then
               execute 'select coalesce((select max('||col.column_name||') from '||p_tab||'), 0) + 1' into v_id;
            else
               execute 'select nextval('''||v_seq||''')' into v_id;
            end if;
         end if;
         v_val := v_id;
      elsif v_is_def_exs then continue;
      elsif v_cns_ty = c_fk then
         execute 'select table_name, column_name
                  from information_schema.key_column_usage
                  where constraint_schema = current_schema()
                    and constraint_name in (select unique_constraint_name from information_schema.referential_constraints
                  where constraint_name in (select constraint_name from information_schema.key_column_usage
                  where lower(table_name) = '''||lower(p_tab)||''' and column_name = '''||col.column_name||'''))' into v_tab_ref, v_col_ref;
         if p_is_add_parent then
            v_val := add_data(v_tab_ref, p_is_inc_null, p_is_add_parent);
         else
            v_val := '(select '||v_col_ref||' from '||v_tab_ref||' order by random() limit 1)';
         end if;
      else 
      
         case col.data_type
            when 'character varying', 'text' then v_val := ''''||gen_rnd(v_len, true)||'''';
            when 'date' then v_val := 'current_date';
            when 'time without time zone' then v_val := 'current_time';
            when 'timestamp without time zone' then v_val := 'clock_timestamp()';
            when 'boolean' then v_val := 'true';
            when 'integer' then v_val := '1';
            else v_val := null;  
         end case;
      end if;
      v_vals := v_vals||(case v_is_first when true then '' else ',' end)||coalesce(v_val, 'null');
      v_cols := v_cols||(case v_is_first when true then '' else ',' end)||col.column_name;
      if v_is_first then v_is_first := false; end if;
   end loop;
   execute 'insert into '||p_tab||'('||v_cols||') values ('||v_vals||')';
   if v_id is null then
      execute 'select max('||v_pk_name||') from '||p_tab into v_id;
   end if;
   return v_id;
end;
$$;

