CREATE FUNCTION sickdoc_create_or_update(p_id integer, p_begin_dt date, p_case_id integer, p_cur_clinic_id integer, p_end_dt date, p_final_diagnosis_id integer, p_hospital_from_dt date, p_hospital_to_dt date, p_individual_id integer, p_initial_diagnosis_id integer, p_journal_id integer, p_number character varying, p_parent_id integer, p_ready_to_work_dt date, p_ready_to_work_other_dt date, p_ready_to_work_other_id integer, p_registrator_id integer, p_workplace_id integer, p_workplace_print character varying, p_was_in_hospital boolean, p_registered_clinic_id integer, p_issue_dt date, p_disability_from_dt date, p_disability_to_dt date, p_disability_reason_edited_id integer, p_disability_reason_ext_id integer, p_disability_reason_id integer, p_is_disability_group_changed boolean, p_is_early_pregnancy_register boolean, p_is_regimen_violation boolean, p_is_mse boolean, p_mse_examination_dt date, p_mse_org_id integer, p_mse_referral_dt date, p_mse_register_dt date, p_on_placement_service boolean, p_regimen_violation_doctor_id integer, p_regimen_violation_dt date, p_regimen_violation_id integer, p_sanatorium_id integer, p_sanatorium_ogrn_code character varying, p_voucher_code character varying, p_care_for_patient_id1 integer, p_care_for_patient_id2 integer, p_family_relation_id1 integer, p_family_relation_id2 integer, p_is_other_clinic_for_period boolean, p_issued_employee_id integer, p_issued_employee_position character varying, p_other_clinic_id_for_preiod integer, p_witness_employee_id integer, p_witness_employee_position character varying, p_workplace_type_id integer, p_transfer_from_clinic boolean)
  RETURNS integer
LANGUAGE plpgsql
AS $$
DECLARE
  c_sicksheet_kind_code CONSTANT VARCHAR = '1';
  c_sickdoc_type_code_primary CONSTANT VARCHAR = '1'; --Первичный
  c_sickdoc_type_code_secondary CONSTANT VARCHAR = '2'; --Продолжение
  l_sickdoc_type_id INTEGER;
  c_new_state_code CONSTANT VARCHAR = '1';
  c_opened_state_code CONSTANT VARCHAR = '2';
  c_closed_state_code CONSTANT VARCHAR = '3';
  c_annuled_state_code CONSTANT VARCHAR = '5';
  c_unknown_state_code CONSTANT VARCHAR = 'unknown';
  l_disability_reason_code VARCHAR;
  l_hospital_from_dt DATE;
  l_hospital_to_dt DATE;
  l_is_update BOOLEAN;
  l_issue_clinic_id INTEGER;
  l_issue_dt DATE = coalesce(p_issue_dt, current_date);
  l_kind_id INTEGER;
  l_ready_to_work_other_id INTEGER = p_ready_to_work_other_id;
  l_state_id INTEGER;
  l_state_code VARCHAR;
  l_sickdoc_id INTEGER;
  l_workplace_id INTEGER;
  l_workplace_print VARCHAR;
  l_transfer_from_clinic BOOLEAN;
  l_cur_state_code VARCHAR;
  l_parent_state_code VARCHAR;
  l_parent_ready_to_work_other_id INTEGER;
BEGIN
  l_sickdoc_id = p_id;
  l_is_update = CASE WHEN p_id NOTNULL AND exists(SELECT 1
                                                  FROM sickdoc.sickdoc
                                                  WHERE id = p_id) THEN TRUE
                ELSE FALSE END;

  l_kind_id  = (SELECT id
                FROM sickdoc.rf_kind
                WHERE code = c_sicksheet_kind_code);

  --  статус присваивается по нарастающей
  l_cur_state_code = (select sickdoc.get_sickdoc_status(p_id));
  IF l_is_update THEN
    l_state_code = l_cur_state_code;

    l_state_code = CASE
                     WHEN p_number ISNULL THEN c_new_state_code
                     WHEN p_number NOTNULL AND l_state_code = c_new_state_code THEN c_opened_state_code
                     ELSE l_state_code END;

    IF l_state_code = c_opened_state_code THEN
      l_state_code = CASE WHEN p_ready_to_work_dt NOTNULL OR p_ready_to_work_other_id NOTNULL THEN c_closed_state_code
                 ELSE l_state_code END;
    END IF;

  ELSE
    l_state_code = CASE WHEN p_number ISNULL THEN c_new_state_code
                 ELSE c_opened_state_code END;

    IF l_state_code = c_opened_state_code THEN
      l_state_code = CASE WHEN p_ready_to_work_dt NOTNULL OR p_ready_to_work_other_id NOTNULL THEN c_closed_state_code
                 ELSE l_state_code END;
    END IF;

  END IF;

  --Определяем тип документа
  l_sickdoc_type_id = (SELECT slt.id
                       FROM md_sicklist_type slt
                       WHERE slt.code = (CASE
                                         WHEN p_parent_id ISNULL
                                           THEN c_sickdoc_type_code_primary
                                         ELSE c_sickdoc_type_code_secondary
                                         END));

  l_transfer_from_clinic = CASE WHEN p_transfer_from_clinic NOTNULL THEN p_transfer_from_clinic ELSE FALSE END;
  IF l_transfer_from_clinic
  THEN
    l_sickdoc_type_id = c_sickdoc_type_code_primary;
  END IF;

  IF l_state_code = c_closed_state_code AND p_number ISNULL
    THEN RAISE EXCEPTION 'Нельзя закрыть ЛН, у которого не задан номер';
  END IF;

  --Окончание проверки

  SELECT id
  FROM md_sicklist_state
  WHERE code = l_state_code
  INTO l_state_id;

  IF l_state_id ISNULL
  THEN RAISE EXCEPTION 'Не удалось определить статус документа нетрудоспособности'; END IF;

  l_issue_clinic_id = p_cur_clinic_id;

-- Стоит на учете в службе занятости? (галка на форме)
  IF p_on_placement_service IS FALSE
  THEN
    l_workplace_id = p_workplace_id;
    l_workplace_print = p_workplace_print;
  END IF;

  l_disability_reason_code = (SELECT code
                              FROM md_sl_disability_reason
                              WHERE id = p_disability_reason_id);

  IF p_was_in_hospital
  THEN
    l_hospital_from_dt = p_hospital_from_dt;
    l_hospital_to_dt = p_hospital_to_dt;
  END IF;

  IF l_is_update
  THEN
    UPDATE sickdoc.sickdoc
    SET
      case_id                = p_case_id,
      final_diagnosis_id     = p_final_diagnosis_id,
      hospital_from_dt       = l_hospital_from_dt,
      hospital_to_dt         = l_hospital_to_dt,
      individual_id          = p_individual_id,
      initial_diagnosis_id   = p_initial_diagnosis_id,
      journal_id             = p_journal_id,
      kind_id                = l_kind_id,
      number                 = p_number,
      ready_to_work_dt       = p_ready_to_work_dt,
      ready_to_work_other_dt = p_ready_to_work_other_dt,
      ready_to_work_other_id = l_ready_to_work_other_id,
      state_id               = l_state_id,
      transfer_to_o_clinic   = FALSE,
      workplace_id           = l_workplace_id,
      workplace_print        = l_workplace_print,
      workplace_type_id      = p_workplace_type_id
    WHERE id = p_id;

    --Дату выдачи, Регистрирующее лицо, и МО можно менять только у заявок
    IF l_cur_state_code = c_new_state_code
    THEN
       UPDATE sickdoc.sickdoc
       SET
         issue_dt               = l_issue_dt,
         registrator_id         = p_registrator_id,
         clinic_id              = l_issue_clinic_id
       WHERE id = p_id;
    END IF;

  ELSE
    INSERT INTO sickdoc.sickdoc (
      id, begin_dt, case_id, clinic_id, end_dt, final_diagnosis_id, hospital_from_dt, hospital_to_dt, individual_id,
      initial_diagnosis_id, issue_dt, journal_id, kind_id, number, parent_id, ready_to_work_dt, ready_to_work_other_dt,
      ready_to_work_other_id, registrator_id, state_id, transfer_to_o_clinic, transfer_from_clinic, workplace_id, workplace_print, workplace_type_id,
      type_id,registered_clinic_id)

    VALUES (
      DEFAULT, p_begin_dt, p_case_id, l_issue_clinic_id, p_end_dt, p_final_diagnosis_id, l_hospital_from_dt, l_hospital_to_dt,
      p_individual_id, p_initial_diagnosis_id, l_issue_dt, p_journal_id, l_kind_id, p_number, p_parent_id, p_ready_to_work_dt,
      p_ready_to_work_other_dt, l_ready_to_work_other_id, p_registrator_id, l_state_id, FALSE, l_transfer_from_clinic, l_workplace_id, l_workplace_print, p_workplace_type_id,
      l_sickdoc_type_id,p_registered_clinic_id)
    RETURNING id
      INTO l_sickdoc_id;

    -- Привязка периода
    PERFORM sickdoc.period_attach(
        l_sickdoc_id, p_cur_clinic_id, p_begin_dt, p_is_other_clinic_for_period, p_issued_employee_id,
        p_issued_employee_position, p_other_clinic_id_for_preiod, p_end_dt, p_witness_employee_id, p_witness_employee_position);


    --Если создавалось продолжение открытого ЛН, то родительский необходимо закрыть, выставив ему КОД ИНОЕ 31 - Продолжает болеть
    IF p_parent_id NOTNULL AND l_sickdoc_type_id = 2
    THEN
      l_parent_state_code =  (select sickdoc.get_sickdoc_status(p_parent_id));
      IF l_parent_state_code = c_opened_state_code
      THEN

        UPDATE sickdoc.sickdoc
        SET
          ready_to_work_other_id = (SELECT id FROM md_sl_readytowork_other WHERE code = '31'),
          ready_to_work_other_dt = l_issue_dt,
          state_id               = (SELECT id FROM md_sicklist_state WHERE code = '3')
        WHERE id = p_parent_id;

      END IF;
    END IF;

  END IF;

-- Привязка записи из sickdoc.sickdoc_extended
  PERFORM sickdoc.sickdoc_extended_create_or_update(
      l_sickdoc_id, p_care_for_patient_id1, p_care_for_patient_id2, l_disability_reason_code, p_disability_from_dt,
      p_disability_to_dt, p_disability_reason_edited_id, p_disability_reason_ext_id, p_disability_reason_id,
      p_family_relation_id1, p_family_relation_id2, p_is_disability_group_changed, p_is_early_pregnancy_register,
      p_is_regimen_violation, p_is_mse, p_mse_examination_dt, p_mse_org_id, p_mse_referral_dt, p_mse_register_dt,
      p_on_placement_service, p_regimen_violation_doctor_id, p_regimen_violation_dt, p_regimen_violation_id,
      p_sanatorium_id, p_sanatorium_ogrn_code, p_voucher_code);

  RETURN l_sickdoc_id;
END;
$$;

