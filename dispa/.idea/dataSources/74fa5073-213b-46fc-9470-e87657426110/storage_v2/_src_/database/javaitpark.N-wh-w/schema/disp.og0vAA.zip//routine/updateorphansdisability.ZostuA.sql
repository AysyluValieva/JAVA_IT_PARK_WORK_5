CREATE FUNCTION updateorphansdisability(xid integer, xdtid integer, xdd character varying, xdls character varying, xddid integer, xvihid integer, xdi character varying, ximid integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
    i integer;
  begin
    IF (select count(id) from disp.md_disp_orphans_disability where id = xid) = 0 THEN
      i = xid;
      insert into disp.md_disp_orphans_disability (id, disability_type_id, date_disability, date_last_survey, diagnosis_disability_id, violations_in_health_id, date_ipr, ipr_made_id)
        values (i, xdtid, to_date(xdd, 'DD.MM.YYYY'), to_date(xdls, 'DD.MM.YYYY'), xddid, xvihid, to_date(xdi, 'DD.MM.YYYY'), ximid);
    ELSE
      update disp.md_disp_orphans_disability set disability_type_id = xdtid, date_disability = to_date(xdd, 'DD.MM.YYYY'), date_last_survey = to_date(xdls, 'DD.MM.YYYY'),
        diagnosis_disability_id = xddid, violations_in_health_id = xvihid, date_ipr = to_date(xdi, 'DD.MM.YYYY'), ipr_made_id = ximid
        where id = xid;
    END IF;
    return 1;
    end;
$$;

