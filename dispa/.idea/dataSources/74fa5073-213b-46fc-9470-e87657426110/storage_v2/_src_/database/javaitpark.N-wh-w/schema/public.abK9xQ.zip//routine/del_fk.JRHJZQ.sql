CREATE FUNCTION del_fk(p_sch name, p_tab name, id text)
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
v_fk record;
v_q text;
begin
for v_fk in select tc.table_schema, tc.table_name, kcu.column_name
   from information_schema.referential_constraints rc, information_schema.table_constraints tc, information_schema.key_column_usage kcu
   where unique_constraint_name = (select constraint_name from information_schema.table_constraints where TABLE_NAME = p_tab and constraint_schema = p_sch and CONSTRAINT_TYPE = 'PRIMARY KEY')
   and delete_rule in ('NO ACTION', 'RESTRICT')
   and tc.constraint_type = 'FOREIGN KEY'
   and rc.constraint_name = tc.constraint_name
   and rc.constraint_catalog = tc.constraint_catalog
   and rc.constraint_schema = tc.constraint_schema
   and kcu.constraint_name = tc.constraint_name
   and kcu.table_name = kcu.table_name
   and kcu.constraint_catalog = tc.constraint_catalog
   and kcu.constraint_schema = tc.constraint_schema loop
   raise notice '%.%', v_fk.table_name, v_fk.column_name;
   v_q := 'delete from '||v_fk.table_schema||'.'||v_fk.table_name||' where '||v_fk.column_name||'='||id;
   execute v_q;
end loop;
end
$$;

