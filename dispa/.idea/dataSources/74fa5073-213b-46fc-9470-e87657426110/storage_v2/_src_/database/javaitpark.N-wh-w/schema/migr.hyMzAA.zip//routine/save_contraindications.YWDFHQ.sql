CREATE FUNCTION save_contraindications(xid integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
                unhealthy_diagnosis boolean;
                unhealthy_result boolean;
            begin
                select exists(select 1 from migr.md_migr_service mgs join md_diagnosis md on mgs.main_diagnosis_id = md.id where mgs.event_patient_id = xid and
                (md.code like 'F10%' or md.code like 'F11%' or md.code like 'F12%' or md.code like 'F13%' or
                md.code like 'F14%' or md.code like 'F15%' or md.code like 'F16%' or md.code like 'F17%' or
                md.code like 'F18%' or md.code like 'F19%' or md.code like 'A15%' or md.code like 'A16%' or
                md.code like 'A17%' or md.code like 'A18%' or md.code like 'A19%' or md.code like 'B20%' or
                md.code like 'B21%' or md.code like 'B22%' or md.code like 'B23%' or md.code like 'B24%' or
                md.code like 'A30%' or md.code like 'A50%' or md.code like 'A51%' or md.code like 'A52%' or
                md.code like 'A53%' or md.code like 'A55%' or md.code like 'A57%')
                and (mgs.is_second is null or mgs.is_second = false)) into unhealthy_diagnosis;

                select exists(select 1 from migr.md_migr_service mgs where mgs.event_patient_id = xid and mgs.result = true and (mgs.is_second is null or mgs.is_second = false)) into unhealthy_result;

                update migr.md_migr_card set is_contraindications = ((unhealthy_diagnosis = true) or (unhealthy_result = true)) where id = xid;
            return xid;
            end;
$$;

