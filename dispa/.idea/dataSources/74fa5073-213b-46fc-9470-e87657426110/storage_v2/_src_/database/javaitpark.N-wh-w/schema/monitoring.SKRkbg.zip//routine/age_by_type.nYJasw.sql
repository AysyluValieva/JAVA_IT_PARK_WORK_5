CREATE FUNCTION age_by_type(birt_date date, death_date date)
  RETURNS monitoring.age_type
LANGUAGE plpgsql
AS $$
DECLARE
  days INTEGER;
  month INTEGER;
  year INTEGER;
  deathDate INTEGER;
  intervalAge INTERVAL;
BEGIN

  intervalAge = AGE(birt_date) - case when death_date is null then '0D'::INTERVAL else AGE(death_date) end;

  year = (SELECT EXTRACT(YEAR FROM (intervalAge)));

  month = year*12 + (SELECT EXTRACT(MONTH FROM (intervalAge)));

  days = (SELECT (CURRENT_DATE - birt_date) - coalesce(CURRENT_DATE - death_date, 0));

  RETURN (days, month, year)::monitoring.age_type;
END;
$$;

