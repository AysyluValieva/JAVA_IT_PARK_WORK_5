CREATE FUNCTION render_house_call()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
declare
            var_house_call integer;
            begin
            if tg_op = 'UPDATE' and new.state_id = 3 and old.state_id != 3 then
            select h.id into var_house_call from md_house_call h
            join md_hcall_assignment ha on ha.id=h.actual_assignment_id
            where ha.appointment_id = new.id;
            if var_house_call is not null then
            update md_house_call set result_id = 2, is_executor_assigned = true where id = var_house_call;
            end if;
            end if;
            return new;
            end;
$$;

