CREATE FUNCTION fin_spec_gen_extra(p1_bill_id integer, p2_status text)
  RETURNS void
STRICT
LANGUAGE plpgsql
AS $$
BEGIN
    ---------------------------------------------------------------параметры-------------------------------------------------------------------------
    /*
    _item_type := (SELECT trim (p.commentary) FROM public.fin_bill_main AS b, public.fin_price_list AS p WHERE b.price_list_id = p.id AND b.id = public.fin_bill__get_main_bill (p1_bill_id))
    ;
    -----------------------------------------------------------тип позиции счёта---------------------------------------------------------------------
    --dentist
    WITH t AS 
    (
        SELECT DISTINCT 
            bill_id, case_id 
        FROM 
            billing.fin_bill_generate AS f
        WHERE 
            f.bill_id = p1_bill_id AND f.care_regimen_id = 1 AND coalesce (array_length (f.price_pos_arr, 1), 0) < 2
            AND coalesce ((SELECT c.name FROM public.sr_service AS s LEFT JOIN public.sr_srv_category AS c ON c.id = s.category_id WHERE s.id = f.service_id LIMIT 1), '0') = 'Стоматология'
    )
    UPDATE billing.fin_bill_generate AS f
    SET
        item_type = 'dentist'
    FROM t
    WHERE
        f.bill_id = t.bill_id AND f.case_id = t.case_id
    ;
    --ambulatory
    WITH t AS 
    (
        SELECT DISTINCT 
            bill_id, case_id 
        FROM 
            billing.fin_bill_generate
        WHERE 
            bill_id = p1_bill_id AND item_type IS NULL AND NOT is_sifted AND care_regimen_id = 1 
    )
    UPDATE billing.fin_bill_generate AS f
    SET
        item_type = 'ambulatory'
    FROM t
    WHERE
        f.bill_id = t.bill_id AND f.case_id = t.case_id
    ;
    --hospital
    WITH t AS 
    (
        SELECT DISTINCT 
            bill_id, case_id 
        FROM 
            billing.fin_bill_generate
        WHERE 
            bill_id = p1_bill_id AND item_type IS NULL AND NOT is_sifted AND care_regimen_id in (2, 3, 4, 5)
    )
    UPDATE billing.fin_bill_generate AS f
    SET
        item_type = 'hospital'
    FROM t
    WHERE
        f.bill_id = t.bill_id AND f.case_id = t.case_id
    ;
    -------------------------------------------------------------отсеивание--------------------------------------------------------------------------
    IF 
        p2_status = 'GENERATE' AND billing.fin_bill__get_sift_status ('SIFT_EMPTY_ITEM_TYPE') 
    THEN
        UPDATE billing.fin_bill_generate 
        SET 
            is_sifted = TRUE, sifting_cause = 'Не входит в реализованные виды помощи' 
        WHERE 
            bill_id = p1_bill_id AND NOT is_sifted AND item_type IS NULL
        ;
    END IF;
    -----------------------------------------------------------номер записи в выгрузке---------------------------------------------------------------
    WITH t AS 
    (
        SELECT bill_id, id, dense_rank () OVER (ORDER BY case_id) AS n_zap FROM billing.fin_bill_generate WHERE bill_id = p1_bill_id AND NOT is_sifted
    )
    UPDATE billing.fin_bill_generate AS f
    SET
        n_zap = t.n_zap
    FROM t
    WHERE
        t.bill_id = f.bill_id AND t.id = f.id
    ;
    */
    ------------------------------------------------------обновление статуса "удалена"---------------------------------------------------------------
    IF
        p2_status = 'GENERATE'
    THEN
        DELETE FROM billing.fin_bill_deleted_services WHERE bill_id = p1_bill_id;
    ELSIF
        p2_status IN ('VALIDATE', 'RECALCULATE')
    THEN
        UPDATE billing.fin_bill_generate AS f 
        SET 
            is_deleted = TRUE 
        FROM 
            billing.fin_bill_deleted_services AS s 
        WHERE 
            f.bill_id = p1_bill_id AND f.bill_id = s.bill_id AND f.id = s.srv_rendered_id AND NOT f.is_sifted
        ;
    END IF;
EXCEPTION
    WHEN NO_DATA_FOUND THEN RAISE EXCEPTION 'Отсутствуют данные по счёту';
END;
$$;

