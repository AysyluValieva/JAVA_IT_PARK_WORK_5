CREATE FUNCTION adr__element_is_locality_contains(id integer)
  RETURNS boolean
LANGUAGE plpgsql
AS $$
declare
            element_id integer := id;
            element record;
            locality boolean;
            begin

            

            for element in
            select aed.id as element_id, t.short_name as type_sname
            from address_element_data aed, address_element ae, address_element_type t
            where ae.id = aed.id
            and aed.path @> (select path from address_element_data aed2 where aed2.id = element_id)
            and ae.type_id = t.id
            loop
            if element.type_sname = 'г' or element.type_sname = 'городок' or 
            element.type_sname = 'арбан' or element.type_sname = 'аул' or
             element.type_sname = 'высел' or element.type_sname = 'дп' or
              element.type_sname = 'д' or element.type_sname = 'заимка' or
               element.type_sname = 'кп' or element.type_sname = 'погост' or
                element.type_sname = 'п' or element.type_sname = 'пгт' or
                 element.type_sname = 'п/ст' or element.type_sname = 'починок' or
                  element.type_sname = 'рп' or element.type_sname = 'с' or
                   element.type_sname = 'сл' or element.type_sname = 'ст' or
                    element.type_sname = 'у' or element.type_sname = 'х' or
                     element.type_sname = 'ст-ца' or element.type_sname = 'ж/д_ст' or
                      element.type_sname = 'рзд' or element.type_sname = 'у' or
                      element.type_sname = 'нп' or element.type_sname = 'ж/д_рзд' or
                      element.type_sname = 'уч-к' or element.type_sname = '' or
                      element.type_sname = 'м' or element.type_sname = 'ж/д_казарм' or
                      element.type_sname = 'казарма' or element.type_sname = 'кордон' or
                      element.type_sname = 'ж/д_будка' or element.type_sname = 'маяк' or
                      element.type_sname = 'ж/д_платф' or element.type_sname = 'погост' or
                      element.type_sname = 'остров' or element.type_sname = 'пл-ка' 
                      

            then
            return true;
            end if;

            end loop;

            return false;

            end;
$$;

