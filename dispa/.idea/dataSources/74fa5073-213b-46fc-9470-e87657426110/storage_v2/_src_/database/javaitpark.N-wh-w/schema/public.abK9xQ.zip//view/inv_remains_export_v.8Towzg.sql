CREATE VIEW inv_remains_export_v AS
  SELECT r.id AS remains_id,
    r.store_nomenclature_id AS sn_id,
    COALESCE(sp.fin_type_id, COALESCE(r.fin_type_id, o.fin_type_id)) AS fin_type_id,
    o.contractor_id,
    o.opr_type_id,
    s.org_id
   FROM inv_remains r,
    inv_opr o,
    inv_spec sp,
    inv_store s
  WHERE ((o.id = sp.opr_id) AND (sp.init_remains_id = r.id) AND (o.contractor_id IS NOT NULL) AND (s.id = r.store_id) AND (o.opr_type_id = ( SELECT inv_opr_type.id
           FROM inv_opr_type
          WHERE ((inv_opr_type.code)::text = COALESCE(( SELECT COALESCE(( SELECT cmn_setting_value.value AS value2
                           FROM cmn_setting_value
                          WHERE ((cmn_setting_value.setting_id)::text = (( SELECT cmn_setting.id
                                   FROM cmn_setting
                                  WHERE (((cmn_setting.code)::text = 'cz.atria.lsd.ns.inventory.api.setting.InvExportSettings.incomeOprTypeCode'::text) AND (cmn_setting_value.scope_id = ( SELECT cmn_scope.id
   FROM cmn_scope
  WHERE (cmn_scope.type_id = ( SELECT cmn_scope_type.id
     FROM cmn_scope_type
    WHERE ((cmn_scope_type.code)::text = 'Global'::text))))))))::text)), ( SELECT cmn_setting.default_value
                           FROM cmn_setting
                          WHERE ((cmn_setting.code)::text = 'cz.atria.lsd.ns.inventory.api.setting.InvExportSettings.incomeOprTypeCode'::text))) AS "coalesce"), ('?'::character varying)::text)))));

