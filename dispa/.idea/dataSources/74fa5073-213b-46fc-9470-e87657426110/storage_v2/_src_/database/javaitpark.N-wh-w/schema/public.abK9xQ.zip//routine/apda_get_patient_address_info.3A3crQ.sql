CREATE FUNCTION apda_get_patient_address_info(address_element_id integer)
  RETURNS apda_patient_address_info
LANGUAGE plpgsql
AS $$
DECLARE
  it         RECORD;
  ids        INTEGER [];
  street_id  INTEGER;
  house_name VARCHAR;
  flat_name  VARCHAR;
BEGIN
  IF address_element_id ISNULL
  THEN RETURN NULL; END IF;
  ids = ARRAY [] :: INTEGER [];
  FOR it IN (
    SELECT
      ae.id,
      ae.name,
      ae.level_id
    FROM address_element ae
      INNER JOIN address_element_data aed ON ae.id = aed.id
      INNER JOIN address_element_type aet ON ae.type_id = aet.id
    WHERE aed.path @> (SELECT path
                       FROM address_element_data
                       WHERE id = $1) AND ae.level_id > 3
    ORDER BY id DESC)
  LOOP ids = array_append(ids, it.id);
    IF it.level_id = 6
    THEN street_id = it.id;
    ELSEIF it.level_id = 7
      THEN house_name = upper(it.name);
    ELSEIF it.level_id = 8
      THEN flat_name = it.name;
    END IF;
  END LOOP;

  IF street_id ISNULL THEN house_name = NULL; flat_name = NULL; END IF;
  RETURN (house_name, flat_name, ids, street_id) :: apda_patient_address_info;
END;
$$;

