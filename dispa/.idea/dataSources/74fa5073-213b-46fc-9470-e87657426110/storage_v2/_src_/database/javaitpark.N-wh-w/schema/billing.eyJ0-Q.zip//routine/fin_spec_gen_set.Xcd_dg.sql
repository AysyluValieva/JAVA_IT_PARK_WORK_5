CREATE FUNCTION fin_spec_gen_set(p1_bill_id integer, p2_status text)
  RETURNS void
STRICT
LANGUAGE plpgsql
AS $$
DECLARE
    _main_bill_id INTEGER := public.fin_bill__get_main_bill (p1_bill_id);
BEGIN
    /*
        version: 2015-08-05
    */
    -----------------------------------------------------информация для расчёта стоимости------------------------------------------------------------
    -----------------------------------------------ует, количество, позиция прайса, код услуги-------------------------------------------------------
    UPDATE billing.fin_bill_generate AS f
    SET
        rdd_cul = r.cul, rdd_quantity = r.quantity,
        srv_cul = s.cul, service_code = coalesce (trim (s.code), ''), service_name = coalesce (trim (s.name), ''), service_type_id = s.type_id,
        quantity =  (
                        CASE WHEN s.is_multuplicity AND NOT s.is_actual_cul THEN coalesce (nullif (r.quantity, 0), 1) ELSE 1 END 
                        * 
                        CASE WHEN s.is_actual_cul THEN coalesce (nullif (r.cul, 0), nullif (s.cul, 0), 1) ELSE coalesce (nullif (s.cul, 0), 1) END
                    )
    FROM
        public.sr_service AS s, public.sr_srv_rendered AS r
    WHERE
        f.bill_id = p1_bill_id AND f.service_id = s.id AND f.id = r.id
    ;
    UPDATE billing.fin_bill_generate AS f
    SET
        price_position_code = coalesce (trim (p.code), ''), price_position_name = coalesce (trim (p.name), '')
    FROM
        public.fin_pl_position AS p
    WHERE
        f.bill_id = p1_bill_id AND NOT f.is_sifted AND f.price_pos_arr[1] = p.id AND p.price_list_id = f.price_list_id
    ;
    ----------------------------------------------------------набор данных---------------------------------------------------------------------------
    UPDATE billing.fin_bill_generate AS f
    SET
        new_born =  EXISTS 
                    (
                        SELECT 1 
                        FROM 
                            public.pci_patient_part_case AS p, public.pci_part_case AS c 
                        WHERE 
                            c.id = p.part_case_id AND c.ui_code IN ('1', '9') AND p.patient_id = f.patient_id AND f.case_close_date <@ daterange (p.from_dt, p.to_dt, '[]') 
                    )
    WHERE
        f.bill_id = p1_bill_id AND NOT f.is_sifted
    ;
    UPDATE billing.fin_bill_generate AS f
    SET
        attendant_id = (SELECT individual_id FROM public.mc_attendant WHERE case_id = f.case_id ORDER BY status_id LIMIT 1),
        relative_id = public.fin_individual__get_realative (f.patient_id, f.case_close_date)
    WHERE
        f.bill_id = p1_bill_id AND NOT f.is_sifted
    ;
    UPDATE billing.fin_bill_generate
    SET
        customer_id = CASE WHEN new_born THEN coalesce (attendant_id, relative_id) ELSE patient_id END,
        representative_id = CASE WHEN new_born THEN coalesce (attendant_id, relative_id) ELSE NULL END,
        id_pac = concat (patient_id, CASE WHEN new_born THEN concat ('П', coalesce (attendant_id, relative_id)) ELSE '' END)
    WHERE
        bill_id = p1_bill_id AND NOT is_sifted
    ;
    UPDATE billing.fin_bill_generate AS f
    SET
        patient_age = date_part ('year', age (f.case_open_date, i.birth_dt)), patient_gender_id = i.gender_id
    FROM 
        public.pim_individual AS i
    WHERE
        f.bill_id = p1_bill_id AND NOT f.is_sifted AND f.patient_id = i.id
    ;
    WITH t AS 
    (
        SELECT 
            f.bill_id, f.id, t.res_group_id
        FROM
            billing.fin_bill_generate AS f
            JOIN LATERAL (SELECT res_group_id FROM public.mc_step WHERE id = f.step_id LIMIT 1) AS t ON TRUE
            LEFT JOIN LATERAL (SELECT responsible_id FROM public.sr_res_group WHERE id = f.res_group_id LIMIT 1) AS r ON TRUE
        WHERE
            f.bill_id = p1_bill_id AND NOT f.is_sifted AND r.responsible_id IS NULL
    )
    UPDATE billing.fin_bill_generate AS f
    SET
        res_group_id = t.res_group_id
    FROM t
    WHERE
        f.bill_id = t.bill_id AND f.id = t.id
    ;
    UPDATE billing.fin_bill_generate AS f
    SET 
        step_cnt = (SELECT count (id) FROM public.mc_step WHERE case_id = f.case_id)
    WHERE
        bill_id = p1_bill_id AND NOT is_sifted
    ;
    --применение условие отбора по подразделениями
    IF 
        p2_status = 'GENERATE' AND EXISTS (SELECT 1 FROM public.fin_bill_main_department WHERE main_bill_id = _main_bill_id)
    THEN
        WITH t AS 
        (
            SELECT
                f.bill_id, f.id
            FROM 
                billing.fin_bill_generate AS f
                LEFT JOIN LATERAL (SELECT responsible_id FROM public.sr_res_group WHERE id = f.res_group_id LIMIT 1) AS g ON TRUE
                LEFT JOIN LATERAL (SELECT position_id FROM public.pim_employee_position WHERE id = g.responsible_id LIMIT 1) AS e ON TRUE
                LEFT JOIN LATERAL (SELECT department_id AS id FROM public.pim_position WHERE id = e.position_id LIMIT 1) AS p ON TRUE
            WHERE
                f.bill_id = p1_bill_id AND NOT f.is_sifted AND (p.id <> ALL (ARRAY (SELECT department_id FROM public.fin_bill_main_department WHERE main_bill_id = _main_bill_id)) OR p.id IS NULL)
        )
        UPDATE billing.fin_bill_generate AS f
        SET
           is_sifted = TRUE, sifting_cause = 'Применён фильтр по подразделениям'
        FROM t
        WHERE
            f.bill_id = t.bill_id AND f.id = t.id AND NOT f.is_sifted
        ;
    END IF;
EXCEPTION
    WHEN NO_DATA_FOUND THEN RAISE EXCEPTION 'Отсутствуют данные по счёту';
END;
$$;

