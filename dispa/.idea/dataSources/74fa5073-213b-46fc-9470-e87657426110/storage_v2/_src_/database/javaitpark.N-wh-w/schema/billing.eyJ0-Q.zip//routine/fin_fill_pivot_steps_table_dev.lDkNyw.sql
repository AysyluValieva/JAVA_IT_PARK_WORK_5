CREATE FUNCTION fin_fill_pivot_steps_table_dev(p1_bill_id integer)
  RETURNS void
STRICT
LANGUAGE plpgsql
AS $$
DECLARE
    _code_snils_ind_id INTEGER;
    _is_log BOOLEAN:=TRUE;
	_case_type_arr INTEGER[];
BEGIN
    _code_snils_ind_id := (SELECT id FROM public.pim_code_type WHERE code = 'SNILS');
	
	_case_type_arr = ARRAY (
		SELECT c.case_type_id FROM public.fin_bill_main b 
		 JOIN public.fin_bill_main_type t ON b.type_id = t.id 
		 JOIN public.fin_bill_main_type_to_case_type c ON c.main_bill_type_id = t.id
		WHERE b.id = p1_bill_id
	); 
	
    IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_fill_pivot_steps_table1. Начало'); END IF; 
    --IF EXISTS (SELECT 1 FROM billing.fin_bill_steps WHERE bill_id = p1_bill_id) THEN DELETE FROM billing.fin_bill_steps WHERE bill_id = p1_bill_id; END IF;
    drop table if EXISTS tmp_fin_bill_steps;
	CREATE TEMP TABLE tmp_fin_bill_steps (LIKE billing.fin_bill_steps INCLUDING DEFAULTS INCLUDING CONSTRAINTS)
	           ON COMMIT PRESERVE ROWS;

    CREATE UNIQUE INDEX tt_fbs_srv_rendered_id ON tmp_fin_bill_steps (srv_rendered_id);
    CREATE INDEX tt_fbs_step_id ON tmp_fin_bill_steps (step_id);

    INSERT INTO tmp_fin_bill_steps
    (
        srv_rendered_id, srv_rendered_bdate, srv_rendered_edate, srv_rendered_comment, srv_diagnosis_code, tooth_number,
        service_id, service_code, service_name, /*srv_prototype_id, srv_prototype_code,*/
        n_zap, case_id, step_id, patient_id, res_group_id, step_admission_date, step_outcome_date, step_profile_code, step_main_diagnosis_id, vmp_type_code, vmp_method_code,
        bill_id, spec_item_id, tariff, quantity, cul, price, price_pos_id, price_pos_code, tariff_code, step_admission_time, step_outcome_time,
        /*step_result_id,*/ step_result_code, /*step_outcome_id,*/ step_outcome_code, service_spec_id, service_spec_code, doctor_code, position_speciality_code,
        employee_speciality_code, /*visit_init_goal_code,*/ code_mes, deviation_reason_code, anest_code, department_id, hsp_department_id, region_data,

		step_diagnosis_main
    )
        SELECT
            f.id AS srv_rendered_id,
            f.bdate AS srv_rendered_bdate,
            f.edate AS srv_rendered_edate,
            f.comment AS srv_rendered_comment,
            --d.code AS srv_diagnosis_code,
            coalesce (trim (billing.get_diagnosis_on_kurgan(d.id)), ''),
            f.tooth_number,
            f.service_id,
            f.service_code,
            f.service_name,
         --   p.id AS srv_prototype_id,
        --    coalesce (trim (p.code), '') AS srv_prototype_code,
            i.number AS n_zap,
            f.case_id,
            f.step_id,
            f.patient_id,
            f.res_group_id,
            t.admission_date AS step_admission_date,
            t.outcome_date AS step_outcome_date,
            coalesce (nullif (trim (r.code), ''), '0') AS step_profile_code,
            t.main_diagnosis_id AS step_main_diagnosis_id,
            coalesce (trim (v.code), '') AS vmp_type_code,
            coalesce (trim (w.code), '') AS vmp_method_code,
            f.bill_id,
            i.id AS spec_item_id,
            i.tariff,
            f.quantity,
            f.srv_cul AS cul,
            i.price AS price,
            f.price_pos_arr[1] AS price_pos_id,
            f.price_position_code AS price_pos_code,
            f.tariff_code,
            t.admission_time AS step_admission_time,
            t.outcome_time AS step_outcome_time,
           -- t.result_id,
            rs.code AS step_result_code,
            --t.outcome_id,
            sc.code AS step_outcome_code,
            s.spec_id AS service_spec_id,
            COALESCE(sp.code,sp.e_code) AS service_spec_code,
            ep.id AS doctor_code,
            sp2.code AS position_speciality_code,
            sp2.code AS employee_speciality_code,
           -- gl.code AS visit_init_goal_code,
            mes.code AS code_mes,
            dev.code AS deviation_reason_code,
            COALESCE(f.anest_code,'') AS anest_code,
            COALESCE(pp.department_id,rg.department_id) as department_id,
            hsp.department_id AS hsp_department_id,
            hstore(
             ARRAY[
                 'code_mes_id',
                 'md_diagnosis_id',
                 'step_profile_id',
                 'is_reception_dep',
                 'bed_days',
               --  'is_oms_serv',
                 'vmp_method_id',
                 'bed_profile_code',
                 'bed_profile_name',
                 'bed_profile_id',
                 'funding_id',
                 'mes_qual_crit_code',
                 'curation',
                 'pos_category_code'
                 ],
             ARRAY[
                  mes.id::varchar,
                  mc.diagnos_id::varchar,
                  t.profile_id::varchar,
                  (COALESCE(hdp.type_id,0)=4)::varchar,
                  CASE WHEN f.case_type_id = 2 THEN public.get_bed_day_count_on_step(f.step_id)::varchar ELSE NULL END,
               --   (EXISTS(SELECT 1 FROM public.sr_service_fin_type srv_fin WHERE srv_fin.service_id = f.service_id AND srv_fin.funding_id = 8))::varchar,
                  t.vmp_method_id::varchar,
                  bed.code,
                  trim(bed.name),
                  bed.id::varchar,
                  hsp.funding_id::varchar,
                  mqc.code,
                  COALESCE(cur.code,cur2.code),
                  cat.code
                 ]
    	    ) AS region_data,

			'' AS step_diagnosis_main
        FROM
            tmp_fin_bill_generate           		AS f
            JOIN public.fin_bill_spec_item   		AS i   ON i.id   = f.fin_bill_spec_item_id /*AND i.bill_id = f.bill_id*/
            JOIN public.sr_service            		AS s   ON s.id   = f.service_id
          --  LEFT JOIN public.sr_srv_prototype 		AS p   ON p.id   = s.prototype_id
            LEFT JOIN public.mc_step          		AS t   ON t.id   = f.step_id
            LEFT JOIN public.md_profile       		AS r   ON r.id   = t.profile_id
            LEFT JOIN public.mc_vmp_type      		AS v   ON v.id   = t.vmp_type_id
            LEFT JOIN public.mc_vmp_method    		AS w   ON w.id   = t.vmp_method_id
            LEFT JOIN public.md_diagnosis     		AS d   ON d.id   = f.rdd_diagnosis_id
            LEFT JOIN public.mc_step_result   		AS rs  ON rs.id  = t.result_id
            LEFT JOIN public.mc_step_care_result 	AS sc  ON sc.id  = t.outcome_id
            LEFT JOIN public.pim_speciality   		AS sp  ON sp.id  = s.spec_id
            LEFT JOIN public.sr_res_group 			AS rg  ON rg.id  = f.res_group_id  --было t.res_group_id 14.03.2016
            LEFT JOIN public.pim_employee_position  AS ep  ON ep.id  = rg.responsible_id
            LEFT JOIN public.pim_position 			AS pp  ON pp.id  = ep.position_id
            LEFT JOIN public.pim_speciality			AS sp2 ON sp2.id = pp.speciality_id
            LEFT JOIN public.pim_position_role		AS pr  ON pr.id  = pp.role_id
            LEFT JOIN public.pim_position_category  AS cat ON cat.id = pr.category_id
          --  LEFT JOIN public.plc_visit 				AS vis ON vis.id = t.id
          --  LEFT JOIN public.mc_case_init_goal 		AS gl  ON gl.id  = vis.goal_id
            LEFT JOIN public.mc_diagnosis 			AS mc  ON mc.id  = t.main_diagnosis_id
            LEFT JOIN public.md_mes					AS mes ON mes.id = mc.mes_id
            LEFT JOIN public.mc_deviation_reason    AS dev ON dev.id = t.deviation_reason_id
            LEFT JOIN public.hsp_record				AS hsp ON hsp.id = t.id
            LEFT JOIN public.pim_department 		AS hdp ON hdp.id = hsp.department_id
            LEFT JOIN public.md_bed_profile 		AS bed ON bed.id = hsp.bed_profile_id
            LEFT JOIN public.mc_complexity_level    AS cur ON cur.id = mes.complexity_level_id
            LEFT JOIN public.mc_mes_quality_criterion AS mqc ON mqc.id = t.mes_quality_criterion_id
            LEFT JOIN public.hsp_record             AS hsp2  ON hsp2.id=f.closing_step_id
            LEFT JOIN public.mc_complexity_level	AS cur2 ON cur2.id = hsp2.complexity_level_id
        WHERE
            1 = 1 /*f.bill_id = p1_bill_id*/ AND NOT f.is_sifted AND NOT i.is_deleted;

	ANALYZE tmp_fin_bill_steps (srv_rendered_id);

    IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_fill_pivot_steps_table1. Конец'); END IF;
    IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_fill_pivot_steps_table23. Начало'); END IF;
   WITH doctors AS
    (
        SELECT
            f.srv_rendered_id,  --1
            coalesce (nullif (trim (p.code), ''), trim (e.number), '') AS doctor_code_regional,  --2
            coalesce (trim (r.code), '') AS pos_role_code, -- 3
            p.position_id,  -- 4
            coalesce (trim (d.code), '') AS department_code, --5
            coalesce (trim (d.name), '') AS department_name, --6
            array_agg(sp.code order by sp.code) as speciality_code_arr, -- 7
			regexp_replace
            (
                replace (replace ((array_agg (coalesce (trim (i.code), '') ORDER BY i.issue_dt DESC NULLS LAST))[1], '-', ''), ' ', ''),
                '(...)(...)(...)(..)',
                '\1-\2-\3 \4'
            ) AS snils, -- 8
			string_agg (DISTINCT (coalesce (trim (billing.get_diagnosis_on_kurgan(od.id)), '')), ';') AS o_diag_str
        FROM
            tmp_fin_bill_steps                 AS f
            LEFT JOIN public.sr_res_group               AS g ON g.id = f.res_group_id
            LEFT JOIN public.pim_department        AS d ON d.id = g.department_id
            LEFT JOIN public.pim_employee_position AS p ON p.id = g.responsible_id
            LEFT JOIN public.pim_employee          AS e ON e.id = p.employee_id
            LEFT JOIN public.pim_position          AS t ON t.id = p.position_id
            LEFT JOIN public.pim_position_role     AS r ON r.id = t.role_id
            LEFT JOIN public.pim_employee_position AS pep2 ON pep2.employee_id = e.id
            LEFT JOIN public.pim_position 		   AS pos ON pep2.position_id = pos.id
            LEFT JOIN public.pim_speciality 	   AS sp ON pos.speciality_id = sp.id
			-- + fin_fill_pivot_steps_table3. СНИЛС
			LEFT JOIN public.pim_indiv_code        AS i ON i.indiv_id = e.individual_id AND i.type_id = _code_snils_ind_id
			-- + fin_fill_pivot_steps_table2. 2
			LEFT JOIN public.mc_diagnosis AS o  ON o.step_id = f.step_id AND NOT coalesce (o.is_main, FALSE)
            LEFT JOIN public.md_diagnosis AS od ON od.id = o.diagnos_id
        WHERE
            1 = 1 /*f.bill_id = p1_bill_id*/
        GROUP BY 1, 2, 3, 4, 5, 6
    )
    UPDATE tmp_fin_bill_steps AS f
    SET
        doctor_code_regional = d.doctor_code_regional,
        speciality_code_arr  = d.speciality_code_arr ,
        pos_role_code        = d.pos_role_code       ,
        position_id          = d.position_id         ,
        department_code      = d.department_code     ,
        department_name      = d.department_name     ,
        doctor_snils         = d.snils               ,
        --
        step_diagnosis_other = d.o_diag_str
    FROM
        doctors AS d
    WHERE
        1 = 1 /*f.bill_id = p1_bill_id*/
		AND f.srv_rendered_id = d.srv_rendered_id;

    ANALYZE tmp_fin_bill_steps (srv_rendered_id);

    WITH steps AS
    (
        SELECT DISTINCT
            f.bill_id,
            f.step_id,
            coalesce (trim (d.code), '') AS hsp_department_code,
            coalesce (trim (d.name), '') AS hsp_department_name,
            coalesce (trim (t.code), '') AS visit_type_code,
            coalesce (trim (p.code), '') AS visit_place_code,
            coalesce (trim (i.code), '') AS visit_inc_code,
            ARRAY [coalesce (trim (g.code), ''), coalesce (trim (g.e_code), '')] AS visit_goal_code_arr,
            coalesce (trim (g.name), '') AS visit_goal_name,
			-- + fin_fill_pivot_steps_table2. 1
			coalesce (trim (billing.get_diagnosis_on_kurgan(md.id)), '') AS m_diag_code
        FROM
            tmp_fin_bill_steps             AS f
            LEFT JOIN public.plc_visit         AS v ON v.id = f.step_id
            LEFT JOIN public.plc_visit_type    AS t ON t.id = v.type_id
            LEFT JOIN public.plc_visit_place   AS p ON p.id = v.place_id
            LEFT JOIN public.plc_initiator     AS i ON i.id = v.initiator_id
            LEFT JOIN public.mc_case_init_goal AS g ON g.id = v.goal_id
            LEFT JOIN public.hsp_record        AS h ON h.id = f.step_id
            LEFT JOIN public.pim_department    AS d ON d.id = h.department_id
			LEFT JOIN public.mc_diagnosis      AS m  ON m.id = f.step_main_diagnosis_id AND coalesce (m.is_main, FALSE)
            LEFT JOIN public.md_diagnosis      AS md ON md.id = m.diagnos_id
        WHERE
            1 = 1 /*f.bill_id = p1_bill_id*/
    )
    UPDATE tmp_fin_bill_steps AS f
    SET
        visit_type_code      = s.visit_type_code    ,
        visit_place_code     = s.visit_place_code   ,
        visit_inc_code       = s.visit_inc_code     ,
        visit_goal_code_arr  = s.visit_goal_code_arr,
        visit_goal_name      = s.visit_goal_name    ,
        hsp_department_code  = s.hsp_department_code,
        hsp_department_name  = s.hsp_department_name,
        speciality_code_arr  = CASE
                                 WHEN f.employee_speciality_code <> ANY(f.speciality_code_arr)
                                   THEN array_append(f.speciality_code_arr, f.employee_speciality_code)
                               ELSE
                                 f.speciality_code_arr
                               END,
        step_diagnosis_main  = s.m_diag_code
    FROM
        steps AS s
    WHERE
        1 = 1 /*f.bill_id = s.bill_id*/ AND f.step_id = s.step_id;


     IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_fill_pivot_steps_table23. Конец'); END IF;
-- + 4
    IF (2 = ANY (_case_type_arr)) THEN


 		--обновляем инфу по реанимации
 		--отдельным запросом - так быстрее
		WITH q AS
		(
			SELECT
				bill_id,
    			step_id,
    			hstore (
    				ARRAY[
        				'reanim_bed_day_count',
            			'reanim_mes_code',
            			'reanim_diag_code'
        			],
        			ARRAY[
        				reanim_array[1],
            			reanim_array[2],
            			reanim_array[3]
        			]
    			) as reanim_hs

			FROM (
				SELECT
					bill_id,
    				step_id,
    				billing.fin_get_reanim_info_on_step(step_id) as reanim_array
				FROM (
					SELECT DISTINCT
						s.bill_id,
    					s.step_id
					FROM
						tmp_fin_bill_steps s
					WHERE
						1 = 1 /*s.bill_id = p1_bill_id*/
				)foo
			)bar
            WHERE reanim_array <> '{}'::varchar[]
		)
		UPDATE tmp_fin_bill_steps s
		SET
			region_data = region_data || reanim_hs
		FROM
			q
		WHERE 1 = 1 /*s.bill_id = q.bill_id*/ AND s.step_id = q.step_id
		;

		--проставялем номер МТЛ
		WITH q AS (
			SELECT
        		step_id,
        		hstore('num_mtl',num_mtl::varchar) as num_mtl_hs
    		FROM
    		(
    			SELECT
        			case_id,
            		step_id,
            		step_outcome_date,
            		row_number() over (partition by case_id order by step_outcome_date, step_outcome_time) as num_mtl
        		FROM
        		(
        			SELECT DISTINCT
            			s.case_id,
                		s.step_id,
                		s.step_outcome_date,
                        s.step_outcome_time
            		FROM
            			tmp_fin_bill_steps s
            		WHERE
            			1 = 1 /*s.bill_id = p1_bill_id*/ AND COALESCE(CAST(s.region_data->'is_reception_dep' AS boolean),FALSE) = FALSE
        		)foo
    		)bar
		)
		UPDATE tmp_fin_bill_steps s
		SET
			region_data = region_data || num_mtl_hs
		FROM
			q
		WHERE
			1 = 1 /*s.bill_id = p1_bill_id*/ AND s.step_id = q.step_id
		;


        -- установка sovmp - кол-во дней совместного нахождения смопровождающих лиц
		WITH att AS
		(
			SELECT DISTINCT
				s.bill_id,
    			--c.id as case_id,
				s.case_id,
    			s.step_id,
				CASE
    				WHEN a.from_dt > a.to_dt THEN NULL
        			WHEN a.from_dt = a.to_dt THEN 1
    				WHEN a.from_dt > s.step_outcome_date THEN NULL
        			WHEN a.to_dt < s.step_admission_date THEN NULL
        			WHEN a.from_dt >= s.step_admission_date AND a.to_dt <= s.step_outcome_date THEN a.to_dt - a.from_dt
        			WHEN a.from_dt <= s.step_admission_date AND a.to_dt < s.step_outcome_date THEN a.to_dt - s.step_admission_date
        			WHEN a.from_dt >= s.step_admission_date AND a.to_dt > s.step_outcome_date THEN s.step_outcome_date - a.from_dt
    			END as days
			FROM
				public.mc_attendant a
    			--JOIN public.mc_case c ON a.case_id = c.id
    			JOIN tmp_fin_bill_steps s ON a.case_id = s.case_id--c.id = s.case_id
    			LEFT JOIN public.pim_department d ON s.hsp_department_id = d.id
			WHERE
				1 = 1 /*s.bill_id = p1_bill_id*/ AND d.type_id <> 4 -- не берем приемные
		)
		UPDATE tmp_fin_bill_steps st
		SET 
			sovmp = att.days 
		FROM
			att
		WHERE
			1 = 1 /*st.bill_id = att.bill_id*/ AND st.case_id = att.case_id AND st.step_id = att.step_id
		;        	    
   
END IF;
-- +4    
END;
$$;

