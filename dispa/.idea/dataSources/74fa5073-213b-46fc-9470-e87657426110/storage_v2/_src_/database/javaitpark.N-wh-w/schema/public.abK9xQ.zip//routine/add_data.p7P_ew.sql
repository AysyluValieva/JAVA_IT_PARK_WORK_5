CREATE FUNCTION add_data(p_tab information_schema.sql_identifier, p_is_inc_null boolean)
  RETURNS bigint
LANGUAGE plpgsql
AS $$
begin
	if p_is_inc_null then return ad2(p_tab);
   else return add_data(p_tab, p_is_inc_null, false);
   end if;
end;
$$;

