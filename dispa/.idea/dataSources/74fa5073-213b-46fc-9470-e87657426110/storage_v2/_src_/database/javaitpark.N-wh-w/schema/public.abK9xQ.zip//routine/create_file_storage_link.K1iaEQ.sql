CREATE FUNCTION create_file_storage_link(graphic_id integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
    _file_name text;
    _file_path text;
    _entity_file_path text;
  BEGIN

    SELECT p.file_name INTO _file_path FROM public.pci_patient_reg_graphics p WHERE p.id=graphic_id;

    _file_name := coalesce(regexp_replace(substring(_file_path from '/\w+$'), '/', ''), _file_path);
    _entity_file_path := '/patient/registration/';

    IF (_file_name IS NOT NULL) THEN
      INSERT INTO public.file_storage (url, path, original_file_name, entity_name)
      VALUES (_entity_file_path || _file_name, _entity_file_path || _file_path, _file_name, 'patient');

      UPDATE public.pci_patient_reg_graphics
      SET url = _entity_file_path || _file_name
      WHERE id = graphic_id;
    END IF;

  END;
$$;

