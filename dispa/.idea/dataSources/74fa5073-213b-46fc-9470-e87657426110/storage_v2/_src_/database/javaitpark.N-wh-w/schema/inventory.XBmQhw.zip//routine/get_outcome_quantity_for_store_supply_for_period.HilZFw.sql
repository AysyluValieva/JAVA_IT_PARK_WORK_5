CREATE FUNCTION get_outcome_quantity_for_store_supply_for_period(storesupplyid integer, fromdate date, todate date, ismnei boolean)
  RETURNS numeric
LANGUAGE plpgsql
AS $$
DECLARE
 outcome NUMERIC;
BEGIN

SELECT (case when isMnei=true then SUM(jur.mnei_quantity) else SUM(jur.quantity) end) INTO outcome  FROM inventory.store_opr_jur AS jur
   LEFT OUTER JOIN inventory.store_opr opr ON jur.store_opr_id=opr.id
   LEFT OUTER JOIN inventory.store_opr_type TYPE ON TYPE.id=opr.opr_type_id
   WHERE TYPE.id=2 AND jur.date >= fromDate::DATE AND jur.date <= toDate::DATE AND send_store_sup_id = storeSupplyId;

if outcome IS NULL THEN outcome=0; END if;
return outcome;
END;
$$;

