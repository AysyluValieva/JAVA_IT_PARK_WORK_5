CREATE FUNCTION denialrenderingservice(xtype integer, xcheckservices character varying, xdeniservice character varying, xdeniservice2 character varying, xepid integer)
  RETURNS text
LANGUAGE plpgsql
AS $$
declare
                        serviceRendered integer [];
                        servicePatient integer [];
                        denial integer [];
                        results text [];
                        service integer;
                        checkserviceId json;
                        result  text ;
                        begin


                         --оказанные услуги
                    serviceRendered:=(array (select mes.service_id  from disp.md_event_service mes
                                                            right join sr_service ss on ss.id = mes.service_id
                                                            left join disp.md_event_service_patient mesp on mesp.service_id= mes.id
                                                            left join disp.md_event_service_status mess on mess.id=mesp.status  where mesp.event_patient_id=xepid and (mess.code=4 or mess.code=3)));



                   --услуги отказанные
                    if (xdeniservice is not null) then
                        foreach checkserviceId in array array(select value from json_array_elements(cast(xdeniservice as json)))
	                        LOOP
		                        if (checkserviceId::text!='null') then
			                        denial:=array_append(denial,(select service_id from disp.md_event_service where id= checkserviceId::text::int));
		                        end if;
	                        END LOOP;
	                else
                        foreach checkserviceId in array array(select value from json_array_elements(cast(xdeniservice2 as json)))
	                        LOOP
		                        if (checkserviceId::text!='null') then
			                        denial:=array_append(denial,(select mes.service_id from disp.md_event_patient mep
                                                                                        left join disp.md_event_service_patient mesp on mesp.event_patient_id=mep.id
                                                                                        left join disp.md_event_service mes on mes.id=mesp.service_id where mep.id=xepid and  mesp.id= checkserviceId::text::int));
		                        end if;
	                        END LOOP;
                    end if ;

                    --частичный отказ
               if (xtype=1)then
                        if (serviceRendered is not null) then
	                        foreach service in array serviceRendered
		                        loop
                        			if ((SELECT service = ANY(denial)) =true) then
				                        results:=array_append(results, cast((select ss.name from sr_service ss where id=service limit 1)as text));
			                        end if;
		                        end loop;
                        end if;

                       else if (xtype=2 and  serviceRendered is not null ) then
                        foreach service in array serviceRendered
		                        loop
                        			
				                        results:=array_append(results, cast((select ss.name from sr_service ss where id=service limit 1)as text));
			                       
		                        end loop;
                       
                       end if ;
                       


                    end if;
                result=array_to_string(results,', ');
                if (result is null) then return 'true'; return result; end if;


 
        return result;
        end;
$$;

