CREATE FUNCTION update_call_dt(xcall integer, xnewdt date, xf_time time without time zone, xtrans_time time without time zone, xexit_time time without time zone, xcom_time time without time zone, xtransp_time time without time zone, xtocl_time time without time zone, xtime_tocl time without time zone, xtosubs_time time without time zone, xt_time time without time zone, xdeath_time time without time zone, xbrg integer, xteam_id integer, xuser integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
                xchange integer;							-- после 1 определения const
                xchange_begin time without time zone;							-- после 1 определения const
                xfrom_time timestamp without time zone;		-- после 1 определения const
                xto_time timestamp without time zone;		-- после 1 определения const

                xtime time without time zone;		-- переменная для хранения значений времени
                xdt timestamp without time zone;	-- переменная для хранения значения поля

                xloop record;						-- для циклов

                -- по бригаде
                xteam integer;
                xbrg_call integer;							-- наряд обслуживший вызов
                xbrg_call_name varchar;						-- наименование бригады, обслужившей вызов

                xbrg_call_new integer;							-- новый наряд обслуживший вызов
                xbrg_name varchar;								-- наименование бригады, вновь выбранной как наименование

                xstation integer;							-- после 1 определения const
                xsubstation integer;						-- после 1 определения const
                xfixedfrom_time timestamp without time zone;-- чтобы знать, были или нет изменения времени приема
                xfixedto_time timestamp without time zone;
                xfixedchange integer;

                xbegind timestamp without time zone; -- начало обслуживания
                xendd timestamp without time zone;	 -- окончание обслуживания

                xduration integer;
                xgroup integer;
                xtrans timestamp without time zone;
                resel record;						-- для цикла записи состава бригады
                xrelationship_id integer;
                xrole integer;

                xhas_brg_name_update boolean := false;
                xtransregistrator_id integer;

              begin

                -- получаем значения необходимые для запросов
                select into xbegind, xendd
                            mash.date_time,cal.to_time + '1 second'
                            from amb.md_ambulance_call cal
                            join amb.md_ambcall_state_history mash on mash.call_id = cal.id and mash.state_id = 5
                            where cal.id = xcall;

                -- станция, подстанция,наряд обслуживший вызов, время приема ...
                select into xstation,xsubstation,xbrg_call,xfixedfrom_time,xfixedto_time,xfrom_time,xto_time,xfixedchange
                            station_id,substation_id,brg_id,from_time,to_time,from_time,to_time,call_dt from amb.md_ambulance_call where id = xcall;
               /* select into xstation,xsubstation,xbrg_call,xfixedfrom_time,xfrom_time,xto_time,xfixedto_time
                            station_id,substation_id,brg_id,from_time,from_time,to_time,to_time from amb.md_ambulance_call where id = xcall;*/

               select into xchange_begin change_begin
                    from amb.md_ambulance_change_setting where clinic_id = xstation and coalesce(department_id, 0) = coalesce(xsubstation, 0);

                -- определяем смену по дате
                xchange =
                --	case when xf_time between cast('00:00' as time) and xchange_begin
               --     	then
               --         	amb.insert_into_md_ambulance_change (cast(xnewdt - cast('1 day' as interval) as date),xstation,xsubstation)
                --        else
                            amb.insert_into_md_ambulance_change (xnewdt,xstation,xsubstation);
                    --end;

            /* <--13.05.2015	*/
                select into xbrg_call_name,xgroup srg.name,srg.id
                      from public.sr_res_group srg
                      join amb.sr_res_team srt on srt.resource_id = srg.id
                      join amb.sr_res_team_job srtj on srtj.team_id = srt.id
                    where srtj.id = xbrg_call;

                select into xbrg_name name
                      from public.sr_res_group srg
                      join amb.sr_res_team srt on srt.resource_id = srg.id
                    where srt.id = xteam_id;
               -- если наименование бригады изменилось, то нужно сохранить новое наименование системного составного ресурса
                IF (xteam_id is not null) and (xbrg_call_name <> xbrg_name) and (xbrg_call = xbrg)
                THEN
                    xhas_brg_name_update = true;


                    -- изменение наименования составного ресурса, обслужившего вызов (sr_srv_rendered.res_group_id)
                    update public.sr_res_group set name = xbrg_name where id = (select res_group_id from sr_srv_rendered where id = (select srv_rendered_id from amb.md_ambulance_call_result where id = xcall));

                    -- создание наряда на бригаду с новым наименованием и составом, как у наряда, указанного в amb.md_ambulance_call.brg_id
                    -- xtransregistrator_id как определить?
                    select into xtransregistrator_id registrator_id from amb.sr_res_team_job where id = xbrg_call;
                    xbrg/*_call_new*/ := amb.add_res_team_job(xteam_id,xchange,xtransregistrator_id);

                    if amb.search_team_job_status (xbrg/*_call_new*/) is null
                        then
                            update amb.sr_res_team_job
                                set bdate = cast((select from_data ||' ' ||from_time from amb.md_ambulance_change where id = xchange) as timestamp without time zone) where id = xbrg/*_call_new*/;

                            execute amb.add_team_job_status_hist(xbrg/*_call_new*/,cast((select from_data ||' ' ||from_time from amb.md_ambulance_change where id = xchange) as timestamp without time zone),1,xtransregistrator_id,'подписка',xuser);

                            update amb.sr_res_team_job
                                set edate = cast((select to_data ||' ' ||to_time from amb.md_ambulance_change where id = xchange) as timestamp without time zone) where id = xbrg/*_call_new*/;
                            execute amb.add_team_job_status_hist (xbrg/*_call_new*/,cast((select to_data ||' ' ||to_time from amb.md_ambulance_change where id = xchange) as timestamp without time zone),7,xtransregistrator_id,'завершение работы',xuser);
                   end if;

                    -- пишем состав наряда бригады на момент обслуживания вызова
                    xtrans = (select date_time from amb.md_ambcall_state_history where call_id = xcall and state_id = 5 order by date_time desc limit 1);
                    for resel in
                        select srtjr.*
                        --srtjr.resource_id as xres, srtte.res_role_id as xroleE,srttt.res_role_id as xroleT,srr.id as xrole,srtjr.is_head as head
                            from amb.sr_res_team_job_resourse srtjr
                            join sr_resource sr on sr.id = srtjr.resource_id
                            join amb.sr_res_team_job srtj on srtjr.team_job_id = srtj.id
                            join amb.sr_res_team srt on srtj.team_id = srt.id
                            left join amb.sr_res_team_template srtt on srt.team_template_id = srtt.id
                            left join amb.sr_res_team_template_employer srtte on srtt.id = srtte.team_template_id and srtte.work_place = srtjr.workplace
                            left join amb.sr_res_team_template_transport srttt on srtt.id = srttt.team_template_id and (srttt.work_place = srtjr.workplace or upper(srttt.work_place) = upper('Транспорт')) and sr.res_kind_id = (select id from sr_res_kind where upper(name) = upper('Транспорт'))
                            left join sr_res_role srr on srtte.res_role_id = srr.id or srttt.res_role_id = srr.id or srtjr.role_id = srr.id
                            where srtjr.team_job_id = xbrg_call and (srtjr.deviation_id is null or srtjr.deviation_id in (2,7))
                                and (srtjr.bdate <= xtrans)
                                and (srtjr.edate >= xfixedto_time or srtjr.edate is null)
                    loop
                        INSERT INTO amb.sr_res_team_job_resourse(change_id,team_job_id,job_kind_id,is_head,planned_bdate,planned_edate,bdate,edate,deviation_id,
                          replacement_id,registrator_id,deviation_registrator_id,workplace,resource_id,role_id)
                        VALUES (xchange,xbrg/*_call_new*/,resel.job_kind_id,resel.is_head,resel.planned_bdate,resel.planned_edate,resel.bdate,xfixedto_time,resel.deviation_id,
                          resel.replacement_id,resel.registrator_id,resel.deviation_registrator_id,resel.workplace,resel.resource_id,resel.role_id);
                    end loop;
                END IF;
            /* 13.05.2015-->*/

                --переопределяем связанные с бригадой значения
                if (xbrg_call <> xbrg)
                    then
                        update amb.md_ambulance_call set brg_id = xbrg where id = xcall;
                        -- здесь переопределение ссылок на наряд в соответствующих таблицах на уже существующий наряд на заданное число
                        --amb.sr_res_team_job_status_history
                        update amb.sr_res_team_job_status_history set team_job_id = xbrg where team_job_id = xbrg_call and job_status_id not in (1,7)
                            and date_time >xfixedfrom_time and date_time <= xfixedto_time + '10 second';   -- надо подумать, время окончания иное чтоб было!!!!

                end if;

              IF (to_char(xf_time,'HH24:mi') <> to_char (xfixedfrom_time,'HH24:mi')) or (xchange <> xfixedchange)
               THEN
                -- время приема
                -- переопределяем дату и время приема
                xfrom_time = case when xf_time between cast('00:00' as time) and xchange_begin
                        then cast(cast(xnewdt + cast('1 day' as interval) as date)||' '|| xf_time  as timestamp without time zone)
                        else cast(xnewdt ||' ' ||xf_time  as timestamp without time zone)
                      end;
                -- время окончания вызова
                -- переопределяем дату и время окончания вызова
                xto_time = case when xt_time between cast('00:00' as time) and xchange_begin
                        or xfrom_time >= cast(cast(xnewdt + cast('1 day' as interval) as date)||' '|| cast('00:00' as time)  as timestamp without time zone)
                        then cast(cast(xnewdt + cast('1 day' as interval) as date)||' '|| xt_time  as timestamp without time zone)
                        else cast(xnewdt ||' ' ||xt_time  as timestamp without time zone)
                      end;
                -- обновляем значения смены, даты-времени приема вызова и даты-времени окончания вызова
                update amb.md_ambulance_call set call_dt = xchange,from_time = xfrom_time, to_time = xto_time where id = xcall;


                -- переопределение даты и измененных временных значений в таблицах

                -- amb.md_ambcall_priority_history
                -- записи из истории смены приоритетов вызова
                for xloop in select id from amb.md_ambcall_priority_history where call_id = xcall order by date_time asc
                    loop
                        --select into xtime cast(date_time as time) from amb.md_ambcall_priority_history where id = xloop.id;
                        xtime = case when to_char(xfixedfrom_time,'HH24:mi') <> to_char(xf_time,'HH24:mi')
                                    then xf_time
                                    else (select cast(date_time as time) from amb.md_ambcall_priority_history where id = xloop.id)
                                end;
                        -- переопределяем дату установки приоритета
                        xdt = case when xtime between cast('00:00' as time) and xchange_begin
                                    or xfrom_time >= cast(cast(xnewdt + cast('1 day' as interval) as date)||' '|| cast('00:00' as time)  as timestamp without time zone)
                                then cast(cast(xnewdt + cast('1 day' as interval) as date)||' '|| xtime  as timestamp without time zone)
                                else cast(xnewdt ||' ' ||xtime  as timestamp without time zone)
                              end;
                        -- обновляем значение даты записи в истории смены приоритетов вызова
                        update amb.md_ambcall_priority_history set date_time = xdt where id = xloop.id;
                    end loop;
                --amb.md_ambcall_route_history
                -- записи из истории смены направления вызова
                for xloop in select id from amb.md_ambcall_route_history where call_id = xcall order by date_time asc
                    loop
                        --select into xtime cast(date_time as time) from amb.md_ambcall_route_history where id = xloop.id;
                        xtime = case when to_char(xfixedfrom_time,'HH24:mi') <> to_char(xf_time,'HH24:mi')
                                    then xf_time
                                    else (select cast(date_time as time) from amb.md_ambcall_route_history where id = xloop.id) end;
                        -- переопределяем дату установки приоритета
                        xdt = case when xtime between cast('00:00' as time) and xchange_begin
                                    or xfrom_time >= cast(cast(xnewdt + cast('1 day' as interval) as date)||' '|| cast('00:00' as time)  as timestamp without time zone)
                                then cast(cast(xnewdt + cast('1 day' as interval) as date)||' '|| xtime  as timestamp without time zone)
                                else cast(xnewdt ||' ' ||xtime  as timestamp without time zone)
                              end;
                        -- обновляем значение даты записи в истории смены приоритетов вызова
                        update amb.md_ambcall_route_history set date_time = xdt where id = xloop.id;
                    end loop;
              END IF;

               --amb.md_ambcall_state_history
               -- записи из истории состояний вызова
               for xloop in select * from amb.md_ambcall_state_history where call_id = xcall
                    loop
                      if (to_char(xf_time,'HH24:mi') <> to_char (xfixedfrom_time,'HH24:mi'))
                      then
                        case
                            -- принят диспетчером
                            when xloop.state_id = 1 then xdt := xfrom_time;
                            -- назначено направление
                            when xloop.state_id = 2 then xdt := xfrom_time;
                            -- назначена подстанция
                            when xloop.state_id = 3 then xdt := xfrom_time;
                            -- назначена бригада 		-- xtrans_time
                            when xloop.state_id = 4 then xdt :=
                                                            case when xtrans_time between cast('00:00' as time) and xchange_begin
                                                                or xfrom_time >= cast(cast(xnewdt + cast('1 day' as interval) as date)||' '|| cast('00:00' as time)  as timestamp without time zone)
                                                            then cast(cast(xnewdt + cast('1 day' as interval) as date)||' '|| xtrans_time  as timestamp without time zone)
                                                            else cast(xnewdt ||' ' ||xtrans_time  as timestamp without time zone)
                                                            end;
                            -- вызов передан бригаде 	-- xtrans_time
                            when xloop.state_id = 15 then xdt :=
                                                            case when xtrans_time between cast('00:00' as time) and xchange_begin
                                                                or xfrom_time >= cast(cast(xnewdt + cast('1 day' as interval) as date)||' '|| cast('00:00' as time)  as timestamp without time zone)
                                                            then cast(cast(xnewdt + cast('1 day' as interval) as date)||' '|| xtrans_time  as timestamp without time zone)
                                                            else cast(xnewdt ||' ' ||xtrans_time  as timestamp without time zone)
                                                            end;
                            -- вызов принят бригадой 	-- xtrans_time
                            when xloop.state_id = 5 then xdt :=
                                                            case when xtrans_time between cast('00:00' as time) and xchange_begin
                                                                or xfrom_time >= cast(cast(xnewdt + cast('1 day' as interval) as date)||' '|| cast('00:00' as time)  as timestamp without time zone)
                                                            then cast(cast(xnewdt + cast('1 day' as interval) as date)||' '|| xtrans_time  as timestamp without time zone)
                                                            else cast(xnewdt ||' ' ||xtrans_time  as timestamp without time zone)
                                                            end;

                            -- выезд на вызов 			-- xexit_time
                            when xloop.state_id = 6 then xdt :=
                                                            case when xexit_time between cast('00:00' as time) and xchange_begin
                                                                or xfrom_time >= cast(cast(xnewdt + cast('1 day' as interval) as date)||' '|| cast('00:00' as time)  as timestamp without time zone)
                                                            then cast(cast(xnewdt + cast('1 day' as interval) as date)||' '|| xexit_time  as timestamp without time zone)
                                                            else cast(xnewdt ||' ' ||xexit_time  as timestamp without time zone)
                                                            end;
                            -- прибытие на место вызова -- xcom_time
                            when xloop.state_id = 7 then xdt :=
                                                            case when xcom_time between cast('00:00' as time) and xchange_begin
                                                                or xfrom_time >= cast(cast(xnewdt + cast('1 day' as interval) as date)||' '|| cast('00:00' as time)  as timestamp without time zone)
                                                            then cast(cast(xnewdt + cast('1 day' as interval) as date)||' '|| xcom_time  as timestamp without time zone)
                                                            else cast(xnewdt ||' ' ||xcom_time  as timestamp without time zone)
                                                            end;
                            -- начало транспортировки	--xtransp_time
                            when xloop.state_id = 8 then xdt :=
                                                            case when xtransp_time is not null then
                                                             case when xtransp_time between cast('00:00' as time) and xchange_begin
                                                                or xfrom_time >= cast(cast(xnewdt + cast('1 day' as interval) as date)||' '|| cast('00:00' as time)  as timestamp without time zone)
                                                            then cast(cast(xnewdt + cast('1 day' as interval) as date)||' '|| xtransp_time  as timestamp without time zone)
                                                            else cast(xnewdt ||' ' ||xtransp_time  as timestamp without time zone)
                                                            end
                                                                else
                                                                    null
                                                            end;
                            -- прибытие в МО			--xtocl_time
                            when xloop.state_id = 9 then xdt :=
                                                            case when xtocl_time is not null then
                                                            case when xtocl_time between cast('00:00' as time) and xchange_begin
                                                                or xfrom_time >= cast(cast(xnewdt + cast('1 day' as interval) as date)||' '|| cast('00:00' as time)  as timestamp without time zone)
                                                            then cast(cast(xnewdt + cast('1 day' as interval) as date)||' '|| xtocl_time  as timestamp without time zone)
                                                            else cast(xnewdt ||' ' ||xtocl_time  as timestamp without time zone)
                                                            end
                                                                else
                                                                    null
                                                            end;
                            -- окончание вызова
                            when xloop.state_id = 10 then xdt := xto_time;
                            -- возвращение на подстанцию--xtosubs_time
                            when xloop.state_id = 11 then xdt :=
                                                            case when xtosubs_time is not null then
                                                            case when xtosubs_time between cast('00:00' as time) and xchange_begin
                                                                or xfrom_time >= cast(cast(xnewdt + cast('1 day' as interval) as date)||' '|| cast('00:00' as time)  as timestamp without time zone)
                                                            then cast(cast(xnewdt + cast('1 day' as interval) as date)||' '|| xtosubs_time  as timestamp without time zone)
                                                            else cast(xnewdt ||' ' ||xtosubs_time  as timestamp without time zone)
                                                            end
                                                                else
                                                                    null
                                                            end;
                            -- вызов отменен
                            --when xloop.state_id = 12 then xdt := ???;
                            -- направлен на отказ
                            when xloop.state_id = 13 then xdt := xto_time;
                            -- отказ врача
                            when xloop.state_id = 14 then xdt := xto_time;

                        end case;
                      else
                       if (xchange <> xfixedchange)
                       then
                        select into xtime cast(date_time as time) from amb.md_ambcall_state_history where id = xloop.id;
                        -- переопределяем дату установки состояния
                        xdt := case when xtime between cast('00:00' as time) and xchange_begin
                                    or xfrom_time >= cast(cast(xnewdt + cast('1 day' as interval) as date)||' '|| cast('00:00' as time)  as timestamp without time zone)
                                then cast(cast(xnewdt + cast('1 day' as interval) as date)||' '|| xtime  as timestamp without time zone)
                                else cast(xnewdt ||' ' ||xtime  as timestamp without time zone)
                              end;
                        end if;
                      end if;

                      -- обновляем значение даты записи в истории состояний вызова
                      if (to_char(xf_time,'HH24:mi') <> to_char (xfixedfrom_time,'HH24:mi')) or (xchange <> xfixedchange)
                        then
                            update amb.md_ambcall_state_history set date_time = xdt where id = xloop.id;
                      end if;
                    end loop;

               /*
                пока так и не решила, править или нет эти значения
                --amb.md_ambulance_call_note
                -- все таблицы расшифровки информации по отметкам полей с датой не содержат, основное изменение только в amb.md_ambulance_call_note
                for xloop in select id from amb.md_ambulance_call_note where call_id = xcall
                    loop
                      if cast(xfrom_time as time) <> cast(xfixedfrom_time as time)
                      then
                        case
                            -- принят диспетчером
                            when xloop.state_id = 1 then xdt = xfrom_time
                        end;
                      end if;
                    end loop;
                    --отметка о госпитализации	-- пока что ставлю значение xtransp_time - начало транспортировки
                    update amb.md_ambulance_call_note set note_dt = case when xtransp_time between cast('00:00' as time) and xchange_begin
                                                                or xfrom_time >= cast(cast(xnewdt + cast('1 day' as interval) as date)||' '|| cast('00:00' as time)  as timestamp without time zone)
                                                            then cast(cast(xnewdt + cast('1 day' as interval) as date)||' '|| xtransp_time  as timestamp without time zone)
                                                            else cast(xnewdt ||' ' ||xtransp_time  as timestamp without time zone)
                                                            end
                        where call_id = xcall and note_id = 21 and cn.note_type is true and cn.note_active is true

                --отметка повторности/задвоенности amb.md_ambulance_call_double
                if exists (select * from amb.md_ambulance_call_double)
                    then
                        update amb.md_ambulance_call_double
                end if;
                --amb.md_ambulance_call_in_cityservice
                --amb.md_ambulance_call_in_clinic
                --amb.md_ambulance_call_on_base
                --amb.md_ambulance_call_on_control
                --amb.md_ambulance_call_selfrefused
                end loop;
                */

                --переопределяем связанные с бригадой значения


                -- здесь переопределение временных полей
                -- amb.sr_res_team_job_status_history
                if (to_char(xf_time,'HH24:mi') <> to_char (xfixedfrom_time,'HH24:mi')) or (xchange <> xfixedchange)
                    then
                        for xloop in select * from amb.sr_res_team_job_status_history
                            where team_job_id = xbrg and date_time >= xbegind and date_time <= xendd order by date_time asc
                            loop
                                 case --1 2 6
                                    -- на вызове
                                    when xloop.job_status_id = 2 then xdt :=
                                                            (select date_time from amb.md_ambcall_state_history where call_id = xcall and state_id = 5);
                                    -- свободна
                                    when (xloop.job_status_id = 1) and not exists (select * from amb.md_ambcall_state_history where call_id = xcall and state_id = 13)
                                        then xdt := xto_time;
                                    when (xloop.job_status_id = 1) and exists (select * from amb.md_ambcall_state_history where call_id = xcall and state_id = 13)
                                        then xdt := (select date_time from amb.md_ambcall_state_history where call_id = xcall and state_id = 13);

                                    -- снята диспетчером
                                    when xloop.job_status_id = 6 then xdt :=
                                                            (select date_time from amb.md_ambcall_state_history where call_id = xcall and state_id = 13);
                                    else xdt := case when cast(xloop.date_time as time) between cast('00:00' as time) and xchange_begin
                                                    or xfrom_time >= cast(cast(xnewdt + cast('1 day' as interval) as date)||' '|| cast('00:00' as time)  as timestamp without time zone)
                                                then cast(cast(xnewdt + cast('1 day' as interval) as date)||' '|| cast(xloop.date_time as time)  as timestamp without time zone)
                                                else cast(xnewdt ||' ' ||cast(xloop.date_time as time)  as timestamp without time zone)
                                                end;
                                 end case;
                                update amb.sr_res_team_job_status_history set date_time = xdt where id = xloop.id;
                            end loop;


                --результат (здесь вроде нечего менять)


                --случай
                update mc_case set open_date = cast(xfrom_time as date),create_date = cast(xfrom_time as date)
                    where id = (select case_id from amb.md_ambulance_call_result where id = xcall);

                --шаг  --xtime_tocl - прием в МО
                        update mc_step set admission_date = cast(xfrom_time as date), admission_time = cast(xfrom_time as time)
                        ,death_date = case when xdeath_time between cast('00:00' as time) and xchange_begin
                                                    or xfrom_time >= cast(cast(xnewdt + cast('1 day' as interval) as date)||' '|| cast('00:00' as time)  as timestamp without time zone)
                                                then cast(xnewdt + cast('1 day' as interval) as date)
                                                else xnewdt
                                     end
                        ,death_time = xdeath_time
                        ,outcome_date = coalesce(case when xtime_tocl between cast('00:00' as time) and xchange_begin
                                                                or xfrom_time >= cast(cast(xnewdt + cast('1 day' as interval) as date)||' '|| cast('00:00' as time)  as timestamp without time zone)
                                                            then cast(xnewdt + cast('1 day' as interval) as date)
                                                            else xnewdt end,cast(xto_time as date)), outcome_time = COALESCE(xtime_tocl,cast(xto_time as time))
                        where id = (select closing_step_id from mc_case where id = (select case_id from amb.md_ambulance_call_result where id = xcall));

                --посещение
                xduration = (select cast(EXTRACT(EPOCH FROM AGE(to_time, from_time))/60 as integer) from amb.md_ambulance_call where id = xcall);
                update plc_visit set duration = xduration where id = (select closing_step_id from mc_case where id = (select case_id from amb.md_ambulance_call_result where id = xcall));

                --услуга
                update public.sr_srv_rendered set bdate = cast(xfrom_time as date),begin_time = cast(xfrom_time as time),edate = CAST(xto_time as date),duration = xduration
                    where id = (select srv_rendered_id from amb.md_ambulance_call_result where id = xcall);

                end if;

                -- если бригада изменилась, то нужно переписать системный составной ресурс, оказавший услугу со значениями из новой бригады
                IF (xbrg_call <> xbrg) and not xhas_brg_name_update
                THEN
                    -- создаём системный составной ресурс
                    xgroup = nextval('sr_res_group_seq');
                    insert into sr_res_group (id,bdate,edate,is_system,name,org_id,department_id)
                        select xgroup,cast(xfrom_time as date),cast(xto_time as date),true,name,org_id,department_id from sr_res_group
                            where id = (select resource_id from amb.sr_res_team rt left join amb.sr_res_team_job rtj on rtj.team_id = rt.id where rtj.id = xbrg);
                    --insert into md_res_group (id) values (xgroup);
                    insert into public.sr_res_group_profile(id,res_group_id,profile_id)
                        values(nextval('sr_res_group_profile_seq'),xgroup,(select profile_id from sr_res_group_profile where res_group_id = (select resource_id from amb.sr_res_team rt left join amb.sr_res_team_job rtj on rtj.team_id = rt.id where rtj.id = xbrg)));

                    -- пишем состав бригады на момент обслуживания вызова
                    xtrans = (select date_time from amb.md_ambcall_state_history where call_id = xcall and state_id = 5 order by date_time desc limit 1);
                    -- //изменить так, чтоб транспорта не было
                    for resel in
                        select srtjr.resource_id as xres, srtte.res_role_id as xroleE,srttt.res_role_id as xroleT,srr.id as xrole,srtjr.is_head as head
                            from amb.sr_res_team_job_resourse srtjr
                            join sr_resource sr on sr.id = srtjr.resource_id
                            join amb.sr_res_team_job srtj on srtjr.team_job_id = srtj.id
                            join amb.sr_res_team srt on srtj.team_id = srt.id
                            left join amb.sr_res_team_template srtt on srt.team_template_id = srtt.id
                            left join amb.sr_res_team_template_employer srtte on srtt.id = srtte.team_template_id and srtte.work_place = srtjr.workplace
                            left join amb.sr_res_team_template_transport srttt on srtt.id = srttt.team_template_id and (srttt.work_place = srtjr.workplace or upper(srttt.work_place) = upper('Транспорт')) and sr.res_kind_id = (select id from sr_res_kind where upper(name) = upper('Транспорт'))
                            left join sr_res_role srr on srtte.res_role_id = srr.id or srttt.res_role_id = srr.id or srtjr.role_id = srr.id
                            where srtjr.team_job_id = xbrg and (srtjr.deviation_id is null or srtjr.deviation_id in (2,7))
                                and (srtjr.bdate <= xtrans)
                                and (srtjr.edate >= xto_time or srtjr.edate is null)
                    loop
                        xrelationship_id :=nextval('sr_res_group_relationship_seq');
                        if (resel.head = true or coalesce(resel.xroleE,resel.xroleT,resel.xrole) = (select id from sr_res_role where upper(code) = upper('TRANSPORT')))
                            then xrole := coalesce(resel.xroleE,resel.xroleT,resel.xrole);
                            else xrole :=
                                case
                                when (select upper(code) from sr_res_role where id = coalesce(resel.xroleE,resel.xroleT,resel.xrole)) like upper('DOCTOR%') then (select id from sr_res_role where upper(code) = upper('DOCTOR_ASST'))
                                when (select upper(code) from sr_res_role where id = coalesce(resel.xroleE,resel.xroleT,resel.xrole)) like upper('PARAMEDIC%') then (select id from sr_res_role where upper(code) = upper('PARAMEDIC_ASST'))
                                when (select upper(code) from sr_res_role where id = coalesce(resel.xroleE,resel.xroleT,resel.xrole)) like upper('DISPATCHER%') then (select id from sr_res_role where upper(code) = upper('DISPATCHER_ASST'))
                                when (select upper(code) from sr_res_role where id = coalesce(resel.xroleE,resel.xroleT,resel.xrole)) like upper('DRIVER%') then (select id from sr_res_role where upper(code) = upper('DRIVER_ASST'))
                                end;
                        end if;
                        INSERT INTO public.sr_res_group_relationship (id,bdatetime,edatetime,resource_id,group_id,role_id)
                            VALUES (xrelationship_id,xfrom_time,xto_time,resel.xres,xgroup,xrole);
                    end loop;
                    if (select upper(srr.e_code)
                            from public.sr_res_group_relationship srgr
                            join public.sr_res_role srr on srr.id = srgr.role_id
                            where srgr.group_id = xgroup and srr.kind_id = 1) = upper('DOCTOR')
                    then
                        insert into public.md_resgroup_amb_profile (id,profile_id)
                            select xgroup,profile_id from public.md_resgroup_amb_profile where id = (select resource_id from amb.sr_res_team rt left join amb.sr_res_team_job rtj on rtj.team_id = rt.id where rtj.id = xbrg);
                    else
                        insert into public.md_resgroup_amb_profile (id,profile_id)
                            values(xgroup, (select id from public.md_ambulance_profile where e_code = '3'));
                    end if;
                    --шаг
                    update mc_step set res_group_id = xgroup where id = (select closing_step_id from mc_case where id = (select case_id from amb.md_ambulance_call_result where id = xcall));

                    --"Оказанная услуга"
                    update public.sr_srv_rendered set res_group_id = xgroup where id = (select srv_rendered_id from amb.md_ambulance_call_result where id = xcall);
                END IF;

              end;
$$;

