CREATE FUNCTION apdam_get_patients(in_type_id integer, in_reg_date date)
  RETURNS void
LANGUAGE plpgsql
AS $$
BEGIN
  DROP TABLE IF EXISTS apdam_patient;
  CREATE UNLOGGED TABLE apdam_patient WITH (AUTOVACUUM_ENABLED = FALSE
  ) AS
    SELECT
      p.id                                    AS patient_id,
      date_part('years', age($2, i.birth_dt)) AS age,
      i.gender_id
    FROM pci_patient p
      JOIN pim_individual i ON i.id = p.id
      LEFT JOIN pci_patient_reg r
        ON p.id = r.patient_id AND state_id = 1 AND r.type_id = $1 AND (r.unreg_dt ISNULL OR $2 <= r.unreg_dt)
    WHERE (i.death_dt ISNULL OR i.death_dt > $2) AND r ISNULL;

  CREATE INDEX ON apdam_patient USING BTREE (patient_id);

  --удаляем пациентов которые уже обрабатывали
  DELETE FROM apdam_patient
  WHERE patient_id IN (SELECT patient_id
                       FROM apdam_regs
                       WHERE new_district_id ISNULL);
END;
$$;

