CREATE FUNCTION questioningevent(xid integer, xcaseid integer, xq1 integer, xq2 integer, xq3 integer, xq4 integer, xq5 integer, xq6 integer, xq7 integer, xq8 integer, xq9 integer, xq10 integer, xq11 integer, xq12 integer, xq13 integer, xq14 integer, xq15 integer, xq16 integer, xq17 integer, xq18 integer, xq19 integer, xq20 integer, xq21 integer, xq22 integer, xq23 integer, xq24 integer, xq25 integer, xq26 integer, xq27 integer, xq28 integer, xq29 integer, xq30 integer, xq31 integer, xq32 integer, xq33 integer, xq34 integer, xq35 integer, xq36 integer, xq37 integer, xq38 integer, xq39 integer, xq40 integer, xq41 integer, xq42 integer, xq43 integer, xserviceid integer, xresource integer, xdate character varying)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
          i integer;
          msrid integer;
          stepid integer;
          sysresid integer;
        begin
          update disp.md_event_questioning set q1=xq1,
          q2 = xq2,
          q3 = xq3,
          q4 = xq4,
          q5 = xq5,
          q6 = xq6,
          q7 = xq7,
          q8 = xq8,
          q9 = xq9,
          q10 = xq10,
          q11 = xq11,
          q12 = xq12,
          q13 = xq13,
          q14 = xq14,
          q15 = xq15,
          q16 = xq16,
          q17 = xq17,
          q18 = xq18,
          q19 = xq19,
          q20 = xq20,
          q21 = xq21,
          q22 = xq22,
          q23 = xq23,
          q24 = xq24,
          q25 = xq25,
          q26 = xq26,
          q27 = xq27,
          q28 = xq28,
          q29 = xq29,
          q30 = xq30,
          q31 = xq31,
          q32 = xq32,
          q33 = xq33,
          q34 = xq34,
          q35 = xq35,
          q36 = xq36,
          q37 = xq37,
          q38 = xq38,
          q39 = xq39,
          q40 = xq40,
          q41 = xq41,
          q42 = xq42,
          q43 = xq43
          where id = xid;
          if (select count(msr.id) from MD_SRV_RENDERED msr
              left join SR_SRV_RENDERED ssr on ssr.id = msr.id
              where msr.case_id = xcaseId and ssr.service_id = xserviceid) = 0 then
              i = nextval('sr_srv_rendered_seq');
              stepid =  nextval('mc_step_seq');
              sysresid = nextval('sr_res_group_seq');
              insert into SR_RES_GROUP(id, bdate, edate, is_system, name, department_id, org_id, responsible_id, is_available_in_electronic_queue, label_id)
                select sysresid as id, bdate, edate, TRUE as is_system, name, department_id, org_id, responsible_id, is_available_in_electronic_queue, label_id
                from SR_RES_GROUP
                where id = xresource;
              insert into mc_step (id, admission_date, outcome_date, case_id, regimen_id, res_group_id, outcome_id, profile_id)
                values (stepid, COALESCE(to_date(xdate, 'DD.MM.YYYY'), current_date), COALESCE(to_date(xdate, 'DD.MM.YYYY'), current_date), xcaseId, (select id from mc_care_regimen where code = 1), sysresid, (select id from mc_step_care_result where code = '306' and to_dt is null),
                      (select mp.id from SR_RES_GROUP srg
                       left join SR_RES_GROUP_RELATIONSHIP srgr on srgr.group_id = srg.id
                       inner join pim_employee_position_resource pepr on pepr.id = srgr.resource_id
                       left join PIM_EMPLOYEE_POSITION pep on pep.id = pepr.employee_position_id
                       left join PIM_POSITION pp on pp.id = pep.POSITION_ID
                       left join PIM_SPECIALITY ps on ps.id = pp.speciality_id
                       left join disp.md_profile_specialty mps on mps.spec_code = ps.code
                       left join md_profile mp on mp.code = mps.profile_code
                       where srg.id = xresource limit 1));
              insert into plc_visit (id, goal_id, place_id) values (stepid, (select mett.case_init_goal_id from disp.md_event_patient mep left join disp.md_event me on me.id = mep.event_id left join disp.md_event_type_target mett on mett.event_type_id = me.event_type where mep.id = xid and mett.stage = 1 and (mett.begin_date is null or mett.begin_date <= current_date) and (mett.end_date is null or mett.end_date >= current_date)),
                (select id from plc_visit_place where code = '1'));
              insert into SR_SRV_RENDERED (id, service_id, bdate, res_group_id, customer_id, is_rendered, edate, quantity, funding_id, org_id, payment_status_id)
                values (i, xserviceid, COALESCE(to_date(xdate, 'DD.MM.YYYY'), current_date), xresource, (select indiv_id from disp.md_event_patient where id = xid), TRUE, COALESCE(to_date(xdate, 'DD.MM.YYYY'), current_date), 1,
                (select etf.funding_source_type_id from disp.md_event_type_fund etf join disp.md_event me on me.event_type = etf.event_type_id join disp.md_event_patient mep on mep.event_id = me.id where mep.id = xid), (select me.org_id from disp.md_event_patient mep left join disp.md_event me on me.id = mep.event_id where mep.id = xid), 1);
              insert into MD_SRV_RENDERED (id, case_id, step_id) values (i, xcaseId, stepid);
          else
              select msr.id into msrid from MD_SRV_RENDERED msr join SR_SRV_RENDERED ssr on ssr.id = msr.id where msr.case_id = xcaseId and ssr.service_id = xserviceid;
			  i = msrid;
              update SR_SRV_RENDERED set bdate = to_date(xdate, 'DD.MM.YYYY'), res_group_id = xresource
                where id = msrid;

              update mc_step set admission_date = COALESCE(to_date(xdate, 'DD.MM.YYYY'), current_date), outcome_date = COALESCE(to_date(xdate, 'DD.MM.YYYY'), current_date)
                where id = (select step_id from MD_SRV_RENDERED where id = msrid);
              if xresource != (select res_group_id from SR_SRV_RENDERED where id = msrid) then
                sysresid = nextval('sr_res_group_seq');
                insert into SR_RES_GROUP(id, bdate, edate, is_system, name, department_id, org_id, responsible_id, is_available_in_electronic_queue, label_id)
                  select sysresid as id, bdate, edate, TRUE as is_system, name, department_id, org_id, responsible_id, is_available_in_electronic_queue, label_id
                  from SR_RES_GROUP
                  where id = xresource;
                update mc_step set res_group_id = sysresid
                  where id = (select step_id from MD_SRV_RENDERED where id = msrid);
              end if;
          end if;
          update MC_CASE set create_date = COALESCE(to_date(xdate, 'DD.MM.YYYY'), current_date),
            open_date = COALESCE(to_date(xdate, 'DD.MM.YYYY'), current_date)
            where id = xcaseId;
          -- change STATUS
          update disp.md_event_service_patient_status set status = 4
              where service_id = (select mesp.id from disp.md_event_patient mep
                left join disp.md_event_service_patient mesp on mesp.event_patient_id = mep.id
                inner join disp.md_event_service mes on mes.id = mesp.service_id and mes.service_id = xserviceid
                where mep.id = xid);
          return i;
        end;
$$;

