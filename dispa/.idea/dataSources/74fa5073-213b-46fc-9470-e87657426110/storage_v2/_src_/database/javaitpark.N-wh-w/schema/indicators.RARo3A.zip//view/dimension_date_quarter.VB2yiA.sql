CREATE VIEW dimension_date_quarter AS
  SELECT dimension_date.id,
    dimension_date.year_,
    dimension_date.quarter_of_year,
    dimension_date.half_of_year,
    dimension_date.aud_who,
    dimension_date.aud_when,
    dimension_date.aud_source,
    dimension_date.aud_who_create,
    dimension_date.aud_when_create,
    dimension_date.aud_source_create
   FROM indicators.dimension_date
  WHERE (dimension_date.dimension_date_def_id = 3);

COMMENT ON VIEW dimension_date_quarter IS 'Временной срез. Год, квартал';

COMMENT ON COLUMN dimension_date_quarter.id IS 'Идентификатор';

COMMENT ON COLUMN dimension_date_quarter.year_ IS 'Год';

COMMENT ON COLUMN dimension_date_quarter.quarter_of_year IS 'Квартал года';

COMMENT ON COLUMN dimension_date_quarter.half_of_year IS 'Полугодие года';

