CREATE FUNCTION add_prototype_list_to_monitoring(xpregnant_map_id integer, xvalue integer, xprototype_ids character varying)
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
  xprototypeid json;
BEGIN
  if (xprototype_ids is not null) then
    foreach xprototypeid in array array(select value from json_array_elements(cast(xprototype_ids as json)))
    LOOP
      INSERT INTO motherhood.mh_treatment_plan_service (planned_dt, pregnant_age, prototype_id, treatment_plan_id)
        SELECT (pm.reg_dt + trunc((xvalue - pm.pregnant_age)*7)::int), xvalue, xprototypeid::text::int, tp.id
        FROM motherhood.mh_treatment_plan tp, motherhood.mh_pregnant_map pm
        WHERE pm.id = xpregnant_map_id and tp.pregnant_map_id = xpregnant_map_id;
    END LOOP;
  END IF;
END;
$$;

