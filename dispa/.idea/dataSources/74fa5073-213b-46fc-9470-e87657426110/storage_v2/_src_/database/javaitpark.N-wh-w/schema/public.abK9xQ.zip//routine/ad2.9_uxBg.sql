CREATE FUNCTION ad2(p_tab text, p_inc_nullable boolean DEFAULT true)
  RETURNS text
LANGUAGE plpgsql
AS $$
declare
-- <rules>
c_r_last	constant int := 1;
c_r_rand	constant int := 2;
c_r_new		constant int := 3;
-- </rules>
c_len 		constant int := 10;	-- default string value length
v_id text := null;
col record;
con record;
coldef pg_attrdef.adbin%type;
v_val text;	-- todo: rename to expr
v_pk_name pg_attribute.attname%type;
v_is_first boolean := true;
v_cols 	text := '';
v_vals 	text := '';
v_frel	pg_class.relname%type;
v_fsch   pg_namespace.nspname%type := null;
v_fatt	pg_attribute.attname%type;
v_r		constant int := c_r_rand;
v_q 	text := '';
v_len	int;	-- actual length
v_fk 	record;
v_is_pk boolean;
v_is_fk boolean;
loid oid = -1;
v_foo int;
c_seq_map_table constant pg_class.relname%type := 'zz_gen_seq_map';
v_att pg_attribute%rowtype;
v_typ pg_type%rowtype;
v_num_precision information_schema.columns.numeric_precision%type;
v_num_scale 	information_schema.columns.numeric_scale%type;
v_sch          pg_namespace.nspname%type := null;
v_tab          pg_class.relname%type := p_tab;
v_dot_pos      int := position('.' in p_tab);
-- todo: determine result for PKs with default values
begin
select count(1) into v_foo from pg_class where lower(relname) = lower(c_seq_map_table);
if v_foo = 0 then
execute format('create table %s(tab name primary key, seq name not null)', c_seq_map_table);
end if;
-- detect schema
if v_dot_pos > 0 then
   v_sch := substring(p_tab from 1 for v_dot_pos - 1);
   v_tab := substring(p_tab from v_dot_pos + 1 for length(p_tab) - (v_dot_pos));
   raise notice 'dbg:s=% t=%', v_sch, v_tab;
else
   v_sch := current_schema;
end if;
--
for col in 
	select a.attname, a.atttypid, t.typname, a.attnotnull, a.atthasdef, attrelid, attnum, t.typtype, t.typcategory, a.attlen, attrelid
	from pg_attribute a, pg_class c, pg_namespace n, pg_type t
	where attnum > 0 and c.relnamespace = n.oid and n.nspname = v_sch and c.oid = a.attrelid and c.relname = lower(v_tab) and t.oid = a.atttypid 
   and attname not in ('aud_who', 'aud_when', 'aud_source', 'aud_who_create', 'aud_when_create', 'aud_source_create')
   and (case p_inc_nullable when true then true else attnotnull end)
   loop
	v_val := null; v_fk := null; v_is_pk := false; v_is_fk := false;
   if col.attlen = -1 and col.typname = 'bpchar' then -- todo: precise
      v_len := 1; 
   else
      if col.attlen = -1 then
         select * into v_att from pg_attribute where attrelid = col.attrelid and attname = col.attname;
         select * into v_typ from pg_type      where oid = col.atttypid;
         v_len := information_schema._pg_char_max_length(information_schema._pg_truetypid(v_att, v_typ), information_schema._pg_truetypmod(v_att, v_typ));
         if v_len is null then v_len = c_len; end if;
      end if;
      if col.attlen > c_len or v_len > c_len then
         v_len := c_len;   -- just for smaller values generating
      elsif col.attlen > 0 then
         v_len := col.attlen;
      end if;
   end if;
	-- raise notice '% % %', col.attnum, col.attname, col.typname;
	-- default value
	for con in select confrelid, conkey, confkey, contype from pg_constraint where conrelid = col.attrelid and col.attnum = conkey[1] loop
		case con.contype	
			when 'f' then v_fk := con; v_is_fk := true;
			when 'p' then v_is_pk := true;
			when 'u' then v_val := null;	-- todo
         else v_val := null;
		end case;
	end loop;
	if v_is_pk then
		v_pk_name := col.attname; 
	end if;
	select adbin into coldef from pg_attrdef where adrelid = col.attrelid and adnum = col.attnum;
	if found and not v_is_fk then
		v_val := pg_get_expr(coldef, col.attrelid);
	else
		con := null;
		-- raise notice '% %', v_is_pk, v_is_fk;
		if v_is_fk then
			if v_fk.confrelid = col.attrelid then continue;	-- exclude self-references
			else
				select nspname, relname into v_fsch, v_frel from pg_class c, pg_namespace n where c.relnamespace = n.oid and c.oid = v_fk.confrelid;
				select attname into v_fatt from pg_attribute where attrelid = v_fk.confrelid and attnum = v_fk.confkey[1];
				-- raise notice '%.%', v_frel, v_fatt;
				if not v_is_pk then
					case v_r
						when c_r_new then if lower(v_sch||'.'||v_tab) <> lower(v_fsch||'.'||v_frel) then v_val := ad2(v_fsch||'.'||v_frel); end if;
						when c_r_last then execute 'select max('||v_fatt||') from '||v_fsch||'.'||v_frel into v_val;
						when c_r_rand then execute 'select '||v_fatt||' from '||v_fsch||'.'||v_frel||'  order by random() limit 1' into v_val;
					end case;
				end if;
				if v_val is null and lower(v_sch||'.'||v_tab) <> lower(v_fsch||'.'||v_frel) then v_val := ad2(v_fsch||'.'||v_frel); end if;
			end if;
		elsif v_is_pk then
			if v_val is null then
				-- try to find sequence
				select 'select nextval('''||nspname||'.'||relname||''')' into v_val 
            from pg_class c, pg_namespace n 
            where n.oid = c.relnamespace and relkind = 'S' and relname in (lower(v_tab||'_seq'), lower(v_tab||'_id_seq')) and n.nspname = v_sch
            limit 1;
				if found then
					execute v_val into v_id;
            else
               select 'select nextval('''||seq||''')' into v_val from zz_gen_seq_map where lower(tab) = lower(v_tab);
               if found then
                  execute v_val into v_id;
               end if;
            end if;
				if v_id is null then
					if col.typcategory = 'N' then
						execute 'select coalesce((select max('||col.attname||') from '||p_tab||'), 0) + 1' into v_id;
					else
						execute 'select max('||col.attname||') from '||p_tab into v_id;
					end if;
				end if;
				v_val := v_id;
			end if;
		end if;
		if v_val is null then
			case col.typname
				when 'character varying', 'text', 'bpchar' then v_val := gen_rnd(v_len, true);
				when 'date' then v_val := 'current_date - gen_rnd(3, false)::int';
				when 'time', 'time without time zone' then v_val := 'current_time';
				when 'timestamp without time zone', 'timestamp', 'timestamptz' then v_val := 'clock_timestamp() - gen_rnd(9, false)::interval';
				when 'boolean', 'bool' then v_val := 'gen_rnd(1, false)::int % 2 = 0';
				when 'integer' then v_val := gen_rnd(3, false)::int;
				when 'numeric' then 
					select numeric_precision, numeric_scale
					into v_num_precision, v_num_scale
					from information_schema.columns
					where lower(table_name) = lower(v_tab)
					  and lower(column_name) = lower(col.attname)
					  and lower(table_schema) = lower(current_schema);
					  
					v_val := gen_rnd(v_num_precision - v_num_scale, false)||(case v_num_scale = 0 when true then '' else '.'||gen_rnd(v_num_scale, false) end);
            when 'bytea' then v_val := gen_rnd(10, true);
            when 'oid' then 
               loid := lo_create(gen_rnd(9, false)::oid);
               select lowrite(lo_open(loid, x'00020000'::int), gen_rnd(10, true)::bytea) into v_foo;
               v_val := loid;
            when 'interval' then 
               v_val := '1 hour';
				else 
				case col.typcategory
					when 'S' then v_val := gen_rnd(v_len, true);
					when 'B' then v_val := 'true';
					when 'N' then v_val := '1';
					else v_val := null;
				end case;
			end case;
		end if;
		if v_val is null then
			raise notice 'ty=%', col.typname;
		elsif col.typcategory = 'S' or col.typname in ('bytea', 'interval') then
			v_val := ''''||v_val||'''';
		end if;
	end if;
	-- raise notice '%=%', col.attname, v_val;
	v_vals := v_vals||(case v_is_first when true then '' else ',' end)||coalesce(v_val, 'null');
	v_cols := v_cols||(case v_is_first when true then '' else ',' end)||(case col.attname = upper(col.attname) when true then '"'||col.attname||'"' else col.attname end);
	if v_is_first then v_is_first := false; end if;
end loop;
v_q := 'insert into '||p_tab||'('||v_cols||') values ('||v_vals||')';
begin
if current_setting('common.is_log_statement')::boolean then
raise notice '%', v_q;
end if;
exception when others then raise notice '%:%', sqlstate, sqlerrm;
end;
execute v_q;
-- raise notice 'q=%', v_q;
-- raise notice 'id=% pk=%', v_id, v_pk_name;
if v_id is null and v_pk_name is not null then
	execute 'select max('||v_pk_name||') from '||p_tab into v_id;
end if;
return v_id;
exception when others then 
	raise notice 'tab=%; %:%', p_tab,sqlstate, sqlerrm;
	raise notice 'q=%', v_q;
	return -1;
end;
$$;

