CREATE FUNCTION monitoring_special_cases_select(date_begin date, date_end date)
  RETURNS SETOF monitoring.monitor_special_cases_response_type_v
LANGUAGE plpgsql
AS $$
DECLARE r record;
		begin
		for r in

		SELECT
		row_number() over() as row_num,
		mc_case.id AS case_id,
		mc_case.uid AS case_num_str,
		public.pim_individual.surname || ' ' || public.pim_individual.name || ' ' || public.pim_individual.patr_name AS patient_full_name,
		public.pim_individual.birth_dt,
		extract(year from AGE(NOW(), public.pim_individual.birth_dt)) as age,
		public.pim_department.type_id as department_type_id,
		mc_case_state.pim_department_type_id as mc_case_state_department_type_id,
		public.pci_patient.social_group_id,
		public.md_soc_group.name as social_group,
		mc_case.patient_id AS patient_id,
		public.pim_gender.id as gender_id,
		public.pim_gender.name AS gender_name,
		monitoring.monitored_cases_list.case_id AS monitor_id,
		public.mc_case.create_date AS enter_date,
		public.md_clinic.short_name as mo_name,   -- name of medical organization
		public.md_clinic.id as mo_id,
		CASE WHEN monitoring.monitored_cases_list.case_id ISNULL THEN FALSE ELSE TRUE END AS is_on_control,
		COALESCE(hsp.f5, 0) as f5,
		CASE WHEN hsp.f5=1 THEN TRUE ELSE FALSE END AS is_hospitalized_before,
		create_date,
		m_diag_str,
		m_d_ids,
		diag_str,
		d_ids,
		doctor_ids,
		stage_ids,
		f1,
		f2,
		doctor.doctor_full_name,
		doctor.id doctor_id,
		severity.severity_level_id AS severity_level_id,
		severity.name AS severity_name,
		severity.point AS f3_severity_point,   --  фактор тяжести общего состояния больного
		social_factor.point AS f4_social_point,  -- социальный фактор
		COALESCE(hsp.f5, 0) AS f5_hospital_point,
		(COALESCE(f1, 0) + COALESCE(f2, 0) + COALESCE(severity.point, 0) + COALESCE(social_factor.point, 0) + COALESCE(hsp.f5, 0)) AS main_factor,
		public.mc_step.id as step_id

		-- раскомментировать для создания таблицы monitor_special_cases_response_type в случае изменения параметров запроса
		-- into table monitoring.monitor_special_cases_response_type

		FROM
		public.mc_case
		JOIN public.mc_step on (public.mc_step.case_id = public.mc_case.id)
		INNER JOIN public.pci_patient ON (public.mc_case.patient_id = public.pci_patient.id)

		INNER JOIN public.pim_individual ON (public.pci_patient.id = public.pim_individual.id)
		INNER JOIN public.mc_case_type ON (public.mc_case.case_type_id = public.mc_case_type.id)
		JOIN public.hsp_record on (public.mc_step.id = public.hsp_record.id)
		JOIN public.pim_department on (public.hsp_record.department_id = public.pim_department.id
		and public.pim_department.type_id = (select distinct id from pim_department_type where code = '4'))
		left outer join mc_case_state on (mc_case.state_id = mc_case_state.id)

		-- diagnosis part
		LEFT OUTER JOIN (
		SELECT diag_.case_id,
		string_agg((case when diag_.is_main = TRUE THEN diag_.d_str END), ', ') m_diag_str,
		monitoring.agg_ids((case when diag_.is_main = TRUE THEN diag_.d_ids END)) m_d_ids,
		string_agg((case when diag_.is_main = FALSE THEN diag_.d_str END), ', ') diag_str,
		monitoring.agg_ids((case when diag_.is_main = FALSE THEN diag_.d_ids END)) d_ids,
		monitoring.agg_ids((case when diag_.is_main = TRUE THEN diag_.doctor_ids END)) doctor_ids,
		monitoring.agg_ids((case when diag_.is_main = TRUE THEN diag_.stage_ids END)) stage_ids,
		sum((case when diag_.f1 ISNULL then 0 ELSE diag_.f1 END)) f1,
		sum((case when diag_.f2 ISNULL then 0 ELSE diag_.f2 END)) f2
		from (
		-- основной диагноз
		SELECT mcd.case_id,
		TRUE is_main,
		string_agg((md_diagnosis.code || ' ' || md_diagnosis.name), ', ') d_str,
		array_agg(md_diagnosis.id) d_ids,
		array_agg(mcd.doctor_id) doctor_ids,
		array_agg(mcd.stage_id) stage_ids,
		sum(criteria.point) f1,
		0 f2
		FROM public.mc_diagnosis mcd
		JOIN public.mc_case on (public.mc_case.id = mcd.case_id)
		JOIN public.md_diagnosis on (mcd.diagnos_id = md_diagnosis.id)
		LEFT JOIN monitoring.md_traumatology_diagnosis_criteria criteria on (criteria.diagnosis_id = mcd.diagnos_id and criteria.type_id = 1 and criteria.stage_id = mcd.stage_id)
		WHERE mcd.is_main = TRUE AND not mcd.stage_id ISNULL
		and public.mc_case.create_date BETWEEN date_begin and date_end
		GROUP BY mcd.case_id
		UNION
		-- сопутствующий диагноз
		SELECT mcd.case_id,
		FALSE is_main,
		string_agg((md_diagnosis.code || ' ' || md_diagnosis.name), ', ') d_str,
		array_agg(md_diagnosis.id) d_ids,
		array_agg(mcd.doctor_id) doctor_ids,
		array_agg(mcd.stage_id) stage_ids,
		0 f1,
		sum(criteria.point) f2
		FROM public.mc_diagnosis mcd
		JOIN public.mc_case on (public.mc_case.id = mcd.case_id )
		JOIN public.md_diagnosis on (mcd.diagnos_id = md_diagnosis.id)
		LEFT JOIN monitoring.md_traumatology_diagnosis_criteria criteria on (criteria.diagnosis_id = mcd.diagnos_id and criteria.type_id = 2)
		WHERE mcd.is_main = FALSE
		and public.mc_case.create_date BETWEEN date_begin and date_end
		GROUP BY mcd.case_id
		) diag_
		GROUP BY diag_.case_id
		) diag on (diag.case_id = mc_case.id)
		left join (
		SELECT mdep.id,
		public.pim_individual.surname || ' ' || public.pim_individual.name || ' ' || public.pim_individual.patr_name AS doctor_full_name
		from
		public.md_employee_position mdep
		join public.pim_employee_position on (public.pim_employee_position.id = mdep.id)
		join public.pim_employee on (public.pim_employee_position.employee_id = public.pim_employee.id)
		join public.pim_individual on (public.pim_individual.id = public.pim_employee.individual_id)
		) doctor on (doctor.id = diag.doctor_ids[1])
		-- diagnosis part end

		LEFT OUTER JOIN public.md_clinic ON (public.md_clinic.id = public.mc_case.clinic_id)
		LEFT OUTER JOIN public.md_soc_group ON (public.md_soc_group.id = public.mc_case.soc_group_id)
		LEFT OUTER JOIN public.pim_gender ON (public.pim_individual.gender_id = public.pim_gender.id)
		LEFT OUTER JOIN monitoring.monitored_cases_list ON (public.mc_case.id = monitoring.monitored_cases_list.case_id)
		left join (
		select mc_step._patient_id, array_agg(mc_step.case_id) case_ids, case when count(hsp_record.*)>0 then (select point from monitoring.md_traumatology_hospitalization where id = 2) else 0 end as f5
		from mc_step
		join hsp_record on (mc_step.id = hsp_record.id)
		JOIN mc_step_result on (mc_step_result.id = mc_step.result_id)
		where mc_step_result.is_closed = TRUE
		GROUP BY mc_step._patient_id
		) hsp on (mc_case.patient_id = hsp._patient_id and mc_case.id != any(hsp.case_ids))
		left join
		(
		select slc.severity_level_id, slc.point, msl.name from public.mc_severity_level msl
		left join monitoring.md_traumatology_severity_level_criteria slc
		on ( msl.id = slc.severity_level_id )
		) severity on (mc_case.severity_level_id = severity.severity_level_id )
		left join monitoring.md_traumatology_soc_group_criteria social_factor
		on ( mc_case.soc_group_id = social_factor.soc_group_id )
		WHERE
		-- do not remove duplicate lines - it is done intentionally
		public.mc_case.create_date BETWEEN date_begin and date_end
		and
		pim_department_type_id = type_id or pim_department_type_id isnull
		and
		-- do not remove duplicate lines - it is done intentionally
		public.mc_case.create_date BETWEEN date_begin and date_end

		loop
		RETURN NEXT r;
		END LOOP;
		END;

$$;

