CREATE FUNCTION fin_fill_pivot_steps_table_test_dev(p1_bill_id integer)
  RETURNS void
STRICT
LANGUAGE plpgsql
AS $$
DECLARE
    _code_snils_ind_id INTEGER;
BEGIN
    /*
        current version date 2016-05-20
    */
    --IF EXISTS (SELECT 1 FROM billing.fin_bill_steps WHERE bill_id = p1_bill_id) THEN DELETE FROM billing.fin_bill_steps WHERE bill_id = p1_bill_id; END IF;
    -- удаление того, что ушло
    DELETE 
      FROM billing.fin_bill_steps fbs
     WHERE fbs.bill_id = p1_bill_id
           AND NOT EXISTS (SElECT NULL
                             FROM tmp_fin_bill_generate fbg
                            WHERE fbg.bill_id = p1_bill_id 
                                  AND NOT fbg.is_sifted
                                  AND fbg.id = fbs.srv_rendered_id
                                  AND fbg.bill_id = fbs.bill_id);                                      
    -------------------------------------       
    _code_snils_ind_id := (SELECT id FROM public.pim_code_type WHERE code = 'SNILS');
    -- обновление и вставка новых записей
    WITH t_data AS (
      SELECT f.id AS srv_rendered_id,
            f.bdate AS srv_rendered_bdate,
            f.edate AS srv_rendered_edate,
            f.rdd_quantity,
            f.comment AS srv_rendered_comment,            
            (select d.code from public.md_diagnosis AS d where d.id = f.rdd_diagnosis_id) AS srv_diagnosis_code,
            f.tooth_number,
            f.service_id,
            f.service_code,
            f.service_name,
            p.id AS srv_prototype_id,
            coalesce (trim (p.code), '') AS srv_prototype_code,
            f.case_id,
            f.step_id,
            f.patient_id,
            f.id_pac,
            f.res_group_id,
            t.admission_date AS step_admission_date,
            t.outcome_date AS step_outcome_date,
            (select coalesce (trim (r.code), '') from public.md_profile AS r where r.id = t.profile_id) AS step_profile_code,
            t.main_diagnosis_id AS step_main_diagnosis_id,
            (select coalesce (trim (v.code), '') from  public.mc_vmp_type AS v where v.id = t.vmp_type_id) AS vmp_type_code,
            (select coalesce (trim (w.code), '') from public.mc_vmp_method AS w where w.id = t.vmp_method_id) AS vmp_method_code,
            f.bill_id,
            f.fin_bill_spec_item_id AS spec_item_id,
            f.tariff,
            f.tariff_code,
            f.quantity,
            f.srv_cul AS cul,
            f.price,
            f.price_pos_arr[1] AS price_pos_id,
            f.price_position_code AS price_pos_code,
            f.price_position_name AS price_pos_name,
            f.n_zap
        FROM 
            tmp_fin_bill_generate          AS f
            JOIN public.sr_service            AS s ON s.id = f.service_id
            LEFT JOIN public.sr_srv_prototype AS p ON p.id = s.prototype_id
            LEFT JOIN public.mc_step          AS t ON t.id = f.step_id 
        WHERE
            f.bill_id = p1_bill_id AND NOT f.is_sifted
    ), upd AS (
      UPDATE billing.fin_bill_steps AS fbs      
         SET srv_rendered_bdate = td.srv_rendered_bdate, 
             srv_rendered_edate = td.srv_rendered_edate, 
             srv_rendered_quantity = td.rdd_quantity, 
             srv_rendered_comment = td.srv_rendered_comment, 
             srv_diagnosis_code = td.srv_diagnosis_code, 
             tooth_number = td.tooth_number, 
             service_id = td.service_id, 
             service_code = td.service_code, 
             service_name = td.service_name, 
             srv_prototype_id = td.srv_prototype_id, 
             srv_prototype_code = td.srv_prototype_code,
             case_id = td.case_id, 
             step_id = td.step_id, 
             patient_id = td.patient_id, 
             id_pac = td.id_pac, 
             res_group_id = td.res_group_id, 
             step_admission_date = td.step_admission_date, 
             step_outcome_date = td.step_outcome_date, 
             step_profile_code = td.step_profile_code, 
             step_main_diagnosis_id = td.step_main_diagnosis_id, 
             vmp_type_code = td.vmp_type_code, 
             vmp_method_code = td.vmp_method_code,
             --bill_id = td.bill_id, 
             spec_item_id = td.spec_item_id, 
             tariff = td.tariff, 
             tariff_code = td.tariff_code, 
             quantity = td.quantity, 
             cul = td.cul, 
             price = td.price, 
             price_pos_id = td.price_pos_id, 
             price_pos_code = td.price_pos_code, 
             price_pos_name = td.price_pos_name, 
             n_zap = td.n_zap
        FROM t_data AS td
       WHERE td.srv_rendered_id = fbs.srv_rendered_id
             AND td.bill_id = fbs.bill_id
   RETURNING fbs.srv_rendered_id, fbs.bill_id
 )
      INSERT 
        INTO billing.fin_bill_steps(srv_rendered_id, srv_rendered_bdate, srv_rendered_edate, srv_rendered_quantity, srv_rendered_comment, srv_diagnosis_code, tooth_number, 
				    service_id, service_code, service_name, srv_prototype_id, srv_prototype_code,
				    case_id, step_id, patient_id, id_pac, res_group_id, step_admission_date, step_outcome_date, step_profile_code, step_main_diagnosis_id, vmp_type_code, vmp_method_code,
				    bill_id, spec_item_id, tariff, tariff_code, quantity, cul, price, price_pos_id, price_pos_code, price_pos_name, n_zap)
      SELECT td.srv_rendered_id, td.srv_rendered_bdate, td.srv_rendered_edate, td.rdd_quantity, td.srv_rendered_comment, td.srv_diagnosis_code, td.tooth_number,
             td.service_id, td.service_code, td.service_name, td.srv_prototype_id, td.srv_prototype_code, 
             td.case_id, td.step_id, td.patient_id, td.id_pac, td.res_group_id, td.step_admission_date, td.step_outcome_date, td.step_profile_code, td.step_main_diagnosis_id, td.vmp_type_code, td.vmp_method_code,
             td.bill_id, td.spec_item_id, td.tariff, td.tariff_code, td.quantity, td.cul, td.price, td.price_pos_id, td.price_pos_code, td.price_pos_name, td.n_zap
        FROM t_data td 
   LEFT JOIN upd u 
          ON(td.srv_rendered_id = u.srv_rendered_id
             AND td.bill_id = u.bill_id)
       WHERE u.srv_rendered_id IS NULL;
   --RETURNING t.id
/*      
    WITH diags AS 
    (
        SELECT 
            f.bill_id, 
            f.srv_rendered_id, 
            (SELECT coalesce (trim (md.code), '') 
               FROM public.mc_diagnosis AS m 
          LEFT JOIN public.md_diagnosis AS md 
                 ON md.id = m.diagnos_id 
              WHERE m.id = f.step_main_diagnosis_id 
                   AND coalesce (m.is_main, FALSE)) AS m_diag_code,
           (SELECT string_agg (DISTINCT (coalesce (trim (od.code), '')), ';') -- !!!
              FROM public.mc_diagnosis AS o  
         LEFT JOIN public.md_diagnosis AS od 
                ON od.id = o.diagnos_id 
             WHERE o.step_id = f.step_id 
                   AND NOT coalesce (o.is_main, FALSE))  AS o_diag_arr
        FROM billing.fin_bill_steps AS f
       WHERE f.bill_id = p1_bill_id
       GROUP BY 1, 2, 3
    )
    UPDATE billing.fin_bill_steps AS f
    SET 
        step_diagnosis_main = d.m_diag_code, 
        step_diagnosis_other = d.o_diag_arr --!!!
    FROM
        diags AS d
    WHERE
        f.bill_id = d.bill_id 
        AND f.srv_rendered_id = d.srv_rendered_id;
 */       
    WITH doctors_diags AS 
    (
       SELECT
            f.bill_id,
            f.srv_rendered_id,
            coalesce (p.employee_id::TEXT, '') AS doctor_code,
            coalesce (nullif (trim (p.code), ''), trim (e.number), '') AS doctor_code_regional,
            ARRAY [coalesce (trim (s.code), ''), coalesce (trim (s.e_code), '')] AS speciality_code_arr,
            coalesce (trim (r.code), '') AS pos_role_code,
            p.position_id,
            coalesce (trim (d.code), '') AS department_code,
            coalesce (trim (d.name), '') AS department_name,
            regexp_replace 
            (
                replace (replace ((array_agg (coalesce (trim (i.code), '') ORDER BY i.issue_dt DESC NULLS LAST))[1], '-', ''), ' ', ''), 
                '(...)(...)(...)(..)', 
                '\1-\2-\3 \4'
            ) AS snils,
	    (SELECT coalesce (trim (md.code), '') 
               FROM public.mc_diagnosis AS m 
          LEFT JOIN public.md_diagnosis AS md 
                 ON md.id = m.diagnos_id 
              WHERE m.id = f.step_main_diagnosis_id 
                   AND coalesce (m.is_main, FALSE)) AS m_diag_code,
           (SELECT string_agg (DISTINCT (coalesce (trim (od.code), '')), ';') -- !!!
              FROM public.mc_diagnosis AS o  
         LEFT JOIN public.md_diagnosis AS od 
                ON od.id = o.diagnos_id 
             WHERE o.step_id = f.step_id 
                   AND NOT coalesce (o.is_main, FALSE))  AS o_diag_arr
        FROM
            billing.fin_bill_steps                 AS f
            LEFT JOIN public.sr_res_group          AS g ON g.id = f.res_group_id
            LEFT JOIN public.pim_employee_position AS p ON p.id = g.responsible_id
            LEFT JOIN public.pim_employee          AS e ON e.id = p.employee_id
            LEFT JOIN public.pim_position          AS t ON t.id = p.position_id
            LEFT JOIN public.pim_department        AS d ON d.id = t.department_id
            LEFT JOIN public.pim_position_role     AS r ON r.id = t.role_id
            LEFT JOIN public.pim_speciality        AS s ON s.id = t.speciality_id
            LEFT JOIN public.pim_indiv_code        AS i ON i.indiv_id = e.individual_id AND i.type_id = (SELECT id FROM public.pim_code_type WHERE code = 'SNILS')
       WHERE
            f.bill_id = p1_bill_id
        GROUP BY 1, 2, 3, 4, 5, 6, 7, 8, 9
    )
    UPDATE billing.fin_bill_steps AS f
    SET 
        doctor_code          = d.doctor_code            ,
        doctor_code_regional = d.doctor_code_regional	,
        speciality_code_arr  = d.speciality_code_arr  	,
        pos_role_code        = d.pos_role_code          ,
        position_id          = d.position_id         	,
        department_code      = d.department_code    	,
        department_name      = d.department_name     	,
        doctor_snils         = d.snils                
    FROM
        doctors_diags AS d
    WHERE
        f.bill_id = d.bill_id AND f.srv_rendered_id = d.srv_rendered_id
    ;
    WITH steps AS
    (
        SELECT DISTINCT
            f.bill_id,
            f.step_id,
            coalesce (trim (d.code), '') AS hsp_department_code,
            coalesce (trim (d.name), '') AS hsp_department_name,
            --coalesce (trim (t.code), '') AS visit_type_code,
						(select coalesce (trim (t.code), '') from public.plc_visit_type    AS t where  t.id = v.type_id)AS visit_type_code,
            --coalesce (trim (p.code), '') AS visit_place_code,
						(select coalesce (trim (p.code), '') from public.plc_visit_place   AS p where  p.id = v.place_id) AS visit_place_code,
            --coalesce (trim (i.code), '') AS visit_inc_code,
						(select coalesce (trim (i.code), '') from  public.plc_initiator     AS i where i.id = v.initiator_id) AS visit_inc_code,
            ARRAY [coalesce (trim (g.code), ''), coalesce (trim (g.e_code), '')] AS visit_goal_code_arr,
            coalesce (trim (g.name), '') AS visit_goal_name,
            h.bed_days_amount
        FROM
            billing.fin_bill_steps              AS f
            LEFT JOIN public.plc_visit         AS v ON v.id = f.step_id
            LEFT JOIN public.mc_case_init_goal AS g ON g.id = v.goal_id
            LEFT JOIN public.hsp_record        AS h ON h.id = f.step_id
            LEFT JOIN public.pim_department    AS d ON d.id = h.department_id
        WHERE
            f.bill_id = p1_bill_id
    )
    UPDATE billing.fin_bill_steps AS f
    SET 
        visit_type_code      = s.visit_type_code    ,
        visit_place_code     = s.visit_place_code   ,
        visit_inc_code       = s.visit_inc_code     ,
        visit_goal_code_arr  = s.visit_goal_code_arr,
        visit_goal_name      = s.visit_goal_name    ,
        hsp_department_code  = s.hsp_department_code,
        hsp_department_name  = s.hsp_department_name,
        bed_days_amount      = s.bed_days_amount
    FROM
        steps AS s
    WHERE
        f.bill_id = s.bill_id AND f.step_id = s.step_id
    ;
END;
$$;

