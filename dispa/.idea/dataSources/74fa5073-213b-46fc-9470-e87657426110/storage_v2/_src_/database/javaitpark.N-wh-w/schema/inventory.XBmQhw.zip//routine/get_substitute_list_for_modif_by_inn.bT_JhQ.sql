CREATE FUNCTION get_substitute_list_for_modif_by_inn(modifid integer, orgid integer, innid integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
DECLARE
BEGIN
return (select inventory.get_substitute_list_for_modif(modifId, orgId,innId));
END;
$$;

