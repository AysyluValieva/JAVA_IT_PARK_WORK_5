CREATE FUNCTION func_pim_room_sync_hospital_unused_bed()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
/*
при создании/редактировании/удалении ПАЛАТЫ перезазапишем все исключения возможности использования коек в КФ
если ПАЛАТА ограничена датами создания и закрытия
*/
DECLARE
    rez             INTEGER;
BEGIN
    IF (TG_OP = 'DELETE') THEN
        -- при удалении записи ПАЛАТЫ почистим все исключения
        DELETE FROM hospital.unused_bed where nlevel(bed_tree) = 4 and subpath(bed_tree,3,1) = OLD.id::text::ltree;
        RETURN OLD;
    ELSE
        -- если было изменение дат в подразделении и это изменение отличается от исключений в бд
        WITH w_tree as (
            WITH room as (
                SELECT  d.id as d_id,
                        dp.id as dp_id,
                        p.id as p_id,
                        r.id as r_id,
                        d.id :: TEXT :: LTREE || p.id :: TEXT || p.id :: TEXT || r.id :: TEXT AS bed_tree,
                        r.from_dt - 1 as from_dt,
                        r.to_dt,
                        unnest(array[(r.from_dt - 1), r.to_dt]) as dt_dt
                FROM    pim_room r
                        JOIN LATERAL (select from pim_room_resource prr where prr.room_id = r.id limit 1) prr on true -- палата является ресурсом
                        JOIN pim_department d ON d.id = r.department_id
                        JOIN md_department_profile dp ON d.id = dp.department_id
                        JOIN md_profile p ON p.id = dp.profile_id
                WHERE   r.id = NEW.id
                union ALL
                SELECT -- исключения по статусам койки (дату действия статуса смотрим до следующего изменения статуса)
                    d.id as d_id,
                    dp.id as dp_id,
                    p.id as p_id,
                    r.id as r_id,
                    d.id :: TEXT :: LTREE || p.id :: TEXT || p.id :: TEXT || r.id :: TEXT AS bed_tree,
                    --prs.from_dt as from_dt,
                    --null::date as to_dt,
                    case when psus.exploitation then prs.from_dt - 1 else null::date end as from_dt,
                    case when psus.exploitation then null::date else prs.from_dt end as to_dt,
                    case when psus.exploitation then prs.from_dt - 1 else prs.from_dt end as dt_dt
                FROM pim_room r
                    JOIN LATERAL (select from pim_room_resource prr where prr.room_id = r.id limit 1) prr on true -- палата является ресурсом
                    JOIN pim_department d ON d.id = r.department_id
                    JOIN md_department_profile dp ON d.id = dp.department_id
                    JOIN md_profile p ON p.id = dp.profile_id
                    join pim_room_state prs on prs.room_id = r.id
                    join pim_stock_unit_state psus on psus.id = prs.state_id
                WHERE r.id = NEW.id
                    and prs.from_dt between coalesce(r.from_dt, prs.from_dt) and coalesce(r.to_dt, prs.from_dt) -- после основной даты закрытия койки изменения статусов не смотрим (но в случае изменения pim_bed пересчитываем и статусы заново)
                ),
            room_profile as (
                select r.r_id, rp.profile_id from room r join md_room_profile rp on rp.room_id = r.r_id and rp.profile_id = r.p_id group by 1, 2
                ),
            room_tree as (
                select r.* from room r where not exists (select from room_profile rp where rp.r_id = r.r_id)
                union all
                select r.* from room r join room_profile rp on r.r_id = rp.r_id and r.p_id = rp.profile_id
                )
            select DISTINCT * from room_tree
        ),

        w_tree_sort as (
            select  *, sum(sort) over (partition by bed_tree, dt_dt order by bed_tree, from_dt, sort, dt_dt, sort_name) as dd -- количество открытий и закрытий в один день
            FROM    (
                select  bed_tree, from_dt, sort, dt_dt, sort_name, LAG (sort, 1, 0) over (partition by bed_tree order by bed_tree, from_dt, sort, dt_dt, sort_name) as sort_lag, LEAD (sort, 1, -1) over (partition by bed_tree order by bed_tree, from_dt, sort, dt_dt, sort_name) as sort_lead
                from    (
                    select  bed_tree, from_dt, 2 as sort, dt_dt, 'begin' as sort_name from w_tree where from_dt is not null
                    UNION ALL
                    select  bed_tree, to_dt, 1, dt_dt, 'end' from w_tree where to_dt is not null
                    GROUP BY 1, 2, 3, 4, 5
                    order by 1, 2, 3, 4, 5
                    )t
                )t
        ),

        w_tree_new as  (-- расчетное состояние исключений по ПАЛАТЕ и статусам палаты
            select  bed_tree, daterange(null, from_dt, '[]') as date_range, concat('по ', to_char(from_dt, 'dd.mm.yyyy'), ' эта палата недоступна') as comment from w_tree_sort where sort_lag = 0 and sort = 2
            UNION ALL
            select  bed_tree, daterange(from_dt, null, '[]') as date_range, concat('c ', to_char(from_dt, 'dd.mm.yyyy'), ' эта палата недоступна') as comment from w_tree_sort where sort_lag = 0 and sort_lead = -1 and sort = 1
            UNION ALL
            select  bed_tree, daterange(from_dt, lead_dt, '[]') as date_range, concat('c ', to_char(from_dt, 'dd.mm.yyyy'), ' по ' || to_char(lead_dt, 'dd.mm.yyyy'), ' эта палата недоступна')
            from   (
                select *, lead(from_dt) over (partition by bed_tree order by bed_tree, from_dt) as lead_dt
                from w_tree_sort
                where --sort_lag <> 0
                    sort <> coalesce(sort_lag, 0)
                order by 1, 2, 3
                )t
            WHERE   sort = 1
                --and from_dt IS DISTINCT FROM  lead_dt
                and coalesce(from_dt, lead_dt) <= coalesce(lead_dt, from_dt)
            ),

        w_tree_bd as (
            select id, bed_tree, date_range, comment
            from hospital.unused_bed
            where nlevel(bed_tree) = 4 and subpath(bed_tree, 3, 1) = new.id::text::ltree
            ),

        w_tree_delta as (
            select  bed_tree as delta_bed_tree, date_range as delta_date_range, comment as delta_comment,
                sum(delta) as delta -- 1 - есть только в новом состоянии, добавляем в дельта
                                    -- 2 - есть только в бд, удаляем
                                    -- 3 - есть и там и там, ничего не делаем
            from (
                select distinct bed_tree, date_range, comment, 1 as delta from w_tree_new
                union all
                select bed_tree, date_range, comment, 2 as delta from w_tree_bd
                )t
            group by bed_tree, date_range, comment
            ),

        del_w_tree_bd as (
            delete from hospital.unused_bed using w_tree_delta
            WHERE bed_tree = delta_bed_tree and date_range = delta_date_range and comment = delta_comment
                and delta = 2
            RETURNING 1
            ),

        ins_w_tree_bd as (
            insert into hospital.unused_bed (bed_tree, date_range, comment)
            select delta_bed_tree, delta_date_range, delta_comment from w_tree_delta where delta = 1
            RETURNING 1
            )
        select 1 into REZ;
        RETURN NEW;
    END IF;
END;
$$;

