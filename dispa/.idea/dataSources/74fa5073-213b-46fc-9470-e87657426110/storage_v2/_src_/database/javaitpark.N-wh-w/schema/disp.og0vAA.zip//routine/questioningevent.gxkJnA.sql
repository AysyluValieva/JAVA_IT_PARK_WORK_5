CREATE FUNCTION questioningevent(xid integer, xcaseid integer, xq1 integer, xq2 integer, xq3 integer, xq4 integer, xq5 integer, xq6 integer, xq7 integer, xq8 integer, xq9 integer, xq10 integer, xq11 integer, xq12 integer, xq13 integer, xq14 integer, xq15 integer, xq16 integer, xq17 integer, xq18 integer, xq19 integer, xq20 integer, xq21 integer, xq22 integer, xq23 integer, xq24 integer, xq25 integer, xq26 integer, xq27 integer, xq28 integer, xq29 integer, xq30 integer, xq31 integer, xq32 integer, xq33 integer, xq34 integer, xq35 integer, xq36 integer, xq37 integer, xq38 integer, xq39 integer, xq40 integer, xq41 integer, xq42 integer, xq43 integer, xq44 integer, xq45 integer, xq46 integer, xq47 character varying, xq48 character varying, xq49 character varying, xq50 character varying, xqa1 integer, xqa2 integer, xqa3 integer, xqa4 integer, xqa5 character varying, xqa6 integer, xqa7 integer, xqa8 integer, xqa9 integer, xqa10 integer, xqa11 integer, xqa12 integer, xqa13 integer, xqa14 integer, xqa15 integer, xqa16 integer, xqa17 integer, xqa18 integer, xqa19 integer, xqa20 integer, xqa21 integer, xqa22 integer, xqa23 integer, xqa24 integer, xqa25 integer, xqa26 integer, xqa27 integer, xqa28 integer, xqa29 integer, xqa30 integer, xqa31 integer, xqa32 integer, xqa33 integer, xserviceid integer, xresource integer, xdate character varying)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
          i integer;
          msrid integer;
          stepid integer;
          sysresid integer;
          oldstepid integer;
        begin
          update disp.md_event_questioning set
          q1=xq1,
          q2 = xq2,
          q3 = xq3,
          q4 = xq4,
          q5 = xq5,
          q6 = xq6,
          q7 = xq7,
          q8 = xq8,
          q9 = xq9,
          q10 = xq10,
          q11 = xq11,
          q12 = xq12,
          q13 = xq13,
          q14 = xq14,
          q15 = xq15,
          q16 = xq16,
          q17 = xq17,
          q18 = xq18,
          q19 = xq19,
          q20 = xq20,
          q21 = xq21,
          q22 = xq22,
          q23 = xq23,
          q24 = xq24,
          q25 = xq25,
          q26 = xq26,
          q27 = xq27,
          q28 = xq28,
          q29 = xq29,
          q30 = xq30,
          q31 = xq31,
          q32 = xq32,
          q33 = xq33,
          q34 = xq34,
          q35 = xq35,
          q36 = xq36,
          q37 = xq37,
          q38 = xq38,
          q39 = xq39,
          q40 = xq40,
          q41 = xq41,
          q42 = xq42,
          q43 = xq43,
          q44 = xq44,
          q45 = xq45,
          q46 = xq46,
          q47 = xq47,
          q48 = xq48,
          q49 = xq49,
          q50 = xq50,
          qa1=xqa1,
          qa2 = xqa2,
          qa3 = xqa3,
          qa4 = xqa4,
          qa5 = xqa5,
          qa6 = xqa6,
          qa7 = xqa7,
          qa8 = xqa8,
          qa9 = xqa9,
          qa10 = xqa10,
          qa11 = xqa11,
          qa12 = xqa12,
          qa13 = xqa13,
          qa14 = xqa14,
          qa15 = xqa15,
          qa16 = xqa16,
          qa17 = xqa17,
          qa18 = xqa18,
          qa19 = xqa19,
          qa20 = xqa20,
          qa21 = xqa21,
          qa22 = xqa22,
          qa23 = xqa23,
          qa24 = xqa24,
          qa25 = xqa25,
          qa26 = xqa26,
          qa27 = xqa27,
          qa28 = xqa28,
          qa29 = xqa29,
          qa30 = xqa30,
          qa31 = xqa31,
          qa32 = xqa32,
          qa33 = xqa33
          where id = xid;
          if (select count(msr.id) from MD_SRV_RENDERED msr
              left join SR_SRV_RENDERED ssr on ssr.id = msr.id
              where msr.case_id = xcaseId and ssr.service_id = xserviceid) = 0 then
              i = nextval('sr_srv_rendered_seq');
              sysresid = nextval('sr_res_group_seq');
              insert into SR_RES_GROUP(id, bdate, edate, is_system, name, department_id, org_id, responsible_id, is_available_in_electronic_queue, label_id, template_res_group_id)
                select sysresid as id, bdate, edate, TRUE as is_system, name, department_id, org_id, responsible_id, is_available_in_electronic_queue, label_id, xresource
                from SR_RES_GROUP
                where id = xresource;
              stepid = (select disp.find_insert_mc_step(xid, xdate, xcaseId, xresource));
              insert into SR_SRV_RENDERED (id, service_id, bdate, res_group_id, customer_id, is_rendered, edate, quantity, funding_id, org_id, payment_status_id)
                values (i, xserviceid, COALESCE(to_date(xdate, 'DD.MM.YYYY'), current_date), xresource, (select indiv_id from disp.md_event_patient where id = xid), TRUE, COALESCE(to_date(xdate, 'DD.MM.YYYY'), current_date), 1,
                (select me.pay_type from disp.md_event me left join disp.md_event_patient mep on mep.event_id=me.id  where mep.id=xid),
                (select me.org_id from disp.md_event_patient mep left join disp.md_event me on me.id = mep.event_id where mep.id = xid), 1);
              insert into MD_SRV_RENDERED (id, case_id, step_id) values (i, xcaseId, stepid);
          else
              select msr.id into msrid from MD_SRV_RENDERED msr join SR_SRV_RENDERED ssr on ssr.id = msr.id where msr.case_id = xcaseId and ssr.service_id = xserviceid;
              i = msrid;
              if (select res_group_id from SR_SRV_RENDERED where id = msrid) <> xresource then
                oldstepid = (select step_id from MD_SRV_RENDERED where id = msrid);
                stepid = (select disp.find_insert_mc_step(xid, xdate, xcaseId, xresource));
                update MD_SRV_RENDERED set step_id = stepid where id = msrid;
                if (select count(1) = 0 from md_srv_rendered where step_id = oldstepid) then
                  delete from mc_step where id = oldstepid;
                end if;
              end if;
              update SR_SRV_RENDERED set bdate = to_date(xdate, 'DD.MM.YYYY'), res_group_id = xresource
                where id = msrid;
          end if;
          update MC_CASE set create_date = COALESCE(to_date(xdate, 'DD.MM.YYYY'), current_date),
            open_date = COALESCE(to_date(xdate, 'DD.MM.YYYY'), current_date)
            where id = xcaseId;
          -- change STATUS
          update disp.md_event_service_patient set status = 4
              where id = (select mesp.id from disp.md_event_patient mep
                left join disp.md_event_service_patient mesp on mesp.event_patient_id = mep.id
                inner join disp.md_event_service mes on mes.id = mesp.service_id and mes.service_id = xserviceid
                where mep.id = xid);
          return i;
        end;
$$;

