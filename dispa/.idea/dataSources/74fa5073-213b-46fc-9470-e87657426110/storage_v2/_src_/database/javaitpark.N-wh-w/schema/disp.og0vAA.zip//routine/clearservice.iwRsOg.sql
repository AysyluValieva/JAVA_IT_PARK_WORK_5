CREATE FUNCTION clearservice(xssrid integer, xmespid integer, xcaseid integer, xmesid integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
          is_link boolean;
          created boolean;
          serviceid integer;
          diagnosis_id integer;
          is_closing_service boolean;
          stepid integer;
        begin
          select service_id into serviceid from sr_srv_rendered where id = xssrid;

          select (count(1) > 0) into is_link from disp.md_event_service_link where service_id = xssrid and event_service_id = xmesid and case_id = xcaseid;
          created = false;
          if (is_link) then
	          select is_created into created from disp.md_event_service_link where service_id = xssrid and event_service_id = xmesid and case_id = xcaseid;
	        end if;
          if (is_link) then
            delete from disp.event_service_protocol_data where service_id = xssrid;
            delete from disp.md_event_service_link where service_id = xssrid and event_service_id = xmesid and case_id = xcaseid;
          end if;
          if ((is_link and created) or (not is_link)) then
            delete from pci_dispensary where srv_rendered_id = xssrid;
            select step_id into stepid from md_srv_rendered where id = xssrid;
            delete from SR_SRV_RENDERED where id = xssrid;
            delete from MD_SRV_RENDERED where id = xssrid;
            if (select count(1) from md_srv_rendered where step_id = stepid) = 0 then
              delete from mc_step where id = stepid;
            end if;
          end if;

          update disp.md_event_service_patient set status = 1 where id = xmespid;

          delete from disp.md_disp_orphans_diagnosis_extended where id = (select diagnos_id from disp.md_disp_orphans_inspec where service_id = xssrid);
          delete from disp.md_disp_orphans_inspec where service_id = xssrid;

          select (mnds.code in ('Д1.18', 'ОН1.1')) into is_closing_service
          from disp.sr_srv_service_document sssd
          join public.md_norm_document_service mnds on mnds.id = sssd.document_service_id
          where sssd.service_id = serviceid
          and sssd.owner_org_id = (select me.org_id from disp.md_event me join disp.md_event_service mes on mes.event_id = me.id where mes.id = xmesid);

          if is_closing_service = true then
            update MC_CASE set closing_step_id = null where id = xcaseid;
          end if;

          select d.id into diagnosis_id from disp.md_dispr_diagnosis_service ds join mc_diagnosis d on ds.diagnosis_id = d.id where d.case_id = xcaseid and ds.service_id = serviceid;
          delete from mc_diagnosis where id = diagnosis_id;
        end;
$$;

