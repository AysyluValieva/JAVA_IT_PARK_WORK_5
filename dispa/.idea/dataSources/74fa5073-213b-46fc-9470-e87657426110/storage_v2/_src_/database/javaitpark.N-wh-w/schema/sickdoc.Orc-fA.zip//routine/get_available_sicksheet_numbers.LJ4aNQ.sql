CREATE FUNCTION get_available_sicksheet_numbers(p_empl_pos_id integer, p_sicksheet_id integer)
  RETURNS SETOF character varying
LANGUAGE plpgsql
AS $$
DECLARE
  sicksheets VARCHAR[];
  available_numbers VARCHAR[];
  cur_number VARCHAR;
  ranges sickdoc.bso_distr_record_range[];
  r sickdoc.bso_distr_record_range;
  l_start VARCHAR;
  l_end VARCHAR;
  index INTEGER := 0;
BEGIN
  -- Сначала добавляем номер, который хотим отредактировать (если он есть)
  IF p_sicksheet_id NOTNULL THEN
    cur_number = left((SELECT number FROM sickdoc.sickdoc WHERE ID = p_sicksheet_id),9);
    IF cur_number NOTNULL THEN
      sicksheets[index] = cur_number;
      index := index + 1;
    END IF;
  END IF;

  --Идем по всем записям сотрудника
    FOR r IN
      (SELECT ran.*
      FROM sickdoc.bso_distr_record distr
      INNER JOIN sickdoc.bso_distr_record_range ran ON ran.distr_record_id = distr.id
      WHERE distr.receiver_id = p_empl_pos_id)
    LOOP
    --Берем первые 9 символов, для исключения проблем связанных с переходом с 12 символов на 9(+3 - контрольное число - не указывается)
      l_start = lpad(left(r.start_num,9), 9, '0');
      l_end = lpad(left(COALESCE(r.end_num,r.start_num),9), 9, '0');
      IF l_start::bigint <= l_end::bigint THEN
        WHILE l_start::bigint <= l_end::bigint LOOP
          --Если этого номера нет в массиве, и он не используется то добавляем его
          IF ((SELECT NOT (SELECT l_start = ANY (sicksheets))) OR sicksheets ISNULL) AND (SELECT COUNT(1) FROM sickdoc.sickdoc WHERE left(number,9)=l_start) = 0
          THEN
            sicksheets[index] = l_start;
            index := index + 1;
          END IF;

          l_start := (l_start::bigint + 1);
        END LOOP;
      END IF;

    END LOOP;

  IF sicksheets NOTNULL THEN
    FOR i IN 0..array_upper(sicksheets, 1) LOOP
       RETURN NEXT sicksheets[i];
    END LOOP;
  END IF;
END;
$$;

