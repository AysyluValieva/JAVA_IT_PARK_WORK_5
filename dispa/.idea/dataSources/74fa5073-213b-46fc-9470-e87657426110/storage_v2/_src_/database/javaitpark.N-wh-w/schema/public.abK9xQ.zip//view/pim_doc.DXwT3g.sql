CREATE VIEW pim_doc AS
  SELECT pim_individual_doc.id,
    pim_individual_doc.type_id,
    pim_individual_doc.series,
    pim_individual_doc.number,
    pim_individual_doc.sha256,
    pim_individual_doc.code_id,
    pim_individual_doc.indiv_id
   FROM pim_individual_doc;

