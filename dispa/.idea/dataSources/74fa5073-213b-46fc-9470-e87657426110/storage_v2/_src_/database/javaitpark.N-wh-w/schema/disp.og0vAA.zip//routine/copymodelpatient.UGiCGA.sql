CREATE FUNCTION copymodelpatient(xid integer, base_model integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
		  i integer;
    begin
      i = nextval('disp.md_model_patient_id_seq');
      insert into disp.md_model_patient
          select i as id, 'Копия - '||name, gender_id, age, soc_group_id, gender, base, org_id
          from disp.md_model_patient
          where id = xid;

      insert into disp.md_model_patient_base
          select nextval('disp.md_model_patient_base_id_seq')::int as id, gender_id, age, i
          from disp.md_model_patient_base
          where model_id = xid;

      insert into disp.md_model_patient_address
          select nextval('disp.md_model_patient_address_id_seq')::int as id, address_type_id, i, address_id
          from disp.md_model_patient_address
          where model_id = xid;

      insert into disp.md_model_patient_benefit
          select nextval('disp.md_model_patient_benefit_id_seq')::int as id, benefit_type_id, benefit_id,
              i, start_date, end_date
          from disp.md_model_patient_benefit
          where model_id = xid;

      insert into disp.md_model_patient_d
          select nextval('disp.md_model_patient_d_id_seq')::int as id, registr_id, i,
              start_date, end_date
          from disp.md_model_patient_d
          where model_id = xid;

      insert into disp.md_model_patient_district
          select nextval('disp.md_model_patient_district_id_seq')::int as id, i, district_id, org_id
          from disp.md_model_patient_district
          where model_id = xid;

      insert into disp.md_model_patient_job
          select nextval('disp.md_model_patient_job_id_seq')::int as id, org_type_id, org_id, depart_id, i
          from disp.md_model_patient_job
          where model_id = xid;
      return i;
      end;
$$;

