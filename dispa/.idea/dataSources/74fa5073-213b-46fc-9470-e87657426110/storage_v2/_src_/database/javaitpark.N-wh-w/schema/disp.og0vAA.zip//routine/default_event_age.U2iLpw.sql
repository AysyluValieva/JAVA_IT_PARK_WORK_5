CREATE FUNCTION default_event_age(xepid integer, xagree_date date, xdeny boolean)
  RETURNS text
LANGUAGE plpgsql
AS $$
dECLARE
  birth_date date;
  event_year text;
  model_age text [];
  exclude_age text [];
  agree_age INTEGER;
  ma INTEGER;
  period_begin INTERVAL;
  period_end INTERVAL;
  result_age INTEGER;

BEGIN
  if xagree_date is null then RETURN NULL; end if;
  birth_date = (select birth_dt from pim_individual where id = (select indiv_id from disp.md_event_patient where id = xepid));
  agree_age = date_part('year',age(xagree_date, birth_date))::int * 12 +
              date_part('month',age(xagree_date, birth_date))::int;

  event_year = date_part('year',(select start_date from disp.md_event where id = (select event_id from disp.md_event_patient WHERE id = xepid)));
  period_begin = age(to_date('01.01.'||event_year, 'DD.MM.YYYY'),birth_date);
  period_end = age(to_date('31.12.'||event_year, 'DD.MM.YYYY'),birth_date);

  model_age = (select ARRAY(select (split_part(model_ages,'.',1)::int * 12 + lpad(split_part(model_ages,'.',2),2,'0')::int)
                          from (select distinct regexp_split_to_table(replace(mmpb.age,' ',''),',') as model_ages
                                from disp.md_event_service mes
                                  left join disp.md_event_service_model mesm on mesm.event_service_id=mes.id
                                  left join disp.md_model_patient mmp on mmp.id=mesm.model_id
                                  inner join disp.md_model_patient_base mmpb on  mmpb.model_id=mmp.id
                                  left join pim_individual i on i.id= (select indiv_id from disp.md_event_patient where id=xepid)
                                where mes.event_id=(select event_id from disp.md_event_patient where id=xepid) and mmp.base is true and mmpb.gender_id=i.gender_id) as set_ages
                          where (split_part(model_ages,'.',1)::int * 12 + lpad(split_part(model_ages,'.',2),2,'0')::int)
                          between (date_part('year',period_begin)::int * 12 + date_part('month',period_begin)::int) and
                          (date_part('year',period_end)::int * 12 + date_part('month',period_end)::int)
                          order by 1));

  exclude_age = (select ARRAY(select (split_part(mep.event_age,'.',1)::int * 12 + lpad(split_part(mep.event_age,'.',2),2,'0')::int)
                  from disp.md_event_patient mep
                  left join public.mc_case mcc on mep.case_id = mcc.id
                  left join public.mc_step mcs on mcs.id = mcc.closing_step_id
                  left join disp.md_event_agreement mea on mea.event_patient_id = mep.id
                where
                  indiv_id = (select indiv_id from disp.md_event_patient where id = xepid)
                  and mep.event_id = (select event_id from disp.md_event_patient where id = xepid)
                  and is_deleted is not true
                  and (mcs.outcome_date is not null
                       or (xdeny and mea.agree))));

  IF array_length(model_age, 1) IS NULL THEN RETURN NULL; END IF;
  IF array_length(exclude_age, 1) IS NOT NULL THEN
    model_age = (select array_agg(el) from (SELECT unnest(model_age)
                                            EXCEPT
                                            SELECT unnest(exclude_age) ORDER BY 1) t (el));
  END IF;
  FOREACH ma IN ARRAY model_age
  LOOP
    IF ma >= agree_age
    THEN
      result_age := ma; EXIT;
    END IF;
  END LOOP;

  IF result_age%12 = 0
    THEN RETURN result_age/12;
    ELSE RETURN result_age/12 ||'.'||result_age%12;
  END IF;

END;
$$;

