CREATE FUNCTION get_individual_patr_name_index(patient_id integer)
  RETURNS character varying
IMMUTABLE
STRICT
LANGUAGE SQL
AS $$
select patr_name from pim_individual where id = $1;
$$;

