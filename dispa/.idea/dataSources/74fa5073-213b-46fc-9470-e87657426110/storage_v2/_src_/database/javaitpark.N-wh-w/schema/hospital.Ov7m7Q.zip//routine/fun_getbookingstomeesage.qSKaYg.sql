CREATE FUNCTION fun_getbookingstomeesage(patiend_id integer, department_id integer, admission_date date, end_date date, is_current_dep boolean DEFAULT true)
  RETURNS SETOF character varying
LANGUAGE SQL
AS $$
with bo as (
    SELECT bo.bed_id, bo.reservation_id, bo.begin_dt, bo.end_dt, daterange(bo.begin_dt, bo.end_dt, '[]') as date_range, bs.code as bs_code
    FROM hospital.booking bo
        JOIN hospital.booking_status bs ON bo.status_id = bs.id
    WHERE bs.code IN ('2', '3')
          and daterange(bo.begin_dt, bo.end_dt, '[]') && daterange($3::date, $4::date, '[]')
          and bo.iscurrent = TRUE
    )
    select _msg::character varying
    from (
        select
            hb.begin_dt,
            concat(
                case hb.bs_code
                when '2' then 'Неподтвержденная'
                when '3' then 'Подтвержденная'
                end,
                ' бронь, на период ',
                concat('с ',to_char(hb.begin_dt, 'dd.mm.yyyy'), ' по ', to_char(hb.end_dt, 'dd.mm.yyyy')),
                '. (',
                concat(d.name, '/' || r.name, '/Койка № '|| mb.number),
                ')'
            ) as _msg
        from bo hb
            join md_bed mb on hb.bed_id = mb.id
            join pim_room r on mb.room_id = r.id
            join pim_department d on r.department_id = d.id
            join md_bed_resource mbr on mbr.bed_id = mb.id
            join md_bed_profile mbp on mb.bed_profile_id = mbp.id
            join lateral (
                 select hr.* from hsp_reservation hr where $5 = true and hb.reservation_id = hr.id and hr.department_id = coalesce(nullif($2, -1), hr.department_id) and $2 is not null
                 union all
                 select hr.* from hsp_reservation hr where $5 = false and hb.reservation_id = hr.id and hr.department_id <> coalesce($2, -1)
                 ) hr on true
            join md_referral mr on hr.referral_id = mr.id
        where
            mr.patient_id = coalesce(nullif($1, -1), mr.patient_id) and $1 is not null
        UNION ALL
        select -- добавляем брони которые входят в заявки найденные в 1й итерации, но по интервалам выходят за рамки указанного периода
            hb.begin_dt,
            concat(
                case hbs.code
                when '2' then 'Неподтвержденная'
                when '3' then 'Подтвержденная'
                end,
                ' бронь, на период ',
                concat('с ',to_char(hb.begin_dt, 'dd.mm.yyyy'), ' по ', to_char(hb.end_dt, 'dd.mm.yyyy')),
                '. (',
                concat(d.name, '/' || r.name, '/Койка № '|| mb.number),
                ')'
            )
        from bo
            join lateral (
                 select hb.* from hospital.booking hb where bo.reservation_id = hb.reservation_id and daterange(hb.begin_dt, hb.end_dt, '[]') << bo.date_range
                 union all
                 select hb.* from hospital.booking hb where bo.reservation_id = hb.reservation_id and daterange(hb.begin_dt, hb.end_dt, '[]') >> bo.date_range
                 ) hb on true
            JOIN hospital.booking_status hbs ON hb.status_id = hbs.id and hbs.code IN ('2', '3')
            join md_bed mb on hb.bed_id = mb.id
            join pim_room r on mb.room_id = r.id
            join pim_department d on r.department_id = d.id
            join md_bed_resource mbr on mbr.bed_id = mb.id
            join md_bed_profile mbp on mb.bed_profile_id = mbp.id
            join lateral (
                 select hr.* from hsp_reservation hr where $5 = true and hb.reservation_id = hr.id and hr.department_id = coalesce(nullif($2, -1), hr.department_id) and $2 is not null
                 union all
                 select hr.* from hsp_reservation hr where $5 = false and hb.reservation_id = hr.id and hr.department_id <> coalesce($2, -1)
                 ) hr on true
            join md_referral mr on hr.referral_id = mr.id
        where
            mr.patient_id = coalesce(nullif($1, -1), mr.patient_id) and $1 is not null
        )t
    order by t.begin_dt
$$;

