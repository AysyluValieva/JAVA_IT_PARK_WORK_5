CREATE FUNCTION fin_fill_pivot_policy_table(p1_bill_id integer)
  RETURNS void
STRICT
LANGUAGE plpgsql
AS $$
DECLARE 
    _code_grn_id INTEGER;
    _code_oms_id INTEGER;
BEGIN
    /*
        current version date 15.10.2014
        
        changelog 
    */
    IF EXISTS (SELECT 1 FROM fin_bill_policy WHERE bill_id = p1_bill_id) THEN DELETE FROM fin_bill_policy WHERE bill_id = p1_bill_id; END IF;
    
    _code_grn_id  := (SELECT id FROM pim_code_type WHERE code = 'OGRN'    );
    _code_oms_id  := (SELECT id FROM pim_code_type WHERE code = 'CODE_OMS');
    -------------------------первичное добавление--------------------------------------------------
    INSERT INTO fin_bill_policy (bill_id, id, belonging_type, item_id_arr)
        SELECT 
            bill_id, coalesce (active_policy_id, 0), belonging_type, array_agg (fin_bill_spec_item_id)
        FROM 
            fin_bill_generate 
        WHERE 
            bill_id = p1_bill_id AND NOT is_sifted
        GROUP BY 1, 2, 3
    ;
    -------------------------информация по полису--------------------------------------------------
    WITH t AS 
    (
        SELECT 
            f.bill_id,
            f.id,
            CASE WHEN i.code_id IS NULL THEN coalesce (trim (upper (t.code  )), '') ELSE 'ENP' END AS type,
            CASE WHEN i.code_id IS NULL THEN coalesce (trim (upper (i.series)), '') ELSE ''    END AS series,
            CASE WHEN i.code_id IS NULL THEN coalesce (trim (upper (i.number)), '') ELSE coalesce (trim (c.code), '') END AS number,
            i.issue_dt,
            i.issuer_id,
            o.work_territory_id,
            coalesce (trim (o.short_name), '') AS issuer_short_name,
            left (coalesce (trim (address__get_nearest_okato (o.work_territory_id)), ''), 5) AS issuer_okato,
            (array_agg (coalesce (trim (s.code), '') ORDER BY s.issue_dt DESC))[1] AS issuer_code_oms,
            (array_agg (coalesce (trim (n.code), '') ORDER BY n.issue_dt DESC))[1] AS issuer_ogrn
        FROM 
            fin_bill_policy            AS f
            JOIN pim_individual_doc    AS i ON i.id = f.id 
            LEFT JOIN pim_indiv_code   AS c ON c.id = i.code_id
            LEFT JOIN pim_doc_type     AS t ON t.id = i.type_id
            LEFT JOIN pim_organization AS o ON o.id = i.issuer_id
            LEFT JOIN pim_org_code     AS n ON n.org_id = o.id AND n.type_id = _code_grn_id
            LEFT JOIN pim_org_code     AS s ON s.org_id = o.id AND s.type_id = _code_oms_id
        WHERE
            f.bill_id = p1_bill_id
        GROUP BY 1, 2, 3, 4, 5, 6, 7, 8, 9
    )
    UPDATE fin_bill_policy AS f
    SET
        type                     = t.type             ,
        series                   = t.series           ,
        number                   = t.number           ,
        issue_dt                 = t.issue_dt         ,
        issuer_id                = t.issuer_id        ,
        issuer_work_territory_id = t.work_territory_id,
        issuer_code_oms          = t.issuer_code_oms  ,
        issuer_ogrn              = t.issuer_ogrn      ,
        issuer_okato             = t.issuer_okato     ,
        issuer_short_name        = t.issuer_short_name 
    FROM t 
    WHERE 
        f.bill_id = t.bill_id AND f.id = t.id
    ;
END;
$$;

