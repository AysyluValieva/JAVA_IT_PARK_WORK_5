CREATE FUNCTION do_event(xcase_id integer, xpatient_id integer, xclinic_id integer, event character varying)
  RETURNS boolean
LANGUAGE plpgsql
AS $$
DECLARE
result BOOLEAN;
BEGIN

event = regexp_replace(event, ':id', '$1', 'g');
event = regexp_replace(event, ':patient_id', '$2', 'g');
event = regexp_replace(event, ':clinic_id', '$3', 'g');

EXECUTE event
INTO result
USING xcase_id, xpatient_id, xclinic_id;
RETURN result;
EXCEPTION
  WHEN others THEN
   RAISE NOTICE 'SQLSTATE: %. QUERY: %', SQLSTATE, event;
   RETURN NULL;

END;
$$;

