CREATE FUNCTION fin_services_generate(p1_step_id integer, p2_service_code text, p3_check_in_case boolean, p4_one_srv_in boolean)
  RETURNS integer
STRICT
LANGUAGE plpgsql
AS $$
DECLARE 
    _clinic_id INTEGER;
    _case_id INTEGER;
    _service_id INTEGER;
    _srv_fin_type_id INTEGER;
    _new_id INTEGER;
    _r RECORD;
BEGIN
    /*
        current version date 2014-12-12
    */
    ------------------------------------------------------------------параметры----------------------------------------------------------------------
    _case_id := (SELECT case_id FROM mc_step WHERE id = p1_step_id)
    ;
    _clinic_id := (SELECT clinic_id FROM mc_case WHERE id = _case_id)
    ;
    ---------------------------------------------------проверка на заполнение обязательных полей-----------------------------------------------------
    IF
        _clinic_id IS NULL
    THEN
        RAISE EXCEPTION 'Не указано МО в случае';
    END IF;
    -----------------------------------------------проверка на уникальность кода фиктивной услуги в МО-----------------------------------------------
    IF
        (SELECT count (1) FROM sr_service WHERE org_id = _clinic_id AND code = p2_service_code) > 1 
    THEN
        RAISE EXCEPTION 'Фиктивная услуга не уникальна в МО';
    END IF;
    -----------------------------------------------------------заполнение параметров-----------------------------------------------------------------
    _service_id := (SELECT id FROM sr_service WHERE org_id = _clinic_id AND code = p2_service_code)
    ;
    _srv_fin_type_id := (SELECT funding_id FROM sr_service_fin_type WHERE service_id = _service_id ORDER BY funding_id = 1 DESC LIMIT 1)
    ;
    --------------------------------------------------------добавление фиктивной услуги--------------------------------------------------------------
    IF 
        p4_one_srv_in
    THEN
        IF
            NOT EXISTS (SELECT 1 FROM md_srv_rendered WHERE CASE WHEN p3_check_in_case THEN case_id = _case_id ELSE step_id = p1_step_id END)
        THEN
            FOR _r IN
                SELECT 
                    c.id AS case_id, s.id AS step_id, c.patient_id, s.res_group_id, s.outcome_date
                FROM
                    mc_case AS c, mc_step AS s 
                WHERE
                    c.id = s.case_id AND c.id = _case_id AND s.id = p1_step_id
            LOOP
                _new_id := nextval ('sr_srv_rendered_seq')
                ;
                INSERT INTO sr_srv_rendered (id, is_rendered, bdate, edate, quantity, customer_id, service_id, funding_id, res_group_id, org_id)
                    SELECT _new_id, TRUE, _r.outcome_date, _r.outcome_date, 1, _r.patient_id, _service_id, _srv_fin_type_id, _r.res_group_id, _clinic_id
                ;
                INSERT INTO md_srv_rendered (id, step_id, case_id) SELECT _new_id, _r.step_id, _r.case_id
                ;
            END LOOP;
        END IF;
    ELSE
        FOR _r IN
            SELECT 
                c.id AS case_id, s.id AS step_id, c.patient_id, s.res_group_id, s.outcome_date
            FROM
                mc_case                   AS c
                JOIN mc_step              AS s ON s.case_id = c.id 
                LEFT JOIN md_srv_rendered AS m ON m.case_id = c.id AND CASE WHEN NOT p3_check_in_case THEN m.step_id = s.id ELSE TRUE END
                LEFT JOIN sr_srv_rendered AS r ON r.id = m.id 
                LEFT JOIN sr_service      AS e ON e.id = r.service_id
            WHERE
                c.id = _case_id AND s.id = p1_step_id
            GROUP BY 1, 2, 3, 4, 5
            HAVING p2_service_code <> ALL (array_agg (coalesce (e.code, '0')))
        LOOP
            _new_id := nextval ('sr_srv_rendered_seq')
            ;
            INSERT INTO sr_srv_rendered (id, is_rendered, bdate, edate, quantity, customer_id, service_id, funding_id, res_group_id, org_id)
                SELECT _new_id, TRUE, _r.outcome_date, _r.outcome_date, 1, _r.patient_id, _service_id, _srv_fin_type_id, _r.res_group_id, _clinic_id
            ;
            INSERT INTO md_srv_rendered (id, step_id, case_id) SELECT _new_id, _r.step_id, _r.case_id
            ;
        END LOOP;
    END IF;
    
    RETURN _new_id
    ;
EXCEPTION
    WHEN NO_DATA_FOUND THEN RAISE EXCEPTION 'Не заполнены необходимые параметры';
END;
$$;

