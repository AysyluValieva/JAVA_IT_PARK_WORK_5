CREATE FUNCTION get_avg_count_emp(start_date date, end_date date, org_id integer, is_woman boolean)
  RETURNS integer
LANGUAGE plpgsql
AS $$
DECLARE
  date_temp date :=date_trunc('month',start_date);
  cnt_emp integer := 0;
  cnt_mon integer := 0;
  total integer := 0;
BEGIN
  while date_temp <= end_date loop
    if is_woman then
      select  count(e.id) into cnt_emp from pim_employee e
      join pim_employee_position ep on ep.employee_id=e.id
      join pim_individual i on i.id=e.individual_id
      where date_trunc('month',ep.start_date) <= date_temp
      and (date_trunc('month',ep.end_date) >= date_temp  or ep.end_date is null)
      and i.gender_id = 2
      and e.organization_id=org_id;
      date_temp := date_temp + interval '1 month';
      cnt_mon := cnt_mon + 1;
      total := total + cnt_emp;
    else
      select  count(e.id) into cnt_emp from pim_employee e
      join pim_employee_position ep on ep.employee_id=e.id
      where date_trunc('month',ep.start_date) <= date_temp
      and (date_trunc('month',ep.end_date) >= date_temp or ep.end_date is null) 
      and e.organization_id=org_id;
      date_temp := date_temp + interval '1 month';
      cnt_mon := cnt_mon + 1;
      total := total + cnt_emp;
    end if;
  end loop;
  total := total/cnt_mon;
  return total;
END;
$$;

