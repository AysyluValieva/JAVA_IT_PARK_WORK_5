CREATE FUNCTION update_request_doc_is_satisfied_status(requestdocid integer, modifid integer, fundsourceid integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE

BEGIN
if exists
   (select 1 from inventory.request_spec reqSpec where reqSpec.modif_id = modifId and reqSpec.request_doc_id = requestDocId and reqSpec.fin_fund_source_type_id = fundSourceId)
then
   update inventory.request_doc set is_satisfied=false where id = requestDocId;
end if;

END;
$$;

