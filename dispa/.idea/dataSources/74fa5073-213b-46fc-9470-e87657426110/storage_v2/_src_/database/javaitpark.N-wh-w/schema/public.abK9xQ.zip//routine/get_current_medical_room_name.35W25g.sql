CREATE FUNCTION get_current_medical_room_name(res_group_id integer)
  RETURNS character varying
LANGUAGE plpgsql
AS $$
declare
      result varchar(255);
begin
      select
         rm.name
      into result
      from
	 pim_room rm inner join md_bed bd on rm.id = bd.room_id
         inner join md_bed_resource br on br.bed_id=bd.id
         inner join sr_resource r on r.id = br.id
	 inner join sr_res_kind rk on r.res_kind_id=rk.id
	 inner join sr_res_group_relationship rgr on rgr.resource_id = r.id
      where
         rk.code='4'
         and rgr.group_id=res_group_id
      order by rgr.edatetime desc limit 1;

      return result;
end;
$$;

