CREATE FUNCTION del_dubl_pim_employee_position_resource()
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
                _r RECORD;
            BEGIN

                FOR _r IN SELECT
                               max(id) max,
                               min(id) min,
                               count(employee_position_id),
                               employee_position_id

                           FROM pim_employee_position_resource
                           GROUP BY employee_position_id
                           HAVING count(employee_position_id) > 1

                LOOP

                    PERFORM public.upd_fk_indiv('pim_employee_position_resource', _r.min, _r.max);

                    DELETE FROM pim_employee_position_resource
                    WHERE id = _r.min;
                    RAISE NOTICE 'удаленный pim_employee_position_resource id =% данные перенесли на id = %', _r.min, _r.max;

                END LOOP;
            END;
$$;

