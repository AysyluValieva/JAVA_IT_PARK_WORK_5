CREATE FUNCTION get_benefit_inn_form_dosage(_benefit_type text, _benefit_id integer, _ids_chain text, _values_chain text, OUT ids_chain text, OUT values_chain text)
  RETURNS SETOF record
LANGUAGE plpgsql
AS $$
DECLARE
       delim text DEFAULT '|';
    begin
        return query
        -- поиск если _ids_chain пустой и передают только наименование лекарства (либо наименование пустое)
        select t.ids_chain, t.values_chain
        from
            (SELECT
                min(mbi.id)::text as ids_chain,
                concat(mbi.latin_name, '/', mbi.rus_name)::text as values_chain,
                min(mbi.id) as l_id,
                null::int as f_id,
                null::int as d_id
            FROM md_benefit_detalization mbd
                JOIN md_benefit_inn mbi ON mbi.id = mbd.inn_id
            WHERE _benefit_type = 'international'
                  AND _ids_chain is null
                  AND current_date BETWEEN mbi.add_date AND coalesce(mbi.delete_date, current_date)
                  AND mbd.holding_id IS NULL
            group by 2
            UNION
            SELECT
                min(mbh.id)::text,
                concat(mbh.latin_name, '/', mbh.rus_name),
                min(mbh.id) as l_id,
                null::int as f_id,
                null::int as d_id
            FROM md_benefit_detalization mbd
                JOIN md_benefit_holding mbh ON mbh.id = mbd.holding_id
            WHERE _benefit_type = 'trade'
                AND _ids_chain is null
                AND current_date BETWEEN mbh.add_date AND coalesce(mbh.delete_date, current_date)
            group by 2
            -- поиск если _ids_chain пустой и передают только наименование лекарства (либо наименование пустое)
            order by 2)t;
    end;
$$;

