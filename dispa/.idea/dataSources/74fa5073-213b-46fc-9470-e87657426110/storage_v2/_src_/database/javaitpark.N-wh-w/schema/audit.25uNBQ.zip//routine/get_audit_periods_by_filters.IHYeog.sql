CREATE FUNCTION get_audit_periods_by_filters(_table_setting_id integer, _record_id character varying, _offset integer, _limit integer, _order character varying)
  RETURNS TABLE(id integer, description character varying)
LANGUAGE plpgsql
AS $$
DECLARE
                  base_query            VARCHAR;
                  error_message         VARCHAR;
                  partition_period_code VARCHAR;
                  shift                 VARCHAR;
                BEGIN
                  BEGIN
                    base_query = audit.get_audit_periods_by_filters_query(_table_setting_id, _record_id);
                    EXCEPTION
                    WHEN raise_exception
                      THEN
                        GET STACKED DIAGNOSTICS error_message = MESSAGE_TEXT;
                        IF error_message = 'BAD_REQUEST'
                        THEN
                          RETURN QUERY (SELECT 1 :: INTEGER, '1' :: VARCHAR WHERE 1 = 0);
                          RETURN;
                        ELSEIF error_message = 'ALL_TIME'
                          THEN
                            RETURN QUERY (SELECT 0 :: INTEGER, 'За все время' :: VARCHAR);
                            RETURN;
                        END IF;
                  END;

                  SELECT lower(pp.code)
                  INTO partition_period_code
                  FROM audit.partition_period pp
                    JOIN audit.table_setting ts ON pp.id = ts.partition_period_id
                  WHERE ts.id = _table_setting_id;

                  IF partition_period_code = 'quarter'
                  THEN shift = '3 month';
                  ELSE shift = concat('1 ', partition_period_code);
                  END IF;

                  base_query = replace(
                      base_query, ':select', '
                        replace(t.begin::VARCHAR, ''-'', '''')::INTEGER,
                        concat(''с '', to_char(t.begin, ''DD.MM.YYYY''), '' по '', to_char(t.begin + INTERVAL ''' || shift || ''',
                          ''DD.MM.YYYY''))::VARCHAR'
                  );

                  RETURN QUERY EXECUTE base_query;
                END;
$$;

