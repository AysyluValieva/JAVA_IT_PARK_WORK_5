CREATE FUNCTION alter_fks_proc(tab_n character varying, action character varying)
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE constrs RECORD;
            BEGIN
            FOR constrs IN
            WITH RECURSIVE
            t AS ( SELECT
            tc.constraint_name,
            tc.table_name,
            kcu.column_name,
            ccu.table_name  AS foreign_table_name,
            ccu.column_name AS foreign_column_name
            FROM
            information_schema.table_constraints AS tc
            JOIN information_schema.key_column_usage AS kcu
            ON tc.constraint_name = kcu.constraint_name
            JOIN information_schema.constraint_column_usage AS ccu
            ON ccu.constraint_name = tc.constraint_name
            WHERE constraint_type = 'FOREIGN KEY' AND ccu.table_name = tab_n
            )
            SELECT
            constraint_name,
            table_name,
            column_name,
            foreign_table_name,
            foreign_column_name
            FROM t
            LOOP
            EXECUTE 'alter table ' || constrs.table_name || ' drop constraint if exists ' || constrs.constraint_name || ';';
            EXECUTE
            'alter table ' || constrs.table_name || ' add  constraint ' || constrs.constraint_name || ' foreign key(' ||
            constrs.column_name || ') references ' || constrs.foreign_table_name || '(' || constrs.foreign_column_name ||
            ') ' || action || ';';
            END LOOP;
            END;
$$;

