CREATE FUNCTION update_driver_status()
  RETURNS integer
LANGUAGE plpgsql
AS $$
begin
  update gibdd.md_gibdd_reference mgr set is_reopen = false, reopen_dt = null  where reopen_dt  < current_date;
  update gibdd.md_gibdd_reference mgr
  set status = 2, close_reason_id = 3
  where (blank_date + 30 < current_date)
        and status = 1
        and is_reopen is not TRUE
        and ((select count(1) from gibdd.md_gibdd_service gs where gs.event_patient_id = mgr.id) <> (select count(1) from disp.md_event_service_patient esp where esp.event_patient_id = mgr.id));

  update gibdd.md_gibdd_reference_reference a set is_valid = false
    where is_valid is true
          and ((select status = 2 and close_reason_id = 3 from gibdd.md_gibdd_reference mgr where mgr.id = a.card_id)
          or  exp_date < current_date);


  return 1;
end;
$$;

