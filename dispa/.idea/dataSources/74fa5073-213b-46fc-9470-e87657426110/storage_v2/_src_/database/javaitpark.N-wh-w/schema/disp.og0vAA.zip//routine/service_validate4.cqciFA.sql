CREATE FUNCTION service_validate4(xmepid integer, xdate character varying)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
	  end_date date;

        begin
          select ms.outcome_date into end_date
           from disp.md_event_patient mep
           join mc_case mc on mep.case_id = mc.id
           join mc_step ms on ms.id = mc.closing_step_id
           where mep.id = xmepid;

          if ((end_date is null) or (end_date = to_date(xdate, 'DD.MM.YYYY'))) then
            return 1;
          else
            return 0;
          end if;
        end;
$$;

