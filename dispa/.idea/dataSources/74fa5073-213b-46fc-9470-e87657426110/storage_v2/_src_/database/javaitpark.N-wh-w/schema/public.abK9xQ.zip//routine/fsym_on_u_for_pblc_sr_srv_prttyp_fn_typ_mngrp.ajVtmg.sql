CREATE FUNCTION fsym_on_u_for_pblc_sr_srv_prttyp_fn_typ_mngrp()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
declare var_row_data text; 
                                declare var_old_data text; 
                                begin
                                   
                                  if 1=1 and "public".sym_triggers_disabled() = 0 then                                                                                                 
                                    var_row_data := 
          case when new."id" is null then '' else '"' || cast(cast(new."id" as numeric) as varchar) || '"' end||','||
          case when new."bdate" is null then '' else '"' || to_char(new."bdate", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when new."edate" is null then '' else '"' || to_char(new."edate", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when new."funding_id" is null then '' else '"' || cast(cast(new."funding_id" as numeric) as varchar) || '"' end||','||
          case when new."prototype_id" is null then '' else '"' || cast(cast(new."prototype_id" as numeric) as varchar) || '"' end; 
                                    var_old_data := 
          case when old."id" is null then '' else '"' || cast(cast(old."id" as numeric) as varchar) || '"' end||','||
          case when old."bdate" is null then '' else '"' || to_char(old."bdate", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when old."edate" is null then '' else '"' || to_char(old."edate", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when old."funding_id" is null then '' else '"' || cast(cast(old."funding_id" as numeric) as varchar) || '"' end||','||
          case when old."prototype_id" is null then '' else '"' || cast(cast(old."prototype_id" as numeric) as varchar) || '"' end; 
                                    if var_old_data is null or var_row_data != var_old_data then 
                                    insert into "public".sym_data                                                                                                                     
                                    (table_name, event_type, trigger_hist_id, pk_data, row_data, old_data, channel_id, transaction_id, source_node_id, external_data, create_time)                     
                                    values(                                                                                                                                                            
                                      'sr_srv_prototype_fin_type',                                                                                                                                            
                                      'U',                                                                                                                                                             
                                      688,                                                                                                                                             
                                      
          case when old."id" is null then '' else '"' || cast(cast(old."id" as numeric) as varchar) || '"' end,                                                                                                                                                      
                                      var_row_data,                                                                                                                                                      
                                      var_old_data,                                                                                                                                                   
                                      'public_sr_srv_prototype_fin_type_default',                                                                                                                                                
                                      txid_current(),                                                                                                                                               
                                      "public".sym_node_disabled(),                                                                                                                   
                                      null,                                                                                                                                               
                                      CURRENT_TIMESTAMP                                                                                                                
                                    );                                                                                                                                                                 
                                  end if;                                                                                                                                                              
                                  end if;                                                                                                                                                              
                                                                                                                                                                               
                                  return null;                                                                                                                                                         
                                end;
$$;

