CREATE FUNCTION anytextcat(anynonarray, text)
  RETURNS text
STABLE
STRICT
PARALLEL SAFE
COST 1
LANGUAGE SQL
AS $$
select $1::pg_catalog.text || $2
$$;

