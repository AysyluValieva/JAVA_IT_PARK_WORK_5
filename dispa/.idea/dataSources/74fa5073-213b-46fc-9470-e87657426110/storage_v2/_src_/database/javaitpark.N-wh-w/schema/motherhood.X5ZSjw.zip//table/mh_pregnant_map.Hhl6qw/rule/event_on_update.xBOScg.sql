CREATE RULE event_on_update AS
    ON UPDATE TO motherhood.mh_pregnant_map DO ( INSERT INTO event_handler.db_event_log (id, event_code, create_event_time, params)  SELECT nextval('event_handler.db_event_log_seq'::regclass) AS nextval,
            'MOTHERHOOD.MH_PREGNANT_MAP|UPDATE',
            now() AS now,
            row_to_json(new.*) AS row_to_json
          WHERE (current_setting('app.source'::text) <> 'DB'::text);
 SELECT pg_notify('db_event'::text, ('MOTHERHOOD.MH_PREGNANT_MAP|UPDATE^'::text || currval('event_handler.db_event_log_seq'::regclass))) AS pg_notify
  WHERE (current_setting('app.source'::text) <> 'DB'::text);
);

