CREATE FUNCTION add_team_job_status_hist(xtjid integer, xdt timestamp without time zone, xstatus integer, xreg integer, xnote character varying, xuser integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
begin
                insert into amb.sr_res_team_job_status_history (team_job_id,date_time,job_status_id,registrator_id,note,user_id)
                    VALUES(xtjid,xdt,xstatus,xreg,xnote,xuser);
                if xstatus = 7
                    then update amb.sr_res_team_job set edate = xdt where id = xtjid;
                end if;
              end;
$$;

