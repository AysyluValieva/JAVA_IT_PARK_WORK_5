CREATE FUNCTION tf_update_hospital_booking_validate()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE
                    text_exc TEXT;
                    bed_name TEXT;
                    is_validate BOOLEAN;
                BEGIN
                    IF ((TG_OP = 'INSERT') and new.iscurrent)
                    THEN
                        select  FALSE, v.validate,
                            coalesce(('койку №' || nullif(regexp_replace(b.number, '\s+$', ''), '')),'койку без названия')
                            into is_validate, text_exc, bed_name
                        from md_bed b
                            join lateral (select * from md_bed_resource mdb where mdb.bed_id = b.id limit 1) mdb on true
                            join lateral (select * from hospital.func_validate_used_bed_trigger(mdb.id, -1::int, new.begin_dt, new.end_dt, null::int, new.id, new.status_id, new.step_id, new.reservation_id) limit 1) v(validate) on true
                        where mdb.bed_id = new.bed_id
                            and v.validate is not null
                        limit 1;
                        IF (NOT is_validate) THEN
                            text_exc = format ('сохранить бронь на %L нельзя: %L', bed_name, text_exc);
                            RAISE EXCEPTION '%', text_exc;
                        END IF;
                    END IF;
                    RETURN NEW;
                END;
$$;

