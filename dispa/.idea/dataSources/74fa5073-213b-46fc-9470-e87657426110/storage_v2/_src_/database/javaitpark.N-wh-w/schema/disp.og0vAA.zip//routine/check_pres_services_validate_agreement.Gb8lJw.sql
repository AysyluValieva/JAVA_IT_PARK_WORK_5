CREATE FUNCTION check_pres_services_validate_agreement(xepid integer, xeventage character varying, xeventcode character varying)
  RETURNS character varying
LANGUAGE plpgsql
AS $$
dECLARE
        num character varying;
        model_age text [] ;
        actual_patient boolean;
        modelages text;
        ageyearmounth text;
        ageyear text;

    BEGIN

        actual_patient:=false;
        model_age=(select array_agg(mmpb.age::text)
                  from disp.md_event_service mes
                left join disp.md_event_service_model mesm on mesm.event_service_id=mes.id
                left join disp.md_model_patient mmp on mmp.id=mesm.model_id
                inner join disp.md_model_patient_base mmpb on  mmpb.model_id=mmp.id
                left join pim_individual i on i.id= (select indiv_id from disp.md_event_patient where id=xepid)
                where mes.event_id=(select event_id from disp.md_event_patient where id=xepid) and mmp.base is true and mmpb.gender_id=i.gender_id);

        ageyearmounth=xeventage;
        ageyear=LEFT(xeventage , Position ('.' in xeventage)-1);

        if model_age is not null then
            foreach  modelages  in array model_age
                Loop
                    if actual_patient then exit; else
                    FOREACH num IN ARRAY regexp_split_to_array(replace(modelages,' ','')  , ',')
                        LOOP
                        if actual_patient then exit; else
                        if(num like '%.%') then
                            if(num=ageyearmounth) then
                               actual_patient:=true;
                               exit;
                             end if;
                        else
                             if(num=ageyear) then
                               actual_patient:=true;
                               exit;
                             end if;
                        end if;
                        end if;
                        END LOOP;
                     end if;
                END LOOP;
        end if;
        if (actual_patient) then return '!'  ; else return ageyearmounth; end if;
        EXCEPTION WHEN others THEN
	return ageyearmounth;

END;
$$;

