CREATE FUNCTION fin_fill_pivot_steps_table(p1_bill_id integer)
  RETURNS void
STRICT
LANGUAGE plpgsql
AS $$
DECLARE
    _code_snils_ind_id INTEGER;
BEGIN
    /*
        current version date 2014-12-23
    */
    IF EXISTS (SELECT 1 FROM fin_bill_steps WHERE bill_id = p1_bill_id) THEN DELETE FROM fin_bill_steps WHERE bill_id = p1_bill_id; END IF;
    
    _code_snils_ind_id := (SELECT id FROM pim_code_type WHERE code = 'SNILS');
    
    INSERT INTO fin_bill_steps
    (
        srv_rendered_id, srv_rendered_bdate, srv_rendered_edate, srv_rendered_quantity, srv_rendered_comment, srv_diagnosis_code, tooth_number, 
        service_id, service_code, service_name, srv_prototype_id, srv_prototype_code,
        case_id, step_id, patient_id, id_pac, res_group_id, step_admission_date, step_outcome_date, step_profile_code, step_main_diagnosis_id, vmp_type_code, vmp_method_code,
        bill_id, spec_item_id, tariff, tariff_code, quantity, cul, price, price_pos_id, price_pos_code, price_pos_name, n_zap
    )
        SELECT
            f.id AS srv_rendered_id,
            f.bdate AS srv_rendered_bdate,
            f.edate AS srv_rendered_edate,
            f.rdd_quantity,
            f.comment AS srv_rendered_comment,
            d.code AS srv_diagnosis_code,
            f.tooth_number,
            f.service_id,
            f.service_code,
            f.service_name,
            p.id AS srv_prototype_id,
            coalesce (trim (p.code), '') AS srv_prototype_code,
            f.case_id,
            f.step_id,
            f.patient_id,
            f.id_pac,
            f.res_group_id,
            t.admission_date AS step_admission_date,
            t.outcome_date AS step_outcome_date,
            coalesce (trim (r.code), '') AS step_profile_code,
            t.main_diagnosis_id AS step_main_diagnosis_id,
            coalesce (trim (v.code), '') AS vmp_type_code,
            coalesce (trim (w.code), '') AS vmp_method_code,
            f.bill_id,
            f.fin_bill_spec_item_id AS spec_item_id,
            f.tariff,
            f.tariff_code,
            f.quantity,
            f.srv_cul AS cul,
            f.price,
            f.price_pos_arr[1] AS price_pos_id,
            f.price_position_code AS price_pos_code,
            f.price_position_name AS price_pos_name,
            f.n_zap
        FROM 
            fin_bill_generate          AS f
            JOIN sr_service            AS s ON s.id = f.service_id
            LEFT JOIN sr_srv_prototype AS p ON p.id = s.prototype_id
            LEFT JOIN mc_step          AS t ON t.id = f.step_id 
            LEFT JOIN md_profile       AS r ON r.id = t.profile_id
            LEFT JOIN mc_vmp_type      AS v ON v.id = t.vmp_type_id
            LEFT JOIN mc_vmp_method    AS w ON w.id = t.vmp_method_id
            LEFT JOIN md_diagnosis     AS d ON d.id = f.rdd_diagnosis_id
        WHERE
            f.bill_id = p1_bill_id AND NOT f.is_sifted
    ;
    WITH diags AS 
    (
        SELECT 
            f.bill_id, 
            f.srv_rendered_id, 
            coalesce (trim (md.code), '') AS m_diag_code, 
            array_agg (DISTINCT coalesce (trim (od.code), '')) AS o_diag_arr
        FROM
            fin_bill_steps         AS f
            LEFT JOIN mc_diagnosis AS m  ON m.id = f.step_main_diagnosis_id AND coalesce (m.is_main, FALSE)
            LEFT JOIN md_diagnosis AS md ON md.id = m.diagnos_id
            LEFT JOIN mc_diagnosis AS o  ON o.step_id = f.step_id AND NOT coalesce (o.is_main, FALSE)
            LEFT JOIN md_diagnosis AS od ON od.id = o.diagnos_id
        WHERE
            f.bill_id = p1_bill_id
        GROUP BY 1, 2, 3
    )
    UPDATE fin_bill_steps AS f
    SET 
        step_diagnosis_main = d.m_diag_code, step_diagnosis_other = array_to_string (d.o_diag_arr, ';')
    FROM
        diags AS d
    WHERE
        f.bill_id = d.bill_id AND f.srv_rendered_id = d.srv_rendered_id
    ;
    WITH doctors AS 
    (
        SELECT
            f.bill_id,
            f.srv_rendered_id,
            coalesce (p.employee_id::TEXT, '') AS doctor_code,
            coalesce (nullif (trim (p.code), ''), trim (e.number), '') AS doctor_code_regional,
            ARRAY [coalesce (trim (s.code), ''), coalesce (trim (s.e_code), '')] AS speciality_code_arr,
            coalesce (trim (r.code), '') AS pos_role_code,
            p.position_id,
            coalesce (trim (d.code), '') AS department_code,
            coalesce (trim (d.name), '') AS department_name,
            regexp_replace 
            (
                replace (replace ((array_agg (coalesce (trim (i.code), '') ORDER BY i.issue_dt DESC NULLS LAST))[1], '-', ''), ' ', ''), 
                '(...)(...)(...)(..)', 
                '\1-\2-\3 \4'
            ) AS snils
        FROM
            fin_bill_steps                  AS f
            JOIN sr_res_group               AS g ON g.id = f.res_group_id
            LEFT JOIN pim_employee_position AS p ON p.id = g.responsible_id
            LEFT JOIN pim_employee          AS e ON e.id = p.employee_id
            LEFT JOIN pim_position          AS t ON t.id = p.position_id
            LEFT JOIN pim_department        AS d ON d.id = t.department_id
            LEFT JOIN pim_position_role     AS r ON r.id = t.role_id
            LEFT JOIN pim_speciality        AS s ON s.id = t.speciality_id
            LEFT JOIN pim_indiv_code        AS i ON i.indiv_id = e.individual_id AND i.type_id = _code_snils_ind_id
        WHERE
            f.bill_id = p1_bill_id
        GROUP BY 1, 2, 3, 4, 5, 6, 7, 8, 9
    )
    UPDATE fin_bill_steps AS f
    SET 
        doctor_code          = d.doctor_code         ,
        doctor_code_regional = d.doctor_code_regional,
        speciality_code_arr  = d.speciality_code_arr ,
        pos_role_code        = d.pos_role_code       ,
        position_id          = d.position_id         ,
        department_code      = d.department_code     ,
        department_name      = d.department_name     ,
        doctor_snils         = d.snils                
    FROM
        doctors AS d
    WHERE
        f.bill_id = d.bill_id AND f.srv_rendered_id = d.srv_rendered_id
    ;
    WITH steps AS
    (
        SELECT DISTINCT
            f.bill_id,
            f.step_id,
            coalesce (trim (d.code), '') AS hsp_department_code,
            coalesce (trim (d.name), '') AS hsp_department_name,
            coalesce (trim (t.code), '') AS visit_type_code,
            coalesce (trim (p.code), '') AS visit_place_code,
            coalesce (trim (i.code), '') AS visit_inc_code,
            ARRAY [coalesce (trim (g.code), ''), coalesce (trim (g.e_code), '')] AS visit_goal_code_arr,
            coalesce (trim (g.name), '') AS visit_goal_name,
            h.bed_days_amount
        FROM
            fin_bill_steps              AS f
            LEFT JOIN plc_visit         AS v ON v.id = f.step_id
            LEFT JOIN plc_visit_type    AS t ON t.id = v.type_id
            LEFT JOIN plc_visit_place   AS p ON p.id = v.place_id
            LEFT JOIN plc_initiator     AS i ON i.id = v.initiator_id
            LEFT JOIN mc_case_init_goal AS g ON g.id = v.goal_id
            LEFT JOIN hsp_record        AS h ON h.id = f.step_id
            LEFT JOIN pim_department    AS d ON d.id = h.department_id
        WHERE
            f.bill_id = p1_bill_id
    )
    UPDATE fin_bill_steps AS f
    SET 
        visit_type_code      = s.visit_type_code    ,
        visit_place_code     = s.visit_place_code   ,
        visit_inc_code       = s.visit_inc_code     ,
        visit_goal_code_arr  = s.visit_goal_code_arr,
        visit_goal_name      = s.visit_goal_name    ,
        hsp_department_code  = s.hsp_department_code,
        hsp_department_name  = s.hsp_department_name,
        bed_days_amount      = s.bed_days_amount
    FROM
        steps AS s
    WHERE
        f.bill_id = s.bill_id AND f.step_id = s.step_id
    ;
END;
$$;

