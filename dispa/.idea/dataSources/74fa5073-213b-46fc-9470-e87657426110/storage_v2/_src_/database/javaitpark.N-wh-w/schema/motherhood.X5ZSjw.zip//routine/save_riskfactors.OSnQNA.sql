CREATE FUNCTION save_riskfactors(xid integer, xname text, b_dt date, e_dt date, xdepens_id integer, is_only_one_opt boolean, from_low integer, to_low integer, from_medium integer, to_medium integer, from_high integer, to_high integer, point integer, risk_factors text, type_rf text)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
  rid integer;
  risk_factor json;
begin

  if (xid is null)

  then
    if type_rf = 'group'
    then
      insert into motherhood.risk_factory_group( name, begin_dt, end_dt, from_low_risk,
            to_low_risk, from_medium_risk, to_medium_risk, from_high_risk,
            to_high_risk) values ( xname, b_dt, e_dt, from_low,
            to_low, from_medium, to_medium, from_high, to_high);
      select currval('motherhood.risk_factory_group_id_seq') into rid;
    END IF;
    if type_rf = 'values'
    then
      insert into motherhood.risk_factory_value(name, group_id, is_only_one_option) values ( xname, xdepens_id, is_only_one_opt);
      select currval('motherhood.risk_factory_value_id_seq') into rid;
    END IF;
    if type_rf = 'options'
    then
      insert into motherhood.risk_factory_options(name, value_id, points) values ( xname, xdepens_id, point);
      select currval('motherhood.risk_factory_options_id_seq') into rid;
    END IF;
    if type_rf = 'setting'
    then
      insert into motherhood.risk_factory_group_setting( name, begin_dt, end_dt, from_low_risk,
            to_low_risk, from_medium_risk, to_medium_risk, from_high_risk,
            to_high_risk, is_active) values ( xname, b_dt, e_dt, from_low,
            to_low, from_medium, to_medium, from_high, to_high, 'false');

      select currval('motherhood.risk_factory_group_setting_id_seq') into rid;

      FOR risk_factor IN SELECT * FROM json_array_elements(risk_factors::json)
      LOOP
	INSERT INTO motherhood.risk_factory_group_to_setting(group_id, setting_id) VALUES (cast(risk_factor->>'id' as int), rid);
      END LOOP;
    END IF;
  ELSE
    rid = xid;
    if type_rf = 'group'
    then
      update motherhood.risk_factory_group set  name = xname, begin_dt = b_dt, end_dt = e_dt, from_low_risk = from_low,
            to_low_risk = to_low, from_medium_risk = from_medium, to_medium_risk = to_medium,
            from_high_risk = from_high, to_high_risk = to_high where id = xid;
    END IF;
    if type_rf = 'values'
    then
      update motherhood.risk_factory_value  set name = xname, is_only_one_option = is_only_one_opt where id = xid;
    END IF;
    if type_rf = 'options'
    then
      update motherhood.risk_factory_options set name = xname, points = point where id = xid;
    END IF;
    if type_rf = 'setting'
     then
      -- обновления полей настройки
      update motherhood.risk_factory_group_setting set  name = xname, begin_dt = b_dt, end_dt = e_dt, from_low_risk = from_low,
            to_low_risk = to_low, from_medium_risk = from_medium, to_medium_risk = to_medium,
            from_high_risk = from_high, to_high_risk = to_high where id = xid;

      -- удаление факторов риска
      delete from motherhood.risk_factory_group_to_setting g_to_s where g_to_s.setting_id = rid and
      g_to_s.group_id not in (select cast(value->>'id' as int) from json_array_elements(risk_factors::json));

      -- добавление факторов риска
      FOR risk_factor IN SELECT * FROM json_array_elements(risk_factors::json)
      LOOP
	IF cast(risk_factor->>'id' as int) not in (select g_to_s.group_id from motherhood.risk_factory_group_to_setting g_to_s
		     where g_to_s.setting_id = rid)
		THEN INSERT INTO motherhood.risk_factory_group_to_setting(group_id, setting_id) VALUES (cast(risk_factor->>'id' as int), rid);
	END IF;
      END LOOP;
    END IF;

  END IF;
  return rid;
end;
$$;

