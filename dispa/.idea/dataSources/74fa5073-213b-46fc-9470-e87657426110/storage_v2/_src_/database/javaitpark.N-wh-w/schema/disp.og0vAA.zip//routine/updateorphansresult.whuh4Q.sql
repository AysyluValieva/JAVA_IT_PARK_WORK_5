CREATE FUNCTION updateorphansresult(xepid integer, xhg integer, xrec character varying, xav boolean, xvm integer, xvmv integer, xbefore boolean, xrid integer, xcdate character varying, xghpe integer, xodate character varying, xvaclist character varying)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
    i integer;
    vacid integer;
    vacListid json;
    stepid integer;
    admissiondate date;
  begin
    IF (select count(id) from disp.md_disp_orphans_result where id = xrid and is_before = xbefore) = 0 THEN
      i = nextval('disp.md_disp_orphans_result_id_seq');
      IF xbefore = FALSE THEN
        vacid = nextval('disp.md_disp_orphans_vac_patient_id_seq');
      ELSE
        vacid = NULL;
      END IF;
      IF xbefore = FALSE THEN
        insert into disp.md_disp_orphans_vac_patient (id, already_vac, vac_mode_id, vac_mode_value_id)
          values (vacid, xav, xvm, CASE WHEN xvm=1 THEN NULL ELSE xvmv END);
        foreach vacListid in array array(select value from json_array_elements(cast(xvacList as json)))
        LOOP
          insert into disp.md_disp_orphans_vac_patient_set(id, vac_id, vac_type_id) values (nextval('disp.md_disp_orphans_vac_patient_id_seq'), vacid, vacListid::text::int);
        END LOOP;
      END IF;
      insert into disp.md_disp_orphans_result (id, health_group_id, vac_id, recommendation, is_before, event_patient_id, close_date, health_group_physical_education_id)
        values (i, xhg, vacid, xrec, xbefore, xepid, to_date(xcdate, 'DD.MM.YYYY'), xghpe);
    ELSE
      update disp.md_disp_orphans_result set health_group_id = xhg, recommendation = xrec, is_before = xbefore, close_date = to_date(xcdate, 'DD.MM.YYYY'), health_group_physical_education_id = xghpe
        where id = xrid;
      IF xbefore = FALSE THEN
        vacid = (select vac_id from disp.md_disp_orphans_result where id = xrid);
        if (vacid is null) then
          vacid = nextval('disp.md_disp_orphans_vac_patient_id_seq');
          insert into disp.md_disp_orphans_vac_patient (id, already_vac, vac_mode_id, vac_mode_value_id)
            values (vacid, xav, xvm, CASE WHEN xvm=1 THEN NULL ELSE xvmv END);
          update disp.md_disp_orphans_result set vac_id = vacid where id = xrid;
        else
          update disp.md_disp_orphans_vac_patient set already_vac = xav, vac_mode_id = xvm, vac_mode_value_id = CASE WHEN xvm=1 THEN NULL ELSE xvmv END
            where id = (select vac_id from disp.md_disp_orphans_result where id = xrid);
        end if;
        delete from disp.md_disp_orphans_vac_patient_set where vac_id = (select vac_id from disp.md_disp_orphans_result where id = xrid);
        foreach vacListid in array array(select value from json_array_elements(cast(xvacList as json)))
        LOOP
          insert into disp.md_disp_orphans_vac_patient_set(id, vac_id, vac_type_id) values (nextval('disp.md_disp_orphans_vac_patient_id_seq'), (select vac_id from disp.md_disp_orphans_result where id = xrid), vacListid::text::int);
        END LOOP;
      END IF;
    END IF;

    update mc_case set open_date = to_date(xodate, 'DD.MM.YYYY') where id = (select  case_id from disp.md_event_patient where id = xepid);

    update MC_MED_CASE_RESULT set health_group_id = xhg
        where id = (select mc.result_id from disp.md_event_patient mep
                    left join MC_CASE mc on mc.id = mep.case_id
                    where mep.id = xepid);
    stepid = (select step_id from disp.md_disp_orphans_inspec where event_patient_id = xepid and is_closing = TRUE);
    admissiondate = (select admission_date from mc_step where id = stepid);
    update mc_step set result_id = (select result_id from disp.md_result_health_group mrhg
                                    where event_type_id = (select me.event_type from disp.md_event_patient mep
                                                           left join disp.md_event me on me.id = mep.event_id
                                                           where mep.id = xepid) and health_group_id = xhg and (is_2_stage = FALSE or is_2_stage is null) and mrhg.stage = 1
                                    and ((mrhg.begin_date is null or COALESCE(admissiondate, current_date) >= mrhg.begin_date) and (mrhg.end_date is null or COALESCE(admissiondate, current_date) <= mrhg.end_date)))
    where id = stepid;

    return 1;
    end;
$$;

