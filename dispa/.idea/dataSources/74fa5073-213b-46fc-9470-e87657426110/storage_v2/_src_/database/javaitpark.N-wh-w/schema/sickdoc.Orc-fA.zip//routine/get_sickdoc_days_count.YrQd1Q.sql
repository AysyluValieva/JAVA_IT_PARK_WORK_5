CREATE FUNCTION get_sickdoc_days_count(xid integer)
  RETURNS integer
LANGUAGE SQL
AS $$
WITH RECURSIVE sd AS (
        SELECT id, parent_id, days, type_id, workplace_type_id
            FROM  sickdoc.sickdoc ls  WHERE id = $1
        UNION
          SELECT ps.id, ps.parent_id,
            CASE WHEN sd.workplace_type_id = 2 then 0 else
                (CASE WHEN sd.type_id = 3 THEN 0 ELSE ps.days END) END AS days,
            ps.type_id, CASE 2 WHEN sd.workplace_type_id THEN 2 WHEN ps.workplace_type_id THEN 2 ELSE 0 END as workplace_type_id
            FROM sickdoc.sickdoc ps
            JOIN sd ON sd.parent_id = ps.id
    )
  SELECT sum(days)::integer AS total_days FROM sd
$$;

