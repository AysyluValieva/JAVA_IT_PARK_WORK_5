CREATE FUNCTION get_first_patient_reg(individual_id integer)
  RETURNS text
LANGUAGE plpgsql
AS $$
declare
            begin
            return (select coalesce(rs.name,' ') || ',' || coalesce(pr.reg_dt || '',' ') from md_reg_state rs
            join pci_patient_reg pr on (pr.state_id = rs.id and pr.patient_id = individual_id) limit 1);
            end;
$$;

