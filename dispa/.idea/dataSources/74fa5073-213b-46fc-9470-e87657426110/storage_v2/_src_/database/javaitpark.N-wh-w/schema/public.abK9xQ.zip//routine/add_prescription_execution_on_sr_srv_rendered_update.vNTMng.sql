CREATE FUNCTION add_prescription_execution_on_sr_srv_rendered_update()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE
    percent_execution_var integer;
    patient_prescription_id_var integer;
BEGIN
	select patient_prescription_id from md_srv_rendered into patient_prescription_id_var where id = NEW.id;
	IF (patient_prescription_id_var is not null) THEN
	    percent_execution_var := prescribed_services_execution(patient_prescription_id_var);
	    IF(percent_execution_var is null) THEN
	       percent_execution_var := 0;
	    END IF;
	    UPDATE md_patient_prescription SET percent_execution = percent_execution_var WHERE id = patient_prescription_id_var;
	END IF;
	RETURN NEW;
END;
$$;

