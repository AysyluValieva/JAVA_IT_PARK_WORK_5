CREATE FUNCTION add_patient_main_data(xpatient integer, xmaritalstatus integer, xbloodgroup integer, xjob integer, xprofessionworking integer, xmaindata integer, xpregnantmap integer, xhusbandsurname text, xhusbandage integer, xhusbandbloodgroup integer, xhusbandjob integer, xhusbandphone text)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
                    maritalStatusOld integer;
                    maritalStatusDateOld date;
                    jobOld integer;
                    jobDateOld date;
                    professionWorkingOld integer;
                begin
            select ims.id, ims.from_dt into maritalStatusOld, maritalStatusDateOld from pim_indiv_marital_status ims
                    where ims.individual_id = xpatient and
                    current_date between coalesce(ims.from_dt, '-infinity') and coalesce(ims.to_dt, 'infinity') limit 1;

                    if (coalesce(xmaritalStatus, 0) <> coalesce(maritalStatusOld, 0))
                    then
                if (maritalStatusDateOld is null or maritalStatusDateOld <> current_date) then
                    update pim_indiv_marital_status
                    set to_dt = cast(current_date - cast('1 day' as interval) as date)
                    WHERE id in
                        (select pims.id
                        from pim_indiv_marital_status pims
                        WHERE pims.individual_id = xpatient
                        and pims.from_dt < current_date
                        and pims.to_dt is null);

                    if (xmaritalStatus is not null) then
                        insert into public.pim_indiv_marital_status (id, individual_id, status_id, from_dt)
                        values (nextval('public.pim_indiv_marital_status_seq'), xpatient, xmaritalStatus, current_date);
                    end if;
                            else
                    if (xmaritalStatus is not null) then
                        update pim_indiv_marital_status
                        set status_id = xmaritalStatus
                        WHERE individual_id = xpatient
                            and from_dt = current_date
                            and to_dt is null;
                    else
                        delete from pim_indiv_marital_status WHERE individual_id = xpatient and from_dt = current_date and to_dt is null;
                    end if;
                            end if;

                    end if;

                    update pci_patient set rh_blood_group_id = xbloodGroup where id = xpatient;

            select pj.organization_id, pj.from_dt, pj.profession_working_id into jobOld, jobDateOld, professionWorkingOld from pci_patient_job pj
                where pj.patient_id = xpatient and current_date between coalesce(pj.from_dt, '-infinity') and coalesce(pj.to_dt, 'infinity')
                order by coalesce(pj.is_main_job, false) desc limit 1;

            if (coalesce(xjob, 0) <> coalesce(jobOld, 0))
                    then
                if (jobDateOld is null or jobDateOld <> current_date) then
                    update pci_patient_job
                    set to_dt = cast(current_date - cast('1 day' as interval) as date)
                    WHERE id in
                        (select pj.id
                        from pci_patient_job pj
                        WHERE pj.patient_id = xpatient
                        and pj.from_dt < current_date
                        and pj.to_dt is null);

                    if (xjob is not null) then
                        insert into public.pci_patient_job (id, patient_id, is_main_job, organization_id, organization_type_id, profession_working_id, from_dt)
                        values (nextval('public.pci_patient_job_id_seq'), xpatient, true, xjob, 1, xprofessionWorking, current_date);
                    end if;
                            else
                    if (xjob is not null) then
                        update pci_patient_job
                        set organization_id = xjob, profession_working_id = xprofessionWorking
                        WHERE patient_id = xpatient
                            and from_dt = current_date
                            and to_dt is null;
                    else
                        delete from pci_patient_job WHERE patient_id = xpatient and from_dt = current_date and to_dt is null;
                    end if;
                            end if;
            else
                if (coalesce(xprofessionWorking, 0) <> coalesce(professionWorkingOld, 0)) then
                    update pci_patient_job set profession_working_id = xprofessionWorking where patient_id = xpatient and organization_id = xjob;
                end if;
                    end if;

				if (xmainData is null) then
					insert into motherhood.mh_pregnant_main_data (id, pregnant_map_id, husband_surname, husband_phone, husband_age, husband_blood_group_id, husband_job_id)
					values (nextval('motherhood.mh_pregnant_main_data_seq'), xpregnantMap, xhusbandSurname, xhusbandPhone, xhusbandAge, xhusbandBloodGroup, xhusbandJob);
				else
					update motherhood.mh_pregnant_main_data
					set husband_surname = xhusbandSurname, husband_phone = xhusbandPhone, husband_age = xhusbandAge, husband_blood_group_id = xhusbandBloodGroup, husband_job_id = xhusbandJob
					where id = xmainData;
				end if;

                return xpatient;
            end;
$$;

