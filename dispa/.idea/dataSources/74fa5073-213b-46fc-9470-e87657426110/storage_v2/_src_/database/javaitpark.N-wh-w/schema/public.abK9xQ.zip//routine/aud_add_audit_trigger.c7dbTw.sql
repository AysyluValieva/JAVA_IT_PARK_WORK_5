CREATE FUNCTION aud_add_audit_trigger(table_name text)
  RETURNS void
LANGUAGE plpgsql
AS $$
BEGIN
        EXECUTE format('CREATE TRIGGER audit_trigger
			BEFORE INSERT OR UPDATE
			ON %s
			FOR EACH ROW
			EXECUTE PROCEDURE audit_trigger_fun();', $1);
    END;
$$;

