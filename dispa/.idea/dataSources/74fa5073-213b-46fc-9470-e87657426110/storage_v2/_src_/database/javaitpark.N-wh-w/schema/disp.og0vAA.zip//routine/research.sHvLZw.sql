CREATE FUNCTION research(xid integer, xcirculatory_system integer, xneoplasm integer, xhasstenocardia boolean, xhastuberculosis boolean, xhasnoninfectiousdisease boolean, xhasinfectiousdisease boolean, xhasonmk boolean, xhasgotoduplex boolean, xhasgotoeso boolean)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare

          count integer;

        begin
        count=(select count(id) from disp.md_dispr_research where id =xid);
        if (count>0) then
            update disp.md_dispr_research set
                        circulatory_system = xcirculatory_system,
                        neoplasm = xneoplasm,
                        has_stenocardia = xhasStenocardia,
                        has_tuberculosis = xhasTuberculosis,
                        has_non_infectious_disease = xhasNonInfectiousDisease,
                        has_infectious_disease = xhasInfectiousDisease,
                        has_onmk = xhasOnmk,
                        has_go_to_duplex = xhasGoToDuplex,
                        has_go_to_eso = xhasGoToEso
                        where id=xid;
        else
            insert into disp.md_dispr_research (id,indiv_id, event_id,circulatory_system,neoplasm,has_stenocardia,has_tuberculosis,has_non_infectious_disease,has_infectious_disease,has_onmk,
                    has_go_to_duplex,has_go_to_eso) values(xid,(select indiv_id from disp.md_event_patient where id=xid),(select event_id from disp.md_event_patient where id=xid),xcirculatory_system,xneoplasm,xhasStenocardia,xhasTuberculosis,xhasNonInfectiousDisease,xhasInfectiousDisease,xhasOnmk,
                    xhasGoToDuplex,xhasGoToEso);
        end if;

          return 1;
        end;
$$;

