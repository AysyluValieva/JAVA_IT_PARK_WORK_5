CREATE FUNCTION calc_main_contacts()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
declare
            xdata varchar[] := array[]::varchar[];
            rec record;
            xret record;
            begin
            if (TG_OP = 'DELETE')
            then
            xdata := xdata || 'OLD'::varchar;
            xret := OLD;
            else
            xdata := xdata || 'NEW'::varchar;
            if (TG_OP = 'UPDATE' AND NEW.indiv_id <> OLD.indiv_id) then
            xdata := xdata || 'OLD'::varchar;
            end if;
            xret := NEW;
            end if;
            FOR i IN array_lower(xdata, 1) .. array_upper(xdata, 1)
            LOOP
            if (xdata[i] = 'NEW') then rec := NEW; else rec := OLD; end if;
            update pim_individual set list_main_contact = (
            select coalesce(ppcc.short_name,' ') || ' : ' || coalesce(pic.value,' ')
            from pim_indiv_contact pic
            join pim_party_contact_type ppct on pic.type_id = ppct.id
            join pim_party_contact_category ppcc on ppct.category_id = ppcc.id
            where pic.indiv_id = rec.indiv_id and pic.is_main = true
            limit 1)
            where id = rec.indiv_id;
            END LOOP;
            return xret;
            end;
$$;

