CREATE MATERIALIZED VIEW tttt AS SELECT mc_case.id
   FROM mc_case
 LIMIT 100;

CREATE INDEX tttt_idx
  ON tttt (id);

