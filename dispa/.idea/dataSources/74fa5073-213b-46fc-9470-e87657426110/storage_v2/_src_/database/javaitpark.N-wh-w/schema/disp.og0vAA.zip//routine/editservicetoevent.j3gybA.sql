CREATE FUNCTION editservicetoevent(xid integer, xorgid integer, xserviceid integer, xresourceid integer, xeventid integer, xpriorityid integer, xdistrict boolean, xignore boolean, xis_mobile_medical_teams boolean)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
          i integer;
        begin
          i = xid;
          IF xpriorityId = 1 THEN
            update disp.md_event_service set first = FALSE where event_id=xeventId;
          ELSIF xpriorityId = 2 THEN
            update disp.md_event_service set last = FALSE where event_id=xeventId;
          END IF;
          update disp.md_event_service set org_id=xorgId, resource_id=xresourceId, service_id=xserviceId, district_check=xdistrict, ignore_service=xignore,
            first = CASE xpriorityId WHEN 1 THEN TRUE ELSE FALSE END,
            last = CASE xpriorityId WHEN 2 THEN TRUE ELSE FALSE END,
            is_mobile_medical_teams = xis_mobile_medical_teams
          where id=xid;
          return i;
        end;
$$;

