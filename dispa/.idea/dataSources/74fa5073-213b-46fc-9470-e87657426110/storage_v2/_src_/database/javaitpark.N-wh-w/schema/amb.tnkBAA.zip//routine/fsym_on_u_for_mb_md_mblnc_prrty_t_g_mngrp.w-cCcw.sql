CREATE FUNCTION fsym_on_u_for_mb_md_mblnc_prrty_t_g_mngrp()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
declare var_row_data text; 
                                declare var_old_data text; 
                                begin
                                   
                                  if 1=1 and "public".sym_triggers_disabled() = 0 then                                                                                                 
                                    var_row_data := 
          case when new."id" is null then '' else '"' || cast(cast(new."id" as numeric) as varchar) || '"' end||','||
          case when new."priority_id" is null then '' else '"' || cast(cast(new."priority_id" as numeric) as varchar) || '"' end||','||
          case when new."from_age_day" is null then '' else '"' || cast(cast(new."from_age_day" as numeric) as varchar) || '"' end||','||
          case when new."from_age_month" is null then '' else '"' || cast(cast(new."from_age_month" as numeric) as varchar) || '"' end||','||
          case when new."from_age_year" is null then '' else '"' || cast(cast(new."from_age_year" as numeric) as varchar) || '"' end||','||
          case when new."to_age_day" is null then '' else '"' || cast(cast(new."to_age_day" as numeric) as varchar) || '"' end||','||
          case when new."to_age_month" is null then '' else '"' || cast(cast(new."to_age_month" as numeric) as varchar) || '"' end||','||
          case when new."to_age_year" is null then '' else '"' || cast(cast(new."to_age_year" as numeric) as varchar) || '"' end; 
                                    var_old_data := 
          case when old."id" is null then '' else '"' || cast(cast(old."id" as numeric) as varchar) || '"' end||','||
          case when old."priority_id" is null then '' else '"' || cast(cast(old."priority_id" as numeric) as varchar) || '"' end||','||
          case when old."from_age_day" is null then '' else '"' || cast(cast(old."from_age_day" as numeric) as varchar) || '"' end||','||
          case when old."from_age_month" is null then '' else '"' || cast(cast(old."from_age_month" as numeric) as varchar) || '"' end||','||
          case when old."from_age_year" is null then '' else '"' || cast(cast(old."from_age_year" as numeric) as varchar) || '"' end||','||
          case when old."to_age_day" is null then '' else '"' || cast(cast(old."to_age_day" as numeric) as varchar) || '"' end||','||
          case when old."to_age_month" is null then '' else '"' || cast(cast(old."to_age_month" as numeric) as varchar) || '"' end||','||
          case when old."to_age_year" is null then '' else '"' || cast(cast(old."to_age_year" as numeric) as varchar) || '"' end; 
                                    if 1=1 then 
                                    insert into "public".sym_data                                                                                                                     
                                    (table_name, event_type, trigger_hist_id, pk_data, row_data, old_data, channel_id, transaction_id, source_node_id, external_data, create_time)                     
                                    values(                                                                                                                                                            
                                      'md_ambulance_priority_to_age',                                                                                                                                            
                                      'U',                                                                                                                                                             
                                      19,                                                                                                                                             
                                      
          case when old."id" is null then '' else '"' || cast(cast(old."id" as numeric) as varchar) || '"' end,                                                                                                                                                      
                                      var_row_data,                                                                                                                                                      
                                      var_old_data,                                                                                                                                                   
                                      'amb_md_ambulance_priority_to_age_default',                                                                                                                                                
                                      txid_current(),                                                                                                                                               
                                      "public".sym_node_disabled(),                                                                                                                   
                                      null,                                                                                                                                               
                                      CURRENT_TIMESTAMP                                                                                                                
                                    );                                                                                                                                                                 
                                  end if;                                                                                                                                                              
                                  end if;                                                                                                                                                              
                                                                                                                                                                               
                                  return null;                                                                                                                                                         
                                end;
$$;

