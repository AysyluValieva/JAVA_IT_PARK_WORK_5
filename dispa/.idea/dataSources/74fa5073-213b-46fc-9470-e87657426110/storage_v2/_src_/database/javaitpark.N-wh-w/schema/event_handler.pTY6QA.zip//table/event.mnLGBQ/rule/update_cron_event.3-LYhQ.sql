CREATE RULE update_cron_event AS
    ON UPDATE TO event_handler.event
   WHERE ((COALESCE(new.period, 'empty'::character varying))::text <> (COALESCE(old.period, 'empty'::character varying))::text) DO ( SELECT pg_notify('cron_event'::text, format('{"action":"ADD", "event":{"cron":"%s", "event":"%s"}}'::text, new.period, new.id)) AS pg_notify
  WHERE (new.period IS NOT NULL);
 SELECT pg_notify('cron_event'::text, format('{"action":"REMOVE", "event":{"cron":"%s", "event":"%s"}}'::text, old.period, old.id)) AS pg_notify
  WHERE (old.period IS NOT NULL);
);

