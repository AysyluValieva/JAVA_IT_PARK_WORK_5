CREATE FUNCTION get_refbook_value(xtable_name character varying, xid integer, xname character varying, xoffset integer, xlimit integer, xorder character varying)
  RETURNS TABLE(id integer, name character varying)
LANGUAGE plpgsql
AS $$
DECLARE
    t BOOLEAN;
    q VARCHAR;
BEGIN

IF $1 ISNULL
    THEN RETURN;
END IF;

q = 'SELECT id, name FROM ' || $1 || ' WHERE ($1 ISNULL OR id = $1)';
IF $3 NOTNULL
	THEN
		q = q || ' AND UPPER(name) LIKE UPPER(''%' || $3 || '%'')';
END IF;

q = q || ' LIMIT $2 OFFSET $3';
RETURN QUERY EXECUTE q USING $2, $5, $4;

END;
$$;

