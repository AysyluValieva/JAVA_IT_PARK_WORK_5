CREATE FUNCTION get_individual_patr_name_for_case(case_id integer)
  RETURNS character varying
IMMUTABLE
STRICT
LANGUAGE SQL
AS $$
select patr_name from pim_individual where id = (select patient_id from mc_case where id = $1);
$$;

