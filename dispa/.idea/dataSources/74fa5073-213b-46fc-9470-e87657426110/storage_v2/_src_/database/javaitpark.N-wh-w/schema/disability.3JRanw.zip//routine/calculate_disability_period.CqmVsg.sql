CREATE FUNCTION calculate_disability_period()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE
    to_dt DATE;
    years INTEGER;
    age INTERVAL;
BEGIN
    to_dt := NEW.to_dt::date + interval '1' day;
    age := age(to_dt, NEW.from_dt);
    years := date_part('year', age);
    NEW.months := date_part('month', age) + 12 * years;
    NEW.days := date_part('day', age );
    RETURN NEW;
END;
$$;

