CREATE FUNCTION fin_services_generate_shell(p1_bill_id integer, p2_status text)
  RETURNS void
STRICT
LANGUAGE plpgsql
AS $$
DECLARE
    _main_bill_id INTEGER := public.fin_bill__get_main_bill (p1_bill_id);
    _price_type TEXT := billing.fin_get_price_type (p1_bill_id);
    _p RECORD;
    _step_id INTEGER;
    _srv_code TEXT;
BEGIN
    /*
        version: 2015-08-04
    */
    IF
        p2_status = 'GENERATE'
    THEN
    ------------------------------------------------------------------параметры----------------------------------------------------------------------
        SELECT 
            coalesce (a.from_date, m.from_date) AS from_dt, coalesce (a.to_date, m.to_date) AS to_dt, m.clinic_id, m.financing_type_id INTO _p
        FROM
            public.fin_bill_main AS m LEFT JOIN public.fin_bill_additional AS a ON m.id = a.base_id AND a.id = p1_bill_id
        WHERE
            m.id = _main_bill_id
        ;
    ------------------------------------------------------------------генерация----------------------------------------------------------------------
        IF
            _price_type = 'hospital'
        THEN
            _srv_code := 'KSKSG';
            FOR _step_id IN 
                EXECUTE concat
                (
                    'SELECT ', 
                        's.id ', 
                    'FROM ', 
                        'public.mc_case AS c ',
                        'JOIN public.mc_step AS t ON t.id = c.closing_step_id AND t.outcome_date BETWEEN ''', _p.from_dt, ''' AND ''', _p.to_dt, ''' ', 
                        'JOIN public.mc_step AS s ON s.case_id = c.id ', 
                    'WHERE ',
                        'c.clinic_id = ', _p.clinic_id, ' ', 
                        'AND c.funding_id = ', _p.financing_type_id, ' ',
                        billing.fin_get_bill_restrictions (p1_bill_id), 
                        'AND s.csg_id IS NOT NULL ', 
                        'AND NOT EXISTS ', 
                        '(', 
                            'SELECT 1 FROM public.md_srv_rendered AS m JOIN public.sr_srv_rendered AS r ON m.id = r.id JOIN public.sr_service AS e ON e.id = r.service_id ',
                            'WHERE m.case_id = c.id AND m.step_id = s.id AND e.code = ''', _srv_code, '''',
                        ') ',
                        'AND pg_try_advisory_xact_lock (s.tableoid::INTEGER, s.id)'
                )
            LOOP
                PERFORM billing.fin_services_generate (_step_id, _srv_code, FALSE);
            END LOOP;
        END IF;
    END IF;
END;
$$;

