CREATE FUNCTION add_arrival_to_call_state_hist(xcall integer, xdt timestamp without time zone, xtransmit integer, xreg integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
	i integer;
    xbrg integer;
  begin
  	if (select call_kind_id from amb.md_ambulance_call where id = xcall) =  5
    	then
        	-- окончании вызова бригаде, которая вызвала спц, когда отмечаем доезд бригаде спц
        	xbrg = (select parent.brg_id from amb.md_ambulance_call_on_base cob
                join amb.md_ambulance_call parent on parent.id = cob.call_on_base_id
                where cob.id = xcall);
            execute amb.close_brg_to_call (xbrg,xreg);
        else
        	/*добавление записи о состоянии в историю*/
			i = nextval('amb.md_ambcall_state_history_id_seq');
    		insert into amb.md_ambcall_state_history (id,call_id,date_time,state_id,transmit_id,registrator_id)
    			VALUES(i,xcall,xdt,7,xtransmit,xreg);
    end if;

    /*
    -- отметка об окончании вызова бригаде, которая вызвала спц, когда отмечаем доезд бригаде спц
    if exist(   select * from amb.md_ambulance_call_on_base cob
                join amb.md_ambulance_call child on child.id = cob.id
                where cob.call_on_base_id = brg_list.id and child.call_kind_id = 5    )
    	then
        	select amb.add_ambcall_state_hist ((select child.id from amb.md_ambulance_call_on_base cob
                join amb.md_ambulance_call child on child.id = cob.id
                where cob.call_on_base_id = brg_list.id and child.call_kind_id = 5),xtodate,7,2,:reg);
        end if;
    */
--    return i;
  end;
$$;

