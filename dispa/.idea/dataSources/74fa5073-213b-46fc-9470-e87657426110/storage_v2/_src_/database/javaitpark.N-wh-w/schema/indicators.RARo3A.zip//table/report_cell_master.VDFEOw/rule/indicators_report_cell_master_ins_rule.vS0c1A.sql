CREATE RULE indicators_report_cell_master_ins_rule AS
    ON INSERT TO indicators.report_cell_master DO INSTEAD NOTHING;

