CREATE FUNCTION save_referral(xid integer, xsr_srv_rendered_id integer, xreferraltype_id integer, xreferralnumber character varying, xreferraldate date, xreferralorganization_id integer, xexecutororganization_id integer, xreferraldepartment_id integer, xexecutordepartment_id integer, xreferralemployee_id integer, xexecutoremployee_id integer, xdiagnosis_id integer, xservice_id integer, xserviceprototype_id integer, xspeciality_id integer, xprofile_id integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
  result_id integer;
  i integer;
  srecord record;
begin
  select ssr.customer_id, msr.case_id, msr.step_id into srecord from sr_srv_rendered ssr join md_srv_rendered msr on ssr.id = msr.id and ssr.id = xsr_srv_rendered_id;
  if (xid is null) then
    i = nextval('md_referral_seq');
    INSERT INTO md_referral(id, order_number, referral_date, diagnosis_id, ref_doctor_id, ref_organization_id,
                            patient_id, recv_organization_id, referral_type_id, recv_doctor_id, department_id, step_id,
                            service_id, ref_department_id, status_id)
    VALUES (i, xreferralNumber, xreferralDate, xdiagnosis_id, xreferralEmployee_id, xreferralOrganization_id,
               srecord.customer_id, xexecutorOrganization_id, xreferralType_id, xexecutorEmployee_id, xexecutorDepartment_id, srecord.step_id,
            xsr_srv_rendered_id, xreferralDepartment_id, (select id from md_ref_document_status where code = '2'));

    INSERT INTO md_referral_service(id, referral_id, service_id, service_prototype_id)
    VALUES (nextval('md_referral_service_id_seq'), i, xservice_id, xservicePrototype_id);

    INSERT INTO disp.md_referral_extended(id, speciality_id, profile_id)
    VALUES (i, xspeciality_id, xprofile_id);
    result_id = i;
  else
    UPDATE md_referral set order_number = xreferralNumber, referral_date = xreferralDate, diagnosis_id = xdiagnosis_id,
      ref_doctor_id = xreferralEmployee_id, ref_organization_id = xreferralOrganization_id,
      patient_id = srecord.customer_id, recv_organization_id = xexecutorOrganization_id, referral_type_id = xreferralType_id, recv_doctor_id = xexecutorEmployee_id,
      department_id = xexecutorDepartment_id, step_id = srecord.step_id,
      service_id = xsr_srv_rendered_id, ref_department_id = xreferralDepartment_id
    where id = xid;

    UPDATE md_referral_service set service_id = xservice_id, service_prototype_id = xservicePrototype_id
    where referral_id = xid;

    UPDATE disp.md_referral_extended set speciality_id = xspeciality_id, profile_id = xprofile_id
    where id = xid;
    result_id = xid;
  end if;
  return result_id;
end;
$$;

