CREATE FUNCTION view_mapping_new(_id integer)
  RETURNS SETOF void
LANGUAGE plpgsql
AS $$
DECLARE
  _txt_table_name varchar;
  _r_internal record;
  _r_external record;
  _r_external2 record;
  _txt_query text;
  _txt_result_ext text;
  _txt_result_ext2 text;
BEGIN
--получить искомое название таблицы
  select mir.table_name into _txt_table_name 
                          from  mdm_refbook_mapping mrm
                           join  mdm_refbook_version mrv on mrv.id=mrm.target_refbook_id
                           join  mdm_refbook_column mrc on mrc.refbook_version_id=mrv.id
                           join mdm_internal_refbook mir on mir.identifier_column_id=mrc.id
                           where mrm.id=_id limit 1;
   RAise notice 'ТАБЛИЦА %;',                   
                     _txt_table_name;          
    --получить все значения внутренней таблицы                      
    for _r_internal in EXECUTE  'select * from '|| _txt_table_name --|| ' where NAME=''Врач-гастроэнтеролог'''
    loop       
          --перебрать значения внешнего справочника                
         for _r_external in ( select mrm.id, mir.table_name, mrm.name, mrc.name, mrc.code
                        ,mrcol_ext.name as "_name",mrc_ext.value,mrc_ext.record_id
                        ,mrm.target_refbook_id
                          from  mdm_refbook_mapping mrm
                           join  mdm_refbook_version mrv on mrv.id=mrm.target_refbook_id
                           join  mdm_refbook_column mrc on mrc.refbook_version_id=mrv.id
                           join mdm_internal_refbook mir on mir.identifier_column_id=mrc.id
                        join mdm_record mr_external on mr_external.refbook_version_id = mrm.source_refbook_id
                        join mdm_record_column mrc_ext on mrc_ext.record_id = mr_external.id
                        join mdm_refbook_column  mrcol_ext on mrcol_ext.id = mrc_ext.column_id
                           where  mrcol_ext.name = 'NAME'
                           and UPPER(mrc_ext.value) =UPPER(_r_internal.name)
                           and mrm.id=_id)
          loop
            --извлечь запрос, который полчит все значения с record_id,
            --где группируются все значения к конкретной записи во внутреннем справочнике
               for _r_external2 in (select mrm.id, mir.table_name, mrm.name, mrc.name, mrc.code
                        ,mrcol_ext.name as "_name",mrc_ext.value,mrc_ext.record_id
                        ,mrm.target_refbook_id, null::INTEGER as "__id", null::text as "__name", null::text as "__code"
                          from  mdm_refbook_mapping mrm
                           join  mdm_refbook_version mrv on mrv.id=mrm.target_refbook_id
                           join  mdm_refbook_column mrc on mrc.refbook_version_id=mrv.id
                           join mdm_internal_refbook mir on mir.identifier_column_id=mrc.id
                        join mdm_record mr_external on mr_external.refbook_version_id = mrm.source_refbook_id
                        join mdm_record_column mrc_ext on mrc_ext.record_id = mr_external.id
                        join mdm_refbook_column  mrcol_ext on mrcol_ext.id = mrc_ext.column_id
                           where
                           mir.table_name=_txt_table_name
                           and mrc_ext.record_id=_r_external.record_id )
               loop   
                
                    _txt_result_ext=CONCAT(_txt_result_ext,  _r_external2._name , '=' , _r_external2.value ,'; ');
               end loop;
                    
          end loop;
          RAise notice 'Внутренняя: id=%;  code=%; name=%;
                        Внешняя  %',                   
                      _r_internal.id ,  _r_internal.code , _r_internal.name,
                      _txt_result_ext;  
          _txt_result_ext=null;                      
   end loop;                       
END;
$$;

