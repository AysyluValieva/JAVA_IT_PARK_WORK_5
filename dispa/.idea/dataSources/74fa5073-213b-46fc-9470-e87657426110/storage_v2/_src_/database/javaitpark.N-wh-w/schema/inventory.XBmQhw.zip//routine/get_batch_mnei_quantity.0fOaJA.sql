CREATE FUNCTION get_batch_mnei_quantity(storesupid integer, mneiquantity numeric, expinvoicedate date)
  RETURNS numeric
LANGUAGE plpgsql
AS $$
DECLARE
 result  NUMERIC;
 income NUMERIC;
 outcome NUMERIC;
 amount record;

BEGIN
 result=0;

with journal as
     (select mnei_quantity,send_store_sup_id, rec_store_sup_id, opr_type_id
      from inventory.store_opr_jur jur
           inner JOIN inventory.store_opr opr ON jur.store_opr_id=opr.id
           inner  JOIN inventory.store_opr_type type_ ON type_.id=opr.opr_type_id
      where jur.date > expInvoiceDate::DATE and (send_store_sup_id = storeSupId or rec_store_sup_id = storeSupId))
      select
           (select sum(mnei_quantity) from journal WHERE opr_type_id=2) as outcome,
           (select sum(mnei_quantity) from journal WHERE opr_type_id=1) as income into amount;
outcome= amount.outcome;
income= amount.income;

if  outcome IS NULL THEN outcome=0; END if;
if  income IS NULL THEN income=0; END if;

result=mneiQuantity+outcome-income;
return trim(to_char(result, 'FM999999990.999999'), '.');
END;
$$;

