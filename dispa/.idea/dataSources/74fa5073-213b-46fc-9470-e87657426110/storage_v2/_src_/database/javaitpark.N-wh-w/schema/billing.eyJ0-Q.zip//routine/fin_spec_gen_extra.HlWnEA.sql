CREATE FUNCTION fin_spec_gen_extra(p1_bill_id integer)
  RETURNS void
STRICT
LANGUAGE plpgsql
AS $$
DECLARE 
   _clinic_id INTEGER;
   _sr_service_id INTEGER;
   _from_date DATE;
   _r RECORD;
   _bill_type text:=billing.kurgan_fin_get_type_bill(p1_bill_id);
   _init_goal_id_7 integer:=(SELECT id FROM mc_case_init_goal WHERE code='7');
   _price_list_vmp integer;
   _case_type_neotl INTEGER:=(SELECT id FROM mc_case_type WHERE code='3');
   _to_date DATE;
   _patient_age INTEGER;
   _is_log BOOLEAN:=TRUE;
   _service_id_TMC INTEGER;
BEGIN

 IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_spec_gen_extra. Начало'); END IF; 
 
 ---Отсеивание комплексных (если это формирование)
 --IF p2_status_text='GENERATE' THEN
 /*
    UPDATE billing.fin_bill_generate f 
    SET is_sifted = TRUE, sifting_cause = 'Комплексная услуга'
    FROM 
        (SELECT g.id
         FROM billing.fin_bill_generate g
         JOIN sr_service s ON s.id=g.service_id
         WHERE g.bill_id=p1_bill_id AND NOT g.is_sifted AND COALESCE(s.is_complex,FALSE)=TRUE
         ) b
    WHERE f.bill_id=p1_bill_id AND f.id=b.id;
*/	
 --END IF;
    UPDATE tmp_fin_bill_generate f 
       SET is_sifted = TRUE, sifting_cause = 'Комплексная услуга'
     WHERE 1 = 1 /*f.bill_id=p1_bill_id */
	   AND NOT f.is_sifted
           AND EXISTS (SELECT NULL 
		       FROM sr_service s 
			WHERE s.id=f.service_id 
			      AND s.is_complex=TRUE); --coalesce не нужен при поиске имеющегося значения
 
 PERFORM billing.fin_fill_pivot_service_jsonb_table (p1_bill_id);
 
 UPDATE tmp_fin_bill_generate f
	SET region_data=coalesce(region_data,hstore(''))||hstore('tarif','0')
 FROM billing.fin_bill_service_jsonb b
 WHERE 1=1
	--AND b.bill_id = p1_bill_id
	AND b.srv_rendered_id = f.id
	AND (b.region_data->'npl') IN ('1','2','3','4')
;
 
 SELECT m.clinic_id, m.from_date, m.to_date INTO _clinic_id, _from_date, _to_date FROM public.fin_bill_main m WHERE m.id = p1_bill_id;
 SELECT id INTO _service_id_TMC FROM sr_service WHERE org_id=_clinic_id AND code='A23.30.099.005';
 
 
 IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_spec_gen_extra. 1'); END IF;   
--устанавливаем поле anest_code
/*
WITH gra AS 
(
	SELECT
		g.bill_id,
    	g.id,
    	COALESCE(a.code,'') AS anest_code 
	FROM
		billing.fin_bill_generate g 
    	JOIN public.md_srv_rendered r ON g.id = r.id
    	JOIN public.mc_anesthesia_type a ON a.id = r.anesthesia_type_id
	WHERE
		g.bill_id = p1_bill_id    
)
UPDATE billing.fin_bill_generate g 
SET
	anest_code = gra.anest_code
FROM
	gra
WHERE
	g.bill_id = gra.bill_id AND g.id = gra.id
; 
*/
	UPDATE tmp_fin_bill_generate g 
	SET
		anest_code = (SELECT COALESCE(code,'') FROM public.mc_anesthesia_type WHERE id = r.anesthesia_type_id LIMIT 1) --LIMIT можно убрать, если там PK
	FROM public.md_srv_rendered r
	WHERE 1=1
		--AND g.bill_id = p1_bill_id
		AND g.id = r.id
	; 

--Для всех случаев, возвращенных МЭК проставляем дату тарифа

IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_spec_gen_extra. 2'); END IF; 
/*
 WITH sv AS
   (SELECT id, coalesce(region_data->'date_bill_mek',to_char(f.to_date- '1 MONTH'::interval,'dd.mm.yyyy')) as date_bill_mek
    FROM billing.fin_bill_generate f
    WHERE bill_id=p1_bill_id AND region_data->'pr_nov'='1'
    )
 UPDATE billing.fin_bill_generate f SET region_data=coalesce(region_data,hstore(''))||hstore('date_bill_mek',sv.date_bill_mek), 
                                        comment='МЭК. Перенесен из предыдущего отчета </br> '||coalesce(comment,'')
 FROM sv WHERE f.bill_id=p1_bill_id AND f.id=sv.id;  
 */
    UPDATE tmp_fin_bill_generate f 
       SET region_data=coalesce(region_data,hstore(''))
					||hstore('date_bill_mek', coalesce(region_data->'date_bill_mek',to_char(f.to_date- '1 MONTH'::interval,'dd.mm.yyyy'))), 
                                             comment='МЭК. Перенесен из предыдущего отчета </br> '||coalesce(comment,'')
     WHERE f.bill_id=p1_bill_id
           AND region_data->'pr_nov'='1';  

IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_spec_gen_extra. 3'); END IF;


--Проверяем на телемедицину
IF _bill_type='app' OR _bill_type = 'stac' THEN
    
    WITH T AS
      (SELECT tfbg.case_id, 
	      CASE WHEN 
			--сортируем по услуге: tmc вперед, null-ы в конец - FIRST_VALUE даст услугу tmc в начале при наличии - проверяем, что это она
			FIRST_VALUE(service_id) OVER (PARTITION BY case_id ORDER BY service_id = _service_id_TMC NULLS LAST) = _service_id_TMC
				THEN 1
	      ELSE 0 END is_tmc
         FROM tmp_fin_bill_generate AS tfbg
        WHERE NOT tfbg.is_sifted)       
    UPDATE tmp_fin_bill_generate AS f 
       SET region_data=coalesce(region_data, hstore(''))||hstore('is_tmc', t.is_tmc::text) 
      FROM t 
     WHERE f.case_id=t.case_id;   
      
END IF;

IF _bill_type='app' THEN 

      --Проверяем на телемедицину - вынесено выше в общий блок
 
--    WITH SV AS
--      (SELECT distinct case_id  FROM tmp_fin_bill_generate WHERE 1 =1 /*bill_id=p1_bill_id*/ AND not is_sifted),
--    T AS
--      (SELECT sv.case_id, EXISTS (SELECT 1 FROM  tmp_fin_bill_generate WHERE 1 = 1 /*bill_id=p1_bill_id*/ AND case_id=sv.case_id AND service_id=_service_id_TMC) is_tmc
--       FROM sv)       
--    UPDATE tmp_fin_bill_generate f SET region_data=coalesce(region_data,hstore(''))||hstore('is_tmc',CASE WHEN t.is_tmc=FALSE THEN '0' ELSE '1' END) FROM t WHERE 1 = 1 /*f.bill_id=p1_bill_id*/ AND f.case_id=t.case_id;
    
	 
  IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_spec_gen_extra. 4'); END IF; 
  --меняем дату открытия случая, если в случае есть услуги до первого посещения
/*  
   FOR _r IN 
               SELECT case_id, patient_id, min(bdate) as new_open_date
               FROM billing.fin_bill_generate 
               WHERE bill_id=p1_bill_id AND  not is_sifted AND case_open_date>bdate
               GROUP by 1,2
           
            LOOP
                IF _r.new_open_date is not null THEN
                    UPDATE mc_case SET open_date = _r.new_open_date WHERE id = _r.case_id;
                    _patient_age:= (SELECT date_part('year', age(_r.new_open_date, birth_dt)) FROM pim_individual 	WHERE id = _r.patient_id);
                    UPDATE billing.fin_bill_generate SET case_open_date = _r.new_open_date, patient_age = _patient_age WHERE bill_id = p1_bill_id AND case_id = _r.case_id AND NOT is_sifted;
                END IF;    
            END LOOP;  
*/
	WITH tt AS (SELECT tfbg.case_id, tfbg.patient_id, min(tfbg.bdate) as new_open_date
			FROM tmp_fin_bill_generate AS tfbg              
			WHERE  not is_sifted AND case_open_date > bdate
			GROUP BY 1, 2),
	upd_mc_case AS 
	   (UPDATE mc_case AS mc
		   SET open_date = tt.new_open_date --здесь null-даты быть не может, потому что первичный отбор по условию
		  FROM tt
		 WHERE id = tt.case_id
			AND (open_date IS NULL OR open_date <> tt.new_open_date)
		)
	-- update fin_bill_generate
	UPDATE tmp_fin_bill_generate AS tfbg
	   SET case_open_date = tt.new_open_date, 
		   patient_age = (SELECT date_part('year', age(tt.new_open_date, birth_dt)) AS patient_age FROM pim_individual WHERE id = tfbg.patient_id LIMIT 1)
	  FROM tt
	 WHERE tfbg.case_id = tt.case_id
	       AND NOT tfbg.is_sifted;
			 
   IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_spec_gen_extra. 5'); END IF;          
   --меняем дату закрытия случая, если в случае есть услуги после даты закрытия
   WITH SV as
      (
        SELECT case_id, max(bdate) as new_close_date
        FROM tmp_fin_bill_generate
        WHERE 1 = 1 /*bill_id=p1_bill_id*/ AND not is_sifted AND bdate>case_close_date AND bdate<=_to_date
        GROUP by 1
       )
    UPDATE tmp_fin_bill_generate f SET case_close_date=sv.new_close_date FROM sv WHERE 1 =1 /*f.bill_id=p1_bill_id*/ AND NOT f.is_sifted AND f.case_id=sv.case_id;       

  -- Проставляем step_id для всех услуг, которые вне шага
   IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_spec_gen_extra. 6'); END IF; 
    UPDATE tmp_fin_bill_generate SET step_id=closing_step_id WHERE 1 = 1 /*bill_id=p1_bill_id*/ AND NOT is_sifted AND step_id is NULL;
  
  --поликлиника
 /*
       IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_spec_gen_extra. 7'); END IF; 
        WITH T AS
           (
               SELECT id, billing.kurgan_fin_get_price_app(id, price_pos_arr[1], step_id, service_id, coalesce(rdd_quantity::integer,1), 
               patient_age, coalesce(to_date(region_data->'date_bill_mek','dd.mm.yyyy'),_to_date), init_goal_id,case_type_id) AS r
               FROM billing.fin_bill_generate 
               WHERE bill_id=p1_bill_id AND NOT is_sifted 
             )
        UPDATE billing.fin_bill_generate AS f     
        SET  tariff = (t.r).tariff,
             price  = (t.r).price,
             tariff_code   =(t.r).tariff_code,
             region_data=coalesce(region_data,hstore(''))||hstore('is_mrt',(t.r).is_mrt::text)
        FROM t
        WHERE f.id = t.id AND f.bill_id = p1_bill_id ;       
  */ 
ELSIF _bill_type='stac' THEN
   --стационар
   
     --Проверяем на телемедицину - вынесено выше в общий блок 

    --Стоимость услуг гемодиализа 17.20.2016
    IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_spec_gen_extra. 8'); END IF; 
	WITH t AS 
    	(
    	    SELECT id, billing.fin_get_tariff_from_pricelist  (id, price_pos_arr[1]) AS r
    	    FROM tmp_fin_bill_generate 
    	    WHERE bill_id = p1_bill_id AND NOT is_sifted AND tariff IS NULL AND NOT coalesce(region_data ? 'tarif',false)
    	)
    	UPDATE tmp_fin_bill_generate AS f
    	SET
    	    (tariff, tariff_code, price) = ((t.r).tariff, (t.r).code, (t.r).tariff*coalesce(nullif(rdd_quantity,0),1))
    	FROM t
    	WHERE
    	    t.id = f.id AND 1 = 1 /*f.bill_id = p1_bill_id*/ AND NOT f.is_sifted AND f.tariff IS NULL
            AND f.org_id IN (43,25)
    	    AND f.price_position_code IN ('A18.05.002.001','A18.05.002.003','A18.05.011','A18.05.011.001','A18.05.003','A18.05.004','A18.05.003.001','A18.05.003.002','A18.05.002.005','A18.05.011.002','A18.30.001','A18.30.001.001','A18.30.001.002','A18.30.001.003','A18.05.002','A18.05.002.002')
    	;
----------------------------------------

    IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_spec_gen_extra. 9'); END IF; 
   

    --получаем id фиктивной услуги
    SELECT s.id INTO _sr_service_id FROM billing.sr_fiction_service_type_kurgan f 
    JOIN public.sr_service s ON upper(trim(s.code)) = upper(trim(f.code))
    WHERE f.id = 1 AND s.org_id = _clinic_id --AND s.is_system
    LIMIT 1
    ;  
    IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_spec_gen_extra. 10'); END IF; 
    IF (_sr_service_id IS NULL) THEN RETURN; END IF;
    
    IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_spec_gen_extra. 11'); END IF; 
     --обновляем стоимость 
         
        perform billing.fin_get_price_station_case(g.case_id,g.price_list_id,coalesce(g.price_list_vmp,0),g.date_bill_mek, g.npl_service_id_arr)
        FROM ( SELECT s.*,
                      (
                        SELECT f.id 
                        FROM fin_price_list f 
                        JOIN fin_pl_type l ON l.id=f.type_id AND l.code='3'
                        WHERE f.clinic_id=_clinic_id AND s.date_bill_mek between coalesce(f.from_dt,'-infinity') AND coalesce(f.to_dt,'infinity')
                      ) as price_list_vmp
               FROM 
               (
                 SELECT g.case_id, g.price_list_id, g.case_close_date, coalesce(to_date(g.region_data->'date_bill_mek','dd.mm.yyyy'),g.to_date) as date_bill_mek,
			array_agg(id) npl_service_id_arr
                 FROM tmp_fin_bill_generate g 
                 WHERE 1=1
			AND g.service_id = _sr_service_id
			AND (region_data ? 'tarif')
		GROUP BY 1, 2, 3, 4	--все указанные поля - свойства случая, значит, уникальны в рамках случая, значит, можно по ним сгруппировать
		HAVING SUM(CASE WHEN service_id = _sr_service_id THEN 1 ELSE 0 END) > 0 --выбираем только такие случаи (а не записи), в которых есть услуга
                ) s 
            ) g
        ;

        
      
    IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_spec_gen_extra. 12'); END IF; 
    --обновляем стоимость из таблицы fin_temp_hsp_rec_price_kurgan, в ней хранится стоимость для каждого шага
        UPDATE tmp_fin_bill_generate g 
        SET 
            tariff = q.price,
            price  = q.price
        FROM
            fin_temp_hsp_rec_price_kurgan q
        WHERE 
            g.bill_id = p1_bill_id AND g.case_id = q.case_id AND g.step_id = q.step_id AND g.service_id = _sr_service_id 
        ;
ELSIF _bill_type='smp' THEN        
      PERFORM billing.fin_spec_gen_price (p1_bill_id);   

--       WITH sv AS 
--           (
--            SELECT case_id, array_agg(id order by price desc nulls last, id) as id
--            FROM tmp_fin_bill_generate 
--            WHERE 1 = 1 /*bill_id=p1_bill_id*/ AND not is_sifted 
--            GROUP by case_id
--           )
--       UPDATE tmp_fin_bill_generate f SET tariff=0,price=0 FROM sv WHERE 1 = 1 /*f.bill_id=p1_bill_id*/ AND not is_sifted AND f.case_id=sv.case_id AND f.id<>sv.id[1]; */

      --выбираем список услуг с максимальной ценой в случае
      WITH sv AS 
	(SELECT id, ROW_NUMBER() OVER (PARTITION BY case_id ORDER BY price DESC NULLS LAST) rn
	 FROM tmp_fin_bill_generate
	 WHERE NOT is_sifted
	)
	UPDATE tmp_fin_bill_generate f SET tariff=0,price=0 FROM sv WHERE 1 = 1 AND not is_sifted AND f.id = sv.id AND rn <> 1;
           
ELSE
     PERFORM billing.fin_spec_gen_price (p1_bill_id);                  
END IF;

IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_spec_gen_extra. Конец'); END IF; 
 
EXCEPTION
    WHEN NO_DATA_FOUND THEN RAISE EXCEPTION 'Отсутствуют данные по счёту';
END;
$$;

