CREATE FUNCTION add_amb_call_double(xcall integer, xnote integer, xtype boolean, xreg integer, xoriginal integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
    xcnote integer;
  begin
    xcnote = amb.add_call_note (xcall,xnote,xtype,null,null,xreg,null);
    if xtype THEN
        insert into amb.md_ambulance_call_double (id,call_note_id,note_id,call_id)
    		values (nextval('amb.md_ambulance_call_double_id_seq'),xcnote,xnote,xoriginal);
        if xnote = 8
        	then update amb.md_ambulance_call set to_time = now() where id = xcall;
        end if;
        	 ELSE
             	update amb.md_ambulance_call set to_time = null where id = xcall;
    end if;
  end;
$$;

