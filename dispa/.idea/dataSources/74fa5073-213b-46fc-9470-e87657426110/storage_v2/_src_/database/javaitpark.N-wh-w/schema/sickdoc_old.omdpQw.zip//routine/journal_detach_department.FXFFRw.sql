CREATE FUNCTION journal_detach_department(p_journal_id integer, p_dep_id integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
BEGIN

-- Если журнал является общим для клиники, то нет смысла удалять отделения - они изначально не могут быть привязаны к журналу такого типа на уровне БД
  IF (SELECT is_common_for_clinic
      FROM sickdoc.journal
      WHERE id = p_journal_id)
  THEN
    RETURN;
  END IF;

  DELETE FROM sickdoc.journal_default
  WHERE journal_id = $1 AND dep_id = $2;

END;
$$;

