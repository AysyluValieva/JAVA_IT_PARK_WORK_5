CREATE FUNCTION typing_get_mc_case_json(integer)
  RETURNS json
LANGUAGE plpgsql
AS $$
declare rec record;
begin
 for rec in 
 with 
 sl as (select sl.* from md_sicklist sl join md_sicklist_type st on st.id = sl.type_id and upper(st.name) = 'ПЕРВИЧНЫЙ' where case_id = $1 limit 1),
 disp as (select d.*, row_number() over(partition by diagnosis_id order by id desc) rn from pci_dispensary d where coalesce(d.med_case_in_id, d.med_case_out_id) = $1 ),
 rd as (
  select 
   concat(
    '{',
    '"id":"', d.id::text, '",',
    '"mkb_id":"', d.diagnos_id::text, '",',
    '"disease_type_id":"', d.disease_type_id::text, '",',
    '"type_id":"', d.type_id::text, '",',
    '"is_main":"', case d.is_main when true then 'true' else 'false' end, '",',
    '"stage_id":"', d.stage_id::text, '",',
    '"step_id":"', d.step_id::text, '",',
    '"step_num":"', d.step_id::text, '",',
    '"disp_id":"', disp.id::text, '",',
    '"disp_in_out":"', case when med_case_in_id = $1 then 'in' when med_case_out_id = $1 then 'out' end::text, '",',
    '"nosol_registr_id":"', disp.nosol_registr_id::text, '",',
    '"dispensary_group_id":"', disp.dispensary_group_id::text, '",',
    '"reg_in_dt":"', to_char(disp.reg_in_dt, 'yyyy-mm-dd'), '",',
    '"reg_out_dt":"', to_char(disp.reg_in_dt, 'yyyy-mm-dd'), '",',
    '"reg_in_doctor_id":"', disp.reg_in_doctor_id::text, '",',
    '"reg_out_doctor_id":"', disp.reg_out_doctor_id::text, '",',
    '"reg_stage_id":"', disp.reg_stage_id::text, '",',
    '"reg_out_reason_id":"', disp.reg_out_reason_id::text, '"',
    '}') rd
  from mc_diagnosis d 
  left join disp on disp.diagnosis_id = d.diagnos_id and disp.rn = 1
  left join md_nosol_registr n on n.id = disp.nosol_registr_id
  where d.case_id = $1
 ),

t as
(
select 
 concat('{',
 --case
 '"patient_id":"', c.patient_id::text, '",',
 '"clinic_id":"', c.clinic_id::text, '",',
 '"id":"', c.id::text, '",',
 '"uid":"', c.uid, '",',
 '"care_regimen_id":"', c.care_regimen_id, '",',
 '"funding_id":"', c.funding_id::text, '",',
 '"init_goal_id":"', c.init_goal_id::text, '",',
 '"care_level_id":"', c.care_level_id::text, '",',
 '"care_providing_form_id":"', c.care_providing_form_id::text, '",',

 '"payment_method_id":"', c.payment_method_id::text, '",',
 '"admission_reason_id":"', c.admission_reason_id, '",',
 '"repeat_count_id":"', c.repeat_count_id::text, '",',
 '"main_diagnos_id":"'::text, c.main_diagnos_id::text, '",',
 --ref
 '"referral_id":"', c.referral_id::text, '",',
 '"ref_organization_id":"', r.ref_organization_id::text, '",',
 '"ref_doctor_id":"', r.ref_doctor_id::text, '",',
 '"referral_date":"', to_char(r.referral_date, 'yyyy-mm-dd'), '",',
 '"recv_organization_id":"', r.recv_organization_id::text, '",',
 '"order_number":"', r.order_number, '",',
 '"referral_type_id":"', r.referral_type_id::text, '",', 
 '"ref_mkb_id":"', r.diagnosis_id::text, '",', 
 --sl
 '"sicklist_id":"', sl.id::text, '",',
 '"sl_code":"', sl.code, '",',
 '"disability_reason_id":"', sl.disability_reason_id::text, '",',
 '"disability_from_dt":"', to_char(sl.disability_from_dt, 'yyyy-mm-dd'), '",',
 '"disability_to_dt":"', to_char(sl.disability_to_dt, 'yyyy-mm-dd'), '",') ||
 -- все диагнозы случа¤
 '"diagnosis":[' || concat('', (select array_to_string(array_agg(rd), ',') from rd )) || '],'  ||
 -- все услуги случа¤ [массив]
 concat('"services":[',
               (
                select 
                  array_to_string(array_agg(
                      concat('{',
                          '"id":"', sr.id::text, '",',
                        '"step_num":"', mr.step_id::text, '",',
                          '"step_id":"', mr.step_id::text, '",',
                          '"service_id":"', sr.service_id::text, '",',
                          '"bdate":"', to_char(sr.bdate, 'yyyy-mm-dd'), '",',
                          '"funding_id":"', sr.funding_id::text, '",',
                          '"quantity":"', sr.quantity::text, '",',
                          '"res_group_id":"', COALESCE(typing_get_nosystem_res_group(sr.res_group_id),sr.res_group_id)::text, '",',

													'"srv_result_id":"', srr.id::text, '",',
													'"result_type_id":"', srr.result_type_id::text, '",',
													'"value":"', srr.value::text, '",',
                         -- '"doctor_id":"', (select rgr.resource_id from sr_res_group_relationship rgr join sr_res_role r on r.id = rgr.role_id and r.code = 'DOCTOR' and rgr.group_id = sr.res_group_id limit 1), '",',
                          '"mkb_id":"', mr.diagnosis_id::text, '"', '}') 
                  ), ',')
                from md_srv_rendered mr join sr_srv_rendered sr on mr.id = sr.id left join sr_srv_result srr on srr.service_id = sr.id
 where mr.case_id = c.id 
 limit 1
               ), '],') ||
 -- посещени¤
CASE WHEN exists(SELECT 1 FROM mc_step st join plc_visit v on v.id = st.id where st.case_id = c.id ) then
 concat('"visits":[',
               (
                select 
                  array_to_string(array_agg(
                      concat('{',
                          '"id":"', st.id::text, '",',
                        '"step_num":"', st.id::text, '",',
                          '"type_id":"', v.type_id::text, '",',
                          '"admission_date":"', to_char(st.admission_date, 'yyyy-mm-dd'), '",',
                          '"place_id":"', v.place_id::text, '",',
                          '"initiator_id":"', v.initiator_id::text, '",',
                          '"goal_id":"', v.goal_id::text, '",',
                          '"profile_id":"', st.profile_id::text, '",',
                          '"standard_id":"', st.standard_id::text, '",',
                          '"mes_id":"', st.mes_id::text, '",',
                          '"res_group_id":"', COALESCE(typing_get_nosystem_res_group(st.res_group_id),st.res_group_id)::text, '",',
                          '"doctor_id":"', (select rgr.resource_id from sr_res_group_relationship rgr join sr_res_role r on r.id = rgr.role_id and r.code = 'DOCTOR' and rgr.group_id = st.res_group_id limit 1), '",',
                          '"result_id":"', st.result_id::text, '",',
                          '"outcome_id":"', st.outcome_id::text, '"',
                          '}') 
                  ), ',')
                from mc_step st join plc_visit v on v.id = st.id where st.case_id = c.id 
               ), ']') 
WHEN exists(SELECT 1 FROM mc_step st join hsp_record r on r.id = st.id where st.case_id = c.id ) then
 concat('"visits":[',
               (
                select 
                  array_to_string(array_agg(
                      concat('{',
                          '"id":"', st.id::text, '",',
                          '"step_num":"', st.id::text, '",',
						              '"department_id":"',h.department_id::text, '",',
													'"bed_profile_id":"', h.bed_profile_id, '",',
                          '"admission_date":"', to_char(st.admission_date, 'yyyy-mm-dd'), '",',
                          '"outcome_date":"', to_char(st.outcome_date, 'yyyy-mm-dd'), '",',
                          '"profile_id":"', st.profile_id::text, '",',
                          '"standard_id":"', st.standard_id::text, '",',
                          '"mes_id":"', st.mes_id::text, '",',
                          '"res_group_id":"', COALESCE(typing_get_nosystem_res_group(st.res_group_id),st.res_group_id)::text, '",',
                          '"doctor_id":"', (select rgr.resource_id from sr_res_group_relationship rgr join sr_res_role r on r.id = rgr.role_id and r.code = 'DOCTOR' and rgr.group_id = st.res_group_id limit 1), '",',
                          '"result_id":"', st.result_id::text, '",',
                          '"outcome_id":"', st.outcome_id::text, '",',
                          '"csg_id":"', st.csg_id::text, '"',
                          '}') 
                  ), ',')
                from mc_step st join hsp_record h on h.id = st.id where st.case_id = c.id 
               ), ']') 

end  

|| '}' t
from mc_case c
left join md_referral r on r.id = c.referral_id
left join sl on true
where c.id = $1
)

select t::json from t
loop 
end loop;
return rec.t;

end
$$;

