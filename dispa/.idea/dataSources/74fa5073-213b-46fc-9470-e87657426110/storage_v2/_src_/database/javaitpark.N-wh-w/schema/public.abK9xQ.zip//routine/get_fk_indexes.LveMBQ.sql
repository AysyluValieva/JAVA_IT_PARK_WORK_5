CREATE FUNCTION get_fk_indexes()
  RETURNS text
LANGUAGE plpgsql
AS $$
declare
            fk record;
            col record;
            ix record;
            idx_fk_list text;
            col_name_ix varchar(30);
            col_name_fk varchar(30);
            col_ix int2vector;
            idx_exists bool;
            i int;
            col_fk_list varchar(1000);
            v_cnt int := 0;
            v_ix_name information_schema.key_column_usage.constraint_name%type;
            v_dup_cnt int;
            v_q   text;
            begin
            idx_fk_list :='';
            drop table if exists tt_ix_name;
            create global temporary table tt_ix_name(ix_name text)on commit preserve rows;
            for fk in
            select distinct table_name, constraint_name, constraint_schema
            from information_schema.key_column_usage kcu
            where kcu.constraint_schema = current_schema()
            and exists (select 1 from information_schema.referential_constraints rc where rc.constraint_name = kcu.constraint_name and kcu.constraint_schema = rc.constraint_schema)
            loop
            begin
            idx_exists := false;
            v_q := null;
            for ix in
            -- get all indexes for given table
            select * from pg_index ix1 where ix1.indrelid in (select oid from pg_class where lower(relname) = lower(fk.table_name)) loop
            i := 0;
            while ix.indkey[i] is not null loop -- loop through index columns
            col_name_fk := null;
            select into col_name_fk kcu.column_name
            from information_schema.key_column_usage kcu
            where kcu.table_name = fk.table_name
            and kcu.constraint_name = fk.constraint_name
            and kcu.constraint_schema = fk.constraint_schema
            and kcu.column_name = (select attname from pg_attribute where attnum = ix.indkey[i] and attrelid = ix.indrelid);
            if col_name_fk is null then exit; end if; -- that is - index columns NOT match constraint columns
            i := i + 1;
            end loop;
            idx_exists := col_name_fk is not null;
            if idx_exists then exit; end if; -- if index already defined
            end loop;
            if not idx_exists then
            col_fk_list := null;
            for col in select *
            from information_schema.key_column_usage kcu
            where kcu.table_name = fk.table_name
            and kcu.constraint_name = fk.constraint_name
            and kcu.constraint_schema = fk.constraint_schema loop
            if col_fk_list is null then col_fk_list := col.column_name;
            else col_fk_list := col_fk_list||','||col.column_name;
            end if;
            end loop;
            v_ix_name := fk.constraint_name;
            v_dup_cnt := 0;
            loop
            select into v_dup_cnt count(1)
            from tt_ix_name
            where lower(v_ix_name) = lower(ix_name);
            if v_dup_cnt = 0 then
            select into v_dup_cnt count(1)
            from pg_index i, pg_class c, pg_namespace ns
            where i.indexrelid = c.oid
            and ns.oid = c.relnamespace
            and lower(c.relname) = lower(v_ix_name)
            and lower(ns.nspname) = lower(fk.constraint_schema);
            end if;
            exit when v_dup_cnt = 0;
            v_cnt := v_cnt + 1;
            v_ix_name := fk.constraint_name||'_'||v_cnt;
            end loop;
            v_q := 'create index '||v_ix_name||' on '||fk.table_name||'('||col_fk_list||');';
            insert into tt_ix_name(ix_name) values(v_ix_name);
            idx_fk_list:=idx_fk_list|| v_q;
            -- raise notice '%', v_q;
            end if;
            if not idx_exists then
            raise notice '% % %', (case idx_exists when true then '+' else '-' end), fk.table_name, fk.constraint_name;
            end if;
            exception
            when others then raise notice 'fk=%; %:% q=%', fk.constraint_name, sqlstate, sqlerrm, v_q;
            end;
            end loop;
            return idx_fk_list;
            end;
$$;

