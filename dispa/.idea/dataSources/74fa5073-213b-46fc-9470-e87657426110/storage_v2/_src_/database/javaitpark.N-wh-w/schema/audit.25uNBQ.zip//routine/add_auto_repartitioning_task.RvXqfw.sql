CREATE FUNCTION add_auto_repartitioning_task()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE
                  old_partition_period_id INTEGER;
                  new_partition_period_id INTEGER;
                BEGIN
                  old_partition_period_id = NEW.partition_period_id;

                  IF TG_OP = 'INSERT'
                  THEN
                    IF old_partition_period_id != 2
                    THEN
                      CASE old_partition_period_id
                        WHEN 1
                        THEN new_partition_period_id = 6;
                        WHEN 6
                        THEN new_partition_period_id = 4;
                        WHEN 4
                        THEN new_partition_period_id = 3;
                        WHEN 3
                        THEN new_partition_period_id = 2;
                      END CASE;

                      INSERT INTO audit.repartitioning_task (
                        table_setting_id, from_partition_period_id, to_partition_period_id, status_id, mode_type_id, created_at)
                      VALUES (NEW.table_setting_id, NEW.partition_period_id, new_partition_period_id, 1, 2, current_timestamp);
                    END IF;

                    RETURN NEW;
                  END IF;

                END;
$$;

