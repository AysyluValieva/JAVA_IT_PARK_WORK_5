CREATE FUNCTION fin_bill__get_root_clinic(bill_id integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
    clinic_id integer;
begin
    clinic_id = (select fin_bill__get_clinic(bill_id));
    clinic_id = (select fin_clinic__get_root_clinic(clinic_id));
    return clinic_id;
end;
$$;

