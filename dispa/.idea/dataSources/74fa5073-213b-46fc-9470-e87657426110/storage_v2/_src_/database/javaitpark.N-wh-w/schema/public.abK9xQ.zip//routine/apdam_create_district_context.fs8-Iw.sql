CREATE FUNCTION apdam_create_district_context(in_md_clinic_id integer, in_check_district boolean, in_department_id integer, in_type_id integer, in_reg_date date)
  RETURNS void
LANGUAGE plpgsql
AS $$
BEGIN
  RAISE NOTICE '----Создание ограниченного контекста для участков ...';
  EXECUTE apdam_create_district_limited_context(in_md_clinic_id, in_check_district, in_department_id, in_type_id,
                                                in_reg_date);

  RAISE NOTICE '----Создание расширенного контекста для участков (вытягиваем из адресов уровня 4 и 5 все до улицы включительно) ...';
  EXECUTE apdam_create_district_extended_context();
END;
$$;

