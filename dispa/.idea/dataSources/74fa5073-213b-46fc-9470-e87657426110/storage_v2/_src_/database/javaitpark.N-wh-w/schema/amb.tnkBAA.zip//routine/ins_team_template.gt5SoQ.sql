CREATE FUNCTION ins_team_template(xorg integer, xcode character varying, xname character varying, xteam_kind integer, xjob_kind integer, xteam_type integer, xprof integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
					xid integer;
				  begin
					xid = nextval('amb.sr_res_team_template_id_seq');
					insert into amb.sr_res_team_template(id,org_id,code,name,team_kind_id,job_kind_id,team_type_id)
						values (xid,xorg,xcode,xname,xteam_kind,xjob_kind,xteam_type);
					If xprof is not null then
						insert into amb.sr_res_team_template_profile(team_template_id,profile_id)
							values (xid,xprof);
					end if;
					return xid;
				  end;

$$;

