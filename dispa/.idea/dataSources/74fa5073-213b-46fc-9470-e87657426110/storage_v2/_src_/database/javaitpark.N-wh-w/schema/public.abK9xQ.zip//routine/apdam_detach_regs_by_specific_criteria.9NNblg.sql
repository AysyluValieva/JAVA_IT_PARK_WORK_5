CREATE FUNCTION apdam_detach_regs_by_specific_criteria(in_reg_date date, in_specific_criteria character varying)
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
  criteria_ids VARCHAR [] := ARRAY [] :: VARCHAR [];
BEGIN
  DROP TABLE IF EXISTS apdam_regs_check_by_specific_criteria;
  CREATE UNLOGGED TABLE apdam_regs_check_by_specific_criteria WITH (AUTOVACUUM_ENABLED = FALSE
  ) AS
    SELECT
      r.reg_id,
      r.reg_info,
      r.current_district_id,
      c1.terminal_id  AS address_terminal_id,
      c2.terminal_id  AS org_terminal_id,
      c3.terminal_id  AS diagnosis_terminal_id,
      c4.terminal_id  AS age_terminal_id,
      c5.terminal_id  AS gender_terminal_id,
      c6.terminal_id  AS benefit_terminal_id,
      NULL :: BOOLEAN AS check_by_specific_criterias
    FROM apdam_regs r
      JOIN md_clinic_district d ON d.id = r.current_district_id
      JOIN md_clinic_separation s ON s.id = d.separation_id
      LEFT JOIN md_district_criterion c1 ON c1.separation_id = s.id AND c1.type_id = 1
      LEFT JOIN md_district_criterion c2 ON c2.separation_id = s.id AND c2.type_id = 2
      LEFT JOIN md_district_criterion c3 ON c3.separation_id = s.id AND c3.type_id = 3
      LEFT JOIN md_district_criterion c4 ON c4.separation_id = s.id AND c4.type_id = 4
      LEFT JOIN md_district_criterion c5 ON c5.separation_id = s.id AND c5.type_id = 5
      LEFT JOIN md_district_criterion c6 ON c6.separation_id = s.id AND c6.type_id = 6
    WHERE r.current_district_id NOTNULL
          AND r.new_district_id ISNULL;

  criteria_ids = regexp_split_to_array($2, E',');

  DELETE FROM apdam_regs_check_by_specific_criteria
  WHERE    ('1' = ANY (criteria_ids) AND address_terminal_id != 3)
        OR ('2' = ANY (criteria_ids) AND org_terminal_id != 3)
        OR ('3' = ANY (criteria_ids) AND diagnosis_terminal_id != 3)
        OR ('4' = ANY (criteria_ids) AND age_terminal_id != 3)
        OR ('5' = ANY (criteria_ids) AND gender_terminal_id != 3)
        OR ('6' = ANY (criteria_ids) AND benefit_terminal_id != 3);

    UPDATE apdam_regs_check_by_specific_criteria r
    SET check_by_specific_criterias = apdam_check_by_specific_criterias(reg_info, current_district_id, criteria_ids);

  WITH cte AS (
      SELECT *
      FROM apdam_regs_check_by_specific_criteria r
      WHERE check_by_specific_criterias = FALSE
  )
  UPDATE pci_patient_reg r
  SET
    state_id = 2,
    unreg_cause_id = 1,
    unreg_dt = in_reg_date
  FROM cte
  WHERE cte.reg_id = r.id;
END;
$$;

