CREATE FUNCTION save_notification(xid integer, xcase_id integer, xorg_id integer, xsr_srv_rendered_id integer, xnotificationnumber character varying, xnotificationdate date, xdiagnosis_id integer, xdisease_type_id integer, xis_suspicion boolean, xdisease_date date, xprimary_treatment_date date, xdiagnosis_determination_date date, xlast_visit_date date, xhospitalization_date date, xhospitalization_place integer, xpoisoning text, xantiepidemic text, xreported_employee_id integer, xprimary_ses_signal_date timestamp without time zone, xfio_accepted character varying, xdispatch_date timestamp without time zone, xregistration_number character varying, xses_number character varying)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
  result_id INTEGER;
begin
  if (xid is null) then
    result_id = (select nextval('disp.md_notification_id_seq'));
    INSERT INTO disp.md_notification(
      id, case_id, org_id, service_id, notif_number, notif_date, diagnosis_id, disease_type_id,
      is_suspicion, disease_date, primary_treatment_date, diagnosis_determination_date,
      last_visit_date, hospitalization_date, hospitalization_place,
      poisoning, antiepidemic, reported_employee_id, primary_ses_signal_date,
      fio_accepted, dispatch_date, registration_number, ses_number,
      status_id)
    VALUES (result_id, xcase_id, xorg_id, xsr_srv_rendered_id, xnotificationNumber, xnotificationDate,
                                                    xdiagnosis_id, xdisease_type_id, xis_suspicion, xdisease_date, xprimary_treatment_date,
      xdiagnosis_determination_date, xlast_visit_date, xhospitalization_date, xhospitalization_place,
      xpoisoning, xantiepidemic, xreported_employee_id, xprimary_ses_signal_date, xfio_accepted,
      xdispatch_date, xregistration_number, xses_number, 1);
  else
    UPDATE disp.md_notification
    SET case_id = xcase_id, org_id = xorg_id, service_id = xsr_srv_rendered_id, notif_number = xnotificationNumber, notif_date = xnotificationDate, diagnosis_id = xdiagnosis_id,
      disease_type_id = xdisease_type_id, is_suspicion = xis_suspicion, disease_date = xdisease_date, primary_treatment_date = xprimary_treatment_date,
      diagnosis_determination_date = xdiagnosis_determination_date, last_visit_date = xlast_visit_date, hospitalization_date = xhospitalization_date,
      hospitalization_place = xhospitalization_place, poisoning = xpoisoning, antiepidemic = xantiepidemic, reported_employee_id = xreported_employee_id,
      primary_ses_signal_date = xprimary_ses_signal_date, fio_accepted = xfio_accepted, dispatch_date = xdispatch_date, registration_number = xregistration_number,
      ses_number = xses_number
    WHERE id = xid;
    result_id = xid;
  end if;

  return result_id;
end;
$$;

