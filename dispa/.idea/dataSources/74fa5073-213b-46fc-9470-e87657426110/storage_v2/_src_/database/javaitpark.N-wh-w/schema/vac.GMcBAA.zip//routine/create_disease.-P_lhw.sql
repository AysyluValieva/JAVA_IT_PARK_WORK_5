CREATE FUNCTION create_disease(xcode character varying, xlabel character varying, xecode character varying, xsimpledisease character varying)
  RETURNS integer
LANGUAGE plpgsql
AS $$
DECLARE
                  new_disease_id integer;
                  xsimplediseaseid json;
                BEGIN
                  insert into vac_disease (id, code, label, e_code) VALUES (nextval('public.vac_disease_id_seq'), xcode,
                    xlabel, xecode)
                    returning id into new_disease_id;

                  if (xsimpledisease is not null) then
                  foreach xsimplediseaseid in array array(select value from json_array_elements(cast(xsimpledisease as json)))
                    LOOP
                      insert into vac_disease2disease (self, child) values (new_disease_id, xsimplediseaseid::text::int);
                    END LOOP;
                  end if;
                  return new_disease_id;
                END;
$$;

