CREATE VIEW md_spj_simple_journal_v AS
  SELECT mdsr.id,
    to_char((sr.bdate)::timestamp with time zone, 'DD.MM.YYYY'::text) AS begin_date,
    sr.cost
   FROM (md_srv_rendered mdsr
     JOIN sr_srv_rendered sr ON ((sr.id = mdsr.id)))
  WHERE (sr.service_id = 2)
  ORDER BY mdsr.id;

