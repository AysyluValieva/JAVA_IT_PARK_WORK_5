CREATE FUNCTION getdoctorlist_v3(idspesiality text, _department_id integer, idpat text DEFAULT NULL::text)
  RETURNS TABLE(arianumber character varying, countfreeparticipantie integer, countfreeticket integer, iddoc character varying, lastdate character varying, name character varying, nearestdate character varying, snils character varying)
LANGUAGE plpgsql
AS $$
DECLARE
-- v_rec typ_sp%ROWTYPE;
_idpat integer;
_id_lpu integer;
BEGIN
--если  _department_id > 10 000 000, то это _department_id,  иначе _id_lpu
if(_department_id > 10000000)
then 
	_id_lpu=null;
	_department_id = substr(_department_id::text, 2, 8)::integer;
else 
	_id_lpu = _department_id;
	_department_id=null;
end if;


if( upper(idpat)='NULL::TEXT' or upper(idpat)='NULL' or idpat='') then  _idpat=0; else _idpat=idpat; end if;
return query (
with 

 other as(select    count(sr_ses.id) as CountFreeTicket,
			ps.e_code FerIdSpesiality, 
			ps.code IdSpesiality, 
			cast(max(shift.bdatetime) as timestamp)::varchar LastDate,
			ps.name NameSpesiality,  
			cast(min(shift.bdatetime) as timestamp)::varchar NearestDate 
,  			concat ( COALESCE(srg.name,concat ( pi.surname || ' ' ||  pi.name || ' ' || pi.patr_name) )  || ' ' || COALESCE(pd.name, '') ) as RGName --Наименование ресурса
 ,mcs.id as AriaNumber
,pid.number as SNILS
,srg.id as IdDoc --Идентификатор ресурса
			from sr_res_group srg 
			left join pim_department pd on pd.id = srg.department_id
			join  sr_timetable_res_group strg on strg.res_group_id=srg.id
			join sr_timetable st on st.id=strg.id
			join sr_shift  shift on shift.timetable_id= st.id
				left join sr_session sr_ses on sr_ses.shift_id = shift.id and sr_ses.time_type_id!=2 and CURRENT_TIMESTAMP::TIMESTAMP < sr_ses.bdatetime --CURRENT_TIMESTAMP 
and cast(sr_ses.edatetime as date)<=(CURRENT_DATE + INTERVAL '1 month')::date
					left join sr_session_ticket sst on sst.session_id=sr_ses.id
			join pim_employee_position  pep on pep.id=srg.responsible_id
			join PIM_POSITION pp on pp.id=pep.position_id
			join pim_employee pe on pe.id=pep.employee_id
			join pim_individual pi on pi.id=pe.individual_id
			left join pim_individual_doc pid on pid.indiv_id=pi.id and pid.type_id=19
			join PIM_SPECIALITY ps on ps.id=pp.speciality_id
			left join sr_session_source_na sssn on sssn.session_id= sr_ses.id
			left join  sr_session_quotum ssq on sr_ses.id=ssq.session_id
			left join md_employee_position mep on  mep.id=pep.id
			left join	md_clinic_separation mcs on mep.profile_id=mcs.profile_id			
			where st.edate > CURRENT_DATE 
			and sst.session_id is null --не учитывать занятые сеансы
			and shift.time_type_id is not null --требование
			and   case  when _department_id is null then srg.org_id =_id_lpu  else   srg.department_id=_department_id::integer end 
				and ps.code=idspesiality
			and ssq.session_id is null --не учитывать квоты
			and  sssn.session_id is null --не учитывать недоступные записи
			and shift.time_type_id!=2 
			and not exists(select 1 from md_appointment p where customer_id=_idpat::INTEGER and shift.bdatetime  >= p.bdatetime and shift.bdatetime <=p.edatetime )
		--блок ресурса
				--and not exists (select 1 from sr_res_group_block where shift.bdatetime::date >= bdate::date and  shift.bdatetime::date <=edate::date and res_group_id=srg.id)
			/*and not exists( select 1 from  (select 
																						( shift.bdatetime::date,  shift.bdatetime::date) overlaps
																									(bdate::date, edate::date) result
																						from sr_res_group_block where res_group_id=srg.id )
																						a where result is false or result is null*/
			group by   ps.name, ps.e_code, ps.code,
RGName
, mcs.id,pid.number,pe.id, srg.id  )

select 
	other.AriaNumber::varchar,
	other.CountFreeTicket::integer as CountFreeParticipantIE ,
	other.CountFreeTicket::integer,
	other.IdDoc::varchar,
	other.LastDate::varchar, 
  other.RGName::varchar as Name,
	other.NearestDate::varchar,
 	other.SNILS::varchar
from other
order by other.CountFreeTicket desc
 );
END;
$$;

