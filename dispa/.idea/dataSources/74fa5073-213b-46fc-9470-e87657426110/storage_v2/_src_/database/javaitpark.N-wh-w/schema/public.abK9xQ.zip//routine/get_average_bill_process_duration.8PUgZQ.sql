CREATE FUNCTION get_average_bill_process_duration(OUT time10k integer, OUT region text)
  RETURNS record
STABLE
LANGUAGE plpgsql
AS $$
DECLARE
    _r RECORD;
    _n BIGINT := 0;
    _srv_cnt BIGINT := 0;
    _all_speed DECIMAL := 0;
BEGIN
    FOR _r IN
        SELECT
            c.bill_id, coalesce (nullif (extract (epoch from age (max (c.date), max (p.date)))::BIGINT, 0), 1)::INTEGER AS process_time
        FROM 
            public.fin_bill_status_log AS c
            JOIN LATERAL 
            (
                SELECT date FROM public.fin_bill_status_log WHERE status_id = 7 AND bill_id = c.bill_id AND user_id = c.user_id AND date < c.date ORDER BY date DESC LIMIT 1
            ) AS p ON TRUE
        WHERE
            c.status_id = 1 AND c.date <@ tsrange (LOCALTIMESTAMP - '14 days'::INTERVAL, LOCALTIMESTAMP, '[]')
            AND NOT EXISTS (SELECT 1 FROM public.fin_bill_status_log WHERE bill_id = c.bill_id AND p.date < date AND date < c.date)
        GROUP BY 1
    LOOP
        IF
            (SELECT status_id IN (1, 2, 3, 4, 5) FROM public.fin_bill WHERE id = _r.bill_id)
        THEN
            _n := _n + 1;
            _srv_cnt := (SELECT service_count FROM public.fin_bill_spec WHERE NOT is_correct AND bill_id = _r.bill_id);
            _all_speed := _all_speed + _srv_cnt / _r.process_time::DECIMAL;
        END IF;
    END LOOP;
    IF
        nullif (_all_speed / _n::DECIMAL, 0) IS NOT NULL
    THEN
        time10k := round (10000 / (_all_speed / _n::DECIMAL));
    END IF;
    region := (SELECT value FROM public.cmn_setting_value WHERE setting_id = 'cz.atria.common.settings.impl.ProductOwnerInfoSettings.regionCode');
END;
$$;

