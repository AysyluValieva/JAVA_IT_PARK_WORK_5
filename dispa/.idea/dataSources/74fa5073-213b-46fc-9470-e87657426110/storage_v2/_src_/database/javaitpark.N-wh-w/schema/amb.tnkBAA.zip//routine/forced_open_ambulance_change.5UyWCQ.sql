CREATE FUNCTION forced_open_ambulance_change(xclin integer, xdep integer, xreg integer, xuser integer)
  RETURNS date
LANGUAGE plpgsql
AS $$
declare
                            xset integer;
                            xchange integer;
                            yesterdaychange record;

                            xroute integer;
                            xchbegin TIME WITHOUT TIME ZONE;
                            xchperiod INTERVAL;

                            xtypeNum integer;
                            xnumid integer;

                            xval integer;
                          begin
                            select into xset id from amb.md_ambulance_change_setting where clinic_id = xclin and (department_id is null or department_id = xdep) order by department_id limit 1;
                            select into xroute,xchbegin,xchperiod route_id,change_begin,change_period from amb.md_ambulance_change_setting where id = xset;

                            xchange:= amb.insert_into_md_ambulance_change (cast(now() as date),xclin,xdep);

                            --execute amb.zeroing_number(xclin);
                            select into xtypeNum,xnumid mans.type_num,mans.id from amb.md_ambulance_numb_setting mans left join amb.md_ambulance_numbers man on mans.id = man.numb_id
                                    where mans.clinic_id = xclin;
                                IF not exists (select * from amb.md_ambulance_numbers man left join amb.md_ambulance_numb_setting mans on mans.id = man.numb_id
                                    where mans.clinic_id = xclin and man.change_id = xchange and man.dep_id = xdep)
                                THEN
                                  if xtypeNum = 1
                                    then
                                        xval =0;
                                        /*insert into amb.md_ambulance_numbers (change_id,numb_id, value,dep_id)
                                            values (xchange,xnumid,0,xdep);*/
                                    end if;
                                  if (xtypeNum = 2)
                                    then
                                      if (EXTRACT(dow FROM now()) = 1)
                                         or not exists(select * from amb.md_ambulance_numbers man
                                                        left join amb.md_ambulance_numb_setting mans on mans.id = man.numb_id
                                                        where mans.clinic_id = xclin and man.dep_id = xdep)
                                         or (
                                              (select extract(week from mac.from_data) from  amb.md_ambulance_change mac
                                                  where mac.clinic_id = xclin and mac.department_id = xdep and mac.state = 1
                                                  order by mac.from_data desc
                                                  limit 1
                                               ) < EXTRACT(week FROM now())
                                           or
                                              (select extract(year from mac.from_data) from  amb.md_ambulance_change mac
                                                  where mac.clinic_id = xclin and mac.department_id = xdep and mac.state = 1
                                                  order by mac.from_data desc
                                                  limit 1
                                               )< EXTRACT(year FROM now())
                                            )
                                        then
                                            xval = 0;
                                        else
                                            xval = (select value from amb.md_ambulance_numbers man left join amb.md_ambulance_numb_setting mans on mans.id = man.numb_id
                                                        where mans.clinic_id = xclin and man.dep_id = xdep order by man.id desc limit 1);
                                      end if;
                                    end if;
                                  if (xtypeNum = 3)
                                    then
                                      if (EXTRACT(day FROM now()) = 1)
                                        or not exists(select * from amb.md_ambulance_numbers man
                                                        left join amb.md_ambulance_numb_setting mans on mans.id = man.numb_id
                                                        where mans.clinic_id = xclin and man.dep_id = xdep)
                                        or (
                                              (select extract(month from mac.from_data) from  amb.md_ambulance_change mac
                                                  where mac.clinic_id = xclin and mac.department_id = xdep and mac.state = 1
                                                  order by mac.from_data desc
                                                  limit 1
                                               ) < EXTRACT(month FROM now())
                                           or
                                              (select extract(year from mac.from_data) from  amb.md_ambulance_change mac
                                                  where mac.clinic_id = xclin and mac.department_id = xdep and mac.state = 1
                                                  order by mac.from_data desc
                                                  limit 1
                                               )< EXTRACT(year FROM now())
                                           )
                                        then
                                            xval = 0;
                                        else
                                            xval = (select value from amb.md_ambulance_numbers man left join amb.md_ambulance_numb_setting mans on mans.id = man.numb_id
                                                        where mans.clinic_id = xclin and man.dep_id = xdep order by man.id desc limit 1);
                                      end if;
                                    end if;
                                  if (xtypeNum = 4)
                                    then
                                      if (EXTRACT(doy FROM now()) = 1)
                                        or not exists(select * from amb.md_ambulance_numbers man
                                                        left join amb.md_ambulance_numb_setting mans on mans.id = man.numb_id
                                                        where mans.clinic_id = xclin and man.dep_id = xdep)
                                        or (
                                              (select extract(year from mac.from_data) from  amb.md_ambulance_change mac
                                                  where mac.clinic_id = xclin and mac.department_id = xdep and mac.state = 1
                                                  order by mac.from_data desc
                                                  limit 1
                                               )< EXTRACT(year FROM now())
                                           )
                                        then
                                            xval = 0;
                                        else
                                            xval = (select value from amb.md_ambulance_numbers man left join amb.md_ambulance_numb_setting mans on mans.id = man.numb_id
                                                        where mans.clinic_id = xclin and man.dep_id = xdep order by man.id desc limit 1);
                                      end if;
                                    end if;
                                  insert into amb.md_ambulance_numbers (change_id,numb_id, value,dep_id)
                                                values (xchange,xnumid,xval,xdep);
                                END if;
                            -- возможно нужно сделать условие, что не просто состояние смены = 1, а <> 2
                            if exists(select id from amb.md_ambulance_change where clinic_id = xclin and COALESCE(department_id, 0) = COALESCE(xdep, 0) and ((from_data = cast(now() - cast('1 day' as interval) as date)) or (state = 1)) )
                              then
                                for yesterdaychange in select id from amb.md_ambulance_change where clinic_id = xclin and COALESCE(department_id, 0) = COALESCE(xdep, 0) and ((from_data <= cast(now() - cast('1 day' as interval) as date))and (state <> 2) or (state = 1))
                                    loop
                                        update amb.md_ambulance_change set state = 2 where id = yesterdaychange.id;
                                    end loop;
                              end if;
                            update amb.md_ambulance_change set state = 1 where id = xchange;

                            -- автозавершение работы всем бригадам в статусе свободна
                            execute  amb.team_job_close (
                                            array(select srtj.id
                                                from amb.sr_res_team_job srtj
                                                join amb.md_ambulance_change mac on mac.id = srtj.change_id
                                                join amb.sr_res_team srt on srt.id = srtj.team_id
                                                join sr_res_group srg on srg.id = srt.resource_id
                                                join pim_organization po on po.id = srg.org_id
                                                join pim_department pd on pd.id = srg.department_id
                                                where po.id=xclin
                                                and pd.id = xdep
                                                and srtj.edate is null
                                                and srtj.planned_edate <= now()
                                                and ((select srtjsh.job_status_id from amb.sr_res_team_job_status_history srtjsh where srtjsh.team_job_id = srtj.id order by srtjsh.date_time desc limit 1) not in (2,3,4,5) or
                                                (select srtjsh.job_status_id from amb.sr_res_team_job_status_history srtjsh where srtjsh.team_job_id = srtj.id order by srtjsh.date_time desc limit 1) is null)
                                                order by 1)
                                        ,xreg,xuser);

                            return cast(now() as date);
                          end;
$$;

