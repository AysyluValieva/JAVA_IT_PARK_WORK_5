CREATE FUNCTION fin_bill_spec_update(p1_bill_id integer)
  RETURNS void
STRICT
LANGUAGE plpgsql
AS $$
DECLARE 
    _r RECORD;
BEGIN
    /*
        version: 2015-02-12
    */
    FOR _r IN
        SELECT
            i.bill_id,
            count (DISTINCT s.patient_id) AS pat_cnt_total,
            count (DISTINCT s.case_id) AS case_cnt_total,
            sum (coalesce (nullif (r.quantity, 0), 1)) AS srv_cnt_total,
            sum (i.price) AS sum_total,
            count (DISTINCT CASE WHEN NOT s.spec_err_exists THEN s.patient_id ELSE NULL END) AS pat_cnt_correct,
            count (DISTINCT CASE WHEN NOT s.spec_err_exists THEN s.case_id ELSE NULL END) AS case_cnt_correct,
            sum (CASE WHEN NOT s.spec_err_exists THEN coalesce (nullif (r.quantity, 0), 1) ELSE 0 END) AS srv_cnt_correct,
            sum (CASE WHEN NOT s.spec_err_exists THEN i.price ELSE 0 END) AS sum_correct
        FROM
            fin_bill_spec_item   AS i
            JOIN fin_bill_steps  AS s ON s.spec_item_id = i.id AND s.bill_id = i.bill_id
            JOIN sr_srv_rendered AS r ON r.id = i.service_id
        WHERE
            i.bill_id = p1_bill_id AND NOT i.is_deleted
        GROUP BY 1
    LOOP
        IF
            (_r.pat_cnt_total, _r.case_cnt_total, _r.srv_cnt_total, _r.sum_total) 
            <> 
            (SELECT patient_count, number_of_cases, service_count, amount FROM fin_bill_spec WHERE bill_id = _r.bill_id AND NOT is_correct)
        THEN
            UPDATE fin_bill_spec
            SET 
                patient_count = _r.pat_cnt_total, number_of_cases = _r.case_cnt_total, service_count = _r.srv_cnt_total, amount = _r.sum_total
            WHERE
                bill_id = _r.bill_id AND NOT is_correct
            ;
        END IF;
        IF
            (_r.pat_cnt_correct, _r.case_cnt_correct, _r.srv_cnt_correct, _r.sum_correct) 
            <> 
            (SELECT patient_count, number_of_cases, service_count, amount FROM fin_bill_spec WHERE bill_id = _r.bill_id AND is_correct)
        THEN
            UPDATE fin_bill_spec
            SET 
                patient_count = _r.pat_cnt_correct, number_of_cases = _r.case_cnt_correct, service_count = _r.srv_cnt_correct, amount = _r.sum_correct
            WHERE
                bill_id = _r.bill_id AND is_correct
            ;
        END IF;
    END LOOP;
END;
$$;

