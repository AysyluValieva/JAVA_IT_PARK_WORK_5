CREATE FUNCTION fsym_on_i_for_pblc_pm_prty_mngrp()
  RETURNS trigger
LANGUAGE plpgsql
AS $fun$
begin                                                                                                                                                                  
                                   
                                  if 1=1 and "public".sym_triggers_disabled() = 0 then                                                                                                 
                                    insert into "public".sym_data                                                                                                                     
                                    (table_name, event_type, trigger_hist_id, row_data, channel_id, transaction_id, source_node_id, external_data, create_time)                                        
                                    values(                                                                                                                                                            
                                      'pim_party',                                                                                                                                            
                                      'I',                                                                                                                                                             
                                      45,                                                                                                                                             
                                      
          case when new."id" is null then '' else '"' || cast(cast(new."id" as numeric) as varchar) || '"' end||','||
          case when new."note" is null then '' else '"' || replace(replace(cast(new."note" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."version" is null then '' else '"' || to_char(new."version", 'YYYY-MM-DD HH24:MI:SS.US') || '"' end||','||
          case when new."type_id" is null then '' else '"' || cast(cast(new."type_id" as numeric) as varchar) || '"' end,                                                                                                                                                      
                                      'public_pim_party_default',                                                                                                                                                
                                      txid_current(),                                                                                                                                               
                                      "public".sym_node_disabled(),                                                                                                                   
                                      null,                                                                                                                                               
                                      CURRENT_TIMESTAMP                                                                                                                
                                    );                                                                                                                                                                 
                                  end if;                                                                                                                                                              
                                                                                                                                                                               
                                  return null;                                                                                                                                                         
                                end;
$fun$;

