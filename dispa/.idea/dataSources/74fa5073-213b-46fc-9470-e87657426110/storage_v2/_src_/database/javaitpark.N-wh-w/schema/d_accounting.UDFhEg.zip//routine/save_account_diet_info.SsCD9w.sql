CREATE FUNCTION save_account_diet_info(xid integer, xaccountid integer, xkeepsdiet integer, xdietschoolstudying integer, xlaststudyingdate date)
  RETURNS integer
LANGUAGE plpgsql
AS $$
DECLARE
  _id INTEGER;
BEGIN
  _id = xid;

  IF (_id IS NULL)
  THEN
    INSERT INTO d_accounting.account_diet_info (id,account_id, keeps_diet, diet_school_studying, last_studying_date)
    VALUES (nextval('d_accounting.account_diet_info_seq'),xaccountId, xkeepsDiet, xdietSchoolStudying, xlastStudyingDate)
    RETURNING id
      INTO _id;
  ELSE
    UPDATE d_accounting.account_diet_info
    SET keeps_diet       = xkeepsDiet, diet_school_studying = xdietSchoolStudying,
      last_studying_date = xlastStudyingDate
    WHERE id = _id;
  END IF;
  IF (xdietSchoolStudying <> 1)
  THEN
    UPDATE d_accounting.account_diet_info
    SET last_studying_date = NULL
    WHERE id = _id;
  END IF;

  RETURN _id;
END;
$$;

