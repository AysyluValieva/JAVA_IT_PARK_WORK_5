CREATE FUNCTION update_call_card(xcall integer, xis_psycho boolean, xcaller_reason_id integer, xreason_diag integer, xreason_note character varying, xcall_place_id integer, xcall_place_note character varying, xplace_org_id integer, xplace_department_id integer, xaddress_id integer, xhouse character varying, xhousing character varying, xapartment character varying, xporch character varying, xfloor character varying, xdoor_code character varying, xdescription character varying, xto_org_id integer, xto_department_id integer, xto_address_id integer, xto_house character varying, xto_housing character varying, xto_apartment character varying, xto_porch character varying, xto_description character varying, xpatient_id integer, xsurname character varying, xname character varying, xpatrname character varying, xbirthdt date, xgender integer, xage_years integer, xage_months integer, xage_days integer, xis_chronic boolean, xphone_caller character varying, xcaller_id integer, xcaller_note character varying, xemployee_id integer, xnote character varying, xreg integer, xexit_time time without time zone, xcoming_time time without time zone, xtransportation_time time without time zone, xtoclinic_time time without time zone, xtosubstation_time time without time zone, xdeath_time time without time zone, xout_delay_reason_id integer, xcall_reason_id integer, xreason_accident_id integer, xcondition_ns character varying, xcitizenship_type_id integer, xnsdatatime timestamp without time zone, xmilage numeric, xneed_exit_through integer, xactiv_visit_clinic_id integer, xother_recommendations character varying, xreceive_emp_id integer, xreceive_emp character varying, xreceive_brg integer, xtime_gone_id integer, xtransporting_type_id integer, xcasenote character varying, xdeathres character varying, xdeathdiag integer, xmasterdiag integer, xresult_id integer, xdeath_date date, xdeathemp integer, xoutdate date, xouttime time without time zone, xout integer, xaccompdiag integer, xmdisease_type integer, xaccompdisease_type integer, xtake_birth_id integer, xis_confirmed boolean)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
                    dt date;
                    ft timestamp without time zone;
                    xcase integer;
                    xcase_state integer;
                    xstep integer;
                    xvisit integer;
                    xrendered integer;
                    xgroup integer;
                    -- по временным полям
                    xexit_time_id integer;
                    xcoming_time_id integer;
                    xtransportation_time_id integer;
                    xtoclinic_time_id integer;
                    xtosubstation_time_id integer;
                    -- результат вызова
                    --xcall_reason_id integer;
                    --xreason_accident_id integer;
                    xhas_list boolean := false;
                    --диагнозы
                    xmasdiag integer := null;
                    xaccdiag integer := null;
                    xstage integer;
                    xaccompstage integer;
                    xmdiatype integer;
                    xaccompdiatype integer;
                    xdoctor integer;

                    xstate integer;

                    xrenderedsel record;

                    xstation_id integer;
                    xsubstation_id integer;

                    -- вид услуги
                    xservice integer;

                    xcallnote integer;
                    xconfirmed boolean;

                  begin
                        --выбираем данные для последующей обработки
                        select into dt, ft cast(from_time as date), from_time from amb.md_ambulance_call where id = xcall;
                        select into xcase, xrendered case_id, srv_rendered_id from amb.md_ambulance_call_result where id = xcall;
                        select into xstep id from mc_step where case_id = xcase;
                        select into xgroup res_group_id from sr_srv_rendered where id = xrendered;  -- не надо для случая, т.к. MC_CASE. emergency_team_code varchar(250) - не понятно, зачем вообще нужно

                        /* если будет одна функция и для БУМ
                        --xtransmit_time -- Передан бригаде
                        if not exist (select * from amb.md_ambcall_state_history mash
                                        left join amb.md_ambulance_call_state macs on macs.id = mash.state_id
                                            where macs.code = '4' and mash.call_id = xcall)
                            then
                                amb.add_ambcall_state_hist (xcall,xtransmit_time,5,2,xreg);
                        end if;
                        */

                        -- временные поля
                        --xexit_time  -- выезд с п/ст
                        IF xexit_time is not null
                        THEN
                            select into xexit_time_id mash.id from amb.md_ambcall_state_history mash
                                        left join amb.md_ambulance_call_state macs on macs.id = mash.state_id
                                            where macs.code = '6' and mash.call_id = xcall;
                            if xexit_time_id is null
                            then
                                --select
                                xstate := amb.add_ambcall_state_hist (xcall,cast(dt + xexit_time as timestamp),6,2,xreg);
                            else
                                update amb.md_ambcall_state_history set date_time = cast(dt + xexit_time as timestamp) where id = xexit_time_id;
                            end if;
                        END IF;
                        --xcoming_time -- прибытие на вызов
                        IF xcoming_time is not null
                        THEN
                            select into xcoming_time_id mash.id from amb.md_ambcall_state_history mash
                                        left join amb.md_ambulance_call_state macs on macs.id = mash.state_id
                                            where macs.code = '7' and mash.call_id = xcall;
                            if xcoming_time_id is null
                            then
                                --select
                                xstate := amb.add_ambcall_state_hist (xcall,cast(dt + xcoming_time as timestamp),7,2,xreg);
                            else
                                update amb.md_ambcall_state_history set date_time = cast(dt + xcoming_time as timestamp) where id = xcoming_time_id;
                            end if;
                        END IF;

                        --xtransportation_time  -- начало транспортировки
                        IF xtransportation_time is not null
                        THEN
                            select into xtransportation_time_id mash.id from amb.md_ambcall_state_history mash
                                        left join amb.md_ambulance_call_state macs on macs.id = mash.state_id
                                            where macs.code = '8' and mash.call_id = xcall;
                            if xtransportation_time_id is null
                            then
                                --select
                                xstate := amb.add_ambcall_state_hist (xcall,cast(dt + xtransportation_time as timestamp),8,2,xreg);
                            else
                                update amb.md_ambcall_state_history set date_time = cast(dt + xtransportation_time as timestamp) where id = xtransportation_time_id;
                            end if;
                        END IF;
                        --xtoclinic_time -- прибытие в МО
                        IF xtoclinic_time is not null
                        THEN
                            select into xtoclinic_time_id mash.id from amb.md_ambcall_state_history mash
                                        left join amb.md_ambulance_call_state macs on macs.id = mash.state_id
                                            where macs.code = '9' and mash.call_id = xcall;
                            if xtoclinic_time_id is null
                            then
                                --select
                                xstate := amb.add_ambcall_state_hist (xcall,cast(dt + xtoclinic_time as timestamp),9,2,xreg);
                            else
                                update amb.md_ambcall_state_history set date_time = cast(dt + xtoclinic_time as timestamp) where id = xtoclinic_time_id;
                            end if;
                        END IF;
                        --xdeath_time time --stamp without time zone -- констатация смерти ???

                        --xtosubstation_time time -- возвращение на п/ст
                        IF xtosubstation_time is not null
                        THEN
                            select into xtosubstation_time_id mash.id from amb.md_ambcall_state_history mash
                                        left join amb.md_ambulance_call_state macs on macs.id = mash.state_id
                                            where macs.code = '11' and mash.call_id = xcall;
                            if xtosubstation_time_id is null
                            then
                                --select
                                xstate := amb.add_ambcall_state_hist (xcall,cast(dt + xtosubstation_time as timestamp),11,2,xreg);
                            else
                                update amb.md_ambcall_state_history set date_time = cast(dt + xtosubstation_time as timestamp) where id = xtosubstation_time_id;
                            end if;
                        END IF;
                        /*
                        if xcaller_reason <> (select caller_reason_id from amb.md_ambulance_call where id = xcall)
                            then
                                select into xcall_reason_id,xreason_accident_id call_reason_id,reason_accident_id
                                    from amb.md_ambulance_caller_reason where id = xcaller_reason;
                        end if;
                        */
                        -- данные о вызове (кроме данных о пациенте)
                        update amb.md_ambulance_call set
                                    caller_reason_id = xcaller_reason_id,
                                    reason_diag = xreason_diag,
                                    reason_note = xreason_note,
                                    call_place_id = xcall_place_id,
                                    call_place_note = xcall_place_note,
                                    place_org_id = xplace_org_id,
                                    place_department_id = xplace_department_id,
                                    address_id  = xaddress_id,
                                    house = xhouse,
                                    housing = xhousing,
                                    apartment = xapartment,
                                    porch = xporch,
                                    floor = xfloor,
                                    door_code = xdoor_code,
                                    description = xdescription,
                                    to_org_id = xto_org_id,
                                    to_department_id = xto_department_id,
                                    to_address_id = xto_address_id,
                                    to_house = xto_house,
                                    to_housing = xto_housing,
                                    to_apartment = xto_apartment,
                                    to_porch = xto_porch,
                                    to_description = xto_description,
                                    --patient_id = xpatient_id,
                                    is_chronic = xis_chronic,
                                    age_years = xage_years,
                                    age_months = xage_months,
                                    age_days = xage_days,
                                    phone_caller = xphone_caller,
                                    caller_id = xcaller_id,
                                    caller_note = xcaller_note,
                                    employee_id = xemployee_id,
                                    note = xnote
                                    where id = xcall;

                        -- данные о пациенте
                        -- что делать с документами пациента, если он выбран не из базы, надо решить
                        if xpatient_id = (select patient_id from amb.md_ambulance_call where id = xcall)
                            then
                                update pim_individual set surname = xsurname, name = xname, patr_name = xpatrname, birth_dt = xbirthdt,gender_id = xgender where id = xpatient_id;
                            else
                                update amb.md_ambulance_call set patient_id = xpatient_id,age_years = xage_years,age_months = xage_months,age_days = xage_days where id = xcall;
                        end if;

                        -- Проверка на null, так как поле diagnosis_is_not_confirmed не должен быть пустым
                        if xis_confirmed is not null
                            then
                                xconfirmed = xis_confirmed;
                            else
                                xconfirmed = false;
                        end if;

                        -- записи в результат вызова информации по сопроводительному листу --xhas_list = ();-- по виду вызова и отметкам (д.б. госпитализация)

                        update amb.md_ambulance_call_result set
                --        			transmit_state_id = xtransmit_state_id,   -- если по БУМ будет этаже функция, то будет
                                    out_delay_reason_id = xout_delay_reason_id,
                                    call_reason_id = xcall_reason_id,
                                    reason_accident_id = xreason_accident_id,
                                    citizenship_type_id = xcitizenship_type_id,
                                    condition_ns = xcondition_ns,
                                    nsdatatime = xnsdatatime,
                                    milage = xmilage,
                                    need_exit_through = xneed_exit_through,
                                    activ_visit_clinic_id = xactiv_visit_clinic_id,
                                    other_recommendations = xother_recommendations,
                                    receive_emp_id = xreceive_emp_id,
                                    receive_emp = xreceive_emp ,
                                    --пока так, но посложнее надо
                --                    todo
                                    receive_brg = xreceive_brg,
                                    has_list = xhas_list,	--,registrator_id = xreg
                                    take_birth_id = xtake_birth_id,
                                    diagnosis_is_not_confirmed = xconfirmed
                                    where id = xcall;

                        -- записываем диагнозы
                        xstage = (select id from mc_stage where e_code = '4');
                        xaccompstage = (select id from mc_stage where e_code = '3');
                        xmdiatype = (select id from mc_diagnosis_type where e_code = '1');
                        xaccompdiatype = (select id from mc_diagnosis_type where e_code = '2');
                        xdoctor = (select pep.id
                            from pim_employee_position pep
                            join pim_employee_position_resource pepr on pepr.employee_position_id = pep.id
                            join sr_resource sr on sr.id = pepr.id
                            join sr_res_group_relationship srgrel on srgrel.resource_id = sr.id
                            join sr_res_group srg on srg.id = srgrel.group_id
                            where srg.id = xgroup and srgrel.role_id in (select id from sr_res_role where kind_id = 1));
                        /*
                        if exists (
                            select pep.id
                            from pim_employee_position pep
                            join pim_employee_position_resource pepr on pepr.employee_position_id = pep.id
                            join sr_resource sr on sr.id = pepr.id
                            join sr_res_group_relationship srgrel on srgrel.resource_id = sr.id
                            join sr_res_group srg on srg.id = srgrel.group_id
                            where srg.id = xgroup and srgrel.role_id = (select id from sr_res_role where code = 'DOCTOR')
                            )
                        then
                            xdoctor =(select pep.id
                            from pim_employee_position pep
                            join pim_employee_position_resource pepr on pepr.employee_position_id = pep.id
                            join sr_resource sr on sr.id = pepr.id
                            join sr_res_group_relationship srgrel on srgrel.resource_id = sr.id
                            join sr_res_group srg on srg.id = srgrel.group_id
                            where srg.id = xgroup and srgrel.role_id = (select id from sr_res_role where code = 'DOCTOR'));
                        else
                            xdoctor = (select pep.id
                            from pim_employee_position pep
                            join pim_employee_position_resource pepr on pepr.employee_position_id = pep.id
                            join sr_resource sr on sr.id = pepr.id
                            join sr_res_group_relationship srgrel on srgrel.resource_id = sr.id
                            join sr_res_group srg on srg.id = srgrel.group_id
                            where srg.id = xgroup and srgrel.role_id = (select id from sr_res_role where code = 'PARAMEDIC') limit 1);
                        end if;
                        */
                        -- обновление основного диагноза
                        if xmasterdiag is not null
                            then
                                if (select main_diagnos_id from mc_case where id = xcase) is not NULL
                                    then
                                        xmasdiag = (select main_diagnos_id from mc_case where id = xcase);
                                    else
                                        xmasdiag = (select id from mc_diagnosis where case_id = xcase and step_id = xstep and is_main = true);
                                end if;
                                if xmasdiag is null
                                    THEN
                                        xmasdiag = nextval('mc_diagnosis_seq');
                                        insert into public.mc_diagnosis(id,patient_id,case_id,step_id,is_main,stage_id,type_id,diagnos_id,disease_type_id,establishment_date,doctor_id)
                                            values (xmasdiag,xpatient_id,xcase,xstep,true,xstage,xmdiatype,xmasterdiag,xmdisease_type,dt,xdoctor);
                                    else
                                        update public.mc_diagnosis  set patient_id = xpatient_id, diagnos_id = xmasterdiag,disease_type_id = xmdisease_type  where id = xmasdiag;
                                        update md_srv_rendered set diagnosis_id = xmasterdiag where id = xrendered;
                                        update mc_step set main_diagnosis_id = xmasdiag  where id = xstep;
                                        update mc_case set main_diagnos_id = xmasdiag where id = xcase;

                                end if;
                            else
                                --записи в услуга (sr_srv_rendered)
                                update md_srv_rendered set diagnosis_id = null where id = xrendered;
                                update mc_step set main_diagnosis_id = null  where id = xstep;
                                update mc_case set main_diagnos_id = null where id = xcase;
                        end if;
                        -- сопутствующий
                        if xaccompdiag is not null
                            then
                                If exists (select * from mc_diagnosis where case_id = xcase and is_main = false)
                                    then
                                        xaccdiag = (select id from mc_diagnosis where case_id = xcase and is_main = false);
                                        update public.mc_diagnosis  set diagnos_id = xaccompdiag, disease_type_id = xaccompdisease_type where id = xaccdiag;
                                    else
                                        xaccdiag = nextval('mc_diagnosis_seq');
                                        insert into public.mc_diagnosis(id,patient_id,case_id,step_id,is_main,stage_id,type_id,diagnos_id,disease_type_id,establishment_date,doctor_id)
                                            values (xaccdiag,xpatient_id,xcase,xstep,false,xaccompstage,xaccompdiatype,xaccompdiag,xaccompdisease_type,dt,xdoctor);
                                end If;
                            else
                        end if;

                        --записи в случай (mc_case)
                        update sr_srv_rendered set customer_id = xpatient_id where id = xrendered;
                        for xrenderedsel in
                        select service_id from amb.md_ambulance_call_services where call_id = xcall
                            loop
                                update sr_srv_rendered set customer_id = xpatient_id where id = xrenderedsel.service_id;
                            end loop;
                            -- шаг
                            -- переписать под определение времени outcome_time в зависимости от результата вызова
                            update mc_step set main_diagnosis_id = xmasdiag
                                ,result_id = xresult_id
                                ,death_date = xdeath_date, death_time = xdeath_time, death_employee_id = xdeathemp
                                ,outcome_date = xoutdate,outcome_time = xouttime
                                ,outcome_id = xout, outcome_clinic_id = xto_org_id
                            where id = xstep;

                        -- дописано, таблица(mc_med_case_result) не нужна для снмп
                        xcase_state = (select id from mc_case_state where e_code = '1');
                        update mc_case set time_gone_id = xtime_gone_id,transporting_type_id = xtransporting_type_id
                            ,note = xcasenote,death_reason = xdeathres, death_reason_diagnosis_id = xdeathdiag
                            ,patient_id = xpatient_id
                        where id = xcase;

                        -- отметка госпитализации
                        -- IF ((xcall_kind_id in (3,4)) or (xto_org_id is not null))
                        IF ((select e_code from mc_step_result where id = xresult_id)= '403') and (xto_org_id is not null)
                            and not exists (select * from amb.md_ambulance_call_note where call_id = xcall and note_id = 21 and note_type = true and note_active = true)
                            THEN
                                xcallnote = amb.add_call_note(xcall,21,true,null,'а/у госпитализация',xreg,null);
                            ELSE
                                if (xto_org_id is null) and exists (select * from amb.md_ambulance_call_note where call_id = xcall and note_id = 21 and note_type = true and note_active = true)
                                    then
                                        xcallnote = amb.add_call_note(xcall,21,false,null,'а/у госпитализация',xreg,null);
                                    end if;
                        END IF;

                        /* вынесено отдельным действием в call.object.xml action = update
                        -- автодобавление отметок
                        select into xstation_id,xsubstation_id station_id, substation_id from amb.md_ambulance_call where id = xcall;
                        execute amb.auto_add_call_note_amb_card (xcall,xcaller_reason_id,xreason_diag,xreg,xstation_id,xsubstation_id,xmasterdiag,xis_psycho);
                        */

                        -- определение вида услуги
                        xservice := amb.set_service (xcall);

                    return xcall;
                  end;
$$;

