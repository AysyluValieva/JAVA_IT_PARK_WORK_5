CREATE FUNCTION get_rnd_id(p_tab name)
  RETURNS text
LANGUAGE plpgsql
AS $$
declare
v_pk_name pg_attribute.attname%type;
v_id text;
begin
select attname into v_pk_name from pg_attribute, pg_class, pg_constraint where attrelid = pg_class.oid and relname = lower(p_tab) and conrelid = attrelid and contype = 'p' and conkey[1] = attnum;
execute 'select '||v_pk_name||' from '||p_tab||' order by random() limit 1' into v_id;
return v_id;
end;
$$;

