CREATE FUNCTION update_cmn_measure(newobjectid integer)
  RETURNS text
LANGUAGE plpgsql
AS $$
declare
    measure record;
    cmnMeasureId integer;
    countOfUpd integer;
    countOfDel integer;
begin
countOfUpd=0;
countOfDel=0;

for measure in select measureId from
 (select id as measureId from cmn_measure where measure_object_id=2 and
           name in('~', 'в куб.мл.', 'г', 'доз', 'кубический дециметр', 'кубический метр',
                 'кубический сантиметр', 'литр', 'мг', '630','46','631','320','322','324','321','85','632')
 union
     select id as measureId from cmn_measure where measure_object_id=3 and
           name in('~', 'мг','мг-эквивалент', 'мл','633','113','329','114')
 union
     select id as measureId from cmn_measure where measure_object_id=5 and
           name in('%', 'x100 Лейк.', 'Ампула','Баллон', 'в мл', 'в п/зр', 'др', 'ед.усл.', 'комп', 'Коробка', 'мм рт.ст.', 'наб', 'пара','Пары', 'пг',
                    'пласт', 'порошок в упак.', 'суп', 'таб', 'табл.', 'Тыс.штук','уп.', 'уп')
 union
     select id as measureId from cmn_measure where measure_object_id=9 and
           name not in('JSK/мл','г/аппликация','г/л','г/мл','грамм/доза','доза/мл','единиц белкового азота/мл','единиц действия/г','единиц действия/доза',
                        'единиц действия/мг','единиц действия/мкл','единиц действия/мл','единиц/мл','Индекс реактивности/мл','калликреиновая ингибирующая единица действия/доза','калликреиновая ингибирующая единица действия/мл',
                        'мг/г','мг/доза','мг йода/мл','мг/мл','мг/сутки','мг/ч','международная единица действия активности ингибирования активированного фактора свертывания крови Х/мл','международная единица действия (анти-ХА)/мл',
                        'международная единица действия/г','международная единица действия/доза','международная единица действия/мл','миллиард клеток/доза','мкг/г','мкг/доза','мкг/мл',
                        'мкг/распыление','мкг/ч','мкмоль/мл','мл/доза','млн единиц действия/мл','млн международных единиц действия/г','млн международных единиц действия/мл','ммоль/л','ммоль/мл','ПЕ/мл','ТЕ/доза')
  )as measure1
 loop
   begin
     cmnMeasureId=measure.measureId;
     delete from cmn_measure where id=cmnMeasureId;
     countOfDel=countOfDel+1;
     
     exception  when foreign_key_violation then
     begin
         update cmn_measure set measure_object_id=newObjectId where id=cmnMeasureId;
         countOfUpd=countOfUpd+1;
     end;

   end;
 end loop;
 return  'updated: '||countOfUpd||', deleted: '||countOfDel;
end;
$$;

