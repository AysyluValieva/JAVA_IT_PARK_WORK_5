CREATE FUNCTION calc_cert_costs_by_period_decree1788(cert_id_i integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
  case_id_l         INTEGER;
  case_cost_l       NUMERIC(19, 2);
  cert_total_cost_l NUMERIC(19, 2) = 0;
  clinic_id_l       INTEGER;
  patient_id_l      INTEGER;
  period_begin_l    DATE;
  period_end_l      DATE;
  r_service_id_l    INTEGER;
  r_bdate_l         DATE;
  r_quantity        DECIMAL;
  service_id_l      INTEGER;
  service_name_l    VARCHAR(200);
  service_cost_l    NUMERIC(19, 2);
  _price_list       RECORD;
  _position_id      INTEGER;
BEGIN
  select clinic_id, patient_id, period_begin, period_end
  from billing.services_cost_certificate where id = cert_id_i
  into clinic_id_l, patient_id_l, period_begin_l, period_end_l;

  FOR r_service_id_l, service_name_l, case_id_l, service_id_l, r_bdate_l, r_quantity IN
    select ssr.id, s.name, msr.case_id, ssr.service_id, ssr.bdate, ssr.quantity
    from
      md_srv_rendered msr
      left join sr_srv_rendered ssr on ssr.id = msr.id
      left join sr_service s on s.id = ssr.service_id
      left join fin_funding_source_type fin on fin.id = ssr.funding_id
      left join mc_case c on c.id = msr.case_id
    where
      fin.code = 'OMS' and c.clinic_id = clinic_id_l and
      c.patient_id = patient_id_l and ssr.bdate between period_begin_l and period_end_l
  LOOP
    --подбор прайса
    _price_list := billing.fin_get_pricelist_by_case (case_id_l, r_bdate_l)
    ;
    _position_id := 
    (
        SELECT 
            p.id
        FROM    
            public.fin_pl_pos_to_clinic_srv AS i, public.fin_pl_position AS p
        WHERE
            i.clinic_service_id = service_id_l AND p.id = i.pl_position_id AND p.price_list_id = _price_list.id AND r_bdate_l <@ daterange (p.from_dt::DATE, p.to_dt::DATE, '[]')
        ORDER BY p.from_dt DESC NULLS LAST, p.to_dt DESC, p.id DESC
        LIMIT 1
    );
    -- вычисление стоимости конкретной услуги
    service_cost_l = 0
    ;
    INSERT INTO billing.cost_certificates_services (case_id, case_cost, cert_id, position_name, service_cost, service_id)
        SELECT
            case_id_l, case_cost_l, cert_id_i, service_name_l, r_quantity * t.tariff, r_service_id_l
        FROM
            billing.fin_get_tariff_from_pricelist (r_service_id_l, _position_id) AS t
    RETURNING service_cost INTO service_cost_l
    ;
    -- формирование итоговой суммы
    cert_total_cost_l = cert_total_cost_l + service_cost_l;
  END LOOP;
  update billing.services_cost_certificate set total_cost = cert_total_cost_l where id = cert_id_i;
END;
$$;

