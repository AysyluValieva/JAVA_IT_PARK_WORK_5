CREATE FUNCTION migration_table_log_write(table_id integer, level character varying, message character varying)
  RETURNS void
LANGUAGE plpgsql
AS $$
BEGIN
  INSERT INTO audit.migration_table_log(table_id, level, message) VALUES(table_id, level, substring(message, 0, 1000));
END;
$$;

