CREATE FUNCTION apda_get_patient_org_ids_active_on_date(individual_id integer, dt date)
  RETURNS integer[]
LANGUAGE plpgsql
AS $$
BEGIN
  RETURN (SELECT array_agg(j.organization_id)
          FROM pci_patient_job j
          WHERE j.patient_id = $1
                AND (dt >= j.from_dt OR j.from_dt ISNULL)
                AND (dt <= j.to_dt OR j.to_dt ISNULL));
END;
$$;

