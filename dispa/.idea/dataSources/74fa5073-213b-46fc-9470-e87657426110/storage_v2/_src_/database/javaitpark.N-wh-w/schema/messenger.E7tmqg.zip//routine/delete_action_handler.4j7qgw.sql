CREATE FUNCTION delete_action_handler(_id integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
                    _actionId integer;
                    _consumerId integer;
                    _messageId integer;
                begin
                    _actionId = (select ah.action_id from messenger.action_handler ah where ah.id = _id);
                    _consumerId = (select act.consumer_id from event_handler.action act where act.id = _actionId);
                    _messageId = (select ah.message_id from messenger.action_handler ah where ah.id = _id);
                    delete from messenger.action_handler where id = _id;
                    delete from event_handler.condition where consumer_id = _consumerId;
                    delete from event_handler.action where id = _actionId;
                    delete from event_handler.consumer where id = _consumerId;
                    if _messageId is not null then
                        delete from messenger.message m where m.id = _messageId;
                    end if;
                end;
$$;

