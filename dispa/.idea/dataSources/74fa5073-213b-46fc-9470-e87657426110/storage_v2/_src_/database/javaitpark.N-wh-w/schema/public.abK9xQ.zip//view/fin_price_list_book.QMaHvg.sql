CREATE VIEW fin_price_list_book AS
  SELECT row_number() OVER () AS id,
    a.id AS position_id,
    sr_service.id AS service_id,
    a.price_modifier_id,
    COALESCE(sr_service.org_id, fin_price_list.clinic_id) AS organization_id
   FROM (((fin_pl_pos_to_clinic_srv
     FULL JOIN ( SELECT fin_pl_position.id,
            fin_modifier_to_pl_pos.price_modifier_id,
            fin_pl_position.price_list_id
           FROM (fin_pl_position
             LEFT JOIN fin_modifier_to_pl_pos ON ((fin_modifier_to_pl_pos.pl_position_id = fin_pl_position.id)))
          WHERE (fin_modifier_to_pl_pos.price_modifier_id IS NOT NULL)
        UNION
         SELECT fin_pl_position.id,
            b.id,
            fin_pl_position.price_list_id
           FROM (fin_pl_position
             LEFT JOIN ( SELECT fin_price_modifier.price_list_id,
                    fin_price_modifier.id
                   FROM fin_price_modifier
                  WHERE (fin_price_modifier.scope_id = 1)) b ON ((fin_pl_position.price_list_id = b.price_list_id)))) a ON ((fin_pl_pos_to_clinic_srv.pl_position_id = a.id)))
     FULL JOIN sr_service ON ((fin_pl_pos_to_clinic_srv.clinic_service_id = sr_service.id)))
     LEFT JOIN fin_price_list ON ((fin_price_list.id = a.price_list_id)));

