CREATE FUNCTION apda_check_district_by_address_criterion(info apda_patient_address_info, reg_dt date, district_id integer)
  RETURNS boolean
LANGUAGE plpgsql
AS $$
DECLARE
  i RECORD;
BEGIN
  IF (SELECT exists(SELECT 1
                    FROM md_district_address da
                    WHERE da.district_id = $3
                          AND ($2 >= da.from_dt OR da.from_dt ISNULL)
                          AND ($2 <= da.to_dt OR da.to_dt ISNULL)
                          AND da.address_id = ANY ((($1).ids) :: INTEGER [])
                          AND (da.building_pattern ISNULL OR da.building_pattern = '')
                    LIMIT 1))
  THEN RETURN TRUE;
  END IF;

  IF ($1).house_name ISNULL OR ($1).house_name = ''
  THEN RETURN FALSE; END IF;

  --если адрессный эдемент типа квартира или дом - поднимаем до улицы, и анализируем паттерн по ней
  FOR i IN (
    SELECT da.building_pattern
    FROM md_district_address da
      JOIN address_element ae ON ae.id = da.address_id
      CROSS JOIN LATERAL ( WITH RECURSIVE cte AS (
        SELECT *
        FROM address_element
        WHERE id = ae.id
        UNION
        SELECT ae.*
        FROM address_element ae
          JOIN cte ON cte.parent_id = ae.id AND ae.level_id >= 6
      )
      SELECT
        cte.id,
        cte.level_id
      FROM cte) h
    WHERE h.level_id = 6
          AND da.district_id = $3
          AND da.building_pattern NOTNULL
          AND da.building_pattern != ''
          AND ($2 >= da.from_dt OR da.from_dt ISNULL)
          AND ($2 <= da.to_dt OR da.to_dt ISNULL)
          AND h.id = ($1).street_address_id
  )
  LOOP
    IF apda_check_address_by_building_pattern(($1).house_name, ($1).flat_name, i.building_pattern)
    THEN RETURN TRUE;
    END IF;
  END LOOP;

  RETURN FALSE;
END;
$$;

