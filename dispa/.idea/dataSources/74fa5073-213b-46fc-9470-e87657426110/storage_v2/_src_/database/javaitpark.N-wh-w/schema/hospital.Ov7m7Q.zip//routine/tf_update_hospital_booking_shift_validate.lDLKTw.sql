CREATE FUNCTION tf_update_hospital_booking_shift_validate()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE
                    new_count_shift_free INT;
                    is_validate boolean;
                    bed_count_shift INT;
                    bed_name CHARACTER VARYING;
                    text_exc CHARACTER VARYING;
                BEGIN
                    -- определим количество свободных смен после текущего добавления/изменения брони
                    with param (_dt, _booking_id, _booking_shift_id, _new_count_shift) as
                        (values(    NEW.dt::date,
                                    NEW.booking_id,
                                    NEW.id,
                                    NEW.count_shift
                                )
                        )
                    select  sr.power - coalesce(param._new_count_shift, 0) - coalesce(bs2.count_shift_busy, 0)  as new_count_shift_free,
                            case --when coalesce(sr.power, 0) < 1 then true -- если меньше 1, то работаем в режиме очередности броней по времени, ограничения нет (возможно -1, 0, null)
                                 when bs.code = '4' then true -- свободные смены не считаем
                                 when sr.power - coalesce(param._new_count_shift, 0) - coalesce(bs2.count_shift_busy, 0) >= 0 then true -- работаем с ограничением по сменам
                                 else false
                            end as is_validate,
                            coalesce(('Койка №' || nullif(regexp_replace(mb.number, '\s+$', ''), '')),'койка без названия') AS bed_name,
                            sr.power
                            into new_count_shift_free, is_validate, bed_name, bed_count_shift
                    from    param
                            join hospital.booking b on true
                            join md_bed mb on mb.id = b.bed_id
                            join lateral (select mbr.id from md_bed_resource mbr where mbr.bed_id = b.bed_id limit 1)mbr on true 
                            join sr_resource sr on sr.id = mbr.id 
                            join hospital.booking_status bs on bs.id = b.status_id
                            left join lateral (
                                select sum(bs2.count_shift) as count_shift_busy
                                from hospital.booking b2
                                     join hospital.booking_shift bs2 on bs2.booking_id = b2.id and bs2.dt = param._dt
                                     join hospital.booking_status bss2 on bss2.id = b2.status_id
                                where b2.bed_id = b.bed_id and param._dt between b2.begin_dt and b2.end_dt
                                      and bs2.id <> _booking_shift_id
                                      and coalesce(b2.iscurrent, TRUE) = TRUE
                                      and bss2.code <> '4'
                                      ) bs2 on true
                            --left join lateral (select sum(count_shift) as count_busy from hospital.booking_shift bs where bs.booking_id = b.id and bs.dt = d.dt limit 1) bs on true
                    where   b.id = param._booking_id
                            and param._dt between b.begin_dt and b.end_dt
                            and sr.power > 0;
                    IF (NOT is_validate) THEN
                        text_exc = format ('Для койки %L превышен лимит свободных смен на дату %L
Количество смен в настройке койки = %s,
Превышение лимита смен на %s.', bed_name, new.dt::date, bed_count_shift, -new_count_shift_free);
                        RAISE EXCEPTION '%', text_exc;
                    END IF;
                    RETURN NEW;
                END;
$$;

