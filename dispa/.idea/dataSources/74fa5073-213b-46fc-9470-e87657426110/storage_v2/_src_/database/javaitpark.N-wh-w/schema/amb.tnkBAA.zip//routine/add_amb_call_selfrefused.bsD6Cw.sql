CREATE FUNCTION add_amb_call_selfrefused(xcall integer, xtype boolean, xreason integer, xdescr character varying, xreg integer, xcaller integer, xemp integer, xsurname character varying, xcomm character varying)
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
    xcnote integer;
    xnote INTEGER := 10;
  begin
	xcnote = amb.add_call_note (xcall,xnote,xtype,xreason,xdescr,xreg,null);
    if xtype THEN
        insert into amb.md_ambulance_call_selfrefused (id,call_note_id,caller_id,employee_id,caller_surname,comment)
    		values (nextval('amb.md_ambulance_call_selfrefused_id_seq'),xcnote,xcaller,xemp,xsurname,xcomm);
        update amb.md_ambulance_call set to_time = now() where id = xcall;
        	 ELSE
             	update amb.md_ambulance_call set to_time = null where id = xcall;
    end if;
  end;
$$;

