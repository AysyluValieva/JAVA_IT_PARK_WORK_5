CREATE FUNCTION collect_venabc_data(p_user_id integer, p_begin_date date, p_end_date date, p_org_ids character varying, p_store_type_id integer, p_store_ids character varying, p_commodity_group_ids character varying, p_pharm_group_ids character varying, p_store_opr_type_id integer, p_is_ven_analysis boolean DEFAULT true, p_is_by_tn_cost boolean DEFAULT true)
  RETURNS numeric
LANGUAGE plpgsql
AS $$
DECLARE
  v_rec RECORD;
  v_rec_next RECORD;
  v_accum_sum NUMERIC; -- аккумулированная сумма
  v_inn_group_size INTEGER; -- размер группы МНН
  v_inn_group_sum_price NUMERIC; -- суммированная цена группы МНН
  v_inn_group_sum_quantity NUMERIC; -- суммированная количество группы МНН
  v_inn_group_sum_summa NUMERIC; -- суммированная сумма группы МНН
  v_inn_group_common_pharm_group_id INTEGER; -- общий родитель в фармакологической группе
  v_inn_id INTEGER;
  v_tn_id INTEGER;
  v_comm_group_id INTEGER;
  v_pharm_group_id INTEGER;
  v_pharm_group_id_next INTEGER;
  v_is_first_row BOOLEAN := TRUE;
  v_not_found BOOLEAN := FALSE;
  v_found BOOLEAN := FALSE;
  v_current_pharm_group_id_1 INTEGER;
  v_current_pharm_group_id_2 INTEGER;

  v_v_count_in_inn_group INTEGER; -- количество V в группе МНН
  v_e_count_in_inn_group INTEGER; -- количество E в группе МНН
  v_n_count_in_inn_group INTEGER; -- количество N в группе МНН
  v_ven_code varchar(1);
  v_counter INTEGER := 1;
    curs_by_inn_cost CURSOR FOR
    SELECT
      inn.name_rus               AS inn_name,
      inn.id                     AS inn_id,
      modif.name                 AS tn_name,
      modif.id                   AS tn_id,
      comm_group.name            AS comm_group_name,
      comm_group.id              AS comm_group_id,
      pharm_group.name           AS pharm_group_name,
      pharm_group.id             AS pharm_group_id,
      arriv_spec.price_vat       AS price,
      holding.ven                AS ven,
      holding.is_vital           AS vn,
      sum(arriv_spec.quantity)   AS quantity,
      sum(arriv_spec.amount_vat) AS summ
    FROM inventory.store_opr_jur AS store_jour
      -- Документ
      LEFT JOIN inventory.document AS doc ON store_jour.doc_id = doc.id
      LEFT JOIN inventory.document_type doctype ON doctype.id = doc.int_doc_type_id
      -- Документ(приход)
      INNER JOIN inventory.arrival_invoice AS arriv_inv ON doc.id = arriv_inv.id
      LEFT JOIN inventory.arrival_spec AS arriv_spec ON arriv_spec.doc_id = arriv_inv.id
      -- Складские операции
      JOIN inventory.store_opr AS store_opr ON store_jour.store_opr_id = store_opr.id
      -- Тип складской операции
      LEFT JOIN inventory.store_opr_type AS store_opr_type ON store_opr.opr_type_id = store_opr_type.id
      --МН
      LEFT JOIN inventory.hold_modif AS modif ON arriv_spec.hold_modif_id = modif.id
      LEFT JOIN inventory.holding AS holding ON holding.id = modif.holding_id
      LEFT JOIN inventory.store AS store ON store.id = store_jour.store_rec_id
      --Товарная группа
      LEFT JOIN inventory.commodity_group AS comm_group ON comm_group.id = holding.commodity_group_id
      --Фармакологическая группа
      LEFT JOIN inventory.holding_pharm_group AS hold2pharmgroup ON hold2pharmgroup.holding_id = holding.id
      LEFT JOIN inventory.pharm_group AS pharm_group ON pharm_group.id = hold2pharmgroup.pharm_group_id
      LEFT JOIN inventory.inn AS inn ON inn.id = holding.inn_id
    WHERE --filters
      (p_is_ven_analysis = false
        or (p_is_ven_analysis = true and holding.ven is not NULL))
      --Период
      AND (store_jour.date BETWEEN p_begin_date AND p_end_date)
      --МО (в принципе фильтруется скаладом)
      --AND store_jour.org_id in (490) --
      --Тип склада (хотя это лишнее)
      --AND store.store_type_id IN (1)
      --Склад
      AND store.id = ANY(string_to_array(p_store_ids, ',')::int[])
      AND comm_group.id = ANY(string_to_array(p_commodity_group_ids, ',')::int[])
      AND (pharm_group.id = ANY(string_to_array(p_pharm_group_ids, ',')::int[]) OR coalesce(p_pharm_group_ids, '') = '')
      --Тип складской операции
      AND store_opr_type.id = 1
    GROUP BY 1,2,3,4,5,6,7,8,9,10,11 ORDER BY inn_id DESC;

BEGIN
  -- удаляем перед каждым расчетом расчитанные данные пользователя
  delete from inventory.analysis_drug where user_id = $1;

  v_accum_sum := 0;

  if p_is_by_tn_cost then
    FOR v_rec IN
      /*************************/
    SELECT
      inn.name_rus               AS inn_name,
      inn.id                     AS inn_id,
      modif.name                 AS tn_name,
      modif.id                   AS tn_id,
      comm_group.name            AS comm_group_name,
      comm_group.id              AS comm_group_id,
      pharm_group.name           AS pharm_group_name,
      pharm_group.id             AS pharm_group_id,
      arriv_spec.price_vat       AS price,
      holding.ven                AS ven,
      holding.is_vital           AS vn,
      sum(arriv_spec.quantity)   AS quantity,
      sum(arriv_spec.amount_vat) AS summ
    FROM inventory.store_opr_jur AS store_jour
      -- Документ
      LEFT JOIN inventory.document AS doc ON store_jour.doc_id = doc.id
      LEFT JOIN inventory.document_type doctype ON doctype.id = doc.int_doc_type_id
      -- Документ(приход)
      INNER JOIN inventory.arrival_invoice AS arriv_inv ON doc.id = arriv_inv.id
      LEFT JOIN inventory.arrival_spec AS arriv_spec ON arriv_spec.doc_id = arriv_inv.id
      -- Складские операции
      JOIN inventory.store_opr AS store_opr ON store_jour.store_opr_id = store_opr.id
      -- Тип складской операции
      LEFT JOIN inventory.store_opr_type AS store_opr_type ON store_opr.opr_type_id = store_opr_type.id
      --МН
      LEFT JOIN inventory.hold_modif AS modif ON arriv_spec.hold_modif_id = modif.id
      LEFT JOIN inventory.holding AS holding ON holding.id = modif.holding_id
      LEFT JOIN inventory.store AS store ON store.id = store_jour.store_rec_id
      --Товарная группа
      LEFT JOIN inventory.commodity_group AS comm_group ON comm_group.id = holding.commodity_group_id
      --Фармакологическая группа
      LEFT JOIN inventory.holding_pharm_group AS hold2pharmgroup ON hold2pharmgroup.holding_id = holding.id
      LEFT JOIN inventory.pharm_group AS pharm_group ON pharm_group.id = hold2pharmgroup.pharm_group_id
      LEFT JOIN inventory.inn AS inn ON inn.id = holding.inn_id
    WHERE --filters
      (p_is_ven_analysis = false
        or (p_is_ven_analysis = true and holding.ven is not NULL))
      --Период
      AND (store_jour.date BETWEEN p_begin_date AND p_end_date)
      --МО (в принципе фильтруется скаладом)
      --AND store_jour.org_id in (490) --
      --Тип склада (хотя это лишнее)
      --AND store.store_type_id IN (1)
      --Склад
      AND store.id = ANY(string_to_array(p_store_ids, ',')::int[])
      AND comm_group.id = ANY(string_to_array(p_commodity_group_ids, ',')::int[])
      AND (pharm_group.id = ANY(string_to_array(p_pharm_group_ids, ',')::int[]) OR coalesce(p_pharm_group_ids, '') = '')
      --Тип складской операции
      AND store_opr_type.id = p_store_opr_type_id
    GROUP BY 1,2,3,4,5,6,7,8,9,10,11 ORDER BY summ DESC --string_to_array(p_commodity_group_ids, ',')
      /*************************/
    LOOP
      v_accum_sum := v_accum_sum + v_rec.summ;

      IF (p_is_ven_analysis = true) THEN
        IF v_rec.ven = 1 THEN
          v_ven_code := 'V';
        ELSEIF v_rec.ven = 2 THEN
          v_ven_code := 'E';
        ELSE
          v_ven_code := 'N';
        END IF;
      ELSE
        IF v_rec.vn = true THEN
          v_ven_code := 'V';
        ELSE
          v_ven_code := 'N';
        END IF;
      END IF;

      INSERT INTO inventory.analysis_drug(id, pp, user_id, inn_id, tn_id, commodity_group_id,
                                          pharm_group_id, quantity, price, summa, ven_code, accum_sum)
      VALUES
        (nextval('inventory.analysis_drug_seq'), v_counter, $1, v_rec.inn_id, v_rec.tn_id, v_rec.comm_group_id,
                                                 v_rec.pharm_group_id, v_rec.quantity, v_rec.price, v_rec.summ, v_ven_code, v_accum_sum);
      v_counter := v_counter + 1;
    END LOOP;
  ELSE
    OPEN curs_by_inn_cost;

    LOOP
      IF v_is_first_row THEN
        FETCH curs_by_inn_cost INTO v_rec;
        v_is_first_row  := FALSE;
      END IF;

      IF NOT found OR v_not_found THEN
        EXIT;
      END IF;

      v_inn_group_size := 1;
      v_v_count_in_inn_group := 0;
      v_e_count_in_inn_group := 0;
      v_n_count_in_inn_group := 0;
      v_inn_group_sum_price := v_rec.price;
      v_inn_group_sum_quantity := v_rec.quantity;
      v_inn_group_sum_summa := v_rec.summ;
      v_inn_id := v_rec.inn_id;
      v_tn_id := v_rec.tn_id;
      v_comm_group_id := v_rec.comm_group_id;
      v_pharm_group_id := v_rec.pharm_group_id;
      v_inn_group_common_pharm_group_id := v_pharm_group_id;

      IF (p_is_ven_analysis = true) THEN
        IF v_rec.ven = 1 THEN
          v_v_count_in_inn_group := 1;
        ELSEIF v_rec.ven = 2 THEN
          v_e_count_in_inn_group := 1;
        ELSE
          v_n_count_in_inn_group := 1;
        END IF;
      ELSE
        IF v_rec.vn = true THEN
          v_v_count_in_inn_group := 1;
        ELSE
          v_n_count_in_inn_group := 1;
        END IF;
      END IF;

      LOOP
        FETCH curs_by_inn_cost INTO v_rec_next;
        IF NOT found THEN
          v_not_found := TRUE;
          EXIT;
        END IF;
        IF v_rec.inn_id = v_rec_next.inn_id AND v_rec.inn_id IS NOT NULL AND v_rec_next.inn_id IS NOT NULL THEN
          -- нашли строку принадлежащей одной группе МНН
          v_inn_group_size := v_inn_group_size + 1;
          IF (p_is_ven_analysis = true) THEN
            IF v_rec_next.ven = 1 THEN
              v_v_count_in_inn_group := v_v_count_in_inn_group + 1;
            ELSEIF v_rec_next.ven = 2 THEN
              v_e_count_in_inn_group := v_e_count_in_inn_group + 1;
            ELSE
              v_n_count_in_inn_group := v_n_count_in_inn_group + 1;
            END IF;
          ELSE
            IF v_rec_next.vn = true THEN
              v_v_count_in_inn_group := v_v_count_in_inn_group + 1;
            ELSE
              v_n_count_in_inn_group := v_n_count_in_inn_group + 1;
            END IF;
          END IF;
          v_inn_group_sum_price := v_inn_group_sum_price + v_rec_next.price;
          v_inn_group_sum_quantity := v_inn_group_sum_quantity + v_rec_next.quantity;
          v_inn_group_sum_summa := v_inn_group_sum_summa + v_rec_next.summ;

          IF v_inn_group_common_pharm_group_id != v_rec_next.pharm_group_id THEN
            v_current_pharm_group_id_1 := v_inn_group_common_pharm_group_id;
            LOOP
              v_current_pharm_group_id_2 := v_rec_next.pharm_group_id;
              LOOP
                BEGIN
                  SELECT parent_id INTO v_current_pharm_group_id_2 FROM inventory.pharm_group WHERE id = v_current_pharm_group_id_2;
                  IF v_current_pharm_group_id_1 = v_current_pharm_group_id_2 THEN
                    v_inn_group_common_pharm_group_id := v_current_1;
                    v_found := TRUE;
                    EXIT;
                  END IF;
                  EXCEPTION
                  WHEN others THEN
                    v_found := TRUE;
                    EXIT;
                END;
              END LOOP;
              IF v_found THEN
                EXIT;
              END IF;
              BEGIN
                SELECT parent_id INTO v_current_pharm_group_id_1 FROM inventory.pharm_group WHERE id = v_current_pharm_group_id_1;
                EXCEPTION
                WHEN others THEN
                  EXIT;
              END;
            END LOOP;
          END IF;
        ELSE
          -- строка принадлжит другой группе
          v_rec := v_rec_next;
          EXIT;
        END IF;

      END LOOP;

      IF v_v_count_in_inn_group >= v_e_count_in_inn_group AND v_v_count_in_inn_group >= v_n_count_in_inn_group THEN
        v_ven_code := 'V';
      ELSEIF v_e_count_in_inn_group >= v_v_count_in_inn_group AND v_e_count_in_inn_group >= v_n_count_in_inn_group THEN
        v_ven_code := 'E';
      ELSE
        v_ven_code := 'N';
      END IF;

      -- v_accum_sum := v_accum_sum + v_rec.summ;

      INSERT INTO inventory.analysis_drug(id, pp, user_id, inn_id, tn_id, commodity_group_id,
                                          pharm_group_id, quantity, price, summa, ven_code, accum_sum)
      VALUES
        (nextval('inventory.analysis_drug_seq'), v_counter, $1, v_inn_id, null, v_comm_group_id,
                                                 v_inn_group_common_pharm_group_id, v_inn_group_sum_quantity / v_inn_group_size, v_inn_group_sum_price / v_inn_group_size, v_inn_group_sum_summa, v_ven_code, 0);
    END LOOP;
    -- подчитаем аккумулированную сумму и заодно отфильтруем
    v_counter := 1;
    v_accum_sum := 0;
    FOR v_rec IN SELECT * FROM inventory.analysis_drug WHERE user_id = $1 ORDER BY summa DESC LOOP
      v_accum_sum := v_accum_sum + v_rec.summa;
      UPDATE inventory.analysis_drug SET accum_sum = v_accum_sum, pp = v_counter WHERE id = v_rec.id;
      v_counter := v_counter + 1;
    END LOOP;

  END IF;

  RETURN v_accum_sum;
END;
$$;

