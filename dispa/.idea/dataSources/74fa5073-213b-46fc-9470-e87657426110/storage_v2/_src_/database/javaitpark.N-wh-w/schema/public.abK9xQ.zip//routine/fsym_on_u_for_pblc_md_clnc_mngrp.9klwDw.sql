CREATE FUNCTION fsym_on_u_for_pblc_md_clnc_mngrp()
  RETURNS trigger
LANGUAGE plpgsql
AS $fun$
declare var_row_data text; 
                                declare var_old_data text; 
                                begin
                                   
                                  if 1=1 and "public".sym_triggers_disabled() = 0 then                                                                                                 
                                    var_row_data := 
          case when new."id" is null then '' else '"' || cast(cast(new."id" as numeric) as varchar) || '"' end||','||
          case when new."code" is null then '' else '"' || replace(replace(cast(new."code" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."note" is null then '' else '"' || replace(replace(cast(new."note" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."nomenclature_type_id" is null then '' else '"' || cast(cast(new."nomenclature_type_id" as numeric) as varchar) || '"' end||','||
          case when new."scope_id" is null then '' else '"' || cast(cast(new."scope_id" as numeric) as varchar) || '"' end||','||
          case when new."subordination_category_id" is null then '' else '"' || cast(cast(new."subordination_category_id" as numeric) as varchar) || '"' end||','||
          case when new."is_in_ads" is null then '' when new."is_in_ads" then '"1"' else '"0"' end||','||
          case when new."location_id" is null then '' else '"' || cast(cast(new."location_id" as numeric) as varchar) || '"' end||','||
          case when new."level_id" is null then '' else '"' || cast(cast(new."level_id" as numeric) as varchar) || '"' end||','||
          case when new."departmental_attachment_id" is null then '' else '"' || cast(cast(new."departmental_attachment_id" as numeric) as varchar) || '"' end||','||
          case when new."e_code" is null then '' else '"' || replace(replace(cast(new."e_code" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."from_dt" is null then '' else '"' || to_char(new."from_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when new."to_dt" is null then '' else '"' || to_char(new."to_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when new."full_name" is null then '' else '"' || replace(replace(cast(new."full_name" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."short_name" is null then '' else '"' || replace(replace(cast(new."short_name" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."reg_dt" is null then '' else '"' || to_char(new."reg_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when new."parent_id" is null then '' else '"' || cast(cast(new."parent_id" as numeric) as varchar) || '"' end||','||
          case when new."use_of_standard_of_care" is null then '' when new."use_of_standard_of_care" then '"1"' else '"0"' end||','||
          case when new."close_dt" is null then '' else '"' || to_char(new."close_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when new."priv_rec_for_unreg_pat" is null then '' when new."priv_rec_for_unreg_pat" then '"1"' else '"0"' end||','||
          case when new."territory_id" is null then '' else '"' || cast(cast(new."territory_id" as numeric) as varchar) || '"' end; 
                                    var_old_data := 
          case when old."id" is null then '' else '"' || cast(cast(old."id" as numeric) as varchar) || '"' end||','||
          case when old."code" is null then '' else '"' || replace(replace(cast(old."code" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when old."note" is null then '' else '"' || replace(replace(cast(old."note" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when old."nomenclature_type_id" is null then '' else '"' || cast(cast(old."nomenclature_type_id" as numeric) as varchar) || '"' end||','||
          case when old."scope_id" is null then '' else '"' || cast(cast(old."scope_id" as numeric) as varchar) || '"' end||','||
          case when old."subordination_category_id" is null then '' else '"' || cast(cast(old."subordination_category_id" as numeric) as varchar) || '"' end||','||
          case when old."is_in_ads" is null then '' when old."is_in_ads" then '"1"' else '"0"' end||','||
          case when old."location_id" is null then '' else '"' || cast(cast(old."location_id" as numeric) as varchar) || '"' end||','||
          case when old."level_id" is null then '' else '"' || cast(cast(old."level_id" as numeric) as varchar) || '"' end||','||
          case when old."departmental_attachment_id" is null then '' else '"' || cast(cast(old."departmental_attachment_id" as numeric) as varchar) || '"' end||','||
          case when old."e_code" is null then '' else '"' || replace(replace(cast(old."e_code" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when old."from_dt" is null then '' else '"' || to_char(old."from_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when old."to_dt" is null then '' else '"' || to_char(old."to_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when old."full_name" is null then '' else '"' || replace(replace(cast(old."full_name" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when old."short_name" is null then '' else '"' || replace(replace(cast(old."short_name" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when old."reg_dt" is null then '' else '"' || to_char(old."reg_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when old."parent_id" is null then '' else '"' || cast(cast(old."parent_id" as numeric) as varchar) || '"' end||','||
          case when old."use_of_standard_of_care" is null then '' when old."use_of_standard_of_care" then '"1"' else '"0"' end||','||
          case when old."close_dt" is null then '' else '"' || to_char(old."close_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when old."priv_rec_for_unreg_pat" is null then '' when old."priv_rec_for_unreg_pat" then '"1"' else '"0"' end||','||
          case when old."territory_id" is null then '' else '"' || cast(cast(old."territory_id" as numeric) as varchar) || '"' end; 
                                    if var_old_data is null or var_row_data != var_old_data then 
                                    insert into "public".sym_data                                                                                                                     
                                    (table_name, event_type, trigger_hist_id, pk_data, row_data, old_data, channel_id, transaction_id, source_node_id, external_data, create_time)                     
                                    values(                                                                                                                                                            
                                      'md_clinic',                                                                                                                                            
                                      'U',                                                                                                                                                             
                                      18284,                                                                                                                                             
                                      
          case when old."id" is null then '' else '"' || cast(cast(old."id" as numeric) as varchar) || '"' end,                                                                                                                                                      
                                      var_row_data,                                                                                                                                                      
                                      var_old_data,                                                                                                                                                   
                                      'public_md_clinic_default',                                                                                                                                                
                                      txid_current(),                                                                                                                                               
                                      "public".sym_node_disabled(),                                                                                                                   
                                      null,                                                                                                                                               
                                      CURRENT_TIMESTAMP                                                                                                                
                                    );                                                                                                                                                                 
                                  end if;                                                                                                                                                              
                                  end if;                                                                                                                                                              
                                                                                                                                                                               
                                  return null;                                                                                                                                                         
                                end;
$fun$;

