CREATE FUNCTION full_addr(INOUT id integer, OUT _cntry character varying, OUT _state character varying, OUT _rayon character varying, OUT _town character varying, OUT _np character varying, OUT _street character varying, OUT _dom character varying, OUT _kor character varying, OUT _kv character varying, OUT _mr character varying)
  RETURNS record
LANGUAGE plpgsql
AS $$
DECLARE _par_id INTEGER;
                    _full_name VARCHAR(500) = '';
                    _addr_name VARCHAR(255);
                    _lvl INTEGER;
                    _type INTEGER;
                    _rec RECORD;
            BEGIN
            _par_id = $1;
            WHILE 1=1
            LOOP
             SELECT adr.parent_id,
                    adr."name",
                    adr.level_id,
                    adr.type_id
                  INTO _par_id,_addr_name, _lvl, _type
                   FROM address_element adr
                    WHERE adr.id  = _par_id;
               _full_name = COALESCE(trim(_addr_name),'') || ', ' || _full_name;

               /*

            level 1- страна
            level 2-
            type_id    name
                5    Автономная область
                6    Автономный округ
                18    Город
                43    Край
                53    Область
                82    Республика
                106    Чувашия (прямо так в базе)
            level 3-
            type_id    name
            81    Район
            102    Улус

            level 4-
            type_id    name
            18    Город
            20    Дачный поселок
            47    Массив
            65    Поселок
            66    Поселок городского типа
            69    Почтовое отделение
            79    Рабочий поселок
            87    Сельская администрация
            88    Сельский округ
            89    Сельское муниципальное образо
            90    Сельское поселение
            91    Сельсовет
            98    Территория


            level 5-
            type_id    name
            2    Аал
            4    Автодорога
            8    Арбан
            9    Аул
            16    Выселки(ок)
            18    Город
            19    Городок
            20    Дачный поселок
            21    Деревня
            24    Железнодорожная будка
            25    Железнодорожная казарма
            26    Железнодорожная платформа
            27    Железнодорожная станция
            28    Железнодорожный пост
            29    Железнодорожный разъезд
            31    Жилая зона
            32    Жилой район
            34    Заимка
            36    Казарма
            38    Квартал
            41    Кордон
            44    Курортный поселок
            47    Массив
            48    Местечко
            49    Микрорайон
            52    Населенный пункт
            55    Остров
            59    Планировочный район
            63    Погост
            65    Поселок
            66    Поселок городского типа
            67    Поселок и(при) станция(и)
            68    Починок
            69    Почтовое отделение
            71    Промышленная зона
            79    Рабочий поселок
            80    Разъезд
            85    Садовое неком-е товарищество
            86    Село
            93    Слобода
            95    Станица
            96    Станция
            98    Территория
            102    Улус
            105    Хутор
            108    ж/д останов. (обгонный) пункт

            level 6-
            type_id    name
            9    Аул
            10    Берег
            11    Бугор
            12    Бульвар
            13    Вал
            15    Въезд
            16    Выселки(ок)
            17    Гаражно-строительный кооперат
            19    Городок
            21    Деревня
            23    Дорога
            24    Железнодорожная будка
            25    Железнодорожная казарма
            26    Железнодорожная платформа
            27    Железнодорожная станция
            28    Железнодорожный пост
            29    Железнодорожный разъезд
            30    Животноводческая точка
            33    Заезд
            35    Зона
            36    Казарма
            37    Канал
            38    Квартал
            39    Километр
            40    Кольцо
            42    Коса
            45    Леспромхоз
            46    Линия
            48    Местечко
            49    Микрорайон
            50    Мост
            51    Набережная
            52    Населенный пункт
            55    Остров
            56    Парк
            57    Переезд
            58    Переулок
            59    Планировочный район
            60    Платформа
            61    Площадка
            62    Площадь
            64    Полустанок
            65    Поселок
            67    Поселок и(при) станция(и)
            69    Почтовое отделение
            70    Проезд
            72    Просек
            73    Просека
            74    Проселок
            75    Проспект
            76    Проток
            78    Проулок
            80    Разъезд
            83    Ряды
            84    Сад
            85    Садовое неком-е товарищество
            86    Село
            92    Сквер
            93    Слобода
            94    Спуск
            96    Станция
            97    Строение
            98    Территория
            99    Тракт
            100    Тупик
            101    Улица
            103    Участок
            104    Ферма
            105    Хутор
            107    Шоссе
            108    ж/д останов. (обгонный) пункт

            level 7- 22 - дом
            level 8- 109 - квартира, 97 - Строение
            level 9- Почтовое отделение

               */
               _cntry = CASE WHEN _lvl = 1 THEN _addr_name ELSE _cntry END;
               _state = CASE WHEN _lvl = 2 THEN _addr_name ELSE _state END;
               _rayon = CASE WHEN _lvl = 3 THEN _addr_name ELSE _rayon END;
               _town  = CASE WHEN _type = 18 THEN _addr_name ELSE CASE WHEN _lvl = 4 THEN _addr_name ELSE _town END END;
               _np    = CASE WHEN _lvl = 5 THEN _addr_name ELSE _np END;
               _street= CASE WHEN _lvl = 6 THEN _addr_name ELSE _street END;
               _dom   = CASE WHEN _lvl = 7 THEN _addr_name ELSE _dom END;
               _kor   = CASE WHEN _lvl = 9 THEN _addr_name ELSE _kor END;
               _kv    = CASE WHEN _lvl = 8 THEN _addr_name ELSE _kv END;
               _mr    = _full_name;

              _rec = ($1,_cntry,_state ,_rayon ,_town ,_np ,_street ,_dom ,_kor ,_kv ,_mr );
              EXIT WHEN _par_id IS NULL;
            END LOOP;
            RETURN;
            END;
$$;

