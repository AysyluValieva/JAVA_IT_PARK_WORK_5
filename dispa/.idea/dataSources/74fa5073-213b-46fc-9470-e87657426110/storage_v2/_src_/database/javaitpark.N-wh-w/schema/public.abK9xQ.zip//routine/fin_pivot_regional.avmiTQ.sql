CREATE FUNCTION fin_pivot_regional(p1_bill_id integer, p2_status text)
  RETURNS void
STRICT
LANGUAGE plpgsql
AS $$
BEGIN
    /*
       version: 2015-02-12
    */
END;
$$;

