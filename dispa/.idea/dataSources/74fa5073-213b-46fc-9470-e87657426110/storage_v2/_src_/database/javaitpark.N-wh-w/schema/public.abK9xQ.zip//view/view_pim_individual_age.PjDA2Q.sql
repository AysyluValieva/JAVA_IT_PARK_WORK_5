CREATE VIEW view_pim_individual_age AS
  SELECT pi.birth_dt,
    pi.death_dt,
    pi.has_citizenship,
    pi.name,
    pi.patr_name,
    pi.surname,
    pi.id,
    pi.gender_id,
    pi.nationality_id,
    pi.list_identity_doc,
    pi.list_oms_doc,
    pi.list_job_org,
    pi.list_reg_name,
    pi.list_snils,
    pi.list_uid,
    pi.aud_who,
    pi.aud_when,
    pi.aud_source,
    pi.aud_who_create,
    pi.aud_when_create,
    pi.aud_source_create,
    pi.birth_place,
    pi.age_year,
    pi.age_month,
    pi.age_day,
    pi.list_main_contact,
    p_age.age_txt,
    p_age.age_sort
   FROM pim_individual pi,
    LATERAL ( SELECT
                CASE
                    WHEN (COALESCE(t.age_yy, 0) = 0) THEN
                    CASE
                        WHEN (COALESCE(t.age_mm, 0) < 1) THEN tdd.day_str
                        ELSE tmm.month_str
                    END
                    WHEN (COALESCE(t.age_yy, 0) < 18) THEN
                    CASE
                        WHEN (COALESCE(t.age_mm, 0) = 0) THEN tyy.year_str
                        ELSE concat(tyy.year_str, ' ', tmm.month_str)
                    END
                    ELSE tyy.year_str
                END AS age_txt,
            NULL::integer AS age_sort
           FROM (((( SELECT COALESCE((date_part('year'::text, t_1.age))::integer, pi.age_year) AS age_yy,
                    COALESCE((date_part('month'::text, t_1.age))::integer, pi.age_month) AS age_mm,
                    COALESCE((date_part('day'::text, t_1.age))::integer, pi.age_day) AS age_dd
                   FROM ( SELECT age((COALESCE((pi.death_dt)::date, ('now'::text)::date))::timestamp with time zone, (pi.birth_dt)::timestamp with time zone) AS age) t_1) t
             LEFT JOIN LATERAL ( SELECT format('%s %s.'::text, t.age_yy,
                        CASE
                            WHEN ((t.age_yy <> ALL (ARRAY[11, 12, 13, 14])) AND ((t.age_yy % 10) = ANY (ARRAY[1, 2, 3, 4]))) THEN 'г'::text
                            ELSE 'л'::text
                        END) AS year_str
                  WHERE (t.age_yy IS NOT NULL)
                 LIMIT 1) tyy ON (true))
             LEFT JOIN LATERAL ( SELECT format('%s мес.'::text, t.age_mm) AS month_str
                  WHERE (t.age_mm IS NOT NULL)
                 LIMIT 1) tmm ON (true))
             LEFT JOIN LATERAL ( SELECT format('%s дн.'::text, t.age_dd) AS day_str
                  WHERE (t.age_dd IS NOT NULL)
                 LIMIT 1) tdd ON (true))
         LIMIT 1) p_age;

