CREATE FUNCTION fsym_on_i_for_mb_pm_trnsprt_mngrp()
  RETURNS trigger
LANGUAGE plpgsql
AS $fun$
begin                                                                                                                                                                  
                                   
                                  if 1=1 and "public".sym_triggers_disabled() = 0 then                                                                                                 
                                    insert into "public".sym_data                                                                                                                     
                                    (table_name, event_type, trigger_hist_id, row_data, channel_id, transaction_id, source_node_id, external_data, create_time)                                        
                                    values(                                                                                                                                                            
                                      'pim_transport',                                                                                                                                            
                                      'I',                                                                                                                                                             
                                      34,                                                                                                                                             
                                      
          case when new."id" is null then '' else '"' || cast(cast(new."id" as numeric) as varchar) || '"' end||','||
          case when new."org_id" is null then '' else '"' || cast(cast(new."org_id" as numeric) as varchar) || '"' end||','||
          case when new."code" is null then '' else '"' || replace(replace(cast(new."code" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."inventory_number" is null then '' else '"' || replace(replace(cast(new."inventory_number" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."okof_code" is null then '' else '"' || replace(replace(cast(new."okof_code" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."category_id" is null then '' else '"' || cast(cast(new."category_id" as numeric) as varchar) || '"' end||','||
          case when new."type_id" is null then '' else '"' || cast(cast(new."type_id" as numeric) as varchar) || '"' end||','||
          case when new."transport_equipment_id" is null then '' else '"' || cast(cast(new."transport_equipment_id" as numeric) as varchar) || '"' end||','||
          case when new."brand_name_id" is null then '' else '"' || cast(cast(new."brand_name_id" as numeric) as varchar) || '"' end||','||
          case when new."model_id" is null then '' else '"' || cast(cast(new."model_id" as numeric) as varchar) || '"' end||','||
          case when new."model" is null then '' else '"' || replace(replace(cast(new."model" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."manufacturer_id" is null then '' else '"' || cast(cast(new."manufacturer_id" as numeric) as varchar) || '"' end||','||
          case when new."country_id" is null then '' else '"' || cast(cast(new."country_id" as numeric) as varchar) || '"' end||','||
          case when new."issue_dt" is null then '' else '"' || to_char(new."issue_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when new."department_id" is null then '' else '"' || cast(cast(new."department_id" as numeric) as varchar) || '"' end||','||
          case when new."purchase_dt" is null then '' else '"' || to_char(new."purchase_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when new."ownership_pattern_id" is null then '' else '"' || cast(cast(new."ownership_pattern_id" as numeric) as varchar) || '"' end||','||
          case when new."warranty_dt" is null then '' else '"' || to_char(new."warranty_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when new."service_period" is null then '' else '"' || cast(cast(new."service_period" as numeric) as varchar) || '"' end||','||
          case when new."service_measure_id" is null then '' else '"' || cast(cast(new."service_measure_id" as numeric) as varchar) || '"' end||','||
          case when new."building_id" is null then '' else '"' || cast(cast(new."building_id" as numeric) as varchar) || '"' end||','||
          case when new."room_id" is null then '' else '"' || cast(cast(new."room_id" as numeric) as varchar) || '"' end||','||
          case when new."contract_id" is null then '' else '"' || cast(cast(new."contract_id" as numeric) as varchar) || '"' end||','||
          case when new."from_dt" is null then '' else '"' || to_char(new."from_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when new."to_dt" is null then '' else '"' || to_char(new."to_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when new."unit_id" is null then '' else '"' || cast(cast(new."unit_id" as numeric) as varchar) || '"' end||','||
          case when new."inventory_code" is null then '' else '"' || replace(replace(cast(new."inventory_code" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end,                                                                                                                                                      
                                      'amb_pim_transport_default',                                                                                                                                                
                                      txid_current(),                                                                                                                                               
                                      "public".sym_node_disabled(),                                                                                                                   
                                      null,                                                                                                                                               
                                      CURRENT_TIMESTAMP                                                                                                                
                                    );                                                                                                                                                                 
                                  end if;                                                                                                                                                              
                                                                                                                                                                               
                                  return null;                                                                                                                                                         
                                end;
$fun$;

