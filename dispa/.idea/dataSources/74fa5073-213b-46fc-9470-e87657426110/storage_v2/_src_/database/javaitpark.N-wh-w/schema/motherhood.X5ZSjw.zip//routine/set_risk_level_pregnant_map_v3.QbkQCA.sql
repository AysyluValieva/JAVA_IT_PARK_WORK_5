CREATE FUNCTION set_risk_level_pregnant_map_v3(mapid integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
  -- существует ли активная настройка
  is_active_setting_exists boolean;
  -- идентификатор группы риска (1 - низкая, 2 - средняя, 3 - высокая)
  risk_level_id int;
BEGIN
  SELECT EXISTS (select 1 from motherhood.risk_factory_group_setting setting where setting.is_active) into is_active_setting_exists;

  IF is_active_setting_exists THEN
       -- если есть активная настройка, то высчитывается степень риска по группам, состоящим в ней и границам, заданным в настройке
      SELECT CASE WHEN (a.from_low_risk IS NULL OR a.from_low_risk <= sum(points)) AND a.to_low_risk >= sum(points) THEN 1 ELSE
             CASE WHEN a.from_medium_risk <= sum(points) AND a.to_medium_risk >= sum(points) THEN 2 ELSE
             CASE WHEN a.from_high_risk <= sum(points) AND (a.to_high_risk IS NULL OR a.to_high_risk >= sum(points)) THEN 3 END END END
      FROM motherhood.risk_factory_group g,
           motherhood.risk_factory_group_setting a,
           motherhood.risk_factory_value rfv,
           motherhood.risk_factory_options rfo,
           motherhood.risk_factory_group_to_setting g_to_s,
           motherhood.mh_pregnant_map_risk_option ro
      WHERE rfv.group_id = g.id
            AND rfo.value_id = rfv.id
            AND a.id = (SELECT s.id FROM motherhood.risk_factory_group_setting s WHERE s.is_active)
            AND g_to_s.setting_id = a.id
            AND g_to_s.group_id = g.id
            AND ro.risk_option_id = rfo.id
            AND ro.pregnant_map_id = mapId
      GROUP BY a.from_low_risk, a.to_low_risk, a.from_medium_risk, a.to_medium_risk, a.from_high_risk, a.to_high_risk into risk_level_id;
  ELSE
      -- если активной настройки нет, то берётся максимальную степень риска по группам
      SELECT max(risk_id)
      FROM (SELECT CASE WHEN rfg.from_high_risk <= sum(points) AND (rfg.to_high_risk IS NULL OR rfg.to_high_risk >= sum(points)) THEN 3
			ELSE CASE WHEN rfg.from_medium_risk <= sum(points) AND rfg.to_medium_risk >= sum(points) THEN 2
                        ELSE CASE WHEN (rfg.from_low_risk IS NULL OR rfg.from_low_risk <= sum(points)) AND rfg.to_low_risk >= sum(points) THEN 1
			END END END AS risk_id
            FROM motherhood.risk_factory_group rfg,
                 motherhood.risk_factory_value rfv,
		 motherhood.risk_factory_options rfo,
		 motherhood.mh_pregnant_map_risk_option ro
            WHERE (end_dt IS NULL OR end_dt >= current_date)
		   AND rfv.group_id = rfg.id
		   AND rfo.value_id = rfv.id
		   AND ro.risk_option_id = rfo.id
		   AND ro.pregnant_map_id = mapId
	   GROUP BY rfg.from_low_risk, rfg.to_low_risk, rfg.from_medium_risk,
	    rfg.to_medium_risk, rfg.from_high_risk, rfg.to_high_risk, rfg.id) AS t into risk_level_id;
  END IF;

  UPDATE motherhood.mh_pregnant_map SET risk_id = risk_level_id WHERE id = mapId AND is_auto_create;
END;
$$;

