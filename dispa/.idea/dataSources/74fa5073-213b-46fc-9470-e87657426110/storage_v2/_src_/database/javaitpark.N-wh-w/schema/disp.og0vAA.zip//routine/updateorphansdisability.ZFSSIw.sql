CREATE FUNCTION updateorphansdisability(xid integer, xdtid integer, xdd character varying, xdls character varying, xddid character varying, xvihid character varying, xdi character varying, ximid integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
    i integer;
    diagnos json;
    violation json;
  begin
    IF (select count(id) from disp.md_disp_orphans_disability where id = xid) = 0 THEN
      i = xid;
      insert into disp.md_disp_orphans_disability (id, disability_type_id, date_disability, date_last_survey, date_ipr, ipr_made_id)
        values (i, xdtid, to_date(xdd, 'DD.MM.YYYY'), to_date(xdls, 'DD.MM.YYYY'), to_date(xdi, 'DD.MM.YYYY'), ximid);
    ELSE
      update disp.md_disp_orphans_disability set disability_type_id = xdtid, date_disability = to_date(xdd, 'DD.MM.YYYY'), date_last_survey = to_date(xdls, 'DD.MM.YYYY'),
        date_ipr = to_date(xdi, 'DD.MM.YYYY'), ipr_made_id = ximid
        where id = xid;
    END IF;

    delete from disp.md_disp_orphans_disability_diagnosis where disability_id = xid;
    delete from disp.md_disp_orphans_disability_violations where disability_id = xid;
    foreach diagnos in array array(select value from json_array_elements(cast(xddid as json)))
    LOOP
      insert into disp.md_disp_orphans_disability_diagnosis(disability_id, diagnosis_id) values (xid, diagnos::text::int);
    END LOOP;
    foreach violation in array array(select value from json_array_elements(cast(xvihid as json)))
    LOOP
      insert into disp.md_disp_orphans_disability_violations(disability_id, violation_id) values (xid, violation::text::int);
    END LOOP;
    return 1;
    end;
$$;

