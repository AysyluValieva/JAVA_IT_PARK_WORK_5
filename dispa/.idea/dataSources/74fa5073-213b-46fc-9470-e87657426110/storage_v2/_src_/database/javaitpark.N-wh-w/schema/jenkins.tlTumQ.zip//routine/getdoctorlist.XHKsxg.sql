CREATE FUNCTION getdoctorlist(idspesiality text, _department_id integer, idpat text DEFAULT NULL::text)
  RETURNS TABLE(arianumber character varying, countfreeparticipantie integer, countfreeticket integer, iddoc character varying, lastdate character varying, name character varying, nearestdate character varying, snils character varying)
LANGUAGE plpgsql
AS $$
BEGIN
 

return query ( select * from "jenkins"."getdoctorlist_v3"( "idspesiality" ,  "_department_id" ,  "idpat") );

 
 
END;
$$;

