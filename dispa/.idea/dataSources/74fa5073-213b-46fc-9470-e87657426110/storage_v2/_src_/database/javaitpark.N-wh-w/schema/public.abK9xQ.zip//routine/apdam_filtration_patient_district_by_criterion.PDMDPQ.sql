CREATE FUNCTION apdam_filtration_patient_district_by_criterion()
  RETURNS void
LANGUAGE plpgsql
AS $$
BEGIN
  --фильтруем по обязательным критериям
  DELETE FROM apdam_patient_district
  WHERE (gender_terminal_id = 3 AND p_gender_id != gender_id)
        OR (age_terminal_id = 3 AND p_age NOT BETWEEN age_from AND age_to)
        OR (org_terminal_id = 3 AND (p_orgs && orgs) = FALSE)
        OR (benefit_terminal_id = 3 AND (p_benefits && benefits) = FALSE)
        OR (diagnosis_terminal_id = 3 AND
            apdam_check_code_in_diapason(p_diagnos_codes, diagnos_code_from, diagnos_code_to) = FALSE);

  --помечаем записи которые не прошли проверку по терминальным критериям
  UPDATE apdam_patient_district
  SET check_terminal = FALSE
  WHERE ((gender_terminal_id = 2 AND p_gender_id != gender_id)
         AND (age_terminal_id = 2 AND p_age NOT BETWEEN age_from AND age_to)
         AND (org_terminal_id = 2 AND (p_orgs && orgs) = FALSE)
         AND (benefit_terminal_id = 2 AND (p_benefits && benefits) = FALSE)
         AND (diagnosis_terminal_id = 2 AND
              apdam_check_code_in_diapason(p_diagnos_codes, diagnos_code_from, diagnos_code_to) = FALSE));

  --помечаем записи которые не прошли проверку по обычным критериям
  UPDATE apdam_patient_district
  SET check_terminal = FALSE
  WHERE check_terminal = FALSE
        OR (gender_terminal_id = 1 AND p_gender_id != gender_id)
        OR (age_terminal_id = 1 AND p_age NOT BETWEEN age_from AND age_to)
        OR (org_terminal_id = 1 AND (p_orgs && orgs) = FALSE)
        OR (benefit_terminal_id = 1 AND (p_benefits && benefits) = FALSE)
        OR (diagnosis_terminal_id = 1 AND
            apdam_check_code_in_diapason(p_diagnos_codes, diagnos_code_from, diagnos_code_to) = FALSE);

  --удалем записи которые не прошли проверку по терминальным и обычным критерия
  DELETE FROM apdam_patient_district
  WHERE check_terminal = FALSE;
END;
$$;

