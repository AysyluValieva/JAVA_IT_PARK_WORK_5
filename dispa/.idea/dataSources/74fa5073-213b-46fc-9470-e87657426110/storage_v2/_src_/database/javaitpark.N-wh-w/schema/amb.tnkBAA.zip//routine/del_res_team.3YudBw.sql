CREATE FUNCTION del_res_team(xid integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
    xresid integer;
  begin
    xresid = (select resource_id from amb.sr_res_team where id = xid);
    If not EXISTS (select * from amb.sr_res_team_job where team_id = xid)
      then
      	update sr_res_group set edate = now() where id = xresid;
      else
      	update sr_res_group set edate = greatest(cast(now() as date), (select max(cast(planned_edate as date)) from amb.sr_res_team_job where team_id = xid)) where id = xresid;
    end if;
  end;
$$;

