CREATE FUNCTION md_event_add_services_validate_function(xcardid integer, xservices character varying)
  RETURNS boolean
LANGUAGE plpgsql
AS $$
declare
                serviceid json;
		eventServicePatientId record;
		f boolean;
            begin
                for eventServicePatientId in
		  (select es.id from disp.md_event_service es
		  join disp.md_event_service_patient esp on es.id = esp.service_id
		  where esp.event_patient_id = xcardid and esp.status <> 1)
		loop
		  f = false;
		  foreach serviceid in array array(select value from json_array_elements(cast(xservices as json)))
		  loop
		    if (eventServicePatientId.id = serviceid::text::int) then
		      f = true;
		      exit;
		    end if;
		  end loop;
		  if (not f) then
		    return false;
		  end if;
		end loop;
                return true;
            end;
$$;

