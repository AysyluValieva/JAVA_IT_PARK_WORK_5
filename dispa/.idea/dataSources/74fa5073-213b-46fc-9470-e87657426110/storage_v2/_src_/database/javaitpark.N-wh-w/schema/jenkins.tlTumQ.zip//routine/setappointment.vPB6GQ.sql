CREATE FUNCTION setappointment(_idappointment character varying, _department_id character varying, _idpdat character varying, _doctorreferals character varying)
  RETURNS TABLE(success boolean, type text)
LANGUAGE plpgsql
AS $$
BEGIN
 

return query ( select * from "jenkins"."setappointment_v6"( "_idappointment" ,  "_department_id" ,  "_idpdat" ,  "_doctorreferals" ) );

 
 
END;
$$;

