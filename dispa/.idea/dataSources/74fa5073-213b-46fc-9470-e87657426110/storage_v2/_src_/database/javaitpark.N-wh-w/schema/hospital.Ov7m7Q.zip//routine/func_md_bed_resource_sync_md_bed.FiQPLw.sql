CREATE FUNCTION func_md_bed_resource_sync_md_bed()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
/*
при создании/редактировании/удалении ресурса палаты изменим палаты и койки что бы пересобрать все ограничения hospital.unused_bed
*/
BEGIN
    IF (TG_OP = 'DELETE') THEN
        -- при удалении ресурса ПАЛАТЫ почистим все исключения
        update md_bed set id = id where id = OLD.bed_id;
        RETURN OLD;
    ELSE
        IF (TG_OP = 'UPDATE' and  OLD.bed_id <> NEW.bed_id) THEN
            update md_bed set id = id where id = OLD.bed_id;
        END IF;
        update md_bed set id = id where id = NEW.bed_id;
        RETURN NEW;
    END IF;
END;
$$;

