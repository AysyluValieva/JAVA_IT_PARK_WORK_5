CREATE FUNCTION journal_delete(p_id integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
BEGIN

  IF exists(SELECT 1
            FROM sickdoc.journal_default
            WHERE journal_id = p_id)
  THEN
    RAISE 'Невозможно удалить журнал, т.к. он является журналом по умолчанию для одного или более отделений';
  END IF;

  DELETE FROM sickdoc.journal
  WHERE id = $1;

END;
$$;

