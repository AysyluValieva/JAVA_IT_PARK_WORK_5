CREATE FUNCTION attachmodeltoservice(xmodelid integer, xeventid integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
          i integer;
          mviews record;
        begin
          FOR mviews IN SELECT id FROM disp.md_event_service where event_id = xeventId LOOP
              i = nextval('disp.md_event_service_model_id_seq');
              insert into disp.md_event_service_model(id, event_service_id, model_id)
                    values(i, CAST(mviews.id as int), xmodelId);
          END LOOP;
          return 1;
        end;
$$;

