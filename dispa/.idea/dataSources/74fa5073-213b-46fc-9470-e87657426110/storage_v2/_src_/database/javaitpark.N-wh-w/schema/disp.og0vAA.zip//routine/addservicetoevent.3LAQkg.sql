CREATE FUNCTION addservicetoevent(xorgid integer, xserviceid integer, xresourceid integer, xeventid integer, xpriorityid integer, xdistrict boolean)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
          i integer;
        begin
          i = nextval('disp.md_event_service_id_seq');
          IF xpriorityId = 1 THEN
            update disp.md_event_service set first = FALSE where event_id=xeventId;
          ELSIF xpriorityId = 2 THEN
            update disp.md_event_service set last = FALSE where event_id=xeventId;
          END IF;
          insert into disp.md_event_service(id, event_id, org_id, resource_id, service_id, district_check, first, last)
            values(i, CAST(xeventId as int), xorgId, xresourceId, xserviceId, xdistrict,
                   CASE xpriorityId WHEN 1 THEN TRUE ELSE FALSE END, CASE xpriorityId WHEN 2 THEN TRUE ELSE FALSE END);
          return i;
        end;
$$;

