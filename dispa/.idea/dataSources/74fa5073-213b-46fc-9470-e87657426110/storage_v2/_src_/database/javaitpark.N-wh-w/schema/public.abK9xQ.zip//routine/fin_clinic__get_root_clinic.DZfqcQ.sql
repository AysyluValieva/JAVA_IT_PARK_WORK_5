CREATE FUNCTION fin_clinic__get_root_clinic(clinic_id integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
    parent_id integer;
begin
    return clinic_id;
-- todo: real implementation
/*
    parent_id = (select fin_clinic.parent_id from fin_clinic where fin_clinic.id = clinic_id);
    if parent_id is null then return clinic_id;
    else return fin_clinic__get_root_clinic(parent_id);
    end if;
*/
end;
$$;

