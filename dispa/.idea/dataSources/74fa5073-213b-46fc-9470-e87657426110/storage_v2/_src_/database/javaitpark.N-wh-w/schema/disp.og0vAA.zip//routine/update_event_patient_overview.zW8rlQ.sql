CREATE FUNCTION update_event_patient_overview()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE
        mespId integer;
        mepId integer;
        overview integer;
BEGIN
    IF TG_OP = 'INSERT' OR TG_OP = 'UPDATE' THEN
        mespId = NEW.id;
    ELSIF TG_OP = 'DELETE' THEN
        mespId = OLD.id;
    ELSE
        RETURN NULL;
    END IF;
    mepId = (select event_patient_id from disp.md_event_service_patient where id = mespId);

    overview = (select round(100.0 *
                CAST((select count(*) from disp.md_event_patient omep
                inner join disp.md_event_service_patient omesp on omesp.event_patient_id = omep.id
                inner join disp.md_event_service omes on omes.id = omesp.service_id  and (omesp.status = 4 or omesp.status = 3)
                where omep.id = mepId and (omes.ignore_service is NULL or omes.ignore_service = FALSE)) as real) / NULLIF(CAST((select count(*) from disp.md_event_patient omep2
                inner join disp.md_event_service_patient omesp2 on omesp2.event_patient_id = omep2.id
                inner join disp.md_event_service omes2 on omes2.id = omesp2.service_id
                where omep2.id = mepId and (omes2.ignore_service is NULL or omes2.ignore_service = FALSE)) as real), 0)
                ));

    update disp.md_event_patient set _overview = overview where id = mepId;
    RETURN NULL;
END;
$$;

