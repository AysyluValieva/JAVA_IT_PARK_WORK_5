CREATE FUNCTION servicen2oformadd(xid integer, xcode character varying, xform character varying)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare

        begin
          IF (xid is not null) THEN
            update disp.service_n2o_form set  n2o_form = xform ,service_code = xcode where id=xid;
          ELSE
             insert into disp.service_n2o_form (id,service_code, n2o_form) values (nextval('disp.service_n2o_form_id_seq'),xcode,xform );
          END IF;

          return 1;
        end;
$$;

