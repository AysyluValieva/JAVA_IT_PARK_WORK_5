CREATE FUNCTION save_institutions(xid integer, xlevel integer, xparent_id integer, xclinic_id integer, b_dt date, e_dt date, xnote text)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
  rid integer;
begin
  if (xid is not null)
  then
    update  motherhood.mh_institutions  set
                                            level = xlevel,
                                            parent_id = xparent_id,
                                            clinic_id = xclinic_id,
                                            begin_dt = b_dt,
                                            end_dt = e_dt,
                                            note = xnote
      where id = xid;
    rid = xid;
  ELSE
    insert into motherhood.mh_institutions (level, parent_id, clinic_id, begin_dt, end_dt, note)
    VALUES (xlevel, xparent_id, xclinic_id, b_dt, e_dt, xnote);
    select currval('motherhood.mh_institutions_id_seq') into rid;
  END IF;
  return rid;
end;
$$;

