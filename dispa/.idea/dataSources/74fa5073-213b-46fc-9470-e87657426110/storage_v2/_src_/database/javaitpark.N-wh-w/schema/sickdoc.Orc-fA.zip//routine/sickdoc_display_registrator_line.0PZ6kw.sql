CREATE FUNCTION sickdoc_display_registrator_line(p_employee_position_id integer, issue_dt date, clinic_id integer)
  RETURNS character varying
LANGUAGE plpgsql
AS $$
DECLARE
  l_result VARCHAR;
BEGIN

  SELECT
    i.surname || ' ' || left(i.name, 1) ||'. ' || left(i.patr_name, 1) || '.'  ||  '    ' || case when issue_dt ISNULL then ' ' else to_char(issue_dt, 'DD.MM.YYYY') end || '    ' || (select short_name from pim_organization where id = clinic_id)
    FROM pim_employee_position emp_pos
    JOIN pim_employee emp ON emp.id = emp_pos.employee_id
    JOIN pim_individual i ON i.id = emp.individual_id
    WHERE emp_pos.id = p_employee_position_id
    LIMIT 1
  INTO l_result;

  RETURN l_result;

END;
$$;

