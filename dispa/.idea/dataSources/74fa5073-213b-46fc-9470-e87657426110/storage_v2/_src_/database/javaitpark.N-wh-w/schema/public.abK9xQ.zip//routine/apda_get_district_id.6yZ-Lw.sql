CREATE FUNCTION apda_get_district_id(info apda_reg_info)
  RETURNS integer
LANGUAGE plpgsql
AS $$
DECLARE
  it RECORD;
BEGIN
  FOR it IN (SELECT
               cs.id          AS separation_id,
               cd.id          AS district_id,
               CASE WHEN cd.attache_number ISNULL
                         OR cd.attache_number > cr.count_regs
                         OR (cd.attache_number = cr.count_regs AND (info).district_id = cd.id)
                 THEN TRUE
               ELSE FALSE END AS has_free_place
             FROM md_clinic_separation cs
               JOIN md_clinic_district cd ON cs.id = cd.separation_id
               ,
               LATERAL (SELECT count(id) AS count_regs
                        FROM pci_patient_reg r
                        WHERE r.district_id = cd.id
                              AND (r.reg_dt ISNULL OR (info).reg_dt >= r.reg_dt)
                              AND (r.unreg_dt ISNULL OR (info).reg_dt <= r.unreg_dt)) cr
             WHERE cs.reg_type_id = (info).type_id
                   AND cs.clinic_id = (info).clinic_id
                   AND (cs.department_id = (info).department_id OR
                        (cs.department_id ISNULL AND (info).department_id ISNULL))
                   AND (cs.from_dt ISNULL OR (info).reg_dt >= cs.from_dt)
                   AND (cd.from_dt ISNULL OR (info).reg_dt >= cd.from_dt)
                   AND (cs.to_dt ISNULL OR ((info).unreg_dt ISNULL AND cs.to_dt > current_date) OR (info).unreg_dt <= cs.to_dt)
                   AND (cd.to_dt ISNULL OR ((info).unreg_dt ISNULL AND cd.to_dt > current_date) OR (info).unreg_dt <= cd.to_dt)
             ORDER BY has_free_place DESC, cd.order_number, cd.attache_number DESC, cd.id
  ) LOOP
    IF apda_check_district_by_reg($1, it.separation_id, it.district_id)
    THEN
      RETURN it.district_id;
    END IF;
  END LOOP;

  RETURN NULL;
END;
$$;

