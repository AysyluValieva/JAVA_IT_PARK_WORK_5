CREATE FUNCTION fin_spec_gen_set(p1_bill_id integer, p2_status text)
  RETURNS void
STRICT
LANGUAGE plpgsql
AS $$
BEGIN
    /*
        version: 2015-01-30
    */
    -----------------------------------------------------информация для расчёта стоимости------------------------------------------------------------
    -----------------------------------------------ует, количество, позиция прайса, код услуги-------------------------------------------------------
    UPDATE fin_bill_generate AS f
    SET
        rdd_cul = r.cul, rdd_quantity = r.quantity,
        srv_cul = s.cul, service_code = coalesce (trim (s.code), ''), service_name = coalesce (trim (s.name), ''), service_type_id = s.type_id,
        quantity =  (
                        CASE WHEN coalesce (s.is_multuplicity, FALSE) AND NOT coalesce (s.is_actual_cul, FALSE) THEN coalesce (nullif (r.quantity, 0), 1) ELSE 1 END 
                        * 
                        CASE WHEN coalesce (s.is_actual_cul, FALSE) THEN coalesce (nullif (r.cul, 0), nullif (s.cul, 0), 1) ELSE coalesce (nullif (s.cul, 0), 1) END
                    )
    FROM
        sr_service AS s, sr_srv_rendered AS r
    WHERE
        f.bill_id = p1_bill_id AND f.service_id = s.id AND f.id = r.id
    ;
    UPDATE fin_bill_generate AS f
    SET
        price_position_code = coalesce (trim (p.code), ''), price_position_name = coalesce (trim (p.name), '')
    FROM
        fin_pl_position AS p
    WHERE
        f.bill_id = p1_bill_id AND NOT f.is_sifted AND f.price_pos_arr[1] = p.id AND p.price_list_id = f.price_list_id
    ;
    ----------------------------------------------------------набор данных---------------------------------------------------------------------------
    UPDATE fin_bill_generate AS f
    SET
        new_born =  EXISTS 
                    (
                        SELECT 1 
                        FROM 
                            pci_patient_part_case AS p, pci_part_case AS c 
                        WHERE 
                            c.id = p.part_case_id AND c.ui_code IN ('1', '9') AND p.patient_id = f.patient_id 
                            AND f.case_close_date BETWEEN coalesce (p.from_dt, DATE '1900-01-01') AND coalesce (p.to_dt, DATE '4000-01-01') 
                    )
    WHERE
        f.bill_id = p1_bill_id AND NOT f.is_sifted
    ;
    UPDATE fin_bill_generate AS f
    SET
        attendant_id = (SELECT individual_id FROM mc_attendant WHERE case_id = f.case_id ORDER BY status_id LIMIT 1),
        relative_id = fin_individual__get_realative (f.patient_id, f.case_close_date)
    WHERE
        f.bill_id = p1_bill_id AND NOT f.is_sifted
    ;
    UPDATE fin_bill_generate
    SET
        customer_id = CASE WHEN new_born THEN coalesce (attendant_id, relative_id) ELSE patient_id END,
        representative_id = CASE WHEN new_born THEN coalesce (attendant_id, relative_id) ELSE NULL END,
        id_pac = concat (patient_id, CASE WHEN new_born THEN concat ('П', coalesce (attendant_id, relative_id)) ELSE '' END)
    WHERE
        bill_id = p1_bill_id AND NOT is_sifted
    ;
    UPDATE fin_bill_generate AS f
    SET
        patient_age = date_part ('year', age (f.case_open_date, i.birth_dt)), patient_gender_id = i.gender_id
    FROM 
        pim_individual AS i
    WHERE
        f.bill_id = p1_bill_id AND NOT f.is_sifted AND f.patient_id = i.id
    ;
    WITH t AS 
    (
        SELECT 
            f.bill_id, f.id, s.id AS res_id
        FROM
            fin_bill_generate                        AS f
            JOIN mc_step                             AS t ON t.id = f.step_id
            LEFT JOIN sr_res_group                   AS s ON s.id = t.res_group_id
            LEFT JOIN sr_res_group                   AS r ON r.id = f.res_group_id
            LEFT JOIN pim_employee_position_resource AS e ON e.employee_position_id = r.responsible_id
            LEFT JOIN sr_res_group_relationship      AS l ON l.group_id = r.id AND l.resource_id = e.id
        WHERE
            f.bill_id = p1_bill_id AND NOT f.is_sifted 
            AND (r.responsible_id IS NULL OR f.bdate NOT BETWEEN coalesce (bdatetime, DATE '1900-01-01') AND coalesce (edatetime, DATE '4000-01-01'))
    )
    UPDATE fin_bill_generate AS f
    SET
        res_group_id = t.res_id
    FROM t
    WHERE
        f.bill_id = t.bill_id AND f.id = t.id
    ;
    WITH cases AS 
    (
        SELECT case_id FROM fin_bill_generate WHERE bill_id = p1_bill_id AND NOT is_sifted GROUP BY 1
    ),
    t AS 
    (
        SELECT 
            c.case_id, count (DISTINCT t.id) AS cnt 
        FROM 
            cases AS c, mc_step AS t
        WHERE 
            c.case_id = t.case_id
        GROUP BY 1
    )
    UPDATE fin_bill_generate AS f
    SET 
        step_cnt = t.cnt
    FROM t
    WHERE
        f.bill_id = p1_bill_id AND NOT f.is_sifted AND t.case_id = f.case_id
    ;
    --применение условие отбора по подразделениями
    IF 
        p2_status = 'GENERATE' AND EXISTS (SELECT 1 FROM fin_bill_main_department WHERE main_bill_id = fin_bill__get_main_bill (p1_bill_id))
    THEN
        WITH item AS 
        (
            SELECT
                f.bill_id, f.id
            FROM 
                fin_bill_generate AS f, fin_bill_main_department AS t, sr_res_group AS g, pim_employee_position AS e, pim_position AS p
            WHERE
                f.bill_id = p1_bill_id AND NOT f.is_sifted AND t.main_bill_id = fin_bill__get_main_bill (p1_bill_id)
                AND g.id = f.res_group_id AND g.responsible_id = e.id AND e.position_id = p.id AND p.department_id = t.department_id 
        ),
        t AS 
        (
            SELECT
                f.bill_id, f.id
            FROM
                fin_bill_generate AS f
                LEFT JOIN item    AS i ON f.bill_id = i.bill_id AND f.id = i.id
            WHERE
                f.bill_id = p1_bill_id AND NOT f.is_sifted AND i.id IS NULL
        )
        UPDATE fin_bill_generate AS f
        SET
           is_sifted = TRUE, sifting_cause = 'Применён фильтр по подразделениям'
        FROM t
        WHERE
            f.bill_id = t.bill_id AND f.id = t.id
        ;
    END IF;
    ------------------------------------------------------обновление статуса "удалена"---------------------------------------------------------------
    IF
        p2_status = 'GENERATE'
    THEN
        DELETE FROM fin_bill_deleted_services WHERE bill_id = p1_bill_id
        ;
    ELSIF
        p2_status IN ('VALIDATE', 'RECALCULATE')
    THEN
        UPDATE fin_bill_generate AS f 
        SET 
            is_deleted = TRUE 
        FROM 
            fin_bill_deleted_services AS s 
        WHERE 
            f.bill_id = p1_bill_id AND f.bill_id = s.bill_id AND f.id = s.srv_rendered_id AND NOT f.is_sifted
        ;
    END IF;
EXCEPTION
    WHEN NO_DATA_FOUND THEN RAISE EXCEPTION 'Отсутствуют данные по счёту';
END;
$$;

