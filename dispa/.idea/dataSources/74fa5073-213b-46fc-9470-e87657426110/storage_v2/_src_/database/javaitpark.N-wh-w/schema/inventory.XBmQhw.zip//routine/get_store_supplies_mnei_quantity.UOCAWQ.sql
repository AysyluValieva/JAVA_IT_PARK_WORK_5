CREATE FUNCTION get_store_supplies_mnei_quantity(mneiquantity numeric, holdmodifid integer, fundid integer, storeid integer, expinvoicedate date)
  RETURNS numeric
LANGUAGE plpgsql
AS $$
DECLARE
 result  NUMERIC;
 income NUMERIC;
 outcome NUMERIC;

BEGIN
 result=0;
SELECT SUM(jur.mnei_quantity) INTO outcome  FROM inventory.store_opr_jur AS jur
   LEFT OUTER JOIN inventory.store_opr opr ON jur.store_opr_id=opr.id
   LEFT OUTER JOIN inventory.store_opr_type TYPE ON TYPE.id=opr.opr_type_id
   WHERE TYPE.id=2 AND jur.date > expInvoiceDate::DATE AND send_store_sup_id  IN(
          SELECT ss.id   FROM inventory.store_supply ss
                INNER JOIN inventory.arrival_spec spec ON spec.store_sup_id=ss.id
                LEFT OUTER JOIN inventory.batch batch ON batch.id=ss.batch_id
                WHERE batch.hold_modif_id = holdModifId AND ss.funding_source_id=fundId AND ss.store_id =storeId);


SELECT SUM(jur.mnei_quantity)INTO income  FROM inventory.store_opr_jur AS jur
   LEFT OUTER JOIN inventory.store_opr opr ON jur.store_opr_id=opr.id
   LEFT OUTER JOIN inventory.store_opr_type TYPE ON TYPE.id=opr.opr_type_id
   WHERE TYPE.id=1 AND jur.date > expInvoiceDate::DATE AND rec_store_sup_id  IN(
          SELECT ss.id   FROM inventory.store_supply ss
                LEFT OUTER JOIN inventory.batch batch ON batch.id=ss.batch_id
                WHERE batch.hold_modif_id = holdModifId AND ss.funding_source_id=fundId AND ss.store_id =storeId);

if outcome IS NULL THEN outcome=0; END if;
if income IS NULL THEN income=0; END if;

result=mneiQuantity+outcome-income;
return result;
END;
$$;

