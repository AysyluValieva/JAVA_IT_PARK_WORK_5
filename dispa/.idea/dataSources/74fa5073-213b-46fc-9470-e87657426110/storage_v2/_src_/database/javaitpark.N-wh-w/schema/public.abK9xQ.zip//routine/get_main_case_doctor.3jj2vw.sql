CREATE FUNCTION get_main_case_doctor(_case_id integer)
  RETURNS character varying
LANGUAGE plpgsql
AS $$
declare
                      doctor_name character varying(70);
                    begin
                        with _case
                          as (
                              select c.id,
                                     ct.code
                                from mc_case c
                                join mc_case_type ct on c.case_type_id = ct.id
                               where c.id = _case_id
                          ),
                            _res_group
                          as (
                              select case
                                     when c.code = '2'
                                       then (
                                             select s.res_group_id
                                               from mc_step s
                                              where s.case_id = c.id
                                           order by s.admission_date desc, s.admission_time desc
                                              limit 1
                                            ) --'врач из последнего зог'
                                       else (
                                               select s.res_group_id
                                                 from mc_step s
                                                where s.case_id = c.id
                                             order by s.admission_date asc, s.admission_time asc
                                                limit 1
                                            ) --'врач из первого посещения'
                                     end
                              from _case c
                          )
                        select concat(initcap(i.surname), ' ' || concat(left(initcap(i.name), 1), '.'), ' ' || concat(left(initcap(i.patr_name), 1), '.')) as doctor
                          into doctor_name
                          from sr_res_group rg
                          join sr_res_group_relationship rgs on rg.id = rgs.group_id
                          join pim_employee_position_resource epr on rgs.resource_id = epr.id
                          join sr_res_role rr on rgs.role_id = rr.id
                          join _res_group r on rg.id = r.res_group_id
                          join pim_employee_position ep on epr.employee_position_id = ep.id
                          join pim_employee e on ep.employee_id = e.id
                          join pim_individual i on i.id = e.individual_id
                          order by
                               case rr.code
                                 when 'DOCTOR' then 1
                                 when 'SURGEON' then 2
                                 when 'ACCOUCHEUR' then 3
                                 when 'DOCTOR_ASST' then 4
                                 when 'PARAMEDIC' then 5
                                 when 'PARAMEDIC_ASST' then 6
                                 when 'ANESTHESIOLOGIST' then 7
                                 else 8
                               end asc
                        limit 1;

                      return doctor_name;
                    end;
$$;

