CREATE FUNCTION copy_death_reasons(xnew_id integer, xis_perinatal boolean, xparent_id integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
                reasons record;
              begin
                IF (xis_perinatal = false)
                    THEN
                      if exists (select * from certificates.death_reason where death_certificate_id = xparent_id)
                          then
                            for reasons in
                                select id
                                    from certificates.death_reason where death_certificate_id = xparent_id
                            loop
                                insert into certificates.death_reason (death_certificate_id,
                                                                        is_direct,is_interim,is_primary,is_foreign,
                                                                        diagnos_id,diagnos_name,diagnos_code,
                                                                        minutes,hours,days,weeks,months,years,
                                                                        is_print)
                                    select xnew_id,
                                           is_direct,is_interim,is_primary,is_foreign,
                                           diagnos_id,diagnos_name,diagnos_code,
                                           minutes,hours,days,weeks,months,years,
                                           is_print
                                    from certificates.death_reason where id = reasons.id;
                            end loop;
                      end if;
                    ELSE
                        if exists (select * from certificates.death_reason where death_certificate_id = xparent_id)
                          then
                            for reasons in
                                select id
                                    from certificates.death_reason where perinatal_death_certificate_id = xparent_id
                            loop
                                insert into certificates.death_reason (perinatal_death_certificate_id,
                                                                        is_perinatal,is_direct,is_other_baby_reason,is_mother_direct,is_mother_other_reason,is_foreign,
                                                                        diagnos_id,diagnos_name,diagnos_code,
                                                                        minutes,hours,days,weeks,months,years)
                                    select xnew_id,
                                           is_perinatal,is_direct,is_other_baby_reason,is_mother_direct,is_mother_other_reason,is_foreign,
                                           diagnos_id,diagnos_name,diagnos_code,
                                           minutes,hours,days,weeks,months,years
                                    from certificates.death_reason where id = reasons.id;
                            end loop;
                      end if;
                END IF;
              end;
$$;

