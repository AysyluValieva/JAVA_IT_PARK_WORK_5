CREATE FUNCTION journal_create(p_clinic_id integer, p_code character varying, p_name character varying, p_is_common_for_clinic boolean, p_begin_dt date, p_end_dt date)
  RETURNS integer
LANGUAGE plpgsql
AS $$
DECLARE
  l_common_journal_id INTEGER;
  l_id INTEGER;
BEGIN
  IF exists(SELECT 1
            FROM sickdoc.journal j
            WHERE j.name = p_name AND j.clinic_id = p_clinic_id)
  THEN
    RAISE 'Журнал с наименованием % уже существует в МО. Введите уникальное наименование', p_name;
  END IF;

  IF exists(SELECT 1
            FROM sickdoc.journal j
            WHERE j.code = p_code AND j.clinic_id = p_clinic_id)
  THEN
    RAISE 'Журнал с кодом % уже существует в МО. Введите уникальное наименование', p_code;
  END IF;

  IF p_is_common_for_clinic
  THEN
    SELECT sickdoc.journal_get_common_for_clinic(p_clinic_id)
    INTO l_common_journal_id;

    IF l_common_journal_id NOTNULL
    THEN
      UPDATE sickdoc.journal
      SET is_common_for_clinic = FALSE
      WHERE id = l_common_journal_id;
    END IF;
  END IF;

  INSERT
  INTO sickdoc.journal (
    id, clinic_id, code, name, is_common_for_clinic, begin_dt, end_dt)
  VALUES (
    DEFAULT, p_clinic_id, p_code, p_name, p_is_common_for_clinic, p_begin_dt, p_end_dt)
  RETURNING id
    INTO l_id;
  RETURN l_id;
END;
$$;

