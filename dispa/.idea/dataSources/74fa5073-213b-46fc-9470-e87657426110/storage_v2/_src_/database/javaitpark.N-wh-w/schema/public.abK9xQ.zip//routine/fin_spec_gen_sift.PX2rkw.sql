CREATE FUNCTION fin_spec_gen_sift(p1_bill_id integer, p2_status text)
  RETURNS void
STRICT
LANGUAGE plpgsql
AS $$
DECLARE 
    _price_list_id INTEGER;
    _financing_type_id INTEGER;
    _payer_id INTEGER;
    _contract_id INTEGER;
    _r RECORD;
    --_template_id INTEGER;
    --_template_group_id INTEGER;
    --_template_group_multiple BOOLEAN := FALSE;
BEGIN
    /*
        current version date 2014-12-16
    */
    ------------------------------------------------------------------параметры----------------------------------------------------------------------
    SELECT 
        price_list_id, financing_type_id, payer_id, contract_id --, template_id
        INTO 
        _price_list_id, _financing_type_id, _payer_id, _contract_id --, _template_id
    FROM
        fin_bill_main
    WHERE
        id = fin_bill__get_main_bill (p1_bill_id)
    ;
    --------------------------------------------заполнение дополнительных параметров для непустого шаблона-------------------------------------------
    /*
    IF 
        _template_id IS NOT NULL 
    THEN 
        SELECT
            t.group_id, g.multiple INTO _template_group_id, _template_group_multiple
        FROM
            fin_bill_main_template            AS t
            LEFT JOIN fin_bill_template_group AS g ON t.group_id = g.id AND t.id = _template_id
        ;
    END IF;
    */
    --------------------------------------------позиции прайса для услуг и отсеивание по количеству--------------------------------------------------
    UPDATE fin_pl_pos_to_clinic_srv AS p2s 
    SET 
        price_list_id = p.price_list_id
    FROM 
        fin_pl_position AS p
    WHERE 
        p2s.pl_position_id = p.id AND coalesce (p2s.price_list_id, 0) <> p.price_list_id AND p.price_list_id = _price_list_id
    ;
    UPDATE fin_bill_generate AS f
    SET
        price_pos_arr = ARRAY 
                            (
                                SELECT 
                                    p.id 
                                FROM 
                                    fin_pl_pos_to_clinic_srv AS p2s, fin_pl_position AS p 
                                WHERE
                                    p.id = p2s.pl_position_id AND p.price_list_id = p2s.price_list_id 
                                    AND p2s.clinic_service_id = f.service_id AND p.price_list_id = f.price_list_id
                                    AND f.case_close_date BETWEEN coalesce (p.from_dt, DATE '1900-01-01') AND coalesce (p.to_dt, DATE '4000-01-01')
                            )
    WHERE
        f.bill_id = p1_bill_id
    ;
    IF 
        p2_status = 'GENERATE' AND fin_bill__get_sift_status ('SIFT_PRICE_QUANTITY') 
    THEN
        UPDATE fin_bill_generate AS f
        SET
            is_sifted = TRUE, 
            sifting_cause = CASE 
                                WHEN 
                                    coalesce (array_length (price_pos_arr, 1), 0) = 0 
                                THEN 
                                    'Нет актуальной позиции в прайсе для услуги' 
                                ELSE 
                                    'Больше одной актуальной позиции в прайсе для услуги' 
                                END
        WHERE
            f.bill_id = p1_bill_id AND coalesce (array_length (price_pos_arr, 1), 0) <> 1
        ;
    END IF;
    -------------------------------------------------------------отсеивание--------------------------------------------------------------------------
    IF 
        p2_status = 'GENERATE' AND _financing_type_id IS NOT NULL 
    THEN 
        UPDATE fin_bill_generate 
        SET 
            is_sifted = TRUE, sifting_cause = 'Тип финансирования не совпадает с прейскурантом' 
        WHERE 
            bill_id = p1_bill_id AND NOT is_sifted AND _financing_type_id <> funding_id
        ;
    END IF;
    IF 
        p2_status = 'GENERATE' AND coalesce ((SELECT type_id FROM pim_party WHERE id = _payer_id), 2) = 1 
    THEN 
        UPDATE fin_bill_generate
        SET
            is_sifted = TRUE, sifting_cause = 'Не совпадает с плательщиком-индивидуалом по счёту'
        WHERE
            bill_id = p1_bill_id AND NOT is_sifted AND patient_id <> _payer_id
        ;
    END IF;
    IF 
        p2_status = 'GENERATE' AND _contract_id IS NOT NULL 
    THEN 
        FOR _r IN
            SELECT
                f.bill_id,
                f.patient_id,
                f.contract_id,
                array_agg (DISTINCT coalesce (t.contract_id, 0)) AS contract_id_arr,
                array_agg (f.id) AS id_arr
            FROM
                fin_bill_generate                 AS f
                LEFT JOIN fin_contract_to_patient AS t ON f.patient_id = t.patient_id
            WHERE
                f.bill_id = p1_bill_id
            GROUP BY 1, 2, 3
        LOOP
            IF
                _r.contract_id = 0
            THEN
                IF
                    _contract_id <> ALL (_r.contract_id_arr)
                THEN
                    UPDATE fin_bill_generate
                    SET
                        is_sifted = TRUE, sifting_cause = 'У пациента отсутствует контракт, указанный в счёте'
                    WHERE
                        bill_id = _r.bill_id AND NOT is_sifted AND id = ANY (_r.id_arr)
                    ;
                END IF;
            ELSE
                IF
                    _contract_id <> _r.contract_id
                THEN
                    UPDATE fin_bill_generate
                    SET
                        is_sifted = TRUE, sifting_cause = 'Контракт по услугам не совпадает с контрактом по счёту'
                    WHERE
                        bill_id = _r.bill_id AND NOT is_sifted AND id = ANY (_r.id_arr)
                    ;
                END IF;
            END IF;
        END LOOP;
    END IF;
    /*
    IF 
        _template_id IS NOT NULL 
    THEN
        UPDATE fin_bill_generate AS f
        SET
            is_sifted = TRUE, sifting_cause = 'Неправильный шаблон'
        WHERE
            f.bill_id = p1_bill_id AND NOT f.is_sifted 
            AND EXISTS 
                (
                    SELECT 1 
                    FROM 
                        fin_bill_spec_item                AS i 
                        JOIN fin_bill_main                AS m ON m.id = _main_bill_id AND i.bill_id = p1_bill_id
                        JOIN fin_bill_main_template       AS t ON t.id = m.template_id
                        LEFT JOIN fin_bill_template_group AS g ON g.id = t.group_id
                    WHERE 
                            i.service_id = f.id
                        AND (t IS NULL OR g IS NULL OR t.id <> _template_id OR g.id <> _template_group_id OR (g.id = _template_group_id AND _template_group_multiple))
                )
        ;
    END IF;
    */
    IF 
        p2_status = 'GENERATE' AND fin_bill__get_sift_status ('SIFT_EMPTY_CASE_ID') 
    THEN
        UPDATE fin_bill_generate 
        SET 
            is_sifted = TRUE, sifting_cause = 'Услуга без случая' 
        WHERE 
            bill_id = p1_bill_id AND NOT is_sifted AND case_id IS NULL
        ;
    END IF;
    IF 
        p2_status = 'GENERATE' AND fin_bill__get_sift_status ('SIFT_EMPTY_STEP_ID') 
    THEN
        UPDATE fin_bill_generate 
        SET 
            is_sifted = TRUE, sifting_cause = 'Услуга без посещения' 
        WHERE 
            bill_id = p1_bill_id AND NOT is_sifted AND step_id IS NULL
        ;
    END IF;
    --отсеивание случаев, имеющих оплаченные услуги в других счетах
    IF 
        p2_status = 'GENERATE' AND fin_bill__get_sift_status ('SIFT_OTHER_BILL_SERVICE') 
    THEN
        WITH cases AS 
        (
            SELECT 
                bill_id, case_id, array_agg (id) AS id_arr 
            FROM 
                fin_bill_generate
            WHERE 
                bill_id = p1_bill_id AND NOT is_sifted
            GROUP BY 1, 2
        ),
        t AS 
        (
            SELECT 
                c.bill_id, c.id_arr
            FROM 
                cases                                 AS c
                JOIN md_srv_rendered                  AS m ON c.case_id = m.case_id AND m.id <> ALL (c.id_arr)
                JOIN fin_bill_spec_item               AS i ON i.service_id = m.id
                JOIN fin_bill                         AS b ON b.id = i.bill_id
            WHERE 
                b.status_id IN (3, 4) AND i.status_id = 2 AND NOT i.is_deleted
            GROUP BY 1, 2
        )
        UPDATE fin_bill_generate AS f
        SET
            is_sifted = TRUE, sifting_cause = 'В случае присутствуют услуги, оплаченные в других счетах'
        FROM t
        WHERE
            f.bill_id = t.bill_id AND f.id = ANY (t.id_arr) AND NOT f.is_sifted
        ;
    END IF;
EXCEPTION
    WHEN NO_DATA_FOUND THEN RAISE EXCEPTION 'Отсутствуют данные по счёту';
END;
$$;

