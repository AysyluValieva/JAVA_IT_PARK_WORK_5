CREATE FUNCTION typing_gate(param json)
  RETURNS text
LANGUAGE plpgsql
AS $$
declare step JSON;
            service JSON;
            diagnos JSON;
            j JSON;
            i integer;
            ary alias for $1;
            begin
            ary=json_extract_path(param,'visits');
            FOR i IN 1..array_upper(ary,1) LOOP
            step := ary[i];
            RAISE NOTICE 'array element % is %', i, step;
            END LOOP;

            j=(select value from json_each(param) where key='id');
            return j;
            end;
$$;

