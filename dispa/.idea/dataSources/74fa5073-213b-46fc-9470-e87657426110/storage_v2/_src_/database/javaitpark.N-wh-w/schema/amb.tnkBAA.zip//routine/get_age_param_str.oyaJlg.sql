CREATE FUNCTION get_age_param_str(p_id integer)
  RETURNS text
LANGUAGE plpgsql
AS $$
declare
  str text;
begin
  str = (select 'Возраст от ' ||
(case
  when from_age_year>0 then (cast(from_age_year as text)||(case when from_age_year = 1 THEN ' года' else ' лет' end ))
  when from_age_month>0 then cast(from_age_month as text)|| (case when from_age_month = 1 THEN ' месяца' else ' месяцев' end)
  when from_age_day>0 then cast(from_age_day as text)|| (case when from_age_day = 1 THEN ' дня' else ' дней' end)
  when from_age_day=0 then cast(from_age_day as text)||' дней'
 end) || ' до '||
(case
  when to_age_year>0 then cast(to_age_year as text)|| (case when to_age_year = 1 THEN ' года' else ' лет' end )
  when to_age_month>0 then cast(to_age_month as text)|| (case when to_age_month = 1 THEN ' месяца' else ' месяцев' end)
  when to_age_day>0 then cast(to_age_day as text)|| (case when to_age_day = 1 THEN ' дня' else ' дней' end)
  when to_age_day=0 then cast(to_age_day as text)||' дней'
 end) )
  from amb.md_ambulance_priority_to_age where id = p_id;
  return str;
end;
$$;

