CREATE FUNCTION orphansabsence(xid integer, xmepid integer, xreasonid integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
 reasonCode character varying;
        begin
        select into reasonCode code from disp.md_absence_reason where id=xreasonid;
        if (reasonCode != '6') then
          if xid is not null and (select exists(select id from disp.md_disp_orphans_absence where id = xid))  then
            update disp.md_disp_orphans_absence set reason_id = xreasonid
                where id = xid;
          else
            insert into disp.md_disp_orphans_absence (id, event_patient_id, reason_id)
                values (nextval('disp.md_disp_orphans_absence_id_seq'), xmepid, xreasonid);
          end if;
          else
          delete from disp.md_disp_orphans_absence where event_patient_id=xmepid;
          end if;
        end;
$$;

