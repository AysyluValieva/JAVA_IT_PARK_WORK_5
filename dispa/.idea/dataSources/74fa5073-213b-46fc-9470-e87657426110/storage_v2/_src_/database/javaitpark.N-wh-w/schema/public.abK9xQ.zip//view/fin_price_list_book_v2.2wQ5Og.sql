CREATE VIEW fin_price_list_book_v2 AS
  SELECT fin_pl_position.id AS position_id,
    sr_service.id AS service_id,
    fin_price_modifier.id AS price_modifier_id,
    sr_res_group.name AS resource_name,
    pim_employee_position_resource.employee_position_id
   FROM (((((((fin_pl_pos_to_clinic_srv
     FULL JOIN fin_pl_position ON ((fin_pl_pos_to_clinic_srv.pl_position_id = fin_pl_position.id)))
     FULL JOIN sr_service ON ((fin_pl_pos_to_clinic_srv.clinic_service_id = sr_service.id)))
     LEFT JOIN fin_price_modifier ON ((fin_pl_position.price_list_id = fin_price_modifier.price_list_id)))
     LEFT JOIN sr_res_group_service ON ((sr_service.id = sr_res_group_service.srv_type_id)))
     LEFT JOIN sr_res_group_relationship ON (((sr_res_group_service.group_id = sr_res_group_relationship.group_id) AND (EXISTS ( SELECT 1
           FROM sr_res_role
          WHERE ((sr_res_role.id = sr_res_group_relationship.role_id) AND (sr_res_role.kind_id = 1)))))))
     LEFT JOIN sr_res_group ON ((sr_res_group.id = sr_res_group_relationship.group_id)))
     LEFT JOIN pim_employee_position_resource ON ((pim_employee_position_resource.id = sr_res_group_relationship.resource_id)))
  WHERE ((fin_price_modifier.scope_id IS NULL) OR (fin_price_modifier.scope_id = 1) OR (EXISTS ( SELECT fin_modifier_to_pl_pos.id
           FROM fin_modifier_to_pl_pos
          WHERE ((fin_modifier_to_pl_pos.price_modifier_id = fin_price_modifier.id) AND (fin_modifier_to_pl_pos.pl_position_id = fin_pl_position.id)))));

