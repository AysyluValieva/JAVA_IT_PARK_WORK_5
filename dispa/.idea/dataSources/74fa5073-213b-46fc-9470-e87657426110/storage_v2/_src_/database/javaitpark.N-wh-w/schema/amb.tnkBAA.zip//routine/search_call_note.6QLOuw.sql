CREATE FUNCTION search_call_note(xcall integer)
  RETURNS text
LANGUAGE plpgsql
AS $$
declare
	result text := '';
	note record;
  begin
  	for note in
    	select n.code as note,cast(cal.call_number as text) as num, to_char(cal.from_time,'dd.mm.yyyy') as dt,cise.code as service
        from amb.md_ambulance_call_note cn
        left join amb.md_ambulance_note n on cn.note_id = n.id
        left join amb.md_ambulance_call_double cd on cn.id = cd.call_note_id
        left join amb.md_ambulance_call cal on cd.call_id = cal.id
        left join amb.md_ambulance_call_selfrefused cs on cn.id = cs.call_note_id
        left join amb.md_ambulance_call_in_cityservice cic on cn.id = cic.call_note_id
        left join amb.md_ambulance_city_service cise on cic.service_id = cise.id
        where cn.call_id = xcall and cn.note_active and cn.note_type
        order by cn.id
    loop
      if result <> '' then result := result || ', '; end if;
      case
      	when (note.num <> '') then result := result || note.note||'(№'||note.num||' от '||note.dt||')';
      	when (note.service <> '') then result := result || note.service;
      	else result := result || note.note;
      end case;
    end loop;
	return result;
  end;
$$;

