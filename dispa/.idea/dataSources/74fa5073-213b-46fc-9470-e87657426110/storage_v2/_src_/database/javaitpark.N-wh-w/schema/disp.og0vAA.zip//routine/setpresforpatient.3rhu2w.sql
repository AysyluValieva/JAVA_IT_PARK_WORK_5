CREATE FUNCTION setpresforpatient(xcheckservices character varying, xeid integer, xeps integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
        checkserviceId json;
        begin
       if (select count(*) from disp.md_event_service_patient where event_patient_id = xeid) > 0 then
       delete from disp.md_event_service_patient where event_patient_id=xeid;
       end if;
        foreach checkserviceId in array array(select value from json_array_elements(cast(xcheckservices as json)))
                LOOP
                 insert into disp.md_event_service_patient (id, service_id, indiv_id, event_id,event_patient_id)
              values (
              nextval('disp.md_event_service_patient_id_seq'),
              (select id from disp.md_event_service where service_id=checkserviceId::text::int and event_id=(select event_id from disp.md_event_patient where id=xeid)),
               (select indiv_id from disp.md_event_patient where id=xeid),
               (select event_id from disp.md_event_patient where id=xeid),
               xeid);
                END LOOP;
          return 1;
        end;
$$;

