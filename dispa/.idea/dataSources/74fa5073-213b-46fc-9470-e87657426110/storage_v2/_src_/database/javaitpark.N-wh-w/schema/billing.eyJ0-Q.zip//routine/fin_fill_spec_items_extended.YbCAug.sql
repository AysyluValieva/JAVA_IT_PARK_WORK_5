CREATE FUNCTION fin_fill_spec_items_extended(p1_bill_id integer)
  RETURNS void
STRICT
LANGUAGE plpgsql
AS $$
BEGIN
    DELETE FROM billing.fin_bill_spec_item_extended WHERE bill_id = p1_bill_id
    ;
    INSERT INTO billing.fin_bill_spec_item_extended 
    (
        id, bill_id, cul, quantity, 
        patient_id, patient_gender_id, patient_name, patient_surname, patient_patr_name, patient_birth_date, 
        service_id, service_type_id, service_category_id, service_name, 
        policy_series, policy_number, policy_issuer_id, policy_issuer_name, 
        case_id, case_uid, init_goal_name, admission_date, outcome_name, main_diagnosis_id, main_diagnosis_code_name, 
        position_name, position_department_id, doctor_id, doctor_name
    )
        SELECT 
            i.id AS id, 
            i.bill_id,
            s.cul,
            s.srv_rendered_quantity::INTEGER AS quantity, 
            (SELECT patient_id FROM public.mc_case WHERE id = s.case_id LIMIT 1) AS patient_id,
            p.pat_gender_id AS patient_gender_id,
            p.pat_name AS patient_name,
            p.pat_surname AS patient_surname,
            p.pat_patr_name AS patient_patr_name,
            p.pat_birth_dt AS patient_birth_date,
            s.service_id,
            (SELECT type_id FROM public.sr_service WHERE id = s.service_id LIMIT 1) AS service_type_id, 
            (SELECT category_id FROM public.sr_service WHERE id = s.service_id LIMIT 1) service_category_id, 
            s.service_name,
            coalesce (i1.series || ' ', '') AS policy_series,
            coalesce (i1.number, '') AS policy_number,
            i1.issuer_id AS policy_issuer_id,
            coalesce (i1.issuer_short_name, '') AS policy_issuer_name,
            s.case_id AS case_id,
            c.uid AS case_uid,
            (SELECT name FROM public.mc_case_init_goal WHERE id = c.init_goal_id LIMIT 1) AS init_goal_name,
            s.step_admission_date AS admission_date,
            coalesce 
            (
                (SELECT n.name FROM public.mc_step AS t, public.mc_step_care_result AS n WHERE t.outcome_id = n.id AND t.id = s.step_id LIMIT 1), 
                (SELECT name FROM public.mc_step_care_result WHERE id = c.last_outcome_id LIMIT 1)
            ) AS outcome_name,
            c.main_diagnosis_id,
            coalesce 
            (
                (SELECT d.code || ' ' || d.name FROM public.md_diagnosis AS d, public.mc_diagnosis AS m WHERE d.id = m.diagnos_id AND m.id = s.step_main_diagnosis_id LIMIT 1),
                (SELECT code || ' ' || name FROM public.md_diagnosis WHERE id = c.main_diagnosis_id LIMIT 1), ''
            ) AS main_diagnosis_code_name,
            o.name AS position_name,
            o.department_id AS position_department_id,
            d.id AS doctor_id,
            d.name AS doctor_name
        FROM 
            public.fin_bill_spec_item AS i
            LEFT JOIN LATERAL 
            (
                SELECT 
                    srv_rendered_quantity, cul, service_id, service_name, case_id, step_main_diagnosis_id, step_admission_date, position_id, doctor_code, id_pac, step_id
                FROM
                    billing.fin_bill_steps
                WHERE
                    srv_rendered_id = i.service_id AND bill_id = i.bill_id
                LIMIT 1
            ) AS s ON TRUE
            LEFT JOIN LATERAL 
            (
                SELECT 
                    uid, active_policy_id, main_diagnosis_id, last_outcome_id, init_goal_id
                FROM 
                    billing.fin_bill_cases
                WHERE 
                    case_id = s.case_id AND bill_id = i.bill_id 
                LIMIT 1
            ) AS c ON TRUE
            LEFT JOIN LATERAL 
            (
                SELECT 
                    pat_surname, pat_name, pat_patr_name, pat_birth_dt, CASE WHEN pat_gender_code = 'MALE' THEN 1 WHEN pat_gender_code = 'FEMALE' THEN 2 ELSE 3 END AS pat_gender_id
                FROM 
                    billing.fin_bill_patients 
                WHERE
                    id_pac = s.id_pac AND bill_id = i.bill_id
                LIMIT 1
            ) AS p ON TRUE
            LEFT JOIN LATERAL 
            (
                SELECT 
                    series, number, issuer_short_name, issuer_id
                FROM 
                    billing.fin_bill_policy 
                WHERE
                    id = c.active_policy_id AND bill_id = i.bill_id 
                LIMIT 1
            ) AS i1 ON TRUE
            LEFT JOIN LATERAL (SELECT department_id, name FROM public.pim_position WHERE id = s.position_id LIMIT 1) AS o ON TRUE
            LEFT JOIN LATERAL
            (
                SELECT 
                    n.id, n.surname || ' ' || upper (left (n.name, 1)) || '.' || coalesce (' ' || upper (left (n.patr_name, 1)) || '.', '') AS name
                FROM 
                    public.pim_employee AS e, public.pim_individual AS n
                WHERE
                    e.individual_id = n.id AND e.id = nullif (s.doctor_code, '')::INTEGER
                LIMIT 1
            ) AS d ON TRUE
        WHERE
            i.bill_id = p1_bill_id
    ;
END;
$$;

