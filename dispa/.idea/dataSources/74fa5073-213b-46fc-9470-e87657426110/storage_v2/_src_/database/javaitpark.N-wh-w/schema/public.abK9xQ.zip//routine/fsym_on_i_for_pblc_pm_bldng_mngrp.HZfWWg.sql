CREATE FUNCTION fsym_on_i_for_pblc_pm_bldng_mngrp()
  RETURNS trigger
LANGUAGE plpgsql
AS $fun$
begin                                                                                                                                                                  
                                   
                                  if 1=1 and "public".sym_triggers_disabled() = 0 then                                                                                                 
                                    insert into "public".sym_data                                                                                                                     
                                    (table_name, event_type, trigger_hist_id, row_data, channel_id, transaction_id, source_node_id, external_data, create_time)                                        
                                    values(                                                                                                                                                            
                                      'pim_building',                                                                                                                                            
                                      'I',                                                                                                                                                             
                                      18281,                                                                                                                                             
                                      
          case when new."id" is null then '' else '"' || cast(cast(new."id" as numeric) as varchar) || '"' end||','||
          case when new."build_dt" is null then '' else '"' || to_char(new."build_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when new."code" is null then '' else '"' || replace(replace(cast(new."code" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."effective_area" is null then '' else '"' || cast(cast(new."effective_area" as numeric) as varchar) || '"' end||','||
          case when new."floor_area" is null then '' else '"' || cast(cast(new."floor_area" as numeric) as varchar) || '"' end||','||
          case when new."floors_number" is null then '' else '"' || cast(cast(new."floors_number" as numeric) as varchar) || '"' end||','||
          case when new."name" is null then '' else '"' || replace(replace(cast(new."name" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."power" is null then '' else '"' || cast(cast(new."power" as numeric) as varchar) || '"' end||','||
          case when new."volume" is null then '' else '"' || cast(cast(new."volume" as numeric) as varchar) || '"' end||','||
          case when new."project_type_id" is null then '' else '"' || cast(cast(new."project_type_id" as numeric) as varchar) || '"' end||','||
          case when new."land_id" is null then '' else '"' || cast(cast(new."land_id" as numeric) as varchar) || '"' end||','||
          case when new."address_id" is null then '' else '"' || cast(cast(new."address_id" as numeric) as varchar) || '"' end||','||
          case when new."ownership_pattern_id" is null then '' else '"' || cast(cast(new."ownership_pattern_id" as numeric) as varchar) || '"' end||','||
          case when new."org_id" is null then '' else '"' || cast(cast(new."org_id" as numeric) as varchar) || '"' end||','||
          case when new."from_dt" is null then '' else '"' || to_char(new."from_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when new."to_dt" is null then '' else '"' || to_char(new."to_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when new."building_function_id" is null then '' else '"' || cast(cast(new."building_function_id" as numeric) as varchar) || '"' end||','||
          case when new."building_technology_id" is null then '' else '"' || cast(cast(new."building_technology_id" as numeric) as varchar) || '"' end||','||
          case when new."on_the_books" is null then '' when new."on_the_books" then '"1"' else '"0"' end||','||
          case when new."beds_count" is null then '' else '"' || cast(cast(new."beds_count" as numeric) as varchar) || '"' end||','||
          case when new."hospital_beds_count" is null then '' else '"' || cast(cast(new."hospital_beds_count" as numeric) as varchar) || '"' end||','||
          case when new."ambulatory_beds_count" is null then '' else '"' || cast(cast(new."ambulatory_beds_count" as numeric) as varchar) || '"' end||','||
          case when new."rooms_count" is null then '' else '"' || cast(cast(new."rooms_count" as numeric) as varchar) || '"' end||','||
          case when new."rooms_area" is null then '' else '"' || cast(cast(new."rooms_area" as numeric) as varchar) || '"' end||','||
          case when new."daily_power" is null then '' else '"' || cast(cast(new."daily_power" as numeric) as varchar) || '"' end||','||
          case when new."ward_area" is null then '' else '"' || cast(cast(new."ward_area" as numeric) as varchar) || '"' end||','||
          case when new."ventilation" is null then '' when new."ventilation" then '"1"' else '"0"' end||','||
          case when new."project_number" is null then '' else '"' || replace(replace(cast(new."project_number" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."project_dt" is null then '' else '"' || to_char(new."project_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when new."reconstruction_dt" is null then '' else '"' || to_char(new."reconstruction_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when new."conditioning" is null then '' when new."conditioning" then '"1"' else '"0"' end||','||
          case when new."electric_supply" is null then '' else '"' || replace(replace(cast(new."electric_supply" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."cold_water_supply" is null then '' when new."cold_water_supply" then '"1"' else '"0"' end||','||
          case when new."medical_gas_supply" is null then '' when new."medical_gas_supply" then '"1"' else '"0"' end||','||
          case when new."common_gas_supply" is null then '' when new."common_gas_supply" then '"1"' else '"0"' end||','||
          case when new."passenger_lift" is null then '' when new."passenger_lift" then '"1"' else '"0"' end||','||
          case when new."medical_lift" is null then '' when new."medical_lift" then '"1"' else '"0"' end||','||
          case when new."fire_alarm_system" is null then '' when new."fire_alarm_system" then '"1"' else '"0"' end||','||
          case when new."security_alarm_system" is null then '' when new."security_alarm_system" then '"1"' else '"0"' end||','||
          case when new."police_call_button" is null then '' when new."police_call_button" then '"1"' else '"0"' end||','||
          case when new."evacuation_system" is null then '' when new."evacuation_system" then '"1"' else '"0"' end||','||
          case when new."fire_protection_water_supply" is null then '' when new."fire_protection_water_supply" then '"1"' else '"0"' end||','||
          case when new."fire_notification_system" is null then '' when new."fire_notification_system" then '"1"' else '"0"' end||','||
          case when new."fire_service_phone_connection" is null then '' when new."fire_service_phone_connection" then '"1"' else '"0"' end||','||
          case when new."fire_violation_count" is null then '' else '"' || cast(cast(new."fire_violation_count" as numeric) as varchar) || '"' end||','||
          case when new."has_evacuation_exit" is null then '' when new."has_evacuation_exit" then '"1"' else '"0"' end||','||
          case when new."respiratory_protection_supply" is null then '' when new."respiratory_protection_supply" then '"1"' else '"0"' end||','||
          case when new."stretcher_supply" is null then '' when new."stretcher_supply" then '"1"' else '"0"' end||','||
          case when new."nearest_fire_service_distance" is null then '' else '"' || cast(cast(new."nearest_fire_service_distance" as numeric) as varchar) || '"' end||','||
          case when new."building_type_construction_id" is null then '' else '"' || cast(cast(new."building_type_construction_id" as numeric) as varchar) || '"' end||','||
          case when new."building_type_overlap_id" is null then '' else '"' || cast(cast(new."building_type_overlap_id" as numeric) as varchar) || '"' end||','||
          case when new."building_state_id" is null then '' else '"' || cast(cast(new."building_state_id" as numeric) as varchar) || '"' end||','||
          case when new."hot_water_supply_type_id" is null then '' else '"' || cast(cast(new."hot_water_supply_type_id" as numeric) as varchar) || '"' end||','||
          case when new."heating_system_type_id" is null then '' else '"' || cast(cast(new."heating_system_type_id" as numeric) as varchar) || '"' end||','||
          case when new."sewer_type_id" is null then '' else '"' || cast(cast(new."sewer_type_id" as numeric) as varchar) || '"' end||','||
          case when new."communication_channel_type_id" is null then '' else '"' || cast(cast(new."communication_channel_type_id" as numeric) as varchar) || '"' end||','||
          case when new."latitude" is null then '' else '"' || cast(cast(new."latitude" as numeric) as varchar) || '"' end||','||
          case when new."longitude" is null then '' else '"' || cast(cast(new."longitude" as numeric) as varchar) || '"' end,                                                                                                                                                      
                                      'public_pim_building_default',                                                                                                                                                
                                      txid_current(),                                                                                                                                               
                                      "public".sym_node_disabled(),                                                                                                                   
                                      null,                                                                                                                                               
                                      CURRENT_TIMESTAMP                                                                                                                
                                    );                                                                                                                                                                 
                                  end if;                                                                                                                                                              
                                                                                                                                                                               
                                  return null;                                                                                                                                                         
                                end;
$fun$;

