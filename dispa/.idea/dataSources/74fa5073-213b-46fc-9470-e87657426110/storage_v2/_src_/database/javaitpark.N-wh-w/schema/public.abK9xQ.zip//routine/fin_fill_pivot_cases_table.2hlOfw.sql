CREATE FUNCTION fin_fill_pivot_cases_table(p1_bill_id integer)
  RETURNS void
STRICT
LANGUAGE plpgsql
AS $$
DECLARE 
    _code_ogrn_org_id INTEGER;
    _code_oms_id INTEGER;
    _code_snils_ind_id INTEGER;
BEGIN
    /*
        current version date 05.12.2014
    */
    IF EXISTS (SELECT 1 FROM fin_bill_cases WHERE bill_id = p1_bill_id) THEN DELETE FROM fin_bill_cases WHERE bill_id = p1_bill_id; END IF;
    
    _code_ogrn_org_id  := (SELECT id FROM pim_code_type WHERE code = 'OGRN'    );
    _code_oms_id       := (SELECT id FROM pim_code_type WHERE code = 'CODE_OMS');
    _code_snils_ind_id := (SELECT id FROM pim_code_type WHERE code = 'SNILS'   );
    --------------общие сведения------------------
    INSERT INTO fin_bill_cases 
    (
        bill_id, case_id, patient_id, patient_age, active_policy_id, belonging_type, new_born, id_pac, representative_id, 
        step_cnt, open_date, close_date, last_id, last_outcome_date, item_id_arr
    )
        SELECT
            bill_id, case_id, patient_id, patient_age, active_policy_id, belonging_type, new_born, id_pac, representative_id, 
            step_cnt, case_open_date, case_close_date, closing_step_id, case_close_date, array_agg (fin_bill_spec_item_id)
        FROM 
            fin_bill_generate 
        WHERE 
            bill_id = p1_bill_id AND NOT is_sifted AND case_id IS NOT NULL
        GROUP BY 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14
    ;
    WITH cases AS 
    (
        SELECT
            f.bill_id, 
            f.case_id,
            coalesce (trim (c.uid), '') AS uid,
            c.admission_type_id,
            t.case_mode_id,
            c.case_type_id,
            coalesce (trim (t.code), '') AS case_type_code,
            c.care_regimen_id,
            m.code::TEXT AS care_regimen_code,
            coalesce (trim (l.code), '') AS care_level_code,
            c.care_level_id,
            coalesce (trim (r.code), '') AS repeat_count_code,
            coalesce (trim (p.code), '') AS payment_method_code,
            c.init_goal_id,
            ARRAY [coalesce (trim (g.code), ''), coalesce (trim (g.e_code), '')] AS init_goal_code_arr,
            coalesce (trim (o.code), '') AS care_providing_form_code,
            coalesce (trim (i.code), '') AS provision_condition_code,
            coalesce (trim (n.code), '') AS ref_clinic_code, 
            coalesce (trim (s.code), '') AS ref_clinic_code_oms
         FROM 
            fin_bill_cases                        AS f
            JOIN mc_case                          AS c ON c.id = f.case_id
            LEFT JOIN mc_payment_method           AS p ON p.id = c.payment_method_id
            LEFT JOIN mc_case_type                AS t ON t.id = c.case_type_id
            LEFT JOIN mc_repeat_count             AS r ON r.id = c.repeat_count_id
            LEFT JOIN mc_care_regimen             AS m ON m.id = c.care_regimen_id
            LEFT JOIN mc_care_level               AS l ON l.id = c.care_level_id
            LEFT JOIN mc_case_init_goal           AS g ON g.id = c.init_goal_id
            LEFT JOIN md_care_providing_form      AS o ON o.id = c.care_providing_form_id
            LEFT JOIN md_care_provision_condition AS i ON i.id = c.provision_condition_id
            LEFT JOIN md_referral                 AS e ON e.id = c.referral_id
            LEFT JOIN md_clinic                   AS n ON n.id = e.ref_organization_id
            LEFT JOIN pim_org_code                AS s ON s.org_id = n.id AND s.type_id = _code_oms_id
        WHERE
            f.bill_id = p1_bill_id
    )
    UPDATE fin_bill_cases AS f
    SET
        uid                      = c.uid                     ,
        admission_type_id        = c.admission_type_id       ,
        case_mode_id             = c.case_mode_id            ,
        case_type_id             = c.case_type_id            ,
        case_type_code           = c.case_type_code          ,
        care_regimen_id          = c.care_regimen_id         ,
        care_regimen_code        = c.care_regimen_code       ,
        care_level_id            = c.care_level_id           ,
        care_level_code          = c.care_level_code         ,
        repeat_count_code        = c.repeat_count_code       ,
        payment_method_code      = c.payment_method_code     ,
        init_goal_id             = c.init_goal_id            ,
        init_goal_code_arr       = c.init_goal_code_arr      ,
        ref_clinic_code          = c.ref_clinic_code         ,
        ref_clinic_code_oms      = c.ref_clinic_code_oms     ,
        care_providing_form_code = c.care_providing_form_code,
        provision_condition_code = c.provision_condition_code 
    FROM 
        cases AS c
    WHERE
        f.bill_id = c.bill_id AND f.case_id = c.case_id
    ;
    ------------------пациент------------------
    WITH patient AS 
    (
        SELECT
            f.bill_id, 
            f.case_id,
            CASE WHEN f.new_born THEN concat (i.gender_id, to_char (i.birth_dt, 'DDMMYY'), coalesce (a.newborn_number, 1)::VARCHAR(2)) ELSE '0' END AS new_born_part,
            CASE WHEN f.new_born THEN a.birthweight ELSE NULL END AS birthweight,
            array_agg (coalesce (trim (p.ui_code), '')) AS os_sluch
         FROM 
            fin_bill_cases                  AS f
            JOIN pim_individual             AS i ON i.id = f.patient_id
            JOIN pci_patient                AS a ON a.id = i.id
            LEFT JOIN pci_patient_part_case AS c ON c.patient_id = a.id
                                                     AND (f.open_date, f.close_date) OVERLAPS (coalesce (c.from_dt, DATE '1900-01-01'), coalesce (c.to_dt, DATE '4000-01-01'))
            LEFT JOIN pci_part_case         AS p ON p.id = c.part_case_id 
        WHERE
            f.bill_id = p1_bill_id
        GROUP BY 1, 2, 3, 4
    )
    UPDATE fin_bill_cases AS f
    SET
        new_born_part   = p.new_born_part,
        pat_birthweight = p.birthweight,
        pat_os_sluch    = p.os_sluch
    FROM 
        patient AS p
    WHERE
        f.bill_id = p.bill_id AND f.case_id = p.case_id
    ;
    ----------------представитель----------------
    WITH representative AS 
    (
        SELECT
            f.bill_id, 
            f.case_id,
            array_agg (coalesce (trim (p.ui_code), '')) AS os_sluch
         FROM 
            fin_bill_cases                  AS f
            JOIN pci_patient                AS a ON a.id = f.representative_id
            LEFT JOIN pci_patient_part_case AS c ON c.patient_id = a.id
                                                     AND (f.open_date, f.close_date) OVERLAPS (coalesce (c.from_dt, DATE '1900-01-01'), coalesce (c.to_dt, DATE '4000-01-01'))
            LEFT JOIN pci_part_case         AS p ON p.id = c.part_case_id 
        WHERE
            f.bill_id = p1_bill_id
        GROUP BY 1, 2
    )
    UPDATE fin_bill_cases AS f
    SET
        rep_os_sluch = r.os_sluch
    FROM 
        representative AS r
    WHERE
        f.bill_id = r.bill_id AND f.case_id = r.case_id
    ;
    --вес новорождённого для пациента-матери--
    WITH t AS (
        SELECT 
            f.bill_id, f.case_id, array_agg (b.birthweight) AS birthweight
        FROM
            fin_bill_cases                AS f
            JOIN pim_individual           AS i ON i.id = f.patient_id
            JOIN pim_party_relation_party AS m ON m.party_id = i.id
            JOIN pim_party_relation_party AS c ON c.rel_id = m.rel_id
            JOIN pim_individual           AS k ON k.id = c.party_id
            JOIN pci_patient              AS b ON b.id = k.id
        WHERE
            f.bill_id = p1_bill_id AND i.gender_id = 2 AND m.side_id = 1 AND c.side_id = 2 AND k.birth_dt BETWEEN f.open_date AND f.close_date AND b.birthweight < 2500
        GROUP BY 1, 2
    )
    UPDATE fin_bill_cases AS f
    SET 
        birthweight = t.birthweight
    FROM t
    WHERE 
        f.bill_id = t.bill_id AND f.case_id = t.case_id
    ;
    -----------------диагнозы------------------
    WITH 
    m AS 
    (
        SELECT 
            f.case_id, d.id AS diag_id, CASE WHEN d.id IS NULL THEN NULL ELSE coalesce (trim (d.code), '') END AS diag_code, trim (i.code) AS inj_code, trim (n.code) AS dis_code
        FROM 
            fin_bill_cases            AS f
            JOIN mc_case              AS c ON c.id = f.case_id
            LEFT JOIN mc_diagnosis    AS m ON m.id = c.main_diagnos_id
            LEFT JOIN md_diagnosis    AS d ON d.id = m.diagnos_id
            LEFT JOIN mc_injury_type  AS i ON i.id = m.injury_type_id
            LEFT JOIN mc_disease_type AS n ON n.id = m.disease_type_id
        WHERE
            f.bill_id = p1_bill_id 
    ),
    s AS 
    (
        SELECT 
            f.case_id, 
            (array_agg (d.id                         ORDER BY m.stage_id DESC NULLS LAST, m.establishment_date DESC NULLS LAST, m.id DESC))[1] AS diag_id, 
            (array_agg (coalesce (trim (d.code), '') ORDER BY m.stage_id DESC NULLS LAST, m.establishment_date DESC NULLS LAST, m.id DESC))[1] AS diag_code, 
            (array_agg (coalesce (trim (i.code), '') ORDER BY m.stage_id DESC NULLS LAST, m.establishment_date DESC NULLS LAST, m.id DESC))[1] AS inj_code,
            (array_agg (coalesce (trim (n.code), '') ORDER BY m.stage_id DESC NULLS LAST, m.establishment_date DESC NULLS LAST, m.id DESC))[1] AS dis_code
        FROM 
            fin_bill_cases            AS f
            LEFT JOIN mc_diagnosis    AS m ON m.case_id = f.case_id AND coalesce (m.is_main, FALSE)
            LEFT JOIN md_diagnosis    AS d ON d.id = m.diagnos_id
            LEFT JOIN mc_injury_type  AS i ON i.id = m.injury_type_id
            LEFT JOIN mc_disease_type AS n ON n.id = m.disease_type_id
        WHERE
            f.bill_id = p1_bill_id 
        GROUP BY 1
    ),
    r AS
    (
        SELECT 
            f.case_id, (array_agg (DISTINCT coalesce (trim (d.code), '')))::VARCHAR[] AS diag_arr
        FROM 
            fin_bill_cases         AS f
            LEFT JOIN mc_diagnosis AS m ON m.case_id = f.case_id AND m.type_id = 2
            LEFT JOIN md_diagnosis AS d ON d.id = m.diagnos_id
        WHERE
            f.bill_id = p1_bill_id 
        GROUP BY 1
    ),
    c AS 
    (
        SELECT 
            f.case_id, (array_agg (DISTINCT coalesce (trim (d.code), '')))::VARCHAR[] AS diag_arr
        FROM 
            fin_bill_cases         AS f
            LEFT JOIN mc_diagnosis AS m ON m.case_id = f.case_id AND m.type_id = 3
            LEFT JOIN md_diagnosis AS d ON d.id = m.diagnos_id
        WHERE
            f.bill_id = p1_bill_id 
        GROUP BY 1
    )
    UPDATE fin_bill_cases AS f
    SET 
        main_diagnosis_id          = coalesce (m.diag_id, s.diag_id)    ,
        main_diagnosis_code        = coalesce (m.diag_code, s.diag_code),
        injury_code                = coalesce (m.inj_code, s.inj_code)  ,
        disease_type_code          = coalesce (m.dis_code, s.dis_code)  ,
        related_diagnosis_arr      = r.diag_arr                         ,
        complication_diagnosis_arr = c.diag_arr
    FROM m, s, r, c
    WHERE
        f.bill_id = p1_bill_id AND f.case_id = m.case_id AND f.case_id = s.case_id AND f.case_id = r.case_id AND f.case_id = c.case_id
    ;
    ----------------первый шаг-----------------
    WITH cte AS 
    (
        SELECT 
            f.bill_id, f.case_id, (array_agg (s.id ORDER BY s.admission_date, s.admission_time NULLS FIRST, s.id))[1] AS step_id
        FROM 
            fin_bill_cases AS f, mc_step AS s
        WHERE 
            f.bill_id = p1_bill_id AND s.case_id = f.case_id
        GROUP BY 1, 2
    )
    UPDATE fin_bill_cases AS f
    SET 
        first_id             = s.id                        ,
        first_diagnosis_id   = d.id                        ,
        first_diagnosis_code = coalesce (trim (d.code), ''),
        first_admission_date = s.admission_date            ,
        first_outcome_date   = s.outcome_date               
    FROM 
        cte                    AS t
        JOIN mc_step           AS s ON s.id = t.step_id AND s.case_id = t.case_id 
        LEFT JOIN mc_diagnosis AS m ON m.id = s.main_diagnosis_id AND coalesce (m.is_main, FALSE)
        LEFT JOIN md_diagnosis AS d ON d.id = m.diagnos_id
    WHERE 
        f.bill_id = t.bill_id AND f.case_id = t.case_id
    ;
    ----------------крайний шаг----------------
    WITH t AS 
    (
        SELECT 
            f.bill_id,
            f.case_id,
            r.id AS result_id,
            s.outcome_id,
            coalesce (trim (r.code), '') AS result_code,
            coalesce (r.is_closed, FALSE) AS is_closed,
            coalesce (trim (u.code), '') AS care_result,
            coalesce (trim (n.code), '') AS hsp_department_code,
            coalesce (trim (n.name), '') AS hsp_department_name,
            p.employee_id AS doctor_code,
            coalesce (trim (d.code), '') AS department_code,
            coalesce (trim (d.name), '') AS department_name,
            ARRAY [coalesce (trim (c.code), ''), coalesce (trim (c.e_code), '')] AS speciality_code_arr,
            coalesce (trim (o.code), '') AS profile_code,
            coalesce (trim (a.code), '') AS csg_code,
            coalesce (trim (m.code), '') AS mes_code,
            coalesce (trim (v.code), '') AS vmp_type_code,
            coalesce (trim (w.code), '') AS vmp_method_code,
            regexp_replace 
            (
                replace (replace ((array_agg (coalesce (trim (i.code), '') ORDER BY i.issue_dt DESC NULLS LAST))[1], '-', ''), ' ', ''), 
                '(...)(...)(...)(..)', 
                '\1-\2-\3 \4'
            ) AS snils
        FROM 
            fin_bill_cases                          AS f
            JOIN mc_step                            AS s ON s.id = f.last_id
            LEFT JOIN mc_step_result                AS r ON r.id = s.result_id
            LEFT JOIN mc_step_care_result           AS u ON u.id = s.outcome_id
            LEFT JOIN hsp_record                    AS h ON h.id = s.id
            LEFT JOIN pim_department                AS n ON n.id = h.department_id
            LEFT JOIN sr_res_group                  AS g ON g.id = s.res_group_id
            LEFT JOIN pim_employee_position         AS p ON p.id = g.responsible_id
            LEFT JOIN pim_employee                  AS e ON e.id = p.employee_id
            LEFT JOIN pim_position                  AS t ON t.id = p.position_id
            LEFT JOIN pim_department                AS d ON d.id = t.department_id
            LEFT JOIN pim_speciality                AS c ON c.id = t.speciality_id
            LEFT JOIN md_profile                    AS o ON o.id = s.profile_id
            LEFT JOIN md_mes                        AS m ON m.id = s.mes_id
            LEFT JOIN md_clinical_statistical_group AS a ON a.id = s.csg_id
            LEFT JOIN mc_vmp_type                   AS v ON v.id = s.vmp_type_id
            LEFT JOIN mc_vmp_method                 AS w ON w.id = s.vmp_method_id
            LEFT JOIN pim_indiv_code                AS i ON i.indiv_id = e.individual_id AND i.type_id = _code_snils_ind_id
        WHERE 
            f.bill_id = p1_bill_id AND f.case_id = s.case_id
        GROUP BY 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18
    )
    UPDATE fin_bill_cases AS f
    SET 
        last_outcome_id          = t.outcome_id         ,
        last_result_id           = t.result_id          ,
        last_result_code         = t.result_code        ,
        last_is_closed           = t.is_closed          ,
        last_care_result         = t.care_result        ,
        last_hsp_department_code = t.hsp_department_code,
        last_hsp_department_name = t.hsp_department_name,
        last_department_code     = t.department_code    ,
        last_department_name     = t.department_name    ,
        last_speciality_code_arr = t.speciality_code_arr,
        last_doctor_code         = t.doctor_code        ,
        last_profile_code        = t.profile_code       ,
        last_mes_code            = t.mes_code           ,
        last_csg_code            = t.csg_code           ,
        last_vmp_type_code       = t.vmp_type_code      ,
        last_vmp_method_code     = t.vmp_method_code    ,
        last_doctor_snils        = t.snils               
    FROM t
    WHERE 
        f.bill_id = t.bill_id AND f.case_id = t.case_id
    ;
END;
$$;

