CREATE FUNCTION sickdoc_delete(p_id integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
  l_family_member_id1 INTEGER;
  l_family_member_id2 INTEGER;
BEGIN
  SELECT
    family_member_1_id,
    family_member_2_id
  FROM sickdoc.sickdoc_extended
  WHERE id = $1
  INTO l_family_member_id1, l_family_member_id2;

  DELETE FROM sickdoc.family_member
  WHERE id IN (l_family_member_id1, l_family_member_id2);

  DELETE FROM sickdoc.sickdoc_extended
  WHERE id = $1;

  DELETE FROM sickdoc.sickdoc
  WHERE id = $1;

END;
$$;

