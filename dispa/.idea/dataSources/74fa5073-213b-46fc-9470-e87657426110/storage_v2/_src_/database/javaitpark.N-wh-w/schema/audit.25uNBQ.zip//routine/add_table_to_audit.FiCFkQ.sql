CREATE FUNCTION add_table_to_audit(_table character varying, _table_hierarchy_id integer, _partition_period_id integer, _position integer, _audit_active boolean, _created_by integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
                  row_id        INTEGER;
                  active_status VARCHAR;
                  period_code   VARCHAR;
                BEGIN
                  SELECT id
                  INTO row_id
                  FROM audit.table_setting ts
                  WHERE concat(ts.table_schema, '.', ts.table_name) = _table;

                  IF row_id ISNULL
                  THEN
                    --create base audit table
                    IF (SELECT EXISTS(
                        SELECT *
                        FROM information_schema.tables
                        WHERE
                          table_schema = 'audit' AND
                          table_name = replace(_table, '.', '$'))) = FALSE
                    THEN
                      EXECUTE audit.add_table(_table :: TEXT);
                    ELSE _partition_period_id = 1;
                    END IF;

                    --create audit.table_setting row
                    INSERT INTO
                      audit.table_setting (
                        table_schema,
                        table_name,
                        table_hierarchy_id,
                        partition_period_id,
                        position,
                        audit_active,
                        is_has_default_primary_key)
                    VALUES (
                      split_part(_table, '.', 1),
                      split_part(_table, '.', 2),
                      _table_hierarchy_id,
                      _partition_period_id,
                      _position,
                      _audit_active,
                      audit.check_table_has_default_primary_key(_table)
                    );

                    SELECT code
                    INTO period_code
                    FROM audit.partition_period
                    WHERE id = _partition_period_id;

                    --create trigger
                    EXECUTE format('
                      CREATE TRIGGER audit_partitioning_trigger
                      AFTER INSERT OR UPDATE OR DELETE
                      ON %s
                      FOR EACH ROW
                      EXECUTE PROCEDURE audit.partitioning_trigger_fun(%s)', _table, period_code);
                  ELSE
                    EXECUTE audit.edit_table_setting_row(
                        row_id, _table_hierarchy_id, _partition_period_id, _position, _audit_active, _created_by);
                  END IF;

                  --enable / disable trigger
                  IF _audit_active
                  THEN active_status = 'ENABLE';
                  ELSE active_status = 'DISABLE'; END IF;
                  EXECUTE format('ALTER TABLE %1$s %2$s TRIGGER audit_partitioning_trigger', _table, active_status);

                  --drop trigger audit_trigger_full
                  EXECUTE format('DROP TRIGGER IF EXISTS audit_trigger_full ON %1$s', _table);
                END;
$$;

