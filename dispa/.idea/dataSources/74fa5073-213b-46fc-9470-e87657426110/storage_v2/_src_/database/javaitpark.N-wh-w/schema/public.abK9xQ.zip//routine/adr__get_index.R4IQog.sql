CREATE FUNCTION adr__get_index(param_id integer)
  RETURNS text
STRICT
LANGUAGE plpgsql
AS $$
DECLARE
    index_to_ret TEXT;
    indexBook    INT4;

  BEGIN
    SELECT
      ac.value
    FROM address_code ac
      INNER JOIN address_element_data aed
        ON ac.element_id = aed.id
    WHERE aed.path @> (SELECT
                         path
                       FROM address_element_data
                       WHERE id = param_id) AND ac.book_id = (SELECT
                                                                adr__get_index_book())
    ORDER BY aed.id DESC
    INTO index_to_ret;
    RETURN index_to_ret;
  END;
$$;

