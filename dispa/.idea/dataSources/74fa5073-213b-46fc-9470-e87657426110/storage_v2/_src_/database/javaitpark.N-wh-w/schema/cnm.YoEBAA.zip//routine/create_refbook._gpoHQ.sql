CREATE FUNCTION create_refbook(full_table_name text, sequence_name text, full_name character varying, short_name character varying, column_props cnm.ref_col_metadata[])
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
	  from_dt_column text := 'from_dt';
	  to_dt_column text := 'to_dt';
	  records_count int;
	  _full_name varchar(255);
	  _short_name varchar(255);
	  _sequence_name text;
	  identifier_column_name varchar(255);
	  table_name varchar(255);
	  schema_name varchar(255);
	  column_name text;
	  column_description text;
	  user_column_description text;
	  is_display_name bool;
  begin
    -- determine schema and table_name
    IF (position('.' in full_table_name) = 0) THEN
	    EXECUTE 'SELECT count(pg_namespace.nspname) FROM pg_class JOIN pg_namespace ON pg_class.relnamespace = pg_namespace.oid WHERE relname = $1'
	    INTO records_count
	    USING full_table_name;

	    IF (records_count > 1) THEN
		    RAISE EXCEPTION 'Table with the name "%" exists in more than one scheme', full_table_name
		    USING HINT = 'Please define schema name clearly through the point';
	    END IF;

	    table_name = full_table_name;
	    EXECUTE 'SELECT pg_namespace.nspname FROM pg_class JOIN pg_namespace ON pg_class.relnamespace = pg_namespace.oid WHERE relname = $1'
	    INTO schema_name
            USING full_table_name;
    ELSE
      table_name := substring(full_table_name from position('.' in full_table_name)+1);
      schema_name := substring(full_table_name from 0 for position('.' in full_table_name));
    END IF;
    RAISE NOTICE 'schema_name %, table_name %',schema_name,table_name;

    -- check columns from_dt and to_dt
    EXECUTE 'SELECT count(1) FROM pg_attribute WHERE attrelid = (SELECT pg_class.oid FROM pg_class JOIN pg_namespace ON pg_class.relnamespace = pg_namespace.oid WHERE relname = $1 and nspname = $2) AND attname = $3'
    INTO records_count
    USING table_name, schema_name, from_dt_column;

    IF (records_count = 0) THEN
	    EXECUTE 'ALTER TABLE '|| (schema_name||'.'||table_name)::regclass ||' ADD COLUMN '|| from_dt_column ||' date';
    END IF;

    EXECUTE 'SELECT count(1) FROM pg_attribute WHERE attrelid = (SELECT pg_class.oid FROM pg_class JOIN pg_namespace ON pg_class.relnamespace = pg_namespace.oid WHERE relname = $1 and nspname = $2) AND attname = $3'
    INTO records_count
    USING table_name, schema_name, to_dt_column;

    IF (records_count = 0) THEN
	    EXECUTE 'ALTER TABLE '|| (schema_name||'.'||table_name)::regclass ||' ADD COLUMN '|| to_dt_column ||' date';
    END IF;

    -- create internal_refbook
    IF (full_name is null) THEN
      EXECUTE 'SELECT description FROM pg_description JOIN pg_class ON pg_description.objoid = pg_class.oid JOIN pg_namespace ON pg_class.relnamespace = pg_namespace.oid WHERE relname = $1 and nspname = $2'
      INTO _full_name
      USING table_name, schema_name;
    ELSE
	    _full_name := full_name;
    END IF;

    IF (short_name is null) THEN
	    _short_name := _full_name;
    ELSE
	    _short_name := short_name;
    END IF;

    BEGIN
      EXECUTE 'SELECT pg_attribute.attname FROM pg_attribute
	      INNER JOIN pg_class ON pg_attribute.attrelid = pg_class.oid
              INNER JOIN pg_namespace ON pg_class.relnamespace = pg_namespace.oid
              INNER JOIN pg_index ON pg_index.indrelid = pg_class.oid
              WHERE pg_class.relname = $1 AND nspname = $2 AND pg_attribute.attnum = any(pg_index.indkey) AND indisprimary'
      INTO STRICT identifier_column_name
      USING table_name, schema_name;
      EXCEPTION WHEN NO_DATA_FOUND THEN
          RAISE NOTICE 'no primary key - no identifier column';
          WHEN TOO_MANY_ROWS THEN
          RAISE NOTICE 'complex primary key - no identifier column';
    END;
    RAISE NOTICE 'identifier_column_name - %', identifier_column_name;

    IF (sequence_name is not null) THEN
	    _sequence_name := sequence_name;
    ELSEIF (identifier_column_name is not null) THEN
	    _sequence_name := table_name||'_'||identifier_column_name||'_seq';

      EXECUTE 'SELECT count(1) FROM pg_class INNER JOIN pg_namespace ON pg_class.relnamespace = pg_namespace.oid WHERE relkind = ''S'' AND relname = $1 AND nspname = $2'
      INTO records_count
      USING _sequence_name, schema_name;

      IF (records_count = 0) THEN
        _sequence_name := NULL;
      END IF;
    END IF;

    INSERT INTO cnm.refbook(id, full_name, short_name, object_id, source_id) VALUES(nextval('cnm.refbook_id_seq'), _full_name, _short_name, currval('cnm.refbook_id_seq'), (select id from cnm.refbook_source where code = 'INTERNAL'));
    INSERT INTO cnm.internal_refbook(id, schema_name, table_name, sequence_name, is_read_only) VALUES(currval('cnm.refbook_id_seq'), schema_name, table_name, _sequence_name, false);

    -- create refbook_version
    INSERT INTO cnm.refbook_version(id, refbook_id, date) VALUES(nextval('cnm.refbook_version_id_seq'), currval('cnm.refbook_id_seq'), current_date);

    -- create refbook_column's
    FOR column_name, column_description IN
      EXECUTE 'SELECT pg_attribute.attname, pg_description.description FROM pg_attribute
        INNER JOIN pg_class ON pg_class.oid = pg_attribute.attrelid
        INNER JOIN pg_namespace ON pg_class.relnamespace = pg_namespace.oid
        LEFT JOIN pg_description ON pg_description.objoid = pg_class.oid and pg_description.objsubid = pg_attribute.attnum
        WHERE pg_class.relname = $1 AND nspname = $2 AND attnum > 0 AND NOT attisdropped'
      USING table_name, schema_name
    LOOP
      EXECUTE 'select a.column_description, a.is_display_name from unnest($1) a where a.column_name = $2'
      INTO user_column_description, is_display_name
      USING column_props, column_name;

      IF (user_column_description is not null) THEN
        column_description := user_column_description;
      END IF;

      INSERT INTO cnm.refbook_column(id, name, title, refbook_version_id, is_display_name) VALUES(nextval('cnm.refbook_column_id_seq'), column_name, column_description, currval('cnm.refbook_version_id_seq'), COALESCE(is_display_name, false));

      IF (identifier_column_name IS NOT NULL AND identifier_column_name = column_name) THEN
        UPDATE cnm.internal_refbook set identifier_column_id = currval('cnm.refbook_column_id_seq') where id = currval('cnm.refbook_id_seq');
      END IF;
    END LOOP;

  end;
$$;

