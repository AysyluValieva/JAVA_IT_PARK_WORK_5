CREATE FUNCTION apda_check_district_by_organization_criterion(ids integer[], district_id integer)
  RETURNS boolean
LANGUAGE plpgsql
AS $$
BEGIN
  RETURN (SELECT exists(SELECT 1
                        FROM md_district_organization o
                        WHERE o.district_id = $2 AND o.organization_id = ANY ($1)
                        LIMIT 1));
END;
$$;

