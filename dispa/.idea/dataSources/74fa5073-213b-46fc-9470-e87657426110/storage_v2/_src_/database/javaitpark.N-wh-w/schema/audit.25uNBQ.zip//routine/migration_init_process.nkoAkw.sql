CREATE FUNCTION migration_init_process(_id integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
  _table_name               VARCHAR;
  _count_row_in_old_aud     BIGINT;
  _table_setting_record     RECORD;
  _none_partition_period_id INT;
  _task_id                  INT;
BEGIN
  SELECT table_name INTO _table_name FROM audit.migration_table WHERE id = _id;

  SELECT count_row INTO _count_row_in_old_aud FROM audit.migration_table WHERE id = _id;

  --удаляем дубликаты
  IF _count_row_in_old_aud > 0
  THEN
    EXECUTE audit.migration_delete_double_rows(_table_name);

    --проверяем сколько записей осталось в _aud - таблице
    _count_row_in_old_aud = audit.migration_get_count_row_in_table(null, replace(_table_name, 'public.', ''));

    UPDATE audit.migration_table SET count_row = _count_row_in_old_aud WHERE id = _id;
  END IF;

  SELECT * INTO _table_setting_record
  FROM audit.table_setting
  WHERE table_schema = 'public' AND table_name = replace(replace(_table_name, '_aud', ''), 'public.', '');

  IF _table_setting_record NOTNULL
  THEN
    IF _count_row_in_old_aud > 0
    THEN
      --закрываем все активные таски на перепартицирование для данной таблицы
      UPDATE audit.repartitioning_task
      SET status_id = (SELECT id
                       FROM audit.repartitioning_task_status
                       WHERE code = 'CANCELED')
      WHERE table_setting_id = _table_setting_record.id;

      --проверяем какой задан период партицирования
      _none_partition_period_id = (SELECT id
                                   FROM audit.partition_period
                                   WHERE code = 'NONE');

      IF _table_setting_record.partition_period_id != _none_partition_period_id
      THEN
        --создаем таск на перепартицирование к NONE
        INSERT INTO audit.repartitioning_task (
          table_setting_id,
          from_partition_period_id,
          to_partition_period_id,
          status_id,
          mode_type_id,
          created_at,
          created_by)
        VALUES (_table_setting_record.id, _table_setting_record.partition_period_id, _none_partition_period_id, 1, 1,
                current_timestamp, NULL)
        RETURNING id
          INTO _task_id;

        --запускаем таск
        EXECUTE audit.repartitioning_task(_task_id);

      END IF;
    END IF;
  ELSE
    --создаем инфраструктуру нового аудита
    EXECUTE audit.add_table_to_audit(
        replace(_table_name, '_aud', ''), 1, (SELECT id FROM audit.partition_period WHERE code = 'NONE'), 1000, TRUE,
        NULL);
  END IF;

  IF _count_row_in_old_aud = 0 THEN RETURN; END IF;

  --создаем индекс для первичного ключа (только для нормальных первичных ключей)
  IF (SELECT base_table_has_default_primary_key
      FROM audit.migration_table
      WHERE id = _id)
  THEN
    IF (SELECT exists(
        SELECT 1
        FROM pg_class c
        WHERE c.relname = concat(replace(_table_name, 'public.', ''), 'id_idx')
              AND c.relkind = 'i')) = FALSE
    THEN
      EXECUTE format('CREATE INDEX %1$s ON %2$s USING BTREE (id)',
                     concat(replace(_table_name, 'public.', ''), 'id_idx'), _table_name);
    END IF;

    --создаем запись о процессе и заполняем метаданными
    EXECUTE format('
      INSERT INTO audit.migration_batch_process (table_id, count_aud_row, min_row_id, max_row_id,
        rev_type_parent_table_name)
      SELECT %1$s, %2$s, min(id), max(id), audit.migration_get_rev_type_parent_table_name(''%3$s'')
      FROM %3$s', _id, _count_row_in_old_aud, _table_name
    );
  ELSE
    --создаем запись о процессе и заполняем метаданными
    EXECUTE format('
      INSERT INTO audit.migration_batch_process (table_id, count_aud_row, min_row_id, max_row_id)
      SELECT %1$s, %2$s, null, null',
                   _id, _count_row_in_old_aud);
  END IF;

  --заполняем данные о подпроцессах
  EXECUTE audit.migration_fill_migration_sub_process(
      (SELECT id FROM audit.migration_batch_process WHERE table_id = _id LIMIT 1));
END;
$$;

