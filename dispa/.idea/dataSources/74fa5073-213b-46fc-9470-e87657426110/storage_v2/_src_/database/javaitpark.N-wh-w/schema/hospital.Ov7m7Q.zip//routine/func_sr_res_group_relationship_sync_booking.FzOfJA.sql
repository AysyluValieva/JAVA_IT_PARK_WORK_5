CREATE FUNCTION func_sr_res_group_relationship_sync_booking()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
/*
синхронизируем запись составного ресурса койки и брони ЗАНЯТО в коечном фонде. Триггерная функция назначена на изменение таблицы sr_res_group_relationship. Создает Меняет записис в таблице hospital.booking и hospital.booking_shift
new: если при создании новой брони есть активная подтвержденная/неподтвержденная бронь соответствующая созданному составному ресусру койка, то мы эту бронь снимаем.
*/
DECLARE
    busy_id INTEGER;
    free_id INTEGER;
    rez     INTEGER;
    rol_res INTEGER;
    unconf_id INTEGER;
    conf_id INTEGER;
    check_used_kf BOOLEAN;
BEGIN
    select id into unconf_id from hospital.booking_status where code = '2';
    select id into conf_id from hospital.booking_status where code = '3';
    select id into busy_id from hospital.booking_status where code = '5';
    select id into free_id from hospital.booking_status where code = '4';

    select id into rol_res from sr_res_role where code = 'BED';
    IF (TG_OP = 'DELETE')
    THEN
        SELECT
            CASE
                WHEN exists(SELECT 1
                            FROM hospital.detailed_bed_sheduler_settings ds
                                LEFT JOIN public.cmn_scope_type cst ON ds.level_id = cst.id
                            WHERE cst.code = 'Clinic' AND ds.org_id in (select mc.clinic_id from mc_step ms join mc_case mc on mc.id = ms.case_id where ms.res_group_id = OLD.group_id)
                                  AND ds.use_detailed_bed_sheduler IS TRUE AND
                                  (ds.from_date IS NULL OR ds.from_date <= current_date))
                    THEN true
                ELSE
                    CASE WHEN (NOT exists(
                        SELECT 1
                        FROM hospital.detailed_bed_sheduler_settings ds
                            LEFT JOIN public.cmn_scope_type cst ON ds.level_id = cst.id
                        WHERE cst.code = 'Clinic' AND ds.org_id in (select mc.clinic_id from mc_step ms join mc_case mc on mc.id = ms.case_id where ms.res_group_id = OLD.group_id))
                              AND exists(
                                   SELECT 1
                                   FROM hospital.detailed_bed_sheduler_settings ds
                                       LEFT JOIN public.cmn_scope_type cst ON ds.level_id = cst.id
                                   WHERE cst.code = 'Global' AND ds.use_detailed_bed_sheduler IS TRUE AND
                                         (ds.from_date IS NULL OR ds.from_date <= current_date))
                    )
                        THEN true
                    ELSE false
                    END
                END into check_used_kf
        ;
        IF (check_used_kf) THEN
            -- найдем все связанные записи в таблице BOOKING и делаем их isCurrent = FALSE
            IF (OLD.role_id = rol_res) THEN -- только если тип составного ресурса КОЙКА, почистисм связаннаую бронь койки
                -- найдем все связанные записи в таблице BOOKING и делаем их isCurrent = FALSE
                UPDATE hospital.booking boo
                SET iscurrent = false
                where boo.rg_rel_id = OLD.id
                        and boo.iscurrent = TRUE
                        and boo.status_id = busy_id;
            END IF;
        END IF;
        RETURN OLD;
    ELSE
        IF (TG_OP = 'INSERT') THEN
            SELECT
                CASE
                    WHEN exists(SELECT 1
                                FROM hospital.detailed_bed_sheduler_settings ds
                                    LEFT JOIN public.cmn_scope_type cst ON ds.level_id = cst.id
                                WHERE cst.code = 'Clinic' AND ds.org_id in (select mc.clinic_id from mc_step ms join mc_case mc on mc.id = ms.case_id where ms.res_group_id = NEW.group_id)
                                      AND ds.use_detailed_bed_sheduler IS TRUE AND
                                      (ds.from_date IS NULL OR ds.from_date <= current_date))
                        THEN true
                    ELSE
                        CASE WHEN (NOT exists(
                            SELECT 1
                            FROM hospital.detailed_bed_sheduler_settings ds
                                LEFT JOIN public.cmn_scope_type cst ON ds.level_id = cst.id
                            WHERE cst.code = 'Clinic' AND ds.org_id in (select mc.clinic_id from mc_step ms join mc_case mc on mc.id = ms.case_id where ms.res_group_id = NEW.group_id))
                                  AND exists(
                                       SELECT 1
                                       FROM hospital.detailed_bed_sheduler_settings ds
                                           LEFT JOIN public.cmn_scope_type cst ON ds.level_id = cst.id
                                       WHERE cst.code = 'Global' AND ds.use_detailed_bed_sheduler IS TRUE AND
                                             (ds.from_date IS NULL OR ds.from_date <= current_date))
                        )
                            THEN true
                        ELSE false
                        END
                    END into check_used_kf
            ;
            IF (check_used_kf) THEN
                IF (NEW.role_id = rol_res) THEN -- только если тип составного ресурса КОЙКА, добавим в БРОНИ новые записи, при условии что есть step_id, даты буккинга заполнены и подразделение в посещении соответствует подразделению в профиле койки
                    --
                    with
                        conf_unconf as (
                        select  boo.reservation_id, boo.id as boo_id-- ИД
                        from    md_bed_resource mbr
                                join hospital.booking boo on boo.bed_id = mbr.bed_id and boo.begin_dt = NEW.bdatetime::date and boo.end_dt = NEW.edatetime::date -- поиск по датам
                                join hsp_reservation hr on hr.id = boo.reservation_id
                                join mc_step s on s.res_group_id = NEW.group_id
                                join mc_case mc ON mc.id = s.case_id
                                join lateral (select h.department_id from hsp_record h where h.id = s.id limit 1) h on true-- только госпитальные случаи
                                join md_referral mr on mr.id = hr.referral_id and mr.patient_id = mc.patient_id -- поиск по пациенту
                                join md_bed bed on bed.id = boo.bed_id
                                join pim_room room ON room.id = bed.room_id and room.department_id = hr.department_id -- поиск по подразделению
                        WHERE   mbr.id = NEW.resource_id
                                and boo.iscurrent
                                and boo.status_id in (conf_id, unconf_id)
                        order by boo.id
                        limit   1 -- если в 1 день на одну койку существует несколько броней (такое возможно) одного пациента то мы только одну сделаем неактуальной: другие закроются в цикле при следующем sr_res_group_reservation
                        ),
                        upd_boo as (--сделаем неактуальной запись UNCONF, CONF которую нашли на предыдущем шаге
                                update hospital.booking set iscurrent = FALSE from conf_unconf t where id = t.boo_id and status_id in (unconf_id, conf_id)
                                returning 1
                        ),
                        ins_b as (
                        insert into hospital.booking (step_id, reservation_id, rg_rel_id, bed_id, status_id, status_date, begin_dt, end_dt, iscurrent)
                        select  s.id, cu.reservation_id, new.id, mbr.bed_id, busy_id, current_date, new.bdatetime::date, new.edatetime::date, TRUE
                        from    mc_step s
                                join lateral (select hr.department_id from hsp_record hr where s.id = hr.id limit 1) hr on true-- только госпитальные случаи
                                join md_bed_resource mbr on mbr.id = new.resource_id
                                join md_bed mb on mb.id = mbr.bed_id
                                join pim_room room ON mb.room_id = room.id
                                --join md_room_profile rp ON rp.room_id = room.id
                                --join pim_room pr ON pr.id = rp.room_id
                                left join conf_unconf cu on true
                        where   s.res_group_id = new.group_id
                                and new.bdatetime <= new.edatetime
                                and room.department_id = hr.department_id
                        returning *),
                        ins_bs as (
                        insert into hospital.booking_shift (booking_id, count_shift, dt)
                        select  boo.id, 1, d.dt --current_date
                        from ins_b boo join lateral (select dt from generate_series(boo.begin_dt::date, boo.end_dt::date, '1 day')dt)d on true
                        returning 1)
                    select 1 into rez;
                END IF;
            END IF;
            RETURN NEW;
        ELSE
            SELECT
                CASE
                    WHEN exists(SELECT 1
                                FROM hospital.detailed_bed_sheduler_settings ds
                                    LEFT JOIN public.cmn_scope_type cst ON ds.level_id = cst.id
                                WHERE cst.code = 'Clinic' AND ds.org_id in (select mc.clinic_id from mc_step ms join mc_case mc on mc.id = ms.case_id where ms.res_group_id = NEW.group_id)
                                      AND ds.use_detailed_bed_sheduler IS TRUE AND
                                      (ds.from_date IS NULL OR ds.from_date <= current_date))
                        THEN true
                    ELSE
                        CASE WHEN (NOT exists(
                            SELECT 1
                            FROM hospital.detailed_bed_sheduler_settings ds
                                LEFT JOIN public.cmn_scope_type cst ON ds.level_id = cst.id
                            WHERE cst.code = 'Clinic' AND ds.org_id in (select mc.clinic_id from mc_step ms join mc_case mc on mc.id = ms.case_id where ms.res_group_id = NEW.group_id))
                                  AND exists(
                                       SELECT 1
                                       FROM hospital.detailed_bed_sheduler_settings ds
                                           LEFT JOIN public.cmn_scope_type cst ON ds.level_id = cst.id
                                       WHERE cst.code = 'Global' AND ds.use_detailed_bed_sheduler IS TRUE AND
                                             (ds.from_date IS NULL OR ds.from_date <= current_date))
                        )
                            THEN true
                        ELSE false
                        END
                    END into check_used_kf
            ;
            IF (check_used_kf) THEN
                IF (NEW.role_id = rol_res) THEN
                    -- найдем разницу между текущим booking и новым состоянием NEW
                    -- если разница есть то старое состояние переводим в FALSE, добавляем новое, иначе оставляем как есть
                    with
                    diff (step_id, reservation_id, rg_rel_id, bed_id, bdatetime, edatetime) as
                        (-- сравним по дням количество смен в ресурсе и в брони, если есть разница выведем значения step_id, rg_rel_id, для которых надо закомитить старые booking и завести новые
                        select boo.step_id, b_res.reservation_id, rg_rel_id, bed_id, srgr.bdatetime, srgr.edatetime, sum(count_shift_new) as count_shift_new, sum(count_shift_booking) as count_shift_booking
                        from (values   (NEW.id,         --610829,
                                        NEW.bdatetime,  --'2014-11-08 00:00:00'::TIMESTAMP,
                                        NEW.edatetime,      --'2014-11-18 00:00:00'::TIMESTAMP,
                                        NEW.resource_id,    --8257,
                                        NEW.group_id        --801128)
                                        )) srgr(id, bdatetime, edatetime, resource_id, group_id)
                            join lateral (
                                select t.step_id, t.rg_rel_id, t.bed_id, t.dt, sum(count_shift_new) as count_shift_new, sum(count_shift_booking) as count_shift_booking, srgr.bdatetime, srgr.edatetime
                                from (
                                    SELECT distinct
                                        srgr.id AS rg_rel_id,
                                        s.id AS step_id,
                                        mbr.bed_id,
                                        dt AS dt,
                                        1 AS count_shift_new,
                                        0 AS count_shift_booking
                                    FROM
                                        --sr_res_group_relationship srg2
                                        mc_step s --on s.res_group_id = srgr.group_id
                                        join lateral (select hr.department_id from hsp_record hr where s.id = hr.id limit 1) hr on true-- только госпитальные случаи
                                        JOIN LATERAL (
                                             SELECT dt
                                             FROM generate_series(srgr.bdatetime :: DATE, srgr.edatetime :: DATE, '1 day') dt
                                             ) d ON TRUE

                                        join md_bed_resource mbr on mbr.id = srgr.resource_id
                                        join md_bed mb on mb.id = mbr.bed_id
                                        join md_room room ON mb.room_id = room.id
--                                         join md_room_profile rp ON rp.room_id = room.id
                                        join pim_room pr ON pr.id = room.id
                                    WHERE
                                        s.res_group_id = srgr.group_id--srg2.id = srgr.id
                                        and pr.department_id = hr.department_id
--                         проверка на существование профиля помещения или отделения вместо join md_room_profile rp ON rp.room_id = room.id
                                        and exists (select rp.id from md_room_profile rp where rp.room_id = room.id
                                                    union select mdp.id from md_department_profile mdp where mdp.department_id = pr.department_id)
                                    UNION ALL
                                    SELECT distinct
                                        boo.rg_rel_id,
                                        boo.step_id,
                                        boo.bed_id,
                                        boo2.dt,
                                        0,
                                        boo2.count_shift
                                    FROM
                                        hospital.booking boo
                                        JOIN hospital.booking_shift boo2 ON boo2.booking_id = boo.id
                                    WHERE
                                        boo.rg_rel_id = srgr.id
                                        and boo.status_id = busy_id
                                        and boo.iscurrent = true
                                    )t
                                GROUP BY t.step_id, t.rg_rel_id, t.bed_id, t.dt
                            )boo on true
                            left join lateral (select b_res.reservation_id from hospital.booking b_res where b_res.step_id = boo.step_id /*and b_res.iscurrent = true */and b_res.reservation_id is not null limit 1) b_res on true
                        where coalesce(count_shift_booking, 0) <> coalesce(count_shift_new, 0)
                              and new.bdatetime <= new.edatetime
                        group by boo.step_id, b_res.reservation_id, rg_rel_id, bed_id, srgr.bdatetime, srgr.edatetime
                        ),
                    upd_book as (-- делаем неактивными только те запими которые отличаются от нового состояния
                        UPDATE  hospital.booking boo
                        SET     iscurrent = false
                        from    diff
                        where   boo.rg_rel_id = diff.rg_rel_id
                                and boo.step_id = diff.step_id
                                and boo.iscurrent = TRUE
                                and boo.bed_id = diff.bed_id
                                and boo.reservation_id IS NOT DISTINCT FROM diff.reservation_id
                                and count_shift_booking <> 0
                        returning *
                        ),
                    ins_book as (--добавляем новые БРОНИ только по тем записям, состояние которых не соответствует состоянию в NEW
                        insert into hospital.booking (step_id, reservation_id, rg_rel_id, bed_id, status_id, status_date, begin_dt, end_dt, iscurrent)
                        select  diff.step_id, diff.reservation_id, diff.rg_rel_id, diff.bed_id, busy_id, current_date, diff.bdatetime, diff.edatetime, true
                        from    diff
                        where   count_shift_new <> 0
                        returning *
                        ),
                    ins_book2 as (--заполняем таблицу смен по новым добавленным записям
                        insert into hospital.booking_shift (booking_id, count_shift, dt)
                        select  boo.id, 1, d.dt
                        from  ins_book as boo
                              join lateral (select dt from generate_series(boo.begin_dt::date, boo.end_dt::date, '1 day')dt)d on true
                        RETURNING *
                        )
                    select 1 into rez;
                END IF;
            END IF;
            RETURN NEW;
        end if;
    END IF;
END;
$$;

