CREATE FUNCTION fin_spec_validate_regional(p1_bill_id integer, p2_user_id integer)
  RETURNS void
STRICT
LANGUAGE plpgsql
AS $$
DECLARE
    _r RECORD;
    _v VARCHAR;
    _validation_code VARCHAR[];
    _validation_enabled BOOLEAN[];
    _validation_title VARCHAR[];
BEGIN
    /*
        version: 2015-12-08
    */
END;
$$;

