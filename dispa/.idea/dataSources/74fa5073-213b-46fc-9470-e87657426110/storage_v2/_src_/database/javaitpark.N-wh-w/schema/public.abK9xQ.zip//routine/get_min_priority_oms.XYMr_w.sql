CREATE FUNCTION get_min_priority_oms(individual_id integer)
  RETURNS text
LANGUAGE plpgsql
AS $$
declare
            doc text;
            begin
            select coalesce(id.series,' ') || ',' || coalesce(id.number,' ') || ',' || coalesce(o.short_name,' ') || ',' || coalesce(oc.code,' ')
            from pim_individual_doc id
            join pim_doc_type dt on (id.type_id = dt.id)
            left join pim_organization o on (o.id = id.issuer_id)
            left join pim_org_code oc on (oc.org_id = o.id)
            left join pim_doc_type_category dtc on (dtc.type_id = dt.id)
            where id.is_active='t' and (id.expire_dt is null or id.expire_dt > current_date) and id.indiv_id = individual_id and dtc.category_id = 2
            order by dt.priority
            limit 1 into doc;
            return doc;
            end;
$$;

