CREATE FUNCTION update_cert_or_refusal_decree1788(id_i integer, case_id_i integer, cert_num_i character varying, creation_date_i character varying, empl_issued_id_i integer, patient_id_i integer, period_begin_i character varying, period_end_i character varying, receiver_id_i integer, remark_i character varying)
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
  date_fmt_l VARCHAR = 'DD.MM.YYYY';
BEGIN
  UPDATE billing.services_cost_certificate
  SET
    case_id = case_id_i, creation_date = to_date(creation_date_i, date_fmt_l),
    employee_issued_id = empl_issued_id_i, number = cert_num_i, patient_id = patient_id_i,
    period_begin = (CASE WHEN period_begin_i IS NULL THEN NULL ELSE to_date(period_begin_i, date_fmt_l) END),
    period_end = (CASE WHEN period_end_i IS NULL THEN NULL ELSE to_date(period_end_i, date_fmt_l) END),
    receiver_id = receiver_id_i, remark = remark_i
  WHERE
    id = id_i;
  PERFORM billing.calc_certificate_costs_decree1788(id_i);
END;
$$;

