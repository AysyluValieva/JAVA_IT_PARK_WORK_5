CREATE FUNCTION denidisprforpatient(xid integer, xserviceid integer, xstatus integer, xagreedate character varying, xepid integer, xesarr character varying)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
          i integer;
          q_seq integer;
          pci integer;
          rstatus integer;
          mmcrid integer;
          eventcode text;
          mviews record;
		  l_pay_method integer;
        begin
          l_pay_method = (select me.pay_method from disp.md_event_patient mep join disp.md_event me on me.id = mep.event_id where mep.id = xepid);
          eventcode = (select met.code from disp.md_event_patient mep
          left join disp.md_event me on me.id = mep.event_id
          left join disp.md_event_type met on met.id = me.event_type
          where mep.id = xepid);

          IF (select count(id) from disp.md_event_eq_case where event_patient_id = xepid) = 0 then
              q_seq = nextval('mc_case_seq');
              pci = (select indiv_id from disp.md_event_patient where id = xepid);
              -- clinic id - ЗАШИТО - плохо (16 ГБ)
              mmcrid = nextval('mc_med_case_result_id');
              insert into MC_MED_CASE_RESULT (id) values (mmcrid);
              insert into MC_CASE (id, uid, create_date, patient_id, case_type_id, clinic_id, care_level_id, funding_id, init_goal_id, care_regimen_id, payment_method_id, open_date, result_id)
                values (q_seq, eventcode||'_'||CAST(nextval('disp.md_event_case_number') as text), current_date, pci, 1,
                (select me.org_id from disp.md_event_patient mep left join disp.md_event me on me.id = mep.event_id where mep.id = xepid),
                (select id from mc_care_level where code = '1' limit 1),
                (select me.pay_type from disp.md_event_patient mep join disp.md_event me on me.id = mep.event_id where mep.id = xepid),
                 46,
                (select id from mc_care_regimen where code = '1' limit 1),
				(CASE WHEN l_pay_method IS NOT NULL THEN l_pay_method ELSE (SELECT id FROM mc_payment_method WHERE CODE = '11' limit 1) END),
				current_date, mmcrid);
              insert into disp.md_event_eq_case (id, event_patient_id, case_id) values (nextval('disp.md_event_eq_case_id_seq'), xepid, q_seq);
          END IF;

          IF xid IS NULL THEN
            i = nextval('disp.md_event_service_patient_agreement_id_seq');
            IF xstatus = 1 THEN
              -- agree ALL
              --PERFORM disp.agreeServiceForPatientAllExceptDeni(1, 1, TRUE, TRUE, xagreeDate, xepid);
              PERFORM disp.agreeServiceForPatientAll(1, 1, TRUE, TRUE, xagreeDate, xepid);
              -- added STATUS
              IF (select count(ssr.id)
                    from disp.md_event_eq_case meec
                    left join MD_SRV_RENDERED msr on msr.case_id = meec.case_id
                    inner join SR_SRV_RENDERED ssr on ssr.id = msr.id and ssr.service_id = (SELECT mes.service_id FROM disp.md_event_service_patient mesp
                                                                                            left join disp.md_event_service mes on mes.id = mesp.service_id
                                                                                            where mesp.id = xserviceId)
                    where meec.event_patient_id = xepid) > 0 THEN
                rstatus = 4;
              ELSE
                rstatus = 1;
              END IF;
              IF (select count(id) from disp.md_event_service_patient_status where service_id = xserviceId) > 0 then
                update disp.md_event_service_patient_status set status = rstatus
                  where service_id = xserviceId;
              ELSE
                insert into disp.md_event_service_patient_status (id, service_id, status)
                  values (nextval('disp.md_event_service_patient_status_seq'), xserviceId, rstatus);
              END IF;
              insert into disp.md_event_service_patient_agreement (id, service_id, agree, denial, agree_date)
                values (i, xserviceId, TRUE, FALSE, to_date(xagreeDate, 'DD.MM.YYYY'));
              -- added OtherService
              FOR mviews IN (select CAST(CAST(foo.value as text) as int) as id from (select value from json_array_elements(CAST(xesArr as json))) as foo) LOOP
                  PERFORM disp.denialServiceForPatient((select id from disp.md_event_service_patient_agreement where service_id = mviews.id), mviews.id, FALSE, TRUE, xagreeDate, xepid);
              END LOOP;

            ELSIF xstatus = 2 THEN
              -- deni all
              PERFORM disp.denialServiceForPatientAll(1, 1, TRUE, TRUE, xagreeDate, xepid);
              -- added CASE
              IF (select count(id) from disp.md_event_eq_case where event_patient_id = xepid) = 0 then
                  q_seq = nextval('mc_case_seq');
                  pci = (select indiv_id from disp.md_event_patient where id = xepid);
                  -- clinic id - ЗАШИТО - плохо (16 ГБ)
                  mmcrid = nextval('mc_med_case_result_id');
              insert into MC_MED_CASE_RESULT (id) values (mmcrid);
              insert into MC_CASE (id, uid, create_date, patient_id, case_type_id, clinic_id, care_level_id, funding_id, init_goal_id, care_regimen_id, payment_method_id, open_date, result_id)
                values (q_seq, eventcode||'_'||CAST(nextval('disp.md_event_case_number') as text), current_date, pci, 1,
                (select me.org_id from disp.md_event_patient mep left join disp.md_event me on me.id = mep.event_id where mep.id = xepid),
                (select id from mc_care_level where code = '1' limit 1),
                (select me.pay_type from disp.md_event_patient mep join disp.md_event me on me.id = mep.event_id where mep.id = xepid),
                46,
                (select id from mc_care_regimen where code = '1' limit 1),
				(CASE WHEN l_pay_method IS NOT NULL THEN l_pay_method ELSE (SELECT id FROM mc_payment_method WHERE CODE = '11' limit 1) END),
				current_date, mmcrid);
              insert into disp.md_event_eq_case (id, event_patient_id, case_id) values (nextval('disp.md_event_eq_case_id_seq'), xepid, q_seq);
              END IF;
              insert into disp.md_event_service_patient_agreement (id, service_id, agree, denial, agree_date)
                values (i, xserviceId, FALSE, TRUE, to_date(xagreeDate, 'DD.MM.YYYY'));
            END IF;
          ELSE
            IF xstatus = 1 THEN
              -- agree all
              -- PERFORM disp.agreeServiceForPatientAllExceptDeni(1, 1, TRUE, TRUE, xagreeDate, xepid);
              PERFORM disp.agreeServiceForPatientAll(1, 1, TRUE, TRUE, xagreeDate, xepid);
              -- added STATUS
              IF (select count(ssr.id)
                    from disp.md_event_eq_case meec
                    left join MD_SRV_RENDERED msr on msr.case_id = meec.case_id
                    inner join SR_SRV_RENDERED ssr on ssr.id = msr.id and ssr.service_id = (SELECT mes.service_id FROM disp.md_event_service_patient mesp
                                                                                            left join disp.md_event_service mes on mes.id = mesp.service_id
                                                                                            where mesp.id = xserviceId)
                    where meec.event_patient_id = xepid) > 0 THEN
                rstatus = 4;
              ELSE
                rstatus = 1;
              END IF;
              IF (select count(id) from disp.md_event_service_patient_status where service_id = xserviceId) > 0 then
                update disp.md_event_service_patient_status set status = rstatus
                  where service_id = xserviceId;
              ELSE
                insert into disp.md_event_service_patient_status (id, service_id, status)
                  values (nextval('disp.md_event_service_patient_status_seq'), xserviceId, rstatus);
              END IF;
              update disp.md_event_service_patient_agreement set service_id=xserviceId, agree=TRUE, denial=FALSE,
                agree_date=to_date(xagreeDate, 'DD.MM.YYYY')
              where id=xid;
              -- added OtherService
              FOR mviews IN (select CAST(CAST(foo.value as text) as int) as id from (select value from json_array_elements(CAST(xesArr as json))) as foo) LOOP
                  PERFORM disp.denialServiceForPatient((select id from disp.md_event_service_patient_agreement where service_id = mviews.id), mviews.id, FALSE, TRUE, xagreeDate, xepid);
              END LOOP;
            ELSIF xstatus = 2 THEN
              -- deni all
              PERFORM disp.denialServiceForPatientAll(1, 1, TRUE, TRUE, xagreeDate, xepid);
              -- added CASE
              IF (select count(id) from disp.md_event_eq_case where event_patient_id = xepid) = 0 then
                  q_seq = nextval('mc_case_seq');
                  pci = (select indiv_id from disp.md_event_patient where id = xepid);
                  -- clinic id - ЗАШИТО - плохо (16 ГБ)
                  mmcrid = nextval('mc_med_case_result_id');
              insert into MC_MED_CASE_RESULT (id) values (mmcrid);
              insert into MC_CASE (id, uid, create_date, patient_id, case_type_id, clinic_id, care_level_id, funding_id, init_goal_id, care_regimen_id, payment_method_id, open_date, result_id)
                values (q_seq, eventcode||'_'||CAST(nextval('disp.md_event_case_number') as text), current_date, pci, 1,
                (select me.org_id from disp.md_event_patient mep left join disp.md_event me on me.id = mep.event_id where mep.id = xepid),
                (select id from mc_care_level where code = '1' limit 1),
                (select me.pay_type from disp.md_event_patient mep join disp.md_event me on me.id = mep.event_id where mep.id = xepid),
                46,
                (select id from mc_care_regimen where code = '1' limit 1),
				(CASE WHEN l_pay_method IS NOT NULL THEN l_pay_method ELSE (SELECT id FROM mc_payment_method WHERE CODE = '11' limit 1) END), current_date, mmcrid);
              insert into disp.md_event_eq_case (id, event_patient_id, case_id) values (nextval('disp.md_event_eq_case_id_seq'), xepid, q_seq);
              END IF;
              update disp.md_event_service_patient_agreement set service_id=xserviceId, agree=FALSE, denial=TRUE,
                agree_date=to_date(xagreeDate, 'DD.MM.YYYY')
              where id=xid;
            END IF;
          END IF;
          return i;
        end;
$$;

