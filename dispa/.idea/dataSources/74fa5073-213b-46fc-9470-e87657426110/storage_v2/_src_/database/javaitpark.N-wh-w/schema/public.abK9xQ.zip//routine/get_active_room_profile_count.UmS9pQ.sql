CREATE FUNCTION get_active_room_profile_count(p_room_id integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
  result INTEGER ;
BEGIN
  result = (
    select count(*)
    from md_profile mrp
    where exists (
      select id
      from md_room_profile
      where room_id = p_room_id and profile_id = mrp.id and
      (from_dt isnull or from_dt <= current_date) and
      (to_dt isnull or to_dt >= current_date)
    )
  );

  Return result;
END;
$$;

