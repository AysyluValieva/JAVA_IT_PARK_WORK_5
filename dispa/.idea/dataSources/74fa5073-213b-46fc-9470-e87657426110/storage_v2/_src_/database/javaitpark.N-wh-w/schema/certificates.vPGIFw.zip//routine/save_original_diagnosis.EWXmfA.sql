CREATE FUNCTION save_original_diagnosis(xstr text)
  RETURNS void
LANGUAGE plpgsql
AS $$
begin
                        execute xstr;
                      end;
$$;

