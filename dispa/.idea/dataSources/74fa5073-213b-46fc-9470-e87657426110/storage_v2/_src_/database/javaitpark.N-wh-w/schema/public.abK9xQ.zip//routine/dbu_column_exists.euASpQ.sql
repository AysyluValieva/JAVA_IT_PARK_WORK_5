CREATE FUNCTION dbu_column_exists(tablename character varying, columnname character varying)
  RETURNS boolean
LANGUAGE plpgsql
AS $$
declare result boolean;
            begin

            select count(*) > 0 into result
            from pg_attribute
            inner join pg_class on pg_attribute.attrelid = pg_class.oid
            inner join pg_namespace on pg_class.relnamespace = pg_namespace.oid
            and pg_namespace.nspname !~ '^(pg_|information_schema)'
            where pg_attribute.attnum > 0
            and pg_class.relname = lower($1)
            and pg_attribute.attname = lower($2);

            return result;
            end;
$$;

