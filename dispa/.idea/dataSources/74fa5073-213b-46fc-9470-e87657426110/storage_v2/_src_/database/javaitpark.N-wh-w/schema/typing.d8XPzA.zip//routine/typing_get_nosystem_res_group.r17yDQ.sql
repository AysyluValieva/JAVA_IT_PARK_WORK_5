CREATE FUNCTION typing_get_nosystem_res_group(integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
DECLARE 
 result int4;
            begin
result = (select srg1.id  from sr_res_group srg 
join sr_res_group srg1 on srg1.responsible_id = srg.responsible_id
where ((select array_agg(resource_id) from sr_res_group_relationship where group_id =srg.id) <@ (select array_agg(resource_id) from sr_res_group_relationship where group_id = srg1.id ))
and srg1.is_system = false
and srg.id = $1 

limit 1);
          return result;

end
$$;

