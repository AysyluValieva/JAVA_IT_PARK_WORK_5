CREATE FUNCTION fin_spec_validate_regional_dev(p1_bill_id integer, p2_user_id integer)
  RETURNS void
STRICT
LANGUAGE plpgsql
AS $$
DECLARE
    _r RECORD;
    _i RECORD;
    _rr RECORD;
    _v VARCHAR;
    _j INTEGER;
    _k INTEGER;
    _kol INTEGER;
    _validation_case_code VARCHAR[];
    _validation_case_enabled BOOLEAN[];
    _validation_case_title VARCHAR[];
    _validation_step_code VARCHAR[];
    _validation_step_enabled BOOLEAN[];
    _validation_step_title VARCHAR[];
    _validation_pol_code VARCHAR[];
    _validation_pol_enabled BOOLEAN[];
    _validation_pol_title VARCHAR[];
    _validation_bill_code VARCHAR[];
    _validation_bill_enabled BOOLEAN[];
    _validation_bill_title VARCHAR[];
    _validation_address_code VARCHAR[];
    _validation_address_enabled BOOLEAN[];
    _validation_address_title VARCHAR[];
    _s_from_date DATE;
    _s_to_date DATE;
    _c_to_date DATE;
    _err BOOLEAN;
    _csg_id INTEGER;
    _other_case_id INTEGER;
    _err_text VARCHAR;
    _bill_from_date DATE:= (SELECT m.from_date FROM fin_bill_main m WHERE m.id = p1_bill_id);
    _bill_type text:=billing.kurgan_fin_get_type_bill(p1_bill_id);
    _host text:='<a href=https://'||(select value from cmn_setting_value where setting_id = 'cz.atria.lsd.zero.server.api.ServerSettings.host' and scope_id = 1);
    _clinic_id INTEGER:=(SELECT rcp_id FROM billing.fin_bill_main_extended WHERE bill_id=p1_bill_id);
    _service_level_arr integer[]:=(
                                   SELECT f.serv_level_id_arr 
                                   FROM fin_available_care_kurgan f 
                                   WHERE clinic_id=_clinic_id AND 1=ANY(care_regimen_id_arr)
                                   limit 1
                                   );
    _indiv_id TEXT;
    _is_log BOOLEAN:=TRUE;
    _bill_id_last INTEGER;
    _referral_type_VMP INTEGER:=(SELECT id FROM public.md_referral_type WHERE code='1');
BEGIN
 /*
 	специфичные для Кугана проверки
 */   

IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_spec_validate_regional. Начало'); END IF; 
--######################### ПРОВЕРКИ НА УРОВНЕ СЛУЧАЯ  #########################--
 
 _validation_case_code := ARRAY 
    [
        'LAST_STEP_DIAG_NO_EQ_FINAL_DIAG',  --1
        'NOT_CORRECT_MTL_DATE',				--2
        'CARE_PROVIDING_RORM_CODE_REQUIRED',--3
        'SERV_REQUIRED_IN_STEP',			--4
        'CASE_NO_IDENTITY',					--5
        'CROSS_CASE_IN_BILL',				--6
        'CROSS_CASE_IN_ANOTHER_CLINIC',		--7
        'NO_CLINIC_BINDING'					--8
    ];
    
 FOREACH _v IN ARRAY _validation_case_code 
 LOOP 
     SELECT 
         coalesce (u.enabled, v.enabled) AS enabled, title INTO _r 
     FROM 
         public.fin_bill_validation                AS v 
         LEFT JOIN public.fin_bill_validation_user AS u ON u.validation_id = v.id AND u.user_id = p2_user_id
     WHERE 
         v.code = _v;
         
     _validation_case_enabled := _validation_case_enabled || _r.enabled;
     _validation_case_title   := _validation_case_title   || _r.title  ;
 END LOOP;
    
 DELETE FROM public.fin_bill_spec_item_error AS e USING public.fin_bill_spec_item AS i 
 WHERE 
     e.code = ANY (_validation_case_code) AND i.bill_id = p1_bill_id AND i.id = e.item_id
 ;

  --------------общие сведения------------------
  CREATE TEMP TABLE tmp_fin_bill_cases (
    case_id                  INTEGER,
    bill_id                  INTEGER,
    region_data              hstore,
    last_id                  INTEGER,
    active_policy_id         INTEGER,
    id_pac                   VARCHAR(255),
    patient_id               INTEGER,
    open_date                DATE,
    close_date               DATE,
    item_id_arr              INTEGER [],
    new_born                 BOOLEAN,
    care_regimen_id          INTEGER,
    care_regimen_code        VARCHAR(50),
    belonging_type           VARCHAR(20),
    vmp_flag                 BOOLEAN,
    care_providing_form_code VARCHAR(10),
    main_diagnosis_code      VARCHAR(50),
    patient_age              INTEGER,
    case_type_code           VARCHAR(10),
    care_level_id            INTEGER,
    init_goal_code_arr       VARCHAR [],
    uid                      VARCHAR(50),
    step_cnt                 INTEGER,
    care_level_code          VARCHAR(50)
  )
  ON COMMIT PRESERVE ROWS; --ещу UNLOGGED можно сделать (?)


  INSERT INTO tmp_fin_bill_cases
  (
    case_id, bill_id, uid, case_type_code,
    --case_mode_id, admission_type_id, repeat_count_code,
    care_regimen_code, care_level_code,
    --ref_clinic_code, payment_method_code, injury_code,
    patient_id,
    --first_id, first_diagnosis_code, first_admission_date, first_outcome_date,
    last_id,
    --last_result_code, last_result_id, last_is_closed, last_care_result, last_outcome_date,
    --last_department_code, last_department_name, last_speciality_code, last_doctor_code, last_doctor_indiv_id, last_profile_code, last_outcome_id, last_outcome_time, first_admission_time,
    --last_asist_id, last_department_id,
    care_regimen_id, care_level_id, care_providing_form_code,
    --provision_condition_code, ref_clinic_code_oms,
    init_goal_code_arr, --main_diagnosis_id,
    --disease_type_code, related_diagnosis_arr, complication_diagnosis_arr,
    step_cnt, id_pac, patient_age, new_born,
    --new_born_part, pat_os_sluch, pat_birthweight, birthweight,
    item_id_arr,
    belonging_type, active_policy_id,
    --first_diagnosis_id, last_mes_code, last_csg_code, last_vmp_type_code, last_vmp_method_code, last_hsp_department_code, last_hsp_department_name,
    --last_speciality_code_arr, last_doctor_snils,
    open_date, close_date, main_diagnosis_code,
    --last_hsp_department_id, time_gone_id, last_deviation_reason_code, sovmp,
    vmp_flag, region_data
  )
    SELECT
      case_id, bill_id, uid, case_type_code,
    --case_mode_id, admission_type_id, repeat_count_code,
    care_regimen_code, care_level_code,
    --ref_clinic_code, payment_method_code, injury_code,
    patient_id,
    --first_id, first_diagnosis_code, first_admission_date, first_outcome_date,
    last_id,
    --last_result_code, last_result_id, last_is_closed, last_care_result, last_outcome_date,
    --last_department_code, last_department_name, last_speciality_code, last_doctor_code, last_doctor_indiv_id, last_profile_code, last_outcome_id, last_outcome_time, first_admission_time,
    --last_asist_id, last_department_id,
    care_regimen_id, care_level_id, care_providing_form_code,
    --provision_condition_code, ref_clinic_code_oms,
    init_goal_code_arr, --main_diagnosis_id,
    --disease_type_code, related_diagnosis_arr, complication_diagnosis_arr,
    step_cnt, id_pac, patient_age, new_born,
    --new_born_part, pat_os_sluch, pat_birthweight, birthweight,
    item_id_arr,
    belonging_type, active_policy_id,
    --first_diagnosis_id, last_mes_code, last_csg_code, last_vmp_type_code, last_vmp_method_code, last_hsp_department_code, last_hsp_department_name,
    --last_speciality_code_arr, last_doctor_snils,
    open_date, close_date, main_diagnosis_code,
    --last_hsp_department_id, time_gone_id, last_deviation_reason_code, sovmp,
    vmp_flag, region_data
    FROM
      billing.fin_bill_cases
    WHERE
      bill_id = p1_bill_id
  --GROUP BY 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15
    ;
    CREATE INDEX tt_fbc_case_id ON tmp_fin_bill_cases (case_id);
	ANALYZE tmp_fin_bill_cases;
  /*--------------------------------*/


 IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_spec_validate_regional. 1'); END IF; 
 FOR _r IN  	
    SELECT DISTINCT 
    	c.case_id,
    	c.main_diagnosis_code,
        s.step_diagnosis_main,
        nullif(trim(c.care_providing_form_code),'') AS care_providing_form_code,
        EXISTS(SELECT 1 FROM public.mc_diagnosis d WHERE d.case_id = c.case_id AND d.stage_id = 4) AS final_diag_exists,
        c.belonging_type,  
        c.region_data -> 'mcod' as mcod,        
        c.item_id_arr,
        coalesce(c.region_data->'funding','budget') as funding
    FROM 
		tmp_fin_bill_cases c
		LEFT JOIN billing.fin_bill_steps s ON c.last_id = s.step_id AND c.case_id = s.case_id AND c.bill_id = s.bill_id
 	WHERE 
    	c.bill_id = p1_bill_id 
 LOOP
 	IF _validation_case_enabled[1] AND (_r.main_diagnosis_code <> _r.step_diagnosis_main OR _r.final_diag_exists = false) THEN 
    	INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id)
               SELECT nextval ('fin_bill_spec_item_error_seq'), _validation_case_title[1], 'LAST_STEP_DIAG_NO_EQ_FINAL_DIAG', unnest (_r.item_id_arr);
    END IF;
    
    IF _validation_case_enabled[3] AND (_r.care_providing_form_code IS NULL) THEN 
    	INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id)
               SELECT nextval ('fin_bill_spec_item_error_seq'), _validation_case_title[3], 'CARE_PROVIDING_RORM_CODE_REQUIRED', unnest (_r.item_id_arr);
    END IF;    
    
         
    IF _validation_case_enabled[5] AND NOT (EXISTS (SELECT 1 FROM public.fin_case_passing_identity_kurgan WHERE case_id = _r.case_id AND error_text is null)
    AND EXISTS (SELECT 1 FROM public.pim_individual_doc_on_case_kurgan WHERE case_id = _r.case_id)) THEN         --если не прошел идентификацию 
       --AND (NOT (SELECT fin_is_exclude_case_validation(_r.case_id,_validation_case_code[5])))  --если случай не в исключениях
         UPDATE tmp_fin_bill_cases f SET region_data=coalesce(region_data,hstore(''))||hstore('on_ident','TRUE') WHERE bill_id=p1_bill_id AND case_id=_r.case_id;
        IF EXISTS (SELECT 1 FROM fin_case_passing_identity_kurgan WHERE case_id = _r.case_id) THEN 
             _err_text := (SELECT error_text FROM fin_case_passing_identity_kurgan WHERE case_id = _r.case_id LIMIT 1);
            IF _bill_type='smp' AND _r.funding='budget' THEN
               UPDATE fin_bill_spec_item i SET comment=c.comment_add||coalesce(comment,'')
               FROM (select '<b>Бюджет. Случай не идентифицирован.</br> Предупреждение: '||coalesce(_err_text,'')||'</b> </br> ' as comment_add) c
               WHERE id=ANY(_r.item_id_arr)
                     and not (i.comment=c.comment_add||coalesce(i.comment,'')) ;
               --UPDATE tmp_fin_bill_cases SET region_data=coalesce(region_data, hstore(''))||hstore('funding','budget') where bill_id=p1_bill_id AND case_id=_r.case_id;
            ELSE 
               IF _err_text ilike '%Не найден в ЦС ЕРЗ.%' AND _r.belonging_type = 'foreign' THEN
         
                ELSIF NOT (nullif(trim(_err_text),'') is null and _r.belonging_type='local') THEN             
                    INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id) SELECT nextval ('fin_bill_spec_item_error_seq'), 
                                                                                       '<b>'||coalesce(Substr(COALESCE(_err_text,''),1,254),'')||'</b>', 
                                                                                      'CASE_NO_IDENTITY', unnest (_r.item_id_arr);
                END IF;
           END IF;     
        ELSE 
        	INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id) SELECT nextval ('fin_bill_spec_item_error_seq'), 
                                                                                   format(_validation_case_title[5],''), 
                                                                                   'CASE_NO_IDENTITY', unnest (_r.item_id_arr);
        END IF;    
    END IF;
    
    IF _validation_case_enabled[8] AND _r.belonging_type = 'local' AND _r.mcod IS NULL  THEN 
    	INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id)
               SELECT nextval ('fin_bill_spec_item_error_seq'), _validation_case_title[8], 'NO_CLINIC_BINDING', unnest (_r.item_id_arr);
        UPDATE tmp_fin_bill_cases f SET region_data=coalesce(region_data,hstore(''))||hstore('on_ident','TRUE') WHERE bill_id=p1_bill_id AND case_id=_r.case_id;
    END IF;  
    
 END LOOP;
  IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_spec_validate_regional. 1.1'); END IF; 
  IF _bill_from_date>to_date('30.06.2016','dd.mm.yyyy') AND _validation_case_enabled[5] THEN
 WITH SV AS 
   ( 
        SELECT c.case_id, c.item_id_arr,
               c.open_date<>k.open_date as is_open_date, 
               (   p.issuer_id<>k.issuer_id OR replace(replace(coalesce(p.series,''),'-',''),' ','')<>replace(replace(coalesce(k.policy_series,''),'-',''),' ','') OR coalesce(p.number,'')<>coalesce(k.policy_number,'') 
                          OR replace(p.type,'ENP','MHI_UNIFORM')<>coalesce(d.code,'')
               ) as is_policy,
               ( (CASE WHEN NOT c.new_born THEN replace((COALESCE(f.number,t.pat_identity_number,'')),' ','') ELSE replace(coalesce(t.rep_identity_number,''),' ','') END)<> replace(coalesce(k.identity_number,''),' ','') OR 
                replace(replace((CASE WHEN NOT c.new_born THEN trim(COALESCE(f.series,t.pat_identity_series,'')) ELSE coalesce(t.rep_identity_series,'') END),' ',''),'-','')<>
                coalesce(replace(replace(k.identity_series,' ',''),'-',''),'')
               ) as is_doc,
               COALESCE((CASE WHEN NOT c.new_born THEN t.pat_snils ELSE t.rep_snils END),'')<>coalesce(k.snils,'') AS is_snils,
               ( trim(COALESCE(f.surname,t.pat_surname,''))<>trim(coalesce(k.pat_surname,'')) OR trim(COALESCE(f.name,t.pat_name,''))<>trim(COALESCE(k.pat_name,'')) OR 
                 trim(COALESCE(f.patr_name,t.pat_patr_name,''))<>trim(COALESCE(k.pat_patr_name,''))
               ) is_fio,
               coalesce(c.belonging_type,'') as belonging_type
    FROM tmp_fin_bill_cases c
    JOIN billing.fin_bill_policy p ON p.bill_id=c.bill_id AND p.id=coalesce(c.active_policy_id,0)
    JOIN billing.fin_bill_patients t ON t.bill_id=c.bill_id AND t.id_pac=c.id_pac
    JOIN fin_case_passing_identity_kurgan k ON k.case_id=c.case_id
    LEFT JOIN pim_doc_type d ON d.id=k.policy_type_code::integer
    LEFT JOIN billing.fin_bill_cases_to_patient AS f ON f.bill_id = c.bill_id AND f.case_id = c.case_id AND f.patient_id = c.patient_id
    WHERE c.bill_id=p1_bill_id AND k.error_text is NULL
  ),
  T AS 
   (
     SELECT * FROM SV WHERE is_open_date OR is_policy OR is_doc AND belonging_type = 'foreign' OR is_fio OR is_snils
    ),  
 U AS  
    (
      UPDATE tmp_fin_bill_cases f
      SET region_data=coalesce(region_data,hstore(''))||hstore('on_ident','TRUE')
      FROM t    
      WHERE bill_id=p1_bill_id AND f.case_id=t.case_id
    )
  INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id) 
  SELECT nextval ('fin_bill_spec_item_error_seq'),
  CASE WHEN is_policy THEN 'Изменились данные по полису. Необходима повторная идентификация'
       WHEN is_doc    THEN 'Изменились данные по документу удостоверяющему личность. Необходима повторная идентификация'
       WHEN is_fio    THEN 'Изменилось ФИО. Необходима повторная идентификация'
       WHEN is_open_date    THEN 'Изменилась дата начала случая. Необходима повторная идентификация'
       WHEN is_snils    THEN 'Изменился СНИЛС. Необходима повторная идентификация'
  END, 'CASE_NO_IDENTITY', unnest (item_id_arr)
  FROM T;
 END IF;
 
 IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_spec_validate_regional. 1.2'); END IF; 
  IF _bill_from_date>to_date('30.06.2016','dd.mm.yyyy') AND _validation_case_enabled[5]  THEN
  /*
 WITH SV AS 
   ( 
        SELECT c.case_id, c.item_id_arr
        FROM tmp_fin_bill_cases c
        JOIN billing.fin_bill_cases_to_patient_reg r ON c.case_id = r.case_id
        JOIN public.pci_patient_reg p ON p.id=r.patient_reg_id
        WHERE c.bill_id=p1_bill_id AND (c.region_data -> 'mcod') is NOT NULL AND (r.aud_when<p.aud_when AND p.aud_when-r.aud_when>'1 sec'::interval)
  ),
  T AS
    (
      UPDATE tmp_fin_bill_cases f
      SET region_data=coalesce(region_data,hstore(''))||hstore('on_ident','TRUE')
      FROM sv    
      WHERE bill_id=p1_bill_id AND f.case_id=sv.case_id
    )
  INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id) 
  SELECT nextval ('fin_bill_spec_item_error_seq'), 'Изменились данные по прикреплению. Необходима повторная идентификация', 'CASE_NO_IDENTITY', unnest (item_id_arr)
  FROM sv;
  */
  WITH SV AS 
   ( 
        SELECT c.case_id, c.item_id_arr
        FROM tmp_fin_bill_cases c
        JOIN fin_case_passing_identity_kurgan k ON k.case_id=c.case_id
        WHERE c.bill_id=p1_bill_id AND coalesce((c.region_data -> 'mcod'),'')<>coalesce(k.mcod,'')
  ),
  T AS
    (
      UPDATE tmp_fin_bill_cases f
      SET region_data=coalesce(region_data,hstore(''))||hstore('on_ident','TRUE')
      FROM sv    
      WHERE bill_id=p1_bill_id AND f.case_id=sv.case_id
    )
  INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id) 
  SELECT nextval ('fin_bill_spec_item_error_seq'), 'Изменились данные по прикреплению. Необходима повторная идентификация', 'CASE_NO_IDENTITY', unnest (item_id_arr)
  FROM sv;
  
 END IF;
 
 IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_spec_validate_regional. 2'); END IF; 
 --проверка для CROSS_CASE_IN_ANOTHER_CLINIC 
IF _validation_case_enabled[7] THEN 
 FOR _r IN 
 	SELECT c.case_id, c.open_date,c.close_date,c.patient_id,c.care_regimen_id,e.rcp_id as clinic_id,c.item_id_arr 
    FROM tmp_fin_bill_cases c
    JOIN billing.fin_bill_main_extended e ON c.bill_id = e.bill_id
    WHERE c.bill_id = p1_bill_id
 LOOP
 	
 	SELECT c.id INTO _other_case_id FROM public.mc_case c 
    --LEFT JOIN mc_step s ON c.closing_step_id = s.id
    WHERE /*c.clinic_id <> _r.clinic_id 
          AND*/ c.patient_id = _r.patient_id     
          AND c.id <> _r.case_id     
          AND (c.open_date between _r.open_date + 1 AND _r.close_date - 1) 
          AND (c.care_regimen_id = 2 AND _r.care_regimen_id = 2)
          AND (select count(1) > 1 from public.mc_step s where s.case_id = c.id) --случай не закончен в приемном отделении
    LIMIT 1
    ;
    
   IF (_other_case_id IS NOT NULL) THEN 
        IF (SELECT COALESCE((billing.fin_get_ksg(_r.case_id,(SELECT DISTINCT c.last_id FROM tmp_fin_bill_cases c WHERE c.bill_id = p1_bill_id AND c.case_id = _r.case_id LIMIT 1))),0) <> 99)
           AND (SELECT COALESCE((billing.fin_get_ksg(_other_case_id, (SELECT id FROM public.mc_step WHERE case_id = _other_case_id ORDER BY admission_date,admission_time DESC LIMIT 1))),0) <> 99)    
		THEN             
         
    	INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id)
               SELECT nextval ('fin_bill_spec_item_error_seq'), 
                      format(
                      		   _validation_case_title[7],
                               (SELECT c.uid FROM public.mc_case c where c.id = _other_case_id),
                               (SELECT o.short_name FROM public.mc_case c JOIN public.pim_organization o ON c.clinic_id = o.id WHERE c.id = _other_case_id),
                               (SELECT to_char(c.open_date,'dd.mm.yyyy') FROM public.mc_case c WHERE c.id = _other_case_id)
                             ),
                      'CROSS_CASE_IN_ANOTHER_CLINIC', unnest (_r.item_id_arr);        
    	END IF;                  
    END IF;
 
 END LOOP;  
END IF; --IF _validation_case_enabled[7]   
 
 IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_spec_validate_regional. 3'); END IF; 
 --отдельный цикл для SERV_REQUIRED_IN_STEP
 FOR _r IN  	
    SELECT DISTINCT 
        r.id AS srv_id,
        st.admission_date,
        st.id as step_id,
        (hsp_dep.type_id = 4) AS is_reception_dept,
        h.id as hsp_id,
        c.care_regimen_code in ('2','3','4','5') as type_stac,
        c.item_id_arr
    FROM 
		tmp_fin_bill_cases c
		LEFT JOIN public.mc_step st ON st.case_id = c.case_id
        LEFT JOIN public.md_srv_rendered r ON r.case_id = st.case_id AND r.step_id = st.id
        LEFT JOIN public.hsp_record h on st.id = h.id
        LEFT JOIN public.pim_department hsp_dep ON hsp_dep.id = h.department_id
	WHERE 
    	c.bill_id = p1_bill_id 
 LOOP
 
 	IF _validation_case_enabled[4] AND (NOT COALESCE(_r.is_reception_dept,FALSE)) AND (_r.srv_id IS NULL) AND (_r.type_stac AND _r.hsp_id is not null or NOT _r.type_stac) THEN 
    	INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id)
               SELECT nextval ('fin_bill_spec_item_error_seq'), format(_validation_case_title[4],to_char(_r.admission_date,'dd.mm.yyyy'))||' (id='||_r.step_id::text||')' , 'SERV_REQUIRED_IN_STEP', unnest (_r.item_id_arr);
    END IF;    
 
 END LOOP;
 
 /*
 --проверка правильной последовательности дат в МТЛ и стат карте
 --только стационар и дн.стационары
 FOR _r IN
 	SELECT DISTINCT
    	c.case_id,
        c.item_id_arr
    FROM
    	fin_bill_cases c
    WHERE c.bill_id = p1_bill_id AND c.care_regimen_id in (2,3,4,5) 
 LOOP
 	_s_from_date	:= NULL;
    _s_to_date		:= NULL;
    _c_to_date		:= NULL;
    _err			:= FALSE;
 	FOR _rr IN 
    	SELECT DISTINCT
 			s.step_id,c.first_admission_date AS c_from_date,c.last_outcome_date AS c_to_date,
            s.step_admission_date,s.step_outcome_date 
		FROM
			fin_bill_cases c 
    		JOIN fin_bill_steps s ON c.bill_id = s.bill_id AND c.case_id = s.case_id
		WHERE
        	c.bill_id = p1_bill_id AND c.case_id = _r.case_id   
		ORDER BY
        	s.step_id
    LOOP
    	IF (NOT _err) THEN
        	IF (_s_from_date IS NULL) THEN  -- первый шаг
        		_s_from_date	:= _rr.step_admission_date;
           	 	_s_to_date		:= _rr.step_outcome_date;
           	 	IF (_s_from_date <> _rr.c_from_date) THEN _err := TRUE; END IF;
       	 	ELSE -- не первый шаг 
       		 	_s_from_date := _rr.step_admission_date;
            	IF (_s_from_date <> _s_to_date) THEN _err := TRUE; END IF;
            	_s_to_date := _rr.step_outcome_date;	     
        	END IF;
        	IF (_c_to_date IS NULL) THEN _c_to_date := _rr.c_to_date; END IF;	
        END IF;    
    END LOOP;
    IF (NOT _err) AND (_s_to_date <> _c_to_date) THEN _err := TRUE; END IF;
    
    IF _validation_case_enabled[2] AND (_err) THEN 
    	INSERT INTO fin_bill_spec_item_error (id, error, code, item_id)
               SELECT nextval ('fin_bill_spec_item_error_seq'), _validation_case_title[2], 'NOT_CORRECT_MTL_DATE', unnest (_r.item_id_arr);
    END IF;           
    
 END LOOP;       
 */ 
	  
 
 
--######################### ПРОВЕРКИ НА УРОВНЕ ШАГА  #########################--
IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_spec_validate_regional. 4'); END IF; 
  _validation_step_code := ARRAY 
    [
        'NO_EXISTING_LICENSE',				--1
        'VMP_TYPE_REQUIRED',				--2
        'VMP_METHOD_REQUIRED',				--3
        'ANEST_CODE_REQUIRED',				--4
        'DEVIATION_CODE_REQUIRED',			--5
        'SERVICE_OUT_STEP',					--6
        'MES_NOT_COMPILE_DIAG',				--7
        'MES_NOT_COMPILE_AGES',				--8
        'DOCTOR_SPECIALITY_IS_NULL',		--9
        'BED_PROFILE_REQUIRED',				--10
        'DOCTOR_SPECIALITY_CODE_WRONG',		--11
        'POSITION_NOT_IN_CSG',				--12
        'SRV_DATE_OUT_OF_HSP',				--13
        'MD_PROFLE_NOT_COMP_BED_PROFILE',	--14
        'REANIM_DURATION_OUT_HSP',			--15
        'MES_IS_NOT_REANIM',				--16
        'REANIM_MES_REQUIRED',				--17
        'REANIM_DIAG_REQUIRED',				--18
        'STEP_OUTCOME_TIME_IS_NULL',		--19
        'DIAG_SUBHEADING_REQUIRED',			--20
        'PIM_POSITION_CATEGORY_WRONG',		--21
        'FINAL_DIAG_EQ_ALL_STEP_DIAG',		--22
        'SERVICE_DOUBLE',     				--23
        'KURGAN_SPECIALITY_SRV_ERROR',      --24
        'KURGAN_APP_DEPARTMENT_ERROR',      --25
        'KURGAN_DATE_IN_DATE_OUT',          --26
        'KURGAN_STEPS_IN_ONE_DAY',          --27
        'KURGAN_SERVICE_LEVEL',             --28        
        'KURGAN_CASE_SUM_IS_NULL',          --29
        'KURGAN_CASE_APP_SUM_IS_NULL',      --30
        'KURGAN_DOCTOR_SNILS',              --31
        'KURGAN_QUANTITY',                  --32
        'KURGAN_CASE_CLOSE_DATE_ERROR',     --33
        'KURGAN_PATIENT_DOUBLE',            --34
        'KURGAN_PATIENT_NEW_BORN_ERROR',    --35
        'KURGAN_SERVICE_SUNDAY',            --36
        'KURGAN_PASSPORT_INCORRECT',        --37
        'KURGAN_NHISTORY_INCORRECT',        --38
        'KURGAN_NHISTORY_DOUBLE',           --39
        'KURGAN_CASE_OPEN_DATE_ERROR',      --40
        'KURGAN_CASE_DOUBLE',               --41
        'KURGAN_BAD_MALE_SPECIALITY',        --42
        'KURGAN_VMP_REF_REQ',               --43
        'KURGAN_VMP_REF_BAD',               --44
        'KURGAN_VMP_REF_PLANNED_DATE',      --45
        'KRG_CARE_REGIMEN_NOT_EQ_LEVEL',    --46
        'KRG_CHILD_SRV_TO_ADULT',           --47
        'KRG_CHECK_VACC',                   --48
        'KRG_AMB_BAD_SPEC',                  --49
        'KRG_AMB_NOT_OMS_DIAG',              --50
        'KRG_CHECK_DISABLE_BENEFIT'          --51
        ];
      
 FOREACH _v IN ARRAY _validation_step_code 
 LOOP 
     SELECT 
         coalesce (u.enabled, v.enabled) AS enabled, title INTO _r 
     FROM 
         public.fin_bill_validation                AS v 
         LEFT JOIN public.fin_bill_validation_user AS u ON u.validation_id = v.id AND u.user_id = p2_user_id
     WHERE 
         v.code = _v;
         
     _validation_step_enabled := _validation_step_enabled || _r.enabled;
     _validation_step_title   := _validation_step_title   || _r.title  ;
 END LOOP;
    
 DELETE FROM public.fin_bill_spec_item_error AS e USING public.fin_bill_spec_item AS i 
 WHERE 
     e.code = ANY (_validation_step_code) AND i.bill_id = p1_bill_id AND i.id = e.item_id
 ;

-- NO_EXISTING_LICENSE --
IF _validation_step_enabled[1] THEN 
FOR _r IN 
   WITH license AS 
   (
  	  SELECT DISTINCT 
	  	  st.spec_item_id,
    	  lic.id AS license_id
	  FROM 
 		  billing.fin_bill_steps st
    	 -- JOIN tmp_fin_bill_cases cs ON cs.bill_id=st.bill_id and st.case_id = cs.case_id
    	  JOIN billing.fin_bill_main_extended ex ON ex.bill_id = st.bill_id
    	  LEFT JOIN public.md_clinic_license lic ON lic.clinic_id = ex.rcp_id AND 
    									     lic.spec_id   = st.service_spec_id AND
            	                             lic.level_id	 = st.urov AND 
                	                         st.srv_rendered_bdate >= lic.dt_from AND 
                    	                     (st.srv_rendered_bdate <= lic.dt_to OR lic.dt_to IS NULL)
	  WHERE 
		  st.bill_id = p1_bill_id     
   )
   SELECT DISTINCT 
	   s.spec_item_id AS id,
       c.care_regimen_code,
       s.service_spec_id,
       s.urov,       
       l.license_id
   FROM
	   billing.fin_bill_steps s 
       JOIN tmp_fin_bill_cases c ON c.bill_id=s.bill_id and s.case_id = c.case_id
       JOIN license l ON l.spec_item_id = s.spec_item_id
   WHERE 
 	  s.bill_id = p1_bill_id 
LOOP
	--пока только для поликлиники
	IF (_r.care_regimen_code = '1') AND 
       (_r.service_spec_id IS NOT NULL) AND (_r.urov <> 0) AND (_r.license_id IS NULL) THEN 
            INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id)
                   SELECT nextval ('fin_bill_spec_item_error_seq'), _validation_step_title[1], 'NO_EXISTING_LICENSE', _r.id;
    END IF;               
END LOOP;
END IF;--IF _validation_step_enabled[1] THEN
-- NO_EXISTING_LICENSE --

IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_spec_validate_regional. 5'); END IF; 
 --проверка на дубли услуг 
 
 IF _validation_step_enabled[23] THEN 
 
 
   FOR _r IN 
         
          SELECT
            		s.service_code,
    				s.srv_rendered_bdate AS bdate,
    				s.doctor_code,
                    s.patient_id,
    				array_agg(s.spec_item_id order by s.srv_rendered_id) AS item_arr, 
                    array_agg(s.srv_rendered_id order by s.srv_rendered_id) AS srv_rendered_id_arr 
				FROM 
					billing.fin_bill_steps s
            		JOIN tmp_fin_bill_cases c ON c.bill_id = s.bill_id AND c.case_id = s.case_id
				WHERE
					s.bill_id = p1_bill_id
    				AND s.doctor_code IS NOT NULL 
            		AND c.care_regimen_id = 1 
                    AND (UPPER(s.region_data->'is_pos')='TRUE' OR s.service_code IN ('A06.09.006','A06.09.006.001','A06.09.007','A06.09.007.002')) 
                    AND NOT s.service_code IN ('B01.026.008','B01.026.014','B01.031.009','B01.047.016')
				GROUP BY 1,2,3,4
				HAVING count(*) > 1  
        LOOP
            FOR _i IN 2..ARRAY_LENGTH(_r.item_arr,1) 
                LOOP
                   INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id)
                    SELECT
                    nextval('fin_bill_spec_item_error_seq'),
                    format(_validation_step_title[23],_r.srv_rendered_id_arr[1],_r.srv_rendered_id_arr[1]),
                    'SERVICE_DOUBLE',
                    _r.item_arr[_i];
                END LOOP;
        END LOOP;
  
 	
    
 END IF;
 
 IF _validation_step_enabled[7] THEN
     
     
     	INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id)
        SELECT  nextval ('fin_bill_spec_item_error_seq'), format(_validation_step_title[7], mes.code,mdd.code), 'MES_NOT_COMPILE_DIAG', s.spec_item_id
        FROM billing.fin_bill_steps  s 
        INNER JOIN tmp_fin_bill_cases c ON s.bill_id = c.bill_id AND s.case_id = c.case_id
        INNER JOIN PUBLIC.mc_diagnosis mcd ON mcd.case_id = c.case_id AND mcd.step_id = s.step_id
        INNER JOIN PUBLIC.md_diagnosis mdd ON mdd.id = mcd.diagnos_id 
        LEFT JOIN PUBLIC.md_mes mes ON mes.id = mcd.mes_id
        LEFT JOIN PUBLIC.mc_mes_diagnos msd ON msd.md_mes = mcd.mes_id AND msd.diagnosis_id = mcd.diagnos_id
        WHERE s.bill_id = p1_bill_id  
          AND nullif(trim(s.vmp_type_code), '')  IS NULL
          AND nullif(trim(s.vmp_method_code), '') IS NULL
          AND mcd.type_id = 2
          AND c.care_regimen_code IN ('2', '3', '4', '5')
          AND msd.id IS NULL;

 END IF; 
    	
 
 
IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_spec_validate_regional. 6'); END IF; 
-- other validation --
FOR _r IN
	SELECT 
		s.spec_item_id AS id,
        s.step_id,
        CASE c.care_regimen_code WHEN '1' THEN 'посещения' ELSE 'отделения' END AS step_name,
		nullif(trim(s.vmp_type_code), '') AS vmp_type,
        EXISTS (
                SELECT 1
                FROM billing.fin_bill_steps st
                WHERE st.bill_id = s.bill_id AND st.case_id = s.case_id AND c.vmp_flag AND nullif(vmp_type_code, '') IS NOT NULL LIMIT 1
                ) AS vmp_type_case_exisits,
    	nullif(trim(s.vmp_method_code),'') AS vmp_method,
    	c.care_regimen_code,
    	COALESCE(c.vmp_flag,FALSE) AS vmp_flag,    	
    	CASE hsp_dep.type_id
    		WHEN 4 THEN TRUE
        	ELSE FALSE
    	END AS is_reception_dep,
        nullif(trim(s.deviation_reason_code),'') AS deviation_reason_code,
        CASE --соответсвие кода МЭС диагнозу
		WHEN NOT c.care_regimen_id IN (2, 3, 4, 5) THEN TRUE --только стационар
		WHEN hsp_dep.type_id = 4 THEN TRUE --кроме приемных отделений
		WHEN TRIM(s.code_mes) = '0' THEN TRUE -- пропускаем нулевой МЭС
		ELSE EXISTS (
                        SELECT 1
                        FROM PUBLIC.mc_mes_diagnos msd
                        WHERE msd.md_mes = cast(s.region_data -> 'code_mes_id' AS INT) AND msd.diagnosis_id = cast(s.region_data -> 'md_diagnosis_id' AS INT)
                    ) END AS is_mes2diag_comp,

        s.code_mes,
        s.step_diagnosis_main,
        EXISTS (
                SELECT 1
                FROM md_mes mes
                WHERE mes.id = cast(s.region_data -> 'code_mes_id' AS INT) AND 
                     ((CASE WHEN c.patient_age >= 18 THEN mes.age_group_id = 1 ELSE mes.age_group_id = 2 END) OR mes.age_group_id = 3)
                ) AS is_mes2ages_comp,
        s.employee_speciality_code,
        EXISTS (SELECT 1 FROM public.pim_speciality sp JOIN public.pim_speciality_to_oms_kurgan o ON o.speciality_id = sp.id WHERE trim(sp.code) = trim(s.employee_speciality_code) 
        AND o.case_type_id IN (SELECT id FROM mc_case_type WHERE code=c.case_type_code)) as is_oms_spec,
        s.region_data -> 'bed_profile_code' AS bed_profile_code,
        s.step_profile_code,
        bm.bill_from_date,
        c.care_level_id,
        (s.srv_rendered_bdate BETWEEN s.step_admission_date AND s.step_outcome_date) AS is_srv_date_in_step_date,
        CASE
        	WHEN c.care_regimen_id IN (2,3,4,5) THEN
            	EXISTS(SELECT 1 FROM md_profile_to_bed_profile p 
                       WHERE p.bed_profile_id = cast(s.region_data->'bed_profile_id' as integer) 
                             AND p.profile_id = cast(s.region_data->'step_profile_id' as integer) 
                      )
            ELSE TRUE
        END AS is_md_profile_comp_bed_profile,
        cast(s.region_data->'reanim_bed_day_count' as integer) as reanim_bed_day_count,
        s.region_data->'reanim_mes_code' as reanim_mes_code,
        s.region_data->'reanim_diag_code' as reanim_diag_code,
        s.step_outcome_time,
        hsp_dep.name as department_name,
        s.step_admission_date,
        s.step_outcome_date,
        s.region_data->'doctor_for_srv' as doctor_for_srv,
        s.department_id,
        s.position_id,
        upper(coalesce(s.region_data->'is_paid','False')) as is_paid,
        s.service_spec_code,
        cast(s.region_data -> 'md_diagnosis_id' as integer) AS md_diagnosis_id,
        CASE 
        	WHEN (COALESCE(c.vmp_flag,FALSE)=FALSE) OR (nullif(trim(s.vmp_type_code),'') = NULL)
                 OR (nullif(trim(s.vmp_method_code),'') = NULL)
            	THEN TRUE --если не ВМП
            WHEN NOT EXISTS (SELECT 1 FROM public.mc_vmp_method_anest_kurgan ak 
                              WHERE ak.vmp_method_id = cast(s.region_data->'vmp_method_id' as integer)
                                    AND ak.is_use_anest
                            )
                THEN TRUE --наличие анастезии не требуется 
            ELSE EXISTS (SELECT 1 FROM billing.fin_bill_steps st WHERE st.bill_id = s.bill_id AND st.step_id = s.step_id AND NULLIF(trim(st.anest_code),'') IS NOT NULL)                    
        END AS vmp_anest_code_check, --наличие в зог услуги с заполненной анестезией     	  	   	  	 	
        s.region_data -> 'pos_category_code' AS pos_category_code,
        c.main_diagnosis_code,
        c.case_type_code,
        s.srv_rendered_bdate BETWEEN c.open_date AND c.close_date as is_date_correct,
        coalesce(s.urov,0) as urov,
        nullif(s.doctor_snils,'') as doctor_snils,
        nullif(s.doctor_code,'') as doctor_code,
        nullif(s.region_data->'asist','') as asist,
        nullif(s.region_data->'asist_snils','') as asist_snils,
        s.quantity,
        coalesce((SELECT employee_id::TEXT FROM  pim_employee_position WHERE id=s.doctor_code::INTEGER),'NULL') as employee_id,
        c.init_goal_code_arr[1] AS init_goal_code,
        s.srv_rendered_bdate,
        s.service_code,
        s.cul        
	FROM
		billing.fin_bill_steps s 
   		JOIN tmp_fin_bill_cases c ON s.bill_id = c.bill_id AND s.case_id = c.case_id
        JOIN billing.fin_bill_main_extended bm ON s.bill_id = bm.bill_id
    	LEFT JOIN public.pim_department hsp_dep ON hsp_dep.id = s.hsp_department_id        
	WHERE
		s.bill_id = p1_bill_id
LOOP
	IF _validation_step_enabled[2] AND (_r.care_regimen_code = '2') AND 
       (NOT _r.is_reception_dep) AND _r.vmp_flag AND (_r.vmp_type_case_exisits IS FALSE) /*(_r.vmp_type IS NULL)*/ THEN
    	INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id)
        	VALUES (nextval ('fin_bill_spec_item_error_seq'), _validation_step_title[2], 'VMP_TYPE_REQUIRED', _r.id);
    END IF;
    
    IF _validation_step_enabled[3] AND (_r.care_regimen_code = '2') AND 
       (NOT _r.is_reception_dep) AND (_r.vmp_type IS NOT NULL) AND (_r.vmp_method IS NULL) THEN
    	INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id)
        	VALUES (nextval ('fin_bill_spec_item_error_seq'), _validation_step_title[3], 'VMP_METHOD_REQUIRED', _r.id);
    END IF;
    
    IF _validation_step_enabled[4] AND (NOT _r.vmp_anest_code_check) THEN
    	INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id)
        	VALUES (nextval ('fin_bill_spec_item_error_seq'), _validation_step_title[4], 'ANEST_CODE_REQUIRED', _r.id);
    END IF;   
    
    IF _validation_step_enabled[6] AND (_r.step_id IS NULL) THEN
    	INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id)
        	VALUES (nextval ('fin_bill_spec_item_error_seq'), format(_validation_step_title[6],_r.step_name), 'SERVICE_OUT_STEP', _r.id);
    END IF;  
    
    IF _validation_step_enabled[9] AND (_r.employee_speciality_code IS NULL) THEN
    		INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id)
    	    	VALUES (nextval ('fin_bill_spec_item_error_seq'), _validation_step_title[9], 'DOCTOR_SPECIALITY_IS_NULL', _r.id);
    END IF; 
    
    IF _validation_step_enabled[11] AND (NOT _r.is_oms_spec) AND (_r.bill_from_date >= '01.03.2015') AND (_r.case_type_code IN ('1','2')) AND _r.position_id is NOT NULL THEN
    		INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id)
    	    	VALUES (nextval ('fin_bill_spec_item_error_seq'), _validation_step_title[11]||' '||_host||'/employees/position/'||_r.position_id::text||'/edit?backUrl=/billing%2Fbills%2F'||p1_bill_id::TEXT||'%2Fspec >'||_r.position_id::text||'</a>', 'DOCTOR_SPECIALITY_CODE_WRONG', _r.id);
    END IF; 
    
    IF _validation_step_enabled[21] AND (_r.bill_from_date >= '01.11.2015') AND (NOT _r.pos_category_code IN ('1','2','3')) THEN
    		INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id)
    	    	VALUES (nextval ('fin_bill_spec_item_error_seq'), _validation_step_title[21], 'PIM_POSITION_CATEGORY_WRONG', _r.id);
    END IF; 
    
    IF _validation_step_enabled[22] AND (_r.care_regimen_code = '1') AND (_r.bill_from_date >= '01.11.2015')
       AND (_r.step_diagnosis_main <> _r.main_diagnosis_code) THEN
    		INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id)
    	    	VALUES (nextval ('fin_bill_spec_item_error_seq'), format(_validation_step_title[22],_r.step_diagnosis_main,_r.main_diagnosis_code), 'FINAL_DIAG_EQ_ALL_STEP_DIAG', _r.id);
    END IF; 

    IF _validation_step_enabled[24] AND nullif(_r.service_spec_code,'') IS NOT NULL and _r.doctor_for_srv is null and _r.case_type_code in ('1','3') 
    /*AND _r.init_goal_code<>'7'*/ and _r.is_paid='TRUE' AND _r.position_id is NOT NULL AND (left(_r.service_code,1)<>'A' or _r.cul>0)
    /*18.07.2016
    AND (_clinic_id<>28 OR _clinic_id=28 AND _r.service_code NOT IN ('A11.20.002', 'A16.20.036.001', 'A03.20.001',
    'A11.20.008','A14.20.001','A11.20.015','A11.20.002','A11.20.017','A11.20.004','A11.20.005','A11.20.009','A11.20.013','A11.20.011','A11.20.003','A16.01.017','A16.01.005'))
    */
    THEN
    		INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id)
    	    	SELECT nextval ('fin_bill_spec_item_error_seq'), 
                format(CASE WHEN _r.init_goal_code='7' THEN replace(_validation_step_title[24],'поликлиническом','клиническом') ELSE _validation_step_title[24] END ,_r.service_spec_code)||
                ' позиция ('||_host||'/employees/position/'||_r.position_id::text||'/edit?backUrl=/billing%2Fbills%2F'||p1_bill_id::TEXT||'%2Fspec >'||_r.position_id::text||'</a> ), '||
                _host||'/employees/employee/'||_r.employee_id||'/edit?backUrl=/billing%2Fbills%2F'||p1_bill_id::TEXT||'%2Fspec >'||
                _r.employee_id||'</a>)', 'KURGAN_SPECIALITY_SRV_ERROR', _r.id
              ;
    END IF; 
    
    IF _validation_step_enabled[26] AND _r.is_date_correct=FALSE THEN
       INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id)
    	    	VALUES (nextval ('fin_bill_spec_item_error_seq'), _validation_step_title[26], 'KURGAN_DATE_IN_DATE_OUT', _r.id);
    END IF;
   
    IF _validation_step_enabled[28] AND _bill_type='app' AND _r.urov NOT IN (SELECT unnest(_service_level_arr)) THEN
       INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id)
    	    	VALUES (nextval ('fin_bill_spec_item_error_seq'), _validation_step_title[28], 'KURGAN_SERVICE_LEVEL', _r.id);
    END IF;
    
    IF _validation_step_enabled[31] AND _bill_type='app' THEN
        IF _r.doctor_snils is NULL AND _r.doctor_code is NOT NULL THEN
           _indiv_id:=COALESCE((SELECT individual_id FROM pim_employee WHERE id=(SELECT employee_id FROM pim_employee_position WHERE id=_r.doctor_code::integer))::TEXT,'NULL');
           INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id)
                    VALUES (nextval ('fin_bill_spec_item_error_seq'), _validation_step_title[31]||' '||_host||'/pim/individuals/'||_indiv_id||'/edit?backUrl=/billing%2Fbills%2F'||p1_bill_id::TEXT||'%2Fspec >'||_indiv_id||'</a> ' ,
                    'KURGAN_DOCTOR_SNILS', _r.id);
        END IF;
        IF _r.asist is NOT NULL AND _r.asist_snils IS NULL  THEN
           _indiv_id:=COALESCE((SELECT individual_id FROM pim_employee WHERE id=LEFT(_r.asist,LENGTH(_r.asist)-3)::integer)::TEXT,'NULL');
            INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id)
                    VALUES (nextval ('fin_bill_spec_item_error_seq'), _validation_step_title[31]||'. Медсестра('||_host||'/pim/individuals/'||_indiv_id||'/edit?backUrl=/billing%2Fbills%2F'||p1_bill_id::TEXT||'%2Fspec >'||_indiv_id||')</a> ' ,
                    'KURGAN_DOCTOR_SNILS', _r.id);
        END IF;
    END IF;
    
    IF _validation_step_enabled[32]  THEN
        IF _r.quantity>100 OR _r.quantity<0 THEN
           INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id)
                    VALUES (nextval ('fin_bill_spec_item_error_seq'), _validation_step_title[32],'KURGAN_QUANTITY', _r.id);
        END IF;
    END IF;
    
    IF _validation_step_enabled[36] AND _bill_type='app' AND TO_CHAR(_r.srv_rendered_bdate,'d')='1' AND _r.case_type_code <> '3' AND _r.init_goal_code<>'7' AND NOT _r.service_code IN ('B01.026.008','B01.026.014','B01.031.009','B01.047.016')  THEN
        INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id)
                    VALUES (nextval ('fin_bill_spec_item_error_seq'), _validation_step_title[36],'KURGAN_SERVICE_SUNDAY', _r.id);
    END IF;
    
   
--ПРОВЕРКИ ТОЛЬКО ДЛЯ ГОСПИТАЛЬНЫХ СЛУЧАЕВ   
    IF (_r.care_regimen_code in ('2','3','4','5')) THEN 
    
    	IF _validation_step_enabled[5] AND (NOT _r.is_reception_dep) AND (_r.deviation_reason_code IS NULL) THEN
    		INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id)
       		 	VALUES (nextval ('fin_bill_spec_item_error_seq'), _validation_step_title[5], 'DEVIATION_CODE_REQUIRED', _r.id);
    	END IF;   
    
    	IF _validation_step_enabled[7] AND (NOT _r.is_mes2diag_comp) AND (_r.vmp_type IS NULL) AND (_r.vmp_method IS NULL)  THEN
    		INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id)
       		 	VALUES (nextval ('fin_bill_spec_item_error_seq'), format(_validation_step_title[7],_r.code_mes,_r.step_diagnosis_main), 'MES_NOT_COMPILE_DIAG', _r.id);
    	END IF; 
    
    	IF _validation_step_enabled[8] AND (NOT _r.is_mes2ages_comp) THEN
    		INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id)
    	    	VALUES (nextval ('fin_bill_spec_item_error_seq'), format(_validation_step_title[8],_r.code_mes), 'MES_NOT_COMPILE_AGES', _r.id);
    	END IF; 
        
        IF _validation_step_enabled[10] AND (NOT _r.is_reception_dep) AND (_r.bed_profile_code IS NULL) AND (_r.bill_from_date >= '01.03.2015') THEN
    		INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id)
    	    	VALUES (nextval ('fin_bill_spec_item_error_seq'), _validation_step_title[10], 'BED_PROFILE_REQUIRED', _r.id);
    	END IF;

        /*
        IF _validation_step_enabled[12] AND (NOT _r.is_reception_dep) AND (_r.bill_from_date >= '01.03.2015')
           AND (_r.vmp_type IS NULL) AND (_r.vmp_method IS NULL) AND (_r.care_level_id <> 5)             
         THEN
            _csg_id = public.fin_get_csg(_r.step_id);
            IF (_csg_id IS NULL) THEN
    			INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id)
    	    		VALUES (nextval ('fin_bill_spec_item_error_seq'), _validation_step_title[12], 'POSITION_NOT_IN_CSG', _r.id);
            END IF;        
    	END IF;
    	*/
        
        IF _validation_step_enabled[13] AND (NOT _r.is_srv_date_in_step_date) THEN
    		INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id)
    	    	VALUES (nextval ('fin_bill_spec_item_error_seq'), _validation_step_title[13], 'SRV_DATE_OUT_OF_HSP', _r.id);
    	END IF; 
        
        IF _validation_step_enabled[14] AND (NOT _r.is_reception_dep) AND (_r.bed_profile_code IS NOT NULL) 
           AND (_r.bill_from_date >= '01.03.2015') AND (NOT _r.is_md_profile_comp_bed_profile) THEN
    		INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id)
    	    	VALUES (nextval ('fin_bill_spec_item_error_seq'), format(_validation_step_title[14],_r.bed_profile_code,_r.step_profile_code), 'MD_PROFLE_NOT_COMP_BED_PROFILE', _r.id);
    	END IF;
        
        IF _validation_step_enabled[15] AND (_r.reanim_bed_day_count IS NOT NULL) AND (_r.reanim_bed_day_count > get_bed_day_count_on_step(_r.step_id)) THEN
    		INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id)
    	    	VALUES (nextval ('fin_bill_spec_item_error_seq'), _validation_step_title[15], 'REANIM_DURATION_OUT_HSP', _r.id);
    	END IF;
        
        IF _validation_step_enabled[16] AND (_r.reanim_mes_code IS NOT NULL) 
           AND (NOT EXISTS (SELECT 1 FROM public.md_mes mes WHERE mes.code = _r.reanim_mes_code AND mes.group_classifier_id =2)) THEN
    		INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id)
    	    	VALUES (nextval ('fin_bill_spec_item_error_seq'), format(_validation_step_title[16],_r.reanim_mes_code), 'MES_IS_NOT_REANIM', _r.id);
    	END IF;
        
        IF _validation_step_enabled[17] AND (_r.reanim_bed_day_count IS NOT NULL) AND (_r.reanim_mes_code IS NULL) THEN
    		INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id)
    	    	VALUES (nextval ('fin_bill_spec_item_error_seq'), _validation_step_title[17], 'REANIM_MES_REQUIRED', _r.id);
    	END IF;
        
        IF _validation_step_enabled[18] AND (_r.reanim_bed_day_count IS NOT NULL) AND (_r.reanim_diag_code IS NULL) THEN
    		INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id)
    	    	VALUES (nextval ('fin_bill_spec_item_error_seq'), _validation_step_title[18], 'REANIM_DIAG_REQUIRED', _r.id);
    	END IF;
        
        IF _validation_step_enabled[19] AND (_r.bill_from_date >= '01.05.2015') AND (NOT _r.is_reception_dep) AND (_r.step_outcome_time IS NULL) THEN
    		INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id)
    	    	VALUES (nextval ('fin_bill_spec_item_error_seq'), 
                format(_validation_step_title[19],concat(_r.department_name,' ',to_char(_r.step_admission_date,'dd.mm.yyyy'),'-',to_char(_r.step_outcome_date,'dd.mm.yyyy'))), 'STEP_OUTCOME_TIME_IS_NULL', _r.id);
    	END IF;
        
        IF _validation_step_enabled[20] AND (_r.bill_from_date >= '01.06.2015') AND (NOT _r.is_reception_dep) AND (position('.' in _r.step_diagnosis_main) = 0)
                                        AND EXISTS (SELECT 1 FROM md_diagnosis WHERE id = _r.md_diagnosis_id AND NOT coalesce (is_leaf, FALSE))
             /*                            
           AND (NOT EXISTS (SELECT 1 FROM public.md_diagnosis d WHERE d.id <> _r.md_diagnosis_id AND d.is_leaf AND d.code LIKE trim(_r.step_diagnosis_main)||'%'))
          
           AND (trim(_r.step_diagnosis_main) <> 'M45')
           AND (CASE 
                WHEN (_r.care_level_id = 3) OR (_r.care_level_id = 4 AND _r.vmp_type IS NULL AND _r.vmp_method IS NULL) THEN 
                	(EXISTS (SELECT 1 FROM billing.kurgan_csg_group_filter f WHERE  f.service_code LIKE trim(_r.step_diagnosis_main)||'%'))
                ELSE TRUE
               END)  
           */    
        THEN
    		INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id)
    	    	VALUES (nextval ('fin_bill_spec_item_error_seq'),format(_validation_step_title[20],_r.step_diagnosis_main), 'DIAG_SUBHEADING_REQUIRED', _r.id);
    	END IF;
        
    END IF;--ПРОВЕРКИ ТОЛЬКО ДЛЯ ГОСПИТАЛЬНЫХ СЛУЧАЕВ  
 
END LOOP;

IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_spec_validate_regional. 7'); END IF; 
IF _validation_step_enabled[25] AND _bill_type='app'  THEN
      FOR _r IN 
         SELECT s.spec_item_id,
                s.position_id::text as position,
                coalesce(s.department_id::TEXT,'NULL') as department_id,
                s.service_code,
                s.cul
         FROM billing.fin_bill_steps s
         JOIN tmp_fin_bill_cases c ON c.bill_id=s.bill_id and c.case_id=s.case_id
         JOIN pim_department d ON d.id=s.department_id
         JOIN pim_department_type t ON d.type_id=t.id
         WHERE s.bill_id=p1_bill_id AND init_goal_code_arr[1]<>'7' AND t.code='3' AND s.position_id is NOT NULL and upper(coalesce(s.region_data->'is_paid','False'))='TRUE' AND (left(s.service_code,1)<>'A' or s.cul>0) /*клиническое*/
         
         
            
        LOOP
            INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id)
    	    	VALUES (nextval ('fin_bill_spec_item_error_seq'),
                _validation_step_title[25]||' '||_host||'/employees/position/'||_r.position||'/edit?backUrl=/billing%2Fbills%2F'||p1_bill_id::TEXT||'%2Fspec >'||_r.position||'</a>, '||
                _host||'/employees/department/'||_r.department_id||'/edit?external=true&backUrl=/billing%2Fbills%2F'||p1_bill_id::TEXT||'%2Fspec >'||_r.department_id||'</a>, ', 'KURGAN_APP_DEPARTMENT_ERROR', _r.spec_item_id); 
        END LOOP;
END IF;


IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_spec_validate_regional. 9'); END IF; 
 IF _validation_step_enabled[29] THEN
            FOR _r IN 
              (
                SELECT s.case_id, sum(coalesce(i.price, 0)) as case_sum, array_agg(i.id) as id_arr
                FROM billing.fin_bill_steps s 
                JOIN public.fin_bill_spec_item i ON i.bill_id=s.bill_id AND i.id=s.spec_item_id
                WHERE s.bill_id = p1_bill_id AND NOT i.is_deleted AND s.service_code NOT in ('A06.09.006','A06.09.006.001','A06.09.007','A06.09.007.002')
                GROUP by 1
              )
            LOOP
                IF  _r.case_sum=0 THEN
                    INSERT INTO  public.fin_bill_spec_item_error (id, error, code,item_id)
                        SELECT nextval ('fin_bill_spec_item_error_seq'), _validation_step_title[29], 'KURGAN_CASE_SUM_IS_NULL',unnest(_r.id_arr);   
                END IF;    
            END LOOP;            
 END IF;
 
 IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_spec_validate_regional. 10'); END IF; 
 IF _validation_step_enabled[30] AND _bill_type='app' THEN
          
                INSERT INTO  public.fin_bill_spec_item_error (id, error, code,item_id)
                SELECT nextval ('fin_bill_spec_item_error_seq'), format(_validation_step_title[30], COALESCE(g.service_code,'')), 'KURGAN_CASE_APP_SUM_IS_NULL',f.spec_item_id  
                FROM billing.fin_bill_steps  f
                JOIN 
                   (
                    SELECT s.case_id, s.service_code
                    FROM billing.fin_bill_steps s 
                    JOIN public.fin_bill_spec_item i ON i.bill_id=s.bill_id AND i.id=s.spec_item_id
                    WHERE s.bill_id = p1_bill_id AND NOT i.is_deleted AND coalesce(i.price,0)=0
                    AND s.service_code NOT in ('A06.09.006','A06.09.006.001','A06.09.007','A06.09.007.002') AND upper((s.region_data->'is_paid'))='TRUE' AND NOT EXISTS (SELECT 1 FROM billing.fin_bill_service_jsonb WHERE bill_id=s.bill_id AND srv_rendered_id=s.srv_rendered_id and coalesce(region_data ? 'npl',false))  
                   ) g ON f.case_id=g.case_id
                WHERE bill_id=p1_bill_id   ;
          
 END IF;
 
 IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_spec_validate_regional. 11'); END IF; 
 IF _validation_step_enabled[33] AND _bill_type='app' THEN
     INSERT INTO  public.fin_bill_spec_item_error (id, error, code,item_id)
                SELECT nextval ('fin_bill_spec_item_error_seq'), _validation_step_title[33], 'KURGAN_CASE_CLOSE_DATE_ERROR',unnest(c.item_id_arr)
                FROM(
                        SELECT case_id, max(srv_rendered_bdate) as srv_rendered_edate
                        FROM billing.fin_bill_steps
                        WHERE bill_id=p1_bill_id 
                        GROUP by 1
                     ) s 
               JOIN  tmp_fin_bill_cases c  ON c.case_id=s.case_id
               WHERE c.bill_id=p1_bill_id AND c.close_date>s.srv_rendered_edate
               ;
                                     
 END IF;
 
 IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_spec_validate_regional. 11.1'); END IF; 
 IF _validation_step_enabled[40] AND _bill_type='app' THEN
     INSERT INTO  public.fin_bill_spec_item_error (id, error, code,item_id)
                SELECT nextval ('fin_bill_spec_item_error_seq'), _validation_step_title[40], 'KURGAN_CASE_OPEN_DATE_ERROR',unnest(c.item_id_arr)
                FROM(
                        SELECT case_id, min(srv_rendered_bdate) as srv_rendered_edate
                        FROM billing.fin_bill_steps
                        WHERE bill_id=p1_bill_id 
                        GROUP by 1
                     ) s 
               JOIN  tmp_fin_bill_cases c  ON c.case_id=s.case_id
               WHERE c.bill_id=p1_bill_id AND c.open_date<s.srv_rendered_edate
               ;
                                     
 END IF;
 
 IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_spec_validate_regional. 12'); END IF; 
 IF _validation_step_enabled[34] THEN
    INSERT INTO  public.fin_bill_spec_item_error (id, error, code,item_id)
                SELECT nextval ('fin_bill_spec_item_error_seq'), _validation_step_title[34]||' '||_host||'/pats/patients/'||s.customer_id::text||'/edit?backUrl=/billing%2Fbills%2F'||p1_bill_id::TEXT||'%2Fspec >'||s.customer_id::text||'</a> )', 'KURGAN_PATIENT_DOUBLE',unnest(s.item_id_arr)
                FROM
                     (
                      SELECT a.item_id_arr, b.customer_id
                      FROM billing.fin_bill_policy a
                      JOIN billing.fin_bill_policy b ON b.bill_id=a.bill_id AND b.id=a.id AND a.customer_id<>b.customer_id
                      WHERE a.bill_id=p1_bill_id AND a.id >0
                     ) s 
             
               ;
 END IF;
 
 IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_spec_validate_regional. 12.0'); END IF; 
 IF _validation_step_enabled[35] THEN
    INSERT INTO  public.fin_bill_spec_item_error (id, error, code,item_id)
                SELECT nextval ('fin_bill_spec_item_error_seq'), _validation_step_title[35], 'KURGAN_PATIENT_NEW_BORN_ERROR',unnest(item_id_arr)
                FROM
                     ( SELECT item_id_arr
                       FROM 
                          (
                            SELECT c.item_id_arr, age(c.open_date,p.pat_birth_dt)>INTERVAL '2 months' as is_no_new_born
                            FROM tmp_fin_bill_cases c
                            JOIN billing.fin_bill_patients p ON p.bill_id=c.bill_id AND p.id_pac = c.id_pac
                            WHERE c.bill_id=p1_bill_id AND c.new_born
                          ) g
                       WHERE is_no_new_born=TRUE 
                     ) f  
                ;
  END IF;     

IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_spec_validate_regional. 12.1'); END IF; 
 IF _validation_step_enabled[37] THEN
    INSERT INTO  public.fin_bill_spec_item_error (id, error, code,item_id)
                SELECT nextval ('fin_bill_spec_item_error_seq'), _validation_step_title[37]||ident_type, 'KURGAN_PASSPORT_INCORRECT',unnest(item_id_arr)
                FROM
                     ( SELECT item_id_arr, CASE WHEN pat_identity_type=1 THEN ' (свидетельство о рождении)' ELSE ' (паспорт РФ)' END as ident_type
                       FROM 
                          (
                            SELECT c.item_id_arr, CASE WHEN c.new_born THEN p.rep_identity_series ELSE p.pat_identity_series END as series,
                            CASE WHEN c.new_born THEN p.rep_identity_number ELSE p.pat_identity_number END as ident_number, p.pat_identity_type
                            FROM tmp_fin_bill_cases c
                            JOIN billing.fin_bill_patients p ON p.bill_id=c.bill_id AND p.id_pac = c.id_pac
                            WHERE c.bill_id=p1_bill_id AND c.belonging_type='foreign' AND p.pat_identity_type in (1,13)
                          ) g
                       WHERE NOT (CASE WHEN pat_identity_type=1 THEN series ~ E'^[IVXLCDM]{1,3}[А-Я]{2}' ELSE series ~ E'^\\d{4}$' END AND ident_number ~ E'^\\d{6}$')
                     ) f  
                ;
  END IF;   

IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_spec_validate_regional. 12.2'); END IF; 
 IF _validation_step_enabled[38] AND _bill_type='app' THEN
    INSERT INTO  public.fin_bill_spec_item_error (id, error, code,item_id)
                SELECT nextval ('fin_bill_spec_item_error_seq'), _validation_step_title[38], 'KURGAN_NHISTORY_INCORRECT',unnest(item_id_arr)
                FROM
                     (      SELECT item_id_arr
                            FROM tmp_fin_bill_cases
                            WHERE bill_id=p1_bill_id AND left(uid,1)='0'
                      ) g
                 ;
  END IF;   

  IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_spec_validate_regional. 12.3'); END IF; 
  IF _validation_step_enabled[39] AND _bill_type='app' THEN
 
    INSERT INTO  public.fin_bill_spec_item_error (id, error, code,item_id)
                SELECT nextval ('fin_bill_spec_item_error_seq'), _validation_step_title[39]||' '|| _host||'/cases/case/'||case_id::text||'/edit?external=true&backUrl=/billing%2Fbills%2F'||p1_bill_id::TEXT||'%2Fspec >'||case_id::text||'</a>', 'KURGAN_NHISTORY_DOUBLE',unnest(item_id_arr)
                FROM
                     (      SELECT c1.case_id,c.item_id_arr
                            FROM tmp_fin_bill_cases c
                            JOIN tmp_fin_bill_cases c1 ON c1.bill_id=c.bill_id AND c1.uid=c.uid
                            WHERE c.bill_id=p1_bill_id AND c.patient_id<>c1.patient_id 
                      ) g
                 ;
  END IF;    

 IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_spec_validate_regional. 12.4'); END IF; 
  IF _validation_step_enabled[41] AND _bill_type='app' THEN
  
    SELECT f1.id 
    INTO _bill_id_last
    FROM fin_bill_main f
    JOIN LATERAL (SELECT id FROM fin_bill_main WHERE clinic_id=f.clinic_id AND type_id=f.type_id AND from_date < f.from_date ORDER by from_date desc limit 1) f1 ON TRUE
    WHERe f.id=p1_bill_id
    ;

 
    INSERT INTO  public.fin_bill_spec_item_error (id, error, code,item_id)
    
    SELECT nextval ('fin_bill_spec_item_error_seq'), _validation_step_title[41]||' '|| _host||'/cases/case/'||case_id::text||'/edit?external=true&backUrl=/billing%2Fbills%2F'||p1_bill_id::TEXT||'%2Fspec >'||case_id::text||'</a>', 'KURGAN_CASE_DOUBLE',unnest(item_id_arr)
    FROM
         ( 
            SELECT s.case_id,array_agg(s.spec_item_id) as item_id_arr
            FROM (SELECT c1.bill_id, c1.case_id 
                  FROM tmp_fin_bill_cases c
                  JOIN billing.fin_bill_cases c1 ON c1.uid=c.uid AND c1.patient_id=c.patient_id AND c1.open_date=c.open_date AND c1.main_diagnosis_code=c.main_diagnosis_code
                  WHERE c.bill_id=p1_bill_id AND c1.bill_id=_bill_id_last AND c.case_id<>c1.case_id
                  ) t
                        JOIN  billing.fin_bill_steps s ON s.bill_id=t.bill_id AND s.case_id=t.case_id
                  JOIN fin_bill_spec_item i ON i.id=s.spec_item_id  AND NOT i.is_deleted
            GROUP by 1         
         ) g
     ;
     
     
    INSERT INTO  public.fin_bill_spec_item_error (id, error, code,item_id)
    
    SELECT nextval ('fin_bill_spec_item_error_seq'), _validation_step_title[41]||' '|| _host||'/cases/case/'||case_id::text||'/edit?external=true&backUrl=/billing%2Fbills%2F'||p1_bill_id::TEXT||'%2Fspec >'||case_id::text||'</a>', 'KURGAN_CASE_DOUBLE',unnest(item_id_arr)
    FROM
         ( 
            SELECT c1.case_id, c.item_id_arr 
           FROM tmp_fin_bill_cases c
           JOIN tmp_fin_bill_cases c1 ON c1.uid=c.uid AND c1.patient_id=c.patient_id AND c1.open_date=c.open_date AND c1.main_diagnosis_code=c.main_diagnosis_code
           WHERE c.bill_id=p1_bill_id AND c1.bill_id=c.bill_id AND c.case_id<>c1.case_id
          ) g
     ;
  END IF;    

IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_spec_validate_regional. 12.5'); END IF; 
  IF _validation_step_enabled[42] THEN
 
    INSERT INTO  public.fin_bill_spec_item_error (id, error, code,item_id)
                SELECT nextval ('fin_bill_spec_item_error_seq'), _validation_step_title[42], 'KURGAN_BAD_MALE_SPECIALITY',spec_item_id
                FROM
                     (      SELECT s.spec_item_id
                            FROM billing.fin_bill_steps s
                            JOIN billing.fin_bill_patients p ON p.bill_id=s.bill_id AND p.patient_id=s.patient_id
                            WHERE s.bill_id=p1_bill_id AND p.pat_gender_code='MALE' AND s.employee_speciality_code in ('1101','2003')
                      ) g
                 ;
  END IF;    
  
  IF _bill_type='stac' and _bill_from_date>=to_date('01.10.2016','dd.mm.yyyy') THEN
     IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_spec_validate_regional. 12.6'); END IF; 
     IF _validation_step_enabled[43] OR _validation_step_enabled[44] OR _validation_step_enabled[45] THEN
 
       WITH SV AS 
            (SELECT c.case_id, c.item_id_arr,j.region_data->>'referral_id' as referral_id,j.region_data->>'referral_type_id' as referral_type_id,
                    j.region_data->>'tal_p' as tal_p
             FROM tmp_fin_bill_cases c
             LEFT JOIN billing.fin_bill_cases_jsonb j ON j.bill_id=c.bill_id AND j.case_id=c.case_id
             WHERE c.bill_id=p1_bill_id AND c.care_level_code='32' 
            ),
        I43 AS 
            (INSERT INTO  public.fin_bill_spec_item_error (id, error, code,item_id)
             SELECT nextval ('fin_bill_spec_item_error_seq'), _validation_step_title[43], 'KURGAN_VMP_REF_REQ',unnest(item_id_arr)
             FROM sv
             WHERE _validation_step_enabled[43]  AND referral_id is NULL 
            ),
         I44 AS 
            (INSERT INTO  public.fin_bill_spec_item_error (id, error, code,item_id)
             SELECT nextval ('fin_bill_spec_item_error_seq'), _validation_step_title[44], 'KURGAN_VMP_REF_BAD',unnest(item_id_arr)
             FROM sv
             WHERE _validation_step_enabled[44]  AND coalesce(referral_type_id::integer,0)<>_referral_type_VMP   
            )    
          INSERT INTO  public.fin_bill_spec_item_error (id, error, code,item_id)
             SELECT nextval ('fin_bill_spec_item_error_seq'), _validation_step_title[45], 'KURGAN_VMP_REF_PLANNED_DATE',unnest(item_id_arr)
             FROM sv
             WHERE _validation_step_enabled[45]  AND coalesce(referral_type_id::integer,0)=_referral_type_VMP AND tal_p is NULL     
          ;
    END IF; 
  END IF;
IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_spec_validate_regional. 12.7'); END IF; 
  IF _validation_step_enabled[46] and _bill_type='stac' THEN
 
    INSERT INTO  public.fin_bill_spec_item_error (id, error, code,item_id)
    SELECT nextval ('fin_bill_spec_item_error_seq'), _validation_step_title[46], 'KRG_CARE_REGIMEN_NOT_EQ_LEVEL',unnest(item_id_arr)
    FROM tmp_fin_bill_cases
    WHERE bill_id=p1_bill_id AND NOT (care_regimen_code='1' AND care_level_code in ('12','13') OR care_regimen_code='2' AND care_level_code in ('31','32','5') OR care_regimen_code='4' AND care_level_code='31' OR care_regimen_code IN ('3','5') AND care_level_code in ('13') OR care_regimen_code='6' AND care_level_code='2')
     ;
  END IF;  
 IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_spec_validate_regional. 12.8'); END IF; 
 IF _validation_step_enabled[47] and _bill_type='app' THEN
 
    INSERT INTO  public.fin_bill_spec_item_error (id, error, code,item_id)
    SELECT nextval ('fin_bill_spec_item_error_seq'), _validation_step_title[47], 'KRG_CHILD_SRV_TO_ADULT',s.spec_item_id
    FROM tmp_fin_bill_cases c
    JOIN billing.fin_bill_steps s ON s.bill_id=c.bill_id AND s.case_id=c.case_id
    WHERE c.bill_id=p1_bill_id AND c.care_regimen_code='1' AND c.patient_age>=18 AND coalesce(s.region_data->'is_oms_serv','false')::boolean=true AND s.service_name ilike '%детск%' 
     ;
  END IF;   
  IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_spec_validate_regional. 12.9'); END IF; 
  IF _validation_step_enabled[48] and _bill_type='app' THEN
 
    INSERT INTO  public.fin_bill_spec_item_error (id, error, code,item_id)
    SELECT nextval ('fin_bill_spec_item_error_seq'), _validation_step_title[48], 'KRG_CHECK_VACC',s.spec_item_id
    FROM tmp_fin_bill_cases c
    JOIN billing.fin_bill_steps s ON s.bill_id=c.bill_id AND s.case_id=c.case_id
    WHERE c.bill_id=p1_bill_id AND c.care_regimen_code='1' AND c.step_cnt=1 
          AND c.main_diagnosis_code in ('Z23.1', 'Z23.2', 'Z23.5', 'Z23.6', 'Z23.7', 'Z23.8', 'Z24.0', 'Z24.1', 'Z24.4', 'Z24.5', 'Z24.6', 'Z25.0', 'Z25.1', 'Z25.8', 'Z27.1', 'Z27.4', 'Z27.8', 'Z27.9')
          AND s.service_code in ('A11.01.002','A11.01.003') 
          AND EXISTS (SELECT 1 FROM billing.fin_bill_steps t WHERE t.bill_id=s.bill_id AND t.case_id=s.case_id AND coalesce(t.region_data->'is_pos','false')::boolean=true AND t.srv_rendered_bdate<>s.srv_rendered_bdate)
          AND (SELECT COUNT(*) FROM billing.fin_bill_steps t WHERE t.bill_id=s.bill_id AND t.case_id=s.case_id AND coalesce(t.region_data->'is_pos','false')::boolean=true)=1
          
     ;
  END IF; 
  IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_spec_validate_regional. 12.10'); END IF;
  IF _bill_type='smp' THEN
    IF _validation_step_enabled[49] THEN
        INSERT INTO  public.fin_bill_spec_item_error (id, error, code,item_id)
        SELECT nextval ('fin_bill_spec_item_error_seq'), _validation_step_title[49], 'KRG_AMB_BAD_SPEC',s.spec_item_id
        FROM billing.fin_bill_steps s
        JOIN tmp_fin_bill_cases c ON 1 = 1 /*c.bill_id=s.bill_id*/ AND coalesce(c.region_data->'funding','')<>'budget'
        WHERE s.bill_id=p1_bill_id AND s.employee_speciality_code not in ('1119','1103','1122','1134','2002','112205')
         ;
     END IF;
     IF _validation_step_enabled[50] THEN

        INSERT INTO  public.fin_bill_spec_item_error (id, error, code,item_id)
        SELECT nextval ('fin_bill_spec_item_error_seq'), _validation_step_title[50], 'KRG_AMB_NOT_OMS_DIAG',unnest(c.item_id_arr)
        FROM  tmp_fin_bill_cases c
        JOIN md_diagnosis d ON d.id=c.main_diagnosis_id
        WHERE 1 = 1 /*c.bill_id=p1_bill_id*/ AND coalesce(c.region_data->'funding','')<>'budget' AND coalesce(d.is_oms_diag,false)=false
        ;
     END IF;
  END IF;
  IF _validation_step_enabled[51] and  _bill_type='app' THEN

        INSERT INTO  public.fin_bill_spec_item_error (id, error, code,item_id)
        SELECT nextval ('fin_bill_spec_item_error_seq'), 'Льгота "'||coalesce(d.name,'')||'" недопустима для пациента '||CASE WHEN c.patient_age<18 THEN 'ребёнка' ELSE 'взрослого' END,
        'KRG_CHECK_DISABLE_BENEFIT',unnest(c.item_id_arr)
        FROM tmp_fin_bill_cases c
        JOIN billing.fin_bill_cases_jsonb b ON b.bill_id=c.bill_id AND b.case_id=c.case_id
        JOIN pci_benefit_definition d ON d.id=(b.region_data->>'inv_id')::integer
        WHERE c.bill_id=p1_bill_id AND (c.patient_age>=18 AND (b.region_data->>'inv')='4' OR c.patient_age<18 AND (b.region_data->>'inv') in ('1','2','3'))
         ;
   END IF;

-- other validation --    

IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_spec_validate_regional. 13'); END IF; 
-- проверка адреса
--address
	
    

    _validation_address_code := ARRAY 
    [
        'ADDRESS_IS_REQUIRED'              --1
    ];
    FOREACH _v IN ARRAY _validation_address_code 
    LOOP 
        SELECT 
            coalesce (u.enabled, v.enabled) AS enabled, title INTO _r 
        FROM 
            public.fin_bill_validation                AS v 
            LEFT JOIN public.fin_bill_validation_user AS u ON u.validation_id = v.id AND u.user_id = p2_user_id
        WHERE 
            v.code = _v;
        _validation_address_enabled := _validation_address_enabled || _r.enabled;
        _validation_address_title   := _validation_address_title   || _r.title  ;
    END LOOP;
    
    DELETE FROM public.fin_bill_spec_item_error AS e USING public.fin_bill_spec_item AS i 
    WHERE 
        i.bill_id = p1_bill_id AND i.id = e.item_id AND e.code = ANY (_validation_address_code) 
    ;
    
    FOR _r IN 
        SELECT 
            patient_id,            
            item_id_arr,
            COALESCE (f.region_data -> 'kladrp',f.region_data -> 'kladrg') AS kladr
        FROM 
            billing.fin_bill_patients AS f
        WHERE
            bill_id = p1_bill_id
    LOOP
    --address
        IF 
            _validation_address_enabled[1] AND _r.kladr IS NULL
        THEN 
            INSERT INTO public.fin_bill_spec_item_error (id, error, code, item_id)
                SELECT nextval ('fin_bill_spec_item_error_seq'), _validation_address_title[1], 'ADDRESS_IS_REQUIRED', unnest (_r.item_id_arr)
            ;
        END IF;
    END LOOP;

-- проверка адреса
/*
--######################### ПРОВЕРКИ НА УРОВНЕ ПОЛИСА  #########################--
        
 _validation_pol_code := ARRAY 
    [
       'NO_CLINIC_BINDING'					--1
    ];
    
 FOREACH _v IN ARRAY _validation_pol_code 
 LOOP 
     SELECT 
         coalesce (u.enabled, v.enabled) AS enabled, title INTO _r 
     FROM 
         fin_bill_validation                AS v 
         LEFT JOIN fin_bill_validation_user AS u ON u.validation_id = v.id 
     WHERE 
         v.code = _v;
         
     _validation_pol_enabled := _validation_pol_enabled || _r.enabled;
     _validation_pol_title   := _validation_pol_title   || _r.title  ;
 END LOOP;
    
 DELETE FROM fin_bill_spec_item_error AS e USING fin_bill_spec_item AS i 
 WHERE 
     e.code = ANY (_validation_pol_code) AND i.bill_id = p1_bill_id AND i.id = e.item_id
 ;

FOR _r IN 
	SELECT DISTINCT
		c.care_regimen_code,
    	c.patient_id,
    	pol.id AS policy_id,
    	pol.item_id_arr,
    	smo.work_territory_id AS terr_smo,
    	mo.work_territory_id AS terr_mo,
    	reg.clinic_id
	FROM
		fin_bill_policy pol 
    	JOIN pim_individual_doc doc ON doc.id = pol.id
    	JOIN fin_bill_cases c ON doc.indiv_id = c.patient_id AND c.bill_id = pol.bill_id
    	JOIN fin_bill_main_extended ex ON ex.bill_id = pol.bill_id
    	LEFT JOIN pim_organization smo ON smo.id = pol.issuer_id
    	LEFT JOIN pim_organization mo ON mo.id = ex.rcp_id
    	LEFT JOIN pci_patient_reg reg ON reg.patient_id = c.patient_id AND reg.type_id = 1 AND reg.state_id = 1
	WHERE
		pol.bill_id = p1_bill_id 
LOOP
	IF _validation_pol_enabled[1] AND (_r.care_regimen_code = '1') AND (_r.terr_mo IS NOT NULL) AND
       (_r.terr_smo IS NOT NULL) AND (COALESCE(_r.terr_mo,0) = COALESCE(_r.terr_smo,0)) AND
       (_r.clinic_id IS NULL) THEN 
    	INSERT INTO fin_bill_spec_item_error (id, error, code, item_id)
               SELECT nextval ('fin_bill_spec_item_error_seq'), _validation_pol_title[1], 'NO_CLINIC_BINDING', unnest (_r.item_id_arr);
    END IF;
END LOOP; 
*/

--######################### ПРОВЕРКИ НА УРОВНЕ ВСЕГО СЧЕТА  #########################-- 
/*
_validation_bill_code := ARRAY 
    [
       'BILL_CASE_TYPE_IS_EMPTY'					--1
    ];
    
 FOREACH _v IN ARRAY _validation_bill_code 
 LOOP 
     SELECT 
         coalesce (u.enabled, v.enabled) AS enabled, title INTO _r 
     FROM 
         fin_bill_validation                AS v 
         LEFT JOIN fin_bill_validation_user AS u ON u.validation_id = v.id 
     WHERE 
         v.code = _v;
         
     _validation_bill_enabled := _validation_bill_enabled || _r.enabled;
     _validation_bill_title   := _validation_bill_title   || _r.title  ;
 END LOOP;
   
 DELETE FROM fin_bill_spec_item_error AS e USING fin_bill_spec_item AS i 
 WHERE 
     e.code = ANY (_validation_bill_code) AND i.bill_id = p1_bill_id AND i.id = e.item_id
 ;
 */
 IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_spec_validate_regional. 14'); END IF; 
 ---Предупреждения
 FOR _r IN 
         
          SELECT  s.patient_id, p.employee_id,s.employee_speciality_code, s.srv_rendered_bdate,array_agg(s.srv_rendered_id ORDER by s.srv_rendered_id) as srv_rendered_id_arr,
          array_agg(s.spec_item_id ORDER by s.srv_rendered_id) AS spec_item_id_arr, array_agg(s.service_code ORDER by s.srv_rendered_id) AS service_code_arr
          FROM (SELECT srv_rendered_id, patient_id, employee_speciality_code, srv_rendered_bdate, spec_item_id,left(service_code,1) as service_alfa, service_code,(region_data->'is_pos')::boolean as is_pos, (region_data->'is_mrt')::boolean as is_mrt, doctor_code::integer as doctor_code,
                (region_data->'is_paid')::boolean as is_paid FROM billing.fin_bill_steps s  WHERE s.bill_id=p1_bill_id
                ) s 
          JOIN pim_employee_position p ON p.id=s.doctor_code
          WHERE s.is_pos AND s.is_paid AND not s.is_mrt AND s.service_alfa in ('A','B') 
          GROUP by 1,2,3,4
          HAVING count(*)>1
        LOOP
            FOR _i IN 2..ARRAY_LENGTH(_r.spec_item_id_arr,1) 
                LOOP
                   UPDATE fin_bill_spec_item i SET price=0, comment=c.comment_add||coalesce(comment,'')
                     FROM (select 'Предупреждение: Дубль услуги '||_r.service_code_arr[1]||' ('||_host||'/cases/service/'||_r.srv_rendered_id_arr[1]::text||'/edit?external=true&backUrl=/billing%2Fbills%2F'||p1_bill_id::TEXT||'%2Fspec >'||_r.srv_rendered_id_arr[1]::text||'</a> ) </br> '::text
                       as comment_add)c
                   WHERE i.id=_r.spec_item_id_arr[_i]
                    and not (i.comment = c.comment_add||coalesce(i.comment,'')
                            and i.price = 0);
                END LOOP;
        END LOOP;
 IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_spec_validate_regional. 8'); END IF; 
IF _validation_step_enabled[27] AND _bill_type='app' THEN
  FOR _r IN 
  
  /*
         WITH sv AS 
         (SELECT s.spec_item_id, s.service_code, s.srv_rendered_id, s.srv_rendered_bdate, s.patient_id,s.case_id, left(s.service_code,7) as service_code_7
          FROM billing.fin_bill_steps s
          WHERE s.bill_id=p1_bill_id AND left(s.service_code,1)='B' AND upper(s.region_data->'is_pos')='TRUE'
         )       
         SELECT s.spec_item_id, s.service_code||'/'||s1.service_code||'('||_host||'/cases/case/'||s1.case_id::text||'/edit?external=true&backUrl=/billing%2Fbills%2F'||p1_bill_id::TEXT||'%2Fspec >'||s1.case_id::text||'</a> )' as service_code_str
         FROM sv s
         JOIN sv s1 ON s.patient_id=s1.patient_id AND s.srv_rendered_id<>s1.srv_rendered_id 
         AND s.srv_rendered_bdate=s1.srv_rendered_bdate and s.service_code_7=s1.service_code_7
    */
           SELECT patient_id, srv_rendered_bdate, left(service_code,7) as service_code_7, array_agg(service_code order by srv_rendered_id) AS service_code_arr, 
                  array_agg(case_id order by srv_rendered_id) as case_id_arr, array_agg(spec_item_id order by srv_rendered_id) as spec_item_id_arr
           FROM billing.fin_bill_steps 
           WHERE bill_id=p1_bill_id AND left(service_code,1)='B' AND upper(region_data->'is_pos')='TRUE'
           GROUP by 1,2,3
           HAVING count(*)>1    
        
        LOOP
            _kol:=ARRAY_LENGTH(_r.case_id_arr,1);
            FOR _J IN 1.._kol
              LOOP
                 _err_text:='Предупреждение: '||_validation_step_title[27]||' ';
                 FOR _K IN 1.._kol
                    LOOP
                       IF _k<>_J THEN
                           _err_text:=_err_text||_r.service_code_arr[_kol]||' / '||_r.service_code_arr[_k]||'('||_host||'/cases/case/'||_r.case_id_arr[_k]::text||'/edit?external=true&backUrl=/billing%2Fbills%2F'||p1_bill_id::TEXT||'%2Fspec >'||_r.case_id_arr[_k]::text||'</a> ) ';
                       
                        END IF;
                    END LOOP;
                    UPDATE fin_bill_spec_item i SET comment=_err_text||' </br> '||coalesce(comment,'')
                    WHERE i.id=_r.spec_item_id_arr[_j];
              END LOOP;                    
        END LOOP;
END IF;  


/*
 устанавливаем ошибки для всех шагов в случае, когда непосредственно ошибочный шаг в спецификацию не попал  
 например SERV_REQUIRED_IN_STEP когда шаг не попадает в спецификацию, т.к. в нем нет ни одной услуги
*/
 IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_spec_validate_regional. 15'); END IF; 
WITH err AS 
( 
SELECT 
    s.bill_id,
	s.case_id,
    s.step_id 
FROM
	public.fin_bill_spec_item_error e 
    JOIN billing.fin_bill_steps s ON e.item_id = s.spec_item_id
WHERE
	s.bill_id = p1_bill_id AND NOT COALESCE(s.spec_err_exists,FALSE)    
)
UPDATE billing.fin_bill_steps AS s 
SET
	spec_err_exists = TRUE 
FROM   
	err 
WHERE 
	s.bill_id = err.bill_id AND s.case_id = err.case_id AND s.step_id = err.step_id 
;     

----------------------------------перенос в основную------------------------------
    --IF EXISTS (SELECT relname FROM pg_class WHERE relname='tmp_fin_bill_cases') THEN
    UPDATE billing.fin_bill_cases AS fbc
       SET
            case_id = tfbc.case_id,
            bill_id = tfbc.bill_id,
            uid = tfbc.uid,
            case_type_code = tfbc.case_type_code,
--             case_mode_id = tfbc.case_mode_id,
--             admission_type_id = tfbc.admission_type_id,
--             repeat_count_code = tfbc.repeat_count_code,
            care_regimen_code = tfbc.care_regimen_code,
            care_level_code = tfbc.care_level_code,
--             ref_clinic_code = tfbc.ref_clinic_code,
--             payment_method_code = tfbc.payment_method_code,
--             injury_code = tfbc.injury_code,
            patient_id = tfbc.patient_id,
--             first_id = tfbc.first_id,
--             first_diagnosis_code = tfbc.first_diagnosis_code,
--             first_admission_date = tfbc.first_admission_date,
--             first_outcome_date = tfbc.first_outcome_date,
            last_id = tfbc.last_id,
--             last_result_code = tfbc.last_result_code,
--             last_result_id = tfbc.last_result_id,
--             last_is_closed = tfbc.last_is_closed,
--             last_care_result = tfbc.last_care_result,
--             last_outcome_date = tfbc.last_outcome_date,
--             last_department_code = tfbc.last_department_code,
--             last_department_name = tfbc.last_department_name,
--             last_speciality_code = tfbc.last_speciality_code,
--             last_doctor_code = tfbc.last_doctor_code,
--             last_doctor_indiv_id = tfbc.last_doctor_indiv_id,
--             last_profile_code = tfbc.last_profile_code,
--             last_outcome_id = tfbc.last_outcome_id,
--             last_outcome_time = tfbc.last_outcome_time,
--             first_admission_time = tfbc.first_admission_time,
--             last_asist_id = tfbc.last_asist_id,
--             last_department_id = tfbc.last_department_id,
            care_regimen_id = tfbc.care_regimen_id,
            care_level_id = tfbc.care_level_id,
            care_providing_form_code = tfbc.care_providing_form_code,
--             provision_condition_code = tfbc.provision_condition_code,
--             ref_clinic_code_oms = tfbc.ref_clinic_code_oms,
            init_goal_code_arr = tfbc.init_goal_code_arr,
--             main_diagnosis_id = tfbc.main_diagnosis_id,
--             disease_type_code = tfbc.disease_type_code,
--             related_diagnosis_arr = tfbc.related_diagnosis_arr,
--             complication_diagnosis_arr = tfbc.complication_diagnosis_arr,
            step_cnt = tfbc.step_cnt,
            id_pac = tfbc.id_pac,
            patient_age = tfbc.patient_age,
            new_born = tfbc.new_born,
--             new_born_part = tfbc.new_born_part,
--             pat_os_sluch = tfbc.pat_os_sluch,
--             pat_birthweight = tfbc.pat_birthweight,
--             birthweight = tfbc.birthweight,
            item_id_arr = tfbc.item_id_arr,
            belonging_type = tfbc.belonging_type,
            active_policy_id = tfbc.active_policy_id,
--             first_diagnosis_id = tfbc.first_diagnosis_id,
--             last_mes_code = tfbc.last_mes_code,
--             last_csg_code = tfbc.last_csg_code,
--             last_vmp_type_code = tfbc.last_vmp_type_code,
--             last_vmp_method_code = tfbc.last_vmp_method_code,
--             last_hsp_department_code = tfbc.last_hsp_department_code,
--             last_hsp_department_name = tfbc.last_hsp_department_name,
--             last_speciality_code_arr = tfbc.last_speciality_code_arr,
--             last_doctor_snils = tfbc.last_doctor_snils,
            open_date = tfbc.open_date,
            close_date = tfbc.close_date,
            main_diagnosis_code = tfbc.main_diagnosis_code,
--             last_hsp_department_id = tfbc.last_hsp_department_id,
--             time_gone_id = tfbc.time_gone_id,
--             last_deviation_reason_code = tfbc.last_deviation_reason_code,
--             sovmp = tfbc.sovmp,
            vmp_flag = tfbc.vmp_flag,
            region_data = tfbc.region_data

	/*,
		aud_who = tfbc.aud_who,
		aud_when = tfbc.aud_when,
		aud_source = tfbc.aud_source,
		aud_who_create = tfbc.aud_who_create,
		aud_when_create = tfbc.aud_when_create,
		aud_source_create = tfbc.aud_source_create*/
      FROM tmp_fin_bill_cases AS tfbc
     WHERE fbc.bill_id = tfbc.bill_id
           AND fbc.case_id = tfbc.case_id
AND (


               coalesce(fbc.uid, '-1') != coalesce(tfbc.uid, '-1')
            OR coalesce(fbc.case_type_code, '-1') != coalesce(tfbc.case_type_code, '-1')
--             OR coalesce(fbc.case_mode_id, -1) != coalesce(tfbc.case_mode_id, -1)
--             OR coalesce(fbc.admission_type_id, -1) != coalesce(tfbc.admission_type_id, -1)
--             OR coalesce(fbc.repeat_count_code, '-1') != coalesce(tfbc.repeat_count_code, '-1')
            OR coalesce(fbc.care_regimen_code, '-1') != coalesce(tfbc.care_regimen_code, '-1')
            OR coalesce(fbc.care_level_code, '-1') != coalesce(tfbc.care_level_code, '-1')
--             OR coalesce(fbc.ref_clinic_code, '-1') != coalesce(tfbc.ref_clinic_code, '-1')
--             OR coalesce(fbc.payment_method_code, '-1') != coalesce(tfbc.payment_method_code, '-1')
--             OR coalesce(fbc.injury_code, '-1') != coalesce(tfbc.injury_code, '-1')
            OR coalesce(fbc.patient_id, -1) != coalesce(tfbc.patient_id, -1)
--             OR coalesce(fbc.first_id, -1) != coalesce(tfbc.first_id, -1)
--             OR coalesce(fbc.first_diagnosis_code, '-1') != coalesce(tfbc.first_diagnosis_code, '-1')
--             OR coalesce(fbc.first_admission_date, date '19000101') != coalesce(tfbc.first_admission_date, date '19000101')
--             OR coalesce(fbc.first_outcome_date, date '19000101') != coalesce(tfbc.first_outcome_date, date '19000101')
            OR coalesce(fbc.last_id, -1) != coalesce(tfbc.last_id, -1)
--             OR coalesce(fbc.last_result_code, '-1') != coalesce(tfbc.last_result_code, '-1')
--             OR coalesce(fbc.last_result_id, -1) != coalesce(tfbc.last_result_id, -1)
--             OR coalesce(fbc.last_is_closed, false) != coalesce(tfbc.last_is_closed, false)
--             OR coalesce(fbc.last_care_result, '-1') != coalesce(tfbc.last_care_result, '-1')
--             OR coalesce(fbc.last_outcome_date, date '19000101') != coalesce(tfbc.last_outcome_date, date '19000101')
--             OR coalesce(fbc.last_department_code, '-1') != coalesce(tfbc.last_department_code, '-1')
--             OR coalesce(fbc.last_department_name, '-1') != coalesce(tfbc.last_department_name, '-1')
--             OR coalesce(fbc.last_speciality_code, '-1') != coalesce(tfbc.last_speciality_code, '-1')
--             OR coalesce(fbc.last_doctor_code, '-1') != coalesce(tfbc.last_doctor_code, '-1')
--             OR coalesce(fbc.last_doctor_indiv_id, -1) != coalesce(tfbc.last_doctor_indiv_id, -1)
--             OR coalesce(fbc.last_profile_code, '-1') != coalesce(tfbc.last_profile_code, '-1')
--             OR coalesce(fbc.last_outcome_id, -1) != coalesce(tfbc.last_outcome_id, -1)
--             OR coalesce(fbc.last_outcome_time, '00:00:01'::time) != coalesce(tfbc.last_outcome_time, '00:00:01'::time)
--             OR coalesce(fbc.first_admission_time, '00:00:01'::time) != coalesce(tfbc.first_admission_time, '00:00:01'::time)
--             OR coalesce(fbc.last_asist_id, -1) != coalesce(tfbc.last_asist_id, -1)
--             OR coalesce(fbc.last_department_id, -1) != coalesce(tfbc.last_department_id, -1)
            OR coalesce(fbc.care_regimen_id, -1) != coalesce(tfbc.care_regimen_id, -1)
            OR coalesce(fbc.care_level_id, -1) != coalesce(tfbc.care_level_id, -1)
            OR coalesce(fbc.care_providing_form_code, '-1') != coalesce(tfbc.care_providing_form_code, '-1')
--             OR coalesce(fbc.provision_condition_code, '-1') != coalesce(tfbc.provision_condition_code, '-1')
--             OR coalesce(fbc.ref_clinic_code_oms, '-1') != coalesce(tfbc.ref_clinic_code_oms, '-1')
            OR coalesce(fbc.init_goal_code_arr::text[], array['']::text[]) != coalesce(tfbc.init_goal_code_arr::text[], array['']::text[])
--             OR coalesce(fbc.main_diagnosis_id, -1) != coalesce(tfbc.main_diagnosis_id, -1)
--             OR coalesce(fbc.disease_type_code, '-1') != coalesce(tfbc.disease_type_code, '-1')
--             OR coalesce(fbc.related_diagnosis_arr::text[], array['']::text[]) != coalesce(tfbc.related_diagnosis_arr::text[], array['']::text[])
--            OR coalesce(fbc.complication_diagnosis_arr::text[], array['']::text[]) != coalesce(tfbc.complication_diagnosis_arr::text[], array['']::text[])
            OR coalesce(fbc.step_cnt, -1) != coalesce(tfbc.step_cnt, -1)
            OR coalesce(fbc.id_pac, '-1') != coalesce(tfbc.id_pac, '-1')
            OR coalesce(fbc.patient_age, -1) != coalesce(tfbc.patient_age, -1)
            OR coalesce(fbc.new_born, false) != coalesce(tfbc.new_born, false)
--             OR coalesce(fbc.new_born_part, '-1') != coalesce(tfbc.new_born_part, '-1')
--             OR coalesce(fbc.pat_os_sluch::text[], array['']::text[]) != coalesce(tfbc.pat_os_sluch::text[], array['']::text[])
--             OR coalesce(fbc.pat_birthweight, -1) != coalesce(tfbc.pat_birthweight, -1)
--             OR coalesce(fbc.birthweight::text[], array['']::text[]) != coalesce(tfbc.birthweight::text[], array['']::text[])
            OR coalesce(fbc.item_id_arr::text[], array['']::text[]) != coalesce(tfbc.item_id_arr::text[], array['']::text[])
            OR coalesce(fbc.belonging_type, '-1') != coalesce(tfbc.belonging_type, '-1')
            OR coalesce(fbc.active_policy_id, -1) != coalesce(tfbc.active_policy_id, -1)
--             OR coalesce(fbc.first_diagnosis_id, -1) != coalesce(tfbc.first_diagnosis_id, -1)
--             OR coalesce(fbc.last_mes_code, '-1') != coalesce(tfbc.last_mes_code, '-1')
--             OR coalesce(fbc.last_csg_code, '-1') != coalesce(tfbc.last_csg_code, '-1')
--             OR coalesce(fbc.last_vmp_type_code, '-1') != coalesce(tfbc.last_vmp_type_code, '-1')
--             OR coalesce(fbc.last_vmp_method_code, '-1') != coalesce(tfbc.last_vmp_method_code, '-1')
--             OR coalesce(fbc.last_hsp_department_code, '-1') != coalesce(tfbc.last_hsp_department_code, '-1')
--             OR coalesce(fbc.last_hsp_department_name, '-1') != coalesce(tfbc.last_hsp_department_name, '-1')
--             OR coalesce(fbc.last_speciality_code_arr::text[], array['']::text[]) != coalesce(tfbc.last_speciality_code_arr::text[], array['']::text[])
--             OR coalesce(fbc.last_doctor_snils, '-1') != coalesce(tfbc.last_doctor_snils, '-1')
            OR coalesce(fbc.open_date, date '19000101') != coalesce(tfbc.open_date, date '19000101')
            OR coalesce(fbc.close_date, date '19000101') != coalesce(tfbc.close_date, date '19000101')
            OR coalesce(fbc.main_diagnosis_code, '-1') != coalesce(tfbc.main_diagnosis_code, '-1')
--             OR coalesce(fbc.last_hsp_department_id, -1) != coalesce(tfbc.last_hsp_department_id, -1)
--             OR coalesce(fbc.time_gone_id, -1) != coalesce(tfbc.time_gone_id, -1)
--             OR coalesce(fbc.last_deviation_reason_code, '-1') != coalesce(tfbc.last_deviation_reason_code, '-1')
--             OR coalesce(fbc.sovmp, -1) != coalesce(tfbc.sovmp, -1)
            OR coalesce(fbc.vmp_flag, false) != coalesce(tfbc.vmp_flag, false)
            OR coalesce(fbc.region_data, ''::hstore) != coalesce(tfbc.region_data, ''::hstore)
    )
    ;


    DROP TABLE tmp_fin_bill_cases;
    --END IF;

---------------------конец переноса-----------------------------


  IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_spec_validate_regional. Конец'); END IF;
END;
$$;

