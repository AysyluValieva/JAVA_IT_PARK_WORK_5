CREATE VIEW inv_holding_form_org AS
  SELECT sn.form_id,
    h.id,
    sn.unit_id,
    sn.clinic_id,
    m.name AS unit_name,
    COALESCE(o.short_name, o.full_name) AS org_name,
    sn.clinic_id AS org_id,
    h.name_trade,
    f.form_full_name,
        CASE (f.id IS NOT NULL)
            WHEN true THEN (f.full_name)::text
            ELSE h.name_trade
        END AS full_name,
    f.form_type_id,
    h.commodity_group_id,
    cg.name AS commodity_group_name,
    h.descr,
    mh.inn_id,
    i.name_rus AS inn_name
   FROM (((((((inv_store_nomenclature sn
     JOIN inv_holding h ON ((h.id = sn.holding_id)))
     JOIN inv_commodity_group cg ON ((cg.id = h.commodity_group_id)))
     LEFT JOIN inv_form f ON ((f.id = sn.form_id)))
     JOIN cmn_measure m ON ((m.id = sn.unit_id)))
     JOIN pim_organization o ON ((o.id = sn.clinic_id)))
     LEFT JOIN inv_md_holding mh ON ((h.id = mh.id)))
     LEFT JOIN inv_inn i ON ((i.id = mh.inn_id)));

