CREATE FUNCTION get_unit_id_by_flag_of_modif(flag integer, holdmodifid integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
DECLARE
 unit_id  integer;
BEGIN
SELECT case when flag=0 then hm.mnei_id
                        else case when flag=1 then hm.extra_pack_unit_id
                                  else case when flag=2 then hm.sec_pack_unit_id end
                             end
       end
INTO unit_id  FROM inventory.hold_modif AS hm where hm.id=holdModifId;

return unit_id;
END;
$$;

