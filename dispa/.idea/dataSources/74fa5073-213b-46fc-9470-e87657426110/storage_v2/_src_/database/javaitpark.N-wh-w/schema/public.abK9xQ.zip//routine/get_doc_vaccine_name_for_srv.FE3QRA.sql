CREATE FUNCTION get_doc_vaccine_name_for_srv(srv_id integer)
  RETURNS text
LANGUAGE plpgsql
AS $$
declare
  i integer;
begin
  RETURN 

(
select d.name_trade || ' ' || coalesce(i.short_name,'') from mc_inv_opr_srv opr_r 
join inv_opr opr on opr.id=opr_r.opr_id and opr_r.service_id=srv_id
join inv_spec spec on spec.opr_id=opr.id
join inv_holding d on d.id=spec.holding_id
join inv_md_holding e on e.id=d.id
join inv_holding_pharm_group f on f.holding_id=e.id
join inv_pharm_group g on g.id=f.pharm_group_id and g.name in ('0010 Вакцины, сыворотки, фаги и анатоксины','0010 Вакцины, сыворотки, фаги и анатоксины в комбинациях')
join inv_form h on h.holding_id=d.id
join inv_form_type i on i.id=h.form_type_id limit 1
)
;
end;
$$;

