CREATE FUNCTION fin_services_generate(p1_step_id integer, p2_service_code text, p3_check_in_case boolean, OUT new_id integer)
  RETURNS integer
STRICT
LANGUAGE plpgsql
AS $$
DECLARE 
    _case_id INTEGER := (SELECT case_id FROM public.mc_step WHERE id = p1_step_id LIMIT 1);
    _clinic_id INTEGER := (SELECT clinic_id FROM public.mc_case WHERE id = _case_id LIMIT 1);
    _check_date DATE := (SELECT outcome_date FROM public.mc_step WHERE id = p1_step_id LIMIT 1);
    _srv_cnt INTEGER := (SELECT count (1) FROM public.sr_service WHERE org_id = _clinic_id AND code = p2_service_code AND daterange (from_dt, to_dt, '[]') @> _check_date);
    _service_id INTEGER;
    _srv_fin_type_arr INTEGER[];
    _p RECORD;
BEGIN
    /*
        version: 2015-12-18
    */
    ---------------------------------------------------проверка на заполнение обязательных полей-----------------------------------------------------
    IF _clinic_id IS NULL THEN RAISE EXCEPTION 'Не указано МО в случае'; END IF;
    -----------------------------------------------проверка на уникальность кода фиктивной услуги в МО-----------------------------------------------
    IF _srv_cnt > 1 THEN RAISE EXCEPTION 'Фиктивная услуга не уникальна в МО'; END IF;
    -----------------------------------------------------------заполнение параметров-----------------------------------------------------------------
    _service_id := (SELECT id FROM public.sr_service WHERE org_id = _clinic_id AND code = p2_service_code);
    _srv_fin_type_arr := ARRAY (SELECT funding_id FROM public.sr_service_fin_type WHERE service_id = _service_id);
    IF _srv_cnt = 1 AND _srv_fin_type_arr = '{}'::INTEGER[] THEN RAISE EXCEPTION 'Не указан вид финансирования для фиктивной услуги'; END IF;
    --------------------------------------------------------добавление фиктивной услуги--------------------------------------------------------------
    IF
        _srv_cnt = 0
    THEN
        new_id := 0;
    ELSE
        --параметры
        SELECT 
            c.id AS case_id, s.id AS step_id, c.funding_id, c.patient_id, s.res_group_id, s.outcome_date INTO STRICT _p
        FROM
            public.mc_case AS c, public.mc_step AS s 
        WHERE
            c.id = s.case_id AND c.id = _case_id AND s.id = p1_step_id
        ;
        --проверка вида финансирования
        IF _p.funding_id <> ALL (_srv_fin_type_arr) THEN RAISE EXCEPTION 'Вид финансирования случая недоступен для услуги'; END IF;
        --проверка на существование
        EXECUTE
            concat 
            (
                'SELECT r.id FROM public.sr_srv_rendered AS r, public.md_srv_rendered AS m WHERE r.id = m.id AND r.service_id = ', _service_id,
                ' AND m.case_id = ', _case_id, CASE WHEN NOT p3_check_in_case THEN concat (' AND m.step_id = ', p1_step_id) ELSE NULL END, ' ORDER BY r.id DESC LIMIT 1'
            )
        INTO new_id
        ;
        --генерация
        IF 
            new_id IS NULL
        THEN
            new_id := nextval ('public.sr_srv_rendered_seq')
            ;
            INSERT INTO public.sr_srv_rendered (id, is_rendered, bdate, edate, quantity, customer_id, service_id, funding_id, res_group_id, org_id, comment)
                VALUES (new_id, TRUE, _p.outcome_date, _p.outcome_date, 1, _p.patient_id, _service_id, _p.funding_id, _p.res_group_id, _clinic_id, 'Услуга создана автоматически при формировании счёта-реестра')
            ;
            INSERT INTO public.md_srv_rendered (id, step_id, case_id) VALUES (new_id, _p.step_id, _p.case_id)
            ;
        END IF;
    END IF;
END;
$$;

