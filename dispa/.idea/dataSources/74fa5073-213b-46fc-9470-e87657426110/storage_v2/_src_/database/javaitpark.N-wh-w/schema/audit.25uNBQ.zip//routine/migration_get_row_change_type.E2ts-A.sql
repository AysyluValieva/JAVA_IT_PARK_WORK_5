CREATE FUNCTION migration_get_row_change_type(_delta hstore, _pk_name character varying)
  RETURNS text
LANGUAGE plpgsql
AS $$
DECLARE
  row_number INT;
BEGIN
  IF (SELECT exists(SELECT 1
                    FROM each(_delta) hs
                    WHERE hs.value NOTNULL))
  THEN
    IF (_delta -> _pk_name) ISNULL
    THEN RETURN 'U';
    ELSE RETURN 'I'; END IF;
  ELSE RETURN 'D'; END IF;
END;
$$;

