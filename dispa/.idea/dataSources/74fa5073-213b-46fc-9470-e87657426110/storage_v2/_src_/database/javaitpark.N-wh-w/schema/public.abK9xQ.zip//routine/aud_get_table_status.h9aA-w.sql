CREATE FUNCTION aud_get_table_status(table_name text)
  RETURNS character varying
LANGUAGE plpgsql
AS $$
DECLARE
    enabled TEXT;
    aud_level TEXT;
  BEGIN
    SELECT pg_trigger.tgenabled INTO enabled
    FROM pg_trigger
    WHERE tgname = 'audit_trigger_full' AND EXISTS(SELECT 1
                                               FROM information_schema.triggers
                                               WHERE trigger_name = pg_trigger.tgname
                                                     AND
                                                     (event_object_schema || '."' || event_object_table || '"' = $1 OR
                                                      event_object_schema || '.' || event_object_table = $1 OR
                                                      event_object_table = $1));
    IF (enabled IS NOT NULL)
    THEN
      IF(enabled ='D') THEN RETURN 'FULL_AUDITED_OFF'; ELSE RETURN 'FULL_AUDITED_ON'; END IF;
    ELSE
      SELECT pg_trigger.tgenabled INTO enabled
      FROM pg_trigger
      WHERE tgname = 'audit_trigger' AND EXISTS(SELECT 1
                                                 FROM information_schema.triggers
                                                 WHERE trigger_name = pg_trigger.tgname
                                                       AND
                                                       (event_object_schema || '."' || event_object_table || '"' = $1 OR
                                                        event_object_schema || '.' || event_object_table = $1 OR
                                                        event_object_table = $1));
      IF(enabled is NULL ) THEN  RETURN 'NO'; END IF;
      IF(enabled ='D') THEN RETURN 'AUDITED_OFF'; ELSE RETURN 'AUDITED_ON'; END IF;
    END IF;
  END;
$$;

