CREATE FUNCTION fin_fill_pivot_patients_table(p1_bill_id integer)
  RETURNS void
STRICT
LANGUAGE plpgsql
AS $$
DECLARE
    _code_snils_ind_id INTEGER;
BEGIN
    /*
        version: 2015-07-21
    */
    IF EXISTS (SELECT 1 FROM billing.fin_bill_patients WHERE bill_id = p1_bill_id) THEN DELETE FROM billing.fin_bill_patients WHERE bill_id = p1_bill_id; END IF;
    
    _code_snils_ind_id := (SELECT id FROM public.pim_code_type WHERE code = 'SNILS');
    
    INSERT INTO billing.fin_bill_patients (bill_id, from_date, to_date, id_pac, patient_id, representative_id, new_born, item_id_arr)
        SELECT
            bill_id, from_date, to_date, id_pac, patient_id, representative_id, new_born, array_agg (fin_bill_spec_item_id)
        FROM 
            billing.fin_bill_generate
        WHERE 
            bill_id = p1_bill_id AND NOT is_sifted
        GROUP BY 1, 2, 3, 4, 5, 6, 7
    ;
    --основная информация о пациенте
    WITH patient AS 
    (
        SELECT 
            f.bill_id,
            f.patient_id,
            initcap (coalesce (trim (i.name), '')) AS name,
            initcap (coalesce (trim (i.surname), '')) AS surname,
            initcap (coalesce (trim (i.patr_name), '')) AS patr_name,
            i.birth_dt, 
            coalesce (trim ((SELECT code FROM public.pim_gender WHERE id = i.gender_id LIMIT 1)), '') AS gender_code,
            concat (i.gender_id, to_char (i.birth_dt, 'DDMMYY'), coalesce (left (p.newborn_number::TEXT, 2), '1')) AS new_born_part,
            p.birthweight,
            (SELECT code FROM public.md_soc_group WHERE id = p.social_group_id LIMIT 1) AS social_status
        FROM
            billing.fin_bill_patients AS f
            JOIN public.pim_individual AS i ON i.id = f.patient_id
            LEFT JOIN LATERAL (SELECT birthweight, newborn_number, social_group_id FROM public.pci_patient WHERE id = i.id LIMIT 1) AS p ON TRUE
        WHERE
            f.bill_id = p1_bill_id
    )
    UPDATE billing.fin_bill_patients AS f
    SET
        new_born_part     = t.new_born_part,
        pat_name          = t.name         ,
        pat_surname       = t.surname      ,
        pat_patr_name     = t.patr_name    ,
        pat_birth_dt      = t.birth_dt     ,
        pat_gender_code   = t.gender_code  ,
        pat_birthweight   = t.birthweight  ,
        pat_social_status = t.social_status
    FROM 
        patient AS t
    WHERE
        f.bill_id = t.bill_id AND f.patient_id = t.patient_id
    ;
    UPDATE billing.fin_bill_patients AS f
    SET
        pat_os_sluch = ARRAY 
                       (
                           SELECT c.ui_code FROM public.pci_patient_part_case AS p, public.pci_part_case AS c 
                           WHERE 
                               c.id = p.part_case_id AND p.patient_id = f.patient_id AND daterange (f.from_date, f.to_date, '[]') && daterange (p.from_dt, p.to_dt, '[]') AND c.ui_code IS NOT NULL
                       )
    WHERE
        f.bill_id = p1_bill_id
    ;
    --обновление информации о фамилии, имени и отчестве пациента из паспорта, если такая есть
    WITH d AS 
    (
        SELECT 
            f.bill_id, f.patient_id, d.name, d.surname, d.patr_name
        FROM
            billing.fin_bill_patients AS f
            JOIN LATERAL 
            (
                SELECT
                    initcap (trim (i.name)) AS name,
                    initcap (trim (i.surname)) AS surname,
                    initcap (trim (i.patr_name)) AS patr_name
                FROM
                    public.pim_individual_doc AS i
                WHERE
                    i.type_id = (SELECT id FROM public.pim_doc_type WHERE code = 'PASSPORT_RUSSIAN_FEDERATION' LIMIT 1) 
                    AND (nullif (trim (i.name), '') || nullif (trim (i.surname), '') || nullif (trim (i.patr_name), '')) IS NOT NULL
                    AND i.indiv_id = f.patient_id AND daterange (f.from_date, f.to_date, '[]') && daterange (i.issue_dt, i.expire_dt, '[]')
                ORDER BY i.is_active DESC, i.issue_dt DESC NULLS LAST, i.expire_dt DESC, i.verific_dt DESC NULLS LAST, i.check_dt DESC NULLS LAST
                LIMIT 1
            ) AS d ON TRUE
        WHERE
            f.bill_id = p1_bill_id AND (f.pat_name <> d.name OR f.pat_surname <> d.surname OR f.pat_patr_name <> d.patr_name)
    )
    UPDATE billing.fin_bill_patients AS f
    SET
        pat_name = d.name, pat_surname = d.surname, pat_patr_name = d.patr_name 
    FROM d
    WHERE
        f.bill_id = d.bill_id AND f.patient_id = d.patient_id
    ;
    --документ пациента, удостоверяющий личность; адрес места рождения (текст)
    WITH d AS 
    (
        SELECT 
            f.bill_id, f.patient_id, d.identity_doc_type, d.identity_doc_series, d.identity_doc_number, d.birth_place
        FROM
            billing.fin_bill_patients AS f
            JOIN LATERAL 
            (
                SELECT
                    i.type_id AS identity_doc_type,
                    coalesce (trim (i.series), '') AS identity_doc_series,
                    coalesce (trim (i.number), '') AS identity_doc_number,
                    left (coalesce (trim (i.birth_place), ''), 100) AS birth_place
                FROM
                    public.pim_individual_doc AS i, public.pim_doc_type AS t, public.pim_doc_type_category AS c 
                WHERE
                    t.id = i.type_id AND c.type_id = t.id AND c.category_id = 1 AND daterange (f.from_date, f.to_date, '[]') && daterange (i.issue_dt, i.expire_dt, '[]')
                    AND i.indiv_id = f.patient_id 
                ORDER BY t.priority, i.is_active DESC, i.issue_dt DESC NULLS LAST, i.expire_dt DESC, i.verific_dt DESC NULLS LAST, i.check_dt DESC NULLS LAST
                LIMIT 1
            ) AS d ON TRUE
        WHERE
            f.bill_id = p1_bill_id
    )
    UPDATE billing.fin_bill_patients AS f
    SET
        pat_identity_type = d.identity_doc_type, pat_identity_series = d.identity_doc_series, pat_identity_number = d.identity_doc_number, pat_birth_addr_text = d.birth_place
    FROM d
    WHERE
        f.bill_id = d.bill_id AND f.patient_id = d.patient_id
    ;
    --снилс пациента
    WITH t AS 
    (
        SELECT 
            f.bill_id, f.patient_id, coalesce (regexp_replace (replace (replace (trim (s.code), '-', ''), ' ', ''), '(...)(...)(...)(..)', '\1-\2-\3 \4'), '') AS code
        FROM 
            billing.fin_bill_patients AS f
            LEFT JOIN LATERAL (SELECT code FROM public.pim_indiv_code WHERE indiv_id = f.patient_id AND type_id = _code_snils_ind_id ORDER BY issue_dt DESC NULLS LAST LIMIT 1) AS s ON TRUE
        WHERE
            f.bill_id = p1_bill_id
    )
    UPDATE billing.fin_bill_patients AS f
    SET
        pat_snils = t.code
    FROM t
    WHERE
        f.bill_id = t.bill_id AND f.patient_id = t.patient_id
    ;
    ----адреса пациента
    --адрес места жительства, адрес места пребывания, адрес места рождения
    WITH t AS 
    (
        SELECT 
            p.bill_id, p.patient_id, r.addr_id AS reg_addr_id, f.addr_id AS fact_addr_id, b.addr_id AS birth_addr_id
        FROM
            billing.fin_bill_patients AS p
            LEFT JOIN LATERAL 
            (
                SELECT 
                    a.addr_id 
                FROM 
                    public.pim_party_address AS a, public.pim_party_addr_to_addr_type AS t
                WHERE
                    a.party_id = p.patient_id AND t.party_address_id = a.id AND t.address_type_id = (SELECT id FROM public.pim_address_type WHERE code = 'REGISTER' LIMIT 1)
                ORDER BY a.register_type_id = 1 DESC NULLS LAST, /*a.from_date DESC NULLS LAST, a.to_date DESC,*/ a.is_valid DESC NULLS LAST, a.id DESC
                LIMIT 1
            ) AS r ON TRUE
            LEFT JOIN LATERAL 
            (
                SELECT 
                    a.addr_id 
                FROM 
                    public.pim_party_address AS a, public.pim_party_addr_to_addr_type AS t
                WHERE
                    a.party_id = p.patient_id AND t.party_address_id = a.id AND t.address_type_id = (SELECT id FROM public.pim_address_type WHERE code = 'ACTUAL' LIMIT 1)
                ORDER BY a.register_type_id = 1 DESC NULLS LAST, /*a.from_date DESC NULLS LAST, a.to_date DESC,*/ a.is_valid DESC NULLS LAST, a.id DESC
                LIMIT 1
            ) AS f ON TRUE
            LEFT JOIN LATERAL 
            (
                SELECT 
                    a.addr_id 
                FROM 
                    public.pim_party_address AS a, public.pim_party_addr_to_addr_type AS t
                WHERE
                    a.party_id = p.patient_id AND t.party_address_id = a.id AND t.address_type_id = (SELECT id FROM public.pim_address_type WHERE code = 'BIRTH' LIMIT 1)
                ORDER BY a.register_type_id = 1 DESC NULLS LAST, /*a.from_date DESC NULLS LAST, a.to_date DESC,*/ a.is_valid DESC NULLS LAST, a.id DESC
                LIMIT 1
            ) AS b ON TRUE
        WHERE
            p.bill_id = p1_bill_id --AND (f.from_date, f.to_date) OVERLAPS (coalesce (a.from_date, '1900-01-01'), coalesce (a.to_date, '4000-01-01'))
    )
    UPDATE billing.fin_bill_patients AS f
    SET
        pat_reg_addr_id = t.reg_addr_id, pat_fact_addr_id = t.fact_addr_id, pat_birth_addr_id = t.birth_addr_id
    FROM t
    WHERE
        f.bill_id = t.bill_id AND f.patient_id = t.patient_id
    ;
    --основная информация о представителе
     WITH representative AS 
    (
        SELECT 
            f.bill_id,
            f.id_pac,
            initcap (coalesce (trim (i.name), '')) AS name,
            initcap (coalesce (trim (i.surname), '')) AS surname,
            initcap (coalesce (trim (i.patr_name), '')) AS patr_name,
            i.birth_dt, 
            coalesce (trim ((SELECT code FROM public.pim_gender WHERE id = i.gender_id LIMIT 1)), '') AS gender_code
        FROM
            billing.fin_bill_patients AS f, public.pim_individual AS i
        WHERE
            f.bill_id = p1_bill_id AND i.id = f.representative_id
    )
    UPDATE billing.fin_bill_patients AS f
    SET
        rep_name = t.name, rep_surname = t.surname, rep_patr_name = t.patr_name, rep_birth_dt = t.birth_dt, rep_gender_code = t.gender_code
    FROM 
        representative AS t
    WHERE
        f.bill_id = t.bill_id AND f.id_pac = t.id_pac
    ;
    UPDATE billing.fin_bill_patients AS f
    SET
        rep_os_sluch = ARRAY 
                       (
                           SELECT c.ui_code FROM public.pci_patient_part_case AS p, public.pci_part_case AS c 
                           WHERE 
                               c.id = p.part_case_id AND p.patient_id = f.representative_id AND daterange (f.from_date, f.to_date, '[]') && daterange (p.from_dt, p.to_dt, '[]') AND c.ui_code IS NOT NULL
                       ),
        rep_no_patr_name = EXISTS 
                       (
                           SELECT 1 FROM public.pci_patient_part_case AS p, public.pci_part_case AS c 
                           WHERE 
                               c.id = p.part_case_id AND p.patient_id = f.representative_id AND daterange (f.from_date, f.to_date, '[]') && daterange (p.from_dt, p.to_dt, '[]') 
                               AND 'В документе, удостоверяющем личность, отсутствует отчество' = c.name
                       )
    WHERE
        f.bill_id = p1_bill_id
    ;
    --обновление информации о фамилии, имени и отчестве представителя из паспорта, если такая есть
    WITH d AS 
    (
        SELECT 
            f.bill_id, f.id_pac, d.name, d.surname, d.patr_name
        FROM
            billing.fin_bill_patients AS f
            JOIN LATERAL 
            (
                SELECT
                    initcap (trim (i.name)) AS name,
                    initcap (trim (i.surname)) AS surname,
                    initcap (trim (i.patr_name)) AS patr_name
                FROM
                    public.pim_individual_doc AS i
                WHERE
                    i.type_id = (SELECT id FROM public.pim_doc_type WHERE code = 'PASSPORT_RUSSIAN_FEDERATION' LIMIT 1) 
                    AND (nullif (trim (i.name), '') || nullif (trim (i.surname), '') || nullif (trim (i.patr_name), '')) IS NOT NULL
                    AND i.indiv_id = f.representative_id AND daterange (f.from_date, f.to_date, '[]') && daterange (i.issue_dt, i.expire_dt, '[]')
                ORDER BY i.is_active DESC, i.issue_dt DESC NULLS LAST, i.expire_dt DESC, i.verific_dt DESC NULLS LAST, i.check_dt DESC NULLS LAST
                LIMIT 1
            ) AS d ON TRUE
        WHERE
            f.bill_id = p1_bill_id AND (f.rep_name <> d.name OR f.rep_surname <> d.surname OR f.rep_patr_name <> d.patr_name)
    )
    UPDATE billing.fin_bill_patients AS f
    SET
        rep_name = d.name, rep_surname = d.surname, rep_patr_name = d.patr_name 
    FROM d
    WHERE
        f.bill_id = d.bill_id AND f.id_pac = d.id_pac
    ;
    --документ представителя, удостоверяющий личность; адрес места рождения (текст)
    WITH d AS 
    (
        SELECT 
            f.bill_id, f.id_pac, d.identity_doc_type, d.identity_doc_series, d.identity_doc_number, d.birth_place
        FROM
            billing.fin_bill_patients AS f
            JOIN LATERAL 
            (
                SELECT
                    i.type_id AS identity_doc_type,
                    coalesce (trim (i.series), '') AS identity_doc_series,
                    coalesce (trim (i.number), '') AS identity_doc_number,
                    left (coalesce (trim (i.birth_place), ''), 100) AS birth_place
                FROM
                    public.pim_individual_doc AS i, public.pim_doc_type AS t, public.pim_doc_type_category AS c 
                WHERE
                    t.id = i.type_id AND c.type_id = t.id AND c.category_id = 1 AND daterange (f.from_date, f.to_date, '[]') && daterange (i.issue_dt, i.expire_dt, '[]')
                    AND i.indiv_id = f.representative_id 
                ORDER BY t.priority, i.is_active DESC, i.issue_dt DESC NULLS LAST, i.expire_dt DESC, i.verific_dt DESC NULLS LAST, i.check_dt DESC NULLS LAST
                LIMIT 1
            ) AS d ON TRUE
        WHERE
            f.bill_id = p1_bill_id
    )
    UPDATE billing.fin_bill_patients AS f
    SET
        rep_identity_type = d.identity_doc_type, rep_identity_series = d.identity_doc_series, rep_identity_number = d.identity_doc_number, rep_birth_addr_text = d.birth_place
    FROM d
    WHERE
        f.bill_id = d.bill_id AND f.id_pac = d.id_pac
    ;
    --снилс представителя
    WITH t AS 
    (
        SELECT 
            f.bill_id, f.id_pac, coalesce (regexp_replace (replace (replace (trim (s.code), '-', ''), ' ', ''), '(...)(...)(...)(..)', '\1-\2-\3 \4'), '') AS code
        FROM 
            billing.fin_bill_patients AS f
            LEFT JOIN LATERAL 
            (
                SELECT code FROM public.pim_indiv_code WHERE indiv_id = f.representative_id AND type_id = _code_snils_ind_id ORDER BY issue_dt DESC NULLS LAST LIMIT 1
            ) AS s ON TRUE
        WHERE
            f.bill_id = p1_bill_id
    )
    UPDATE billing.fin_bill_patients AS f
    SET
        rep_snils = t.code
    FROM t
    WHERE
        f.bill_id = t.bill_id AND f.id_pac = t.id_pac
    ;
    ----адреса представителя
    --адрес места жительства, адрес места пребывания, адрес места рождения
    WITH t AS 
    (
        SELECT 
            p.bill_id, p.id_pac, r.addr_id AS reg_addr_id, f.addr_id AS fact_addr_id, b.addr_id AS birth_addr_id
        FROM
            billing.fin_bill_patients AS p
            LEFT JOIN LATERAL 
            (
                SELECT 
                    a.addr_id 
                FROM 
                    public.pim_party_address AS a, public.pim_party_addr_to_addr_type AS t
                WHERE
                    a.party_id = p.representative_id AND t.party_address_id = a.id AND t.address_type_id = (SELECT id FROM public.pim_address_type WHERE code = 'REGISTER' LIMIT 1)
                ORDER BY a.register_type_id = 1 DESC NULLS LAST, /*a.from_date DESC NULLS LAST, a.to_date DESC,*/ a.is_valid DESC NULLS LAST, a.id DESC
                LIMIT 1
            ) AS r ON TRUE
            LEFT JOIN LATERAL 
            (
                SELECT 
                    a.addr_id 
                FROM 
                    public.pim_party_address AS a, public.pim_party_addr_to_addr_type AS t
                WHERE
                    a.party_id = p.representative_id AND t.party_address_id = a.id AND t.address_type_id = (SELECT id FROM public.pim_address_type WHERE code = 'ACTUAL' LIMIT 1)
                ORDER BY a.register_type_id = 1 DESC NULLS LAST, /*a.from_date DESC NULLS LAST, a.to_date DESC,*/ a.is_valid DESC NULLS LAST, a.id DESC
                LIMIT 1
            ) AS f ON TRUE
            LEFT JOIN LATERAL 
            (
                SELECT 
                    a.addr_id 
                FROM 
                    public.pim_party_address AS a, public.pim_party_addr_to_addr_type AS t
                WHERE
                    a.party_id = p.representative_id AND t.party_address_id = a.id AND t.address_type_id = (SELECT id FROM public.pim_address_type WHERE code = 'BIRTH' LIMIT 1)
                ORDER BY a.register_type_id = 1 DESC NULLS LAST, /*a.from_date DESC NULLS LAST, a.to_date DESC,*/ a.is_valid DESC NULLS LAST, a.id DESC
                LIMIT 1
            ) AS b ON TRUE
        WHERE
            p.bill_id = p1_bill_id --AND (f.from_date, f.to_date) OVERLAPS (coalesce (a.from_date, '1900-01-01'), coalesce (a.to_date, '4000-01-01'))
    )
    UPDATE billing.fin_bill_patients AS f
    SET
        rep_reg_addr_id = t.reg_addr_id, rep_fact_addr_id = t.fact_addr_id, rep_birth_addr_id = t.birth_addr_id
    FROM t
    WHERE
        f.bill_id = t.bill_id AND f.id_pac = t.id_pac
    ;
    ----окато для адресов
    UPDATE billing.fin_bill_patients
    SET
        pat_reg_addr_okato   = public.address__get_nearest_okato (pat_reg_addr_id)  ,
        pat_fact_addr_okato  = public.address__get_nearest_okato (pat_fact_addr_id) ,
        pat_birth_addr_okato = public.address__get_nearest_okato (pat_birth_addr_id),
        rep_reg_addr_okato   = public.address__get_nearest_okato (rep_reg_addr_id)  ,
        rep_fact_addr_okato  = public.address__get_nearest_okato (rep_fact_addr_id)
    WHERE
        bill_id = p1_bill_id
    ;
END;
$$;

