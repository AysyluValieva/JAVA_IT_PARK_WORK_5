CREATE FUNCTION delete_indiv_code_if_del_doc()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE
                  _id INTEGER;

                BEGIN
                  IF    TG_OP = 'DELETE' THEN
                    IF (OLD.code_id is not null and not exists (select 1 from pim_individual_doc where code_id = OLD.code_id and id <> OLD.id)) THEN
                        _id = OLD.code_id;
                        DELETE FROM pim_indiv_code where id = _id;
                    END IF;
                    RETURN OLD;
                  END IF;
                END;
$$;

