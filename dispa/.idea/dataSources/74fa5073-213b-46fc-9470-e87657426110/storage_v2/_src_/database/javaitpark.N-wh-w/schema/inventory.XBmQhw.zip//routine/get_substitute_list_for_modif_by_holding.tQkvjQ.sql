CREATE FUNCTION get_substitute_list_for_modif_by_holding(modifid integer, orgid integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
DECLARE
BEGIN
return (select inventory.get_substitute_list_for_modif(modifId, orgId,0));
END;
$$;

