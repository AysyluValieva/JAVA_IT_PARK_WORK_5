CREATE FUNCTION apda_check_district_by_diagnosis_criterion(codes character varying[], district_id integer)
  RETURNS boolean
LANGUAGE plpgsql
AS $$
DECLARE
  code VARCHAR;
BEGIN
  RETURN (SELECT exists(SELECT 1
                        FROM (SELECT unnest($1) AS code) a
                          CROSS JOIN
                          (SELECT
                             d1.code AS code_from,
                             d2.code AS code_to
                           FROM md_district_diagnosis dd
                             JOIN md_diagnosis d1 ON d1.id = dd.from_diagnosis_id
                             JOIN md_diagnosis d2 ON d2.id = dd.to_diagnosis_id
                           WHERE dd.district_id = $2
                          ) b
                        WHERE a.code BETWEEN b.code_from AND b.code_to
                        LIMIT 1));
END;
$$;

