CREATE FUNCTION format_snils(src character varying)
  RETURNS character varying
LANGUAGE plpgsql
AS $$
begin
return
 (select 
  case 
   when length(src) = 11 then 
    concat(substring(src, 1, 3), '-', substring(src, 4, 3), '-', substring(src, 7, 3), ' ', substring(src, 10, 2))
   when length(src) = 14 then src
   else null
  end);
end;
$$;

