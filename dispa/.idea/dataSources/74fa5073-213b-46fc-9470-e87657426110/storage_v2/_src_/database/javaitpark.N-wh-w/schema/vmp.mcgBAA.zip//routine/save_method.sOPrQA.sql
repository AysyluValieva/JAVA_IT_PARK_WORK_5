CREATE FUNCTION save_method(xkind_id integer, xmethod_id integer, xnot_method boolean, xcode text, xname text, xtreatment_kind_id integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
DECLARE
  _method_id INTEGER ;
  _id INTEGER;
BEGIN
  IF ($3 IS NOT TRUE ) THEN
    _method_id = $2;
  ELSE
    INSERT INTO public.mc_vmp_method(id, code, name, treatment_kind_id, type_id, from_dt) VALUES
      (nextval('mc_vmp_method_id_seq'),$4, $5, $6,(SELECT type_id  from vmp.vmp_kind WHERE id = $1 LIMIT 1), current_date) RETURNING id INTO _method_id;
  END IF;
  INSERT INTO vmp.vmp_kind_method (kind_id,method_id) VALUES ($1, _method_id) RETURNING id INTO _id;
  return _id;
END
$$;

