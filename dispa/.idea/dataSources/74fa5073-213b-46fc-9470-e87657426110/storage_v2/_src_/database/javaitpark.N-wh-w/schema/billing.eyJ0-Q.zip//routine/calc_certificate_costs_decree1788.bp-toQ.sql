CREATE FUNCTION calc_certificate_costs_decree1788(cert_id_i integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
BEGIN
--    DELETE FROM billing.cost_certificates_services WHERE cert_id = cert_id_i;
    
  if (select case_id from billing.services_cost_certificate where id = cert_id_i LIMIT 1) is not null
--   справки по случаю
  then PERFORM billing.calc_cert_costs_by_case_decree1788(cert_id_i);
--   справки по периоду
  else PERFORM billing.calc_cert_costs_by_period_decree1788(cert_id_i);
  end if;
END;
$$;

