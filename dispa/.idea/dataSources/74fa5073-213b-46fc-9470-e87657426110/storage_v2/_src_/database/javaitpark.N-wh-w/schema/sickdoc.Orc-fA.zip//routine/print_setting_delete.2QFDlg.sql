CREATE FUNCTION print_setting_delete(p_id integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
BEGIN

  DELETE FROM sickdoc.print_settings
  WHERE id = $1;

END;
$$;

