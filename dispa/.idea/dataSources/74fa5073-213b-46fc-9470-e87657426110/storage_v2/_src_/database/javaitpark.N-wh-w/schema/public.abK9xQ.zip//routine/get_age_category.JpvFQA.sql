CREATE FUNCTION get_age_category(age integer, gender integer DEFAULT 3)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
  age integer;
  gender_code character varying;
begin
  gender_code = (select code from pim_gender where id = gender);
  if age < 14 then return 1;
  else if age >= 15 and age <= 18 then return 2;
  else if age >= 55 and gender_code = 'FEMALE' then return 4;
  else if age >= 60 and gender_code = 'MALE' then return 4;
  else if age > 18 then return 3;
  else return 0;
  end if;
  end if;
  end if;
  end if;
  End if;
end;
$$;

