CREATE FUNCTION validatehealthgroup(xepid integer, xhealthgroup integer)
  RETURNS boolean
LANGUAGE plpgsql
AS $$
declare
                            countDiagnosis integer;
                        begin
                            if (xhealthgroup!=1) then  return true; else
                                countDiagnosis = (select sum (count) from ((select  count (mdd.code) from disp.md_event_patient mep
                                                                                    left join MC_DIAGNOSIS mcd on mcd.case_id = mep.case_id
                                                                                    left join md_diagnosis mdd on mdd.id = mcd.diagnos_id
                                                                                        where mep.id =xepid and mdd.code not like 'Z%'
                                                                                union all
                                                                            select  count (mdd.code)from disp.md_event_patient_diagnosis mepd
                                                                            left join md_diagnosis mdd on mdd.id = mepd.diagnosis_id
                                                                            where mepd.event_patient_id =xepid and mdd.code not like 'Z%'
                                                                             )) as foo);
                                if (countDiagnosis >0) then return false; end if;

                            end if ;
                    return true;
            end;
$$;

