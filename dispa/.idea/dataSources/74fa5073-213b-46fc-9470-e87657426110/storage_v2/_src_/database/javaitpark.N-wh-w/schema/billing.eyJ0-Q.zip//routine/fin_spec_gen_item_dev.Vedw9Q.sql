CREATE FUNCTION fin_spec_gen_item_dev(p1_bill_id integer)
  RETURNS void
STRICT
LANGUAGE plpgsql
AS $$
DECLARE
   _bill_type text:=billing.kurgan_fin_get_type_bill(p1_bill_id);
BEGIN
    /*
        current version date 05.08.2014
        
        changelog https://sources.kirkazan.ru/revisionList.jsp?url=lsd-stable%2Fbilling.configs%2Fspecific%2Ftrunk%2Fsql%2Ffin_spec_gen_item.sql
    */
    ---------------------------------------------------------вставка в спецификацию------------------------------------------------------------------
    
    WITH t AS 
        (
            SELECT
                f.bill_id, f.id
            FROM
                tmp_fin_bill_generate            AS f
                LEFT JOIN public.sr_srv_rendered    AS r ON f.id = r.id
                LEFT JOIN public.pim_individual_doc AS i ON i.id = f.active_policy_id
            WHERE
                1 = 1 /*f.bill_id = p1_bill_id*/ AND NOT f.is_sifted AND (f.active_policy_id IS NOT NULL AND i IS NULL OR r IS NULL)
        )
        UPDATE tmp_fin_bill_generate AS f
        SET 
            is_sifted = TRUE, sifting_cause = 'Услуга или полис отсутствует в базе' 
        FROM t
        WHERE 
            1 = 1 /*f.bill_id = t.bill_id*/ AND f.id = t.id
        ;
	
	--удаляем из fbsi то, что "ушло" из fbg, в т.ч. те записи, которые стали IS_SIFTED
	DELETE FROM public.fin_bill_spec_item i WHERE i.bill_id = p1_bill_id AND NOT EXISTS(SELECT 1 FROM tmp_fin_bill_generate f WHERE f.id = i.service_id AND NOT is_sifted); --отвязываемся от избыточной связки по fin_bill_spec_item_id)   
	

	WITH tt_fbg AS 
	(
		SELECT 	price, 
			tariff,
			bill_id, 
			id,
			active_policy_id, 
			dense_rank () OVER (ORDER BY case_id) AS number,
			comment
		FROM tmp_fin_bill_generate
		WHERE NOT is_sifted
	),
	tt_upd AS
	(
		--сохранившееся апдейтим при наличии изменений. 
		
		-- NB (by Davydov): в Кургане на момент выполнения данной функции нет полностью заполненных price/tarif. Поэтому адпейтим с выборкой по заполненным.
		-- 			Для нового счета всё равно будет переапдейт fin_bill_spec_item далее в fin_fill_price, но с этим автовакуум всяко справится.
		-- 			Главное, что при повторных генерациях, коих основная масса, не будет лишних апдейтов (кроме нарастающей дельты по случаям).
		
		UPDATE public.fin_bill_spec_item AS i
			SET 	price = round (t.price, 2),
				tariff = t.tariff,
				is_deleted = false, --если осталось, то могло стать в рамках других БП true/null. Но мы как бы перезаливаем, поэтому проставляем "исходный" true, если изменилось
				doc_id	= t.active_policy_id,
				number = t.number,
				comment = t.comment,
				status_id = 1 --если осталось, то могло стать в рамках других БП любым другим значением. Но мы как бы перезаливаем, поэтому проставляем "исходную" 1цу, если изменилось
		FROM tt_fbg t
		WHERE 1=1
			AND i.service_id = t.id
			AND i.bill_id = p1_bill_id --опять отвязались от fin_bill_spec_item_id
			AND (	COALESCE(i.price, 0) <> COALESCE(t.price, 0)
				OR COALESCE(i.tariff, 0) <> COALESCE(t.tariff, 0)
				OR COALESCE(i.is_deleted, true) <> false
				OR COALESCE(i.doc_id, -1) <> COALESCE(t.active_policy_id, -1)
				OR COALESCE(i.number, -1) <> t.number
				OR COALESCE(i.comment, '') <> COALESCE(t.comment, '')
				OR COALESCE(i.status_id, -1) <> 1)
	)
	--вставляем новое (то чего нет в fbsi)
	INSERT INTO public.fin_bill_spec_item (price, tariff, id, is_deleted, bill_id, service_id, doc_id, number, comment, status_id)
	SELECT	t.price,
		t.tariff,
		nextval ('public.fin_bill_spec_item_seq'),
		false,
		t.bill_id,
		t.id, 
		t.active_policy_id,
		t.number,
		t.comment,
		1
	FROM tt_fbg t
	WHERE NOT EXISTS(SELECT 1 FROM public.fin_bill_spec_item si WHERE t.id = si.service_id AND si.bill_id = p1_bill_id)
	;

	--проставляем связь (вновь вставленные и старые одним апдейтом)
	UPDATE tmp_fin_bill_generate AS b
		SET fin_bill_spec_item_id 	= fbsi.id,
		    b_fin_bill_spec_item_id 	= fbsi.id --можно и не учитывать здесь и проставлять только в переливке в постоянную таблицу, но кто знает, вдруг где-то в транке читается именно это поле (надо поискать потом)...
	FROM public.fin_bill_spec_item fbsi
	WHERE 1=1
		AND b.id = fbsi.service_id
		AND NOT is_sifted
	;	


EXCEPTION
    WHEN NO_DATA_FOUND THEN RAISE EXCEPTION 'Отсутствуют данные по счёту';
END;
$$;

