CREATE FUNCTION md_driver_card_open_function(xcardid integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
begin
  update gibdd.md_gibdd_reference set status = 1, close_reason_id = null where id = xcardid;
  update gibdd.md_gibdd_reference set is_reopen = true, reopen_dt = current_date where id = xcardid;
end;
$$;

