CREATE FUNCTION apdam_create_district_extended_context()
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
  query VARCHAR;
BEGIN
  DROP TABLE IF EXISTS apdam_district_extended;
  CREATE UNLOGGED TABLE apdam_district_extended WITH (AUTOVACUUM_ENABLED = FALSE
  ) AS
    SELECT
      d.district_id,
      CASE WHEN d.level_id = 6
        THEN d.address_id
      ELSE ext.id
      END                                      AS address_id,
      d.building_pattern,
      d.org_terminal_id,
      d.diagnosis_terminal_id,
      d.age_terminal_id,
      d.gender_terminal_id,
      d.benefit_terminal_id,
      coalesce(d.orgs, ARRAY [] :: INT [])     AS orgs,
      coalesce(d.benefits, ARRAY [] :: INT []) AS benefits,
      d.diagnos_code_from,
      d.diagnos_code_to,
      coalesce(d.age_from, -1)                 AS age_from,
      coalesce(d.age_to, -1)                   AS age_to,
      coalesce(d.gender_id, -1)                AS gender_id
    FROM apdam_district d
      LEFT JOIN LATERAL (WITH RECURSIVE cte AS (
        SELECT *
        FROM address_element
        WHERE id = d.address_id
        UNION
        SELECT ae.*
        FROM address_element ae
          JOIN cte ON cte.id = ae.parent_id AND ae.level_id < 7
      )
      SELECT
        cte.id AS id,
        cte.level_id
      FROM cte) ext ON d.level_id IN (4, 5);

  CREATE INDEX ON apdam_district_extended USING BTREE (address_id);
END;
$$;

