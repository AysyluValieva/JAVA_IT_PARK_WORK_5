CREATE FUNCTION get_age(birth_dt date, open_dt date)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
  age integer;
begin
  if birth_dt IS NULL or open_dt IS NULL then return -1;
  end if;
  age = DATE_PART('year', open_dt) - DATE_PART('year', birth_dt) - (CASE TO_CHAR(open_dt, 'MMDD') < TO_CHAR(birth_dt, 'MMDD') WHEN TRUE THEN 1 ELSE 0 END);
  return age;
end;
$$;

