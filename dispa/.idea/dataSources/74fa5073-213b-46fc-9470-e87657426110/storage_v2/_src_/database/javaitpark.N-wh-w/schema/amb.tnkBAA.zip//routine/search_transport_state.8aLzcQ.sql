CREATE FUNCTION search_transport_state(xtr integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
    xtime timestamp;
    cs record;
    xstate integer;
    result integer;
  begin
    select into xtime from_dt from amb.pim_transport where id = xtr;
	select into xstate, result state_id,id from amb.pim_transport_state where transport_id = xtr order by from_dt limit 1;
    for cs in
    	select id,transport_id,state_id,from_dt from amb.pim_transport_state where transport_id = xtr
    loop
        if (cs.from_dt >= xtime) and (cs.state_id <> xstate)
        THEN
        	xtime = cs.from_dt;
            xstate = cs.state_id;
            result = cs.id;
        end if;
    end loop;
    return result;
  end;
$$;

