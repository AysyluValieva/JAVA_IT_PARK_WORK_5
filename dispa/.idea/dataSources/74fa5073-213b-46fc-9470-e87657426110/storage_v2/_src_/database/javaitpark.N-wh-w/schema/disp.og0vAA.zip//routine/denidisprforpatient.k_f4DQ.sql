CREATE FUNCTION denidisprforpatient(xstatus integer, xagreedate character varying, xepid integer, xdenialservice character varying, xappropiatservices character varying, realservices character varying)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
          i integer;
          q_seq integer;
          pci integer;
          rstatus integer;
          mmcrid integer;
          eventcode text;
          mviews record;
          xservices character varying;
          xserviceid json;
          mesp integer;
        begin


if realServices is  NULL THEN
PERFORM disp.agreement (xagreedate, xepid, xappropiatservices);

xservices=(select array_to_json(array_agg(row_to_json(serv))) from (select id from disp.md_event_service_patient  where event_patient_id = xepid) as serv);
	IF xstatus=1 THEN
		foreach xserviceid in array array(select value from json_array_elements(cast(xdenialservice as json)))
		LOOP
			mesp=(select id from disp.md_event_service_patient where service_id=xserviceid::text::int and event_patient_id=xepid);
			update disp.md_event_service_patient  set status = 2 where  id =mesp;
			update disp.md_event_service_patient_agreement set agree=False, denial=True, agree_date=to_date(xagreeDate, 'DD.MM.YYYY')  where service_id=mesp;
		END LOOP;
	ELSIF xstatus = 2 THEN
		foreach xserviceid in array array(select value from json_array_elements(cast(xservices as json)))
		LOOP
			update disp.md_event_service_patient  set status = 2 where  id =cast(xserviceid::json->>'id' as integer);
			update disp.md_event_service_patient_agreement set agree=False, denial=True, agree_date=to_date(xagreeDate, 'DD.MM.YYYY')  where service_id=cast(xserviceid::json->>'id' as integer);
		END LOOP;
		if (select count(1) from disp.md_event_agreement where event_patient_id = xepid) > 0 then
        update disp.md_event_agreement set agree = false, denial = true, adate = to_date(xagreeDate, 'DD.MM.YYYY') where event_patient_id = xepid;
    else
        insert into disp.md_event_agreement(id, event_patient_id, agree, denial, adate) values(nextval('disp.md_event_agreement_id_seq'), xepid, false, true, to_date(xagreeDate, 'DD.MM.YYYY'));
    end if;
	END IF;

	END IF;

if realServices is  NOT NULL THEN
xservices=(select array_to_json(array_agg(row_to_json(serv))) from (select id from disp.md_event_service_patient  where event_patient_id = xepid) as serv);
PERFORM disp.agreement (xagreedate, xepid, xservices);
IF xstatus=1 THEN
		foreach xserviceid in array array(select value from json_array_elements(cast(realServices as json)))
		LOOP
			mesp=xserviceid::text::int ;
			update disp.md_event_service_patient  set status = 2 where id =mesp;
			update disp.md_event_service_patient_agreement set agree=False, denial=True, agree_date=to_date(xagreeDate, 'DD.MM.YYYY')  where service_id=mesp;
		END LOOP;
	ELSIF xstatus = 2 THEN
		foreach xserviceid in array array(select value from json_array_elements(cast(xservices as json)))
		LOOP
			update disp.md_event_service_patient set status = 2 where id =cast(xserviceid::json->>'id' as integer);
			update disp.md_event_service_patient_agreement set agree=False, denial=True, agree_date=to_date(xagreeDate, 'DD.MM.YYYY')  where service_id=cast(xserviceid::json->>'id' as integer);
		END LOOP;
		if (select count(1) from disp.md_event_agreement where event_patient_id = xepid) > 0 then
        update disp.md_event_agreement set agree = false, denial = true, adate = to_date(xagreeDate, 'DD.MM.YYYY') where event_patient_id = xepid;
    else
        insert into disp.md_event_agreement(id, event_patient_id, agree, denial, adate) values(nextval('disp.md_event_agreement_id_seq'), xepid, false, true, to_date(xagreeDate, 'DD.MM.YYYY'));
    end if;
	END IF;
END IF;
return i;
end;
$$;

