CREATE FUNCTION get_first_indiv_code_uid(individual_id integer)
  RETURNS text
LANGUAGE plpgsql
AS $$
declare
            begin
            return (select ic.code from pim_indiv_code ic
            join pim_code_type ct on (ic.type_id = ct.id) where ic.indiv_id = individual_id and ct.code = 'UID' limit 1);
            end;
$$;

