CREATE FUNCTION fin_pivot_regional_dev(p1_bill_id integer)
  RETURNS void
STRICT
LANGUAGE plpgsql
AS $$
declare  _bill_type text:=billing.kurgan_fin_get_type_bill(p1_bill_id);
         _department_type_id_arr INTEGER[];
         _department_id_arr INTEGER[];
         _department_id_type_3_arr INTEGER[];
         _org_id INTEGER:=(SELECT rcp_id FROM billing.fin_bill_main_extended WHERE bill_id=p1_bill_id);
         _code_snils_ind_id INTEGER:=(SELECT id FROM public.pim_code_type WHERE code = 'SNILS');
         _is_log BOOLEAN:=TRUE;
         _financing_type_id_OMS INTEGER:=(SELECT id FROM  fin_funding_source_type WHERE code = 'OMS');
BEGIN
     ANALYZE tmp_fin_bill_cases;
--raise notice '1';
    /*
       version: 2016-11-16
    */
    --CREATE INDEX h1idx ON tmp_fin_bill_steps USING GIST (region_data);
    --CREATE INDEX h2idx ON tmp_fin_bill_cases USING GIST (region_data);
    --CREATE INDEX h3idx ON tmp_fin_bill_patients USING GIST (region_data);
--raise notice '2';
    IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_pivot_regional. Начало'); END IF;
--raise notice '3';
    UPDATE tmp_fin_bill_cases AS f
    SET
        last_outcome_time		 = t.last_outcome_time		 ,
        last_deviation_reason_code = t.last_deviation_reason_code,
        vmp_flag				 = t.vmp_flag,
        region_data              = coalesce(f.region_data,hstore('')) || t.region_data
    FROM
       (select hstore ('') as h0) h,
       (
        SELECT
            f.bill_id,
            f.case_id,
            s.outcome_time AS last_outcome_time,
            dev.code AS last_deviation_reason_code,
            coalesce(cl.vmp_flag,FALSE) AS vmp_flag,
            hstore(
                    ARRAY['last_bed_profile_code',
                          'last_bed_profile_name',
                          'ref_cost_build_date',      --дата формирования справки о стоимости
                          'on_ident'
                          ],
                    ARRAY[bed.code,
                          trim(bed.name),
                          (SELECT to_char(dt,'yyyy-mm-dd') FROM public.fin_bill_case_preliminary_cost pre WHERE pre.case_id = f.case_id and pre.error_id = 0 LIMIT 1),
                          'FALSE'
                         ]
                    ) as region_data
        FROM
            tmp_fin_bill_cases                         AS f
            JOIN public.mc_step                            AS s ON s.id = f.last_id
            LEFT JOIN public.hsp_record                    AS h ON h.id = s.id
            LEFT JOIN public.mc_deviation_reason		   AS dev ON s.deviation_reason_id = dev.id
            LEFT JOIN public.mc_care_level					AS cl ON cl.id = f.care_level_id
            LEFT JOIN public.md_bed_profile                AS bed ON bed.id = h.bed_profile_id
        WHERE
            /*f.bill_id = p1_bill_id AND */f.case_id = s.case_id
       ) t
    WHERE
        /*f.bill_id = t.bill_id AND */f.case_id = t.case_id
        -- проверка на изменение в таблице
	AND not (
          coalesce(f.last_outcome_time, '00:00:01') = coalesce(t.last_outcome_time, '00:00:01')
          and coalesce(f.last_deviation_reason_code, '-1') = coalesce(t.last_deviation_reason_code, '-1')
          and coalesce(f.vmp_flag, false) = coalesce(t.vmp_flag, false)
          and coalesce(f.region_data, h0) = coalesce(t.region_data, h0))
    ;
--raise notice '4';
    IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_pivot_regional. 0'); END IF;
    UPDATE tmp_fin_bill_cases AS f
    SET
        last_doctor_indiv_id     = t.last_doctor_indiv_id
    FROM
       (
        SELECT
            f.bill_id,
            f.case_id,
            p.employee_id as last_doctor_indiv_id
        FROM
            tmp_fin_bill_cases                         AS f
            JOIN public.pim_employee_position         AS p ON p.id = f.last_doctor_code::integer
         WHERE
            1 = 1 /*f.bill_id = p1_bill_id*/
       ) t
    WHERE
        1 = 1 /*f.bill_id = t.bill_id*/ AND f.case_id = t.case_id
        -- проверка на изменение в таблице
        and not coalesce(f.last_doctor_indiv_id, -1) = coalesce(t.last_doctor_indiv_id, -1)
    ;
--raise notice '5';
    IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_pivot_regional. 01'); END IF;
    UPDATE tmp_fin_bill_cases AS f
    SET
        last_speciality_code = coalesce (nullif(last_speciality_code_arr[1],''),(
                                                                                    SELECT sp.code
                                                                                    FROM PUBLIC.pim_speciality sp
                                                                                    INNER JOIN PUBLIC.pim_employee_to_speciality e2s
                                                                                        ON e2s.speciality_id = sp.id AND e2s.employee_id = last_doctor_indiv_id
                                                                                    limit 1
                                                                                )
                                        )

    WHERE
        1 = 1 /*f.bill_id = p1_bill_id*/
        -- проверка на изменение в таблице
        and not coalesce(f.last_speciality_code, '-1') = coalesce (nullif(last_speciality_code_arr[1],''),(
                                                                                    SELECT sp.code
                                                                                    FROM PUBLIC.pim_speciality sp
                                                                                    INNER JOIN PUBLIC.pim_employee_to_speciality e2s
                                                                                        ON e2s.speciality_id = sp.id AND e2s.employee_id = last_doctor_indiv_id
                                                                                    limit 1
                                                                                ),'-1'
    );
--raise notice '6';


    IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_pivot_regional. 02'); END IF;

--     UPDATE tmp_fin_bill_cases AS f
--     SET
--         last_asist_id            = t.last_asist_id
--     FROM
--        (
--         SELECT
--             f.bill_id,
--             f.case_id,
--             pep.id AS last_asist_id
--         FROM
--             tmp_fin_bill_cases                         AS f
--             JOIN public.mc_step                            AS s ON s.id = f.last_id
--             JOIN public.sr_res_group_relationship          AS gr ON gr.group_id=s.res_group_id AND gr.role_id = 2 --медсестра
--             JOIN public.pim_employee_position_resource     AS pr ON pr.id = gr.resource_id
--     	    JOIN public.pim_employee_position              AS pep ON pr.employee_position_id = pep.id
--         WHERE
--             1 = 1 /*f.bill_id = p1_bill_id*/
--        ) t
--     WHERE
--         1 = 1 /*f.bill_id = t.bill_id*/ AND f.case_id = t.case_id
--         -- проверка на изменение в таблице
--         --and coalesce(f.last_asist_id, -1) <> coalesce(t.last_asist_id, -1)
--     ;

    ANALYZE tmp_fin_bill_cases (case_id);

    UPDATE tmp_fin_bill_cases AS f
    SET
        last_asist_id            = pep.id
    FROM public.mc_step                     AS s 
	JOIN LATERAL (SELECT resource_id FROM public.sr_res_group_relationship          AS gr WHERE gr.group_id=s.res_group_id AND gr.role_id = 2 ORDER BY gr.id DESC LIMIT 1) gr ON true --медсестра
	--JOIN LATERAL (SELECT employee_position_id FROM public.pim_employee_position_resource     AS pr WHERE pr.id = gr.resource_id LIMIT 1) pr ON true
	JOIN public.pim_employee_position_resource     AS pr ON pr.id = gr.resource_id
	JOIN public.pim_employee_position   AS pep ON pr.employee_position_id = pep.id
    WHERE
            1 = 1 /*f.bill_id = p1_bill_id*/
            AND s.id = f.last_id
            and coalesce(f.last_asist_id, -1) <> coalesce(pep.id, -1)
    ;  

--raise notice '7';


     IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_pivot_regional. 1'); END IF;
--raise notice '8';
    IF _bill_type='app' THEN
        _department_type_id_arr:= (SELECT array_agg(id) FROM pim_department_type  WHERE code IN ('1', '2', '11', '9', '8'));
        _department_id_arr:=(SELECT array_agg(id) FROM pim_department WHERE org_id=_org_id AND type_id=ANY(_department_type_id_arr));
        _department_id_type_3_arr:=(SELECT array_agg(id) FROM pim_department WHERE org_id=_org_id AND type_id in (SELECT id FROM pim_department_type WHERE code in ('3','4')));
--raise notice '9';
    IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_pivot_regional. 2'); END IF;
        WITH sv AS
          (
            SELECT s.srv_rendered_id,  c.main_diagnosis_code
            FROM (SELECT bill_id, case_id, srv_rendered_id, coalesce(nullif(srv_diagnosis_code,''),  step_diagnosis_main) srv_diagnosis_code
                  FROM tmp_fin_bill_steps  WHERE 1 = 1 /*bill_id=p1_bill_id*/
                  ) s
            JOIN tmp_fin_bill_cases c ON c.bill_id=s.bill_id AND c.case_id=s.case_id
            WHERE  c.main_diagnosis_code<>s.srv_diagnosis_code AND NOT (s.srv_diagnosis_code=ANY(c.related_diagnosis_arr) OR s.srv_diagnosis_code=ANY(complication_diagnosis_arr))
          )
        UPDATE tmp_fin_bill_steps f SET srv_diagnosis_code=sv.main_diagnosis_code,step_diagnosis_main=sv.main_diagnosis_code FROM sv WHERE 1 = 1 /*f.bill_id=p1_bill_id*/ AND f.srv_rendered_id=sv.srv_rendered_id
        -- проверка на изменение в таблице
        and not (coalesce(f.srv_diagnosis_code, '-1') = coalesce(sv.main_diagnosis_code, '-1')
                 and coalesce(f.step_diagnosis_main, '-1') = coalesce(sv.main_diagnosis_code, '-1') );
--raise notice '10';


    ELSIF _bill_type = 'stac' THEN

         IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_pivot_regional. 3'); END IF;
        _department_type_id_arr:= (SELECT array_agg(id) FROM pim_department_type WHERE code IN ('3', '4', 'SURGERY'));

         IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_pivot_regional. 4'); END IF;
        WITH SV AS
        (SELECT case_id, max(is_tmc) is_tmc
         FROM (SELECT case_id, (region_data->'is_tmc')::integer as is_tmc
               FROM tmp_fin_bill_generate
               WHERE 1 = 1 /*bill_id=p1_bill_id*/ AND not is_sifted
               ) g
         GROUP by 1
        )
        UPDATE tmp_fin_bill_cases f
        SET region_data=coalesce(f.region_data,hstore(''))||hstore('is_tmc',sv.is_tmc::text)
        FROM sv, (select hstore ('') as h0) h
        WHERE 1 = 1 /*f.bill_id=p1_bill_id*/  AND f.case_id=sv.case_id
        -- проверка на изменение в таблице
        and not (coalesce(f.region_data, h0) = coalesce(hstore('is_tmc',sv.is_tmc::text), h0));
    ELSIF _bill_type='smp' THEN
            UPDATE tmp_fin_bill_cases AS f
            SET region_data = coalesce(f.region_data,hstore('')) || hstore('funding',CASE WHEN (SELECT c.funding_id=_financing_type_id_OMS FROM mc_case c WHERE c.id=f.case_id) THEN 'oms' ELSE 'budget' END)
            WHERE 1 = 1 /*f.bill_id=p1_bill_id*/
            -- проверка на изменение в таблице
            and not (coalesce(f.region_data, hstore('')) = coalesce(f.region_data,hstore('')) || hstore('funding',CASE WHEN (SELECT c.funding_id=_financing_type_id_OMS FROM mc_case c WHERE c.id=f.case_id) THEN 'oms' ELSE 'budget' END));
      --raise notice '11';
    END IF;

     IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_pivot_regional. 5'); END IF;
    UPDATE tmp_fin_bill_steps f
        SET region_data=coalesce(f.region_data,hstore(''))||hstore(ARRAY['date_bill_mek',g.region_data->'date_bill_mek','is_mrt',g.region_data->'is_mrt','is_tmc',g.region_data->'is_tmc','pr_nov',g.region_data->'pr_nov'])
        FROM tmp_fin_bill_generate g, (select hstore ('') as h0) h
        WHERE 1 = 1 /*f.bill_id=p1_bill_id AND g.bill_id=p1_bill_id*/ AND f.srv_rendered_id=g.id
        -- проверка на изменение в таблице
        and not (coalesce(f.region_data, h0) = coalesce(hstore(ARRAY['date_bill_mek',g.region_data->'date_bill_mek','is_mrt',g.region_data->'is_mrt','is_tmc',g.region_data->'is_tmc','pr_nov',g.region_data->'pr_nov']), h0));
--raise notice '12';
     IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_pivot_regional. 6'); END IF;
     WITH cte AS
      (
        SELECT id_pac, CASE WHEN NOT new_born THEN public.address__get_nearest_kladr(p.pat_reg_addr_id) ELSE public.address__get_nearest_kladr(p.rep_reg_addr_id) END as kladrg,
                       CASE WHEN NOT new_born THEN public.address__get_nearest_kladr(p.pat_fact_addr_id) ELSE public.address__get_nearest_kladr(p.rep_fact_addr_id) END as kladrp
     	FROM
        	tmp_fin_bill_patients p
		WHERE
        	1 = 1 /*p.bill_id = p1_bill_id*/
	  )

    UPDATE tmp_fin_bill_patients pat
    SET
    	region_data = coalesce (pat.region_data, hstore ('')) || hstore(ARRAY['kladrg', cte.kladrg,'kladrp', cte.kladrp])
	FROM
    	cte, (select hstore ('') as h0) h
    WHERE
    	1 = 1 /*pat.bill_id = p1_bill_id*/ AND pat.id_pac = cte.id_pac
      -- проверка на изменение в таблице
      and not (coalesce(pat.region_data, h0) = coalesce(hstore(ARRAY['kladrg', cte.kladrg,'kladrp', cte.kladrp]), h0));

     IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_pivot_regional. 7'); END IF;
--raise notice '13';

	ANALYZE tmp_fin_bill_cases (case_id);
	ANALYZE tmp_fin_bill_steps (srv_rendered_id);
        --данные медсестер, и замена врача на медсестру
        WITH t AS
            (
               SELECT 	f.srv_rendered_id,
			e.id as ep_id,
			coalesce(s.id,0) as speciality_id,
			coalesce(s.code,'') as speciality_code,
			(u.responsible_id IS NULL or g1.id IS NULL) as is_assist,
			e.position_id,
			p.department_id,
			e.employee_id,
			r.employee_position_id
               FROM tmp_fin_bill_steps f
               JOIN LATERAL (SELECT responsible_id FROM sr_res_group u WHERE u.id=f.res_group_id LIMIT 1) u ON TRUE
               JOIN LATERAL (SELECT resource_id FROM sr_res_group_relationship as g WHERE g.group_id=f.res_group_id AND g.role_id = 2 ORDER BY g.id DESC LIMIT 1) g ON TRUE --медсестра
               LEFT JOIN LATERAL (SELECT id FROM sr_res_group_relationship as g1 WHERE g1.group_id=f.res_group_id AND g1.role_id=1 LIMIT 1) g1 ON TRUE --врач
               --JOIN LATERAL (SELECT employee_position_id FROM pim_employee_position_resource as r WHERE r.id=g.resource_id LIMIT 1) r ON TRUE
               JOIN pim_employee_position_resource as r ON r.id=g.resource_id
               JOIN pim_employee_position as e ON e.id=r.employee_position_id
               JOIN pim_position p ON p.id=e.position_id
               LEFT JOIN pim_speciality s ON s.id=p.speciality_id
               WHERE 1 = 1 /*f.bill_id=p1_bill_id*/
		
            ),
            snils AS
            (   SELECT t.srv_rendered_id,
                       regexp_replace
                            (
                                replace (replace ((array_agg (coalesce (trim (i.code), '') ORDER BY i.issue_dt DESC NULLS LAST))[1], '-', ''), ' ', ''),
                                '(...)(...)(...)(..)',
                                '\1-\2-\3 \4'
                            ) AS snils
                FROM t
                LEFT JOIN public.pim_employee          AS e ON e.id=t.employee_id
                LEFT JOIN public.pim_indiv_code        AS i ON i.indiv_id = e.individual_id AND i.type_id = _code_snils_ind_id
                GROUP by 1
            ),
            sv AS
            (
                SELECT t.*, s.snils
                FROM t
                JOIN snils s ON t.srv_rendered_id=s.srv_rendered_id
            )
        UPDATE tmp_fin_bill_steps f
        SET region_data=coalesce(f.region_data, hstore('')) ||hstore(array['asist',CASE WHEN is_assist THEN '' ELSE CASE WHEN _bill_type = 'app'
                                                                                                                         THEN sv.employee_id::text||lpad(sv.speciality_id::text,3,'0')
                                                                                                                         WHEN _bill_type='stac'
                                                                                                                         THEN sv.employee_position_id::text
                                                                                                                         END
                                                                                   END,
                                                                           'is_doctor', sv.is_assist::TEXT,
                                                                           'asist_snils', CASE WHEN is_assist THEN '' ELSE sv.snils END
                                                                           ]),
            doctor_code=CASE WHEN is_assist THEN sv.ep_id::TEXT ELSE f.doctor_code END,
            speciality_code_arr = CASE WHEN is_assist THEN ARRAY [coalesce (trim (sv.speciality_code), ''), coalesce (trim (sv.speciality_code), '')] ELSE f.speciality_code_arr END,
            position_id = CASE WHEN is_assist THEN sv.position_id ELSE f.position_id END,
            department_id=CASE WHEN is_assist THEN sv.department_id ELSE f.department_id END,
            employee_speciality_code = CASE WHEN is_assist THEN sv.speciality_code ELSE f.employee_speciality_code END,
            doctor_snils= CASE WHEN is_assist THEN sv.snils ELSE f.doctor_snils END
        FROM sv
        WHERE 1 = 1 /*f.bill_id=p1_bill_id*/ AND f.srv_rendered_id=sv.srv_rendered_id;
--raise notice '14';
     IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_pivot_regional. 8'); END IF;
--raise notice '14_1';
    --данные врача из посещения, если в услуге всё пусто
        WITH t AS
            (
               SELECT f.srv_rendered_id, e.id as ep_id, coalesce(s.id,0) as speciality_id, coalesce(s.code,'') as speciality_code,  e.position_id,
                      p.department_id, e.employee_id, t.res_group_id
               FROM tmp_fin_bill_steps f
               JOIN mc_step t ON t.id=f.step_id
               JOIN sr_res_group r ON r.id=t.res_group_id
               JOIN pim_employee_position as e ON e.id=r.responsible_id
               JOIN pim_position p ON p.id=e.position_id
               LEFT JOIN pim_speciality s ON s.id=p.speciality_id
               WHERE 1 = 1 /*f.bill_id=p1_bill_id*/ AND nullif(f.doctor_code,'') is NULL
            ),
            snils AS
            (   SELECT t.srv_rendered_id,
                       regexp_replace
                            (
                                replace (replace ((array_agg (coalesce (trim (i.code), '') ORDER BY i.issue_dt DESC NULLS LAST))[1], '-', ''), ' ', ''),
                                '(...)(...)(...)(..)',
                                '\1-\2-\3 \4'
                            ) AS snils
                FROM t
                LEFT JOIN public.pim_employee          AS e ON e.id=t.employee_id
                LEFT JOIN public.pim_indiv_code        AS i ON i.indiv_id = e.individual_id AND i.type_id = _code_snils_ind_id
                GROUP by 1
            ),
            sv AS
            (
                SELECT t.*, s.snils
                FROM t
                JOIN snils s ON t.srv_rendered_id=s.srv_rendered_id
            )
        UPDATE tmp_fin_bill_steps f
        SET doctor_code=sv.ep_id::TEXT,
            speciality_code_arr = ARRAY [coalesce (trim (sv.speciality_code), ''), coalesce (trim (sv.speciality_code), '')],
            position_id = sv.position_id,
            department_id=sv.department_id,
            employee_speciality_code = sv.speciality_code,
            doctor_snils= sv.snils,
            res_group_id=sv.res_group_id
        FROM sv
        WHERE 1 = 1 /*f.bill_id=p1_bill_id*/ AND f.srv_rendered_id=sv.srv_rendered_id
        -- проверка на изменение в таблице
        and not (coalesce(f.doctor_code,'-1'::text) = coalesce(sv.ep_id::TEXT, '-1'::text)
            and coalesce(f.speciality_code_arr, ARRAY['']::text[])::text[] = coalesce(ARRAY [coalesce (trim (sv.speciality_code), ''), coalesce (trim (sv.speciality_code), '')],ARRAY['']::text[])::text[]
            and coalesce(f.position_id, -1) = coalesce(sv.position_id, -1)
            and coalesce(f.department_id , -1) = coalesce(sv.department_id, -1)
            and coalesce(f.employee_speciality_code, '-1')::text = coalesce(sv.speciality_code, '-1')::text
            and coalesce(f.doctor_snils::text, '-1'::text) = coalesce(sv.snils::text, '-1'::text)
            and coalesce(f.res_group_id, -1) = coalesce(sv.res_group_id, -1)
        )
        ;
--raise notice '15';

     IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_pivot_regional. 9'); END IF;
       ---Замена врача в последнем шаге
       ---Если проставлена медсестра, но нет врача
       WITH sv AS
            (
               SELECT f.case_id, f.last_asist_id, s.code as speciality_code
               FROM tmp_fin_bill_cases f
               JOIN pim_employee_position e ON e.id=f.last_asist_id
               JOIN pim_position p ON p.id=e.position_id
               JOIN pim_speciality s ON s.id=p.speciality_id
               WHERE 1 = 1 /*f.bill_id=p1_bill_id*/ AND f.last_doctor_code is NULL AND f.last_asist_id is NOT NULL
            )
        UPDATE tmp_fin_bill_cases f
        SET last_speciality_code=sv.speciality_code,
            last_doctor_code=sv.last_asist_id::text
        FROM sv
        WHERE 1 = 1 /*f.bill_id=p1_bill_id*/ AND f.case_id=sv.case_id
        -- проверка на изменение в таблице
        and not (coalesce(last_speciality_code, '-1') = coalesce(sv.speciality_code, '-1')
        and coalesce(last_doctor_code , '-1') = coalesce(sv.last_asist_id::text, '-1')
        )
        ;
--raise notice '16';
     IF _bill_type='app' THEN

         IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_pivot_regional. 10'); END IF;
        UPDATE tmp_fin_bill_steps f
        SET region_data=coalesce (f.region_data, hstore ('')) || hstore (ARRAY['is_pos',COALESCE(is_pos,False)::TEXT,'is_paid',coalesce(is_paid,False)::TEXT])
        FROM   sr_service s
        WHERE 1 = 1 /*f.bill_id=p1_bill_id*/ and f.service_id=s.id ;

         IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_pivot_regional. 11'); END IF;
        --все неоплачиваемые (is_paid=FALSE)+специальности 069(service_spec_id is NULL)+те, для которых ресурс нужный в случае + услуги с А не стоматология
        WITH sv AS
        (
          SELECT s.srv_rendered_id, s.position_id, s.doctor_code::integer as doctor_code
          FROM tmp_fin_bill_steps s
          JOIN tmp_fin_bill_cases c ON 1 = 1 /*c.bill_id=s.bill_id*/ AND c.case_id=s.case_id
          WHERE 1 = 1 /*s.bill_id=p1_bill_id*/ AND s.doctor_code is NOT NULL AND (UPPER(s.region_data->'is_paid')='FALSE' OR s.service_spec_id is NULL OR
          (s.department_id=ANY(_department_id_arr) OR s.department_id=ANY(_department_id_type_3_arr) AND c.init_goal_code_arr[1]='7')
          AND (service_spec_code=employee_speciality_code OR service_spec_code IN ('111802', '1118') AND employee_speciality_code IN ('111802', '1118'))
          OR left(s.service_code,1)='A' AND coalesce(s.cul,0)=0)
        ),
        speciality AS
        (
          SELECT sv.srv_rendered_id, lpad(trim(p.speciality_id::TEXT),3,'0') as speciality_id, e.employee_id::TEXT as employee_id
          FROM sv
          JOIN pim_position p ON p.id=sv.position_id
          JOIN pim_employee_position e ON e.id=sv.doctor_code::INTEGER
        )
        UPDATE tmp_fin_bill_steps f
        SET region_data = coalesce(region_data, hstore('')) || hstore(ARRAY['doctor_code', f.doctor_code,'doctor_for_srv',s.employee_id||s.speciality_id])
        FROM speciality s, (select hstore ('') as h0) h
        WHERE 1 = 1 /*f.bill_id=p1_bill_id*/ AND f.srv_rendered_id=s.srv_rendered_id
        -- проверка на изменение в таблице
        and not (coalesce(f.region_data, h0) = coalesce(hstore(ARRAY['doctor_code', f.doctor_code,'doctor_for_srv',s.employee_id||s.speciality_id]), h0))
        ;
--raise notice '17';
         IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_pivot_regional. 12'); END IF;
        --для всех, у которых подразделение поликлиника, перебираем специальности
--raise notice '17_1';
        WITH sv AS
        (
          SELECT s.srv_rendered_id, s.service_spec_code, s.doctor_code::integer as doctor_code
          FROM tmp_fin_bill_steps s
          JOIN tmp_fin_bill_cases c ON 1 = 1 /*c.bill_id=s.bill_id*/ AND c.case_id=s.case_id
          WHERE 1 = 1 /*s.bill_id=p1_bill_id*/ AND (s.region_data->'doctor_for_srv') IS NULL AND (s.department_id=ANY(_department_id_arr) OR s.department_id=ANY(_department_id_type_3_arr) AND c.init_goal_code_arr[1]='7')
        ),
        employee AS
        (
          SELECT sv.*, p.employee_id
          FROM sv
          JOIN pim_employee_position p ON p.id=sv.doctor_code
        ),
        speciality AS
        (
          SELECT e.srv_rendered_id, e.employee_id, s.id as speciatity_id, s.code as speciality_code
          FROM employee e
          JOIN pim_employee_to_speciality p ON p.employee_id=e.employee_id
          JOIN LATERAL (SELECT code_regional FROM pim_speciality WHERE code=e.service_spec_code limit 1) r ON TRUE
          JOIN LATERAL (SELECT i.id, i.code FROM pim_speciality i WHERE i.id=p.speciality_id AND i.code_regional=r.code_regional ORDER by i.code=e.service_spec_code limit 1) s ON TRUE


        )
        UPDATE tmp_fin_bill_steps f
        SET region_data = coalesce(region_data, hstore('')) || hstore(ARRAY['doctor_code', f.doctor_code::TEXT, 'doctor_for_srv',s.employee_id::text||lpad(s.speciatity_id::TEXT,3,'0')]),
            employee_speciality_code=s.speciality_code, position_speciality_code=s.speciality_code, speciality_code_arr = ARRAY [s.speciality_code]::TEXT[]
        FROM speciality s, (select hstore ('') as h0) h
        WHERE 1 = 1 /*f.bill_id=p1_bill_id*/ AND f.srv_rendered_id=s.srv_rendered_id
        -- проверка на изменение в таблице
        and not (coalesce(f.region_data, h0) = coalesce(hstore(ARRAY['doctor_code', f.doctor_code::TEXT, 'doctor_for_srv',s.employee_id::text||lpad(s.speciatity_id::TEXT,3,'0')]))
        and coalesce(f.employee_speciality_code, '-1') =coalesce(s.speciality_code, '-1')
        and coalesce(f.position_speciality_code, '-1') =coalesce(s.speciality_code, '-1')
        and coalesce(f.speciality_code_arr::text[], ARRAY['']::text[]) = coalesce(ARRAY [s.speciality_code]::TEXT[], ARRAY['']::text[])
        )
       ;
--raise notice '18';
         IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_pivot_regional. 13'); END IF;


	ANALYZE tmp_fin_bill_cases (case_id);
	ANALYZE tmp_fin_bill_steps (case_id);
	         
        --Для всех, у кого подразделение не поликлиника, ищем позицию с поликлиника+специальность
        WITH sv AS
            (
              SELECT s.srv_rendered_id, s.doctor_code::INTEGER as doctor_code, s.service_spec_code, s.step_outcome_date, c.init_goal_code_arr[1] as init_goal_code
              FROM tmp_fin_bill_steps s
              JOIN tmp_fin_bill_cases c ON 1 = 1 /*c.bill_id=s.bill_id*/ AND c.case_id=s.case_id
              WHERE 1 = 1 /*s.bill_id=p1_bill_id*/ AND (s.region_data->'doctor_for_srv') IS NULL
            ),
        employee AS
            (
              SELECT  sv.*, p.employee_id
              FROM sv
              JOIN pim_employee_position p ON p.id=sv.doctor_code
            ),
        position AS
            ( SELECT e.srv_rendered_id,
                     e.employee_id,
                     s.id as speciality_id,
                     s.code as speciality_code,
                     array_agg(ep.id ORDER BY p.id) ep_arr,
                     array_agg(p.department_id ORDER BY ep.id) department_id_arr,
                     array_agg(ep.position_id ORDER BY ep.id) AS position_id_arr
              FROM employee e
              JOIN pim_employee_position ep ON ep.employee_id=e.employee_id
              JOIN pim_position p ON p.id=ep.position_id
              JOIN LATERAL (SELECT code_regional FROM pim_speciality WHERE code=e.service_spec_code limit 1) r ON TRUE
              JOIN LATERAL (SELECT i.id, i.code FROM pim_speciality i WHERE i.id=p.speciality_id AND i.code_regional=r.code_regional ORDER BY ep.id limit 1) s ON TRUE
              WHERE (ep.end_date IS NULL OR ep.end_date >= e.step_outcome_date)
                AND (p.end_date IS NULL OR p.end_date >= e.step_outcome_date)
                AND (p.department_id=ANY(_department_id_arr) OR p.department_id=ANY(_department_id_type_3_arr) AND e.init_goal_code='7')

             GROUP by 1,2,3,4
            ),
        no_position AS
            (
              SELECT *
              FROM employee
              WHERE srv_rendered_id NOT IN (SELECT srv_rendered_id FROM position)
            ),
        position_new AS
            ( SELECT e.srv_rendered_id,
                     e.employee_id,
                     e.service_spec_code,
                     array_agg(ep.id ORDER BY p.id) ep_arr,
                     array_agg(p.department_id ORDER BY ep.id) department_id_arr,
                     array_agg(ep.position_id ORDER BY ep.id) AS position_id_arr
              FROM no_position e
              JOIN pim_employee_position ep ON ep.employee_id=e.employee_id
              JOIN pim_position p ON p.id=ep.position_id
              WHERE (ep.end_date IS NULL OR ep.end_date >= e.step_outcome_date)
                AND (p.end_date IS NULL OR p.end_date >= e.step_outcome_date)
                AND (p.department_id=ANY(_department_id_arr) OR p.department_id=ANY(_department_id_type_3_arr) AND e.init_goal_code='7')
            GROUP by 1,2,3
            ),
        speciality AS
            (
              SELECT e.srv_rendered_id,e.employee_id,e.department_id_arr[1] as department_id, e.position_id_arr[1] as position_id, ep_arr[1] as ep_id,
              s.id as speciality_id, s.code as speciality_code
              FROM position_new e
              JOIN pim_employee_to_speciality p ON p.employee_id=e.employee_id
              JOIN LATERAL (SELECT code_regional FROM pim_speciality WHERE code=e.service_spec_code limit 1) r ON TRUE
              JOIN LATERAL (SELECT i.id, i.code FROM pim_speciality i WHERE i.id=p.speciality_id AND i.code_regional=r.code_regional ORDER by i.code=e.service_spec_code limit 1) s ON TRUE

            )
        UPDATE tmp_fin_bill_steps f
        SET department_id = p.department_id,
            position_id = p.position_id,
            region_data = coalesce(f.region_data, hstore('')) || hstore(ARRAY['doctor_code',p.doctor_code,'doctor_for_srv', p.doctor_for_srv]),
            speciality_code_arr = ARRAY [service_spec_code]::TEXT[],
            employee_speciality_code=service_spec_code, position_speciality_code=service_spec_code
        FROM
              (
               SELECT srv_rendered_id, department_id_arr[1] as department_id, position_id_arr[1] as position_id, ep_arr[1]::TEXT as doctor_code, employee_id::TEXT||lpad(speciality_id::text,3,'0') as doctor_for_srv, speciality_code
               FROM position
               UNION ALL
               SELECT srv_rendered_id, department_id, position_id, ep_id::TEXT as doctor_code, employee_id::TEXT||lpad(speciality_id::text,3,'0') as doctor_for_srv, speciality_code FROM speciality
              ) p
        WHERE 1 = 1 /*f.bill_id = p1_bill_id*/ AND f.srv_rendered_id = p.srv_rendered_id;


         IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_pivot_regional. 14'); END IF;
	
	ANALYZE tmp_fin_bill_steps (case_id);
	ANALYZE tmp_fin_bill_steps (step_id);
        
	--проставляем специальность на основании подмены в услугах
        WITH sv AS
            (
              SELECT c.case_id, s.doctor_for_srv, s.employee_speciality_code
              FROM tmp_fin_bill_cases c
              JOIN LATERAL (SELECT region_data->'doctor_for_srv' as doctor_for_srv, employee_speciality_code
			    FROM tmp_fin_bill_steps
			    WHERE 1 = 1 /*bill_id=c.bill_id*/ 
				AND step_id=c.last_id 
				AND doctor_code=c.last_doctor_code 
			    ORDER by (region_data->'is_pos')::Boolean desc, srv_rendered_id DESC
			    LIMIT 1) s ON TRUE
              WHERE 1 =  1 /*c.bill_id=p1_bill_id*/
            )
        UPDATE tmp_fin_bill_cases f
		SET last_speciality_code=sv.employee_speciality_code, region_data=coalesce(f.region_data, hstore(''))||hstore('doctor_for_srv',sv.doctor_for_srv)
        FROM sv, (select hstore ('') as h0) h
        WHERE 1 = 1 /*f.bill_id=p1_bill_id*/ AND f.case_id=sv.case_id
        -- проверка на изменение в таблице
        and not (
		  coalesce(f.last_speciality_code, '-1') = coalesce(sv.employee_speciality_code, '-1')
		  and coalesce(f.region_data, h0) = coalesce(f.region_data, h0)||hstore('doctor_for_srv',sv.doctor_for_srv)
		  )
	;

--         WITH sv AS
--             (
--               SELECT 	region_data->'doctor_for_srv' as doctor_for_srv, 
-- 			employee_speciality_code,
-- 			doctor_code,
-- 			step_id,
-- 			case_id,
-- 			row_number() over (partition by step_id, doctor_code order by (region_data->'is_pos')::Boolean desc) rn
-- 	      FROM tmp_fin_bill_steps
-- 	      WHERE 1 = 1 /*bill_id=c.bill_id*/ 
--             )
--         UPDATE tmp_fin_bill_cases f
-- 		SET last_speciality_code=sv.employee_speciality_code, region_data=coalesce(f.region_data, h0)||hstore('doctor_for_srv',sv.doctor_for_srv)
--         FROM sv, (select hstore ('') as h0) h
--         WHERE 1 = 1 /*f.bill_id=p1_bill_id*/ 
-- 		AND f.case_id=sv.case_id
-- 		AND f.last_id = sv.step_id
-- 		AND f.last_doctor_code = sv.doctor_code
-- 		AND sv.rn = 1
-- 		-- проверка на изменение в таблице
-- 		and not (
-- 		  coalesce(f.last_speciality_code, '-1') = coalesce(sv.employee_speciality_code, '-1')
-- 		  and coalesce(f.region_data, h0) = coalesce(f.region_data, h0)||hstore('doctor_for_srv',sv.doctor_for_srv)
-- 		  )
--         ;
--raise notice '19';
        IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_pivot_regional. 15'); END IF;

	ANALYZE tmp_fin_bill_steps (case_id);
	ANALYZE tmp_fin_bill_steps (step_id);
	        
        --Если специальность не найдена, то подставляем первого врача из последнего посещения
        WITH sv AS
            (
              SELECT c.case_id, s.doctor_for_srv, s.employee_speciality_code
              FROM tmp_fin_bill_cases c
              JOIN LATERAL (
                            SELECT region_data->'doctor_for_srv' as doctor_for_srv, employee_speciality_code
                            FROM tmp_fin_bill_steps
                            WHERE 1 = 1 /*bill_id=c.bill_id*/ AND step_id=c.last_id AND (region_data->'doctor_for_srv') is NOT NULL ORDER by (region_data->'is_pos') DESC, srv_rendered_id DESC
                            limit 1
                            ) s ON TRUE
              WHERE 1 = 1 /*c.bill_id=p1_bill_id*/ AND (c.region_data->'doctor_for_srv') is NULL
            )
        UPDATE tmp_fin_bill_cases f
        SET last_speciality_code=sv.employee_speciality_code, region_data=coalesce(f.region_data, hstore(''))||hstore('doctor_for_srv',sv.doctor_for_srv)
        FROM sv, (select hstore ('') as h0) h
        WHERE 1 = 1 /*f.bill_id=p1_bill_id*/ AND f.case_id=sv.case_id
        -- проверка на изменение в таблице
		and not (
		  coalesce(f.last_speciality_code, '-1') = coalesce(sv.employee_speciality_code, '-1')
		  and coalesce(f.region_data, h0) = coalesce(f.region_data, h0)||hstore('doctor_for_srv',sv.doctor_for_srv)
		  )
        ;
--raise notice '20';
        IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_pivot_regional. 16'); END IF;
        UPDATE tmp_fin_bill_steps
        SET doctor_code=coalesce((region_data->'doctor_code'),doctor_code),
            region_data=coalesce(region_data,hstore(''))||hstore('is_oms_serv',(EXISTS (SELECT 1 FROM billing.kurgan_fys WHERE kod_usl_mz=service_code AND oms='+'))::text),
            urov=billing.fin_get_serv_level_department(step_id,srv_rendered_id,department_id)
        WHERE 1 = 1 /*bill_id=p1_bill_id*/
        -- проверка на изменение в таблице
        --
        ;

        /*
        IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_pivot_regional. 17'); END IF;
        UPDATE tmp_fin_bill_steps SET region_data=coalesce(region_data,hstore(''))||hstore('is_oms_serv',(EXISTS (SELECT 1 FROM billing.kurgan_fys WHERE kod_usl_mz=service_code AND oms='+'))::text)
        WHERE bill_id=p1_bill_id;

        IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_pivot_regional. 18'); END IF;
        UPDATE tmp_fin_bill_steps SET urov=billing.fin_get_serv_level_department(step_id,srv_rendered_id,department_id) WHERE bill_id=p1_bill_id;
         */

    ELSIF  _bill_type='stac'    THEN
--raise notice '21';
        IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_pivot_regional. 18'); END IF;
        UPDATE tmp_fin_bill_steps SET urov=fin_get_step_level(step_id) WHERE 1 = 1 /*bill_id=p1_bill_id*/;
--raise notice '22';
         IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_pivot_regional. 19'); END IF;
        ---врач в шаге
        WITH sv AS
          (
            SELECT
              f.step_id,
              p.id AS doctor_code,
              coalesce (trim (c.code), '') AS speciality_code
            FROM
                (SELECT distinct step_id FROM tmp_fin_bill_steps WHERE 1 = 1 /*bill_id=p1_bill_id*/) AS f
                JOIN public.mc_step                            AS s ON s.id = f.step_id
                JOIN public.sr_res_group                       AS g ON g.id = s.res_group_id
                JOIN public.pim_employee_position              AS p ON p.id = g.responsible_id
                JOIN public.pim_employee                       AS e ON e.id = p.employee_id
                JOIN public.pim_position                       AS t ON t.id = p.position_id
                LEFT JOIN public.pim_speciality                AS c ON c.id = t.speciality_id

          )
        UPDATE tmp_fin_bill_steps AS f
        SET
            region_data = coalesce(f.region_data,hstore('')) || hstore(ARRAY['step_doctor_code',sv.doctor_code::text, 'step_employee_speciality_code',sv.speciality_code])
        FROM sv, (select hstore ('') as h0) h
        WHERE
            1 = 1 /*f.bill_id = p1_bill_id*/ AND f.step_id = sv.step_id
            -- проверка на изменение в таблице
				    AND not (
              coalesce(f.region_data, h0) = coalesce(hstore(ARRAY['step_doctor_code',sv.doctor_code::text, 'step_employee_speciality_code',sv.speciality_code]), h0))

        ;
--raise notice '23';
         IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_pivot_regional. 20'); END IF;
        --если врач в шаге отсутствует, а есть медсестра
        WITH sv AS
          (
            SELECT
              f.step_id,
              e.id AS doctor_code,
              coalesce (trim (c.code), '') AS speciality_code
            FROM
                (SELECT distinct step_id FROM tmp_fin_bill_steps WHERE 1 = 1 /*bill_id=p1_bill_id*/ AND (region_data->'step_doctor_code') is NULL) AS f
                JOIN public.mc_step                            AS s ON s.id = f.step_id
                JOIN sr_res_group_relationship                 AS g ON g.group_id=s.res_group_id AND g.role_id = 2 --медсестра
                JOIN pim_employee_position_resource            AS r ON r.id=g.resource_id
                JOIN pim_employee_position                     AS e ON e.id=r.employee_position_id
                JOIN pim_position                              AS p ON p.id=e.position_id
                LEFT JOIN pim_speciality                       AS c ON c.id=p.speciality_id
               )
        UPDATE tmp_fin_bill_steps AS f
        SET
            region_data = coalesce(f.region_data,hstore('')) || hstore(ARRAY['step_doctor_code',sv.doctor_code::text, 'step_employee_speciality_code',sv.speciality_code])
        FROM sv, (select hstore ('') as h0) h
        WHERE
            1 = 1 /*f.bill_id = p1_bill_id*/ AND f.step_id = sv.step_id
            -- проверка на изменение в таблице
				    AND not (
              coalesce(f.region_data, h0) = coalesce(hstore(ARRAY['step_doctor_code',sv.doctor_code::text, 'step_employee_speciality_code',sv.speciality_code]), h0))
        ;
--raise notice '24';
         IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_pivot_regional. 21'); END IF;
        --если врача в шаге нет, то берем первого из услуги
        WITH sv AS
          (
            SELECT step_id, array_agg(doctor_code order by srv_rendered_id) as doctor_code_arr, array_agg(employee_speciality_code order by srv_rendered_id) as speciality_code_arr
            FROM tmp_fin_bill_steps
            WHERE 1 = 1 /*bill_id=p1_bill_id*/ AND (region_data->'step_doctor_code') is NULL
            GROUP by 1
           )
        UPDATE tmp_fin_bill_steps AS f
        SET
            region_data = coalesce(f.region_data,hstore('')) || hstore(ARRAY['step_doctor_code',sv.doctor_code_arr[1], 'step_employee_speciality_code',sv.speciality_code_arr[1]])
        FROM sv, (select hstore ('') as h0) h
        WHERE
            1 = 1 /*f.bill_id = p1_bill_id*/ AND f.step_id = sv.step_id
            -- проверка на изменение в таблице
				    AND not (coalesce(f.region_data, h0) = coalesce(hstore(ARRAY['step_doctor_code',sv.doctor_code_arr[1], 'step_employee_speciality_code',sv.speciality_code_arr[1]]), h0))
        ;
--raise notice '25';
         IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_pivot_regional. 22'); END IF;
        UPDATE tmp_fin_bill_steps SET region_data=coalesce(region_data,hstore(''))||hstore('is_oms_serv',(NOT EXISTS (SELECT 1 FROM billing.sr_fiction_service_type_kurgan WHERE code=service_code))::text)
        WHERE 1 = 1 /*bill_id=p1_bill_id*/;
--raise notice '26';
    END IF;



    IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_pivot_regional. 23'); END IF;
    UPDATE billing.fin_bill_policy
    SET series=NULL
    WHERE bill_id=p1_bill_id AND type IN ('MHI_UNIFORM', 'ENP')
    -- проверка на изменение в таблице
    and series is not null;
  --raise notice '27';



     IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_pivot_regional. Конец'); END IF;

END;
$$;

