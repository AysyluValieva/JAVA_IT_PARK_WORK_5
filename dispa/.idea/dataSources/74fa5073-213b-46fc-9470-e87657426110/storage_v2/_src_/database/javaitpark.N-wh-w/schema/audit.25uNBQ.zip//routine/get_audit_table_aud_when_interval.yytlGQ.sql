CREATE FUNCTION get_audit_table_aud_when_interval(_table_name character varying, _old_period_code character varying, _new_period_code character varying)
  RETURNS date[]
LANGUAGE plpgsql
AS $$
DECLARE
                  cur_table_name VARCHAR;
                  start_date     DATE;
                  end_date       DATE;
                BEGIN
                  IF _old_period_code = 'none'
                  THEN
                    EXECUTE format('SELECT (min(aud_when))::DATE FROM audit."%1$s"', _table_name)
                    INTO start_date;
                    start_date = date_trunc(_new_period_code, start_date);

                    EXECUTE format('SELECT max(aud_when)::DATE + interval ''1 day'' FROM audit."%1$s"', _table_name)
                    INTO end_date;
                  ELSE
                    SELECT relname
                    INTO cur_table_name
                    FROM pg_class
                    WHERE relreplident = 'd' AND relname :: VARCHAR LIKE concat('%', _table_name, '$%')
                    ORDER BY relname
                    LIMIT 1;

                    EXECUTE format('SELECT (min(aud_when))::DATE FROM audit."%1$s"', cur_table_name)
                    INTO start_date;

                    IF _new_period_code != 'none' THEN start_date = date_trunc(_new_period_code, start_date); END IF;

                    SELECT relname
                    INTO cur_table_name
                    FROM pg_class
                    WHERE relreplident = 'd' AND relname :: VARCHAR LIKE concat('%', _table_name, '$%')
                    ORDER BY relname DESC
                    LIMIT 1;

                    EXECUTE format('SELECT max(aud_when)::DATE + interval ''1 day'' FROM audit."%1$s"', cur_table_name)
                    INTO end_date;
                  END IF;

                  RETURN ARRAY[start_date, end_date];
                END;
$$;

