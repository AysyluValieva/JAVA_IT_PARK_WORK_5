CREATE FUNCTION adr__element_is_city_contains1(id integer)
  RETURNS boolean
LANGUAGE plpgsql
AS $$
declare
  element_id integer := id;
  element record;
begin

  for element in
    select true z
      from address_element_inclusion i join address_element e on i.child_id = element_id and i.parent_id = e.id join address_element_type t on 
      e.type_id = t.id and (t.short_name='г' or t.short_name='городок') limit 1
  loop

    if element.z then
      return true;
    end if;

  end loop;

  return false;

end;
$$;

