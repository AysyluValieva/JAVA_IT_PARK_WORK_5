CREATE FUNCTION fsym_on_i_for_pblc_ph_rm_mngrp()
  RETURNS trigger
LANGUAGE plpgsql
AS $fun$
begin                                                                                                                                                                  
                                   
                                  if 1=1 and "public".sym_triggers_disabled() = 0 then                                                                                                 
                                    insert into "public".sym_data                                                                                                                     
                                    (table_name, event_type, trigger_hist_id, row_data, channel_id, transaction_id, source_node_id, external_data, create_time)                                        
                                    values(                                                                                                                                                            
                                      'pha_room',                                                                                                                                            
                                      'I',                                                                                                                                                             
                                      469,                                                                                                                                             
                                      
          case when new."id" is null then '' else '"' || cast(cast(new."id" as numeric) as varchar) || '"' end||','||
          case when new."bathroom_quantity" is null then '' else '"' || cast(cast(new."bathroom_quantity" as numeric) as varchar) || '"' end||','||
          case when new."ceiling_area" is null then '' else '"' || cast(cast(new."ceiling_area" as numeric) as varchar) || '"' end||','||
          case when new."equipment_area" is null then '' else '"' || cast(cast(new."equipment_area" as numeric) as varchar) || '"' end||','||
          case when new."furniture_area" is null then '' else '"' || cast(cast(new."furniture_area" as numeric) as varchar) || '"' end||','||
          case when new."shower_quantity" is null then '' else '"' || cast(cast(new."shower_quantity" as numeric) as varchar) || '"' end||','||
          case when new."sink_quantity" is null then '' else '"' || cast(cast(new."sink_quantity" as numeric) as varchar) || '"' end||','||
          case when new."toilet_sink_quantity" is null then '' else '"' || cast(cast(new."toilet_sink_quantity" as numeric) as varchar) || '"' end||','||
          case when new."wall_area" is null then '' else '"' || cast(cast(new."wall_area" as numeric) as varchar) || '"' end||','||
          case when new."danger_category_id" is null then '' else '"' || cast(cast(new."danger_category_id" as numeric) as varchar) || '"' end||','||
          case when new."kitchen_quantity" is null then '' else '"' || cast(cast(new."kitchen_quantity" as numeric) as varchar) || '"' end||','||
          case when new."balcony_quantity" is null then '' else '"' || cast(cast(new."balcony_quantity" as numeric) as varchar) || '"' end||','||
          case when new."room_quantity" is null then '' else '"' || cast(cast(new."room_quantity" as numeric) as varchar) || '"' end||','||
          case when new."window_view" is null then '' else '"' || replace(replace(cast(new."window_view" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end,                                                                                                                                                      
                                      'public_pha_room_default',                                                                                                                                                
                                      txid_current(),                                                                                                                                               
                                      "public".sym_node_disabled(),                                                                                                                   
                                      null,                                                                                                                                               
                                      CURRENT_TIMESTAMP                                                                                                                
                                    );                                                                                                                                                                 
                                  end if;                                                                                                                                                              
                                                                                                                                                                               
                                  return null;                                                                                                                                                         
                                end;
$fun$;

