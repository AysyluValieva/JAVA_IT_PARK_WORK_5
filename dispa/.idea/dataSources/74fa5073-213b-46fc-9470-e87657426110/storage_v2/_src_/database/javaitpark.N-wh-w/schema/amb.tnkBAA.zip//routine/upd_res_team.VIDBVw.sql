CREATE FUNCTION upd_res_team(xid integer, xbdate date, xedate date, xradio character varying, xprof integer, xmedprof integer, xbtime time without time zone, xetime time without time zone)
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
                xresid integer;
              begin
                xresid = (select resource_id from amb.sr_res_team where id = xid);
                update amb.sr_res_team set radio_code = xradio,btime = xbtime,etime=xetime where id = xid;
                update sr_res_group set bdate = xbdate,edate = xedate where id = xresid;
                If xprof is not null
                then
                    If not exists (select * from public.md_resgroup_amb_profile where id = xresid)
                        THEN
                            insert into public.md_resgroup_amb_profile (id,profile_id) values (xresid,xprof);
                        ELSE
                            update public.md_resgroup_amb_profile set profile_id = xprof where id = xresid;
                    end if;
                else
                    delete from public.md_resgroup_amb_profile where id = xresid;
                end if;
                if xmedprof is not null --and
                then
                    If not exists (select * from public.sr_res_group_profile where res_group_id = xresid)
                        THEN
                            insert into public.sr_res_group_profile (id,res_group_id,profile_id) values (nextval('sr_res_group_profile_seq'),xresid,xmedprof);
                        ELSE
                            update public.sr_res_group_profile set profile_id = xmedprof where res_group_id = xresid;
                    end if;
               -- else     	delete from public.md_resgroup_amb_profile where id = xresid;
                end if;
              end;
$$;

