CREATE VIEW dimension_date_half_year AS
  SELECT dimension_date.id,
    dimension_date.year_,
    dimension_date.half_of_year,
    dimension_date.aud_who,
    dimension_date.aud_when,
    dimension_date.aud_source,
    dimension_date.aud_who_create,
    dimension_date.aud_when_create,
    dimension_date.aud_source_create
   FROM indicators.dimension_date
  WHERE (dimension_date.dimension_date_def_id = 2);

COMMENT ON VIEW dimension_date_half_year IS 'Временной срез. Год, полугодие';

COMMENT ON COLUMN dimension_date_half_year.id IS 'Идентификатор';

COMMENT ON COLUMN dimension_date_half_year.year_ IS 'Год';

COMMENT ON COLUMN dimension_date_half_year.half_of_year IS 'Полугодие года';

