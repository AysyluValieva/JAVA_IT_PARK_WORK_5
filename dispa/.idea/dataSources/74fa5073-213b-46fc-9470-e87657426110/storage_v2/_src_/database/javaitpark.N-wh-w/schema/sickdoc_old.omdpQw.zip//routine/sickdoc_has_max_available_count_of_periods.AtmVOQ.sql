CREATE FUNCTION sickdoc_has_max_available_count_of_periods(p_id integer)
  RETURNS boolean
IMMUTABLE
LANGUAGE plpgsql
AS $$
BEGIN

  RETURN (SELECT count(1)
          FROM sickdoc.period
          WHERE sickdoc_id = p_id) = 3;

END;
$$;

