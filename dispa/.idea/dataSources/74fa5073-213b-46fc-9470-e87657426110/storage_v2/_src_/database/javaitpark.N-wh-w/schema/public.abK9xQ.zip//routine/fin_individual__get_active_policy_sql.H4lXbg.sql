CREATE FUNCTION fin_individual__get_active_policy_sql(p1_individual_id integer, p2_date date, OUT policy_id integer)
  RETURNS integer
STABLE
LANGUAGE SQL
AS $$
SELECT
        pid.id
    FROM
        pim_individual_doc pid
		JOIN pim_doc_type pdt
			ON pid.type_id = pdt.id
    WHERE 1=1
        AND indiv_id = p1_individual_id
        AND pdt.code IN ('MHI_UNIFORM', 'MHI_TEMP', 'MHI_OLDER')
        AND (p2_date >= issue_dt OR issue_dt IS NULL) AND (p2_date <= expire_dt OR expire_dt IS NULL)
    ORDER BY is_active DESC NULLS LAST, 
		CASE code WHEN 'MHI_UNIFORM' 	THEN 100
			  WHEN 'MHI_TEMP' 	THEN 99
			  WHEN 'MHI_OLDER' 	THEN 98
		END DESC,
		id DESC
    LIMIT 1

$$;

