CREATE FUNCTION saveorphansinspec(xepid integer, xssrid integer, xcaseid integer, xbdate character varying, xresource integer, xmd integer, xdis integer, xcounsel character varying, xreference character varying, xservice integer, xsuspicion boolean, xmake_d boolean, xregistr_id integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
          serviceid integer;
          srrid integer;
          stepid integer;
          sysresid integer;
          result_id integer;
          emplPosId integer;
          dispensaryId integer;
          pci_dispensary_seq integer;
          oldstepid integer;
          maindiagid integer;
        begin
          serviceid = xservice;

          if (select count(mep.id) from disp.md_event_patient mep
                left join MD_SRV_RENDERED msr on msr.case_id = mep.case_id
                inner join SR_SRV_RENDERED ssr on ssr.id = msr.id and ssr.service_id = serviceid
                where mep.id = xepid) > 0 then
              if xssrid IS NULL then
                xssrid = (select ssr.id from disp.md_event_patient mep
                left join MD_SRV_RENDERED msr on msr.case_id = mep.case_id
                inner join SR_SRV_RENDERED ssr on ssr.id = msr.id and ssr.service_id = serviceid
                where mep.id = xepid);
              end if;
              srrid = xssrid;
              update mc_diagnosis set diagnos_id =  xmd, disease_type_id = xdis, establishment_date = COALESCE(to_date(xbdate, 'DD.MM.YYYY'), current_date), is_suspicion = xsuspicion
                where id = (select diagnos_id from disp.md_disp_orphans_inspec where service_id = xssrid);
              update disp.md_dispr_diagnosis_service set resource_id = xresource, service_id = serviceid
                where diagnosis_id = (select diagnos_id from disp.md_disp_orphans_inspec where service_id = xssrid);
              if (select res_group_id from SR_SRV_RENDERED where id = xssrid) <> xresource then
                oldstepid = (select step_id from MD_SRV_RENDERED where id = xssrid);
                stepid = (select disp.find_insert_mc_step(xepid, xbdate, xcaseId, xresource));
                update MD_SRV_RENDERED set step_id = stepid where id = xssrid;
                if (select count(1) = 0 from md_srv_rendered where step_id = oldstepid) then
                  delete from mc_step where id = oldstepid;
                end if;
              end if;
              update SR_SRV_RENDERED set bdate=COALESCE(to_date(xbdate, 'DD.MM.YYYY'), current_date), edate=COALESCE(to_date(xbdate, 'DD.MM.YYYY'), current_date), res_group_id=xresource
               where id = xssrid;
              if (select count(id) from disp.md_disp_orphans_inspec where service_id = xssrid) > 0 then
                update disp.md_disp_orphans_inspec set main_diagnos=xmd, disease=xdis, counsel=xcounsel, reference=xreference
                  where service_id = xssrid;
              else
                insert into disp.md_disp_orphans_inspec (id, event_patient_id, service_id, main_diagnos, disease, counsel, reference)
                  values (nextval('disp.md_disp_orphans_inspec_id_seq'), xepid, srrid, xmd, xdis, xcounsel, xreference);
              end if;
	      emplPosId = (select pes.id from sr_srv_rendered ssr
                join SR_RES_GROUP srg on srg.id = ssr.res_group_id
                join PIM_EMPLOYEE_POSITION pes on pes.id = srg.responsible_id
                where ssr.id = srrid);
              dispensaryId = (select pci_dispensary_id from disp.md_disp_orphans_diagnosis_extended where id = (select diagnos_id from disp.md_disp_orphans_inspec where service_id = xssrid));
              IF xmake_d = TRUE THEN
                if (dispensaryId is null) then
                  pci_dispensary_seq = nextval('pci_dispensary_seq');
                  insert into pci_dispensary (id, diagnosis_id, reg_in_dt, clinic_id, reg_in_doctor_id, reg_stage_id, patient_id, nosol_registr_id, srv_rendered_id, med_case_in_id)
                    values (pci_dispensary_seq, xmd, (select bdate from sr_srv_rendered where id = srrid),
                    (select clinic_id from mc_case where id = xcaseid),
                    emplPosId, 1, (select indiv_id from disp.md_event_patient where id = xepid), xregistr_id, srrid, xcaseid);
                  update disp.md_disp_orphans_diagnosis_extended set pci_dispensary_id = pci_dispensary_seq where id = (select diagnos_id from disp.md_disp_orphans_inspec where service_id = xssrid);
                  update disp.md_dispr set is_d = true where id = xepid;
                else
                  update pci_dispensary set diagnosis_id = xmd, nosol_registr_id = xregistr_id where id = dispensaryId;
                end if;
              ELSE
                update disp.md_disp_orphans_diagnosis_extended set pci_dispensary_id = null where id = (select diagnos_id from disp.md_disp_orphans_inspec where service_id = xssrid);
                delete from pci_dispensary where id = dispensaryId;
                update disp.md_dispr set is_d = false where id = xepid;
              END IF;
          else
            srrid = nextval('sr_srv_rendered_seq');
            sysresid = nextval('sr_res_group_seq');
            maindiagid = nextval('mc_diagnosis_seq');
            -- insert newsysres, step, visit, diag
            insert into SR_RES_GROUP(id, bdate, edate, is_system, name, department_id, org_id, responsible_id, is_available_in_electronic_queue, label_id, template_res_group_id)
              select sysresid as id, bdate, edate, TRUE as is_system, name, department_id, org_id, responsible_id, is_available_in_electronic_queue, label_id, xresource
              from SR_RES_GROUP
              where id = xresource;
            insert into MC_DIAGNOSIS (id, case_id, patient_id, establishment_date, diagnos_id, disease_type_id, type_id, is_suspicion, is_main, stage_id)
              values (maindiagid, xcaseId, (select indiv_id from disp.md_event_patient where id = xepid), COALESCE(to_date(xbdate, 'DD.MM.YYYY'), current_date), xmd,
                      xdis, (select id from mc_diagnosis_type where code = '1' and to_dt is null), xsuspicion, TRUE, (select id from mc_stage where code = '3' and to_dt is null));
            insert into disp.md_dispr_diagnosis_service (id, resource_id, service_id, diagnosis_id)
              values (nextval('disp.md_dispr_diagnosis_service_id_seq'), xresource, serviceid, maindiagid);
            -- end insert
            insert into SR_SRV_RENDERED (id, service_id, bdate, res_group_id, customer_id, is_rendered, edate, quantity, funding_id, org_id, payment_status_id)
              values (srrid, serviceid, COALESCE(to_date(xbdate, 'DD.MM.YYYY'), current_date), xresource, (select indiv_id from disp.md_event_patient where id = xepid), TRUE, COALESCE(to_date(xbdate, 'DD.MM.YYYY'), current_date), 1,
              (select me.pay_type from disp.md_event me left join disp.md_event_patient mep on mep.event_id=me.id  where mep.id=xepid),
              (select me.org_id from disp.md_event_patient mep left join disp.md_event me on me.id = mep.event_id where mep.id = xepid), 1);
            stepid = (select disp.find_insert_mc_step(xepid, xbdate, xcaseId, xresource));
            insert into MD_SRV_RENDERED (id, case_id, step_id, diagnosis_id) values (srrid, xcaseId, stepid,
              (select md.diagnos_id from disp.md_dispr_diagnosis_service mdds left join mc_diagnosis md on md.id = mdds.diagnosis_id where mdds.id = currval('disp.md_dispr_diagnosis_service_id_seq') and md.is_main = true)
            );
            insert into disp.md_disp_orphans_inspec (id, event_patient_id, service_id, main_diagnos, disease, counsel, reference, diagnos_id, step_id)
              values (nextval('disp.md_disp_orphans_inspec_id_seq'), xepid, srrid, xmd, xdis, xcounsel, xreference, maindiagid, stepid);

            select id into result_id from disp.md_disp_orphans_result where event_patient_id = xepid and is_before = false;
            if (result_id is not null) then
	          insert into disp.md_disp_orphans_diagnosis_extended (id, result_id, service_id)
                values (maindiagid, result_id, srrid);
	        end if;

	    emplPosId = (select pes.id from sr_srv_rendered ssr
              join SR_RES_GROUP srg on srg.id = ssr.res_group_id
              join PIM_EMPLOYEE_POSITION pes on pes.id = srg.responsible_id
              where ssr.id = srrid);
	    IF xmake_d = TRUE THEN
              pci_dispensary_seq = nextval('pci_dispensary_seq');
              insert into pci_dispensary (id, diagnosis_id, reg_in_dt, clinic_id, reg_in_doctor_id, reg_stage_id, patient_id, nosol_registr_id, srv_rendered_id, med_case_in_id)
                values (pci_dispensary_seq, xmd, (select bdate from sr_srv_rendered where id = srrid),
                (select clinic_id from mc_case where id = xcaseId),
                emplPosId, 1, (select indiv_id from disp.md_event_patient where id = xepid), xregistr_id, srrid, xcaseid);
              update disp.md_disp_orphans_diagnosis_extended set pci_dispensary_id = pci_dispensary_seq where id = currval('mc_diagnosis_seq');
              update disp.md_dispr set is_d = true where id = xepid;
            END IF;

          end if;

          if (select open_date from MC_CASE where id = xcaseId) IS NULL then
            update MC_CASE set open_date = COALESCE(to_date(xbdate, 'DD.MM.YYYY'), current_date)
              where id = xcaseId;
          end if;

          -- change STATUS
          update disp.md_event_service_patient set status = 4
              where id = (select mesp.id from disp.md_event_patient mep
                left join disp.md_event_service_patient mesp on mesp.event_patient_id =  mep.id
                inner join disp.md_event_service mes on mes.id = mesp.service_id and mes.service_id = serviceid
                where mep.id = xepid);
          return srrid;
        end;
$$;

