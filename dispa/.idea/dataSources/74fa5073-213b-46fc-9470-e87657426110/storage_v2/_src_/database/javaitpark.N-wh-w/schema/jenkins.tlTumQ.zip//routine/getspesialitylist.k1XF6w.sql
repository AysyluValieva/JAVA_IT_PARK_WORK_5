CREATE FUNCTION getspesialitylist(_department_id integer, idpat text)
  RETURNS TABLE(countfreeparticipantie bigint, countfreeticket bigint, feridspesiality character varying, idspesiality character varying, lastdate character varying, namespesiality character varying, nearestdate character varying)
LANGUAGE plpgsql
AS $$
BEGIN
 

return query ( select * from "jenkins"."get_spesiality_list_v4"( "_department_id" ,  "idpat" ) );

 
 
END;
$$;

