CREATE FUNCTION team_job_resource_deviation(xresid integer, xrepl integer, xdev integer, xdreg integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
                xreplteamjob integer;
                xreplishead boolean;
                xresource integer;
                xdate TIMESTAMP WITHOUT TIME ZONE;
                xbdate TIMESTAMP WITHOUT TIME ZONE;

                xchange integer;
                xteamjob integer;
                xresrole integer;
                xresrepl integer;
                xworkplace varchar(50);
                xishead boolean;
                -- заменяющего
                xplannedbdate TIMESTAMP WITHOUT TIME ZONE;
                xplannededate TIMESTAMP WITHOUT TIME ZONE;
                -- заменяемого
                xdevbd TIMESTAMP WITHOUT TIME ZONE;
                xpbd TIMESTAMP WITHOUT TIME ZONE;
                xped TIMESTAMP WITHOUT TIME ZONE;
                xreg integer;
                xjkind integer;
              begin
                -- данные отклоняемого ресурса
                SELECT INTO xreplteamjob, xreplishead, xpbd, xped, xjkind, xworkplace, xresrole, xchange, xdevbd
                    team_job_id, is_head, planned_bdate, planned_edate, job_kind_id, workplace, role_id, change_id, bdate
                FROM amb.sr_res_team_job_resourse WHERE id = xresid;

                xdate := now();
                IF (xrepl IS NULL) THEN
                    UPDATE amb.sr_res_team_job_resourse SET deviation_id = xdev, deviation_registrator_id = xdreg, bdate = xdate WHERE id = xresid;
                ELSE
                    -- создаем наряд на заменяющего сотрудника для включения в общий наряд для бригады
                    xresrepl := amb.add_res_team_job_resourse(xreplteamjob, xchange, xrepl, xresrole, xworkplace, xjkind, xreplishead, xpbd, xped, xdreg);
                    UPDATE amb.sr_res_team_job_resourse SET deviation_id = xdev, replacement_id = xresrepl, deviation_registrator_id = xdreg, edate = xdate WHERE id = xresid;
                    -- начал ли заменяемый ресурс наряда уже свою работу
                    IF (xdevbd IS NOT NULL) THEN
                        UPDATE amb.sr_res_team_job_resourse SET bdate = xdate WHERE id = xresrepl;
                    END IF;
                END IF;
              end;
$$;

