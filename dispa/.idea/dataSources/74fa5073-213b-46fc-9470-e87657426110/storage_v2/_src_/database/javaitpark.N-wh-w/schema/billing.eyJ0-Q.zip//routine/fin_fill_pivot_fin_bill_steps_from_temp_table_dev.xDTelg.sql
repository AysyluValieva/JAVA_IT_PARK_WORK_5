CREATE FUNCTION fin_fill_pivot_fin_bill_steps_from_temp_table_dev(p1_bill_id integer)
  RETURNS void
STRICT
LANGUAGE plpgsql
AS $$
DECLARE
	v_cnt bigint;
BEGIN
/*fin_bill_steps*/

    INSERT INTO billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fill_fin_bill_steps. Начало');
    
    IF EXISTS (SELECT relname FROM pg_class WHERE relname='tmp_fin_bill_steps') THEN
    DELETE 
      FROM billing.fin_bill_steps fbs
     WHERE fbs.bill_id = p1_bill_id
           AND NOT EXISTS (SElECT NULL
                             FROM tmp_fin_bill_steps tfbs
                            WHERE fbs.srv_rendered_id = tfbs.srv_rendered_id
                                  AND fbs.bill_id = tfbs.bill_id); 


	GET DIAGNOSTICS v_cnt = ROW_COUNT;
	INSERT INTO billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fill_fin_bill_steps. Deleted: ' || v_cnt || ' rows.');



    UPDATE billing.fin_bill_steps fbs
       SET
								n_zap = tfbs.n_zap,
								case_id = tfbs.case_id,
								step_id = tfbs.step_id,
								step_diagnosis_main = tfbs.step_diagnosis_main,
								step_diagnosis_other = tfbs.step_diagnosis_other,
								step_admission_date = tfbs.step_admission_date,
								step_outcome_date = tfbs.step_outcome_date,
								department_code = tfbs.department_code,
								department_name = tfbs.department_name,
								srv_rendered_id = tfbs.srv_rendered_id,
								srv_rendered_bdate = tfbs.srv_rendered_bdate,
								srv_rendered_edate = tfbs.srv_rendered_edate,
								service_id = tfbs.service_id,
								service_code = tfbs.service_code,
								service_name = tfbs.service_name,
								prototype_id = tfbs.prototype_id,
								prototype_code = tfbs.prototype_code,
								patient_id = tfbs.patient_id,
								doctor_code = tfbs.doctor_code,
								doctor_code_regional = tfbs.doctor_code_regional,
								position_speciality_code = tfbs.position_speciality_code,
								pos_role_code = tfbs.pos_role_code,
								profile_code = tfbs.profile_code,
								position_id = tfbs.position_id,
								visit_type_code = tfbs.visit_type_code,
								visit_place_code = tfbs.visit_place_code,
								visit_inc_code = tfbs.visit_inc_code,
								bill_id = tfbs.bill_id,
								spec_item_id = tfbs.spec_item_id,
								spec_err_exists = tfbs.spec_err_exists,
								tariff = tfbs.tariff,
								quantity = tfbs.quantity,
								cul = tfbs.cul,
								price = tfbs.price,
								price_pos_id = tfbs.price_pos_id,
								price_pos_code = tfbs.price_pos_code,
								employee_speciality_code = tfbs.employee_speciality_code,
								urov = tfbs.urov,
								step_admission_time = tfbs.step_admission_time,
								step_outcome_time = tfbs.step_outcome_time,
								srv_rendered_time_in = tfbs.srv_rendered_time_in,
								srv_rendered_time_out = tfbs.srv_rendered_time_out,
								department_id = tfbs.department_id,
								code_mes = tfbs.code_mes,
								service_spec_id = tfbs.service_spec_id,
								srv_rendered_comment = tfbs.srv_rendered_comment,
								srv_diagnosis_code = tfbs.srv_diagnosis_code,
								tooth_number = tfbs.tooth_number,
								res_group_id = tfbs.res_group_id,
								step_main_diagnosis_id = tfbs.step_main_diagnosis_id,
								step_profile_code = tfbs.step_profile_code,
								vmp_type_code = tfbs.vmp_type_code,
								vmp_method_code = tfbs.vmp_method_code,
								hsp_department_code = tfbs.hsp_department_code,
								hsp_department_name = tfbs.hsp_department_name,
								doctor_snils = tfbs.doctor_snils,
								speciality_code_arr = tfbs.speciality_code_arr,
								visit_goal_code_arr = tfbs.visit_goal_code_arr,
								visit_goal_name = tfbs.visit_goal_name,
								tariff_code = tfbs.tariff_code,
								hsp_department_id = tfbs.hsp_department_id,
								service_spec_code = tfbs.service_spec_code,
								step_result_code = tfbs.step_result_code,
								step_outcome_code = tfbs.step_outcome_code,
								deviation_reason_code = tfbs.deviation_reason_code,
								sovmp = tfbs.sovmp,
								anest_code = tfbs.anest_code,
								region_data = tfbs.region_data
      FROM tmp_fin_bill_steps AS tfbs
     WHERE tfbs.srv_rendered_id = fbs.srv_rendered_id
           AND tfbs.bill_id = fbs.bill_id
			     AND (
								   coalesce(fbs.n_zap, -1) = coalesce(tfbs.n_zap, -1)
								OR coalesce(fbs.case_id, -1) = coalesce(tfbs.case_id, -1)
								OR coalesce(fbs.step_id, -1) = coalesce(tfbs.step_id, -1)
								OR coalesce(fbs.step_diagnosis_main, '-1') = coalesce(tfbs.step_diagnosis_main, '-1')
								OR coalesce(fbs.step_diagnosis_other, '-1') = coalesce(tfbs.step_diagnosis_other, '-1')
								OR coalesce(fbs.step_admission_date, date '19000101') = coalesce(tfbs.step_admission_date, date '19000101')
								OR coalesce(fbs.step_outcome_date, date '19000101') = coalesce(tfbs.step_outcome_date, date '19000101')
								OR coalesce(fbs.department_code, '-1') = coalesce(tfbs.department_code, '-1')
								OR coalesce(fbs.department_name, '-1') = coalesce(tfbs.department_name, '-1')
								OR coalesce(fbs.srv_rendered_id, -1) = coalesce(tfbs.srv_rendered_id, -1)
								OR coalesce(fbs.srv_rendered_bdate, date '19000101') = coalesce(tfbs.srv_rendered_bdate, date '19000101')
								OR coalesce(fbs.srv_rendered_edate, date '19000101') = coalesce(tfbs.srv_rendered_edate, date '19000101')
								OR coalesce(fbs.service_id, -1) = coalesce(tfbs.service_id, -1)
								OR coalesce(fbs.service_code, '-1') = coalesce(tfbs.service_code, '-1')
								OR coalesce(fbs.service_name, '-1') = coalesce(tfbs.service_name, '-1')
								OR coalesce(fbs.prototype_id, -1) = coalesce(tfbs.prototype_id, -1)
								OR coalesce(fbs.prototype_code, '-1') = coalesce(tfbs.prototype_code, '-1')
								OR coalesce(fbs.patient_id, -1) = coalesce(tfbs.patient_id, -1)
								OR coalesce(fbs.doctor_code, '-1') = coalesce(tfbs.doctor_code, '-1')
								OR coalesce(fbs.doctor_code_regional, '-1') = coalesce(tfbs.doctor_code_regional, '-1')
								OR coalesce(fbs.position_speciality_code, '-1') = coalesce(tfbs.position_speciality_code, '-1')
								OR coalesce(fbs.pos_role_code, '-1') = coalesce(tfbs.pos_role_code, '-1')
								OR coalesce(fbs.profile_code, '-1') = coalesce(tfbs.profile_code, '-1')
								OR coalesce(fbs.position_id, -1) = coalesce(tfbs.position_id, -1)
								OR coalesce(fbs.visit_type_code, '-1') = coalesce(tfbs.visit_type_code, '-1')
								OR coalesce(fbs.visit_place_code, '-1') = coalesce(tfbs.visit_place_code, '-1')
								OR coalesce(fbs.visit_inc_code, '-1') = coalesce(tfbs.visit_inc_code, '-1')
								OR coalesce(fbs.bill_id, -1) = coalesce(tfbs.bill_id, -1)

								OR coalesce(fbs.spec_item_id, -1) = coalesce(tfbs.spec_item_id, -1)
								OR coalesce(fbs.spec_err_exists, false) = coalesce(tfbs.spec_err_exists, false)
								OR coalesce(fbs.tariff, -1) = coalesce(tfbs.tariff, -1)
								OR coalesce(fbs.quantity, -1) = coalesce(tfbs.quantity, -1)
								OR coalesce(fbs.cul, -1) = coalesce(tfbs.cul, -1)
								OR coalesce(fbs.price, -1) = coalesce(tfbs.price, -1)
								OR coalesce(fbs.price_pos_id, -1) = coalesce(tfbs.price_pos_id, -1)
								OR coalesce(fbs.price_pos_code, '-1') = coalesce(tfbs.price_pos_code, '-1')
								OR coalesce(fbs.employee_speciality_code, '-1') = coalesce(tfbs.employee_speciality_code, '-1')
								OR coalesce(fbs.urov, -1) = coalesce(tfbs.urov, -1)
								OR coalesce(fbs.step_admission_time, '00:00:01'::time) = coalesce(tfbs.step_admission_time, '00:00:01'::time)
								OR coalesce(fbs.step_outcome_time, '00:00:01'::time) = coalesce(tfbs.step_outcome_time, '00:00:01'::time)
								OR coalesce(fbs.srv_rendered_time_in, '00:00:01'::time) = coalesce(tfbs.srv_rendered_time_in, '00:00:01'::time)
								OR coalesce(fbs.srv_rendered_time_out, '00:00:01'::time) = coalesce(tfbs.srv_rendered_time_out, '00:00:01'::time)
								OR coalesce(fbs.department_id, -1) = coalesce(tfbs.department_id, -1)
								OR coalesce(fbs.code_mes, '-1') = coalesce(tfbs.code_mes, '-1')
								OR coalesce(fbs.service_spec_id, -1) = coalesce(tfbs.service_spec_id, -1)
								OR coalesce(fbs.srv_rendered_comment, '-1') = coalesce(tfbs.srv_rendered_comment, '-1')
								OR coalesce(fbs.srv_diagnosis_code, '-1') = coalesce(tfbs.srv_diagnosis_code, '-1')

								OR coalesce(fbs.tooth_number, '-1') = coalesce(tfbs.tooth_number, '-1')
								OR coalesce(fbs.res_group_id, -1) = coalesce(tfbs.res_group_id, -1)
								OR coalesce(fbs.step_main_diagnosis_id, -1) = coalesce(tfbs.step_main_diagnosis_id, -1)
								OR coalesce(fbs.step_profile_code, '-1') = coalesce(tfbs.step_profile_code, '-1')
								OR coalesce(fbs.vmp_type_code, '-1') = coalesce(tfbs.vmp_type_code, '-1')
								OR coalesce(fbs.vmp_method_code, '-1') = coalesce(tfbs.vmp_method_code, '-1')
								OR coalesce(fbs.hsp_department_code, '-1') = coalesce(tfbs.hsp_department_code, '-1')
								OR coalesce(fbs.hsp_department_name, '-1') = coalesce(tfbs.hsp_department_name, '-1')
								OR coalesce(fbs.doctor_snils, '-1') = coalesce(tfbs.doctor_snils, '-1')
								OR coalesce(fbs.speciality_code_arr::text[], array['']::text[]) = coalesce(tfbs.speciality_code_arr::text[], array['']::text[])
								OR coalesce(fbs.visit_goal_code_arr::text[], array['']::text[]) = coalesce(tfbs.visit_goal_code_arr::text[], array['']::text[])
								OR coalesce(fbs.visit_goal_name, '-1') = coalesce(tfbs.visit_goal_name, '-1')
								OR coalesce(fbs.tariff_code, '-1') = coalesce(tfbs.tariff_code, '-1')
								OR coalesce(fbs.hsp_department_id, -1) = coalesce(tfbs.hsp_department_id, -1)
								OR coalesce(fbs.service_spec_code, '-1') = coalesce(tfbs.service_spec_code, '-1')
								OR coalesce(fbs.step_result_code, '-1') = coalesce(tfbs.step_result_code, '-1')
								OR coalesce(fbs.step_outcome_code, '-1') = coalesce(tfbs.step_outcome_code, '-1')
								OR coalesce(fbs.deviation_reason_code, '-1') = coalesce(tfbs.deviation_reason_code, '-1')
								OR coalesce(fbs.sovmp, -1) = coalesce(tfbs.sovmp, -1)
								OR coalesce(fbs.anest_code, '-1') = coalesce(tfbs.anest_code, '-1')
								OR coalesce(fbs.region_data, ''::hstore) = coalesce(tfbs.region_data, ''::hstore)
			 );

	GET DIAGNOSTICS v_cnt = ROW_COUNT;
	INSERT INTO billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fill_fin_bill_steps. Updated: ' || v_cnt || ' rows.');

    INSERT

      INTO billing.fin_bill_steps(
									n_zap, case_id, step_id, step_diagnosis_main, step_diagnosis_other, step_admission_date, step_outcome_date, department_code,
									department_name, srv_rendered_id, srv_rendered_bdate, srv_rendered_edate, service_id, service_code, service_name, prototype_id,
									prototype_code, patient_id, doctor_code, doctor_code_regional, position_speciality_code, pos_role_code, profile_code, position_id,
									visit_type_code, visit_place_code, visit_inc_code, bill_id, spec_item_id, spec_err_exists, tariff, quantity, cul, price, price_pos_id,
									price_pos_code, employee_speciality_code, urov, step_admission_time, step_outcome_time, srv_rendered_time_in, srv_rendered_time_out,
									department_id, code_mes, service_spec_id, srv_rendered_comment, srv_diagnosis_code, tooth_number, res_group_id, step_main_diagnosis_id,
									step_profile_code, vmp_type_code, vmp_method_code, hsp_department_code, hsp_department_name, doctor_snils, speciality_code_arr,
									visit_goal_code_arr, visit_goal_name, tariff_code, hsp_department_id, service_spec_code, step_result_code, step_outcome_code,
									deviation_reason_code, sovmp, anest_code, region_data)
    SELECT
									n_zap, case_id, step_id, step_diagnosis_main, step_diagnosis_other, step_admission_date, step_outcome_date, department_code,
									department_name, srv_rendered_id, srv_rendered_bdate, srv_rendered_edate, service_id, service_code, service_name, prototype_id,
									prototype_code, patient_id, doctor_code, doctor_code_regional, position_speciality_code, pos_role_code, profile_code, position_id,
									visit_type_code, visit_place_code, visit_inc_code, bill_id, spec_item_id, spec_err_exists, tariff, quantity, cul, price, price_pos_id,
									price_pos_code, employee_speciality_code, urov, step_admission_time, step_outcome_time, srv_rendered_time_in, srv_rendered_time_out,
									department_id, code_mes, service_spec_id, srv_rendered_comment, srv_diagnosis_code, tooth_number, res_group_id, step_main_diagnosis_id,
									step_profile_code, vmp_type_code, vmp_method_code, hsp_department_code, hsp_department_name, doctor_snils, speciality_code_arr,
									visit_goal_code_arr, visit_goal_name, tariff_code, hsp_department_id, service_spec_code, step_result_code, step_outcome_code,
									deviation_reason_code, sovmp, anest_code, region_data
      FROM tmp_fin_bill_steps AS tfbs
     WHERE NOT EXISTS (SElECT NULL
			 FROM billing.fin_bill_steps AS fbs
			WHERE fbs.bill_id = p1_bill_id
			      AND fbs.srv_rendered_id = tfbs.srv_rendered_id);

	GET DIAGNOSTICS v_cnt = ROW_COUNT;
	INSERT INTO billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fill_fin_bill_steps. Inserted: ' || v_cnt || ' rows.');

    DROP TABLE tmp_fin_bill_steps;
    END IF;

    INSERT INTO billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fill_fin_bill_steps. Конец');
        
END;
$$;

