CREATE FUNCTION saveeventserviceultrasound(xepid integer, xssrid integer, xcaseid integer, xbdate character varying, xresource integer, xrate character varying, xonko boolean, xpt boolean, xservice integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
          serviceid integer;
          srrid integer;
        begin
          serviceid = xservice;
          if (select count(meec.id) from disp.md_event_eq_case meec
                left join MD_SRV_RENDERED msr on msr.case_id = meec.case_id
                inner join SR_SRV_RENDERED ssr on ssr.id = msr.id and ssr.service_id = serviceid
                where meec.event_patient_id = xepid) > 0 then
              if xssrid IS NULL then
                xssrid = (select ssr.id from disp.md_event_eq_case meec
                left join MD_SRV_RENDERED msr on msr.case_id = meec.case_id
                inner join SR_SRV_RENDERED ssr on ssr.id = msr.id and ssr.service_id = serviceid
                where meec.event_patient_id = xepid);
              end if;
              srrid = xssrid;
              update SR_SRV_RENDERED set bdate=COALESCE(to_date(xbdate, 'DD.MM.YYYY'), current_date), edate=COALESCE(to_date(xbdate, 'DD.MM.YYYY'), current_date), res_group_id=xresource
               where id = xssrid;
              if (select count(id) from disp.md_event_service_ultrasound where service_id = xssrid) > 0 then
                update disp.md_event_service_ultrasound set rate=xrate, oncology_suspicion=xonko, pathology=xpt
                  where service_id = xssrid;
              else
                insert into disp.md_event_service_ultrasound (id, event_patient_id, service_id, rate, oncology_suspicion, pathology)
                  values (nextval('disp.md_event_service_ultrasound_id_seq'), xepid, srrid, xrate, xonko, xpt);
              end if;
          else
            srrid = nextval('sr_srv_rendered_seq');
            insert into SR_SRV_RENDERED (id, service_id, bdate, res_group_id, customer_id, is_rendered, edate, quantity, funding_id, org_id, payment_status_id)
              values (srrid, serviceid, COALESCE(to_date(xbdate, 'DD.MM.YYYY'), current_date), xresource, (select indiv_id from disp.md_event_patient where id = xepid), TRUE, COALESCE(to_date(xbdate, 'DD.MM.YYYY'), current_date), 1,
              (select etf.funding_source_type_id from disp.md_event_type_fund etf join disp.md_event me on me.event_type = etf.event_type_id join disp.md_event_patient mep on mep.event_id = me.id where mep.id = xepid), (select me.org_id from disp.md_event_patient mep left join disp.md_event me on me.id = mep.event_id where mep.id = xepid), 1);
            insert into MD_SRV_RENDERED (id, case_id) values (srrid, xcaseId);
            insert into disp.md_event_service_ultrasound (id, event_patient_id, service_id, rate, oncology_suspicion, pathology)
                  values (nextval('disp.md_event_service_ultrasound_id_seq'), xepid, srrid, xrate, xonko, xpt);
          end if;

          -- change STATUS
          update disp.md_event_service_patient_status set status = 4
              where service_id = (select mesp.id from disp.md_event_patient mep
                left join disp.md_event_service_patient mesp on mesp.event_patient_id = mep.id
                inner join disp.md_event_service mes on mes.id = mesp.service_id and mes.service_id = serviceid
                where mep.id = xepid);
          return srrid;
        end;
$$;

