CREATE FUNCTION select_service_for_gibdd_patient_licences(xepid integer, xeventage character varying, xcategories character varying)
  RETURNS integer[]
LANGUAGE plpgsql
AS $$
DECLARE
        mes_id integer;
        model_age text;
		    categories text;
        num text;
        services_id_model_ages text [] ;
        xage numeric;
        age text;
		    category text;
        service_id_actual integer [];
        service_id_model_age text;
        event_type_code character varying;
    BEGIN

        services_id_model_ages=(select   array_agg(row_to_json(row(mes.id,mmpb.age,(select array_to_string(array(select mmpl.category_id from disp.md_model_patient_licences mmpl where mmpl.model_id = mmp.id),',')))))
                            from disp.md_event_service mes
                            left join disp.md_event_service_model mesm on mesm.event_service_id=mes.id
                            left join disp.md_model_patient mmp on mmp.id=mesm.model_id
                            inner join disp.md_model_patient_base mmpb on  mmpb.model_id=mmp.id
                            left join pim_individual i on i.id= (select indiv_id from disp.md_event_patient where id=xepid)
                                where  mmpb.gender_id=i.gender_id and
                                        mes.event_id=(select event_id from disp.md_event_patient where id=xepid)
                   );

        event_type_code = (select met.code from disp.md_event_patient mep
                        join disp.md_event me on me.id = mep.event_id
                        join disp.md_event_type met on met.id = me.event_type
                        where mep.id=xepid);
        if (event_type_code = 'ОВ') then
          if xeventage is Null then xeventage= (select CONCAT(date_part('year',age(birth_dt)), '.', date_part('month',age(birth_dt)))  from disp.md_event_patient mep
                                                                        left join disp.md_event me on me.id=mep.event_id
                                                                        left join pim_individual i on i.id=mep.indiv_id
                                                                      where mep.id=xepid); end if;
        else
          xeventage = (select (extract(year from current_date) - extract(year from pi.birth_dt))::integer age from pim_individual pi where pi.id = (select indiv_id from disp.md_event_patient mep where mep.id = xepid));
        end if;
        xage:=xeventage::NUMERIC;

        if xage>=3 then xage:=trunc(xage); end if;
        if services_id_model_ages is not null then
            foreach  service_id_model_age  in array services_id_model_ages
                Loop
                --mes.id
                mes_id:=cast((service_id_model_age::json->'f1')as text);
                continue when mes_id = any(service_id_actual);
				        model_age:=cast((service_id_model_age::json->'f2')as character varying);
				        categories:=cast((service_id_model_age::json->'f3')as character varying);
				        categories:=substring(categories from  2 for length (categories)-2 );
				        if(model_age = 'null') then
                    FOREACH category IN ARRAY regexp_split_to_array(replace(categories,' ',''),',')
                      LOOP
                          if(category::text = any(array(select value from json_array_elements(cast(xcategories as json)))::text[])) then
                              service_id_actual:=array_append(service_id_actual,mes_id::integer);
                              exit;
                          end if;
                      END LOOP;
                  else
                    model_age:=substring(model_age from  2 for length (model_age)-2 );
                    FOREACH age IN ARRAY regexp_split_to_array(replace(model_age,' ',''),',')
                      LOOP
                          if(age::numeric=xage) then
                              FOREACH category IN ARRAY regexp_split_to_array(replace(categories,' ',''),',')
                                  LOOP
                                      if(category::text = any(array(select value from json_array_elements(cast(xcategories as json)))::text[])) then
                                          service_id_actual:=array_append(service_id_actual,mes_id::integer);
                                          exit;
                                      end if;
                                  END LOOP;
                              exit;
                          end if;
                      END LOOP;
						    end if;
                END LOOP;

        end if;
        return  service_id_actual;

        EXCEPTION WHEN others THEN
        return  ARRAY[]::integer[];

END;
$$;

