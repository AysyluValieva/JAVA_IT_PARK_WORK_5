CREATE FUNCTION fin_spec_gen_price(p1_bill_id integer)
  RETURNS void
STRICT
LANGUAGE plpgsql
AS $$
DECLARE
    _r RECORD;
BEGIN
    /*
        current version date 2014-12-12
    */
    -------------------------------------------------------------подсчёт стоимости-------------------------------------------------------------------
    FOR _r IN
        SELECT 
            id, tariff, price, price_pos_arr[1] AS pos_id, bill_id
        FROM 
            fin_bill_generate 
        WHERE 
            bill_id = p1_bill_id AND NOT is_sifted
    LOOP
        IF
            _r.tariff IS NULL
        THEN
            WITH t AS (SELECT fin_get_tariff_from_pricelist (_r.id, _r.pos_id) AS r)
            UPDATE fin_bill_generate AS f
            SET
                tariff = (t.r).tariff, tariff_code = (t.r).code, tariff_name = (t.r).name, price = (t.r).tariff * quantity
            FROM t
            WHERE
                f.id = _r.id AND f.bill_id = _r.bill_id
            ;
        ELSE
            IF 
                _r.price IS NULL 
            THEN
                UPDATE fin_bill_generate SET price = tariff * quantity WHERE id = _r.id AND bill_id = _r.bill_id
                ;
            END IF;
        END IF;
    END LOOP;
EXCEPTION
    WHEN NO_DATA_FOUND THEN RAISE EXCEPTION 'Отсутствуют данные по счёту';
END;
$$;

