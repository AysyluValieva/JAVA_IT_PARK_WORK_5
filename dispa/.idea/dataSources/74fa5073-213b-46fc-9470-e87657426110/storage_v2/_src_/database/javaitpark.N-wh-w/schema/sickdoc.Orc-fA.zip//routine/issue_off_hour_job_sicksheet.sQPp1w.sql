CREATE FUNCTION issue_off_hour_job_sicksheet(p_parent_id integer, p_number character varying, p_journal_id integer, p_workplace_id integer, p_workplace_print character varying, p_registrator_id integer, p_clinic_id integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
DECLARE
  l_parent_sickdock sickdoc.sickdoc%ROWTYPE;
  l_parent_sickdock_extended sickdoc.sickdoc_extended%ROWTYPE;
  l_period sickdoc.period%ROWTYPE;
  l_family_member1 sickdoc.family_member%ROWTYPE;
  l_family_member2 sickdoc.family_member%ROWTYPE;
  l_sickdoc_id INTEGER;
  l_disability_reason_code VARCHAR;
  l_issue_dt DATE = current_date;
BEGIN
  SELECT *
    FROM sickdoc.sickdoc
    WHERE id = p_parent_id
    INTO l_parent_sickdock;

  IF l_parent_sickdock.workplace_type_id <> 1
  THEN RAISE EXCEPTION 'ЛН по совместительству оформляется только для ЛН по основному месту работы'; END IF;

  IF l_parent_sickdock.workplace_id = p_workplace_id
  THEN RAISE EXCEPTION 'Место работы ЛН по совместительству должно отличаться от указанного в первичном ЛН'; END IF;

  SELECT *
    FROM sickdoc.sickdoc_extended
    WHERE id = p_parent_id
    INTO l_parent_sickdock_extended;

  IF l_parent_sickdock_extended.on_placement_service IS TRUE
  THEN RAISE EXCEPTION 'ЛН по совместительству не может быть выдан, т.к. в первичном ЛН указана отметка "Стоит на учете в службе занятости" '; END IF;

  INSERT INTO sickdoc.sickdoc (
      id, begin_dt, case_id, clinic_id, days, end_dt, final_diagnosis_id, hospital_from_dt, hospital_to_dt, individual_id,
      initial_diagnosis_id, issue_dt, journal_id, kind_id, number, parent_id, ready_to_work_dt, ready_to_work_other_dt,
      ready_to_work_other_id, registrator_id, state_id, transfer_to_o_clinic, transfer_from_clinic, workplace_id, workplace_print, workplace_type_id, type_id) --
    VALUES (
      DEFAULT, l_parent_sickdock.begin_dt, l_parent_sickdock.case_id, p_clinic_id, l_parent_sickdock.days,
      l_parent_sickdock.end_dt, l_parent_sickdock.final_diagnosis_id, l_parent_sickdock.hospital_from_dt,
      l_parent_sickdock.hospital_to_dt, l_parent_sickdock.individual_id, l_parent_sickdock.initial_diagnosis_id,
      l_issue_dt, p_journal_id, l_parent_sickdock.kind_id, p_number, p_parent_id,
      l_parent_sickdock.ready_to_work_dt, l_parent_sickdock.ready_to_work_other_dt, l_parent_sickdock.ready_to_work_other_id,
      p_registrator_id, l_parent_sickdock.state_id, l_parent_sickdock.transfer_to_o_clinic, l_parent_sickdock.transfer_from_clinic, p_workplace_id, p_workplace_print, 2, 1) -- workplace_type_id=2, т.к выдаем по совместительству, type_id=1, то есть станет первичным
    RETURNING id
      INTO l_sickdoc_id;

  INSERT INTO sickdoc.sickdoc_extended (
      id, disability_from_dt, disability_reason_edited_id, disability_reason_ext_id, disability_reason_id,
      disability_to_dt, is_disability_group_changed, is_early_pregnancy_register, mse_examination_dt,
      mse_referral_dt, mse_register_dt, on_placement_service, regimen_id, regimen_violation_doctor_id,
      regimen_violation_dt, regimen_violation_id, sanatorium_id, sanatorium_ogrn_code, voucher_code,
      family_member_1_relation_id_lsd, family_member_1_age_lsd, family_member_1_age_month_lsd, family_member_1_name_lsd,
	    family_member_2_relation_id_lsd, family_member_2_age_lsd, family_member_2_age_month_lsd, family_member_2_name_lsd)
    VALUES (
      l_sickdoc_id, l_parent_sickdock_extended.disability_from_dt, l_parent_sickdock_extended.disability_reason_edited_id,
      l_parent_sickdock_extended.disability_reason_ext_id, l_parent_sickdock_extended.disability_reason_id,
      l_parent_sickdock_extended.disability_to_dt, l_parent_sickdock_extended.is_disability_group_changed,
      l_parent_sickdock_extended.is_early_pregnancy_register, l_parent_sickdock_extended.mse_examination_dt,
      l_parent_sickdock_extended.mse_referral_dt, l_parent_sickdock_extended.mse_register_dt,
      l_parent_sickdock_extended.on_placement_service, l_parent_sickdock_extended.regimen_id,
      l_parent_sickdock_extended.regimen_violation_doctor_id, l_parent_sickdock_extended.regimen_violation_dt,
      l_parent_sickdock_extended.regimen_violation_id, l_parent_sickdock_extended.sanatorium_id,
      l_parent_sickdock_extended.sanatorium_ogrn_code, l_parent_sickdock_extended.voucher_code,
      l_parent_sickdock_extended.family_member_1_relation_id_lsd, l_parent_sickdock_extended.family_member_1_age_lsd,
      l_parent_sickdock_extended.family_member_1_age_month_lsd, l_parent_sickdock_extended.family_member_1_name_lsd,
      l_parent_sickdock_extended.family_member_2_relation_id_lsd, l_parent_sickdock_extended.family_member_2_age_lsd,
      l_parent_sickdock_extended.family_member_2_age_month_lsd, l_parent_sickdock_extended.family_member_2_name_lsd
    );

    -- Копируем родственников, по уходу за которыми выдан ЛН
    l_disability_reason_code = (SELECT code
                              FROM md_sl_disability_reason
                              WHERE id = l_parent_sickdock_extended.disability_reason_id);

    SELECT *
      FROM sickdoc.family_member
      WHERE id = l_parent_sickdock_extended.family_member_1_id
      INTO l_family_member1;

    SELECT *
      FROM sickdoc.family_member
      WHERE id = l_parent_sickdock_extended.family_member_2_id
      INTO l_family_member2;

    PERFORM sickdoc.family_member_update(
      l_sickdoc_id, l_disability_reason_code, l_family_member1.patient_id, l_family_member2.patient_id, l_family_member1.relation_id, l_family_member2.relation_id);

    --Копируем периоды
    FOR l_period IN
      SELECT * FROM sickdoc.period WHERE sickdoc_id = p_parent_id
    LOOP
      INSERT INTO sickdoc.period (
        clinic_id, from_dt, issued_employee_id, issued_employee_position, sickdoc_id, to_dt, witness_employee_id, witness_employee_position)
      VALUES (
        l_period.clinic_id, l_period.from_dt, l_period.issued_employee_id, l_period.issued_employee_position, l_sickdoc_id,
        l_period.to_dt, l_period.witness_employee_id, l_period.witness_employee_position);
    END LOOP;

  RETURN l_sickdoc_id;
END;
$$;

