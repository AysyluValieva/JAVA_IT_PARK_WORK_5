CREATE FUNCTION apdam_check_by_specific_criterias(info apda_reg_info, district_id integer, criteria_ids character varying[])
  RETURNS boolean
LANGUAGE plpgsql
AS $$
DECLARE
  cur_criteria VARCHAR;
BEGIN
  IF criteria_ids NOTNULL AND array_length(criteria_ids, 1) > 0
  THEN
    FOR i IN array_lower(criteria_ids, 1)..array_upper(criteria_ids, 1) LOOP
      CASE criteria_ids [i]
        WHEN '1'
        THEN cur_criteria = 'ADDRESS';
        WHEN '2'
        THEN cur_criteria = 'ORGANIZATION';
        WHEN '3'
        THEN cur_criteria = 'DIAGNOSIS';
        WHEN '4'
        THEN cur_criteria = 'AGE';
        WHEN '5'
        THEN cur_criteria = 'GENDER';
        WHEN '6'
        THEN cur_criteria = 'BENEFIT';
      END CASE;

      IF apda_check_district_by_reg_and_criterion_type(info, district_id, cur_criteria) = FALSE
      THEN RETURN FALSE;
      END IF;
    END LOOP;
  END IF;

  RETURN TRUE;
END;
$$;

