CREATE FUNCTION add_diagnosis_from_previous_case(xresultid integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
          xcase_id integer;
          xresult_id integer;
          cur_mep record;
          diag record;
        begin

	  select mep.id, mep.indiv_id, mc.open_date, mc.init_goal_id into cur_mep
	  from disp.md_disp_orphans_result mdor
	  join disp.md_event_patient mep on mep.id = mdor.event_patient_id
          join mc_case mc on mc.id = mep.case_id
	  where mdor.id = xresultid;

          select mc.id into xcase_id from disp.md_event_patient mep
          join mc_case mc on mc.id = mep.case_id
          join mc_step ms on mc.closing_step_id = ms.id
          where mep.indiv_id = cur_mep.indiv_id
          and mc.init_goal_id = cur_mep.init_goal_id
          and ms.admission_date < cur_mep.open_date
          order by ms.admission_date desc
          limit 1;

          select id into xresult_id from disp.md_disp_orphans_result where event_patient_id = cur_mep.id and is_before = true;
          if (xresult_id is not null) then
            for diag in
              select id
              from mc_diagnosis md
              where case_id = xcase_id
            loop

            INSERT INTO disp.md_disp_orphans_diagnosis_extended_copied(
            id, result_id, extra_cons_assigned_type, extra_cons_assigned_org,
            extra_cons_performed_type, extra_cons_performed_org, therapy_assigned_type,
            therapy_assigned_org, therapy_performed_type, therapy_performed_org,
            rehabilitation_assigned_type, rehabilitation_assigned_org, rehabilitation_performed_type,
            rehabilitation_performed_org, therapy_amb_fail, therapy_hos_fail,
            rehabilitation_amb_fail, rehabilitation_hos_fail, recommended_vmp,
            recommendation, is_d, is_before_d, pci_dispensary_id)
            SELECT id, result_id, extra_cons_assigned_type, extra_cons_assigned_org,
            extra_cons_performed_type, extra_cons_performed_org, therapy_assigned_type,
            therapy_assigned_org, therapy_performed_type, therapy_performed_org,
            rehabilitation_assigned_type, rehabilitation_assigned_org, rehabilitation_performed_type,
            rehabilitation_performed_org, therapy_amb_fail, therapy_hos_fail,
            rehabilitation_amb_fail, rehabilitation_hos_fail, recommended_vmp,
            recommendation, is_d, is_before_d, pci_dispensary_id
            FROM disp.md_disp_orphans_diagnosis_extended WHERE id = diag.id;
            update disp.md_disp_orphans_diagnosis_extended_copied set result_id = xresult_id where id = diag.id;

            end loop;
          end if;

        end;
$$;

