CREATE FUNCTION func_md_bed_state_sync_hospital_unused_bed()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
/*
при создании/редактировании/удалении статуса койки перезазапишем все исключения возможности использования коек в КФ
если койка ограничена датами создания и закрытия койки
если койка ограничена изменениями статусов
*/
DECLARE
    rez             INTEGER;
    _department_id  INTEGER;
    _profile_id     INTEGER;
BEGIN
    IF ((TG_OP = 'DELETE') OR (TG_OP = 'UPDATE' and (OLD.bed_id IS DISTINCT FROM NEW.bed_id))) THEN
        -- если мы удаляем или изменяем в текущей записи значение department_id или profile_id, определим что делать с исключениями по профилю
        WITH w_tree as (
            WITH bed_room as ( -- исключения по койке дата открытия дата закрытия койки
                SELECT
                    d.id as d_id,
                    dp.id as dp_id,
                    p.id as p_id,
                    r.id as r_id,
                    b.id as b_id,
                    d.id :: TEXT :: LTREE || p.id :: TEXT || p.id :: TEXT || r.id :: TEXT || b.id :: TEXT AS bed_tree,
                    b.from_dt - 1 as from_dt,
                    b.to_dt,
                    unnest(array[(b.from_dt - 1), b.to_dt]) as dt_dt
                FROM md_bed b
                    JOIN lateral (select from md_bed_resource mbr where mbr.bed_id = b.id) mbr on TRUE
                    JOIN LATERAL (select from pim_room_resource prr where prr.room_id = b.room_id limit 1) prr on true -- палата является ресурсом
                    JOIN md_room mr ON b.room_id = mr.id
                    join pim_room r on r.id = b.room_id
                    JOIN pim_department d ON d.id = r.department_id
                    JOIN md_department_profile dp ON d.id = dp.department_id
                    JOIN md_profile p ON p.id = dp.profile_id
                where b.id = OLD.bed_id
                union ALL
                SELECT -- исключения по статусам койки (дату действия статуса смотрим до следующего изменения статуса)
                    d.id as d_id,
                    dp.id as dp_id,
                    p.id as p_id,
                    r.id as r_id,
                    b.id as b_id,
                    d.id :: TEXT :: LTREE || p.id :: TEXT || p.id :: TEXT || r.id :: TEXT || b.id :: TEXT AS bed_tree,
                    case when psus.exploitation then mbs.from_dt - 1 else null::date end as from_dt,
                    case when psus.exploitation then null::date else mbs.from_dt end as to_dt,
                    case when psus.exploitation then mbs.from_dt - 1 else mbs.from_dt end as dt_dt
                FROM md_bed b
                    JOIN lateral (select from md_bed_resource mbr where mbr.bed_id = b.id) mbr on TRUE
                    JOIN LATERAL (select from pim_room_resource prr where prr.room_id = b.room_id limit 1) prr on true -- палата является ресурсом
                    JOIN md_room mr ON b.room_id = mr.id
                    join pim_room r on r.id = b.room_id
                    JOIN pim_department d ON d.id = r.department_id
                    JOIN md_department_profile dp ON d.id = dp.department_id
                    JOIN md_profile p ON p.id = dp.profile_id
                    join md_bed_state mbs on mbs.bed_id = b.id
                    join pim_stock_unit_state psus on psus.id = mbs.state_id
                where b.id = OLD.bed_id
                    and mbs.from_dt between coalesce(b.from_dt, mbs.from_dt) and coalesce(b.to_dt, mbs.from_dt) -- после основной даты закрытия койки изменения статусов не смотрим (но в случае изменения pim_bed пересчитываем и статусы заново)
                    and mbs.id <> OLD.id
                    ),
                bed_room_profile as (
                    select r.r_id, rp.profile_id from bed_room r join md_room_profile rp on rp.room_id = r.r_id and rp.profile_id = r.p_id group by 1, 2
                    ),
                bed_room_tree as (
                    select r.* from bed_room r where not exists (select from bed_room_profile rp where rp.r_id = r.r_id)
                    union all
                    select r.* from bed_room r join bed_room_profile rp on r.r_id = rp.r_id and r.p_id = rp.profile_id
                    )
                --select r.r_id, rp.profile_id from bed_room r join md_room_profile rp on rp.room_id = r.r_id and rp.profile_id = r.p_id
            select distinct * from bed_room_tree
            ),

        w_tree_sort as (
            select  *, sum(sort) over (partition by bed_tree, dt_dt order by bed_tree, from_dt, sort, dt_dt, sort_name) as dd -- количество открытий и закрытий в один день
            FROM    (
                select  bed_tree, from_dt, sort, dt_dt, sort_name, LAG (sort, 1, 0) over (partition by bed_tree order by bed_tree, from_dt, sort, dt_dt, sort_name) as sort_lag, LEAD (sort, 1, -1) over (partition by bed_tree order by bed_tree, from_dt, sort, dt_dt, sort_name) as sort_lead
                from    (
                    select  bed_tree, from_dt, 2 as sort, dt_dt, 'begin' as sort_name from w_tree where from_dt is not null
                    UNION ALL
                    select  bed_tree, to_dt, 1, dt_dt, 'end' from w_tree where to_dt is not null
                    GROUP BY 1, 2, 3, 4, 5
                    order by 1, 2, 3, 4, 5
                    )t
                )t
            ),

        w_tree_new as  (-- расчетное состояние исключений по КОЙКЕ и статусам койки
            select  bed_tree, daterange(null, from_dt, '[]') as date_range, concat('по ', to_char(from_dt, 'dd.mm.yyyy'), ' эта койка недоступна') as comment from w_tree_sort where sort_lag = 0 and sort = 2
            UNION ALL
            select  bed_tree, daterange(from_dt, null, '[]') as date_range, concat('c ', to_char(from_dt, 'dd.mm.yyyy'), ' эта койка недоступна') as comment from w_tree_sort where sort_lag = 0 and sort_lead = -1 and sort = 1
            UNION ALL
            select  bed_tree, daterange(from_dt, lead_dt, '[]') as date_range, concat('c ', to_char(from_dt, 'dd.mm.yyyy'), ' по ' || to_char(lead_dt, 'dd.mm.yyyy'), ' эта койка недоступна')
            from   (
                select *, lead(from_dt) over (partition by bed_tree order by bed_tree, from_dt) as lead_dt
                from w_tree_sort
                where --sort_lag <> 0
                    sort <> coalesce(sort_lag, 0)
                order by 1, 2, 3
                )t
            WHERE   sort = 1
                --and from_dt IS DISTINCT FROM  lead_dt
                and coalesce(from_dt, lead_dt) <= coalesce(lead_dt, from_dt)
            ),

        w_tree_bd as (
            select id, bed_tree, date_range, comment
            from hospital.unused_bed
            where nlevel(bed_tree) = 5 and subpath(bed_tree, 4, 1) = OLD.bed_id::text::ltree
            ),

        w_tree_delta as (
            select  bed_tree as delta_bed_tree, date_range as delta_date_range, comment as delta_comment,
                sum(delta) as delta -- 1 - есть только в новом состоянии, добавляем в дельта
                                    -- 2 - есть только в бд, удаляем
                                    -- 3 - есть и там и там, ничего не делаем
            from (
                select distinct bed_tree, date_range, comment, 1 as delta from w_tree_new
                union all
                select bed_tree, date_range, comment, 2 as delta from w_tree_bd
                )t
            group by bed_tree, date_range, comment
            ),

        del_w_tree_bd as (
            delete from hospital.unused_bed using w_tree_delta
            WHERE bed_tree = delta_bed_tree and date_range = delta_date_range and comment = delta_comment
                and delta = 2
            RETURNING 1
            ),

        ins_w_tree_bd as (
            insert into hospital.unused_bed (bed_tree, date_range, comment)
            select delta_bed_tree, delta_date_range, delta_comment from w_tree_delta where delta = 1
            RETURNING 1
            )
        select 1 into REZ;

        IF (TG_OP = 'DELETE') THEN
            RETURN OLD;
        END IF;
    END IF;
    IF (TG_OP <> 'DELETE') THEN
        -- если было изменение подразделения или профиля в текущем профиле подразделения то мы старые значения уже пересчитали, остается заполнить новое состояние
        WITH w_tree as (
            WITH bed_room as ( -- исключения по койке дата открытия дата закрытия койки
                SELECT
                    d.id as d_id,
                    dp.id as dp_id,
                    p.id as p_id,
                    r.id as r_id,
                    b.id as b_id,
                    d.id :: TEXT :: LTREE || p.id :: TEXT || p.id :: TEXT || r.id :: TEXT || b.id :: TEXT AS bed_tree,
                    b.from_dt - 1 as from_dt,
                    b.to_dt,
                    unnest(array[(b.from_dt - 1), b.to_dt]) as dt_dt
                FROM md_bed b
                    JOIN lateral (select from md_bed_resource mbr where mbr.bed_id = b.id) mbr on TRUE
                    JOIN LATERAL (select from pim_room_resource prr where prr.room_id = b.room_id limit 1) prr on true -- палата является ресурсом
                    JOIN md_room mr ON b.room_id = mr.id
                    join pim_room r on r.id = b.room_id
                    JOIN pim_department d ON d.id = r.department_id
                    JOIN md_department_profile dp ON d.id = dp.department_id
                    JOIN md_profile p ON p.id = dp.profile_id
                where b.id = NEW.bed_id
                union ALL
                SELECT -- исключения по статусам койки (дату действия статуса смотрим до следующего изменения статуса)
                    d.id as d_id,
                    dp.id as dp_id,
                    p.id as p_id,
                    r.id as r_id,
                    b.id as b_id,
                    d.id :: TEXT :: LTREE || p.id :: TEXT || p.id :: TEXT || r.id :: TEXT || b.id :: TEXT AS bed_tree,
                    case when psus.exploitation then mbs.from_dt - 1 else null::date end as from_dt,
                    case when psus.exploitation then null::date else mbs.from_dt end as to_dt,
                    case when psus.exploitation then mbs.from_dt - 1 else mbs.from_dt end as dt_dt
                FROM md_bed b
                    JOIN lateral (select from md_bed_resource mbr where mbr.bed_id = b.id) mbr on TRUE
                    JOIN LATERAL (select from pim_room_resource prr where prr.room_id = b.room_id limit 1) prr on true -- палата является ресурсом
                    JOIN md_room mr ON b.room_id = mr.id
                    join pim_room r on r.id = b.room_id
                    JOIN pim_department d ON d.id = r.department_id
                    JOIN md_department_profile dp ON d.id = dp.department_id
                    JOIN md_profile p ON p.id = dp.profile_id
                    join md_bed_state mbs on mbs.bed_id = b.id
                    join pim_stock_unit_state psus on psus.id = mbs.state_id
                where b.id = NEW.bed_id
                    and mbs.from_dt between coalesce(b.from_dt, mbs.from_dt) and coalesce(b.to_dt, mbs.from_dt) -- после основной даты закрытия койки изменения статусов не смотрим (но в случае изменения pim_bed пересчитываем и статусы заново)
                    ),
                bed_room_profile as (
                    select r.r_id, rp.profile_id from bed_room r join md_room_profile rp on rp.room_id = r.r_id and rp.profile_id = r.p_id group by 1, 2
                    ),
                bed_room_tree as (
                    select r.* from bed_room r where not exists (select from bed_room_profile rp where rp.r_id = r.r_id)
                    union all
                    select r.* from bed_room r join bed_room_profile rp on r.r_id = rp.r_id and r.p_id = rp.profile_id
                    )
                --select r.r_id, rp.profile_id from bed_room r join md_room_profile rp on rp.room_id = r.r_id and rp.profile_id = r.p_id
            select DISTINCT * from bed_room_tree
            ),

        w_tree_sort as (
            select  *, sum(sort) over (partition by bed_tree, dt_dt order by bed_tree, from_dt, sort, dt_dt, sort_name) as dd -- количество открытий и закрытий в один день
            FROM    (
                select  bed_tree, from_dt, sort, dt_dt, sort_name, LAG (sort, 1, 0) over (partition by bed_tree order by bed_tree, from_dt, sort, dt_dt, sort_name) as sort_lag, LEAD (sort, 1, -1) over (partition by bed_tree order by bed_tree, from_dt, sort, dt_dt, sort_name) as sort_lead
                from    (
                    select  bed_tree, from_dt, 2 as sort, dt_dt, 'begin' as sort_name from w_tree where from_dt is not null
                    UNION ALL
                    select  bed_tree, to_dt, 1, dt_dt, 'end' from w_tree where to_dt is not null
                    GROUP BY 1, 2, 3, 4, 5
                    order by 1, 2, 3, 4, 5
                    )t
                )t
            ),

        w_tree_new as  (-- расчетное состояние исключений по КОЙКЕ и статусам койки
            select  bed_tree, daterange(null, from_dt, '[]') as date_range, concat('по ', to_char(from_dt, 'dd.mm.yyyy'), ' эта койка недоступна') as comment from w_tree_sort where sort_lag = 0 and sort = 2
            UNION ALL
            select  bed_tree, daterange(from_dt, null, '[]') as date_range, concat('c ', to_char(from_dt, 'dd.mm.yyyy'), ' эта койка недоступна') as comment from w_tree_sort where sort_lag = 0 and sort_lead = -1 and sort = 1
            UNION ALL
            select  bed_tree, daterange(from_dt, lead_dt, '[]') as date_range, concat('c ', to_char(from_dt, 'dd.mm.yyyy'), ' по ' || to_char(lead_dt, 'dd.mm.yyyy'), ' эта койка недоступна')
            from   (
                select *, lead(from_dt) over (partition by bed_tree order by bed_tree, from_dt) as lead_dt
                from w_tree_sort
                where --sort_lag <> 0
                    sort <> coalesce(sort_lag, 0)
                order by 1, 2, 3
                )t
            WHERE   sort = 1
                --and from_dt IS DISTINCT FROM  lead_dt
                and coalesce(from_dt, lead_dt) <= coalesce(lead_dt, from_dt)
            ),

        w_tree_bd as (
            select id, bed_tree, date_range, comment
            from hospital.unused_bed
            where nlevel(bed_tree) = 5 and subpath(bed_tree, 4, 1) = new.bed_id::text::ltree
            ),

        w_tree_delta as (
            select  bed_tree as delta_bed_tree, date_range as delta_date_range, comment as delta_comment,
                sum(delta) as delta -- 1 - есть только в новом состоянии, добавляем в дельта
                                    -- 2 - есть только в бд, удаляем
                                    -- 3 - есть и там и там, ничего не делаем
            from (
                select distinct bed_tree, date_range, comment, 1 as delta from w_tree_new
                union all
                select bed_tree, date_range, comment, 2 as delta from w_tree_bd
                )t
            group by bed_tree, date_range, comment
            ),

        del_w_tree_bd as (
            delete from hospital.unused_bed using w_tree_delta
            WHERE bed_tree = delta_bed_tree and date_range = delta_date_range and comment = delta_comment
                and delta = 2
            RETURNING 1
            ),

        ins_w_tree_bd as (
            insert into hospital.unused_bed (bed_tree, date_range, comment)
            select delta_bed_tree, delta_date_range, delta_comment from w_tree_delta where delta = 1
            RETURNING 1
            )
        select 1 into REZ;
        RETURN NEW;
    END IF;
END;
$$;

