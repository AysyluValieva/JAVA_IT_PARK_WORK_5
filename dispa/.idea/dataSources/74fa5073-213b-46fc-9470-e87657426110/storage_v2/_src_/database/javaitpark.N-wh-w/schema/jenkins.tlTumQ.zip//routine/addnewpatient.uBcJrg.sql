CREATE FUNCTION addnewpatient(_birth_dt character varying, _surname character varying, _name character varying, _patr_name character varying, _snils character varying, _mobilephone character varying, _lpu_id character varying)
  RETURNS integer
LANGUAGE plpgsql
AS $$
DECLARE
  _patient_id_result integer;
BEGIN
 select * into _patient_id_result from "jenkins"."add_new_patient_v1"("_birth_dt" , "_surname" , "_name" , "_patr_name" , "_snils" , "_mobilephone" , "_lpu_id" );
RETURN _patient_id_result;
END;
$$;

