CREATE FUNCTION update_call_card(xcall integer, xis_psycho boolean, xis_alco boolean, xcaller_reason_id integer, xreason_diag integer, xreason_note character varying, xcall_place_id integer, xcall_place_note character varying, xplace_org_id integer, xplace_department_id integer, xaddress_id integer, xhouse character varying, xhousing character varying, xapartment character varying, xporch character varying, xfloor character varying, xdoor_code character varying, xdescription character varying, xpatient_id integer, xsurname character varying, xname character varying, xpatrname character varying, xbirthdt date, xgender integer, xage_years integer, xage_months integer, xage_days integer, xis_chronic boolean, xphone_caller character varying, xcaller_id integer, xcaller_note character varying, xemployee_id integer, xnote character varying, xreg integer, xexit_time time without time zone, xcoming_time time without time zone, xtransportation_time time without time zone, xtoclinic_time time without time zone, xtosubstation_time time without time zone, xdeath_time time without time zone, xcall_reason_id integer, xreason_accident_id integer, xcondition_ns character varying, xcitizenship_type_id integer, xnsdatatime timestamp without time zone, xreceive_brg integer, xtime_gone_id integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
                      dt date;
                      xrendered integer;
                      xcase integer;
                      xstep integer;
                      -- time поля
                      xexit_time_id integer;
                      xcoming_time_id integer;
                      xtransportation_time_id integer;
                      xtoclinic_time_id integer;
                      xtosubstation_time_id integer;
                      xstate integer;
                      xrenderedsel record;
                      -- вид услуги
                      xservice integer;
                      xcallnote integer;

                    begin
                      --выбираем данные для последующей обработки
                      if ((select cast(date_time as date)
                           from amb.md_ambcall_state_history
                           where state_id = (select id from amb.md_ambulance_call_state where e_code ='5') and call_id = xcall order by date_time desc limit 1) >
                          (select cast(from_time as date) from amb.md_ambulance_call where id = xcall))
                      then
                        dt = (select cast(date_time as date)
                              from amb.md_ambcall_state_history
                              where state_id = (select id from amb.md_ambulance_call_state where e_code ='5') and call_id = xcall order by date_time desc limit 1);
                      else
                        dt = (select cast(from_time as date) from amb.md_ambulance_call where id = xcall);
                      end if;

                      select into xcase, xrendered case_id, srv_rendered_id from amb.md_ambulance_call_result where id = xcall;
                      select into xstep id from mc_step where case_id = xcase;

                      -- time поля
                      --xexit_time  -- выезд с п/ст
                      IF xexit_time is not null
                      THEN
                        select into xexit_time_id mash.id from amb.md_ambcall_state_history mash
                          left join amb.md_ambulance_call_state macs on macs.id = mash.state_id
                        where macs.code = '6' and mash.call_id = xcall;
                        if xexit_time_id is null
                        then
                          --select
                          xstate := amb.add_ambcall_state_hist (xcall,cast(dt + xexit_time as timestamp),6,2,xreg);
                        else
                          update amb.md_ambcall_state_history set date_time = cast(dt + xexit_time as timestamp) where id = xexit_time_id;
                        end if;
                      END IF;
                      --xcoming_time -- прибытие на вызов
                      IF xcoming_time is not null
                      THEN
                        select into xcoming_time_id mash.id from amb.md_ambcall_state_history mash
                          left join amb.md_ambulance_call_state macs on macs.id = mash.state_id
                        where macs.code = '7' and mash.call_id = xcall;
                        if xcoming_time_id is null
                        then
                          --select
                          xstate := amb.add_ambcall_state_hist (xcall,cast(dt + xcoming_time as timestamp),7,2,xreg);
                        else
                          update amb.md_ambcall_state_history set date_time = cast(dt + xcoming_time as timestamp) where id = xcoming_time_id;
                        end if;
                      END IF;

                      --xtransportation_time  -- начало транспортировки
                      IF xtransportation_time is not null
                      THEN
                        select into xtransportation_time_id mash.id from amb.md_ambcall_state_history mash
                          left join amb.md_ambulance_call_state macs on macs.id = mash.state_id
                        where macs.code = '8' and mash.call_id = xcall;
                        if xtransportation_time_id is null
                        then
                          --select
                          xstate := amb.add_ambcall_state_hist (xcall,cast(dt + xtransportation_time as timestamp),8,2,xreg);
                        else
                          update amb.md_ambcall_state_history set date_time = cast(dt + xtransportation_time as timestamp) where id = xtransportation_time_id;
                        end if;
                      END IF;
                      --xtoclinic_time -- прибытие в МО
                      IF xtoclinic_time is not null
                      THEN
                        select into xtoclinic_time_id mash.id from amb.md_ambcall_state_history mash
                          left join amb.md_ambulance_call_state macs on macs.id = mash.state_id
                        where macs.code = '9' and mash.call_id = xcall;
                        if xtoclinic_time_id is null
                        then
                          --select
                          xstate := amb.add_ambcall_state_hist (xcall,cast(dt + xtoclinic_time as timestamp),9,2,xreg);
                        else
                          update amb.md_ambcall_state_history set date_time = cast(dt + xtoclinic_time as timestamp) where id = xtoclinic_time_id;
                        end if;
                      END IF;

                      --xtosubstation_time time -- возвращение на п/ст
                      IF xtosubstation_time is not null
                      THEN
                        select into xtosubstation_time_id mash.id from amb.md_ambcall_state_history mash
                          left join amb.md_ambulance_call_state macs on macs.id = mash.state_id
                        where macs.code = '11' and mash.call_id = xcall;
                        if xtosubstation_time_id is null
                        then
                          --select
                          xstate := amb.add_ambcall_state_hist (xcall,cast(dt + xtosubstation_time as timestamp),11,2,xreg);
                        else
                          update amb.md_ambcall_state_history set date_time = cast(dt + xtosubstation_time as timestamp) where id = xtosubstation_time_id;
                        end if;
                      END IF;

                      -- данные о вызове (кроме данных о пациенте)
                      update amb.md_ambulance_call set
                        caller_reason_id = xcaller_reason_id,
                        reason_diag = xreason_diag,
                        reason_note = xreason_note,
                        call_place_id = xcall_place_id,
                        call_place_note = xcall_place_note,
                        place_org_id = xplace_org_id,
                        place_department_id = xplace_department_id,
                        address_id  = xaddress_id,
                        house = xhouse,
                        housing = xhousing,
                        apartment = xapartment,
                        porch = xporch,
                        floor = xfloor,
                        door_code = xdoor_code,
                        description = xdescription,
                        is_chronic = xis_chronic,
                        age_years = xage_years,
                        age_months = xage_months,
                        age_days = xage_days,
                        phone_caller = xphone_caller,
                        caller_id = xcaller_id,
                        caller_note = xcaller_note,
                        employee_id = xemployee_id,
                        note = xnote
                      where id = xcall;

                      -- данные о пациенте
                      -- что делать с документами пациента, если он выбран не из базы, надо решить
                      if xpatient_id = (select patient_id from amb.md_ambulance_call where id = xcall)
                      then
                        update pim_individual set surname = xsurname, name = xname, patr_name = xpatrname, birth_dt = xbirthdt, gender_id = xgender where id = xpatient_id;
                      else
                        update amb.md_ambulance_call set patient_id = xpatient_id, age_years = xage_years, age_months = xage_months, age_days = xage_days where id = xcall;
                      end if;

                      -- записи в результат вызова информации по сопроводительному листу --xhas_list = ();-- по виду вызова и отметкам (д.б. госпитализация)
                      update amb.md_ambulance_call_result set
                        call_reason_id = xcall_reason_id,
                        reason_accident_id = xreason_accident_id,
                        citizenship_type_id = xcitizenship_type_id,
                        condition_ns = xcondition_ns,
                        nsdatatime = xnsdatatime,
                        receive_brg = xreceive_brg
                      where id = xcall;

                      update mc_case set time_gone_id = xtime_gone_id
                      where id = xcase;

                      update mc_step set  death_time = xdeath_time
                        where id = xstep;

                      --записи в случай (mc_case)
                      update sr_srv_rendered set customer_id = xpatient_id where id = xrendered;
                      for xrenderedsel in select service_id from amb.md_ambulance_call_services where call_id = xcall
                        loop
                          update sr_srv_rendered set customer_id = xpatient_id where id = xrenderedsel.service_id;
                        end loop;

                      -- автодобавление отметок
                      execute amb.auto_add_call_note_amb_card (xcall, xcaller_reason_id, xreason_diag, xreg, xplace_org_id, xplace_department_id, null, xis_psycho, xis_alco);

                      -- определение вида услуги
                      xservice := amb.set_service (xcall);

                      return xcall;
                    end;
$$;

