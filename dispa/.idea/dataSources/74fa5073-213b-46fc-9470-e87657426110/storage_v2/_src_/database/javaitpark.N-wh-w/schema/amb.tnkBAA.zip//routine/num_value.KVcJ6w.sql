CREATE FUNCTION num_value(xorg integer, xchange integer, xdep integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
                            xn 			    integer;
                            xv 			    integer;
                            xtype 		    integer;
                            xstartdate      date;
                            xambnumsettid   integer;
                        begin
                            with numb_setting
                              as (
                                     select id,
                                            start_date,
                                            type_num
                                       from amb.md_ambulance_numb_setting
                                      where clinic_id = xorg
                                 )
                                select into xn, xv, xambnumsettid, xtype, xstartdate
                                       an.id,
                                       an.value + 1,
                                       ns.id,
                                       ns.type_num,
                                       ns.start_date
                                  from amb.md_ambulance_numbers an
                                  join numb_setting ns on an.numb_id = ns.id
                                 where change_id = xchange
                                   and dep_id = xdep;

                            if (
                                 xtype = 1
                                   and (
                                        select extract(days from age(current_date, xstartdate)) > 0
                                       )
                               or
                               (
                                 xtype = 2
                                   and (
                                                    select extract(days from (age(current_date, (select xstartdate - (
                                                                                                                                case extract(dow from xstartdate)
                                                                                                                                   when 0 then 7
                                                                                                                                   else extract(dow from xstartdate)
                                                                                                                                 end
                                                                                                                                )::int
                                                                                                   + 1
                                                                                                   )
                                                                                   )
                                                                                )
                                                                    ) > 6
                                        )
                                )
                                or
                               (
                                 xtype = 3
                                   and (
                                           select extract(month from age(current_date, xstartdate)) > 0
                                       )
                               )
                                or
                               (
                                  xtype = 4
                                    and (
                                          select extract(year from age(current_date, xstartdate)) > 0
                                        )
                               )
                             )
                            then
                                xv := 1;

                                update amb.md_ambulance_numb_setting
                                   set start_date = current_date
                                 where id = xambnumsettid;
                            end if;

                            update amb.md_ambulance_numbers
                               set value = xv
                             where id = xn;

                            return xv;
                        end;
$$;

