CREATE FUNCTION fin_bill__get_payer(bill_id integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
    main_bill_id integer;
    payer_id integer;
begin
    main_bill_id = (select fin_bill__get_main_bill(bill_id));
    payer_id = (select fin_bill_main.payer_id from fin_bill_main where fin_bill_main.id = main_bill_id);
    return payer_id;
end;
$$;

