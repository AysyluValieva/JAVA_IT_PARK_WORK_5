CREATE FUNCTION exists_address_in_building_template(building_number character varying, building_template text)
  RETURNS boolean
LANGUAGE plpgsql
AS $$
DECLARE
	tokens text[];
    building text;
    address text;
    building_n text := ' '||building_number;
    building_from integer;
    building_to integer;
BEGIN

	if (building_number is null or trim(building_number) = '')
    	and
	    (building_template is null or trim(building_template) = '') then
        return false;
	end if;

    select string_to_array(building_template, ',') into tokens;

    foreach building in array tokens loop
    	if building is not null and upper(trim(building_number)) = upper(trim(building)) then
        	return true;
        end if;

        address := ' ';

        -- интервал домов без четности/нечетности
        if position('-' in trim(building)) > 0 then
        	if position('Ч' in upper(trim(building))) = 0 and position('Н' in upper(trim(building))) = 0 then
            	building_from := cast(substring(trim(building)
                				from 0
                                for position('-' in trim(building))) as integer);
                building_to := cast(substring(trim(building)
                				from position('-' in trim(building)) + 1
                                for length(trim(building)) - position('-' in trim(building))) as integer);
                while building_from <= building_to loop
                	address := address || building_from || ' ';
                    building_from := building_from + 1;
                end loop;
				if position(building_n in address) <> 0 then
                	return true;
                else
                	return false;
                end if;
            end if;

            -- интервал домов с четностью
            if position('Ч' in upper(trim(building))) > 0 then
            	building_from := cast(substring(trim(building)
                				from position('(' in trim(building)) + 1
                                for position('-' in trim(building)) - 1 - position('(' in trim(building))) as integer);
                building_to := cast(substring(trim(building)
                				from position('-' in trim(building)) + 1
                                for position(')' in trim(building)) - 1 - position('-' in trim(building))) as integer);
                while building_from <= building_to loop
                	if building_from % 2 = 0 then
                    	address := address || building_from || ' ';
                    end if;
                	building_from := building_from + 1;
                end loop;
                if position(building_n in address) <> 0 then
                	return true;
                else
                	return false;
                end if;
            end if;

            -- интервал домов с нечетностью
            if position('Н' in upper(trim(building))) > 0 then
            	building_from := cast(substring(trim(building)
                				from position('(' in trim(building)) + 1
                                for position('-' in trim(building)) - 1 - position('(' in trim(building))) as integer);
                building_to := cast(substring(trim(building)
                				from position('-' in trim(building)) + 1
                                for position(')' in trim(building)) - 1 - position('-' in trim(building))) as integer);
                while building_from <= building_to loop
                	if building_from % 2 <> 0 then
                    	address := address || cast(building_from as text) || ' ';
                    end if;
                	building_from := building_from + 1;
                end loop;
                if position(building_n in address) <> 0 then
                	return true;
                else
                	return false;
                end if;
            end if;
        end if;

    end loop;

    return false;

    exception
    	when invalid_text_representation then
        	return false;

END;
$$;

