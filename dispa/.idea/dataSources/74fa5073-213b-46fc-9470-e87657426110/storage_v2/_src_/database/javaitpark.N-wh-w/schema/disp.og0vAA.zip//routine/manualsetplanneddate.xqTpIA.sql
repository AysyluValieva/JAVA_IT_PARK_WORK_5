CREATE FUNCTION manualsetplanneddate(xiid integer, xeid integer, xdate character varying)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
          i integer;
        begin
          IF (select count(*) from disp.md_event_planning where indiv_id = xiid and event_id = xeid) > 0 THEN
            update disp.md_event_planning set target_date = to_date(xdate, 'DD.MM.YYYY')
              where indiv_id = xiid and event_id = xeid;
          ELSE
            insert into disp.md_event_planning (id, indiv_id, event_id, target_date, district_id)
              values (nextval('disp.md_event_planning_seq'), xiid, xeid, to_date(xdate, 'DD.MM.YYYY'), NULL);
          END IF;
          return 1;
        end;
$$;

