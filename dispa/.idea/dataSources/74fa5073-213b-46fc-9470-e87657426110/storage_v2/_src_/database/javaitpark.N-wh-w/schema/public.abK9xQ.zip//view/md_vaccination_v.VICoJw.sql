CREATE VIEW md_vaccination_v AS
  SELECT mdsrvren.id,
    to_char((srvren.bdate)::timestamp with time zone, 'DD.MM.YYYY'::text) AS begin_date,
    ( SELECT ehr_protocol_query_result.value
           FROM ehr_protocol_query_result
          WHERE ((ehr_protocol_query_result.query_id = ( SELECT ehp.id
                   FROM ehr_protocol_query ehp
                  WHERE ((ehp.code)::text = 'vaccinationBase'::text))) AND (ehr_protocol_query_result.protocol_id = srvpr.protocol_id))
          ORDER BY ehr_protocol_query_result.id DESC
         LIMIT 1) AS basis,
    srv.name AS vaccine_type,
    vac.vac_name AS name,
    ( SELECT ehr_protocol_query_result.value
           FROM ehr_protocol_query_result
          WHERE ((ehr_protocol_query_result.query_id = ( SELECT ehp.id
                   FROM ehr_protocol_query ehp
                  WHERE ((ehp.code)::text = 'vaccinationMethod'::text))) AND (ehr_protocol_query_result.protocol_id = srvpr.protocol_id))
          ORDER BY ehr_protocol_query_result.id DESC
         LIMIT 1) AS method,
    ((vac.vac_dose || ' '::text) || (vac.meas)::text) AS dose,
    vac.vac_series AS series,
    (((((COALESCE(indiv.surname, ' '::character varying))::text || ' '::text) || (COALESCE(indiv.name, ''::character varying))::text) || ' '::text) || (COALESCE(indiv.patr_name, ''::character varying))::text) AS pat_fio,
    to_char((indiv.birth_dt)::timestamp with time zone, 'DD.MM.YYYY'::text) AS pat_birth_day,
    ( SELECT ehr_protocol_query_result.value
           FROM ehr_protocol_query_result
          WHERE ((ehr_protocol_query_result.query_id = ( SELECT ehp.id
                   FROM ehr_protocol_query ehp
                  WHERE ((ehp.code)::text = 'vaccinationNote'::text))) AND (ehr_protocol_query_result.protocol_id = srvpr.protocol_id))
          ORDER BY ehr_protocol_query_result.id DESC
         LIMIT 1) AS note
   FROM (((((((md_srv_rendered mdsrvren
     JOIN sr_srv_rendered srvren ON ((srvren.id = mdsrvren.id)))
     LEFT JOIN sr_service srv ON ((srvren.service_id = srv.id)))
     JOIN md_vaccination_srv_prototype vac_srv_prot ON ((vac_srv_prot.srv_prototype_id = srv.prototype_id)))
     LEFT JOIN pci_patient pat ON ((srvren.customer_id = pat.id)))
     LEFT JOIN md_srv_protocol srvpr ON ((srvpr.srv_rendered_id = srvren.id)))
     JOIN pim_individual indiv ON ((indiv.id = pat.id)))
     LEFT JOIN ( SELECT
                CASE
                    WHEN (vac_1.wrire_off_for_service_id IS NOT NULL) THEN vac_1.wrire_off_for_service_id
                    ELSE vac_1.not_wrire_off_for_service_id
                END AS srv_ren_id,
                CASE
                    WHEN (vac_1.wrire_off_for_service_id IS NOT NULL) THEN vac_1.write_off_name
                    ELSE vac_1.not_write_off_name
                END AS vac_name,
                CASE
                    WHEN (vac_1.wrire_off_for_service_id IS NOT NULL) THEN vac_1.write_off_amount
                    ELSE vac_1.not_write_off_count
                END AS vac_dose,
                CASE
                    WHEN (vac_1.wrire_off_for_service_id IS NOT NULL) THEN vac_1.write_off_meas
                    ELSE vac_1.not_write_off_meas
                END AS meas,
                CASE
                    WHEN (vac_1.wrire_off_for_service_id IS NOT NULL) THEN (vac_1.write_off_series)::text
                    ELSE vac_1.not_wrire_off_series
                END AS vac_series
           FROM ( SELECT write_off.wrire_off_for_service_id,
                    write_off.write_off_name,
                    write_off.write_off_amount,
                    write_off.write_off_meas,
                    write_off.write_off_series,
                    not_write_off.not_wrire_off_for_service_id,
                    not_write_off.not_write_off_name,
                    not_write_off.not_write_off_count,
                    not_write_off.not_write_off_meas,
                    not_write_off.not_wrire_off_series
                   FROM (( SELECT srv_cons.service_id AS wrire_off_for_service_id,
                            ih.name_trade AS write_off_name,
                            ispec.amount AS write_off_amount,
                            meas.mnemocode AS write_off_meas,
                            iser.num AS write_off_series
                           FROM ((((((inv_holding ih
                             JOIN inv_spec ispec ON ((ispec.holding_id = ih.id)))
                             JOIN mc_inv_spec_consumable spec_cons ON ((ispec.id = spec_cons.spec_id)))
                             JOIN mc_inv_srv_consumable srv_cons ON ((srv_cons.id = spec_cons.srv_consumable_id)))
                             LEFT JOIN cmn_measure meas ON ((meas.id = ispec.unit_id)))
                             LEFT JOIN inv_remains ir ON ((ir.id = ispec.init_remains_id)))
                             LEFT JOIN inv_series iser ON ((iser.id = ir.series_id)))) write_off
                     FULL JOIN ( SELECT srv_cons.service_id AS not_wrire_off_for_service_id,
                            ih.name_trade AS not_write_off_name,
                            cons.count AS not_write_off_count,
                            meas.mnemocode AS not_write_off_meas,
                            ( SELECT ehr_protocol_query_result.value
                                   FROM ehr_protocol_query_result
                                  WHERE ((ehr_protocol_query_result.query_id = ( SELECT ehr_protocol_query.id
   FROM ehr_protocol_query
  WHERE ((ehr_protocol_query.code)::text = 'vaccinationSeries'::text))) AND (ehr_protocol_query_result.protocol_id = srvpr_1.protocol_id))
                                  ORDER BY ehr_protocol_query_result.id DESC
                                 LIMIT 1) AS not_wrire_off_series
                           FROM ((((inv_holding ih
                             JOIN mc_inv_consumable cons ON ((ih.id = cons.holding_id)))
                             JOIN mc_inv_srv_consumable srv_cons ON ((srv_cons.id = cons.id)))
                             LEFT JOIN cmn_measure meas ON ((meas.id = cons.measure_id)))
                             LEFT JOIN md_srv_protocol srvpr_1 ON ((srvpr_1.srv_rendered_id = srv_cons.service_id)))) not_write_off ON ((not_write_off.not_wrire_off_for_service_id = write_off.wrire_off_for_service_id)))) vac_1) vac ON ((vac.srv_ren_id = mdsrvren.id)))
  ORDER BY mdsrvren.id;

