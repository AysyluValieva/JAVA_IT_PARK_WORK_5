CREATE FUNCTION update_card_paper(xid integer, xcall_num integer, xcall_dt integer, xcall_kind_id integer, xcall_type_id integer, xis_group_sufferer boolean, xis_psycho boolean, xis_alco boolean, xsum_sufferer integer, xcaller_reason_id integer, xreason_diag integer, xreason_note character varying, xcall_place_id integer, xcall_place_note character varying, xplace_org_id integer, xplace_department_id integer, xaddress_id integer, xhouse character varying, xhousing character varying, xapartment character varying, xporch character varying, xfloor character varying, xdoor_code character varying, xto_org_id integer, xto_department_id integer, xto_address_id integer, xto_house character varying, xto_housing character varying, xto_apartment character varying, xto_porch character varying, xto_description character varying, xpatient_id integer, xsurname character varying, xname character varying, xpatrname character varying, xbirthdt date, xgender integer, xis_chronic boolean, xyears integer, xmonths integer, xdays integer, xphone_caller character varying, xcaller_id integer, xemployee_id integer, xcaller_note character varying, xpriority_id integer, xpriority integer, xcontrol integer, xnote character varying, xregistrator_id integer, xstation_id integer, xroute_id integer, xsubstation_id integer, xbrg_id integer, xemp_id integer, xtransregistrator_id integer, xreceipt_time time without time zone, xtransmit_time time without time zone, xto_time time without time zone, xresdoc integer, xres1 integer, xres2 integer, xcardreg integer, xdeath_time time without time zone, xout_delay_reason_id integer, xcall_reason_id integer, xreason_accident_id integer, xcondition_ns character varying, xcitizenship_type_id integer, xnsdatatime timestamp without time zone, xmilage numeric, xneed_exit_through integer, xactiv_visit_clinic_id integer, xother_recommendations character varying, xtime_gone_id integer, xtransporting_type_id integer, xcasenote character varying, xdeathres character varying, xdeathdiag integer, xmasterdiag integer, xmcdiag integer, xresult_id integer, xdeath_date date, xdeathemp integer, xoutdate date, xouttime time without time zone, xout integer, xaccompdiag integer, xaccompd integer, xmdisease_type integer, xaccompdisease_type integer, xtake_birth_id integer, xuser integer, xcase integer, xstep integer, xgroup integer, xrelationshipdoc integer, xrelationshipres1 integer, xrelationshipres2 integer, xmaster_injury integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
                            -- время приёма вызова
                            xfrom_dt date;
                            xfrom_time timestamp without time zone;
                            -- время передачи бригаде
                            xtrans_time timestamp without time zone;
                            -- из посыла
                            xbrg integer;	-- вот это уже наряд!
                            -- из завершения
                            xend_time timestamp without time zone;
                            -- для услуги
                            xrendered integer;
                            --диагнозы
                            xstage integer;
                            xaccompstage integer;
                            xmdiatype integer;
                            xaccompdiatype integer;
                            xdoctor integer;

                          begin

                                --преобразование времени приёма в timestamp
                                xfrom_dt = (select from_data from amb.md_ambulance_change where id = xcall_dt);
                                --xreceipt_time time		-- приём
                                xfrom_time = case when xreceipt_time between cast('00:00' as time) and
                                                (select change_begin from amb.md_ambulance_change_setting where clinic_id = xstation_id and coalesce(department_id, 0) = coalesce(xsubstation_id, 0))
                                            then cast(cast(xfrom_dt + cast('1 day' as interval) as date)||' '|| xreceipt_time  as timestamp without time zone)
                                            else cast(xfrom_dt ||' ' ||xreceipt_time  as timestamp without time zone)
                                            end;

                                 if (xpatient_id is null)
                                    then
                                        xpatient_id = amb.create_pat_vrem (xsurname,xname,xpatrname,xbirthdt,xgender);
                                        update pci_patient set
                                        note = note||', '||(select short_name from pim_organization where id = xstation_id)||', вызов №'||cast(xcall_num as varchar(6))||' от '||(select to_char(from_data,'dd.mm.yyyy') from amb.md_ambulance_change where id = xcall_dt)
                                        where id = xpatient_id;
                                /*1*/end if;
                                -- формирование наряда на бригаду на смену вызова
                                -- xbrg_id -- пока регистратором бригады будет диспетчер направления


                                xbrg := amb.add_res_team_job(xbrg_id,xcall_dt,xtransregistrator_id);
                                 if amb.search_team_job_status (xbrg) is null
                                    then
                                        update amb.sr_res_team_job set bdate = cast((select from_data ||' ' ||from_time from amb.md_ambulance_change where id = xcall_dt) as timestamp without time zone) where id = xbrg;
                                        --cast((select from_data ||' ' ||from_time from amb.md_ambulance_change where id = xcall_dt) as timestamp without time zone)
                                        execute amb.add_team_job_status_hist(xbrg,cast((select from_data ||' ' ||from_time from amb.md_ambulance_change where id = xcall_dt) as timestamp without time zone),1,xtransregistrator_id,'подписка',xuser);

                                        update amb.sr_res_team_job set edate = cast((select to_data ||' ' ||to_time from amb.md_ambulance_change where id = xcall_dt) as timestamp without time zone) where id = xbrg;

                                     execute amb.add_team_job_status_hist (xbrg,cast((select to_data ||' ' ||to_time from amb.md_ambulance_change where id = xcall_dt) as timestamp without time zone),7,xtransregistrator_id,'завершение работы',xuser);
                                /*2*/end if;

                                update amb.md_ambulance_call set call_number=xcall_num, call_dt=xcall_dt,call_kind_id=xcall_kind_id,call_type_id=xcall_type_id,
                                is_group_sufferer=xis_group_sufferer,sum_sufferer=xsum_sufferer,
                                from_time=xfrom_time,caller_reason_id=xcaller_reason_id,reason_diag=xreason_diag,reason_note=xreason_note,

                                call_place_id=xcall_place_id,call_place_note=xcall_place_note,place_org_id=xplace_org_id,place_department_id=xplace_department_id,
                                address_id=xaddress_id,house=xhouse,housing=xhousing,apartment=xapartment,porch=xporch,floor=xfloor,door_code=xdoor_code, --description=xdescription,
                                to_org_id=xto_org_id,to_department_id=xto_department_id,to_address_id=xto_address_id,to_house=xto_house,to_housing=xto_housing,
                                to_apartment=xto_apartment,to_porch=xto_porch,to_description=xto_description,
                                patient_id=xpatient_id,is_chronic=xis_chronic,age_years=xyears,age_months=xmonths,age_days=xdays,
                                phone_caller=xphone_caller,caller_id=xcaller_id,employee_id=xemployee_id,caller_note=xcaller_note,
                                priority_id=xpriority_id,priority=xpriority,control=xcontrol,note=xnote,registrator_id=xregistrator_id,
                                station_id=xstation_id,route_id=xroute_id,substation_id=xsubstation_id,brg_id=xbrg,emp_id=xemp_id where id = xid;

                                -- передан бригаде
                                --преобразование времени передачи в timestamp
                                --xtransmit_time time		-- передача
                                xtrans_time = case when xtransmit_time between cast('00:00' as time) and
                                                (select change_begin from amb.md_ambulance_change_setting where clinic_id = xstation_id and coalesce(department_id, 0) = coalesce(xsubstation_id, 0))
                                                or xfrom_time >= cast(cast(xfrom_dt + cast('1 day' as interval) as date)||' '|| cast('00:00' as time)  as timestamp without time zone)
                                            then cast(cast(xfrom_dt + cast('1 day' as interval) as date)||' '|| xtransmit_time  as timestamp without time zone)
                                            else cast(xfrom_dt ||' ' ||xtransmit_time  as timestamp without time zone)
                                            end;

                                xend_time = case when xto_time between cast('00:00' as time) and
                                                (select change_begin from amb.md_ambulance_change_setting where clinic_id = xstation_id and coalesce(department_id, 0) = coalesce(xsubstation_id, 0))
                                                or xfrom_time >= cast(cast(xfrom_dt + cast('1 day' as interval) as date)||' '|| cast('00:00' as time)  as timestamp without time zone)
                                            then cast(cast(xfrom_dt + cast('1 day' as interval) as date)||' '|| xto_time  as timestamp without time zone)
                                            else cast(xfrom_dt ||' ' ||xto_time  as timestamp without time zone)
                                            end;

                                -- отметки Гр., П, А
                                -- автодобавление отметок ! переменные
				execute amb.auto_add_call_note (xid, xcaller_reason_id, xreason_diag, xis_psycho, xis_alco, xregistrator_id, xplace_org_id, xplace_department_id, xaddress_id, xhouse);


                                xrendered =  (select srv_rendered_id from amb.md_ambulance_call_result where id = xid);

                                if xresDoc is not null
				      then
				      if xrelationshipdoc is not null
				        then
					   update public.sr_res_group_relationship set resource_id = xresDoc where id = xrelationshipdoc;
				        else
					  xrelationshipdoc :=nextval('sr_res_group_relationship_seq');
					  INSERT INTO public.sr_res_group_relationship (id,bdatetime,edatetime,resource_id,group_id,role_id)
					      VALUES (xrelationshipdoc,xtrans_time,xend_time,xresDoc,xgroup,(select id from sr_res_role where upper(code) = upper('DOCTOR')));
                                      end if;
			              if xres1 is not null
					    then
					    if xrelationshipres1 is not null
					      then
					      update public.sr_res_group_relationship set resource_id = xres1 where id = xrelationshipres1;
					      else
						xrelationshipres1 :=nextval('sr_res_group_relationship_seq');
						INSERT INTO public.sr_res_group_relationship (id,bdatetime,edatetime,resource_id,group_id,role_id)
						    VALUES (xrelationshipres1,xtrans_time,xend_time,xres1,xgroup,(select id from sr_res_role where upper(code) = upper('PARAMEDIC_ASST')));
					    end if;
					else
					   delete from public.sr_res_group_relationship where id = xrelationshipres1;
					end if;
					if xres2 is not null
					    then
					    if xrelationshipres2 is not null
					      then
					      update public.sr_res_group_relationship set resource_id = xres2 where id = xrelationshipres2;
					      else
						xrelationshipres2 :=nextval('sr_res_group_relationship_seq');
						INSERT INTO public.sr_res_group_relationship (id,bdatetime,edatetime,resource_id,group_id,role_id)
						    VALUES (xrelationshipres2,xtrans_time,xend_time,xres2,xgroup,(select id from sr_res_role where upper(code) = upper('PARAMEDIC_ASST')));
					    end if;
					else
					   delete from public.sr_res_group_relationship where id = xrelationshipres2;
					end if;


				      else
				        delete from public.sr_res_group_relationship where id = xrelationshipdoc;
					if xres1 is not null
					    then
					     if xrelationshipres1 is not null
					       then
					       update public.sr_res_group_relationship set resource_id = xres1 where id = xrelationshipres1;
					       else
						 xrelationshipres1 :=nextval('sr_res_group_relationship_seq');
						 INSERT INTO public.sr_res_group_relationship (id,bdatetime,edatetime,resource_id,group_id,role_id)
						   VALUES (xrelationshipres1,xtrans_time,xend_time,xres1,xgroup,(select id from sr_res_role where upper(code) = upper('PARAMEDIC')));
					      end if;
					      if xres2 is not null
						then
						 if xrelationshipres2 is not null
					           then
					           update public.sr_res_group_relationship set resource_id = xres2 where id = xrelationshipres2;
					         else
						    xrelationshipres2 :=nextval('sr_res_group_relationship_seq');
						    INSERT INTO public.sr_res_group_relationship (id,bdatetime,edatetime,resource_id,group_id,role_id)
							VALUES (xrelationshipres2,xtrans_time,xend_time,xres2,xgroup,(select id from sr_res_role where upper(code) = upper('PARAMEDIC_ASST')));
                                                 end if;
                                                 else
                                                   delete from public.sr_res_group_relationship where id = xrelationshipres2;
					      end if;
					    else
					        delete from public.sr_res_group_relationship where id = xrelationshipres1;
						if xres2 is not null
						  then
						    if xrelationshipres2 is not null
					              then
					              update public.sr_res_group_relationship set resource_id = xres2 where id = xrelationshipres2;
					             else
						      xrelationshipres2 :=nextval('sr_res_group_relationship_seq');
						      INSERT INTO public.sr_res_group_relationship (id,bdatetime,edatetime,resource_id,group_id,role_id)
							  VALUES (xrelationshipres2,xtrans_time,xend_time,xres2,xgroup,(select id from sr_res_role where upper(code) = upper('PARAMEDIC')));
                                                    end if;
                                                 else
                                                   delete from public.sr_res_group_relationship where id = xrelationshipres1;
						end if;
					end if;
				    end if;

                                 update amb.md_ambulance_call_result set
                                            out_delay_reason_id = xout_delay_reason_id,
                                            call_reason_id = xcall_reason_id,
                                            reason_accident_id = xreason_accident_id,
                                            citizenship_type_id = xcitizenship_type_id,
                                            condition_ns = xcondition_ns,
                                            nsdatatime = xnsdatatime,
                                            milage = xmilage,
                                            need_exit_through = xneed_exit_through,
                                            activ_visit_clinic_id = xactiv_visit_clinic_id,
                                            other_recommendations = xother_recommendations,
                                            registrator_id = xcardreg,
                                            take_birth_id = xtake_birth_id
                                            where id = xid;



                                  -- записываем диагнозы
                                xstage = (select id from mc_stage where e_code = '4');
                                xaccompstage = (select id from mc_stage where e_code = '3');
                                xmdiatype = (select id from mc_diagnosis_type where e_code = '1');
                                xaccompdiatype = (select id from mc_diagnosis_type where e_code = '2');
                                xdoctor := (select pep.id
                                    from pim_employee_position pep
                                    join pim_employee_position_resource pepr on pepr.employee_position_id = pep.id
                                    join sr_resource sr on sr.id = pepr.id
                                    join sr_res_group_relationship srgrel on srgrel.resource_id = sr.id
                                    join sr_res_group srg on srg.id = srgrel.group_id
                                    where srg.id = xgroup and sr.id = xresDoc limit 1);

                                if xmasterdiag is not null
                                    then
                                       if xmcdiag is not null
                                       then
                                         update public.mc_diagnosis set patient_id = xpatient_id, diagnos_id = xmasterdiag
                                            where id = xmcdiag;
                                       else
                                          xmcdiag = nextval('mc_diagnosis_seq');
                                          insert into public.mc_diagnosis(id,patient_id,case_id,step_id,is_main,stage_id,type_id,diagnos_id,disease_type_id,establishment_date,doctor_id,injury_reason_id)
                                            values (xmcdiag,xpatient_id,xcase,xstep,true,xstage,xmdiatype,xmasterdiag,xmdisease_type,xfrom_dt,xdoctor,xmaster_injury);
                                       end if;
                                    else
                                        delete from public.mc_diagnosis where id = xmcdiag;

                                end if;

                                if xaccompdiag is not null
                                    then
                                        if xaccompd is not null
                                        then
                                        update public.mc_diagnosis set patient_id = xpatient_id, diagnos_id = xaccompdiag
                                            where id = xaccompd;
                                        else
                                        xaccompd = nextval('mc_diagnosis_seq');
                                        insert into public.mc_diagnosis(id,patient_id,case_id,step_id,is_main,stage_id,type_id,diagnos_id,disease_type_id,establishment_date,doctor_id)
                                            values (xaccompd,xpatient_id,xcase,xstep,false,xaccompstage,xaccompdiatype,xaccompdiag,xaccompdisease_type,xfrom_dt,xdoctor);
                                        end if;
                                    else
                                        delete from public.mc_diagnosis where id = xaccompd;
                                end if;
                                --записи в случай (mc_case)
                                        --записи в услуга (sr_srv_rendered)
                                        update md_srv_rendered set diagnosis_id = xmasterdiag where id = xrendered;
                                    -- шаг

                               update mc_step set main_diagnosis_id = xmcdiag
                                        ,result_id = xresult_id
                                        ,death_date = xdeath_date, death_time = xdeath_time, death_employee_id = xdeathemp
                                        ,outcome_date = case when xoutdate is null then cast(xend_time as date) else xoutdate end,outcome_time = xouttime
                                        ,outcome_id = xout, outcome_clinic_id = xto_org_id
                                    where id = xstep;

                               update mc_case set main_diagnos_id = xmcdiag,time_gone_id = xtime_gone_id,transporting_type_id = xtransporting_type_id
                                    ,note = xcasenote,death_reason = xdeathres, death_reason_diagnosis_id = xdeathdiag
                                    where id = xcase;

                            return xid;
                          end;
$$;

