CREATE FUNCTION add_patient_main_data(xpatient integer, xmaritalstatus integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
                maritalStatusOld integer;
            begin
		        select ims.id into maritalStatusOld from pim_indiv_marital_status ims
                where ims.individual_id = xpatient and
                current_date between coalesce(ims.from_dt, '-infinity') and coalesce(ims.to_dt, 'infinity') limit 1;

                if (xmaritalStatus <> maritalStatusOld)
                then
			        update pim_indiv_marital_status
                        set to_dt = cast(current_date - cast('1 day' as interval) as date)
                        WHERE id in
                            (select pims.id
                            from pim_indiv_marital_status pims
                            WHERE pims.individual_id = xpatient
                                and pims.from_dt < current_date
                                and pims.to_dt is null);

			            if (xmaritalStatus is not null) then
                        insert into public.pim_indiv_marital_status (id, individual_id, status_id, from_dt)
                            values (nextval('public.pim_indiv_marital_status_seq'), xpatient, xmaritalStatus, current_date);
                        end if;
                end if;
                return xpatient;
            end;
$$;

