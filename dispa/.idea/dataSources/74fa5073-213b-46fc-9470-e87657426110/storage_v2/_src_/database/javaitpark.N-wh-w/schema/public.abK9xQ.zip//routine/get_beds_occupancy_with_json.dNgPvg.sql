CREATE FUNCTION get_beds_occupancy_with_json(in_org_id integer, in_degin_dt character varying, in_end_dt character varying, in_care_regimen_id integer, in_department_id integer, in_profile_id integer, in_bed_profile_id integer, in_patient_sex_id integer, OUT id bigint, OUT org_id integer, OUT org_name character varying, OUT care_regimen_id integer, OUT care_regimen_name character varying, OUT dep_id integer, OUT dep_name character varying, OUT profile_id integer, OUT profile_name character varying, OUT room_id integer, OUT room_name character varying, OUT bed_profile_id integer, OUT bed_profile_name character varying, OUT bed_id integer, OUT bed_name character varying, OUT booking_status character varying, OUT dates_json character varying)
  RETURNS SETOF record
LANGUAGE plpgsql
AS $$
begin
                return query
                with dates
                  as (
                      select to_date(in_degin_dt, 'dd.mm.yyyy') + interval '0 hours 0 minute 0 second' as from_dt,
                             to_date(in_end_dt, 'dd.mm.yyyy') + interval '23 hours 59 minute 59 second' as to_dt
                     ),
                      datesTbl
                  as (
                      select * from period_to_columns(in_degin_dt, in_end_dt)
                     ),
                    patients
                  as (
                      select o.id                  as org_id,
                             o.full_name           as org_name,
                             cr.id                 as care_regimen_id,
                             cr.name               as care_regimen_name,
                             d.id                  as dep_id,
                             d.name                as dep_name,
                             p.id                  as profile_id,
                             p.name                as profile_name,
                             r.id                  as room_id,
                             nullif(concat(nullif(regexp_replace(rt.name, '\s+$', ''), '') || ': ' || nullif(regexp_replace(r.name, '\s+$', ''), ''), ' (' || nullif(regexp_replace(left(g.name, 1), '\s+$', ''), '') || ')'), '')                as room_name,
                             bp.id                 as bed_profile_id,
                             bp.name               as bed_profile_name,
                             b.id                  as bed_id,
                             'Койка №' || nullif(regexp_replace(b.number, '\s+$', ''), '') as bed_name,
                             i.id as patient_id,
                             nullif(concat(initcap(i.surname), ' ' || upper(left(i.name, 1)) || '.', ' ' || upper(left(i.patr_name, 1)) || '.'), '') as patient_name,
                             i.gender_id as patient_sex_id,
                             s.admission_date,
                             coalesce(s.admission_time, '08:00:00'::time) as admission_time,
                             coalesce(s.outcome_date, coalesce(hr.issue_planned_date, s.admission_date)) as outcome_date,
                             coalesce(s.outcome_time, coalesce(s.admission_time, '08:00:00'::time) + interval '15 minutes') as outcome_time,
                             bs.name as booking_status
                      from pim_organization o
                        left join pim_department d on o.id = d.org_id
                                                   and in_department_id in (d.id, -1)
                        left join md_department_profile dp on d.id = dp.department_id
                        left join md_profile p on dp.profile_id = p.id
                                               and in_profile_id in (p.id, -1)
                        left join md_room_profile rp on p.id = rp.profile_id
                        left join pim_room r on rp.room_id = r.id
                                             and in_department_id in (r.department_id, -1)
                        left join pim_room_type rt on r.type_id = rt.id
                        left join pim_gender g on r.gender_id = g.id
                        left join md_bed b on r.id = b.room_id
                                           and in_care_regimen_id in (b.regimen_id, -1)
                        left join mc_care_regimen cr on b.regimen_id = cr.id
                        left join md_bed_profile bp on b.bed_profile_id = bp.id
                                                    and in_bed_profile_id in (bp.id, -1)
                        left join md_bed_resource br on b.id = br.bed_id
                        left join sr_resource res on br.id = res.id
                        left join sr_res_group_relationship rg_rel on res.id = rg_rel.resource_id
                        left join mc_step s on rg_rel.group_id = s.res_group_id
                        left join mc_case c on s.case_id = c.id
                                               and o.id = c.clinic_id
                        left join hsp_record hr on s.id = hr.id
                        left join dates dat on true
                        left join pim_individual i on c.patient_id = i.id
                                              and in_patient_sex_id in (i.gender_id, -1)
                        left join hospital.booking bo on c.id = bo.id
                        left join hospital.booking_status bs on bo.status_id = bs.id
                      where (s.admission_date <= coalesce(s.outcome_date, coalesce(hr.issue_planned_date, s.admission_date))
                        and daterange(s.admission_date, coalesce(s.outcome_date, coalesce(hr.issue_planned_date, s.admission_date)), '[]') && daterange(dat.from_dt::date, dat.to_dt::date, '[]')
                          or  s.admission_date is null and coalesce(s.outcome_date, coalesce(hr.issue_planned_date, s.admission_date)) is null)
                        and o.id = in_org_id
                        and cr.id is not null
                        and d.id is not null
                        and p.id is not null
                        and p.id is not null
                        and b.id is not null
                     ),
                       patients_at_date
                  as (
                      select row_number() over() as id,
                        p.org_id,
                        p.org_name,
                        p.care_regimen_id,
                        p.care_regimen_name,
                        p.dep_id,
                        p.dep_name,
                        p.profile_id,
                        p.profile_name,
                        p.room_id,
                        p.room_name,
                        p.bed_profile_id,
                        p.bed_profile_name,
                        p.bed_id,
                        p.bed_name,
                        p.booking_status,
                        json_agg(case when to_date(dt.date1, 'dd.mm.yyyy') <@ daterange(p.admission_date, p.outcome_date, '[]') then json_object(concat('{type, ', coalesce(p.booking_status, 'empty'), ', label, ', coalesce(p.patient_name, 'free'), '}')::text[]) end) as date1,
                        json_agg(case when to_date(dt.date2, 'dd.mm.yyyy') <@ daterange(p.admission_date, p.outcome_date, '[]') then json_object(concat('{type, ', coalesce(p.booking_status, 'empty'), ', label, ', coalesce(p.patient_name, 'free'), '}')::text[]) end) as date2,
                        json_agg(case when to_date(dt.date3, 'dd.mm.yyyy') <@ daterange(p.admission_date, p.outcome_date, '[]') then json_object(concat('{type, ', coalesce(p.booking_status, 'empty'), ', label, ', coalesce(p.patient_name, 'free'), '}')::text[]) end) as date3,
                        json_agg(case when to_date(dt.date4, 'dd.mm.yyyy') <@ daterange(p.admission_date, p.outcome_date, '[]') then json_object(concat('{type, ', coalesce(p.booking_status, 'empty'), ', label, ', coalesce(p.patient_name, 'free'), '}')::text[]) end) as date4,
                        json_agg(case when to_date(dt.date5, 'dd.mm.yyyy') <@ daterange(p.admission_date, p.outcome_date, '[]') then json_object(concat('{type, ', coalesce(p.booking_status, 'empty'), ', label, ', coalesce(p.patient_name, 'free'), '}')::text[]) end) as date5,
                        json_agg(case when to_date(dt.date6, 'dd.mm.yyyy') <@ daterange(p.admission_date, p.outcome_date, '[]') then json_object(concat('{type, ', coalesce(p.booking_status, 'empty'), ', label, ', coalesce(p.patient_name, 'free'), '}')::text[]) end) as date6,
                        json_agg(case when to_date(dt.date7, 'dd.mm.yyyy') <@ daterange(p.admission_date, p.outcome_date, '[]') then json_object(concat('{type, ', coalesce(p.booking_status, 'empty'), ', label, ', coalesce(p.patient_name, 'free'), '}')::text[]) end) as date7,
                        json_agg(case when to_date(dt.date8, 'dd.mm.yyyy') <@ daterange(p.admission_date, p.outcome_date, '[]') then json_object(concat('{type, ', coalesce(p.booking_status, 'empty'), ', label, ', coalesce(p.patient_name, 'free'), '}')::text[]) end) as date8,
                        json_agg(case when to_date(dt.date9, 'dd.mm.yyyy') <@ daterange(p.admission_date, p.outcome_date, '[]') then json_object(concat('{type, ', coalesce(p.booking_status, 'empty'), ', label, ', coalesce(p.patient_name, 'free'), '}')::text[]) end) as date9,
                        json_agg(case when to_date(dt.date10, 'dd.mm.yyyy') <@ daterange(p.admission_date, p.outcome_date, '[]') then json_object(concat('{type, ',coalesce(p.booking_status, 'empty'), ', label, ', coalesce(p.patient_name, 'free'), '}')::text[]) end) as date10,
                        json_agg(case when to_date(dt.date11, 'dd.mm.yyyy') <@ daterange(p.admission_date, p.outcome_date, '[]') then json_object(concat('{type, ', coalesce(p.booking_status, 'empty'), ', label, ', coalesce(p.patient_name, 'free'), '}')::text[]) end) as date11,
                        json_agg(case when to_date(dt.date12, 'dd.mm.yyyy') <@ daterange(p.admission_date, p.outcome_date, '[]') then json_object(concat('{type, ', coalesce(p.booking_status, 'empty'), ', label, ', coalesce(p.patient_name, 'free'), '}')::text[]) end) as date12,
                        json_agg(case when to_date(dt.date13, 'dd.mm.yyyy') <@ daterange(p.admission_date, p.outcome_date, '[]') then json_object(concat('{type, ', coalesce(p.booking_status, 'empty'), ', label, ', coalesce(p.patient_name, 'free'), '}')::text[]) end) as date13,
                        json_agg(case when to_date(dt.date14, 'dd.mm.yyyy') <@ daterange(p.admission_date, p.outcome_date, '[]') then json_object(concat('{type, ', coalesce(p.booking_status, 'empty'), ', label, ', coalesce(p.patient_name, 'free'), '}')::text[]) end) as date14
                      from patients p
                        left join datesTbl dt on true
                      group by p.org_id, p.org_name, p.care_regimen_id, p.care_regimen_name, p.dep_id, p.dep_name, p.profile_id, p.profile_name, p.room_id, p.room_name, p.bed_profile_id, p.bed_profile_name, p.bed_id, p.bed_name, p.booking_status
                  ),-- select * from patients_at_date
                    date_state_json
                  as (
                      select
                        dad.id,
                        dad.org_id,
                        dad.org_name,
                        dad.care_regimen_id,
                        dad.care_regimen_name,
                        dad.dep_id,
                        dad.dep_name,
                        dad.profile_id,
                        dad.profile_name::character varying,
                        dad.room_id,
                        dad.room_name::character varying,
                        dad.bed_profile_id,
                        dad.bed_profile_name,
                        dad.bed_id,
                        dad.bed_name::character varying,
                        dad.booking_status,
                        json_build_array(json_build_object('date', dt.date1, 'state', dad.date1),
                                       json_build_object('date', dt.date2, 'state', dad.date2),
                                       json_build_object('date', dt.date3, 'state', dad.date3),
                                       json_build_object('date', dt.date4, 'state', dad.date4),
                                       json_build_object('date', dt.date5, 'state', dad.date5),
                                       json_build_object('date', dt.date6, 'state', dad.date6),
                                       json_build_object('date', dt.date7, 'state', dad.date7),
                                       json_build_object('date', dt.date8, 'state', dad.date8),
                                       json_build_object('date', dt.date9, 'state', dad.date9),
                                       json_build_object('date', dt.date10, 'state', dad.date10),
                                       json_build_object('date', dt.date11, 'state', dad.date11),
                                       json_build_object('date', dt.date12, 'state', dad.date12),
                                       json_build_object('date', dt.date13, 'state', dad.date13),
                                       json_build_object('date', dt.date14, 'state', dad.date14))::character varying as dates_json

                      from patients_at_date dad
                        join datesTbl dt on true
                  ) select * from date_state_json;
                end;
$$;

