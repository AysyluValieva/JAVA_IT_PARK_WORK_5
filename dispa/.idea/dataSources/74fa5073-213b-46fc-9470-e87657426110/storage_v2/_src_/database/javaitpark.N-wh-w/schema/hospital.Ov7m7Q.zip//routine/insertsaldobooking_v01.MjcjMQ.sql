CREATE FUNCTION insertsaldobooking_v01(p_begin_date date, p_end_date date, p_case_id integer DEFAULT NULL::integer, p_step_id integer DEFAULT NULL::integer, p_sr_res_group_relationship_id integer DEFAULT NULL::integer)
  RETURNS text
LANGUAGE plpgsql
AS $$
DECLARE
    rez            text;
BEGIN
    -- функция для перехода на booking: формируем записи "занято" и "бронь не подтверждена"
    -- если будет передан хоть 1 параметр p_case_id, p_step_id, p_sr_res_group_relationship_id то смотрим только по этому значению, даты тогда считаются c -infinity по infinity
    WITH    param(
            in_degin_dt,
            in_end_dt,
            in_case_id,
            in_step_id,
            in_sr_res_group_relationship_id
        ) AS (
        VALUES (
            case when coalesce(p_case_id, p_step_id, p_sr_res_group_relationship_id) is not null then '-infinity'::TIMESTAMP else coalesce(p_begin_date, now()) :: DATE + INTERVAL '0 hours 0 minute 0 second' end,
            case when coalesce(p_case_id, p_step_id, p_sr_res_group_relationship_id) is not null then 'infinity'::TIMESTAMP else coalesce(p_end_date, 'infinity'):: DATE + INTERVAL '23 hours 59 minute 59 second' end,
            nullif(p_case_id, -1),
            nullif(p_step_id, -1),
            nullif(p_sr_res_group_relationship_id, -1)
            )
        ),
        palat AS (
        SELECT
            o.ID AS org_id,
            o.full_name AS org_name,
            cr.ID AS care_regimen_id,
            cr.NAME AS care_regimen_name,
            d.ID AS dep_id,
            d.NAME AS dep_name,
            P.ID AS profile_id,
            P.NAME AS profile_name,
            room.ID AS room_id,
            nullif(concat(nullif(regexp_replace(rt.name, '\s+$', ''), '') || ': ' ||
                          nullif(regexp_replace(pr.name, '\s+$', ''), ''),
                          ' (' || nullif(regexp_replace(left(g.name, 1), '\s+$', ''), '') || ')'),
                   '') AS room_name,            bp.ID AS bed_profile_id,
            bp.NAME AS bed_profile_name,
            b.ID AS bed_id,
            --coalesce(b.count_shift, 4) AS bed_count_shift,
            -- общее количество смен согласно настройке
            coalesce(('Койка №' || nullif(regexp_replace(b.number, '\s+$', ''), '')),
                      'койка без названия') AS bed_name
        FROM
            param
            JOIN md_bed_resource r ON TRUE
            INNER JOIN md_bed b ON r.bed_id = b.ID
            JOIN md_room room ON b.room_id = room.ID
            LEFT JOIN mc_care_regimen cr ON b.regimen_id = cr.ID
            LEFT OUTER JOIN md_room_profile rp ON rp.room_id = room.ID
            LEFT OUTER JOIN pim_room pr ON pr.ID = rp.room_id
            LEFT OUTER JOIN pim_room_type rt ON pr.type_id = rt.ID
            LEFT OUTER JOIN pim_gender G ON pr.gender_id = G.ID
            LEFT OUTER JOIN pim_department d ON d.ID = pr.department_id
            LEFT OUTER JOIN pim_organization o ON o.ID = d.org_id
            LEFT OUTER JOIN md_bed_profile bp ON bp.ID = b.bed_profile_id
            LEFT JOIN md_profile P ON rp.profile_id = P.ID
        WHERE
            TRUE --o.id = coalesce(nullif(param.in_org_id, -1), o.id)
        --AND b.regimen_id = coalesce(nullif(param.in_care_regimen_id, -1), b.regimen_id)
        --AND pr.department_id = coalesce(nullif(param.in_department_id, -1), pr.department_id)
        --AND p.id = coalesce(nullif(param.in_profile_id, -1), p.id)
        --AND bp.id = coalesce(nullif(param.in_bed_profile_id, -1), bp.id)
        --AND coalesce(g.id, -1) = coalesce(nullif(param.in_patient_sex_id, -1), g.id, -1)
    ),
    beddays as ( -- для генератора не будем проваливаться до уровня поликлиники, определим первое дефолтное значение
                 SELECT cmn_sv.VALUE::INT AS avgBedDays
                 FROM cmn_setting_value cmn_sv JOIN cmn_scope cmn_s ON cmn_sv.scope_id = cmn_s.ID
                     --join cmn_scope_type cmn_st on cmn_st.id = cmn_s.type_id
                     LEFT JOIN LATERAL (SELECT mdc.ID FROM md_clinic mdc WHERE /*mdc.id = in_org_id and*/ cmn_s.type_id = 2 AND mdc.scope_id = cmn_s.ID ) mdc ON TRUE
                 WHERE
                     cmn_sv.setting_id = 'cz.atria.medcase.ui.MedicalCaseUISettings.avgBedDays'
                 ORDER BY
                     mdc.ID DESC NULLS FIRST -- если есть дефолт значение в автомат. заполнении то смотрим дефолтное значение
               LIMIT 1
    ),
    w_hsp_record AS (
        SELECT
            hh.s_ID as step_id,
            rgrel.id as rgrel_id,
            null::int as reservation_id,
            br.bed_id,
            hh.s_admission_date,
            hh.h_outcome_date,
            'busy',
            1
        FROM param
			LEFT JOIN beddays ON TRUE
            JOIN LATERAL (
                 SELECT s.id as s_id,
                        s.res_group_id as s_res_group_id,
                        s.admission_date as s_admission_date,
                        h.outcome_date as h_outcome_date
                 FROM
                     hsp_record hr
                     JOIN mc_step s ON s.ID = hr.ID
                     JOIN LATERAL (
                          SELECT
                              s.admission_date,
                              --coalesce(s.admission_time, '00:00:00' :: TIME) ::time without time zone  AS admission_time,
                              COALESCE(
                                  s.outcome_date,
                                  hr.issue_planned_date,
                                  s.admission_date + COALESCE(beddays.avgBedDays - 1, 0)
                              ) AS outcome_date
                     ) h ON TRUE
                 WHERE  hr.id = coalesce(in_step_id, hr.id)
                        and hr.issue_planned_date between param.in_degin_dt and param.in_end_dt
                        and s.case_id = coalesce(in_case_id, s.case_id)
												--h.outcome_date BETWEEN param.in_degin_dt AND param.in_end_dt
				 UNION	-- приходится разбивать на union: отдельно собираем все hr где дата явно попадает в диапазон, и отдельно все посещения с расчетной датой закрытия
                 SELECT s.id as s_id,
                        s.res_group_id as s_res_group_id,
                        s.admission_date as s_admission_date,
                        h.outcome_date as h_outcome_date
                 FROM
                     mc_step s
					 JOIN hsp_record hr ON s.ID = hr.ID--hr.issue_planned_date between param.in_degin_dt and param.in_end_dt
                     JOIN LATERAL (
                          SELECT
                              s.admission_date,
                              --coalesce(s.admission_time, '00:00:00' :: TIME) ::time without time zone  AS admission_time,
                              COALESCE(
                                  s.outcome_date,
                                  hr.issue_planned_date,
                                  s.admission_date + COALESCE(beddays.avgBedDays - 1, 0)
                              ) AS outcome_date
                     ) h ON TRUE
                 WHERE
                     s.case_id = coalesce(in_case_id, s.case_id)
                     and s.id = coalesce(in_step_id, s.id)
                     and COALESCE(s.outcome_date, s.admission_date + COALESCE(beddays.avgBedDays - 1, 0)) BETWEEN param.in_degin_dt AND param.in_end_dt
                 ) hh ON TRUE
            JOIN LATERAL (
                 SELECT rgrel.id, rgrel.resource_id
                 FROM sr_res_role r join sr_res_group_relationship rgrel on rgrel.id = coalesce(in_sr_res_group_relationship_id, rgrel.id) and rgrel.role_id = r.id AND rgrel.group_id = hh.s_res_group_id
                 WHERE r.code = 'BED'
                 LIMIT 100
            ) rgrel ON TRUE
            JOIN sr_resource res ON res.ID = rgrel.resource_id
            JOIN md_bed_resource br ON br.ID = res.ID
            --bbr.id = res.id --.id = br.bed_id
            JOIN palat ON palat.bed_id = br.bed_id
        where hh.h_outcome_date BETWEEN param.in_degin_dt AND param.in_end_dt
    ),
    -- так же пройдемся по всем записям которых нет в sr_res_group_relationship и запишем их в неподтвержденные брони
    w_hsp_record_unconf AS (
        SELECT
            null::int as step_id,
            null::int as rgel_id,
            hsr.id as reservation_id,
            b.id as bed_id,
            h.planned_date_from,
            h.planned_date_to,
            'unconf',
            1
        --hsr.id, hsr.bed_profile_id, mref.step_id, b.*
        FROM param
            LEFT JOIN beddays ON TRUE
            JOIN hsp_reservation hsr ON TRUE--ON hsr.id = bo.reservation_id --and  = bp.id
            left join lateral (select h_s.planned_date_to from hospital.reservation__status h_s where h_s.reservation_id = hsr.id order by h_s.begin_dt desc limit 1) h_s on TRUE
            JOIN LATERAL (
                          SELECT
                              hsr.planned_date_from::date as planned_date_from,
                              COALESCE(
                                  h_s.planned_date_to::date,
                                  hsr.planned_date_from::date + COALESCE(beddays.avgBedDays - 1, 0)
                              ) AS planned_date_to
                     ) h ON TRUE
            JOIN md_referral mref ON mref.id = hsr.referral_id
            JOIN md_bed_profile bp ON bp.id = hsr.bed_profile_id
            JOIN md_bed b ON b.bed_profile_id = bp.id
            left join LATERAL (select w.step_id from w_hsp_record w where w.step_id = mref.step_id)s on true
            left join LATERAL (select TRUE as is_hsp_record from hsp_record h where h.id = mref.step_id union all select TRUE where mref.step_id is null limit 1)ss on true
        where s.step_id is NULL
            and ss.is_hsp_record = TRUE
            and h.planned_date_to BETWEEN param.in_degin_dt AND param.in_end_dt
            and coalesce(in_case_id, in_step_id, in_sr_res_group_relationship_id) is null -- заполняем в том случае если нет явных ИД
    ),
--select * from mc_step s join hsp_record h on s.id = h.id where s.id = 960884
--select * from hsp_reservation
    b_ins AS (
        INSERT INTO hospital.booking (step_id, rg_rel_id, bed_id, reservation_id, status_id, status_date, begin_dt, end_dt, iscurrent)
            SELECT
                step_id,
                rgrel_id,
                bed_id,
                228,
                2,
                now() :: DATE,
                s_admission_date::DATE,
                h_outcome_date::DATE,
                true
            FROM w_hsp_record w
            WHERE not exists(select true from hospital.booking b where w.step_id = b.step_id and w.bed_id = b.bed_id and b.begin_dt = w.s_admission_date)
        RETURNING *),
        b_shift_ins AS (INSERT INTO hospital.booking_shift (booking_id, count_shift, dt)
        SELECT
            bi.id,
            1,
            b.b
        FROM b_ins bi
            JOIN LATERAL (SELECT b
                          FROM generate_series(bi.begin_dt :: DATE, bi.end_dt :: DATE, '1 day') b ) b ON TRUE
    RETURNING *
    ),
    b_ins_uncof AS (
        INSERT INTO hospital.booking (step_id, rg_rel_id, bed_id, reservation_id, status_id, status_date, begin_dt, end_dt, iscurrent)
            SELECT
                step_id,
                rgel_id,
                bed_id,
                reservation_id,
                2,
                now() :: DATE,
                planned_date_from::DATE,
                planned_date_to::DATE,
                TRUE
            FROM w_hsp_record_unconf w
            WHERE not exists(select true from hospital.booking b where w.reservation_id = b.reservation_id and w.bed_id = b.bed_id and b.begin_dt = w.planned_date_from)
        RETURNING *),
        b_shift_ins_uncof AS (INSERT INTO hospital.booking_shift (booking_id, count_shift, dt)
        SELECT
            bi.id,
            1,
            b.b
        FROM b_ins_uncof bi
            JOIN LATERAL (SELECT b
                          FROM generate_series(bi.begin_dt :: DATE, bi.end_dt :: DATE, '1 day') b ) b ON TRUE
    RETURNING *
    )
    select format('Генерация данных прошла успешно, было сформировано:
            %s записей "занято" (по всем броням всего %s койкосмен);
            %s записей "бронь неподтверждена" (по всем броням всего %s койкосмен);',b_ins, b_shift_ins, b_ins_uncof, b_shift_ins_uncof) into rez
    FROM (values(1))ttt
    left join (select count(*) from b_ins)b_ins on true
    left join (select count(*) from b_shift_ins)b_shift_ins on true
    left join (select count(*) from b_ins_uncof)b_ins_uncof on true
    left join (select count(*) from b_shift_ins_uncof)b_shift_ins_uncof on true
    ;
    RETURN rez;
END;
$$;

