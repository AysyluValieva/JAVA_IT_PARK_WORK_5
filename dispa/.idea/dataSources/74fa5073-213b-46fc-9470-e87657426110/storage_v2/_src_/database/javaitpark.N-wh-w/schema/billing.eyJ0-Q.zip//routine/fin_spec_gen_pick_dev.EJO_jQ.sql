CREATE FUNCTION fin_spec_gen_pick_dev(p1_bill_id integer, p2_status_text text)
  RETURNS void
STRICT
LANGUAGE plpgsql
AS $$
DECLARE 
    _is_log BOOLEAN:=TRUE;
    /*-----------------------------*/
	_main_bill_id INTEGER:=public.fin_bill__get_main_bill (p1_bill_id); 
    _clinic_id INTEGER;
    _from_date DATE;
    _to_date DATE;
    _price_list_id INTEGER;
    _case_type_arr INTEGER[];
    _payment_method_arr INTEGER[];
    _care_regimen_arr INTEGER[];
    _case_init_goal_arr INTEGER[];
    _case_level_arr INTEGER[];
    _case_id_arr INTEGER[];
    _from_date_bill DATE;
    _financing_type_id INTEGER;
    _bill_main_type INTEGER;
    _mek_error_case_arr INTEGER[];
    _bill_type text:=billing.kurgan_fin_get_type_bill(p1_bill_id);
BEGIN

    /*
        current version date 01.07.2016
       
    */
    --SET temp_buffers = '40960';
    CREATE TEMP TABLE tmp_fin_bill_generate (LIKE billing.fin_bill_generate INCLUDING DEFAULTS INCLUDING CONSTRAINTS) 	
	           ON COMMIT PRESERVE ROWS;
    ALTER TABLE tmp_fin_bill_generate ADD mc_case_funding_id INT4;
    CREATE UNIQUE INDEX tt_fbg_id_bill_id ON tmp_fin_bill_generate (id);

    --------------------------------------------------очистка от предыдущего формирования------------------------------------------------------------
    IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_spec_gen_pick11. Начало. tmp_table_version.'); END IF; 
    /*
    IF 
        p2_status_text IN ('VALIDATE', 'RECALCULATE')
    THEN  
      WITH t AS 
        (
            (
              SELECT spec_item_id AS id 
              FROM billing.fin_bill_steps  
              WHERE bill_id = p1_bill_id 
            )
            EXCEPT ALL
            (
              SELECT id 
              FROM public.fin_bill_spec_item  
              WHERE bill_id = p1_bill_id
            )  
                
        )
        DELETE FROM billing.fin_bill_steps AS s USING t WHERE s.bill_id = p1_bill_id AND s.spec_item_id = t.id
        
        ;
        
     END IF;
     */
    /*убрать?*/
    IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_spec_gen_pick11. Конец'); END IF; 
	
	    --------------------------------------------------очистка от предыдущего формирования------------------------------------------------------------
    IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_spec_gen_pick12. Начало'); END IF; 
   
    --DELETE FROM billing.fin_bill_generate WHERE bill_id = p1_bill_id ;
  
    IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_spec_gen_pick12. Конец. No action.'); END IF; 
	
    IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_spec_gen_pick13. Начало'); END IF; 
  
    --DELETE FROM fin_bill_spec_item WHERE bill_id = p1_bill_id;
    
    IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_spec_gen_pick13. Конец.No action.'); END IF; 

/*-2-*/	
    IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_spec_gen_pick2. Начало'); END IF; 
    
     
    IF
        p2_status_text = 'CORRECT'
    THEN
        SELECT 
            m.from_date, m.to_date, m.clinic_id, m.price_list_id, m.financing_type_id
            INTO 
            _from_date, _to_date, _clinic_id, _price_list_id, _financing_type_id
        FROM
            public.fin_bill_main m
           
        WHERE
            m.id = _main_bill_id       
        ;
    ELSIF
        p2_status_text IN ('GENERATE', 'VALIDATE')
    THEN
      
        SELECT 
            coalesce (a.from_date, m.from_date), coalesce (a.to_date, m.to_date), m.clinic_id, m.price_list_id, m.financing_type_id
            INTO 
            _from_date, _to_date, _clinic_id, _price_list_id, _financing_type_id
        FROM
            public.fin_bill_main m            
            LEFT JOIN public.fin_bill_additional AS a ON m.id = a.base_id AND a.id = p1_bill_id
        WHERE
            m.id = _main_bill_id        
        ;
        
        IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_spec_gen_pick2. 0'); END IF; 
        
        --определяем 20 число предыдущего месяца 
        IF _bill_type='app' THEN 
            IF (to_char(_to_date,'MM')<>'01') THEN 
                _from_date_bill := to_date('20.'||(to_number(to_char(_to_date,'MM'),'99')-1)||'.'||to_char(_to_date,'YYYY'),'DD.MM.YYYY');
            ELSE
                _from_date_bill := to_date('20.12.'||(to_number(to_char(_to_date,'YYYY'),'9999')-1),'DD.MM.YYYY'); 
            END IF;      
        ELSE
            _from_date_bill:=_from_date;
        END IF;
        
    END IF;

    IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_spec_gen_pick2. 1'); END IF; 
    
    SELECT type_id INTO _bill_main_type FROM public.fin_bill_main WHERE id = p1_bill_id; --получаем тип счета
    
    -------------------------------------------------режим лечения, способ оплаты, цель посещения, тип случая, уровень мп------------------------------    
    IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_spec_gen_pick2. 2'); END IF; 
    _care_regimen_arr   := ARRAY (SELECT care_regimen_id   FROM public.fin_bill_main_type_to_care_regimen   WHERE main_bill_type_id = _bill_main_type);
    
    IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_spec_gen_pick2. 3'); END IF; 
    _payment_method_arr := ARRAY (SELECT payment_method_id FROM public.fin_bill_main_type_to_payment_method WHERE main_bill_type_id = _bill_main_type);
    
    IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_spec_gen_pick2. 4'); END IF; 
    _case_init_goal_arr := ARRAY (SELECT case_init_goal_id FROM public.fin_bill_main_type_to_case_init_goal WHERE main_bill_type_id = _bill_main_type);
    
    IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_spec_gen_pick2. 5'); END IF; 
    _case_type_arr      := ARRAY (SELECT case_type_id      FROM public.fin_bill_main_type_to_case_type      WHERE main_bill_type_id = _bill_main_type);
    
    IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_spec_gen_pick2. 6'); END IF; 
    _case_level_arr     := ARRAY (SELECT care_level_id     FROM public.fin_bill_main_type_to_care_level     WHERE main_bill_type_id = _bill_main_type);
    
    IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_spec_gen_pick2. 7'); END IF; 
    _mek_error_case_arr := billing.fin_get_case_after_mek_error_correct(p1_bill_id);
    -----------------------------------------------------------первичное добавление------------------------------------------------------------------

    IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_spec_gen_pick2. 8'); END IF; 
    IF 
        p2_status_text IN ('GENERATE')
    THEN
        INSERT INTO tmp_fin_bill_generate 
        (
            id, bdate, edate, service_id, comment, tooth_number, funding_id, step_id, res_group_id, rdd_diagnosis_id,
            case_id, case_type_id, closing_step_id, case_open_date, case_close_date, care_regimen_id, provision_condition_id, init_goal_id, patient_id, 
            org_id,  
            bill_id, price_list_id, from_date, to_date, contract_id, region_data
			,mc_case_funding_id
        )
            SELECT
                s.id, s.bdate, CASE WHEN s.edate<s.bdate THEN s.bdate ELSE s.edate END, s.service_id, s.comment, s.tooth_number, coalesce (s.funding_id, c.funding_id, 0), m.step_id, s.res_group_id, m.diagnosis_id,
                c.id, c.case_type_id, c.closing_step_id, c.open_date, c.close_date, c.care_regimen_id, c.provision_condition_id, c.init_goal_id, c.patient_id, 
                coalesce (s.org_id, c.clinic_id), 
                p1_bill_id, _price_list_id, _from_date, _to_date, s.contract_id,                
                hstore('pr_nov','0') as region_data
				,c.funding_id
            FROM
                public.mc_case               AS c 
                JOIN public.md_srv_rendered  AS m ON m.case_id = c.id 
                JOIN public.sr_srv_rendered  AS s ON m.id = s.id AND NOT EXISTS (SELECT 1 FROM public.fin_bill_spec_item WHERE service_id = m.id AND bill_id <> p1_bill_id AND NOT is_deleted)
            WHERE
                 c.close_date BETWEEN _from_date_bill AND _to_date
                AND c.closing_step_id IS NOT NULL
                AND c.clinic_id = _clinic_id
                AND (c.id <> ANY (_mek_error_case_arr) AND array_length (_mek_error_case_arr, 1) IS NOT NULL OR array_length (_mek_error_case_arr, 1) IS NULL)
                AND CASE WHEN array_length (_case_type_arr     , 1) IS NOT NULL THEN c.case_type_id      = ANY (_case_type_arr)      ELSE TRUE END
                AND CASE WHEN array_length (_care_regimen_arr  , 1) IS NOT NULL THEN c.care_regimen_id   = ANY (_care_regimen_arr)   ELSE TRUE END
                AND CASE WHEN array_length (_payment_method_arr, 1) IS NOT NULL THEN c.payment_method_id = ANY (_payment_method_arr) ELSE TRUE END
                AND CASE WHEN array_length (_case_init_goal_arr, 1) IS NOT NULL THEN c.init_goal_id      = ANY (_case_init_goal_arr) ELSE TRUE END
                AND CASE WHEN array_length (_case_level_arr    , 1) IS NOT NULL THEN c.care_level_id     = ANY (_case_level_arr)     ELSE TRUE END
     
           ;
           
           INSERT INTO tmp_fin_bill_generate 
        (
            id, bdate, edate, service_id, comment, tooth_number, funding_id, step_id, res_group_id, rdd_diagnosis_id,
            case_id, case_type_id, closing_step_id, case_open_date, case_close_date, care_regimen_id, provision_condition_id, init_goal_id, patient_id, 
            org_id,  
            bill_id, price_list_id, from_date, to_date, contract_id, region_data
			,mc_case_funding_id
        )
        --добавляем случаи из предыдущего отчета попавшие под санкции МЭК
           
           SELECT
                s.id, s.bdate, CASE WHEN s.edate<s.bdate THEN s.bdate ELSE s.edate END, s.service_id, '', s.tooth_number, coalesce (s.funding_id, c.funding_id, 0), m.step_id, s.res_group_id, m.diagnosis_id,
                c.id, c.case_type_id, c.closing_step_id, c.open_date, c.close_date, c.care_regimen_id, c.provision_condition_id, c.init_goal_id, c.patient_id, 
                coalesce (s.org_id, c.clinic_id), 
                p1_bill_id, _price_list_id, _from_date, _to_date, s.contract_id,                
                hstore('pr_nov','1') as region_data
				,c.funding_id
            FROM
                public.mc_case               AS c 
                JOIN public.md_srv_rendered  AS m ON m.case_id = c.id 
                JOIN public.sr_srv_rendered  AS s ON m.id = s.id
            WHERE c.id = ANY (_mek_error_case_arr)                     
                
        ;
    ELSIF
        p2_status_text = 'VALIDATE' THEN
        INSERT INTO tmp_fin_bill_generate 
          (
            id, bdate, edate, service_id, comment, tooth_number, funding_id, step_id, res_group_id, rdd_diagnosis_id,
            case_id, case_type_id, closing_step_id, case_open_date, case_close_date, care_regimen_id, provision_condition_id, init_goal_id, patient_id, 
            org_id,  
            bill_id, price_list_id, from_date, to_date, contract_id, region_data
			,mc_case_funding_id
           )
            SELECT
                s.id, s.bdate, CASE WHEN s.edate<s.bdate THEN s.bdate ELSE s.edate END, s.service_id, s.comment, s.tooth_number, coalesce (s.funding_id, c.funding_id, 0), m.step_id, s.res_group_id, m.diagnosis_id,
                c.id, c.case_type_id, c.closing_step_id, c.open_date, c.close_date, c.care_regimen_id, c.provision_condition_id, c.init_goal_id, c.patient_id, 
                coalesce (s.org_id, c.clinic_id), 
                p1_bill_id, _price_list_id, _from_date, _to_date, s.contract_id,                
                hstore('pr_nov',f.region_data -> 'pr_nov') as region_data 
				,c.funding_id
            FROM
                --(SELECT srv_rendered_id, region_data->'pr_nov' as pr_nov FROM billing.fin_bill_steps WHERE bill_id=p1_bill_id ) AS f 
                billing.fin_bill_steps AS f 
		JOIN public.sr_srv_rendered AS s ON s.id = f.srv_rendered_id    
		JOIN public.md_srv_rendered AS m ON m.id = s.id
		JOIN public.mc_case AS c ON c.id = m.case_id 
            WHERE 1=1
		AND f.bill_id = p1_bill_id
		AND EXISTS(SELECT 1 FROM fin_bill_spec_item i WHERE i.id = f.spec_item_id)
         ;
       
    ELSIF
        p2_status_text = 'CORRECT'      
    THEN
        UPDATE public.fin_bill_spec_item_returned AS r
        SET 
            correctional_bill_id = p1_bill_id
        WHERE
            EXISTS (SELECT 1 FROM public.fin_bill_spec_item WHERE id = r.id AND bill_id = _main_bill_id) AND r.correctional_bill_id IS NULL
        ;
        INSERT INTO tmp_fin_bill_generate 
        (
            id, bdate, edate, service_id, comment, tooth_number, funding_id, step_id, res_group_id, rdd_diagnosis_id,
            case_id, case_type_id, closing_step_id, case_open_date, case_close_date, care_regimen_id, provision_condition_id, init_goal_id, patient_id, 
            org_id, 
            bill_id, price_list_id, from_date, to_date, contract_id, 
			mc_case_funding_id
        )
            SELECT
                f.id, f.bdate, f.edate, f.service_id, f.comment, f.tooth_number, f.funding_id, f.step_id, f.res_group_id, f.rdd_diagnosis_id,
                f.case_id, f.case_type_id, f.closing_step_id, f.case_open_date, f.case_close_date, f.care_regimen_id, f.provision_condition_id, f.init_goal_id, f.patient_id, 
                f.org_id, 
                p1_bill_id, _price_list_id, _from_date, _to_date, f.contract_id, 
				f.funding_id
            FROM
                public.fin_bill_spec_item               AS i 
                JOIN billing.fin_bill_generate           AS f ON f.fin_bill_spec_item_id = i.id AND f.bill_id = i.bill_id
                JOIN public.fin_bill_spec_item_returned AS r ON r.id = i.id
            WHERE
                i.bill_id = _main_bill_id AND r.correctional_bill_id = p1_bill_id
        ;
    END IF;
    IF _is_log THEN insert into billing.kurgan_fin_bill_status_log (bill_id, dt, step_code) values (p1_bill_id, clock_timestamp (),'fin_spec_gen_pick2. Конец'); END IF;	
   
EXCEPTION
    WHEN NO_DATA_FOUND THEN RAISE EXCEPTION 'Не заполнены необходимые параметры, либо неправильные данные счёта';
END;
$$;

