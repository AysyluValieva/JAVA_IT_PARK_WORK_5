CREATE FUNCTION create_fk_indexes()
  RETURNS character varying
LANGUAGE plpgsql
AS $$
declare
fk record;
col record;
ix record;
col_name_ix varchar(300);
col_name_fk varchar(300);
col_ix int2vector;
idx_exists bool;
tab_name varchar(300);
i int;
col_fk_list varchar(1000);
index_list varchar;
begin
for fk in select * from information_schema.referential_constraints rc loop
   select into tab_name table_name from information_schema.key_column_usage kcu 
   where kcu.constraint_name = fk.constraint_name 
     and kcu.constraint_schema = fk.constraint_schema;
   idx_exists := false;
   for ix in 
      -- get all indexes for given table
      select * from pg_index ix1 where ix1.indrelid in (select oid from pg_class where lower(relname) = lower(tab_name)) loop
      i := 0;
      while ix.indkey[i] is not null loop -- loop through index columns
         col_name_fk := null;
         select into col_name_fk kcu.column_name
         from information_schema.key_column_usage kcu 
         where kcu.constraint_name = fk.constraint_name 
           and kcu.constraint_schema = fk.constraint_schema
           and kcu.column_name = (select attname from pg_attribute where attnum = ix.indkey[i] and attrelid = ix.indrelid);
         if col_name_fk is null then exit; end if; -- that is - index columns NOT match constraint columns
         i := i + 1;
      end loop;
      idx_exists := col_name_fk is not null;
      if idx_exists then exit; end if; -- if index already defined
   end loop;
   if not idx_exists then
      col_fk_list := null;
      for col in select *
         from information_schema.key_column_usage kcu 
         where kcu.constraint_name = fk.constraint_name 
           and kcu.constraint_schema = fk.constraint_schema loop
         if col_fk_list is null then col_fk_list := col.column_name;
         else col_fk_list := ','||col.column_name;
         end if;
      end loop;
      index_list := index_list || ';' || 'create index '||fk.constraint_name||' on '||tab_name||'('||col_fk_list||')';
   end if;
   raise notice '% % %', tab_name, fk.constraint_name, idx_exists;
end loop;
return index_list;
end;
$$;

