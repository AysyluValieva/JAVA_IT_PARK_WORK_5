CREATE FUNCTION apda_check_address_by_building_pattern(house_name character varying, flat_name character varying, building_pattern character varying)
  RETURNS boolean
LANGUAGE plpgsql
AS $$
DECLARE
  items1 apda_district_address_build_pattern_items;
  items2 apda_district_address_build_pattern_items;
  array1 VARCHAR [];
  array2 VARCHAR [];
BEGIN
  IF $1 ISNULL OR $1 = ''
  THEN RETURN FALSE; END IF;

  items1 = apda_get_apda_district_address_build_pattern_items($3);

  --проверяем наличия в исключениях
  array1 = (items1).excludes;
  IF array1 NOTNULL AND array_length(array1, 1) > 0
  THEN
    FOR i IN array_lower(array1, 1)..array_upper(array1, 1) LOOP
      items2 = apda_get_apda_district_address_build_pattern_items(
          substr(array1 [i] :: VARCHAR, 3, length(array1 [i] :: VARCHAR) - 3));
      array2 = (items2).includes;
      IF array2 NOTNULL AND array_length(array2, 1) > 0
      THEN
        FOR j IN array_lower(array2, 1)..array_upper(array2, 1) LOOP
          IF apda_check_address_by_building_pattern_item($1, $2, array2 [j] :: VARCHAR)
          THEN RETURN FALSE;
          END IF;
        END LOOP;
      END IF;
    END LOOP;
  END IF;

  --проверяем наличия во включениях
  array1 = (items1).includes;
  IF array1 NOTNULL AND array_length(array1, 1) > 0
  THEN
    FOR i IN array_lower(array1, 1)..array_upper(array1, 1) LOOP
      IF apda_check_address_by_building_pattern_item($1, $2, array1 [i] :: VARCHAR)
      THEN RETURN TRUE;
      END IF;
    END LOOP;
  END IF;

  RETURN FALSE;
END;
$$;

