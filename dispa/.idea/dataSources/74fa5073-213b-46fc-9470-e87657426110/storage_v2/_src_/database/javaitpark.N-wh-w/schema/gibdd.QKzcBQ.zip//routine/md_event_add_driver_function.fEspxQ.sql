CREATE FUNCTION md_event_add_driver_function(xeid integer, xpid integer, xseries character varying, xnumber character varying, xblankdate date, xcategories character varying)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
  i integer;
  categoryid json;
  service integer;

  services_for_patient_age  integer [];
begin
  i = nextval('disp.md_event_patient_id_seq');
  insert into disp.md_event_patient (id, event_id, indiv_id, event_age) values (i, xeid, xpid,(SELECT CONCAT(date_part('year',age(birth_dt)), '.', date_part('month',age(birth_dt))) FROM pim_individual where id = xpid));
  insert into gibdd.md_gibdd_reference (id, blank_date, status) values (i, xblankdate, 1);
  insert into gibdd.md_gibdd_reference_reference (series, number, card_id) values (xseries,xnumber,i);

  foreach categoryid in array array(select value from json_array_elements(cast(xcategories as json)))
  LOOP
    insert into gibdd.md_gibdd_reference_category(reference_id, category_id) values (i, categoryid::text::int);
  END LOOP;
  services_for_patient_age := (select disp.select_service_for_gibdd_patient_licences (i, (select event_age from disp.md_event_patient where id=i), xcategories));
  if(services_for_patient_age is not null) then
    foreach service in array services_for_patient_age
    loop
      insert into disp.md_event_service_patient (id, service_id, indiv_id, event_id, event_patient_id) values (nextval('disp.md_event_service_patient_id_seq'), service, xpid, xeid, i);
    end loop;
  end if;

  PERFORM gibdd.agreedisprforpatient(null::integer, to_char(current_date, 'DD-MM-YYYY'), i);
  return i;
end;
$$;

