CREATE FUNCTION orphans_agreement(xepid integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
   checkserviceId json;
   xcheckservices character varying;
begin
   delete from disp.md_event_service_patient mesp where event_patient_id=xepid;

   xcheckservices= (select array_to_json(array_agg(row_to_json(serv)))
                      from (
                              select unnest(disp.select_service_for_all_patient_agreement(xepid,(select case
                                                                                                           when position('.' in event_age) = 0 then concat(event_age, '.0')
                                                                                                           else event_age
                                                                                                         end as event_age
                                                                                                   from disp.md_event_patient
                                                                                                  where id=xepid
                                                                                                )
                                                                                         )
                                           ) as id
                           ) as serv
                   );

   if xcheckservices is not null then

     --проставляют услуги по назначению (автомат)
     foreach checkserviceId in array array(select value from json_array_elements(cast(xcheckservices as json)))
        loop
           insert into disp.md_event_service_patient (id, service_id, indiv_id, event_id,event_patient_id)
           values (nextval('disp.md_event_service_patient_id_seq'),
                  (select id
                     from disp.md_event_service
                    where id= cast(checkserviceId::json->>'id' as integer)
                      and event_id = (select event_id
                                        from disp.md_event_patient
                                       where id = xepid
                                     )
                  ),
                 (select indiv_id
                    from disp.md_event_patient
                   where id = xepid
                 ),
                 (select event_id
                    from disp.md_event_patient
                   where id = xepid
                 ),
                 xepid
                 );
        end loop;

   end if;

   return 1;
end;
$$;

