CREATE FUNCTION fsym_on_u_for_mb_pm_trnsprt_mngrp()
  RETURNS trigger
LANGUAGE plpgsql
AS $fun$
declare var_row_data text; 
                                declare var_old_data text; 
                                begin
                                   
                                  if 1=1 and "public".sym_triggers_disabled() = 0 then                                                                                                 
                                    var_row_data := 
          case when new."id" is null then '' else '"' || cast(cast(new."id" as numeric) as varchar) || '"' end||','||
          case when new."org_id" is null then '' else '"' || cast(cast(new."org_id" as numeric) as varchar) || '"' end||','||
          case when new."code" is null then '' else '"' || replace(replace(cast(new."code" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."inventory_number" is null then '' else '"' || replace(replace(cast(new."inventory_number" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."okof_code" is null then '' else '"' || replace(replace(cast(new."okof_code" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."category_id" is null then '' else '"' || cast(cast(new."category_id" as numeric) as varchar) || '"' end||','||
          case when new."type_id" is null then '' else '"' || cast(cast(new."type_id" as numeric) as varchar) || '"' end||','||
          case when new."transport_equipment_id" is null then '' else '"' || cast(cast(new."transport_equipment_id" as numeric) as varchar) || '"' end||','||
          case when new."brand_name_id" is null then '' else '"' || cast(cast(new."brand_name_id" as numeric) as varchar) || '"' end||','||
          case when new."model_id" is null then '' else '"' || cast(cast(new."model_id" as numeric) as varchar) || '"' end||','||
          case when new."model" is null then '' else '"' || replace(replace(cast(new."model" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when new."manufacturer_id" is null then '' else '"' || cast(cast(new."manufacturer_id" as numeric) as varchar) || '"' end||','||
          case when new."country_id" is null then '' else '"' || cast(cast(new."country_id" as numeric) as varchar) || '"' end||','||
          case when new."issue_dt" is null then '' else '"' || to_char(new."issue_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when new."department_id" is null then '' else '"' || cast(cast(new."department_id" as numeric) as varchar) || '"' end||','||
          case when new."purchase_dt" is null then '' else '"' || to_char(new."purchase_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when new."ownership_pattern_id" is null then '' else '"' || cast(cast(new."ownership_pattern_id" as numeric) as varchar) || '"' end||','||
          case when new."warranty_dt" is null then '' else '"' || to_char(new."warranty_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when new."service_period" is null then '' else '"' || cast(cast(new."service_period" as numeric) as varchar) || '"' end||','||
          case when new."service_measure_id" is null then '' else '"' || cast(cast(new."service_measure_id" as numeric) as varchar) || '"' end||','||
          case when new."building_id" is null then '' else '"' || cast(cast(new."building_id" as numeric) as varchar) || '"' end||','||
          case when new."room_id" is null then '' else '"' || cast(cast(new."room_id" as numeric) as varchar) || '"' end||','||
          case when new."contract_id" is null then '' else '"' || cast(cast(new."contract_id" as numeric) as varchar) || '"' end||','||
          case when new."from_dt" is null then '' else '"' || to_char(new."from_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when new."to_dt" is null then '' else '"' || to_char(new."to_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when new."unit_id" is null then '' else '"' || cast(cast(new."unit_id" as numeric) as varchar) || '"' end||','||
          case when new."inventory_code" is null then '' else '"' || replace(replace(cast(new."inventory_code" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end; 
                                    var_old_data := 
          case when old."id" is null then '' else '"' || cast(cast(old."id" as numeric) as varchar) || '"' end||','||
          case when old."org_id" is null then '' else '"' || cast(cast(old."org_id" as numeric) as varchar) || '"' end||','||
          case when old."code" is null then '' else '"' || replace(replace(cast(old."code" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when old."inventory_number" is null then '' else '"' || replace(replace(cast(old."inventory_number" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when old."okof_code" is null then '' else '"' || replace(replace(cast(old."okof_code" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when old."category_id" is null then '' else '"' || cast(cast(old."category_id" as numeric) as varchar) || '"' end||','||
          case when old."type_id" is null then '' else '"' || cast(cast(old."type_id" as numeric) as varchar) || '"' end||','||
          case when old."transport_equipment_id" is null then '' else '"' || cast(cast(old."transport_equipment_id" as numeric) as varchar) || '"' end||','||
          case when old."brand_name_id" is null then '' else '"' || cast(cast(old."brand_name_id" as numeric) as varchar) || '"' end||','||
          case when old."model_id" is null then '' else '"' || cast(cast(old."model_id" as numeric) as varchar) || '"' end||','||
          case when old."model" is null then '' else '"' || replace(replace(cast(old."model" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end||','||
          case when old."manufacturer_id" is null then '' else '"' || cast(cast(old."manufacturer_id" as numeric) as varchar) || '"' end||','||
          case when old."country_id" is null then '' else '"' || cast(cast(old."country_id" as numeric) as varchar) || '"' end||','||
          case when old."issue_dt" is null then '' else '"' || to_char(old."issue_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when old."department_id" is null then '' else '"' || cast(cast(old."department_id" as numeric) as varchar) || '"' end||','||
          case when old."purchase_dt" is null then '' else '"' || to_char(old."purchase_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when old."ownership_pattern_id" is null then '' else '"' || cast(cast(old."ownership_pattern_id" as numeric) as varchar) || '"' end||','||
          case when old."warranty_dt" is null then '' else '"' || to_char(old."warranty_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when old."service_period" is null then '' else '"' || cast(cast(old."service_period" as numeric) as varchar) || '"' end||','||
          case when old."service_measure_id" is null then '' else '"' || cast(cast(old."service_measure_id" as numeric) as varchar) || '"' end||','||
          case when old."building_id" is null then '' else '"' || cast(cast(old."building_id" as numeric) as varchar) || '"' end||','||
          case when old."room_id" is null then '' else '"' || cast(cast(old."room_id" as numeric) as varchar) || '"' end||','||
          case when old."contract_id" is null then '' else '"' || cast(cast(old."contract_id" as numeric) as varchar) || '"' end||','||
          case when old."from_dt" is null then '' else '"' || to_char(old."from_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when old."to_dt" is null then '' else '"' || to_char(old."to_dt", 'YYYY-MM-DD HH24:MI:SS') || '"' end||','||
          case when old."unit_id" is null then '' else '"' || cast(cast(old."unit_id" as numeric) as varchar) || '"' end||','||
          case when old."inventory_code" is null then '' else '"' || replace(replace(cast(old."inventory_code" as varchar),$$\$$,$$\\$$),'"',$$\"$$) || '"' end; 
                                    if 1=1 then 
                                    insert into "public".sym_data                                                                                                                     
                                    (table_name, event_type, trigger_hist_id, pk_data, row_data, old_data, channel_id, transaction_id, source_node_id, external_data, create_time)                     
                                    values(                                                                                                                                                            
                                      'pim_transport',                                                                                                                                            
                                      'U',                                                                                                                                                             
                                      34,                                                                                                                                             
                                      
          case when old."id" is null then '' else '"' || cast(cast(old."id" as numeric) as varchar) || '"' end,                                                                                                                                                      
                                      var_row_data,                                                                                                                                                      
                                      var_old_data,                                                                                                                                                   
                                      'amb_pim_transport_default',                                                                                                                                                
                                      txid_current(),                                                                                                                                               
                                      "public".sym_node_disabled(),                                                                                                                   
                                      null,                                                                                                                                               
                                      CURRENT_TIMESTAMP                                                                                                                
                                    );                                                                                                                                                                 
                                  end if;                                                                                                                                                              
                                  end if;                                                                                                                                                              
                                                                                                                                                                               
                                  return null;                                                                                                                                                         
                                end;
$fun$;

