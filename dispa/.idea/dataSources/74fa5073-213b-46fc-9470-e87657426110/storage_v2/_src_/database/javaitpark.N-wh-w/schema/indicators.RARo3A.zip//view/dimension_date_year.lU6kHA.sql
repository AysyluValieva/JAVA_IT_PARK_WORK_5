CREATE VIEW dimension_date_year AS
  SELECT dimension_date.id,
    dimension_date.year_,
    dimension_date.aud_who,
    dimension_date.aud_when,
    dimension_date.aud_source,
    dimension_date.aud_who_create,
    dimension_date.aud_when_create,
    dimension_date.aud_source_create
   FROM indicators.dimension_date
  WHERE (dimension_date.dimension_date_def_id = 1);

COMMENT ON VIEW dimension_date_year IS 'Временной срез. Год';

COMMENT ON COLUMN dimension_date_year.id IS 'Идентификатор';

COMMENT ON COLUMN dimension_date_year.year_ IS 'Год';

