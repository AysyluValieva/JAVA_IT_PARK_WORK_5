CREATE FUNCTION save_account_diagnosis_info(xid integer, xaccountid integer, xyearofdiag integer, xcurrentdiabtypeid integer, xanothercurrdiabtype text, xprevdiabtypeid integer, xanotherprevdiabtype text, xdiabtypechangeyear integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
DECLARE
  _id INTEGER;
BEGIN
  _id = xid;

  IF (_id IS NULL)
  THEN
    INSERT INTO d_accounting.account_diagnosis_info (id, account_id, year_of_diagnosis, current_diabetes_type_id, another_current_diabetes_type,
                                                     previous_diabetes_type_id, another_previous_diabetes_type, diabetes_type_change_year)
    VALUES (nextval('d_accounting.account_diagnosis_info_seq'), xaccountId,xyearOfDiag, xcurrentDiabTypeId, xanotherCurrDiabType,
            xprevDiabTypeId, xanotherPrevDiabType, xdiabTypeChangeYear)
    RETURNING id
      INTO _id;
  ELSE
    UPDATE d_accounting.account_diagnosis_info
    SET year_of_diagnosis           = xyearOfDiag, current_diabetes_type_id = xcurrentDiabTypeId,
      another_current_diabetes_type = xanotherCurrDiabType,
      previous_diabetes_type_id     = xprevDiabTypeId, another_previous_diabetes_type = xanotherPrevDiabType,
      diabetes_type_change_year     = xdiabTypeChangeYear
    WHERE id = _id;
  END IF;
  IF (xcurrentDiabTypeId <> 4)
  THEN
    UPDATE d_accounting.account_diagnosis_info
    SET another_current_diabetes_type = NULL
    WHERE id = _id;
  END IF;
  IF (xprevDiabTypeId <> 4)
  THEN
    UPDATE d_accounting.account_diagnosis_info
    SET another_previous_diabetes_type = NULL
    WHERE id = _id;
  END IF;

  RETURN _id;
END;
$$;

