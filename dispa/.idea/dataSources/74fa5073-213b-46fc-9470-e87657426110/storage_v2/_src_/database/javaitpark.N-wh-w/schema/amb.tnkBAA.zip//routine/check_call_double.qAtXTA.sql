CREATE FUNCTION check_call_double(xcall integer)
  RETURNS boolean
LANGUAGE plpgsql
AS $$
declare
                    xaddress_id INTEGER := (select address_id from amb.md_ambulance_call where id = xcall);
                    xpatient_id INTEGER := (select patient_id from amb.md_ambulance_call where id = xcall);
                    xelapsed_time interval :=
                        (select elapsed_time from amb.md_ambulance_notes_setting
                            where clinic_id = (select station_id from amb.md_ambulance_call where id = xcall) limit 1);

                    xf_time timestamp := (select from_time from amb.md_ambulance_call where id = xcall);
                    result boolean;
                  begin
                    result := false;
                    if exists (
                        select * from amb.md_ambulance_call cal
                        left join amb.md_ambulance_call_note cn on cal.id = cn.call_id and cn.note_id in (8,9) and cn.note_active is true and cn.note_type is true
                        left join amb.md_ambulance_call_double macd on macd.call_note_id = cn.id
                            where ((cal.address_id = xaddress_id) or (cal.patient_id = xpatient_id))
                                  and (cal.from_time between (cast(xf_time as timestamp) - CAST(xelapsed_time as interval)) and cast(xf_time as timestamp))
                                  and cal.id not in (xcall)
                                  or (macd.call_id = cal.id)
                              )
                     then
                        result:= true;
                     end if;
                     return result;
                  end;
$$;

