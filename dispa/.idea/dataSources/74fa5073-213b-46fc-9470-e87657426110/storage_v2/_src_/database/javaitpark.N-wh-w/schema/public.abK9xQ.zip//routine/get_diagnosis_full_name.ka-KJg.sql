CREATE FUNCTION get_diagnosis_full_name(diag_id integer)
  RETURNS text
LANGUAGE plpgsql
AS $$
DECLARE
    full_name text;
  BEGIN
    SELECT concat_ws(' ', code,tt.subcode, concat_ws(', ', name, tt.subname)) into full_name
    FROM 
      public.mc_diagnosis mc_d
      JOIN public.md_diagnosis md_d ON md_d.id = mc_d.diagnos_id
      LEFT JOIN (select da.diagnosis_id,
              array_to_string(array_agg(av.value order by ap.pos), '.') as subcode,
              array_to_string(array_agg(av.name order by ap.pos), '; ') as subname
            from mc_diag_attr da
              join mc_diagnosis dd on dd.id=da.diagnosis_id
              join md_attr_value av on av.id=da.attr_value_id
              join md_diag_attr mda on mda.id=av.diag_attr_id
              join md_attr_pos ap on ap.diag_attr_id=mda.id and ap.diagnosis_id=dd.diagnos_id
            group by da.diagnosis_id) as tt on tt.diagnosis_id = mc_d.id
    WHERE mc_d.id=diag_id;
    RETURN full_name;
  END;
$$;

