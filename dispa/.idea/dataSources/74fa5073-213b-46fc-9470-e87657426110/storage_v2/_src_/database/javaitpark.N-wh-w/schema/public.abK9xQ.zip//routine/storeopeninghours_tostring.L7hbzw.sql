CREATE FUNCTION storeopeninghours_tostring(numeric)
  RETURNS SETOF record
LANGUAGE plpgsql
AS $$
DECLARE
 open_id ALIAS FOR $1;
 result RECORD;
BEGIN
 RETURN QUERY SELECT '1', '2', '3';
 RETURN QUERY SELECT '3', '4', '5';
 RETURN QUERY SELECT '3', '4', '5';
END
$$;

