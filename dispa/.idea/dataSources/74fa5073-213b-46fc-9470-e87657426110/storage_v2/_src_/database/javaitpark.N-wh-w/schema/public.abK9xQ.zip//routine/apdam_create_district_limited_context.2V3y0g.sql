CREATE FUNCTION apdam_create_district_limited_context(in_md_clinic_id integer, in_check_district boolean, in_department_id integer, in_type_id integer, in_reg_date date)
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
  query VARCHAR;
BEGIN
  DROP TABLE IF EXISTS apdam_district;
  query = '
  CREATE UNLOGGED TABLE apdam_district WITH (AUTOVACUUM_ENABLED = FALSE) AS
  SELECT
    mcd.id               AS district_id,
    mcd.attache_number   AS attache_number,
    mcd.order_number     AS order_number,
    CASE WHEN ae.level_id > 6
      THEN 6
    ELSE ae.level_id END AS level_id,
    CASE WHEN ae.level_id = 6 THEN ae.id
    WHEN ae.level_id = 7
      THEN ae.parent_id
    WHEN ae.level_id = 8
      THEN ae2.parent_id
    ELSE ae.id
    END                 AS address_id,
    CASE WHEN ae.level_id > 5 AND da.building_pattern != ''''
      THEN da.building_pattern
    ELSE NULL END        AS building_pattern,
    c2.terminal_id       AS org_terminal_id,
    c3.terminal_id       AS diagnosis_terminal_id,
    c4.terminal_id       AS age_terminal_id,
    c5.terminal_id       AS gender_terminal_id,
    c6.terminal_id       AS benefit_terminal_id,
    orgs.c1              AS orgs,
    benefits.c1          AS benefits,
    diagnos_from.code    AS diagnos_code_from,
    diagnos_to.code      AS diagnos_code_to,
    d_age.from_age       AS age_from,
    d_age.to_age         AS age_to,
    d_gender.gender_id   AS gender_id
  FROM md_clinic_separation mcs
    JOIN md_clinic_district mcd ON mcd.separation_id = mcs.id
    JOIN md_district_address da ON da.district_id = mcd.id
    JOIN address_element ae ON ae.id = da.address_id AND ae.level_id > 3
    LEFT JOIN address_element ae2 ON ae2.id = ae.parent_id AND ae.level_id = 8
    LEFT JOIN md_district_criterion c1 ON c1.separation_id = mcs.id AND c1.type_id = 1
    LEFT JOIN md_district_criterion c2 ON c2.separation_id = mcs.id AND c2.type_id = 2
    LEFT JOIN md_district_criterion c3 ON c3.separation_id = mcs.id AND c3.type_id = 3
    LEFT JOIN md_district_criterion c4 ON c4.separation_id = mcs.id AND c4.type_id = 4
    LEFT JOIN md_district_criterion c5 ON c5.separation_id = mcs.id AND c5.type_id = 5
    LEFT JOIN md_district_criterion c6 ON c6.separation_id = mcs.id AND c6.type_id = 6
    LEFT JOIN md_district_diagnosis mdd ON mdd.district_id = mcd.id
    LEFT JOIN md_diagnosis diagnos_from ON mdd.from_diagnosis_id = diagnos_from.id
    LEFT JOIN md_diagnosis diagnos_to ON mdd.to_diagnosis_id = diagnos_to.id
    LEFT JOIN md_district_age d_age ON d_age.district_id = mcd.id
    LEFT JOIN md_district_gender d_gender ON d_gender.district_id = mcd.id
    LEFT JOIN pci_district_benefit d_benefit ON d_benefit.district_id = mcd.id
    ,
    LATERAL (SELECT array_agg(o.organization_id) AS c1
             FROM md_district_organization o
             WHERE o.district_id = mcd.id) orgs,
    LATERAL (SELECT array_agg(b.benefit_definition_id) AS c1
             FROM pci_district_benefit b
             WHERE b.district_id = mcd.id) benefits
  WHERE c1.terminal_id = 3
        AND mcs.clinic_id = $1
        AND mcs.reg_type_id = $2
        AND ($3 >= da.from_dt OR da.from_dt ISNULL)
        AND ($3 <= da.to_dt OR da.to_dt ISNULL)
        AND ($3 >= mcd.from_dt OR mcd.from_dt ISNULL)
        AND ($3 <= mcd.to_dt OR mcd.to_dt ISNULL)
        AND ($3 >= mcs.from_dt OR mcs.from_dt ISNULL)
        AND ($3 <= mcs.to_dt OR mcs.to_dt ISNULL)';

  IF in_department_id NOTNULL
  THEN query = query || ' AND mcs.department_id = ' || in_department_id;
  ELSEIF in_check_district = FALSE
    THEN query = query || ' AND mcs.department_id ISNULL';
  END IF;

  EXECUTE query
  USING in_md_clinic_id, in_type_id, in_reg_date;

  CREATE INDEX ON apdam_district USING BTREE (address_id);
END;
$$;

