CREATE FUNCTION add_ambcall_priority_hist(xcall integer, xdt timestamp without time zone, xprior integer, xreg integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
	i integer;
  begin
    /*добавление записи о смене приоритета в историю*/
	i = nextval('amb.md_ambcall_priority_history_id_seq');
    insert into amb.md_ambcall_priority_history (id,call_id,date_time,priority_id,registrator_id)
    	VALUES(i,xcall,xdt,xprior,xreg);
    return i;
  end;
$$;

