CREATE FUNCTION fin_spec_gen_item(p1_bill_id integer, p2_status text)
  RETURNS void
STRICT
LANGUAGE plpgsql
AS $$
BEGIN
    /*
        version: 2015-04-09
    */
    -------------------------------------------------------------отсеивание--------------------------------------------------------------------------
    IF 
        p2_status = 'GENERATE' AND billing.fin_bill__get_sift_status ('SIFT_INCORRECT_SERVICE') 
    THEN
        WITH t AS 
        (
            SELECT
                f.bill_id, f.id
            FROM
                billing.fin_bill_generate            AS f
                LEFT JOIN public.sr_srv_rendered    AS r ON f.id = r.id
                LEFT JOIN public.pim_individual_doc AS i ON i.id = f.active_policy_id
            WHERE
                f.bill_id = p1_bill_id AND NOT f.is_sifted AND f.active_policy_id IS NOT NULL AND (r IS NULL OR i IS NULL)
        )
        UPDATE billing.fin_bill_generate AS f
        SET 
            is_sifted = TRUE, sifting_cause = 'Услуга или полис отсутствует в базе' 
        FROM t
        WHERE 
            f.bill_id = t.bill_id AND f.id = t.id
        ;
    END IF;
    -----------------------------------------------------------номер записи в выгрузке---------------------------------------------------------------
    WITH t AS 
    (
        SELECT bill_id, id, dense_rank () OVER (ORDER BY patient_id, active_policy_id) AS n_zap FROM billing.fin_bill_generate WHERE bill_id = p1_bill_id AND NOT is_sifted AND n_zap IS NULL
    )
    UPDATE billing.fin_bill_generate AS f
    SET
        n_zap = t.n_zap
    FROM t
    WHERE
        t.bill_id = f.bill_id AND t.id = f.id
    ;
    ---------------------------------------------------------вставка в спецификацию------------------------------------------------------------------
    --генерирование id для спецификации
    UPDATE billing.fin_bill_generate
    SET 
        b_fin_bill_spec_item_id = nextval ('public.fin_bill_spec_item_seq')
    WHERE
        bill_id = p1_bill_id AND NOT is_sifted
    ;
    --добавление в спецификацию
    INSERT INTO public.fin_bill_spec_item (price, tariff, id, is_deleted, bill_id, service_id, doc_id, number, comment, status_id)
        SELECT
            round (price, 2) AS price, tariff, b_fin_bill_spec_item_id AS id, is_deleted, bill_id, id AS service_id, 
            active_policy_id AS doc_id, n_zap AS number, item_comment, 1 AS default_status_id
        FROM 
            billing.fin_bill_generate
        WHERE 
            bill_id = p1_bill_id AND NOT is_sifted
    ;
    UPDATE billing.fin_bill_generate 
    SET 
        fin_bill_spec_item_id = b_fin_bill_spec_item_id
    WHERE 
        fin_bill_spec_item_id IS NULL AND bill_id = p1_bill_id AND NOT is_sifted
    ;
EXCEPTION
    WHEN NO_DATA_FOUND THEN RAISE EXCEPTION 'Отсутствуют данные по счёту';
END;
$$;

