CREATE FUNCTION clear_service(xid integer, xmespid integer, xevent_patient_id integer, xcase_id integer, xssr_type_id integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
            _id INTEGER;
            stepId integer;
            deleteProhibited boolean;
            BEGIN
            --   из за того что при сохранении не успевает отработать функция оказания услуги, id услуги не подгружается, приходится вручную вытаскивать данные
            _id = coalesce($1,(
            select ssr.id from MD_SRV_RENDERED msr
            left join SR_SRV_RENDERED ssr on ssr.id = msr.id
            WHERE msr.case_id = $4 and ssr.service_id = $5 limit 1
            ));
            delete from gibdd.md_gibdd_service_category where gibdd_service_id = (select id from gibdd.md_gibdd_service where service_id = _id);
            delete from gibdd.md_gibdd_service where service_id = _id;
            delete from disp.md_referral_extended where id in (select id from md_referral where service_id = _id);

            -- идентификатор шага/посещения
            stepId = (select mrs.step_id from md_srv_rendered mrs where mrs.id = _id);

            delete from SR_SRV_RENDERED where id = _id;
            delete from MD_SRV_RENDERED where id = _id;

            -- проверка на возможность и удаление посещения
            deleteProhibited = (select exists (select 1 from md_srv_rendered mrs where mrs.step_id = stepId));
            if (not deleteProhibited) then
            delete from plc_visit where id = stepId;
            delete from mc_step where id = stepId;
            end if;

            update disp.md_event_service_patient set status = 1 where id = $2;
            PERFORM gibdd.set_contraindication($3);
            END;
$$;

