CREATE FUNCTION add_prescription_execution()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE
    percent_execution_var integer;   
BEGIN
    IF    TG_OP = 'INSERT' THEN
        IF (NEW.patient_prescription_id is not null) THEN
            percent_execution_var = prescribed_services_execution(NEW.patient_prescription_id);
            IF(percent_execution_var is null) THEN
               percent_execution_var := 0;
            END IF;
            UPDATE md_patient_prescription SET percent_execution = percent_execution_var WHERE id = NEW.patient_prescription_id;   
        END IF;
        RETURN NEW;
    ELSIF TG_OP = 'UPDATE' THEN
       IF (NEW.patient_prescription_id is not null) THEN
            percent_execution_var := prescribed_services_execution(NEW.patient_prescription_id);
            IF(percent_execution_var is null) THEN
               percent_execution_var := 0;
            END IF;
            UPDATE md_patient_prescription SET percent_execution = percent_execution_var WHERE id = NEW.patient_prescription_id;   
        END IF;
        RETURN NEW;
    ELSIF TG_OP = 'DELETE' THEN
        IF (OLD.patient_prescription_id is not null) THEN
            percent_execution_var := prescribed_services_execution(OLD.patient_prescription_id);
            IF(percent_execution_var is null) THEN
               percent_execution_var := 0;
            END IF;
            UPDATE md_patient_prescription SET percent_execution = percent_execution_var WHERE id = OLD.patient_prescription_id;   
        END IF;
        RETURN OLD;
    END IF;
END;
$$;

