CREATE FUNCTION checkpatient_2017(p_arianumber text DEFAULT NULL::integer, p_birthday date DEFAULT NULL::date, p_cellphone text DEFAULT NULL::text, p_document_n text DEFAULT NULL::text, p_document_s text DEFAULT NULL::text, p_homephone text DEFAULT NULL::text, p_idpat text DEFAULT NULL::text, p_name text DEFAULT NULL::text, p_polis_n text DEFAULT NULL::text, p_polis_s text DEFAULT NULL::text, p_secondname text DEFAULT NULL::text, p_surname text DEFAULT NULL::text, p_lpuid text DEFAULT NULL::text)
  RETURNS TABLE(idpat integer)
LANGUAGE plpgsql
AS $$
DECLARE
v_rec public.typ_searchtop10patient%ROWTYPE;
_result BOOLEAN;
BEGIN

  if( upper(p_arianumber::TEXT)='NULL::TEXT' or upper(p_arianumber::TEXT)='NULL' or p_arianumber::TEXT='') then  p_arianumber=NULL; end if;
   if( upper(p_birthday::TEXT)='NULL::date'  or upper(p_birthday::TEXT)='NULL' or p_birthday::TEXT='' ) then  p_birthday=NULL; end if;
    if( upper(p_cellphone)='NULL::TEXT'  or upper(p_cellphone)='NULL' or p_cellphone='') then  p_cellphone=NULL; end if;
      if( upper(p_document_n)='NULL::TEXT' or upper(p_document_n)='NULL' or p_document_n='') then  p_document_n=NULL; end if;
   if( upper(p_document_s)='NULL::TEXT'  or upper(p_document_s)='NULL' or p_document_s='' ) then  p_document_s=NULL; end if;
    if( upper(p_homephone)='NULL::TEXT'  or upper(p_homephone)='NULL' or p_homephone='') then  p_homephone=NULL; end if;
      if( upper(p_idpat)='NULL::TEXT' or upper(p_idpat)='NULL' or p_idpat='') then  p_idpat=NULL; end if;
   if( upper(p_name)='NULL::TEXT'  or upper(p_name)='NULL' or p_name='' ) then  p_name=NULL; end if;
    if( upper(p_polis_n)='NULL::TEXT'  or upper(p_polis_n)='NULL' or p_polis_n='') then  p_polis_n=NULL; end if;
      if( upper(p_polis_s)='NULL::TEXT' or upper(p_polis_s)='NULL' or p_polis_s='') then  p_polis_s=NULL; end if;
   if( upper(p_secondname)='NULL::TEXT'  or upper(p_secondname)='NULL' or p_secondname='' ) then  p_secondname=NULL; end if;
    if( upper(p_surname)='NULL::TEXT'  or upper(p_surname)='NULL' or p_surname='') then  p_surname=NULL; end if;
    if( upper(p_lpuid)='NULL::TEXT'  or upper(p_lpuid)='NULL' or p_lpuid='') then  p_lpuid=NULL; end if;


  return query (with main as (select 
 					pi.id,
 					ppr.district_id,--AriaNumber
 					pi.name,
                    pi.surname,--Surname
                    pi.patr_name, --SecondName
                    pi.birth_dt	 --Birthday
 					from pim_individual pi

left join  pci_patient_reg ppr  on ppr.patient_id=pi.id    

                    left join pim_individual_doc pid on pi.id=pid.indiv_id       
                    where coalesce (ppr.district_id::text, '%') ilike COALESCE(p_arianumber::text, '%') 
                    and pi.name ilike COALESCE(p_name, '%') 
                    and pi.surname ilike COALESCE(p_surname, '%') 
                    and pi.patr_name ilike COALESCE(p_secondname, '%') 
                   and pi.id BETWEEN (case when p_idpat is null then 0::integer  else p_idpat::integer end) 
                   								and (case when p_idpat is null then 999999999::integer  else p_idpat::integer end)
                    and   pi.birth_dt BETWEEN (case when p_birthday::date  is null then '01.01.1800'::date  else p_birthday::date  end) 
                   								and (case when p_birthday::date  is null then '01.01.2800'::date  else p_birthday::date  end)  
                   and  pid.number ilike  COALESCE(p_document_n, p_polis_n, '%')
                   and  pid.series ilike COALESCE(p_document_s,p_polis_s, '%')   
                   --and  ppr.clinic_id::text  ilike COALESCE(p_lpuid, '%')                                                        
                   -- and ppr.patient_id=6060824--
 )
 --select * from main
 , phones as 
 (
 	select
    pic.indiv_id 
    ,get_phone(pic.indiv_id, 2) mob
    ,get_phone(pic.indiv_id, 3) dom
    from main
    join pim_indiv_contact pic on pic.indiv_id=main.id
    where pic.value like COALESCE(p_cellphone, p_homephone, '%') 
 )
 select case when exists( select 
 1
 from main
 left join phones on phones.indiv_id=main.id
 limit 1)
 then main.id 
 else 0
 end 
 from main
 left join phones on phones.indiv_id=main.id
 limit 1
 );
 
--return _result;
  
END;
$$;

